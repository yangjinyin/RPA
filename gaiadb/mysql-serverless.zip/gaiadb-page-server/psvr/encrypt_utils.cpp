#include "psvr/encrypt_utils.h"

namespace psvr {

bool BlockAccessCipherStream::encrypt(char *data, size_t data_size) {
    std::unique_ptr<unsigned char[]> buf (new (std::nothrow) unsigned char[data_size]);
    if (buf.get() == nullptr) {
        return false;
    }
    int ret = gaiadb::common::cipher::encrypt_block(
            reinterpret_cast<const unsigned char *>(data), data_size, buf.get(),
            reinterpret_cast<const unsigned char *>(_key.data()), _key.size(), _mode,
            reinterpret_cast<const unsigned char *>(_iv.data()));
    if (ret != 0) {
        return false;
    }
    memcpy(data, buf.get(), data_size);
    return true;
}

bool BlockAccessCipherStream::decrypt(char *data, size_t data_size) {
    // decrypt_block may write up to (main_len + BLOCK_SIZE * 2) bytes when
    // the input is not 16-byte aligned, which can exceed data_size by up to
    // 31 bytes. Allocate extra space to avoid heap corruption.
    const size_t buf_size = data_size + gaiadb::common::cipher::BLOCK_SIZE * 2;
    std::unique_ptr<unsigned char[]> buf (new (std::nothrow) unsigned char[buf_size]);
    if (buf.get() == nullptr) {
        return false;
    }
    int ret = gaiadb::common::cipher::decrypt_block(
            reinterpret_cast<const unsigned char *>(data), data_size, buf.get(),
            reinterpret_cast<const unsigned char *>(_key.data()), _key.size(), _mode,
            reinterpret_cast<const unsigned char *>(_iv.data()));
    if (ret != 0) {
        return false;
    }
    memcpy(data, buf.get(), data_size);
    return true;
}

bool BlockAccessCipherStream::encrypt_page(gaia_apply::space_id_t logical_space_id,
                                           gaia_apply::page_no_t logical_page_no,
                                           gaia_apply::byte *data) {
    gaia_apply::ulint page_type = gaia_apply::fil_page_get_type(data);
    gaia_apply::space_id_t page_space = gaia_apply::page_get_space_id(data);
    gaia_apply::space_id_t page_no = gaia_apply::page_get_page_no(data);

    if (page_type == gaia_apply::FIL_PAGE_RTREE
        || page_type == gaia_apply::FIL_PAGE_COMPRESSED // if data is compressed
        || page_type == gaia_apply::FIL_PAGE_ENCRYPTED // if data has been encrypted
        || page_type == gaia_apply::FIL_PAGE_COMPRESSED_AND_ENCRYPTED // if data has been commpressed and encrypted
        || page_space != logical_space_id
        || page_no != logical_page_no
        || page_no < 2 ) { // ignore page 0 and page 1
        LOG(TRACE) << "write page data does not meet encrypt conditions,"
                   << " page_type:[" << page_type << "] page_space:[" << page_space
                   << "] page_no:[" << page_no << "] logical_space_id:[" << logical_space_id
                   << "] logical_page_no:[" << logical_page_no << "]";
        return true;
    }

    // page body - page header
    gaia_apply::ulint real_data_size = gaia_apply::FLAGS_univ_page_size - gaia_apply::FIL_PAGE_DATA;
    bool res = encrypt(reinterpret_cast<char*>(data) + gaia_apply::FIL_PAGE_DATA, real_data_size);
    if (!res) {
        return false;
    }

    INIT_APPLY_RAW_ARG(false);
    // reset page type to encrypt type
    gaia_apply::mach_write_to_2(data + gaia_apply::FIL_PAGE_TYPE, gaia_apply::FIL_PAGE_ENCRYPTED APPLY_RAW_ARG_NAME_CC);
    if (!APPLY_RAW_IS_ERROR()) {
        gaia_apply::mach_write_to_2(data + gaia_apply::FIL_PAGE_ORIGINAL_TYPE_V1, page_type APPLY_RAW_ARG_NAME_CC);
    }
    if (APPLY_RAW_IS_ERROR()) {
        LOG(ERROR) << "set page type error,"
                   << " page_type:[" << gaia_apply::FIL_PAGE_ENCRYPTED
                   << "] page_type:[" << page_type
                   << "] real_data_size:[" << real_data_size
                   << "]";
        return false;
    }

    LOG(TRACE) << "encrypt page success, page_space:[" << page_space << "] page_no:[" << page_no << "]";

    return true;
}

bool BlockAccessCipherStream::decrypt_page(gaia_apply::byte *data, gaia_apply::ulint size) {
    INIT_APPLY_RAW_ARG(false);

    gaia_apply::space_id_t page_space = gaia_apply::page_get_space_id(data);
    gaia_apply::space_id_t page_no = gaia_apply::page_get_page_no(data);
    gaia_apply::ulint original_type = gaia_apply::mach_read_from_2(data + gaia_apply::FIL_PAGE_ORIGINAL_TYPE_V1);
    gaia_apply::ulint page_type = gaia_apply::fil_page_get_type(data);
    if (page_type != gaia_apply::FIL_PAGE_ENCRYPTED) {
        return true;
    }
    if (size != gaia_apply::FLAGS_univ_page_size) {
        LOG(ERROR) << "decrypt page faild, real_data_size:[" << size << "] FLAGS_univ_page_size:["
                   << gaia_apply::FLAGS_univ_page_size << "]";
        return false;
    }

    // page body - page header
    gaia_apply::ulint real_data_size = gaia_apply::FLAGS_univ_page_size - gaia_apply::FIL_PAGE_DATA;
    bool res = decrypt(reinterpret_cast<char*>(data) + gaia_apply::FIL_PAGE_DATA, real_data_size);
    if (!res) {
        LOG(ERROR) << "decrypt page failed, page_type:[" << page_type << "] page_space:["
                   << page_space << "] page_no:[" << page_no << "]";
        return false;
    }

    LOG(TRACE) << "decrypt page success, page_space:[" << page_space << "] page_no:[" << page_no << "]";

    gaia_apply::mach_write_to_2(data + gaia_apply::FIL_PAGE_TYPE,
                                original_type APPLY_RAW_ARG_NAME_CC);  // reset page type
    if (APPLY_RAW_IS_ERROR()) {
        LOG(ERROR) << "set type error, type:" << original_type;
        return false;
    }

    return true;
}

};  // namespace psvr
