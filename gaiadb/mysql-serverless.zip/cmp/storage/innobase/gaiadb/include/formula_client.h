/*****************************************************************************

Copyright (c) 2022, Baidu and/or its affiliates. All Rights Reserved.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

#pragma once

#include <gflags/gflags.h>
#include <future>
#include "gaiadb/proto/formula/query.pb.h"
#include "gaiadb/psm_client/client.h"
#include "log0types.h"
#include "sql/range_optimizer/columnar_index_scan.h"
#include "sql/sql_class.h"

#include <baidu/rpc/stream.h>

namespace formula {

struct QueryContext;

class ResultReceiver : public brpc::StreamInputHandler {
 public:
  using StreamId = brpc::StreamId;

  static ResultReceiver *make(std::shared_ptr<QueryContext> &ctx);

  int on_received_messages(StreamId id, base::IOBuf *const messages[], 
                           size_t size) override;
  void on_idle_timeout(StreamId id) override;
  void on_closed(StreamId id) override;

 private:
  ResultReceiver(std::vector<std::shared_ptr<::ResultSet>> &sink,
                 std::atomic<bool> &eos, std::atomic<bool> &err)
    : sink_(sink), eos_(eos), err_(err) {}

  std::vector<std::shared_ptr<::ResultSet>> &sink_;
  std::atomic<bool> &eos_;
  std::atomic<bool> &err_;
};

struct QueryContext {
  QueryContext(std::atomic<bool> &_canceled,
               std::atomic<THD::killed_state> &_killed)
      : canceled(_canceled), killed(_killed) {}

  ~QueryContext() {}

  baidu::rpc::Controller *cntl;
  formula_pb::SelectQueryRequest *request;
  formula_pb::SelectQueryResponse *response;
  gaiadb::common::PeerZone server_addr;
  std::vector<gaiadb::common::PeerZone> backup_servers;

  lsn_t vlsn{0};
  uint64_t start_us{0};
  uint64_t real_start_us{0};
  int retry_count{0};
  uint32_t space_id{0};
  uint64_t index_id{0};
  int64_t log_id{0};

  uint32_t err_code{1};  // 0 means success
  std::string err_msg;

  std::vector<std::shared_ptr<::ResultSet>> results;
  std::atomic<bool> is_eos{false};
  std::atomic<bool> is_err{false};
  
  std::atomic<bool> is_done{false};
  std::atomic<bool> &canceled;
  std::atomic<THD::killed_state> &killed;
};

using QueryContextPtr = std::shared_ptr<QueryContext>;

class FormulaClient {
 public:
  static FormulaClient &get_instance() {
    static FormulaClient formula_client;
    return formula_client;
  }
  ~FormulaClient() {}

  int query(QueryContextPtr ctx);

  bool init(gaiadb::psm_client::Psmgr_client *psm_client);

 private:
  FormulaClient() : psm_client_(nullptr),  last_zone_version_(0) {}
  void do_query(QueryContextPtr ctx);
  void on_query(QueryContextPtr ctx);
  int get_column_stores(uint32_t space_id, uint64_t index_id,
                        std::vector<gaiadb::common::PeerZone> &stores,
                        bool force_sync);

 private:
  DISALLOW_COPY_AND_ASSIGN(FormulaClient);
  gaiadb::psm_client::Psmgr_client *psm_client_;
  gaiadb::common::RpcClient query_client_;
  uint32_t last_zone_version_;
};

}  // namespace formula
