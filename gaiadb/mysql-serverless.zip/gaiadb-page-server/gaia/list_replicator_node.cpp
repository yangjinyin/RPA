/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_replicator_node.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_replicator_node.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ListReplicatorNode::Run() {
    RpcStatus status;
    gaiapb::ListReplicatorNodeRequest request;
    gaiapb::ListReplicatorNodeResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    request.set_log_id(_log_id);

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_replicator_node, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " list replicator node failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("list failed, all nodes failed");
    return Output(response);
}

int ListReplicatorNode::Format(const gaiapb::ListReplicatorNodeResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.nodes_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({"node", "epoch", "token"}, true);
        for (auto& pb : rsp.nodes()) {
            table.AddRowsValue({pb.addr(), pb.epoch(), pb.token()});
        }
        table.Display();
    }
    return 0;
}

}
}
