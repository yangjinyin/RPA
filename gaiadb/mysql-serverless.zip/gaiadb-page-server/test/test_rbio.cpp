/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_rbio.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/rbio.h"
#include "test/mock_thread_pool.h"
#include "test/mock_queue.h"
#include "test/mock_rpc_client.h"
#include "test/mock_dbengine.h"
#include "test/mock_dblwr.h"
#include "bmock.h"

namespace psvr {
namespace test {

class RbioManagerTests : public PsvrTest {
 public:
    RbioManagerTests(): _rbio_manager(nullptr) {
        _mock_control->rbio_manager()->Stop();
    }

    virtual ~RbioManagerTests() {}

    void SetUp() {
        _rbio_manager.reset(new RbioManager(_mock_client, _control));

        //_mock_thread_pool = new MockExecutor<RbioManager::Context, thread::TaskContext>;
        _mock_thread_pool = new MockGroupThreadPoolExecutor<RbioManager::Context, thread::TaskContext>;
        _rbio_manager->_thread_pool.reset(_mock_thread_pool);

        _mock_condition_thread_pool = new MockGroupConditionThread<RbioManager::ConditionTask, RbioManager::ConditionQueue>;
        _rbio_manager->_condition_thread_pool.reset(_mock_condition_thread_pool);

        //EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillOnce(Return());

        gaia_apply::page_size_t page_size(16<<10, 16<<10, false);

        _rbio_manager->_stopped = false;

        // The mock objects created by BMOCK_NS_METHOD attach their hooks at static-init
        // time, so they would stay in effect for the whole binary. Stop them all here and
        // let each test enable only the ones it injects with BMOCK_NS_RESUME.
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        BMOCK_NS_STOP(psvr, check_buf_block_page_space, bool(BufBlockPtr, bool, gaia_apply::space_id_t*, gaia_apply::page_no_t*));
        BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
    }

    void TearDown() {
    }

private:
    RbioManagerPtr _rbio_manager;
    MockGroupThreadPoolExecutor<RbioManager::Context, thread::TaskContext>* _mock_thread_pool;
    MockGroupConditionThread<RbioManager::ConditionTask, RbioManager::ConditionQueue>* _mock_condition_thread_pool;
    //MockExecutor<RbioManager::Context, thread::TaskContext>* _mock_thread_pool;
};

bool MockExecuteOk(size_t, RbioManager::Context *ctx) {
    delete ctx;
    return true;
}

bool MockScheduleOk(size_t, thread::TaskContext* ctx, uint64_t) {
    delete ctx;
    return true;
}

void set_buf_block(BufBlockPtr buf_block, gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no, const gaia_apply::page_size_t& page_size, gaia_apply::lsn_t lsn = 1024) {
    init_buf_block(buf_block, space_id, page_no, page_size);
    gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, space_id);
    gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_OFFSET, page_no);
    page_set_page_lsn(buf_block->frame, page_size.physical(), lsn);
}

BMOCK_NS_METHOD3(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
BMOCK_NS_METHOD4(psvr, check_buf_block_page_space, bool(BufBlockPtr, bool, gaia_apply::space_id_t*, gaia_apply::page_no_t*));

TEST_F(RbioManagerTests, test_Task) {
    auto segment = create_segment();
    brpc::Controller cntl;
    {
        // test init failed
        page_server::RbioRequest request;
        page_server::RbioResponse response;
        RbioManager::ReadTask ctx(segment, 3, &cntl, &request, &response, nullptr);
        request.set_requestid(1111);
        request.set_n(3);
        request.set_readtype(pspb::RbioRequest::READ_SYNC);
        request.set_segment_id(segment->segment_id());
        request.set_cluster_id(segment->cluster_id());
        request.set_max_error_code(5);
        request.set_is_primary(true);

        for (int32_t i = 0; i < 3; ++i) {
            auto reqvec = request.add_reqvec();
            reqvec->set_tablespaceid(1);
            reqvec->set_logicalpageno(i);
            reqvec->set_vlsn(9999);
            reqvec->set_ziplen(gaia_logical_page_size());
        }
        segment->_parse_lsn(8888);
        FLAGS_psvr_segment_fetch_max_buf_size = 0;
        ctx.last_error_code = pspb::RbioResponse::RBIO_SEGMENT_NOT_EXIST;
        ASSERT_FALSE(ctx.Init(base::cpuwide_time_us()));
        ctx.is_primary_req();
    }
    {
        // test init on rule le
        page_server::RbioRequest request;
        page_server::RbioResponse response;
        RbioManager::ReadTask ctx(segment, 3, &cntl, &request, &response, nullptr);
        request.set_requestid(1111);
        request.set_n(3);
        request.set_readtype(pspb::RbioRequest::READ_SYNC);
        request.set_segment_id(segment->segment_id());
        request.set_cluster_id(segment->cluster_id());
        request.set_max_error_code(5);
        request.set_is_primary(false);
        request.set_version_rule(pspb::RbioRequest::LE);
        for (int32_t i = 0; i < 3; ++i) {
            auto reqvec = request.add_reqvec();
            reqvec->set_tablespaceid(1);
            reqvec->set_logicalpageno(i);
            reqvec->set_vlsn(9999);
            reqvec->set_ziplen(gaia_logical_page_size());
        }
        segment->_parse_lsn(8888);
        FLAGS_psvr_segment_fetch_max_buf_size = 0;
        ctx.last_error_code = pspb::RbioResponse::RBIO_SEGMENT_NOT_EXIST;
        ASSERT_TRUE(ctx.Init(base::cpuwide_time_us()));
    }
    {
        // test init ok
        page_server::RbioRequest request;
        page_server::RbioResponse response;
        RbioManager::ReadTask ctx(segment, 3, &cntl, &request, &response, nullptr);
        request.set_requestid(1111);
        request.set_n(3);
        request.set_readtype(pspb::RbioRequest::READ_SYNC);
        request.set_segment_id(segment->segment_id());
        request.set_cluster_id(segment->cluster_id());
        request.set_max_error_code(5);
        request.set_is_primary(true);
        for (int32_t i = 0; i < 3; ++i) {
            auto reqvec = request.add_reqvec();
            reqvec->set_tablespaceid(1);
            reqvec->set_logicalpageno(i);
            reqvec->set_vlsn(9999);
            reqvec->set_ziplen(gaia_logical_page_size());
        }
        segment->_parse_lsn(9999 + 1);
        FLAGS_psvr_segment_fetch_max_buf_size = 0;
        ctx.last_error_code = pspb::RbioResponse::RBIO_SUCCESS;
        ASSERT_TRUE(ctx.Init(base::cpuwide_time_us()));
    }
    {
        // test init
        page_server::WritePageRequest request;
        page_server::WritePageResponse response;
        RbioManager::WriteTask ctx(segment, 3, &request, &response, nullptr);
        request.set_request_id(111);
        request.set_segment_id(segment->segment_id());
        request.set_cluster_id(segment->cluster_id());
        request.set_n(3);
        for (int32_t i = 0; i < 3; ++i) {
            auto reqvec = request.add_requestvec();
            reqvec->set_space_id(1);
            reqvec->set_page_no(i);
            reqvec->set_data(std::string("xxxxxxxxx"));
            reqvec->set_ziplen(gaia_logical_page_size());
        }

        ctx.last_error_code = pspb::WritePageResponse::TIMEOUT;
        ctx.Init(base::cpuwide_time_us());
    }
}

TEST_F(RbioManagerTests, test_Context) {
    auto segment = create_segment();
    page_server::RbioRequest request;
    page_server::RbioResponse response;
    RbioManager::ReadTask rbio(segment, 1, nullptr, &request, &response, nullptr);
    bool is_ok = false;
    {
        // ok
        RbioManager::Context ctx(&rbio);
        ctx.read_rsp = response.add_resvec();
        ctx.buf_block = _buf_block;

        rbio.finish_count = 0;

        FLAGS_psvr_rbio_long_write_page_us = 1;
        usleep(2);
        ASSERT_TRUE(ctx.Finish(pspb::RbioResponse::RBIO_SUCCESS, &is_ok));
    }
    {
        // fail
        RbioManager::Context ctx(&rbio);
        ctx.read_rsp = response.add_resvec();
        rbio.last_error_code = pspb::RbioResponse::RBIO_SUCCESS;

        rbio.finish_count = 0;

        FLAGS_psvr_rbio_long_write_page_us = 1;
        usleep(2);
        ASSERT_TRUE(ctx.Finish(pspb::RbioResponse::RBIO_TIMEOUT, &is_ok));
    }
    {
        // ok
        RbioManager::Context ctx(&rbio);
        ctx.read_rsp = response.add_resvec();
        ctx.buf_block = _buf_block;
        rbio.last_error_code = pspb::RbioResponse::RBIO_SUCCESS;

        rbio.finish_count = 0;

        FLAGS_psvr_rbio_long_query_time_us = 1;
        FLAGS_psvr_rbio_long_query_time_print_detail_us = 1;
        usleep(2);
        rbio.segment = create_segment();
        ASSERT_TRUE(ctx.Finish(pspb::RbioResponse::RBIO_SUCCESS, &is_ok));
    }
    {
        // fail
        RbioManager::Context ctx(&rbio);
        ctx.read_rsp = response.add_resvec();
        ctx.task = &rbio;
        rbio.last_error_code = pspb::RbioResponse::RBIO_SUCCESS;

        rbio.finish_count = 0;

        FLAGS_psvr_rbio_long_query_time_us = 1;
        FLAGS_psvr_rbio_long_query_time_print_detail_us = 1;
        usleep(2);
        rbio.segment = create_segment();
        ASSERT_TRUE(ctx.Finish(pspb::RbioResponse::RBIO_TIMEOUT, &is_ok));
    }
}

TEST_F(RbioManagerTests, test_Context2) {
    auto segment = create_segment();
    page_server::WritePageRequest request;
    page_server::WritePageResponse response;
    RbioManager::WriteTask rbio(segment, 1, &request, &response, nullptr);
    bool is_ok = false;
    {
        // ok
        RbioManager::Context ctx(&rbio);

        rbio.finish_count = 0;

        FLAGS_psvr_rbio_long_write_page_us = 1;
        usleep(2);
        ASSERT_TRUE(ctx.Finish(pspb::WritePageResponse_Error_SUCCESS, &is_ok));
    }
    {
        // fail
        RbioManager::Context ctx(&rbio);

        rbio.finish_count = 0;

        FLAGS_psvr_rbio_long_write_page_us = 1;
        usleep(2);
        ASSERT_TRUE(ctx.Finish(pspb::WritePageResponse_Error_INVALID, &is_ok));
    }
}

TEST_F(RbioManagerTests, test_Start) {
    {
        // start failed
        EXPECT_CALL(*_mock_condition_thread_pool, Start(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _, _mock_control->timer(), _, _, _)).WillOnce(Return(false));
        ASSERT_FALSE(_rbio_manager->Start(1));
    }
    {
        // start ok
        EXPECT_CALL(*_mock_condition_thread_pool, Start(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _, _mock_control->timer(), _, _, _)).WillOnce(Return(true));
        ASSERT_TRUE(_rbio_manager->Start(1));
    }
    {
        // start fail
        _rbio_manager->_control.reset();
        ASSERT_FALSE(_rbio_manager->Start(1));
    }
}

TEST_F(RbioManagerTests, test_Start_Stop) {
    {
        // start ok
        FLAGS_multi_psvr_rbio_max_tasks_size = 8;
        EXPECT_CALL(*_mock_condition_thread_pool, Start(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _, _mock_control->timer(), _, _, _)).WillOnce(Return(true));
        ASSERT_TRUE(_rbio_manager->Start(1));
    }
    {
        _rbio_manager->Stop();
    }
}

TEST_F(RbioManagerTests, test_IncOrDecThreadNum) {
    _rbio_manager->_thread_num = FLAGS_multi_psvr_rbio_thread_num_per_group;
    _mock_thread_pool->_thread_pool_size = 1;
    {
        _rbio_manager->_stopped = false;
        _rbio_manager->IncOrDecThreadNum();
    }
    {
        // inc
        FLAGS_multi_psvr_rbio_thread_num_per_group += 1;
        EXPECT_CALL(*_mock_thread_pool, IncThread(_, _)).WillOnce(Return(true));
        _rbio_manager->IncOrDecThreadNum();
    }
    {
        // dec
        std::vector<MockExecutor<RbioManager::Context, thread::TaskContext>::ThreadType> vec;
        FLAGS_multi_psvr_rbio_thread_num_per_group -= 1;
        EXPECT_CALL(*_mock_thread_pool, DecThread(_, _))
            .WillOnce(Return(vec));
        _rbio_manager->IncOrDecThreadNum();
    }
    _rbio_manager->_stopped = true;
}

BMOCK_NS_METHOD1(gaiadb::common, terminate, void(int));
TEST_F(RbioManagerTests, test_Schedule) {
    auto segment = create_segment();
    page_server::RbioRequest request;
    page_server::RbioResponse response;
    RbioManager::ReadTask rbio(segment, 5, nullptr, &request, &response, nullptr);
    RbioManager::Context* ctx = rbio.reqs[0];
    for (uint32_t i = 0; i < 5; ++i) {
        auto reqvec = request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(i);
        reqvec->set_vlsn(9999);
        reqvec->set_ziplen(gaia_logical_page_size());
    }
    request.set_fetch_lsn(1024);
    request.set_ls_dispatch_lsn(1024);
    segment->_parse_lsn(10000);
    ASSERT_TRUE(rbio.Init(5));
    { // ok
        FLAGS_psvr_rbio_thread_max_queue_size = 0;
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Return(true));
        _rbio_manager->Schedule(ctx, 0, false);
    }
    { // ok
        FLAGS_psvr_rbio_thread_max_queue_size = 0;
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Return(true));
        _rbio_manager->Schedule(ctx, 1000, true);
    }
    { // max_queue_size
        FLAGS_psvr_rbio_thread_max_queue_size = 100;
        EXPECT_CALL(*_mock_thread_pool, GetThreadQueueSize(_, _)).WillOnce(Return(101));
        _rbio_manager->Schedule(ctx, 0, false, true);
    }
    {
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Return(true));
        _rbio_manager->Execute(ctx);
    } END_OF_CASE;
    {
        _rbio_manager->_stopped = true;
        _rbio_manager->Schedule(ctx, 0, false);
        _rbio_manager->_stopped = false;
    } END_OF_CASE;
    {
        _rbio_manager->_stopped = true;
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Return(false));
        _rbio_manager->Execute(ctx);
    } END_OF_CASE;
    {
        _rbio_manager->_stopped = false;
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Return(false));
        BMOCK_NS_RESUME(gaiadb::common, terminate, void(int));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaiadb::common, terminate), terminate(_)).WillOnce(Return());
        _rbio_manager->Execute(ctx);
        BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
    }
}

TEST_F(RbioManagerTests, test_ConditionSchedule) {
    auto segment = create_segment();;
    page_server::RbioRequest request;
    page_server::RbioResponse response;
    RbioManager::ReadTask rbio(segment, 2, nullptr, &request, &response, nullptr);
    RbioManager::Context* ctx = rbio.reqs[0];
    for (uint32_t i = 0; i < 2; ++i) {
        auto reqvec = request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(i);
        reqvec->set_vlsn(9999);
        reqvec->set_ziplen(gaia_logical_page_size());
    }
    {
        EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Return());
        _rbio_manager->ConditionScheduleNextAction(ctx, RbioManager::Action::kWaitLsn, segment, 1024);
    }
    {
        ctx->stat_timer.reset();
        auto fun1 = [this](size_t, const RbioManager::ConditionTask& task) {
            _rbio_manager->ConditionFn(task);
        };
        EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Return(true));
        _rbio_manager->RetryConditionSchedule(ctx, segment, 1024);
    }
    rbio.last_error_code = pspb::RbioResponse::RBIO_INVALID;
}

TEST_F(RbioManagerTests, test_OnCompletion) {
    auto segment = create_segment();;
    page_server::RbioRequest request;
    page_server::RbioResponse response;
    RbioManager::ReadTask rbio(segment, 2, nullptr, &request, &response, nullptr);
    RbioManager::Context* ctx = rbio.reqs[0];
    for (uint32_t i = 0; i < 2; ++i) {
        auto reqvec = request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(i);
        reqvec->set_vlsn(9999);
        reqvec->set_ziplen(gaia_logical_page_size());
        if (i == 0) {
            reqvec->set_lowest_lsn(9999);
        }
    }

    segment->_parse_lsn(10000);
    ASSERT_TRUE(rbio.Init(2));

    {
        segment->_status = Segment::Status::kDelete;
        rbio.finish_count = 0;
        _rbio_manager->OnCompletion(ctx);
    }
    {
        segment->_status = Segment::Status::kOpen;
        segment->_stopped = true;
        rbio.finish_count = 0;
        _rbio_manager->OnCompletion(ctx);
        segment->_stopped = false;
    }
    {
        _rbio_manager->_stopped = true;
        rbio.finish_count = 0;
        _rbio_manager->OnCompletion(ctx);
        _rbio_manager->_stopped = false;
    }
    rbio.last_error_code = pspb::RbioResponse::RBIO_INVALID;
}

// ─── Dispatch Write: vlsn guard (LSN_BEHIND) ─────────────────────────────────
// Covers the new vlsn check in RbioManager::Dispatch: if request has vlsn and
// vlsn < checkpoint_lsn (append_file mode) or vlsn < gc_lsn (non-append_file
// mode), return LSN_BEHIND. Also covers SealBufByLsn call when dblwr is enabled.

TEST_F(RbioManagerTests, test_Dispatch_Write_vlsn_check) {
    auto segment = create_segment();
    auto* mock_engine = new MockAppendDBEngine();
    segment->_append_db_engine.reset(mock_engine);
    auto* mock_dblwr = new MockDblwr();
    segment->_dblwr.reset(mock_dblwr);

    int64_t rbio_size = 10;
    _rbio_manager->_rbio_size = &rbio_size;
    _rbio_manager->_store_inflight_rbio_size.emplace_back(
            std::make_shared<std::atomic<int64_t>>(0));
    FLAGS_psvr_rbio_store_max_tasks_size = 100;

    bool saved_append_file = FLAGS_psvr_enable_append_file;
    uint32_t saved_dblwr_max = FLAGS_psvr_dblwr_max_page_num;

    {
        // Case 1: no vlsn field set → vlsn check skipped, not LSN_BEHIND
        FLAGS_psvr_enable_append_file = true;
        FLAGS_psvr_rbio_thread_max_queue_size = 0;
        pspb::WritePageRequest request;
        pspb::WritePageResponse response;
        request.set_n(1);
        request.add_requestvec();
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _rbio_manager->Dispatch(segment, &request, &response, nullptr, 1);
        ASSERT_NE(response.status().code(), pspb::WritePageResponse::LSN_BEHIND);
    } END_OF_CASE;

    {
        // Case 2: append_file mode, vlsn <= checkpoint_lsn → not LSN_BEHIND
        // Logic: wait = (vlsn > checkpoint_lsn), so vlsn=1000 <= checkpoint=2000 → no wait
        FLAGS_psvr_enable_append_file = true;
        FLAGS_psvr_dblwr_max_page_num = 0;
        FLAGS_psvr_rbio_thread_max_queue_size = 0;
        EXPECT_CALL(*mock_engine, GetCheckPointLsn()).WillRepeatedly(Return(2000));
        pspb::WritePageRequest request;
        pspb::WritePageResponse response;
        request.set_n(1);
        request.add_requestvec();
        request.set_vlsn(1000);
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _rbio_manager->Dispatch(segment, &request, &response, nullptr, 1);
        ASSERT_NE(response.status().code(), pspb::WritePageResponse::LSN_BEHIND);
    } END_OF_CASE;

    {
        // Case 3: append_file mode, vlsn > checkpoint_lsn, dblwr disabled → LSN_BEHIND
        // Logic: wait = (vlsn > checkpoint_lsn) = (5000 > 3000) = true
        FLAGS_psvr_enable_append_file = true;
        FLAGS_psvr_dblwr_max_page_num = 0;
        EXPECT_CALL(*mock_engine, GetCheckPointLsn()).WillRepeatedly(Return(3000));
        pspb::WritePageRequest request;
        pspb::WritePageResponse response;
        request.set_n(1);
        request.add_requestvec();
        request.set_vlsn(5000);
        _rbio_manager->Dispatch(segment, &request, &response, nullptr, 1);
        ASSERT_EQ(response.status().code(), pspb::WritePageResponse::LSN_BEHIND);
    } END_OF_CASE;

    {
        // Case 4: append_file mode, vlsn > checkpoint_lsn, dblwr enabled
        //         → SealBufByLsn(vlsn) called, then LSN_BEHIND
        FLAGS_psvr_enable_append_file = true;
        FLAGS_psvr_dblwr_max_page_num = 4;
        EXPECT_CALL(*mock_engine, GetCheckPointLsn()).WillRepeatedly(Return(3000));
        EXPECT_CALL(*mock_dblwr, SealBufByLsn(5000)).WillOnce(Return(db::Status()));
        pspb::WritePageRequest request;
        pspb::WritePageResponse response;
        request.set_n(1);
        request.add_requestvec();
        request.set_vlsn(5000);
        _rbio_manager->Dispatch(segment, &request, &response, nullptr, 1);
        ASSERT_EQ(response.status().code(), pspb::WritePageResponse::LSN_BEHIND);
    } END_OF_CASE;

    {
        // Case 5: non-append_file mode, vlsn > gc_lsn → LSN_BEHIND
        // Logic: wait = (vlsn > gc_lsn) = (5000 > 3000) = true
        FLAGS_psvr_enable_append_file = false;
        segment->_gc_lsn(3000, true);
        pspb::WritePageRequest request;
        pspb::WritePageResponse response;
        request.set_n(1);
        request.add_requestvec();
        request.set_vlsn(5000);
        _rbio_manager->Dispatch(segment, &request, &response, nullptr, 1);
        ASSERT_EQ(response.status().code(), pspb::WritePageResponse::LSN_BEHIND);
    } END_OF_CASE;

    {
        // Case 6: non-append_file mode, vlsn <= gc_lsn → not LSN_BEHIND
        // Logic: wait = (vlsn > gc_lsn) = (2000 > 5000) = false
        FLAGS_psvr_enable_append_file = false;
        FLAGS_psvr_rbio_thread_max_queue_size = 0;
        segment->_gc_lsn(5000, true);
        pspb::WritePageRequest request;
        pspb::WritePageResponse response;
        request.set_n(1);
        request.add_requestvec();
        request.set_vlsn(2000);
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _rbio_manager->Dispatch(segment, &request, &response, nullptr, 1);
        ASSERT_NE(response.status().code(), pspb::WritePageResponse::LSN_BEHIND);
    } END_OF_CASE;

    FLAGS_psvr_enable_append_file = saved_append_file;
    FLAGS_psvr_dblwr_max_page_num = saved_dblwr_max;
}

TEST_F(RbioManagerTests, test_GetRbioCtx_PutRbioCtx) {
    SegmentPtr segment = create_segment();
    int64_t rbio_size = 0;
    _rbio_manager->_rbio_size = &rbio_size;
    {
        rbio_size = 0;
        ASSERT_FALSE(_rbio_manager->CheckQuota(1));
        rbio_size = 10;
        ASSERT_TRUE(_rbio_manager->CheckQuota(1));
    }
    {
        page_server::WritePageRequest request;
        page_server::WritePageResponse response;
        RbioManager::WriteTask rbio(segment, 1, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio.reqs[0];
        _rbio_manager->SetRbioReqCtxClientId(ctx);
        rbio.segment.reset();
        _rbio_manager->SetRbioReqCtxClientId(ctx);
    }
    {
        page_server::WritePageRequest request;
        page_server::WritePageResponse response;
        RbioManager::WriteTask* rbio = new RbioManager::WriteTask(segment, 1, &request, &response, nullptr);
        _rbio_manager->PutRbioCtx(rbio);
    }
    {
        _rbio_manager->_stopped = false;
        FLAGS_psvr_rbio_store_max_tasks_size = 1;
        bool pass = false;
        auto id = _rbio_manager->CheckStoreQuota(-1, 2, &pass);
        ASSERT_EQ(id, -1);

        id = _rbio_manager->CheckStoreQuota(0, 2, &pass);
        ASSERT_EQ(id, -1);

        _rbio_manager->_store_inflight_rbio_size.emplace_back(std::make_shared<std::atomic<int64_t>>(0));
        id = _rbio_manager->CheckStoreQuota(0, 2, &pass);
        ASSERT_EQ(id, -1);

        id = _rbio_manager->CheckStoreQuota(0, 1, &pass);
        ASSERT_EQ(id, 0);

        id = _rbio_manager->CheckStoreQuota(0, 1, &pass);
        ASSERT_EQ(id, -1);

        _rbio_manager->PutStoreQuota(id, 1);
        _rbio_manager->PutStoreQuota(0, 1);
    }
}

TEST_F(RbioManagerTests, test_Dispatch_Write) {
    auto segment = create_segment();
    int64_t rbio_size = 0;
    _rbio_manager->_rbio_size = &rbio_size;
    {
        // mismatch size
        page_server::WritePageRequest request;
        page_server::WritePageResponse response;
        request.set_n(1);

        _rbio_manager->Dispatch(segment, &request, &response, nullptr, 1);
        ASSERT_EQ(response.status().code(), page_server::WritePageResponse::INVALID);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());
    }
    {
        // get quota failed
        page_server::WritePageRequest request;
        page_server::WritePageResponse response;
        request.set_n(1);
        request.add_requestvec();

        rbio_size = 0;
        _rbio_manager->Dispatch(segment, &request, &response, nullptr, 1);
        ASSERT_EQ(response.status().code(), page_server::WritePageResponse::QUOTA_LIMIT);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());
        rbio_size = 2;
    } END_OF_CASE;
    {
        _rbio_manager->_store_inflight_rbio_size.emplace_back(std::make_shared<std::atomic<int64_t>>(1));
        // get quota failed
        page_server::WritePageRequest request;
        page_server::WritePageResponse response;
        request.set_n(1);
        request.add_requestvec();

        FLAGS_psvr_rbio_store_max_tasks_size = 1;
        ASSERT_EQ(segment->_store_id, 0);
        _rbio_manager->Dispatch(segment, &request, &response, nullptr, 1);
        ASSERT_EQ(response.status().code(), page_server::WritePageResponse::QUOTA_LIMIT);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());
        ASSERT_EQ(1, _rbio_manager->_store_inflight_rbio_size[0]->load());
        FLAGS_psvr_rbio_store_max_tasks_size = 2;

    } END_OF_CASE;
    {
        // init ok
        page_server::WritePageRequest request;
        page_server::WritePageResponse response;
        request.set_n(1);
        request.add_requestvec();

        FLAGS_psvr_rbio_thread_max_queue_size = 0;

        auto fun2 = [this](RbioManager::Context *ctx) {
            ASSERT_EQ(1, _rbio_manager->inflight_rbio_size());
            ASSERT_EQ(2, _rbio_manager->_store_inflight_rbio_size[0]->load());
            _rbio_manager->FinishRbioReqWithTimeout(ctx);
        };
        auto fun1 = [this, &fun2](size_t, RbioManager::Context *ctx) -> bool {
            fun2(ctx);
            return true;
        };

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(fun1));

        _rbio_manager->Dispatch(segment, &request, &response, nullptr, 1);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());
        ASSERT_EQ(1, _rbio_manager->_store_inflight_rbio_size[0]->load());
    }
}

TEST_F(RbioManagerTests, test_Dispatch_Read) {
    auto segment = create_segment();
    int64_t rbio_size = 0;
    _rbio_manager->_rbio_size = &rbio_size;
    FLAGS_psvr_segment_fetch_max_buf_size = (256<<20);
    {
        // mismatch size
        page_server::RbioRequest request;
        page_server::RbioResponse response;
        request.set_n(1);

        _rbio_manager->Dispatch(segment, nullptr, &request, &response, nullptr, 1);
        ASSERT_EQ(response.errcode(), page_server::RbioResponse::RBIO_INVALID);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());
    } END_OF_CASE;
    {
        // disable rbio as source
        FLAGS_psvr_rbio_disabled_as_data_source = true;

        page_server::RbioRequest request;
        request.set_max_error_code(5);
        page_server::RbioResponse response;
        request.set_n(1);
        request.add_reqvec();
        request.set_max_error_code(10);

        _rbio_manager->Dispatch(segment, nullptr, &request, &response, nullptr, 1);
        ASSERT_EQ(response.errcode(), page_server::RbioResponse::RBIO_SEGMENT_INACTIVE);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());

        FLAGS_psvr_rbio_disabled_as_data_source = false;
    } END_OF_CASE;
    {
        // disable recovery as source
        FLAGS_psvr_recover_disabled_as_data_source = true;

        page_server::RbioRequest request;
        request.set_max_error_code(5);
        page_server::RbioResponse response;
        request.set_n(1);
        request.add_reqvec();
        request.set_peerread(true);
        request.set_max_error_code(10);

        _rbio_manager->Dispatch(segment, nullptr, &request, &response, nullptr, 1);
        ASSERT_EQ(response.errcode(), page_server::RbioResponse::RBIO_SEGMENT_INACTIVE);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());

        FLAGS_psvr_recover_disabled_as_data_source = false;
    } END_OF_CASE;
    {
        // get failed
        page_server::RbioRequest request;
        request.set_max_error_code(5);
        page_server::RbioResponse response;
        request.set_n(1);
        request.add_reqvec();

        rbio_size = 0;
        _rbio_manager->Dispatch(segment, nullptr, &request, &response, nullptr, 1);
        ASSERT_EQ(response.errcode(), page_server::RbioResponse::RBIO_TIMEOUT);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());
        rbio_size = 10;
    } END_OF_CASE;
    {
        // init failed
        page_server::RbioRequest request;
        page_server::RbioResponse response;
        request.set_n(1);
        auto req = request.add_reqvec();
        req->set_vlsn(100000 + FLAGS_psvr_segment_fetch_max_buf_size);
        segment->_parse_lsn(0);

        EXPECT_CALL(*_mock_fetcher, Wakeup(_)).WillOnce(Return());

        _rbio_manager->Dispatch(segment, nullptr, &request, &response, nullptr, 1);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());
        ASSERT_EQ(response.errcode(), page_server::RbioResponse::RBIO_TIMEOUT);
    } END_OF_CASE;
    {
        // init ok
        page_server::RbioRequest request;
        page_server::RbioResponse response;
        request.set_n(1);
        request.set_enable_attachment_type(true);
        brpc::Controller cntl;

        auto req = request.add_reqvec();
        req->set_vlsn(100000 + FLAGS_psvr_segment_fetch_max_buf_size);
        segment->_parse_lsn(req->vlsn() + 1);

        FLAGS_psvr_rbio_thread_max_queue_size = 0;
        auto fun2 = [this](RbioManager::Context *ctx) {
            ASSERT_FALSE(dynamic_cast<RbioManager::ReadTask*>(ctx->task)->wait_lsn);
            ASSERT_EQ(1, _rbio_manager->inflight_rbio_size());
            _rbio_manager->FinishRbioReqWithTimeout(ctx);
        };
        auto fun1 = [this, &fun2](size_t, RbioManager::Context *ctx) -> bool {
            fun2(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(fun1));

        _rbio_manager->Dispatch(segment, &cntl, &request, &response, nullptr, 1);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());

    } END_OF_CASE;
    {
        // init ok & WaitLsn
        page_server::RbioRequest request;
        page_server::RbioResponse response;
        request.set_n(1);
        request.set_enable_attachment_type(true);
        brpc::Controller cntl;

        auto req = request.add_reqvec();
        req->set_vlsn(100000 + FLAGS_psvr_segment_fetch_max_buf_size);
        segment->_parse_lsn(req->vlsn() + 1 - FLAGS_psvr_segment_fetch_max_buf_size);

        auto fun2 = [this](RbioManager::Context *ctx) {
            ASSERT_TRUE(dynamic_cast<RbioManager::ReadTask*>(ctx->task)->wait_lsn);
            ASSERT_EQ(1, _rbio_manager->inflight_rbio_size());
            _rbio_manager->FinishRbioReqWithTimeout(ctx);
        };
        auto fun1 = [this, &fun2](size_t, RbioManager::Context *ctx) -> bool {
            fun2(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(fun1));

        FLAGS_psvr_rbio_enable_wait_queue = false;
        _rbio_manager->Dispatch(segment, &cntl, &request, &response, nullptr, 1);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());

    } END_OF_CASE;
    {
        // init ok & WaitLsn 2
        page_server::RbioRequest request;
        page_server::RbioResponse response;
        request.set_n(1);
        request.set_enable_attachment_type(false);
        request.set_is_primary(false);
        request.set_fetch_lsn(11111);
        request.set_ls_dispatch_lsn(11111);
        brpc::Controller cntl;

        auto req = request.add_reqvec();
        req->set_vlsn(100000 + FLAGS_psvr_segment_fetch_max_buf_size);
        segment->_parse_lsn(req->vlsn() + 1 - FLAGS_psvr_segment_fetch_max_buf_size);

        auto fun2 = [this](RbioManager::Context *ctx) {
            ASSERT_TRUE(dynamic_cast<RbioManager::ReadTask*>(ctx->task)->wait_lsn);
            ASSERT_EQ(1, _rbio_manager->inflight_rbio_size());
            _rbio_manager->FinishRbioReqWithTimeout(ctx);
        };
        auto fun1 = [this, &fun2](size_t, const RbioManager::ConditionTask& task) {
            fun2(task.ctx);
        };

        EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Invoke(fun1));

        FLAGS_psvr_rbio_enable_wait_queue = true;
        _rbio_manager->Dispatch(segment, &cntl, &request, &response, nullptr, 1);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());

    } END_OF_CASE;
    {
        // not segment
        page_server::RbioRequest request;
        page_server::RbioResponse response;
        _rbio_manager->_control.reset();
        _rbio_manager->Dispatch(segment, nullptr, &request, &response, nullptr, 1);
        ASSERT_EQ(0, _rbio_manager->inflight_rbio_size());
    } END_OF_CASE;
}

TEST_F(RbioManagerTests, test_WaitLsn) {
    auto segment = create_mock_segment();

    page_server::RbioRequest request;
    request.set_requestid(1);
    request.set_n(2);
    request.set_readtype(pspb::RbioRequest::READ_SYNC);
    for (int32_t i = 0; i < 2; ++i) {
        auto req = request.add_reqvec();
        req->set_tablespaceid(1);
        req->set_logicalpageno(i);
        req->set_vlsn(9999);
        req->set_ziplen(gaia_logical_page_size());
    }

    {
        // invalid segment
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        segment->_parse_lsn(10000);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        ctx->action = RbioManager::Action::kWaitLsn;
        rbio_ctx.segment.reset();
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;
        rbio_ctx.secondary_fetch_lsn = 1000;

        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // lowest_lsn
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];
        ctx->lowest_lsn = 9999;
        segment->_parse_lsn(9999 - 1);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        ctx->action = RbioManager::Action::kWaitLsn;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;
        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // vlsn > parse_lsn
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];
        ctx->lowest_lsn = 9999 - 1;

        FLAGS_psvr_segment_fetch_max_buf_size = 100;
        segment->_parse_lsn(9999 - 1);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        ctx->action = RbioManager::Action::kWaitLsn;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        EXPECT_CALL(*_mock_fetcher, Wakeup(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Return(true));

        FLAGS_psvr_rbio_enable_wait_queue = false;
        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // vlsn > parse_lsn
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];
        ctx->lowest_lsn = 0;

        segment->_fetch_lsn(9999 + 1);
        segment->_parse_lsn(9999 - 1);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        ctx->action = RbioManager::Action::kWaitLsn;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;

        EXPECT_CALL(*_mock_fetcher, Wakeup(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Return());

        FLAGS_psvr_rbio_enable_wait_queue = true;
        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // vlsn > parse_lsn on rule le
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        segment->_parse_lsn(9999 - 1);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        ctx->action = RbioManager::Action::kWaitLsn;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;
        rbio_ctx.read_rule = pspb::RbioRequest::LE;

        //EXPECT_CALL(*_mock_fetcher, Wakeup(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Return(true));
        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // vlsn <= parse_lsn
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        segment->_parse_lsn(9999 + 1);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        ctx->action = RbioManager::Action::kWaitLsn;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Return(true));
        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;
}

TEST_F(RbioManagerTests, test_Prepare) {
    auto segment = create_mock_segment();
    FLAGS_psvr_rbio_enable_direct_get_meta = false;
    page_server::RbioRequest request;
    request.set_requestid(1);
    request.set_n(2);
    request.set_readtype(pspb::RbioRequest::READ_SYNC);
    for (int32_t i = 0; i < 2; ++i) {
        auto req = request.add_reqvec();
        req->set_tablespaceid(1);
        req->set_logicalpageno(i);
        req->set_vlsn(9999);
        req->set_ziplen(gaia_logical_page_size());
    }
    segment->_parse_lsn(10000);

    {
        // invalid segment
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        rbio_ctx.segment.reset();
        ctx->action = RbioManager::Action::kPrepare;
        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;

    pspb::WritePageRequest w_request;
    w_request.set_request_id(1);
    w_request.set_n(2);
    for (int32_t i = 0; i < 2; ++i) {
        auto w_reqvec = w_request.add_requestvec();
        w_reqvec->set_space_id(1);
        w_reqvec->set_page_no(i);
        w_reqvec->set_data(std::string(16<<10, 'a'));
    }

    {
        // GetOrAllocBufBlock fail
        page_server::WritePageResponse response;

        RbioManager::WriteTask rbio_ctx(segment, 2, &w_request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        rbio_ctx.Init(base::cpuwide_time_us());
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->action = RbioManager::Action::kPrepare;

        EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(nullptr));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Return(true));

        _rbio_manager->OnCompletion(ctx);

    } END_OF_CASE;

    {
        // GetSpacePagePhysicalOffset fail
        page_server::WritePageResponse response;

        RbioManager::WriteTask rbio_ctx(segment, 2, &w_request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        rbio_ctx.Init(base::cpuwide_time_us());
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->action = RbioManager::Action::kPrepare;

        EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment.get(), GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(false));

        auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, gaia_apply::page_no_t, ggpb::Closure* closure, pspb::Status* status) {
            if (status) {
                status->set_code(pspb::Status::INVALID);
            }
            if (closure) {
                closure->Run();
            }
        };
        EXPECT_CALL(*_mock_parser, AddGetSpaceExtentEvent(_ TRACE_MOCK_ARG_CC, _, _, _, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Return(true));

        _rbio_manager->OnCompletion(ctx);

    } END_OF_CASE;

    {
        // ok
        page_server::WritePageResponse response;

        RbioManager::WriteTask rbio_ctx(segment, 2, &w_request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        rbio_ctx.Init(base::cpuwide_time_us());
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->action = RbioManager::Action::kPrepare;

        EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment.get(), GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Return(true));

        _rbio_manager->OnCompletion(ctx);

    } END_OF_CASE;

    {
        // ok 2
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;

        ctx->action = RbioManager::Action::kPrepare;

        EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment.get(), GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Return(true));

        _rbio_manager->OnCompletion(ctx);

    } END_OF_CASE;

    {
        // ok 3
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;
        rbio_ctx.req_has_physical_extent_id = true;

        ctx->action = RbioManager::Action::kPrepare;

        EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        //EXPECT_CALL(*segment.get(), GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Return(true));

        _rbio_manager->OnCompletion(ctx);

    } END_OF_CASE;

    FLAGS_psvr_rbio_enable_direct_get_meta = true;
    {
        // GetSpacePagePhysicalOffset fail
        page_server::WritePageResponse response;

        RbioManager::WriteTask rbio_ctx(segment, 2, &w_request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        rbio_ctx.Init(base::cpuwide_time_us());
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->action = RbioManager::Action::kPrepare;

        EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment.get(), GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(false));
        // get lock
        EXPECT_CALL(*segment, GetSpaceExtentReqLock(_, _)).WillOnce(Return(false));

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Return(true));
        _rbio_manager->OnCompletion(ctx);
        segment->PutSpaceExtentReqLock(1, 0);

    } END_OF_CASE;

    {
        //  GetSpaceExtent fail
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        EXPECT_CALL(*segment, GetSpaceExtentReqLock(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSpaceExtentMapCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kCntlFailed, "fail");
            closure->Run();
        };

        auto fun2 = [](RpcGetSpaceExtentMapCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_TIMEOUT);
            closure->Run();
        };

        auto fun3 = [](RpcGetSpaceExtentMapCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_INVALID);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSpaceExtentMap(_, _))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun2))
            .WillOnce(Invoke(fun3))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun2))
            .WillOnce(Invoke(fun3));

        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Return(true));

        _rbio_manager->GetSpaceExtent(ctx);
    } END_OF_CASE;

    {
        //  GetSpaceExtent fail 2
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        EXPECT_CALL(*segment, GetSpaceExtentReqLock(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSpaceExtentMapCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_NOT_EXIST);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSpaceExtentMap(_, _))
            .WillOnce(Invoke(fun1));

        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Return(true));

        _rbio_manager->GetSpaceExtent(ctx);
    } END_OF_CASE;

    {
        //  GetSpaceExtent ok
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        EXPECT_CALL(*segment, GetSpaceExtentReqLock(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSpaceExtentMapCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSpaceExtentMap(_, _))
            .WillOnce(Invoke(fun1));

        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Return(true));

        _rbio_manager->GetSpaceExtent(ctx);
    } END_OF_CASE;
}

TEST_F(RbioManagerTests, test_ReadPage) {
    auto segment = create_mock_segment();

    FLAGS_psvr_rbio_transfer_req_in_recovery = true;

    page_server::RbioRequest request;
    request.set_requestid(1);
    request.set_n(2);
    request.set_readtype(pspb::RbioRequest::READ_SYNC);
    for (int32_t i = 0; i < 2; ++i) {
        auto req = request.add_reqvec();
        req->set_tablespaceid(1);
        req->set_logicalpageno(i);
        req->set_vlsn(9999);
        req->set_ziplen(gaia_logical_page_size());
    }
    segment->_parse_lsn(10000);

    {
        // invalid segment
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        rbio_ctx.segment.reset();
        ctx->action = RbioManager::Action::kReadPage;
        _rbio_manager->OnCompletion(ctx);
    }
    {
        // invalid size
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size() + 1;

        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // ReadPageData ok & is_peer_read
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));

        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;
        rbio_ctx.is_peer_read = true;

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size();

        set_buf_block(_buf_block, 1, ctx->logical_page_no + 1, gaia_page_size(), 99);

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk, "mock ok")));
        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // ReadPageData ok & is_peer_read
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));

        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;
        rbio_ctx.is_peer_read = true;

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size();

        set_buf_block(_buf_block, 1, ctx->logical_page_no + 1, gaia_page_size(), 99);

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk, "mock ok")));
        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // ReadPageData ok & is_peer_read false & page_is_empty false
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));

        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size();

        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 99);

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk, "mock ok")));
        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // ReadPageData ok & page_is_empty & is_peer_read false & RECOVERY_FINISH
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size();

        segment->_recovery_status = gaiadb::RECOVERY_FINISH;
        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 99);

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(DoAll(SetArgPointee<7>(true), Return(db::Status(db::Code::kOk, "mock ok"))));
        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // ReadPageData ok & empty & recover not finish
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size();

        segment->_recovery_status = gaiadb::RECOVERY_IN;
        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 99);

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(DoAll(SetArgPointee<7>(true), Return(db::Status(db::Code::kOk, "mock ok"))));

        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(Return(false));

        auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, ggpb::Closure* closure, pspb::Status* status) {
            brpc::ClosureGuard closure_guard(closure);
            if (status) {
                status->set_code(pspb::Status::INVALID);
            }
        };
        EXPECT_CALL(*_mock_parser, AddGetPeerEvent(_ TRACE_MOCK_ARG_CC, _, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Return(true));

        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // ReadPageData ahead & is_peer_read false
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size();

        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 99);

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(DoAll(SetArgPointee<7>(true), Return(db::Status(db::Code::kAhead, "mock ahead"))));

        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // ReadPageData ahead & is_peer_read false
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));

        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;
        rbio_ctx.read_rule = pspb::RbioRequest::GE;

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size();

        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 99);

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(DoAll(SetArgPointee<7>(true), Return(db::Status(db::Code::kAhead, "mock ahead"))));

        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // ReadPageData ahead & peer read
        page_server::RbioResponse response;

        brpc::Controller cntl;
        RbioManager::ReadTask* rbio_ctx(new RbioManager::ReadTask(segment, 2, &cntl, &request, &response, nullptr));
        for (int32_t i = 0; i < 2; ++i) {
            RbioManager::Context* ctx = rbio_ctx->reqs[i];

            ASSERT_TRUE(rbio_ctx->Init(base::cpuwide_time_us()));
            rbio_ctx->role = RbioManager::Task::RBIO_PRIMARY;
            rbio_ctx->is_peer_read = true;
            rbio_ctx->enable_attachment_type = true;

            ctx->page_physical_offset = 0;
            ctx->buf_block = _buf_block;
            ctx->action = RbioManager::Action::kReadPage;
            ctx->size = gaia_logical_page_size();

            set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 99);

            EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(DoAll(SetArgPointee<7>(true), Return(db::Status(db::Code::kAhead, "mock ahead"))));

            _rbio_manager->OnCompletion(ctx);
        }

        ASSERT_TRUE(response.resvec(0).pageframe().empty());
        ASSERT_TRUE(response.resvec(1).pageframe().empty());

        char* buf = static_cast<char*>(malloc((16<<10) * 2));
        ASSERT_EQ(2 * (16<<10), cntl.response_attachment().copy_to(buf));
        assert(0 == memcmp(buf, _buf_block->frame, 16<<10));
        ASSERT_EQ(0, memcmp(buf + (16<<10), _buf_block->frame, 16<<10));
        free(buf);

    } END_OF_CASE;
    {
        // ReadPageData ioerror
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;
        rbio_ctx.is_peer_read = true;

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size();

        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 99);

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(DoAll(SetArgPointee<7>(true), Return(db::Status(db::Code::kIOError, "mock ahead"))));

        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // ReadPageData busy
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size();

        rbio_ctx.is_peer_read = true;
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 99);

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(DoAll(SetArgPointee<7>(true), Return(db::Status(db::Code::kBusy, "mock ahead"))));

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Return(true));

        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // ReadPageData IsCorrupted
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;
        rbio_ctx.is_peer_read = true;

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size();

        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 99);

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(DoAll(SetArgPointee<7>(true), Return(db::Status(db::Code::kCorrupted, "mock ahead"))));

        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // ReadPageData IsCorrupted
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size();
        rbio_ctx.is_peer_read = false;

        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 99);

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(DoAll(SetArgPointee<7>(true), Return(db::Status(db::Code::kCorrupted, "mock ahead"))));

        std::vector<gaiadb::common::PeerZone> peers;
        FillServers(&peers, 2);
        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(peers), Return(false)));

        EXPECT_CALL(*_mock_parser, AddGetPeerEvent(_ TRACE_MOCK_ARG_CC, _, _)).WillOnce(Return());

        auto fun2 = [](ReadPeerPageContext* ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
        };
        EXPECT_CALL(*segment.get(), ReadPeerPage(_, _)).WillOnce(Invoke(fun2));

        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // ReadPageData IsCorrupted
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->page_physical_offset = 0;
        ctx->buf_block = _buf_block;
        ctx->action = RbioManager::Action::kReadPage;
        ctx->size = gaia_logical_page_size();
        rbio_ctx.is_peer_read = false;

        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 99);

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(DoAll(SetArgPointee<7>(true), Return(db::Status(db::Code::kCorrupted, "mock ahead"))));

        FLAGS_psvr_rbio_transfer_req_in_recovery = false;
        _rbio_manager->OnCompletion(ctx);
    } END_OF_CASE;
}

TEST_F(RbioManagerTests, test_OnReadPeerPage) {
    auto segment = create_mock_segment();

    page_server::RbioRequest request;
    request.set_requestid(1);
    request.set_n(1);
    request.set_readtype(pspb::RbioRequest::READ_SYNC);
    for (int32_t i = 0; i < 2; ++i) {
        auto req = request.add_reqvec();
        req->set_tablespaceid(1);
        req->set_logicalpageno(i);
        req->set_vlsn(9999);
        req->set_ziplen(gaia_logical_page_size());
    }
    segment->_parse_lsn(10000);

    {
        // invalid segment
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->action = RbioManager::Action::kReadPage;

        auto read_peer_page_ctx = new ReadPeerPageContext(1, ctx->logical_page_no, ctx->vlsn, _buf_block);
        rbio_ctx.segment.reset();
        _rbio_manager->OnReadPeerPage(ctx, read_peer_page_ctx);
    }

    {
        // page lsn > vlsn
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->action = RbioManager::Action::kReadPage;
        ctx->buf_block = _buf_block;
        ctx->vlsn = 9999;
        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 9999 + 1);

        auto read_peer_page_ctx = new ReadPeerPageContext(1, ctx->logical_page_no, ctx->vlsn, _buf_block);
        read_peer_page_ctx->response.success = true;

        _rbio_manager->OnReadPeerPage(ctx, read_peer_page_ctx);
    }
    {
        // page lsn > vlsn on rule ge
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;
        rbio_ctx.read_rule = pspb::RbioRequest::GE;

        ctx->action = RbioManager::Action::kReadPage;
        ctx->buf_block = _buf_block;
        ctx->vlsn = 9999;
        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 9999 + 1);


        auto read_peer_page_ctx = new ReadPeerPageContext(1, ctx->logical_page_no, ctx->vlsn, _buf_block);
        read_peer_page_ctx->response.success = true;

        _rbio_manager->OnReadPeerPage(ctx, read_peer_page_ctx);
    }
    {
        // ok
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        ctx->action = RbioManager::Action::kReadPage;
        ctx->buf_block = _buf_block;
        ctx->vlsn = 9999;
        set_buf_block(_buf_block, 1, ctx->logical_page_no, gaia_page_size(), 9999 - 1);


        auto read_peer_page_ctx = new ReadPeerPageContext(1, ctx->logical_page_no, ctx->vlsn, _buf_block);
        read_peer_page_ctx->response.success = true;

        _rbio_manager->OnReadPeerPage(ctx, read_peer_page_ctx);
    }
}

TEST_F(RbioManagerTests, test_WritePage) {
    auto segment = create_mock_segment();
    pspb::WritePageRequest request;
    request.set_request_id(1);
    request.set_n(1);
    for (int32_t i = 0; i < 1; ++i) {
        auto w_reqvec = request.add_requestvec();
        w_reqvec->set_space_id(1);
        w_reqvec->set_page_no(i);
        w_reqvec->set_data(std::string(16<<10, 'a'));
    }
    {
        // write failed
        pspb::WritePageResponse response;

        RbioManager::WriteTask* rbio = new RbioManager::WriteTask(segment, 1, &request, &response, nullptr);
        rbio->request = &request;
        rbio->response = &response;
        rbio->role = RbioManager::Task::RBIO_PRIMARY;

        RbioManager::Context* ctx = rbio->reqs[0];
        ctx->action = RbioManager::Action::kWritePage;
        ctx->stat_timer.reset();

        auto reqvec = request.add_requestvec();
        reqvec->set_data(std::string("xx"));
        ctx->write_req = reqvec;

        ctx->retry_times = 0;
        ctx->vlsn = 888;
        ctx->buf_block = _buf_block;
        init_buf_block(_buf_block, 1, 1, gaia_page_size());

        segment->_fetch_lsn(999);
        segment->_parse_lsn(999);

        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(Return(false));

        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kCorrupted)));

        _rbio_manager->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), page_server::WritePageResponse_Error_ERROR);
    } END_OF_CASE;
    {
        // write failed
        pspb::WritePageResponse response;

        RbioManager::WriteTask* rbio = new RbioManager::WriteTask(segment, 1, &request, &response, nullptr);
        rbio->request = &request;
        rbio->response = &response;
        rbio->role = RbioManager::Task::RBIO_PRIMARY;

        RbioManager::Context* ctx = rbio->reqs[0];
        ctx->action = RbioManager::Action::kWritePage;
        ctx->stat_timer.reset();

        auto reqvec = request.add_requestvec();
        reqvec->set_data(std::string("xx"));
        ctx->write_req = reqvec;

        ctx->retry_times = 0;
        ctx->vlsn = 888;
        ctx->buf_block = _buf_block;
        init_buf_block(_buf_block, 1, 1, gaia_page_size());

        segment->_fetch_lsn(999);
        segment->_parse_lsn(999);

        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(Return(false));

        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));


        _rbio_manager->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), page_server::WritePageResponse_Error_SUCCESS);
    } END_OF_CASE;
    {
        // write failed
        pspb::WritePageResponse response;

        RbioManager::WriteTask rbio(segment, 1, &request, &response, nullptr);
        rbio.request = &request;
        rbio.response = &response;
        rbio.role = RbioManager::Task::RBIO_PRIMARY;

        RbioManager::Context* ctx = rbio.reqs[0];
        ctx->stat_timer.reset();

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Return(true));
        _rbio_manager->Rbio(ctx);
    }

    BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
}

TEST_F(RbioManagerTests, test_Rbio) {
    auto segment = create_mock_segment();

    page_server::RbioRequest request;
    request.set_requestid(1);
    request.set_n(2);
    request.set_readtype(pspb::RbioRequest::READ_SYNC);
    for (int32_t i = 0; i < 2; ++i) {
        auto req = request.add_reqvec();
        req->set_tablespaceid(1);
        req->set_logicalpageno(i);
        req->set_vlsn(9999);
        req->set_ziplen(gaia_logical_page_size());
    }

    {
        // lowest_lsn
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];
        ctx->lowest_lsn = 10001;

        segment->_parse_lsn(10000);

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;

        _rbio_manager->Rbio(ctx);
    } END_OF_CASE;

    {
        // is_peer_read
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];
        ctx->lowest_lsn = 10000;

        segment->_parse_lsn(10000);

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.is_peer_read = true;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Return(true));
        _rbio_manager->Rbio(ctx);
    } END_OF_CASE;

    {
        // recovery_status_is_finish
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];
        ctx->lowest_lsn = 0;

        segment->_parse_lsn(10000);

        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.is_peer_read = false;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;

        segment->_recovery_status = gaiadb::RECOVERY_IN;

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Return(true));
        _rbio_manager->Rbio(ctx);
    } END_OF_CASE;

    {
        // vlsn > parser_lsn
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        segment->_parse_lsn(10000);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.is_peer_read = false;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;

        segment->_recovery_status = gaiadb::RECOVERY_FINISH;
        ctx->vlsn = 10000 + 99;

        EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Return());
        _rbio_manager->Rbio(ctx);
    } END_OF_CASE;

    {
        // with offset & LE
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        segment->_parse_lsn(10000);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.is_peer_read = false;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;

        segment->_recovery_status = gaiadb::RECOVERY_FINISH;
        ctx->vlsn = 10000 + 99;
        rbio_ctx.req_has_physical_extent_id = true;
        rbio_ctx.read_rule = pspb::RbioRequest::LE;
        rbio_ctx.enable_attachment_type = true;
        rbio_ctx.last_error_code = pspb::RbioResponse_Error_RBIO_INVALID;

        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(_buf_block))
            .WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kCorrupted, "mock corrupt")));

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Return(true));
        _rbio_manager->Rbio(ctx);
    } END_OF_CASE;

    {
        // GetSpacePagePhysicalOffset fail
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        segment->_parse_lsn(10000);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.is_peer_read = false;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;

        segment->_recovery_status = gaiadb::RECOVERY_FINISH;

        EXPECT_CALL(*segment.get(), GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(false));

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Return(true));
        _rbio_manager->Rbio(ctx);
    } END_OF_CASE;

    {
        // buf_block fail
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        segment->_parse_lsn(10000);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.is_peer_read = false;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;

        segment->_recovery_status = gaiadb::RECOVERY_FINISH;
        rbio_ctx.enable_attachment_type = true;
        rbio_ctx.last_error_code = pspb::RbioResponse_Error_RBIO_INVALID;

        EXPECT_CALL(*segment.get(), GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(nullptr));

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Return(true));
        _rbio_manager->Rbio(ctx);
    } END_OF_CASE;

    {
        // ok
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        segment->_parse_lsn(10000);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.is_peer_read = false;
        segment->_recovery_status = gaiadb::RECOVERY_FINISH;
        ctx->vlsn = 10000 + 99;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;

        rbio_ctx.req_has_physical_extent_id = true;
        rbio_ctx.read_rule = pspb::RbioRequest::LE;
        rbio_ctx.enable_attachment_type = false;
        rbio_ctx.last_error_code = pspb::RbioResponse_Error_RBIO_INVALID;

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk, "mock ok")));

        _rbio_manager->Rbio(ctx);
    } END_OF_CASE;

    {
        // ahead
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        segment->_parse_lsn(10000);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.is_peer_read = false;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_SECONDARY;

        segment->_recovery_status = gaiadb::RECOVERY_FINISH;
        ctx->vlsn = 10000;
        ctx->fetch_begin_time = 1;

        rbio_ctx.req_has_physical_extent_id = true;
        rbio_ctx.enable_attachment_type = false;
        rbio_ctx.last_error_code = pspb::RbioResponse_Error_RBIO_INVALID;

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kAhead, "mock ok")));

        _rbio_manager->Rbio(ctx);
    } END_OF_CASE;

    {
        // ahead 2
        page_server::RbioResponse response;

        RbioManager::ReadTask rbio_ctx(segment, 2, nullptr, &request, &response, nullptr);
        RbioManager::Context* ctx = rbio_ctx.reqs[0];

        segment->_parse_lsn(10000);
        ASSERT_TRUE(rbio_ctx.Init(base::cpuwide_time_us()));
        rbio_ctx.is_peer_read = false;
        rbio_ctx.finish_count = 0;
        rbio_ctx.role = RbioManager::Task::RBIO_PRIMARY;
        rbio_ctx.secondary_fetch_lsn = 1000;

        segment->_recovery_status = gaiadb::RECOVERY_FINISH;
        //ctx->vlsn = 10000;
        rbio_ctx.req_has_physical_extent_id = true;
        rbio_ctx.enable_attachment_type = false;

        EXPECT_CALL(*segment.get(), ReadPageData(_, _, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kAhead, "mock ok")));

        _rbio_manager->Rbio(ctx);
    } END_OF_CASE;
}

TEST_F(RbioManagerTests, test_RbioCondition) {
    auto segment = create_segment();
    RbioManager::Context ctx(nullptr);
    {
        RbioManager::ConditionTask t1(&ctx, segment, 1024);
        RbioManager::ConditionTask t2(t1);
        RbioManager::ConditionTask t3(std::move(t1));

        ASSERT_EQ(t2.lsn, t3.lsn);

        ASSERT_FALSE(t3);

        segment->_parse_lsn(1025);
        ASSERT_TRUE(t3);
    }
    {

        RbioManager::ConditionTask t1(&ctx, segment, 1024);
        ASSERT_TRUE(t1);
        RbioManager::ConditionTask t2(&ctx, segment, 1026);
        ASSERT_FALSE(t2);

        RbioManager::ConditionQueue queue;
        queue.Push(t1);
        queue.Push(t2);

        typename ConditionThread<RbioManager::ConditionTask, RbioManager::ConditionQueue>::Fn fun1 = [](const RbioManager::ConditionTask& t) {
                    LOG(NOTICE) << "pop lsn:" << t.lsn;
                    ASSERT_EQ(t.lsn, 1024);
                };
        queue.PopIf(fun1);

        typename ConditionThread<RbioManager::ConditionTask, RbioManager::ConditionQueue>::Fn fun2 = [](const RbioManager::ConditionTask& t) {
                    ASSERT_EQ(t.lsn, 1026);
                };
        queue.Clear(fun2);

        queue.Push(t1);
        queue.Push(t2);

        queue.PopIf(fun1);
        queue.Clear(fun2);
    }
}


}
}
