/*****************************************************************************

Copyright (c) 2022, Baidu and/or its affiliates. All Rights Reserved.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

#include "rbio.h"

#include <algorithm>
#include <random>
#include "buf0buf.h"
#include "db0err.h"
#include "rpl0rpl.h"
#include <future>
#include <atomic>
#include <base/third_party/murmurhash3/murmurhash3.h>
#include "gaiadb/rpc_client/rpc_call.h"
#include "sql/current_thd.h"
#include "sql/mysqld.h"     //stage_gaia_doing_rbio
#include "sql/sql_class.h" // THD
#include "fsp0fsp.h"
#include "os0file.h"
#include "buf0checksum.h"
#include "log0log.h"
#include "gaiadb.h"
#include "takeover.h"
#include "landing_zone_client.h"
#include "ibuf0ibuf.h"
#include "rpl0fetch.h"  // FLAGS_secondary_exit_if_slow_node
#include "bthread0op.h"

DEFINE_int32(rbio_timeout_ms, 800, "timeout ms for rbio request");
BAIDU_RPC_VALIDATE_GFLAG(rbio_timeout_ms, baidu::rpc::PositiveInteger);

DEFINE_int32(rbio_max_timeout_ms, 5000, "max timeout ms for rbio request");
BAIDU_RPC_VALIDATE_GFLAG(rbio_max_timeout_ms, baidu::rpc::PositiveInteger);

DEFINE_bool(rbio_enable_gaia_backup, true, "rbio use gaia backup request");
BAIDU_RPC_VALIDATE_GFLAG(rbio_enable_gaia_backup, baidu::rpc::PassValidate);

DEFINE_int32(rbio_gaia_backup_node_size, 0, "rbio gaia backup request node size, 0 means use all");
BAIDU_RPC_VALIDATE_GFLAG(rbio_gaia_backup_node_size, baidu::rpc::NonNegativeInteger);

DEFINE_int64(rbio_gaia_backup_first_request_us, 1500, "set gaia rbio backup request trigger time ms");
BAIDU_RPC_VALIDATE_GFLAG(rbio_gaia_backup_first_request_us, baidu::rpc::PositiveInteger);

DEFINE_int64(rbio_gaia_backup_second_request_us, 3000, "set gaia rbio backup request trigger time ms");
BAIDU_RPC_VALIDATE_GFLAG(rbio_gaia_backup_second_request_us, baidu::rpc::PositiveInteger);

DEFINE_int32(rbio_gaia_backup_wait_succ_response, 2,
    "rbio gaia backup request wait success response if the first return fails,"
    " 0 if disable, > 0 if enable., > 1 if use only successful");
BAIDU_RPC_VALIDATE_GFLAG(rbio_gaia_backup_wait_succ_response, baidu::rpc::NonNegativeInteger);

DEFINE_bool(rbio_gaia_backup_enable_exclude_policy, true,
    "rbio gaia backup request using a custom exclude policy");
BAIDU_RPC_VALIDATE_GFLAG(rbio_gaia_backup_enable_exclude_policy, baidu::rpc::PassValidate);

DEFINE_bool(rbio_enable_backup, true, "rbio use brpc backup request");
BAIDU_RPC_VALIDATE_GFLAG(rbio_enable_backup, baidu::rpc::PassValidate);

DEFINE_string(rbio_backup_lb_name, "gaia", "The algorithm for load balancing");

DEFINE_int64(rbio_backup_request_ms, 2, "set rbio brpc backup request trigger time ms");
BAIDU_RPC_VALIDATE_GFLAG(rbio_backup_request_ms, baidu::rpc::PositiveInteger);

DEFINE_int32(rbio_backup_max_retry, 1, "set rbio brpc backup request max retry");
BAIDU_RPC_VALIDATE_GFLAG(rbio_backup_max_retry, baidu::rpc::PositiveInteger);

DEFINE_int64(rbio_max_sleep_us, 2000000, "rbio max sleep us on failed");
BAIDU_RPC_VALIDATE_GFLAG(rbio_max_sleep_us, baidu::rpc::PositiveInteger);

DEFINE_bool(rbio_enable_simple_rpc_client, true, "rbio use simple brpc client");
BAIDU_RPC_VALIDATE_GFLAG(rbio_enable_simple_rpc_client, baidu::rpc::PassValidate);

DEFINE_bool(rbio_enable_attachment_type_data, false, "rbio use attachment type for data");
BAIDU_RPC_VALIDATE_GFLAG(rbio_enable_attachment_type_data, baidu::rpc::PassValidate);

DEFINE_bool(rbio_with_extent_offset, false, "rbio rquest with extent offset");
BAIDU_RPC_VALIDATE_GFLAG(rbio_with_extent_offset, baidu::rpc::PassValidate);

DEFINE_bool(rbio_with_polar_client, false, "rbio rquest with use polar client");
BAIDU_RPC_VALIDATE_GFLAG(rbio_with_polar_client, baidu::rpc::PassValidate);

DEFINE_bool(rbio_polar_use_bthread_queue, false, "use bhtread queue to send rbio to polar");
BAIDU_RPC_VALIDATE_GFLAG(rbio_polar_use_bthread_queue, baidu::rpc::PassValidate);

DEFINE_uint64(rbio_polar_bthread_queue_size, 4, "bthread queues size");
DEFINE_uint64(rbio_polar_bthread_queue_max_task_size, 10240, "bthread queues max task size");

DEFINE_uint64(rbio_trace_max_lat_us, 1000 * 1000 * 1000, "trace page server rbio max lat us");

DECLARE_bool(gaia_enable_slow_query_log);

std::atomic<ulint> rbio_count(0);
std::atomic<ulonglong> rbio_time_sum(0);

constexpr static uint32_t kMaxRbioBackupCount = 10;

extern bool srv_rpl_primary;

/* for bvar */
static bvar::LatencyRecorder page_rbio_total("gaia_cmp_page_rbio_total");

static bvar::LatencyRecorder page_rbio_real("gaia_cmp_page_rbio_real");

static bvar::LatencyRecorder page_rbio_rpc("gaia_cmp_page_rbio_rpc");

static bvar::LatencyRecorder page_rbio_undo("gaia_cmp_page_rbio_undo");

static bvar::LatencyRecorder purge_index_rbio("gaia_cmp_purge_index_rbio");

static bvar::LatencyRecorder page_on_handle_rbio("gaia_cmp_page_on_handle_rbio");

static bvar::Adder<uint64_t> space0_page_rbio_number;
static bvar::Window<bvar::Adder<uint64_t>> space0_page_rbio_number_w("gaia_cmp",
                                        "space0_page_rbio_number_1s",
                                        &space0_page_rbio_number, 1);

static bvar::Adder<uint64_t> ibuf_bitmap_page_rbio_number;
static bvar::Window<bvar::Adder<uint64_t>> ibuf_bitmap_page_rbio_number_w("gaia_cmp",
                                        "ibuf_bitmap_page_rbio_number_1s",
                                        &ibuf_bitmap_page_rbio_number, 1);

static bvar::Adder<uint64_t> rbio_with_backup_count;
static bvar::PerSecond<bvar::Adder<uint64_t>> rbio_with_backup_count_window("gaia_cmp_page_rbio_with_backup_qps",
    &rbio_with_backup_count, -1);

static bvar::Adder<uint64_t> rbio_with_polar_count;
static bvar::PerSecond<bvar::Adder<uint64_t>> rbio_with_polar_count_window("gaia_cmp_page_rbio_with_polar_qps",
    &rbio_with_polar_count, -1);

static bvar::Adder<uint64_t> rbio_with_le_count;
static bvar::PerSecond<bvar::Adder<uint64_t>> rbio_with_le_count_window("gaia_cmp_page_rbio_with_le_qps",
    &rbio_with_le_count, -1);

static bvar::Adder<uint64_t> rbio_with_reset_vlsn;
static bvar::PerSecond<bvar::Adder<uint64_t>> rbio_with_reset_vlsn_window("gaia_cmp_page_rbio_with_reset_vlsn_qps",
    &rbio_with_reset_vlsn, -1);

static bvar::Adder<uint64_t> rbio_with_delta_apply;
static bvar::PerSecond<bvar::Adder<uint64_t>> rbio_with_delta_apply_window("gaia_cmp_page_rbio_with_delta_apply_qps",
    &rbio_with_delta_apply, -1);

static bvar::LatencyRecorder rbio_delta_apply("gaia_cmp_page_rbio_delta_apply");

static bvar::Adder<uint64_t> page_rbio_errors;
static bvar::Window<bvar::Adder<uint64_t>> page_rbio_errors_w(
    "gaia_cmp", "page_rbio_errors_1s", &page_rbio_errors, 1);

static bvar::LatencyRecorder ps_fetch_latency("gaia_cmp_ps_fetch");
static bvar::LatencyRecorder ps_parse_latency("gaia_cmp_ps_parse");
static bvar::LatencyRecorder ps_apply_latency("gaia_cmp_ps_apply");

DEFINE_int32(slow_rbio_cost_time_ms, 50, "slow rbio cost time,ms");
BAIDU_RPC_VALIDATE_GFLAG(slow_rbio_cost_time_ms, baidu::rpc::PositiveInteger);

static bvar::Adder<uint64_t> pri_rbio_use_vdl;
static bvar::Window<bvar::Adder<uint64_t>> pri_rbio_use_vdl_w(
    "cmp_page_rbio_pri_use_vdl", &pri_rbio_use_vdl, 1);

static bvar::Miner<uint64_t> pri_rbio_vlsn_shrink;
static bvar::Window<bvar::Miner<uint64_t>> pri_rbio_vlsn_shrink_w(
    "cmp_page_rbio_pri_vlsn_shrink", &pri_rbio_vlsn_shrink, 1);

static uint64_t hash_rbio_reqid(uint32_t reqid, uint32_t retry_n) {
    uint32_t hash;
    base::MurmurHash3_x86_32(&reqid, sizeof(reqid), 0, &hash);
    return gaiadb::psm_client::make_rpc_request_code(hash, retry_n);
}

static int64_t calc_rbio_sleep_us(uint32_t retry_n) {
  int64_t t = retry_n * 20l;
  return std::min(t, FLAGS_rbio_max_sleep_us);
}

static int32_t calc_rbio_timeout_ms(uint32_t retry_n) {
  int32_t next_timeout = FLAGS_rbio_timeout_ms + retry_n * 200;
  return std::min(next_timeout, FLAGS_rbio_max_timeout_ms);
}

/** To get vlsn from pagelsn_hash, if not found, use vdl instead
@param[in]  page_id            page_id by which we can get buf_pool,
                               space_id, page_no
@return vlsn for RBIO */
static lsn_t rbio_vlsn_get_for_primary(buf_page_t *bpage, bool *version_ge) {
  ut_a(version_ge);
  ut_a(srv_rpl_primary);
  ut_a(bpage);
  lsn_t lsn = bpage->get_request_vlsn();
  // if (bpage->get_request_vlsn()) {
  //   lsn = bpage->get_request_vlsn();
  // } else {
  //   lsn_t start_vdl = log_get_start_vdl(*log_sys);
  //   if (start_vdl > 0) {
  //     lsn = start_vdl;
  //   }
  // }

  *version_ge = false;
  if (lsn > 0) {
    if (hotbackup::get_stage() >= hotbackup::Stage::Success) {
      lsn = std::max(
          landing_zone::g_landing_zone_client.last_increase_epoch_lsn(), lsn);
    }

    *version_ge = true;
    if (log_sys) {
      pri_rbio_vlsn_shrink << log_get_vdl(*log_sys) - lsn;
    }
    return lsn;
  } else {
    pri_rbio_use_vdl << 1;
    auto vdl = log_sys != nullptr ? log_get_vdl(*log_sys) : 0;
    //return  vdl == 0 ? compute_node_info->apply_lsn : vdl;

    if (vdl > 0) {
      return std::min(landing_zone::get_last_increase_epoch_lsn(), vdl);
    } else {
      return std::max(compute_node_info->apply_lsn,
          landing_zone::g_landing_zone_client.last_increase_epoch_lsn());
    }
  }
}

static lsn_t rbio_vlsn_get_for_secondary(buf_page_t *bpage,
    uint32_t *ref_redo_type, lsn_t *refed_index, lsn_t *lowest_lsn) {
  lsn_t read_lsn = 0;

  if (!rpl::FLAGS_rpl_enable_delta_replay) {
    read_lsn = rpl::get_read_lsn();
    *lowest_lsn = rpl::get_lowest_lsn();
  } else {
    ut_a(ref_redo_type);
    ut_a(refed_index);
    ut_a(lowest_lsn);
    *ref_redo_type = rpl::rbio_get_refed_read_lsn(read_lsn, refed_index, lowest_lsn);
  }
  if(read_lsn == 0){
    read_lsn = compute_node_info->apply_lsn;
    *lowest_lsn = rpl::get_lowest_lsn();
  }
  LOG(TRACE) << "page: " << bpage->id
    << " , read_lsn: " << read_lsn
    << " , lowest_lsn: " << *lowest_lsn;
  ut_a(read_lsn > 0);
  if (*lowest_lsn > read_lsn) {
    *lowest_lsn = read_lsn;
  }
  return read_lsn;
}

void destroy_gaia_backup_request() {
  gaiadb::common::stop_rpc_backup_request();
}

/* Calculate extent_no and pass it to extent map lib,
@param[in]	space_id	space_id
@param[in]	page_no		page_no
@param[in]	page_size	page_size, by which we get extent_no
@return extent_no, by which we can get segment and ip+port from extent map lib*/
uint32_t extent_no_get(space_id_t space_id, page_no_t page_no) {
  /* pyhsical extent size can be 1MB, 2MB, 4MB, devide it by 1MB. */
  return uint32_t(uint64_t(UNIV_PAGE_SIZE) * page_no / (1024 * 1024));
}

namespace gaia {

static bool aio_executers_succ = false;
gaia::AIO_Executor_Array aio_executors {};

static bool aio_cb_in_threads_succ = false;
gaiadb::common::thread::Executor<AIO_cb, AIO_cb> *aio_cb_threads_executor = nullptr;

int aio_executer_cb(void *, bthread::TaskIterator<AIO_cb *> &it) {
  if (it.is_queue_stopped()) {
    return 0;
  }
  int ret = 0;
  for (; it; ++it) {
    AIO_cb *aio_cb = *it;
    if (gaiadb_async_read_page(aio_cb) != DB_SUCCESS) {
      ret = -1;
    }
  }
  return ret;
}

static bool aio_cb_fn(AIO_cb *aio_cb) {
  os_aio_wake_remote_io_completed(aio_cb);
  return true;
}

void aio_init() {
  ut_a(!aio_executers_succ);
  aio_executers_succ = aio_executors.init(srv_gaia_aio_executer_num + 1/*ibuf*/,
                                          srv_gaia_aio_executer_queue_size);
  if (!aio_executers_succ) {
    srv_use_gaia_aio = false;
    LOG(WARNING) << "init bthread queue aio executors failed";
  } else {
    ib_system() << "init aio executors ok, num:" << srv_gaia_aio_executer_num
      << ", per queue size:" << srv_gaia_aio_executer_queue_size;
  }

  typename gaiadb::common::thread::Executor<AIO_cb>::TaskFn fn
    = std::bind(aio_cb_fn, std::placeholders::_1);
  aio_cb_threads_executor = new gaiadb::common::ThreadPoolExecutor<AIO_cb, AIO_cb>();
  aio_cb_in_threads_succ = aio_cb_threads_executor->Start("gaia_aio_c", nullptr,
      srv_n_read_io_threads + 1/*ibuf*/, false, fn);
  if (!aio_cb_in_threads_succ) {
    ib_warn() << "start gaia aio complete threads failed";
  }
}

void aio_deinit() {
  if (aio_executers_succ) {
    aio_executors.deinit();
  }
  if (aio_cb_in_threads_succ) {
    aio_cb_threads_executor->Stop(true);
  }
}

} // end of ns gaia

void RbioClient::deinit() {
  set_stop();
  gaia::aio_deinit();
}

bool RbioRetryPolicy::DoRetry(const baidu::rpc::Controller* cntl) const {
  if (cntl->ErrorCode() == baidu::rpc::EBACKUPREQUEST) {
    // backup request, should retry
    return true;
  }
  const bool backup = FLAGS_rbio_enable_gaia_backup &&
                      FLAGS_rbio_gaia_backup_wait_succ_response > 1;
  if (cntl->ErrorCode() == 0) {   // net is ok
    const auto& rc = static_cast<page_server::RbioResponse*>(cntl->response())->errcode();
    if (backup) {
      // in backup request, give higher priority to requests that return successfully.
      return rc != page_server::RbioResponse::RBIO_SUCCESS;
    }
    // no need to repeatedly retry these error codes on the same node.
    if (rc != page_server::RbioResponse::RBIO_SUCCESS     // ok
        && rc != page_server::RbioResponse::RBIO_INVALID   // rbio request error, bug
        && rc != page_server::RbioResponse::RBIO_NOT_EXIST  // space not exist
        && rc != page_server::RbioResponse::RBIO_SEGMENT_NOT_EXIST  // segment not exist, sync segment
        && rc != page_server::RbioResponse::RBIO_AHEAD_FAILED // lsn invalid
        && rc != page_server::RbioResponse::RBIO_SEGMENT_INACTIVE) {  // segment status error, sync segment or other error
      cntl->response()->Clear();
      return true;
    }
  }
  return backup || baidu::rpc::DefaultRetryPolicy()->DoRetry(cntl);
}

int32_t RbioExlucdePolicy::DoExclude(const baidu::rpc::Controller* cntl) const {
  if (cntl->ErrorCode() == 0) {   // ok
    const auto& rc = static_cast<page_server::RbioResponse*>(cntl->response())->errcode();
    if (rc == page_server::RbioResponse::RBIO_SERVER_STOP) {
      LOG(WARNING) << "rpc response code not ok, exclude it,"
        << " addr:" << cntl->remote_side()
        << " code:" << pspb::RbioResponse::Error_Name(rc);
      return gaiadb::common::backup_request::ExlucdePolicy::kCommonErr;
    }
    if (rc == page_server::RbioResponse::RBIO_SEGMENT_NOT_EXIST
        || rc == page_server::RbioResponse::RBIO_SEGMENT_INACTIVE
        || rc == page_server::RbioResponse::RBIO_LSN_WAIT) {
      LOG(WARNING) << "rpc response code not ok, exclude it,"
        << " addr:" << cntl->remote_side()
        << " code:" << pspb::RbioResponse::Error_Name(rc);
      return gaiadb::common::backup_request::ExlucdePolicy::kCustomErr;
    }
  }
  return gaiadb::common::DefaultBackRequestExlucdePolicy()->DoExclude(cntl);
}

void RbioClient::RbioContext::deref_redo() {
  if (ref_redo_type > 0) {
    rpl::rbio_finish_apply(ref_redo_type, refed_index);
    ref_redo_type = 0;
  }
}

RbioClient::RbioContext::~RbioContext() {
  deref_redo();
  delete cntl;
  delete request;
  delete response;
  delete gaia_backup_ctx;
}

bool RbioClient::init(gaiadb::psm_client::Psmgr_client *psm_client) {
  rpc_log_id_.store(base::gettimeofday_us());
  gaiadb::common::init_rpc_backup_request();
  rbio_retry_policy_.reset(new RbioRetryPolicy());
  rbio_exclude_policy_.reset(new RbioExlucdePolicy());
  psm_client_ = psm_client;
  if (opt_initialize) {
    return true;
  }
  if (gaiadb::polar::enable_polar()) {
    rbio_executors_succ_ = rbio_executors_.Start(FLAGS_rbio_polar_bthread_queue_size,
        FLAGS_rbio_polar_bthread_queue_max_task_size);
    if (!rbio_executors_succ_) {
      LOG(WARNING) << "init bthread queue executors failed";
    }
  }
  return true;
}

dberr_t RbioClient::get_page_by_gaia_backup(RbioContext* context) {
  // if brpc backup disable or init fail, retry normal
  auto& segment_replicas = context->backup_servers;
  do {
    if (segment_replicas.empty() || context->sync_segment) {
      dberr_t err = get_segment_replicas(context->segment_id, segment_replicas, context->sync_segment);
      ut_a(err == DB_SUCCESS);
      context->sync_segment = false;
    }
    const size_t replicas_size = segment_replicas.size();
    size_t backup_num = 0;
    if (FLAGS_rbio_gaia_backup_node_size > 0) {
      backup_num = std::min(replicas_size, static_cast<size_t>(FLAGS_rbio_gaia_backup_node_size));
    }
    auto gaia_backup_ctx = new gaiadb::common::BackRequestContext(segment_replicas[0].addr, backup_num);
    for (size_t i = 1; i < replicas_size; ++i) {
      gaia_backup_ctx->AddReq(segment_replicas[i].addr,
          i == 1 ? FLAGS_rbio_gaia_backup_first_request_us : FLAGS_rbio_gaia_backup_second_request_us);
    }
    gaia_backup_ctx->set_log_id(context->request->requestid());
    gaia_backup_ctx->set_timeout_ms(calc_rbio_timeout_ms(context->retry_count));
    gaia_backup_ctx->set_max_retry(gaiadb::common::FLAGS_gaia_rpc_try_times);
    gaia_backup_ctx->set_retry_policy(rbio_retry_policy_);
    if (FLAGS_rbio_gaia_backup_enable_exclude_policy) {
      gaia_backup_ctx->set_exclude_policy(rbio_exclude_policy_);
      gaia_backup_ctx->set_exclude_id(context->segment_id);
    }
    if (FLAGS_rbio_gaia_backup_wait_succ_response) {
      gaia_backup_ctx->set_wait_succ(true);
    }

    context->real_start_us = base::monotonic_time_us();
    context->gaia_backup_ctx = gaia_backup_ctx;
    if (context->aio_cb) {
        ggpb::Closure *closure = brpc::NewCallback(this, &RbioClient::on_rbio, context, true);
        gaia_rpc_bakcup_request_.Call(gaia_backup_ctx,
            context->request, context->response, &page_server::RbioService_Stub::Rbio, closure);
        return DB_SUCCESS;
    }

    // send sync rbio & handle result
    std::unique_ptr<gaiadb::common::BackRequestContext> gaia_backup_ctx_guard(gaia_backup_ctx);
    gaia_rpc_bakcup_request_.Call(gaia_backup_ctx,
        context->request, context->response, &page_server::RbioService_Stub::Rbio, nullptr);
    on_rbio(context, true);

    context->gaia_backup_ctx = nullptr;

    if (context->space_not_exist) {
      return DB_TABLESPACE_DELETED;
    }
    if (context->success) {
      return DB_SUCCESS;
    }
  } while (FLAGS_rbio_enable_gaia_backup && !stopped_);
  return DB_ERROR;
}

dberr_t RbioClient::get_page_by_brpc_backup(RbioContext* context) {
  auto channel = psm_client_->get_segment_rpc_backup_channel(context->segment_id,
      rbio_retry_policy_.get(), FLAGS_rbio_backup_lb_name.c_str());
  if (channel) {
    page_server::RbioService_Stub stub(channel.get());
    auto cntl = context->cntl;
    do {
      cntl->set_timeout_ms(calc_rbio_timeout_ms(context->retry_count));
      cntl->set_max_retry(FLAGS_rbio_backup_max_retry); // for backup request
      cntl->set_backup_request_ms(FLAGS_rbio_backup_request_ms);
      cntl->set_request_code(hash_rbio_reqid(context->request->requestid(), context->retry_count));
      cntl->set_user_defined_retry_policy_manage_backup_request();
      // send sync rbio & handle result
      context->real_start_us = base::monotonic_time_us();
      if (context->aio_cb) {
        ggpb::Closure *closure = brpc::NewCallback(this, &RbioClient::on_rbio, context, true);
        stub.Rbio(cntl, context->request, context->response, closure);
        return DB_SUCCESS;
      }

      // send sync rbio & handle result
      stub.Rbio(cntl, context->request, context->response, nullptr);
      on_rbio(context, true/*is backup*/);

      if (context->space_not_exist) {
        return DB_TABLESPACE_DELETED;
      }
      if (context->success) {
        return DB_SUCCESS;
      }

      cntl->Reset();
    } while (FLAGS_rbio_enable_backup && !stopped_);
  }
  return DB_ERROR;
}

dberr_t RbioClient::get_page_by_brpc(RbioContext* context) {
  auto& segment_replicas = context->backup_servers;
  if (segment_replicas.empty() || context->sync_segment) {
    dberr_t err = get_segment_replicas(context->segment_id, segment_replicas, context->sync_segment);
    ut_a(err == DB_SUCCESS);
    context->sync_segment = false;
    context->backup_servers_idx = 0;
  }
  const size_t replicas_size = segment_replicas.size();
  auto cntl = context->cntl;
  if (context->backup_servers_idx >= replicas_size) {
    context->backup_servers_idx = 0;
  }
  while (context->backup_servers_idx < replicas_size && !stopped_) {
    cntl->set_timeout_ms(calc_rbio_timeout_ms(context->retry_count));
    cntl->set_max_retry(gaiadb::common::FLAGS_gaia_rpc_try_times);
    context->server_addr = &segment_replicas[context->backup_servers_idx++];
    context->real_start_us = base::monotonic_time_us();
    if (context->aio_cb) {
      ggpb::Closure *closure = brpc::NewCallback(this, &RbioClient::on_rbio, context, false);
      do_rbio(context, closure);
      return DB_SUCCESS;
    }

    // send sync rbio & handle result
    do_rbio(context, nullptr);
    on_rbio(context, false);

    if (context->space_not_exist) {
      return DB_TABLESPACE_DELETED;
    }
    if (context->success) {
      return DB_SUCCESS;
    }
  }
  return DB_ERROR;
}

void RbioClient::on_polar_rbio(RbioContext* context) {
  context->polar_sync_promise->set_value();
}

void RbioClient::do_rbio(RbioContext* context,
    google::protobuf::Closure* closure) {
  baidu::rpc::Controller* cntl = context->cntl;
  page_server::RbioRequest* request = context->request;
  page_server::RbioResponse* response = context->response;
  auto& peer = *context->server_addr;

  LOG(TRACE) << "RBIO sync_mode=" << (closure ? "async" : "sync")
    << " on request=" << request->requestid()
    << ", spage_id:" << request->reqvec(0).tablespaceid()
    << ", page_no:" << request->reqvec(0).logicalpageno()
    << ", LSN:" << request->reqvec(0).vlsn()
    << ", page_server:" << peer
    << ", simple_rpc:" << (context->simple_rpc ? 1 : 0)
    << ", use_polar:" << (context->use_polar ? 1 : 0);

  if (psm_client_->has_zone() && peer.has_zone()) {
    request->mutable_zone()->set_region(peer.region);
    request->mutable_zone()->set_available_zone(peer.available_zone);
  }

  if (context->use_polar) {
    rbio_with_polar_count << 1;
    if (rbio_executors_succ_ && FLAGS_rbio_polar_use_bthread_queue) {
      if (rbio_executors_.GetExecutor().Execute(cntl, peer.addr,
            &page_server::RbioService_Stub::Rbio,
            request, response, closure)) {
        return;
      }
      LOG(WARNING) << "rbio executor execute failed";
    }
    std::promise<void> polar_sync_promise;
    std::future<void> polar_sync_future;
    const bool create_closure = !closure;
    if (!closure) {
      polar_sync_future = polar_sync_promise.get_future();
      context->polar_sync_promise = &polar_sync_promise;
      closure = baidu::rpc::NewCallback(this, &RbioClient::on_polar_rbio, context);
    }
    polar_rbio_client_.Call(cntl, peer,
        &page_server::RbioService_Stub::Rbio,
        request, response, closure);
    if (create_closure) {
      polar_sync_future.get();
      closure = nullptr;
      context->polar_sync_promise = nullptr;
    }
  } else if (context->simple_rpc) {
    rbio_client_.Call(cntl, peer,
        &page_server::RbioService_Stub::Rbio,
        request, response, closure);
  } else {
    gaiadb::common::issue_rpc<page_server::RbioRequest,
      page_server::RbioResponse,
      page_server::RbioService_Stub,
      gaiadb::common::DESTINATION::PAGE_SERVER>(
          peer.addr, &page_server::RbioService_Stub::Rbio, request,
          response, closure, nullptr, nullptr, nullptr, cntl);
  }
}

void RbioClient::async_handler(RbioContext* context) {
  if (!context->aio_cb) {
    return;
  }
  if (stopped_) {
    delete context;
    return;
  }
  if (context->success || context->space_not_exist) {
    if (gaia::aio_cb_in_threads_succ && srv_enable_gaia_aio_cb_in_pthread) {
      if (!context->aio_cb->is_ibuf) {
        static std::atomic<uint32_t> dispatch_idx = 0;
        context->aio_cb->client_id =
          dispatch_idx.fetch_add(1, std::memory_order_relaxed) % srv_n_read_io_threads;
      } else {
        context->aio_cb->client_id = srv_n_read_io_threads;
      }
      gaia::aio_cb_threads_executor->Execute(context->aio_cb);
    } else {
      os_aio_wake_remote_io_completed(context->aio_cb);
    }
    delete context;
    return;
  }
  dberr_t err = get_page_low(context);
  ut_a(err == DB_SUCCESS);
}

void RbioClient::on_rbio(RbioContext* context, bool is_backup) {
  uint64_t begin_time = base::monotonic_time_us();
  base::EndPoint remote_server;
  bool need_reset_vlsn = false;
  do {
    if (is_backup) {
      if (context->gaia_backup_ctx) {
        remote_server = context->gaia_backup_ctx->remote_side();
      } else {
        remote_server = context->cntl->remote_side();
      }
    } else {
      remote_server = context->server_addr->addr;
    }
    context->success = false;
    context->space_not_exist = false;
    bool rpc_is_failed = false;
    if (context->gaia_backup_ctx) {
      rpc_is_failed = context->gaia_backup_ctx->Failed();
    } else {
      rpc_is_failed = context->cntl->Failed();
    }
    if (rpc_is_failed) {
      LOG(ERROR) << "RBIO: error on request=" << context->request->requestid()
        << ", page server=" << remote_server
        << ", space=" << context->page_id.space()
        << ", page_no=" << context->page_id.page_no()
        << ", LSN:" << context->vlsn
        << ", errno: " << (context->gaia_backup_ctx ?
            context->gaia_backup_ctx->ErrorCode() : context->cntl->ErrorCode())
        << ", error: " << (context->gaia_backup_ctx ?
            context->gaia_backup_ctx->ErrorText() : context->cntl->ErrorText())
        << ", is_backup: " << is_backup
        << ", simple_rpc: " << context->simple_rpc;
      break;
    }

    auto request = context->request;
    auto response = context->response;

    //save [fetch,parse,apply] cost time and vlsn_diff_ls_dispatch_lsn  to context
    if (response->resvec_size() > 0) {
      const page_server::RbioResponse_ResponseInfo& res_info = response->resvec(0);
      if (res_info.detail_time_cost_size() == 6) {
        if (res_info.detail_time_cost(3) < FLAGS_rbio_trace_max_lat_us
            && res_info.detail_time_cost(4) < FLAGS_rbio_trace_max_lat_us
            && res_info.detail_time_cost(5) < FLAGS_rbio_trace_max_lat_us) {
          ps_fetch_latency << res_info.detail_time_cost(3);
          ps_parse_latency << res_info.detail_time_cost(4);
          ps_apply_latency << res_info.detail_time_cost(5);
        }
      }
      if (context->vlsn_diff_ls_dispatch_lsn == 0 && res_info.has_diff_ls_dispatch_lsn()) {
        context->vlsn_diff_ls_dispatch_lsn = res_info.diff_ls_dispatch_lsn();
      }
    }

    if (response->errcode() != page_server::RbioResponse_Error_RBIO_SUCCESS) {
      const lsn_t cn_lowest_gc_lsn = gaiadb_data->get_cn_lowest_gc_lsn();
      LOG(ERROR) << "RBIO: error on request=" << request->requestid()
        << ", page server=" << remote_server
        << ", error=" << page_server::RbioResponse_Error_Name(response->errcode())
        << ", space=" << context->page_id.space()
        << ", page_no=" << context->page_id.page_no()
        << ", LSN=" << context->vlsn
        << ", cn_lowest_gc_lsn=" << cn_lowest_gc_lsn;
      if (page_server::RbioResponse_Error_RBIO_NOT_EXIST == response->errcode()) {
        context->space_not_exist = true;
        page_on_handle_rbio << base::monotonic_time_us() - begin_time;
        async_handler(context);
        return;
      } else if (page_server::RbioResponse_Error_RBIO_INVALID == response->errcode()) {
        ut_error;
      } else if (page_server::RbioResponse_Error_RBIO_AHEAD_FAILED == response->errcode()) {
        if (!srv_rpl_primary
            && cn_lowest_gc_lsn > context->vlsn) {
          LOG_EVERY_SECOND(WARNING) << "secondary is slow cn with request="
            << request->requestid() << ", page server=" << remote_server
            << " cn_lowest_gc_lsn=" << cn_lowest_gc_lsn
            << " vlsn=" << context->vlsn;
          if (FLAGS_secondary_exit_if_slow_node) {
            std::quick_exit(0);
          }
        }

        if (context->retry_count > 100 &&
            context->vlsn == compute_node_info->apply_lsn) {
          const lsn_t lowest_lsn = std::max(gaiadb_data->get_cn_lowest_lsn(),
              gaiadb_data->get_cn_lowest_gc_lsn());
          if (lowest_lsn > context->vlsn) {
            LOG(WARNING) << "rbio start_lsn=" << context->vlsn
              << " slow lowest_lsn=" << lowest_lsn << ", exit";
            std::quick_exit(0);
          }
        }
      }
      // other error code
      break;
    }
    if (UNIV_UNLIKELY(response->resvec_size() != 1)) {
      // should not reach here!!
      LOG(ERROR) << "RBIO: [Unexpected]response mismatch with request="
        << request->requestid() << ", page server=" << remote_server
        << ", space=" << context->page_id.space()
        << ", page_no=" << context->page_id.page_no()
        << ", LSN=" << context->vlsn
        << ", resvec_size=" << response->resvec_size()
        << ", error=" << page_server::RbioResponse_Error_Name(response->errcode());
      break;
    }
    const page_server::RbioResponse_ResponseInfo& res = response->resvec(0);
    if (UNIV_UNLIKELY(context->page_id.space() != res.tablespaceid()
          || context->page_id.page_no() != res.logicalpageno())) {
      LOG(ERROR) << "RBIO: [Unexpected]Page id mismatch with request="
        << request->requestid() << ", page server=" << remote_server
        << ", page_id(" << res.tablespaceid() << ", " << res.logicalpageno()
        << ") expected(" << context->page_id.space() << ", " << context->page_id.page_no()
        << ")";
      break;
    }

    const page_server::RbioRequest_RequestInfo& req = request->reqvec(0);
    if (req.has_lowest_lsn()
        && !response->has_lowest_gc_lsn()
        && res.vlsn() < req.lowest_lsn()) {
      // PAGE_SERVER version not supoort lowest gc lsn feauter,
      // and return too old page data, need ignore it
      LOG_EVERY_SECOND(WARNING) << "RBIO: page rsp lsn is lowest with request="
        << request->requestid() << ", page server=" << remote_server
        << " req vlsn:" << req.lowest_lsn()
        << " rsp vlsn:" << res.vlsn();
      break;
    }

    if (request->enable_attachment_type() && res.pageframe().empty()) {
      auto response_attachment = context->gaia_backup_ctx ?
        context->gaia_backup_ctx->response_attachment() : context->cntl->response_attachment();
      auto n = response_attachment.copy_to(static_cast<char*>(context->page_ptr), UNIV_PAGE_SIZE);
      ut_a(n == UNIV_PAGE_SIZE);
      assert(n == UNIV_PAGE_SIZE);
    } else {
      const byte *p = (byte *)res.pageframe().c_str();
      std::memmove(context->page_ptr, p, UNIV_PAGE_SIZE);
    }

    // on success
    context->success = true;

    byte* page_frame = static_cast<byte*>(context->page_ptr);
    lsn_t page_lsn = mach_read_from_8(page_frame + FIL_PAGE_LSN);
    ut_a(request->version_rule() == pspb::RbioRequest::GE ||
        page_lsn <= context->vlsn || srv_force_recovery >= 6);
    ut_a(res.has_vlsn());
    ut_a(page_lsn <= res.vlsn() || srv_force_recovery >= 6);

    if(!context->bpage) {
      break;
    }

    buf_page_t *bpage = static_cast<buf_page_t *>(context->bpage);
    buf_block_t *block = (buf_block_t *)bpage;
    ut_a(block->frame == page_frame);
    // update last_page_lsn
    bpage->last_page_lsn = mach_read_from_8(page_frame + FIL_PAGE_LSN);
    bpage->primary_read = srv_rpl_primary ? true : false;
    if (context->ref_redo_type) {
      ScopedLatencyRecorder delta_apply_lat(&rbio_delta_apply);
      ut_a(rpl::FLAGS_rpl_enable_delta_replay);
      int32_t ok = rpl::rbio_further_apply(context->ref_redo_type, context->refed_index,
                                           block, res.vlsn(), context->vlsn);
      if (ok < 0) {
        ut_a(res.vlsn() < context->vlsn);
        ut_a(res.vlsn() >= rpl::get_init_lsn());
        ut_a(request->has_version_rule());
        ut_a(request->version_rule() == page_server::RbioRequest_VersionRule_LE);
        need_reset_vlsn = true;
        context->success = false;
        break;
      } else if (ok > 0) {    // delta applied
        ut_a(res.vlsn() < context->vlsn);
        ut_a(res.vlsn() >= rpl::get_init_lsn());
        ut_a(request->has_version_rule());
        ut_a(request->version_rule() == page_server::RbioRequest_VersionRule_LE);
        ut_a(block->applied_lsn.load() >= context->vlsn);
        block->update_page_checksum();
        rbio_with_delta_apply << 1;
      } // else: page data not changed
    }
    block->update_applied_lsn(res.vlsn());
    if (request->has_version_rule() &&
        request->version_rule() !=
            ::page_server::RbioRequest_VersionRule_EQ) {
      LOG(TRACE) << "page: " << bpage->id
                  << ", rbio request vlsn: " << context->vlsn
                  << ", response vlsn: " << res.vlsn()
                  << ", page_lsn: " << bpage->last_page_lsn
                  << ", block_applied_lsn: " << block->applied_lsn.load();
    }
  } while (0);

  // bvar
  uint64_t now = base::monotonic_time_us();
  page_rbio_real << now - context->real_start_us;
  if (context->gaia_backup_ctx) {
    page_rbio_rpc << context->gaia_backup_ctx->latency_us();
    if (is_backup && context->gaia_backup_ctx->has_backup_request()) {
      rbio_with_backup_count << 1;
    }
  } else {
    page_rbio_rpc << context->cntl->latency_us();
    if (is_backup && context->cntl->has_backup_request()) {
      rbio_with_backup_count << 1;
    }
  }

  LOG(TRACE) << "RBIO sync_mode=sync"
    << " on request=" << context->request->requestid()
    << ", space_id:" << context->page_id.space()
    << ", page_no:" << context->page_id.page_no()
    << ", LSN:" << context->vlsn
    << ", page_server:" << remote_server
    << ", backup:" << is_backup
    << ", simple_rpc:" << context->simple_rpc
    << ", rc:" << (context->success ? " success" : " failed");

#ifdef UNIV_DEBUG
  static std::atomic<int32_t> read_fail_num {0};
  if (context->success) {
    read_fail_num.store(0);
  }
#endif

  if (context->success) {
    page_rbio_total << now - context->start_us;
    // for show engine innodb status
    rbio_count.fetch_add(1);
    rbio_time_sum.fetch_add(now - context->start_us);

    if (fsp_is_undo_tablespace(context->page_id.space())) {
      page_rbio_undo << now - context->start_us;
    } else if (context->purge_index_rbio && FLAGS_enable_purge_time_monitor) {
      purge_index_rbio << now - context->real_start_us;
    }

    if (context->page_id.space() == 0){
      space0_page_rbio_number << 1;
    }

    if (context->bpage && ibuf_bitmap_page(context->page_id,
          static_cast<buf_page_t *>(context->bpage)->size)) {
      ibuf_bitmap_page_rbio_number << 1;
    }

    page_on_handle_rbio << base::monotonic_time_us() - begin_time;
    async_handler(context);
    return;
  }

#ifdef UNIV_DEBUG
  if (read_fail_num.fetch_add(1) > 100) {
    /* in debug, maybe the page servers shutdown, finish mtr test */
    ut_error;
  }
#endif

  // on failed
  ut_a(context->success == false);
  page_rbio_errors << 1;

  // reset refer redo
  if (need_reset_vlsn) {
    rbio_with_reset_vlsn << 1;
    reset_vlsn(context);
  }

  ++context->retry_count;
  context->simple_rpc = FLAGS_rbio_enable_simple_rpc_client;
  context->use_polar = FLAGS_rbio_with_polar_client && gaiadb::polar::enable_polar();
  /*
   * Same cases to disable backup:
   * 1) the segment majority replicas are invalid, the normal replica is busy or return the expected error,
   *    but the backup will retry the next node, and the next node always return an error.
   **/
  context->use_backup = FLAGS_rbio_enable_backup && context->retry_count < kMaxRbioBackupCount;
  context->use_gaia_backup = FLAGS_rbio_enable_gaia_backup;

  if (!FLAGS_rbio_with_extent_offset && context->request->has_physical_extent_id()) {
    context->request->clear_physical_extent_id();
  }
  context->request->set_enable_attachment_type(FLAGS_rbio_enable_attachment_type_data);

  page_on_handle_rbio << base::monotonic_time_us() - begin_time;

  const bool failed = context->gaia_backup_ctx ? context->gaia_backup_ctx->Failed() : context->cntl->Failed();
  if (failed
      || context->response->errcode() == page_server::RbioResponse::RBIO_SEGMENT_NOT_EXIST
      || context->response->errcode() == page_server::RbioResponse::RBIO_SEGMENT_INACTIVE) {
    context->sync_segment = true;
    if (is_backup && !context->gaia_backup_ctx) {
      psm_client_->set_segment_rpc_backup_error_replica(context->segment_id,
          remote_server);
    }
  }

  if (context->retry_count % std::max(2lu, context->backup_servers.size()) == 0) {
    gaia::this_thread::sleep_for(std::chrono::microseconds(calc_rbio_sleep_us(context->retry_count)));
  }

  context->cntl->Reset();
  context->response->Clear();
  context->request->set_requestid(context->request->requestid());
  async_handler(context);
  return;
}

void RbioClient::reset_vlsn(RbioContext* context) {
  lsn_t rbio_lowest_lsn = 0;
  auto page = static_cast<buf_page_t *>(context->bpage);
  lsn_t vlsn = rbio_vlsn_get_for_secondary(page, &context->ref_redo_type,
                                           &context->refed_index,
                                           &rbio_lowest_lsn);
  context->vlsn = vlsn;
  page->set_vlsn(vlsn);

  auto request = context->request;
  page_server::RbioRequest::RequestInfo *rbio_req = request->mutable_reqvec(0);
  rbio_req->set_vlsn(vlsn);

  if (context->ref_redo_type) {
    request->set_version_rule(page_server::RbioRequest_VersionRule_LE);
    rbio_req->set_lowest_lsn(rbio_lowest_lsn);
  } else {
    request->set_version_rule(page_server::RbioRequest_VersionRule_EQ);
  }
  request->set_fetch_lsn(rpl::get_fetch_lsn());
  request->set_ls_dispatch_lsn(rpl::get_ls_dispatch_lsn());
}

int RbioClient::io_submit(gaia::AIO_cb *aio_cb) {
  if (gaia::aio_executers_succ) {
    ut_a(aio_cb);
    return gaia::aio_executors.submit(aio_cb) ? 0 : 1;
  }
  return -1;
}

/** get a single page from page-server
@param[in]  type            request: rbio request type
param[in] ignore_ahead_fail ignore read ahead fail
@return DB_SUCCESS or error number
*/
dberr_t RbioClient::get_page(const page_id_t &page_id, void *page_ptr,
                             void *bpage, bool skip_delta_replay, bool purge_index_rbio,
                             gaia::AIO_cb *aio_cb
#ifdef ENABLED_GAIADB_PAGE_VALIDATION
                             , lsn_t vlsn_p
#endif /* ENABLED_GAIADB_PAGE_VALIDATION */
) {
  RbioContext *context = new RbioContext();
  brpc::Controller *cntl = new brpc::Controller;
  page_server::RbioRequest *request = new page_server::RbioRequest;
  page_server::RbioResponse *response = new page_server::RbioResponse;

  context->page_id.reset(page_id.space(), page_id.page_no());
  context->cntl = cntl;
  context->request = request;
  context->response = response;

  context->start_us = base::monotonic_time_us();
  context->page_ptr = page_ptr;
  context->purge_index_rbio = purge_index_rbio;

  context->aio_cb = aio_cb;

  lsn_t rbio_lowest_lsn = 0;
  bool use_version_rule_ge = false;
  lsn_t vlsn = 0;
  buf_page_t *page = static_cast<buf_page_t *>(bpage);
#ifdef ENABLED_GAIADB_PAGE_VALIDATION
  if (vlsn_p != 0) {
    vlsn = vlsn_p;
  } else {
#endif /* ENABLED_GAIADB_PAGE_VALIDATION */
    ut_a(bpage);
    vlsn = srv_rpl_primary
               ? rbio_vlsn_get_for_primary(page, &use_version_rule_ge)
               : rbio_vlsn_get_for_secondary(page, &context->ref_redo_type,
                                             &context->refed_index,
                                             &rbio_lowest_lsn);
    page->set_vlsn(vlsn);
#ifdef ENABLED_GAIADB_PAGE_VALIDATION
  }
#else
  ((buf_block_t*)bpage)->applied_lsn.store(0);
#endif /* ENABLED_GAIADB_PAGE_VALIDATION */

  context->bpage = page;
  context->vlsn = vlsn;

  page_server::RbioRequest::RequestInfo *rbio_req = request->add_reqvec();
  rbio_req->set_tablespaceid(page_id.space());
  rbio_req->set_logicalpageno(page_id.page_no());
  rbio_req->set_vlsn(vlsn);
  rbio_req->set_ziplen(UNIV_PAGE_SIZE);

  // Tell page server how many error codes we support
  request->set_max_error_code((uint32_t)page_server::RbioResponse::RBIO_SERVER_ERROR);
  request->set_n(1);
  request->set_requestid(rpc_log_id_.fetch_add(1));
  request->set_readtype(page_server::RbioRequest_Type_READ_SYNC);

  if (rpl::FLAGS_rpl_enable_delta_replay && !srv_rpl_primary &&
      context->ref_redo_type &&
      rpl::get_init_finished() &&
      !skip_delta_replay) {
    request->set_version_rule(page_server::RbioRequest_VersionRule_LE);
    rbio_with_le_count << 1;
    /* rbio_lowest_lsn:
     * we need to ensure that ps parse_lsn more than this value.
     * if we enable lowest gc lsn feature,
     *  some ps slow nodes are not in lowest gc lsn view (but in lowest lsn view).
     */
    rbio_req->set_lowest_lsn(rbio_lowest_lsn);
  } else if (use_version_rule_ge) {
    request->set_version_rule(page_server::RbioRequest_VersionRule_GE);
  } else {
    request->set_version_rule(page_server::RbioRequest_VersionRule_EQ);
  }
  request->set_fetch_lsn(rpl::get_fetch_lsn());
  request->set_ls_dispatch_lsn(rpl::get_ls_dispatch_lsn());

  const std::string& cluster_id = psm_client_->get_cluster_id();
  uint32_t extent_no = extent_no_get(page_id.space(), page_id.page_no());
  gaiadb::common::segment_t segment_id = 0;
  gaiadb::common::segment_t physical_extent_id = 0;
  dberr_t err =
      get_segment_id(page_id.space(), extent_no, segment_id, physical_extent_id);
  if (err == DB_OUT_OF_FILE_SPACE) {
    LOG(ERROR) << "RBIO request invalid page, spage_id:" << page_id.space()
               << ", page_no:" << page_id.page_no();
    ut_error;
  }
  ut_a(err == DB_SUCCESS);

  context->segment_id = segment_id;

  request->set_cluster_id(cluster_id);
  request->set_segment_id(segment_id);
  if (FLAGS_rbio_with_extent_offset) {
      request->set_physical_extent_id(physical_extent_id);
  }
  request->set_is_primary(srv_rpl_primary);
  request->set_enable_attachment_type(FLAGS_rbio_enable_attachment_type_data);

  return get_page_low(context);
}

dberr_t RbioClient::get_page_low(RbioContext* context) {
  context->simple_rpc = FLAGS_rbio_enable_simple_rpc_client;
  context->use_polar = FLAGS_rbio_with_polar_client && gaiadb::polar::enable_polar();
  context->use_backup = FLAGS_rbio_enable_backup;
  context->use_gaia_backup = FLAGS_rbio_enable_gaia_backup;

  const bool is_aio = context->aio_cb;

  dberr_t err = DB_ERROR_UNSET;
  while (!stopped_) {
    if (context->use_gaia_backup) {
      err = get_page_by_gaia_backup(context);
      if (err == DB_SUCCESS || err == DB_TABLESPACE_NOT_FOUND) {
        break;
      }
      context->use_gaia_backup = false;
    }

    if (context->use_backup) {
      err = get_page_by_brpc_backup(context);
      if (err == DB_SUCCESS || err == DB_TABLESPACE_NOT_FOUND) {
        break;
      }
      context->use_backup = false;
    }

    err = get_page_by_brpc(context);
    if (err == DB_SUCCESS || err == DB_TABLESPACE_NOT_FOUND) {
      break;
    }
  }
  if (!is_aio) {
    delete context;
  }
  return err;
}

dberr_t RbioClient::get_segment_id(uint32_t space_id, uint32_t logical_extent_id,
                                   uint32_t &segment_id, uint32_t &physical_extent_id) {
  int32_t ret = 0;
  do {  // get segment_id, return error if space already deleted or retry
        // infinitely with other errors
    ret = psm_client_->get_segment_id_and_extent_id(space_id, logical_extent_id,
                &segment_id, &physical_extent_id);
    if (ret == 0 && segment_id > 0) {
      break;
    }
    if (ret == gaiadb::GIE_SPACE_NOT_EXIST) {
      LOG(WARNING) << "RBIO on deleted space: " << space_id;
      return DB_TABLESPACE_NOT_FOUND;
    }
    if (ret == gaiadb::GIE_NOT_EXIST) {
      LOG(WARNING) << "RBIO on invalid extent: " << logical_extent_id;
      return DB_OUT_OF_FILE_SPACE;
    }
    gaia::this_thread::sleep_for(std::chrono::microseconds(1000));
    LOG_IF_EVERY_N(ERROR, ret != 0, 100)
        << "RBIO get_segment_id failed, space" << space_id
        << ", pace_no: " << logical_extent_id;
  } while (ret != 0);

  return DB_SUCCESS;
}

dberr_t RbioClient::get_segment_replicas(
    uint32_t segment_id, std::vector<gaiadb::common::PeerZone> &segment_replicas,
    bool force_sync) {
  bool sync_mode = force_sync ? true : false;
  int ret = 0;
  const uint32_t zone_version = psm_client_->zone_version();
  if (last_zone_version_ != zone_version) {
    last_zone_version_ = zone_version;
    force_sync = true;
  }
  do {  // get segment_replicas, return error if
        // space already deleted, retry infinitely with
        // other errors
    segment_replicas.clear();
    ret = psm_client_->get_segment_replicas(segment_id, &segment_replicas, sync_mode);
    if (ret == 0 && segment_replicas.size() > 0) {
      std::random_shuffle(segment_replicas.begin(), segment_replicas.end(), base::fast_rand_less_than);
      if (psm_client_->has_zone()) {
        std::string region;
        std::string available_zone;
        if (psm_client_->get_zone(&region, &available_zone)
            && !region.empty() && !available_zone.empty()) {
          gaiadb::common::sort_peer_zone_vector(segment_replicas, region, available_zone);
        }
      }
      break;
    }
    if (sync_mode &&
        ret == gaiadb::GIE_NOT_EXIST) {
      ut_a(false);  // unexpected error
    }

    sync_mode = true;
    gaia::this_thread::sleep_for(std::chrono::microseconds(1000));

    LOG_IF_EVERY_N(ERROR, ret != 0 || segment_replicas.size() == 0, 100)
        << "RBIO get_segment_replica failed, segment_id: " << segment_id
        << ", ret: " << ret;
  } while (ret != 0 || segment_replicas.size() == 0);
  return DB_SUCCESS;
}
