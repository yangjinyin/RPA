/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_append_file.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include "test/test_common.h"
#include "test/mock_append_block.h"
#include "psvr/append_file.h"
#include "bmock.h"

namespace psvr {
namespace test {

class AppendDBEngineTests : public PsvrTest {
 public:
    AppendDBEngineTests() {
        _buf_pool.reset(new BufPool());
        _buf_pool->_slice_size = 16384;
        //_dir = std::filesystem::temp_directory_path();
        _dir = std::filesystem::current_path();
        gaiadb::common::ut_crc32_init();
        FLAGS_psvr_append_file_block_size = 64 << 20;
    }
    virtual ~AppendDBEngineTests() {}

    void SetUp() {
        FLAGS_psvr_append_fix_footer_backward_scan = false;
        FLAGS_psvr_append_fix_footer_backward_scan_min_file_size = 0;
        FLAGS_psvr_append_merge_max_buf_size = 1UL << 20;
        FLAGS_psvr_append_fix_footer_max_truncate_size = 4UL << 20;
        FLAGS_psvr_append_seek_anchor_chunk_size = 8UL << 20;
        _append_db.reset(new AppendDBEngine);
        LOG(NOTICE) << "test path:" << _dir / "psvr_test/";
        std::filesystem::create_directory(_dir / "psvr_test/");
        ASSERT_TRUE(std::filesystem::exists(_dir / "psvr_test/"));
        _data_path = _dir / "psvr_test";
    }

    void TearDown() {
        FLAGS_psvr_append_fix_footer_backward_scan = false;
        FLAGS_psvr_append_fix_footer_backward_scan_min_file_size = 16UL << 20;
        FLAGS_psvr_append_merge_max_buf_size = 1UL << 20;
        FLAGS_psvr_append_fix_footer_max_truncate_size = 4UL << 20;
        FLAGS_psvr_append_seek_anchor_chunk_size = 8UL << 20;
        std::filesystem::remove_all(_dir / "psvr_test/");
    }

    void Reset() {
        _append_db->Clear();
        _append_db->_disable = 1;
    }

    std::shared_ptr<db::Block> CreateDB(uint64_t id, uint64_t start_lsn, bool tmp = false) {
        std::string block_file_name = base::string_printf("%s/db/%lu%s", _data_path.c_str(), id, ".db");
        if (tmp) {
            block_file_name.append("123");
        }
        auto block = std::make_shared<db::Block>(block_file_name, id);
        auto st = block->Open(start_lsn);
        LOG(NOTICE) << "create db:" << id << ", " << st;
        return block;

    }

    void CreateAppendLog(LogBlockPtr log_block, db::LogHeader* header, base::Slice* key, base::Slice* value) {
        header->magic = db::kLogHeaderMagic;
        header->proto_version = db::kLogHeaderVserion;
        header->start_lsn = log_block->start_lsn;
        header->end_lsn = log_block->end_lsn;
        header->buf_crc = log_block->buf_crc;
        header->records_count = log_block->records_count;
        header->fetch_from_ip = base::ip2int(log_block->fetch_from.ip);
        header->fetch_from_port = log_block->fetch_from.port;

        size_t align_fold_size = 0;
        std::set<fold_space_page_t> fold_space_align_pages;
        for (auto& it : log_block->fold_space_page_lsn_map) {
            const auto& fold = it.first;
            if (fold_space_align_pages.emplace(fold_space_page_align(fold)).second) {
                ++align_fold_size;
            }
        }
        uint32_t extern_id = 0;
        log_block->fold_space_page_offset_cache.Init(align_fold_size);
        for (auto& it : fold_space_align_pages) {
            log_block->fold_space_page_offset_cache.Add(fold_space_page_to_key(it), ++extern_id);
        }

        auto& offset_cache = log_block->fold_space_page_offset_cache;
        header->fold_size = offset_cache.size();

        *key = base::Slice(static_cast<const char*>(offset_cache.buf()), offset_cache.buf_size());
        *value = base::Slice(reinterpret_cast<const char*>(log_block->buf), log_block->buf_size);

        header->key_crc = db::get_crc(reinterpret_cast<const void*>(key->data()), key->size());
        header->key_size = key->size();
        header->value_size = value->size();

        db::make_checksum(header, db::kLogHeaderSize);
    }

    void AppendLog(std::shared_ptr<db::Block> block, LogBlockPtr log_block) {
        db::LogHeader header;
        base::Slice key;
        base::Slice value;

        CreateAppendLog(log_block, &header, &key, &value);

        base::Slice header2(reinterpret_cast<const char*>(&header), db::kLogHeaderSize);
        size_t write_size = header2.size() + key.size() + value.size();

        struct iovec iov[3];
        iov[0].iov_base = const_cast<void*>(reinterpret_cast<const void*>(header2.data()));
        iov[0].iov_len = header2.size();
        iov[1].iov_base = const_cast<void*>(reinterpret_cast<const void*>(key.data()));
        iov[1].iov_len = key.size();
        iov[2].iov_base = const_cast<void*>(reinterpret_cast<const void*>(value.data()));
        iov[2].iov_len = value.size();

        uint64_t fno, off;
        auto st = block->Append(iov, 3, write_size, header.start_lsn, header.end_lsn, &fno, &off, false);
        LOG(NOTICE) << "db:" << block->file_no() << " append log, " << st;
    }

    uint64_t AppendLogWithOff(std::shared_ptr<db::Block> block, LogBlockPtr log_block) {
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(log_block, &header, &key, &value);

        base::Slice header2(reinterpret_cast<const char*>(&header), db::kLogHeaderSize);
        size_t write_size = header2.size() + key.size() + value.size();

        struct iovec iov[3];
        iov[0].iov_base = const_cast<void*>(reinterpret_cast<const void*>(header2.data()));
        iov[0].iov_len = header2.size();
        iov[1].iov_base = const_cast<void*>(reinterpret_cast<const void*>(key.data()));
        iov[1].iov_len = key.size();
        iov[2].iov_base = const_cast<void*>(reinterpret_cast<const void*>(value.data()));
        iov[2].iov_len = value.size();

        uint64_t fno = 0;
        uint64_t off = 0;
        auto st = block->Append(iov, 3, write_size, header.start_lsn, header.end_lsn,
                &fno, &off, false);
        EXPECT_TRUE(st.IsOk()) << st;
        return off;
    }

    void BuildSealedBlock(uint32_t record_num, uint64_t start_lsn,
            std::vector<uint64_t>* starts, std::vector<uint64_t>* offs) {
        std::filesystem::create_directory(_dir / "psvr_test/db");
        auto block = CreateDB(1, start_lsn);
        uint64_t lsn = start_lsn;
        for (uint32_t i = 0; i < record_num; ++i) {
            auto lb = create_log_block(lsn, lsn + 10, true, 0, false, 200 << 10);
            offs->push_back(AppendLogWithOff(block, lb));
            starts->push_back(lsn);
            lsn += 10;
        }
        ASSERT_TRUE(block->Sync(true).IsOk());
        ASSERT_TRUE(block->Close().IsOk());
    }

    db::BlockFooter ReadFooter(const std::string& path, uint64_t file_size) {
        db::BlockFooter footer;
        int fd = open(path.c_str(), O_RDONLY);
        EXPECT_GE(fd, 0);
        if (fd < 0) {
            footer.magic = 0;
            return footer;
        }
        auto st = db::preadx(fd, &footer, db::kBlockFooterSize,
                file_size - db::kBlockFooterSize);
        EXPECT_TRUE(st.IsOk());
        if (!st.IsOk()) {
            footer.magic = 0;
        }
        close(fd);
        return footer;
    }

    db::LogHeader MakeBogusHeader() {
        db::LogHeader bogus;
        bogus.magic = db::kLogHeaderMagic;
        bogus.proto_version = 0;
        bogus.start_lsn = 1256;
        bogus.end_lsn = 1280;
        bogus.key_crc = 0;
        bogus.buf_crc = 0;
        bogus.records_count = 0;
        bogus.fetch_from_ip = 0;
        bogus.fetch_from_port = 0;
        bogus.fold_size = 0;
        bogus.key_size = 0;
        bogus.value_size = 0;
        bogus.checksum = 0;
        if (db::get_crc(&bogus, db::kLogHeaderSize - sizeof(bogus.checksum)) == 0) {
            bogus.checksum = 1;
        }
        return bogus;
    }

    void CheckLastLog(const AppendDBEngine::RandomAccessBlockPtr& rblock,
            bool expect_found, bool expect_safe, uint64_t expect_end_lsn) {
        bool found = false;
        bool safe = false;
        uint64_t record_off = 0;
        db::LogHeader header;
        auto st = _append_db->FindLastCompleteLog(rblock, rblock->file_size(),
                rblock->start_lsn(), &found, &safe, &record_off, &header);
        EXPECT_TRUE(st.IsOk());
        EXPECT_EQ(found, expect_found);
        EXPECT_EQ(safe, expect_safe);
        if (expect_found) {
            EXPECT_EQ(header.end_lsn, expect_end_lsn);
        }
    }

    void CorruptHeader(const std::string& path, uint64_t off) {
        char zero[db::kLogHeaderSize] = {};
        int fd = open(path.c_str(), O_WRONLY);
        ASSERT_GE(fd, 0);
        auto st = db::pwritex(fd, zero, sizeof(zero), off);
        ASSERT_TRUE(st.IsOk());
        close(fd);
    }

    void CorruptValue(const std::string& path, uint64_t off) {
        db::LogHeader header;
        int fd = open(path.c_str(), O_RDWR);
        ASSERT_GE(fd, 0);
        auto st = db::preadx(fd, &header, db::kLogHeaderSize, off);
        ASSERT_TRUE(st.IsOk());
        const uint64_t value_off = off + db::kLogHeaderSize + header.key_size;
        char value = 0;
        st = db::preadx(fd, &value, sizeof(value), value_off);
        ASSERT_TRUE(st.IsOk());
        value ^= 0xff;
        st = db::pwritex(fd, &value, sizeof(value), value_off);
        ASSERT_TRUE(st.IsOk());
        close(fd);
    }

private:
    BufPoolPtr _buf_pool;
    std::filesystem::path _dir;
    std::shared_ptr<AppendDBEngine> _append_db;
    std::string _data_path;
};

TEST_F(AppendDBEngineTests, test_validate_append_redo_block) {
    const std::string key_data = "offset-cache";
    const std::string value_data = "redo-data";
    const base::Slice key(key_data);
    const base::Slice value(value_data);

    db::LogHeader log_header;
    log_header.magic = db::kLogHeaderMagic;
    log_header.proto_version = db::kLogHeaderVserion;
    log_header.start_lsn = 1000;
    log_header.end_lsn = 2000;
    log_header.key_crc = db::get_crc(
            reinterpret_cast<const void*>(key.data()), key.size());
    log_header.buf_crc = db::get_crc(
            reinterpret_cast<const void*>(value.data()), value.size());
    db::make_checksum(&log_header, db::kLogHeaderSize);

    ASSERT_TRUE(validate_append_redo_block(log_header, key, value).IsOk());

    auto invalid_header = log_header;
    ++invalid_header.checksum;
    ASSERT_EQ(validate_append_redo_block(invalid_header, key, value).code,
            db::Code::kCorrupted);

    auto invalid_key = log_header;
    ++invalid_key.key_crc;
    db::make_checksum(&invalid_key, db::kLogHeaderSize);
    ASSERT_EQ(validate_append_redo_block(invalid_key, key, value).code,
            db::Code::kCorrupted);

    auto invalid_value = log_header;
    ++invalid_value.buf_crc;
    db::make_checksum(&invalid_value, db::kLogHeaderSize);
    ASSERT_EQ(validate_append_redo_block(invalid_value, key, value).code,
            db::Code::kCorrupted);

    db::LogHeader empty_header;
    empty_header.magic = db::kLogHeaderMagic;
    empty_header.proto_version = db::kLogHeaderVserion;
    empty_header.key_crc = db::get_crc(nullptr, 0);
    empty_header.buf_crc = db::get_crc(nullptr, 0);
    db::make_checksum(&empty_header, db::kLogHeaderSize);
    ASSERT_TRUE(validate_append_redo_block(
            empty_header, base::Slice(), base::Slice()).IsOk());

    END_OF_CASE;
}


TEST_F(AppendDBEngineTests, test_Open) {
    gaia_apply::lsn_t checkpoint_lsn, max_apply_lsn;
    {
        // is open
        _append_db->_block_no = 1;
        auto st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
        std::cout << st << std::endl;
        _append_db->_block_no = 0;
        ASSERT_TRUE(st.IsOk());
    } END_OF_CASE;
    {
        std::filesystem::create_directory(_dir / "psvr_test/db");
        std::filesystem::create_directory(_dir / "psvr_test/db/dir");
        CreateDB(1, 1234, true);
        CreateDB(1, 1234);
        atomic_write_file(_dir / "psvr_test/db/a.db", "", true);
        auto st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
        std::cout << st << std::endl;
        ASSERT_TRUE(st.IsInvalid());
        std::filesystem::remove_all(_dir / "psvr_test/db");
    } END_OF_CASE;
    {
        std::filesystem::create_directory(_dir / "psvr_test/db");
        auto b1= CreateDB(1, 1234);
        AppendLog(b1, create_empty_log_block(1234, 1240, true));
        b1->Close();
        auto b2 = CreateDB(2, 1240);
        auto st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
        std::cout << st << std::endl;
        ASSERT_TRUE(st.IsOk());
        std::filesystem::remove_all(_dir / "psvr_test/db");
    } END_OF_CASE;
    {
        Reset();
        std::filesystem::create_directory(_dir / "psvr_test/db");
        CreateDB(1, 1234);
        auto b2 = CreateDB(2, 1234);
        AppendLog(b2, create_empty_log_block(1234, 1560, true));
        auto st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
        std::cout << st << std::endl;
        ASSERT_TRUE(st.IsOk());
        std::filesystem::remove_all(_dir / "psvr_test/db");
    } END_OF_CASE;
    {
        auto st = _append_db->Close(false);
        ASSERT_TRUE(st.IsOk());
        st = _append_db->Close();
        ASSERT_TRUE(st.IsOk());
    } END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock) {
    {
        // truncate  header
        Reset();
        std::filesystem::create_directory(_dir / "psvr_test/db");
        _append_db->_data_path = _dir / "psvr_test/db";
        auto b1 = CreateDB(1, 1234);
        AppendDBEngine::RandomAccessBlockPtr rb1;
        auto st = _append_db->NewRandomAccessBlock(1, 1234, &rb1);
        std::cout << st << std::endl;
        ASSERT_TRUE(st.IsOk());
        st = _append_db->TryFixBlock(rb1);
        std::cout << st << std::endl;
        ASSERT_TRUE(st.IsEmpty());
        std::filesystem::remove_all(_dir / "psvr_test/db");
    } END_OF_CASE;
    {
        // append log
        Reset(); std::filesystem::create_directory(_dir / "psvr_test/db");
        _append_db->_data_path = _dir / "psvr_test/db";
        auto b1 = CreateDB(1, 1234);
        AppendLog(b1, create_log_block(1234, 1256, true));

        AppendDBEngine::RandomAccessBlockPtr rb1;
        auto st = _append_db->NewRandomAccessBlock(1, 0, &rb1);
        std::cout << st << std::endl;
        ASSERT_TRUE(st.IsOk());
        st = _append_db->TryFixBlock(rb1);
        std::cout << st << std::endl;
        ASSERT_TRUE(st.IsOk());
        std::filesystem::remove_all(_dir / "psvr_test/db");
    } END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_torn_tail) {
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1234);
    auto lb1 = create_log_block(1234, 1256, true);
    AppendLog(block, lb1);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t first_size = std::filesystem::file_size(path);

    auto lb2 = create_log_block(1256, 1280, true);
    AppendLog(block, lb2);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const uint64_t second_size = std::filesystem::file_size(path);
    ASSERT_GT(second_size, first_size);
    ASSERT_TRUE(block->Close().IsOk());

    std::filesystem::resize_file(path, first_size + 10);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    ASSERT_EQ(rblock->file_size(), first_size + 10);

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsOk());
    ASSERT_EQ(rblock->end_lsn(), lb1->end_lsn);
    ASSERT_EQ(rblock->file_size(), first_size + db::kBlockFooterSize);

    auto footer = ReadFooter(path, rblock->file_size());
    ASSERT_EQ(footer.magic, db::kBlockFooterMagic);
    ASSERT_FALSE(db::check_is_corrupt(footer, db::kBlockFooterSize));
    ASSERT_EQ(footer.start_lsn, 1234);
    ASSERT_EQ(footer.end_lsn, lb1->end_lsn);
    ASSERT_EQ(footer.last_start_lsn, lb1->start_lsn);
    ASSERT_EQ(footer.file_size, rblock->file_size());

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_incomplete_first_log) {
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1234);
    auto lb1 = create_log_block(1234, 1256, true);
    AppendLog(block, lb1);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    ASSERT_GT(std::filesystem::file_size(path), db::kBlockHeaderSize + 10);
    ASSERT_TRUE(block->Close().IsOk());

    std::filesystem::resize_file(path, db::kBlockHeaderSize + 10);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsEmpty());
    ASSERT_EQ(rblock->end_lsn(), 1234);
    ASSERT_EQ(rblock->file_size(), 0);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_record_larger_than_scan_chunk) {
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1234);
    auto lb1 = create_log_block(1234, 1256, true);
    AppendLog(block, lb1);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t first_size = std::filesystem::file_size(path);

    auto lb2 = create_log_block(1256, 1280, true, 0, true, 5 << 20);
    AppendLog(block, lb2);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const uint64_t second_size = std::filesystem::file_size(path);
    ASSERT_GT(second_size - first_size, 4UL << 20);
    ASSERT_TRUE(block->Close().IsOk());

    std::filesystem::resize_file(path, first_size + (1UL << 20));

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsOk());
    ASSERT_EQ(rblock->end_lsn(), lb1->end_lsn);
    ASSERT_EQ(rblock->file_size(), first_size + db::kBlockFooterSize);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_backward_scan_record_larger_than_chunk) {
    FLAGS_psvr_append_fix_footer_backward_scan = true;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1234);
    auto lb1 = create_log_block(1234, 1256, true);
    AppendLog(block, lb1);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t first_size = std::filesystem::file_size(path);

    auto lb2 = create_log_block(1256, 1280, true, 0, true, 5 << 20);
    AppendLog(block, lb2);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const uint64_t second_size = std::filesystem::file_size(path);
    ASSERT_GT(second_size - first_size, 4UL << 20);
    ASSERT_TRUE(block->Close().IsOk());

    std::filesystem::resize_file(path, first_size + (1UL << 20));

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsOk());
    ASSERT_EQ(rblock->end_lsn(), lb1->end_lsn);
    ASSERT_EQ(rblock->file_size(), first_size + db::kBlockFooterSize);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_backward_scan_unsafe_fallback) {
    FLAGS_psvr_append_fix_footer_backward_scan = true;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1234);
    auto lb1 = create_log_block(1234, 1256, true);
    AppendLog(block, lb1);
    auto lb2 = create_log_block(1256, 1280, true);
    AppendLog(block, lb2);
    auto lb3 = create_log_block(1280, 1304, true);
    AppendLog(block, lb3);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t data_size = std::filesystem::file_size(path);
    ASSERT_TRUE(block->Close().IsOk());
    std::filesystem::resize_file(path, data_size);

    char corrupt[db::kLogHeaderSize] = {};
    int fd = open(path.c_str(), O_WRONLY);
    ASSERT_GE(fd, 0);
    auto st = db::pwritex(fd, corrupt, sizeof(corrupt), db::kBlockHeaderSize);
    ASSERT_TRUE(st.IsOk());
    close(fd);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsEmpty());
    ASSERT_EQ(rblock->end_lsn(), 1234);
    ASSERT_EQ(rblock->file_size(), 0);
    ASSERT_EQ(std::filesystem::file_size(path), 0);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_backward_scan_unsafe_exceed_max_truncate) {
    FLAGS_psvr_append_fix_footer_backward_scan = true;
    FLAGS_psvr_append_fix_footer_max_truncate_size = 64;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1234);
    auto lb1 = create_log_block(1234, 1256, true);
    AppendLog(block, lb1);
    auto lb2 = create_log_block(1256, 1280, true);
    AppendLog(block, lb2);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t data_size = std::filesystem::file_size(path);
    ASSERT_TRUE(block->Close().IsOk());
    std::filesystem::resize_file(path, data_size);
    CorruptHeader(path, db::kBlockHeaderSize);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsCorrupted());
    ASSERT_EQ(rblock->file_size(), data_size);
    ASSERT_EQ(std::filesystem::file_size(path), data_size);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_wipe_exceed_max_truncate) {
    FLAGS_psvr_append_fix_footer_backward_scan = true;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1234);
    auto lb1 = create_log_block(1234, 1256, true);
    AppendLog(block, lb1);
    auto lb2 = create_log_block(1256, 1280, true);
    AppendLog(block, lb2);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t data_size = std::filesystem::file_size(path);
    ASSERT_TRUE(block->Close().IsOk());
    std::filesystem::resize_file(path, data_size);
    CorruptHeader(path, db::kBlockHeaderSize);
    FLAGS_psvr_append_fix_footer_max_truncate_size = data_size - 1;

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsCorrupted());
    ASSERT_EQ(rblock->file_size(), data_size);
    ASSERT_EQ(std::filesystem::file_size(path), data_size);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_Ax_torn_tail) {
    FLAGS_psvr_append_merge_max_buf_size = 64 << 10;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);
    auto a1 = create_log_block(1000, 1010, true, 0, true, 1024);
    AppendLog(block, a1);
    auto a2 = create_log_block(1010, 1020, true, 0, true, 1024);
    AppendLog(block, a2);
    auto a3 = create_log_block(1020, 1030, true, 0, true, 1024);
    const uint64_t a3_off = std::filesystem::file_size(block->file_name());
    AppendLog(block, a3);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    ASSERT_TRUE(block->Close().IsOk());
    std::filesystem::resize_file(path, a3_off + 10);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, true, true, a2->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_B) {
    FLAGS_psvr_append_merge_max_buf_size = 64 << 10;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);
    auto b = create_log_block(1000, 1010, true, 0, true, 256 << 10);
    AppendLog(block, b);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t data_size = std::filesystem::file_size(path);
    ASSERT_TRUE(block->Close().IsOk());
    std::filesystem::resize_file(path, data_size);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, true, true, b->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_B_torn) {
    FLAGS_psvr_append_merge_max_buf_size = 64 << 10;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);
    auto b = create_log_block(1000, 1010, true, 0, true, 256 << 10);
    const uint64_t b_off = std::filesystem::file_size(block->file_name());
    AppendLog(block, b);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    ASSERT_TRUE(block->Close().IsOk());
    std::filesystem::resize_file(path, b_off + 10);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, false, false, 0);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_Ax_plus_B) {
    FLAGS_psvr_append_merge_max_buf_size = 64 << 10;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);
    auto a1 = create_log_block(1000, 1010, true, 0, true, 1024);
    AppendLog(block, a1);
    auto a2 = create_log_block(1010, 1020, true, 0, true, 1024);
    AppendLog(block, a2);
    auto a3 = create_log_block(1020, 1030, true, 0, true, 1024);
    AppendLog(block, a3);
    auto b = create_log_block(1030, 1040, true, 0, true, 256 << 10);
    AppendLog(block, b);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t data_size = std::filesystem::file_size(path);
    ASSERT_TRUE(block->Close().IsOk());
    std::filesystem::resize_file(path, data_size);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, true, true, b->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_Ax_plus_B_torn) {
    FLAGS_psvr_append_merge_max_buf_size = 64 << 10;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);
    auto a1 = create_log_block(1000, 1010, true, 0, true, 1024);
    AppendLog(block, a1);
    auto a2 = create_log_block(1010, 1020, true, 0, true, 1024);
    AppendLog(block, a2);
    auto a3 = create_log_block(1020, 1030, true, 0, true, 1024);
    AppendLog(block, a3);
    auto b = create_log_block(1030, 1040, true, 0, true, 256 << 10);
    const uint64_t b_off = std::filesystem::file_size(block->file_name());
    AppendLog(block, b);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    ASSERT_TRUE(block->Close().IsOk());
    std::filesystem::resize_file(path, b_off + 10);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, true, true, a3->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_Ax_plus_B_hole) {
    FLAGS_psvr_append_merge_max_buf_size = 64 << 10;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);
    auto a1 = create_log_block(1000, 1010, true, 0, true, 1024);
    AppendLog(block, a1);
    auto a2 = create_log_block(1010, 1020, true, 0, true, 1024);
    AppendLog(block, a2);
    auto a3 = create_log_block(1020, 1030, true, 0, true, 1024);
    AppendLog(block, a3);
    auto b = create_log_block(1030, 1040, true, 0, true, 256 << 10);
    AppendLog(block, b);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t data_size = std::filesystem::file_size(path);
    ASSERT_TRUE(block->Close().IsOk());
    std::filesystem::resize_file(path, data_size);

    char zero[db::kLogHeaderSize] = {};
    int fd = open(path.c_str(), O_WRONLY);
    ASSERT_GE(fd, 0);
    auto st = db::pwritex(fd, zero, sizeof(zero), db::kBlockHeaderSize);
    ASSERT_TRUE(st.IsOk());
    close(fd);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, true, false, b->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_hole_after_anchor) {
    FLAGS_psvr_append_merge_max_buf_size = 64 << 10;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);
    auto a1 = create_log_block(1000, 1010, true, 0, true, 1024);
    AppendLog(block, a1);
    auto a2 = create_log_block(1010, 1020, true, 0, true, 1024);
    AppendLog(block, a2);
    auto a3 = create_log_block(1020, 1030, true, 0, true, 1024);
    const uint64_t a3_off = std::filesystem::file_size(block->file_name());
    AppendLog(block, a3);
    auto a4 = create_log_block(1030, 1040, true, 0, true, 1024);
    AppendLog(block, a4);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    ASSERT_TRUE(block->Close().IsOk());
    CorruptHeader(path, a3_off);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, true, true, a2->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_hole_before_anchor) {
    FLAGS_psvr_append_merge_max_buf_size = 64 << 10;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);
    auto a1 = create_log_block(1000, 1010, true, 0, true, 1024);
    AppendLog(block, a1);
    auto a2 = create_log_block(1010, 1020, true, 0, true, 1024);
    AppendLog(block, a2);
    auto a3 = create_log_block(1020, 1030, true, 0, true, 1024);
    AppendLog(block, a3);
    auto a4 = create_log_block(1030, 1040, true, 0, true, 1024);
    AppendLog(block, a4);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    ASSERT_TRUE(block->Close().IsOk());
    CorruptHeader(path, db::kBlockHeaderSize);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, true, false, a4->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_payload_hole_before_anchor) {
    FLAGS_psvr_append_merge_max_buf_size = 64 << 10;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);
    auto a1 = create_log_block(1000, 1010, true, 0, true, 1024);
    AppendLog(block, a1);
    auto a2 = create_log_block(1010, 1020, true, 0, true, 1024);
    AppendLog(block, a2);
    auto a3 = create_log_block(1020, 1030, true, 0, true, 1024);
    AppendLog(block, a3);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    ASSERT_TRUE(block->Close().IsOk());
    CorruptValue(path, db::kBlockHeaderSize);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, true, false, a3->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_payload_hole_after_anchor) {
    FLAGS_psvr_append_merge_max_buf_size = 64 << 10;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);
    auto a1 = create_log_block(1000, 1010, true, 0, true, 1024);
    AppendLog(block, a1);
    auto a2 = create_log_block(1010, 1020, true, 0, true, 1024);
    const uint64_t a2_off = std::filesystem::file_size(block->file_name());
    AppendLog(block, a2);
    auto a3 = create_log_block(1020, 1030, true, 0, true, 1024);
    AppendLog(block, a3);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    ASSERT_TRUE(block->Close().IsOk());
    CorruptValue(path, a2_off);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, true, true, a1->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_backward_multi_step) {
    FLAGS_psvr_append_merge_max_buf_size = 512;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);

    LogBlockPtr last_complete;
    const uint32_t record_num = 200;
    for (uint32_t i = 0; i < record_num; ++i) {
        const uint64_t start_lsn = 1000 + static_cast<uint64_t>(i) * 10;
        auto lb = create_log_block(start_lsn, start_lsn + 10, true, 0, true, 0);
        AppendLog(block, lb);
        last_complete = lb;
    }

    const uint64_t torn_start_lsn = 1000 + static_cast<uint64_t>(record_num) * 10;
    auto torn = create_log_block(torn_start_lsn, torn_start_lsn + 10, true, 0, true, 0);
    const uint64_t torn_off = std::filesystem::file_size(block->file_name());
    AppendLog(block, torn);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    ASSERT_TRUE(block->Close().IsOk());
    std::filesystem::resize_file(path, torn_off + 10);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, true, true, last_complete->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_backward_bogus_candidate) {
    FLAGS_psvr_append_merge_max_buf_size = 4096;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);

    LogBlockPtr last_complete;
    uint64_t bogus_off = 0;
    const uint32_t record_num = 200;
    for (uint32_t i = 0; i < record_num; ++i) {
        const uint64_t start_lsn = 1000 + static_cast<uint64_t>(i) * 10;
        if (i == 5) {
            bogus_off = std::filesystem::file_size(block->file_name());
        }
        auto lb = create_log_block(start_lsn, start_lsn + 10, true, 0, true, 0);
        AppendLog(block, lb);
        last_complete = lb;
    }

    const uint64_t torn_start_lsn = 1000 + static_cast<uint64_t>(record_num) * 10;
    auto torn = create_log_block(torn_start_lsn, torn_start_lsn + 10, true, 0, true, 0);
    const uint64_t torn_off = std::filesystem::file_size(block->file_name());
    AppendLog(block, torn);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    ASSERT_TRUE(block->Close().IsOk());
    std::filesystem::resize_file(path, torn_off + 10);

    auto bogus = MakeBogusHeader();
    int fd = open(path.c_str(), O_WRONLY);
    ASSERT_GE(fd, 0);
    auto st = db::pwritex(fd, &bogus, sizeof(bogus), bogus_off);
    ASSERT_TRUE(st.IsOk());
    close(fd);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, true, false, last_complete->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_no_anchor) {
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    ASSERT_TRUE(block->Close().IsOk());

    const std::string garbage(2048, static_cast<char>(0xab));
    int fd = open(path.c_str(), O_WRONLY);
    ASSERT_GE(fd, 0);
    auto st = db::pwritex(fd, garbage.data(), garbage.size(), db::kBlockHeaderSize);
    ASSERT_TRUE(st.IsOk());
    close(fd);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, false, false, 0);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_FindLastCompleteLog_bogus_anchor_candidate) {
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);
    auto a1 = create_log_block(1000, 1010, true, 0, true, 0);
    const uint64_t a1_off = std::filesystem::file_size(block->file_name());
    AppendLog(block, a1);
    auto a2 = create_log_block(1010, 1020, true, 0, true, 0);
    AppendLog(block, a2);
    auto a3 = create_log_block(1020, 1030, true, 0, true, 0);
    AppendLog(block, a3);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    ASSERT_TRUE(block->Close().IsOk());

    auto bogus = MakeBogusHeader();
    int fd = open(path.c_str(), O_WRONLY);
    ASSERT_GE(fd, 0);
    auto st = db::pwritex(fd, &bogus, sizeof(bogus), a1_off);
    ASSERT_TRUE(st.IsOk());
    close(fd);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());
    CheckLastLog(rblock, true, false, a3->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_garbage_tail) {
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1234);
    auto lb1 = create_log_block(1234, 1256, true);
    AppendLog(block, lb1);
    auto lb2 = create_log_block(1256, 1280, true);
    AppendLog(block, lb2);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t second_size = std::filesystem::file_size(path);

    const std::string garbage(10, static_cast<char>(0xab));
    int fd = open(path.c_str(), O_WRONLY);
    ASSERT_GE(fd, 0);
    auto st = db::pwritex(fd, garbage.data(), garbage.size(), second_size);
    ASSERT_TRUE(st.IsOk());
    close(fd);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsOk());
    ASSERT_EQ(rblock->end_lsn(), lb2->end_lsn);
    ASSERT_EQ(rblock->file_size(), second_size + db::kBlockFooterSize);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_backward_scan_torn_tail) {
    FLAGS_psvr_append_fix_footer_backward_scan = true;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1234);
    auto lb1 = create_log_block(1234, 1256, true);
    AppendLog(block, lb1);
    auto lb2 = create_log_block(1256, 1280, true);
    AppendLog(block, lb2);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t second_size = std::filesystem::file_size(path);
    ASSERT_TRUE(block->Close().IsOk());

    std::filesystem::resize_file(path, second_size - 10);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsOk());
    ASSERT_EQ(rblock->end_lsn(), lb1->end_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_backward_scan_skips_bogus_header) {
    FLAGS_psvr_append_fix_footer_backward_scan = true;
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1234);
    auto lb1 = create_log_block(1234, 1256, true);
    AppendLog(block, lb1);
    auto lb2 = create_log_block(1256, 1280, true);
    AppendLog(block, lb2);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t second_size = std::filesystem::file_size(path);
    ASSERT_TRUE(block->Close().IsOk());

    auto bogus = MakeBogusHeader();

    int fd = open(path.c_str(), O_WRONLY);
    ASSERT_GE(fd, 0);
    auto st = db::pwritex(fd, &bogus, sizeof(bogus), second_size);
    ASSERT_TRUE(st.IsOk());
    close(fd);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsOk());
    ASSERT_EQ(rblock->end_lsn(), lb2->end_lsn);
    ASSERT_EQ(rblock->file_size(), second_size + db::kBlockFooterSize);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_iterate_corrupted_tail) {
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1234);
    auto lb1 = create_log_block(1234, 1256, true);
    AppendLog(block, lb1);
    auto lb2 = create_log_block(1256, 1280, true);
    AppendLog(block, lb2);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t second_size = std::filesystem::file_size(path);
    ASSERT_TRUE(block->Close().IsOk());

    auto bogus = MakeBogusHeader();

    int fd = open(path.c_str(), O_WRONLY);
    ASSERT_GE(fd, 0);
    auto st = db::pwritex(fd, &bogus, sizeof(bogus), second_size);
    ASSERT_TRUE(st.IsOk());
    close(fd);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsOk());
    ASSERT_EQ(rblock->end_lsn(), lb2->end_lsn);
    ASSERT_EQ(rblock->file_size(), second_size + db::kBlockFooterSize);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_iterate_payload_corrupt_tail) {
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1234);
    auto lb1 = create_log_block(1234, 1256, true);
    AppendLog(block, lb1);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t first_size = std::filesystem::file_size(path);
    auto lb2 = create_log_block(1256, 1280, true, 0, true, 1024);
    AppendLog(block, lb2);
    ASSERT_TRUE(block->Sync(true).IsOk());
    const uint64_t data_size = std::filesystem::file_size(path);
    ASSERT_TRUE(block->Close().IsOk());
    std::filesystem::resize_file(path, data_size);
    CorruptValue(path, first_size);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsOk());
    ASSERT_EQ(rblock->end_lsn(), lb1->end_lsn);
    ASSERT_EQ(rblock->file_size(), first_size + db::kBlockFooterSize);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_lsn_discontinuous) {
    for (bool backward_scan : {false, true}) {
        FLAGS_psvr_append_fix_footer_backward_scan = backward_scan;
        Reset();
        std::filesystem::create_directory(_dir / "psvr_test/db");
        _append_db->_data_path = _dir / "psvr_test/db";
        auto block = CreateDB(1, 1234);
        auto lb1 = create_log_block(1234, 1256, true);
        AppendLog(block, lb1);
        auto lb2 = create_log_block(1256, 1280, true);
        AppendLog(block, lb2);
        auto lb3 = create_log_block(1300, 1320, true);
        AppendLog(block, lb3);
        ASSERT_TRUE(block->Sync(true).IsOk());
        const std::string path = block->file_name();
        const uint64_t data_size = std::filesystem::file_size(path);
        ASSERT_TRUE(block->Close().IsOk());
        std::filesystem::resize_file(path, data_size);

        AppendDBEngine::RandomAccessBlockPtr rblock;
        auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
        ASSERT_TRUE(st.IsOk());

        st = _append_db->TryFixBlock(rblock);
        ASSERT_TRUE(st.IsCorrupted());
        ASSERT_EQ(std::filesystem::file_size(path), data_size);

        std::filesystem::remove_all(_dir / "psvr_test/db");
    }
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_TryFixBlock_iterate_read_buf) {
    Reset();
    std::filesystem::create_directory(_dir / "psvr_test/db");
    _append_db->_data_path = _dir / "psvr_test/db";
    auto block = CreateDB(1, 1000);

    LogBlockPtr last_complete;
    uint64_t last_complete_size = 0;
    const uint32_t record_num = 300;
    for (uint32_t i = 0; i < record_num; ++i) {
        const uint64_t start_lsn = 1000 + static_cast<uint64_t>(i) * 10;
        auto lb = create_log_block(start_lsn, start_lsn + 10, true, 0, true, 16 << 10);
        if (i + 1 == record_num) {
            last_complete_size = std::filesystem::file_size(block->file_name());
        }
        AppendLog(block, lb);
        if (i + 2 == record_num) {
            last_complete = lb;
        }
    }
    ASSERT_TRUE(block->Sync(true).IsOk());
    const std::string path = block->file_name();
    const uint64_t file_size = std::filesystem::file_size(path);
    ASSERT_GT(file_size, 4UL << 20);
    ASSERT_TRUE(block->Close().IsOk());

    std::filesystem::resize_file(path, last_complete_size + 10);

    AppendDBEngine::RandomAccessBlockPtr rblock;
    auto st = _append_db->NewRandomAccessBlock(1, 0, &rblock);
    ASSERT_TRUE(st.IsOk());

    st = _append_db->TryFixBlock(rblock);
    ASSERT_TRUE(st.IsOk());
    ASSERT_EQ(rblock->end_lsn(), last_complete->end_lsn);
    ASSERT_EQ(rblock->file_size(), last_complete_size + db::kBlockFooterSize);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_DB) {
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn, max_apply_lsn;
    {
        auto st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
        ASSERT_TRUE(st.IsOk());
        ASSERT_EQ(checkpoint_lsn, 0);
        ASSERT_EQ(max_apply_lsn, 0);

        _append_db->Init(8092);
        std::map<std::pair<uint64_t, uint64_t>, uint32_t> append_recs;
        std::map<uint64_t, uint64_t> append_lsns;
        std::map<uint64_t, uint64_t> append_recs_lsns;
        // FetchRedoLog/RecoverLog skip empty blocks, so the empty ones are kept out of the
        // expected fetch/recover sequences. Remember each block's own start_lsn so we can
        // tell whether the recover patched it (see the checksum check below).
        std::map<std::pair<uint64_t, uint64_t>, uint64_t> append_start_lsns;
        uint64_t lsn = 8092;
        size_t iter = 0;
        size_t empty_num = 0;
        while (lsn < 400000000) {
            uint64_t len = base::RandUint64() % (512<<10);
            // Force empty blocks regularly so that path is always exercised (the random
            // draw alone hits len == 0 only about once every 500k iterations). Keep more
            // than one iteration's worth of LSN headroom so the sequence never ends on an
            // empty block: the recover would skip it and the final LSN check below expects
            // the last recovered block to reach `lsn`.
            if (iter++ % 200 == 0 && lsn + (512 << 10) + 1 < 400000000) {
                len = 0;
            }
            LogBlockPtr log_block = nullptr;
            if (len == 0) {
                log_block = create_empty_log_block(lsn, lsn + 1, true);
                len = 1;
                ++empty_num;
            } else {
                len += 10;
                uint32_t rec_n = 1 + len % 10;
                log_block = create_log_block(lsn, lsn + len, true, rec_n, false, 2048 + len);
            }

            db::LogHeader log_header;
            base::Slice key;
            base::Slice value;
            CreateAppendLog(log_block, &log_header, &key, &value);
            uint64_t fno, off;
            auto st = _append_db->Append(log_header, key, value, &fno, &off, false);
            LOG_IF(NOTICE, !st.IsOk()) << "append log, fno:" << fno << " off:" << off << ", " << st;
            ASSERT_TRUE(st.IsOk());
            if (len > 1) {
                append_recs.emplace(std::make_pair(fno, off), log_header.checksum);
                append_start_lsns.emplace(std::make_pair(fno, off), log_header.start_lsn);
                append_lsns.emplace(lsn, value.size());
                for (auto& it : log_block->records_start_lsn) {
                    append_recs_lsns.emplace(it, value.size());
                }
            }

            lsn += len;
        } END_OF_CASE;

        // The loop above forces empty blocks, so the skip paths of FetchRedoLog/RecoverLog
        // are always covered by this test.
        ASSERT_GT(empty_num, 0);

        ASSERT_GT(_append_db->_random_access_blocks_size.load(), 3);

        uint64_t db_size = 0;
        st = _append_db->GetSize(&db_size);
        LOG_IF(NOTICE, !st.IsOk()) << st;
        ASSERT_TRUE(st.IsOk());
        ASSERT_GT(db_size, 64<<20);

        ASSERT_EQ(_append_db->_random_access_blocks.size(), static_cast<size_t>(_append_db->_random_access_blocks_size));

        std::vector<uint64_t> end_lsn_vec;
        for (auto& it : append_recs) {
            base::Slice data;
            db::LogHeader log_header;
            auto st = _append_db->Read(it.first.first, it.first.second, &data, reinterpret_cast<char*>(&log_header), db::kLogHeaderSize);
            LOG_IF(NOTICE, !st.IsOk()) << "read log, fno:" << it.first.first << " off:" << it.first.second << ", " << st;
            ASSERT_TRUE(st.IsOk());
            ASSERT_EQ(it.second, log_header.checksum);

            end_lsn_vec.push_back(log_header.end_lsn);
        } END_OF_CASE;

        {
            gaia_apply::lsn_t fetch_lsn;
            base::Slice key; base::Slice value;
            char* buf;
            db::LogHeader log_header;
            uint64_t block_no = 0;
            uint64_t block_offset = 0;

            for (auto it : append_lsns) {
                fetch_lsn = it.first;
                st = _append_db->FetchRedoLog(fetch_lsn, &log_header, &key, &value, &buf,
                        block_no, block_offset);
                LOG_IF(NOTICE, !st.IsOk()) << st;
                ASSERT_TRUE(st.IsOk());
                ASSERT_EQ(value.size(), it.second);
            } END_OF_CASE;

            for (auto it : append_recs_lsns) {
                fetch_lsn = it.first;
                st = _append_db->FetchRedoLog(fetch_lsn, &log_header, &key, &value, &buf,
                        block_no, block_offset);
                LOG_IF(NOTICE, !st.IsOk()) << st;
                ASSERT_TRUE(st.IsOk());
                ASSERT_EQ(value.size(), it.second);
            } END_OF_CASE;

        } END_OF_CASE;

        LOG(NOTICE) << "test_DB rblocks:" << _append_db->_random_access_blocks_size.load()
            << " blocks:" << append_recs.size();
        {
            size_t k = 0;
            for (auto& it : append_recs) {
                if (k++ >= 8) {
                    break;
                }
                LOG(NOTICE) << "test_DB append#" << (k - 1)
                    << " fno:" << it.first.first << " off:" << it.first.second;
            }
        }

        {
            auto st = _append_db->Close();
            ASSERT_TRUE(st.IsOk());
        } END_OF_CASE;

        {
            auto st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
            LOG_IF(NOTICE, !st.IsOk()) << st;
            ASSERT_TRUE(st.IsOk());
            ASSERT_EQ(checkpoint_lsn, 8092);
            ASSERT_EQ(max_apply_lsn, lsn);

            ASSERT_TRUE(_append_db->_recover_info != nullptr);
            ASSERT_EQ(_append_db->_recover_info->lsn, 8092);

            uint64_t db_size2 = 0;
            st = _append_db->GetSize(&db_size2);
            LOG_IF(NOTICE, !st.IsOk()) << st;
            ASSERT_TRUE(st.IsOk());
            ASSERT_EQ(db_size + 512, db_size2);

            ASSERT_EQ(_append_db->_random_access_blocks.size(), static_cast<size_t>(_append_db->_random_access_blocks_size.load()));
        } END_OF_CASE;

        {
            std::map<std::pair<uint64_t, uint64_t>, uint32_t> recovery_recs;
            size_t idx = 0;
            uint64_t last_lsn = 0;
            while (true) {
                db::LogHeader log_header;
                base::Slice key, value;
                char* buf = nullptr;
                uint64_t fno, off;

                auto st = _append_db->RecoverLog(&log_header, &key, &value, &buf, &fno, &off);
                LOG_IF(NOTICE, !st.IsOk()) << st;
                ASSERT_TRUE(st.IsOk() || st.IsEof());
                if (st.IsOk()) {
                    uint64_t next_lsn = 0;
                    st = _append_db->PreRecoverNextLog(&next_lsn);
                    LOG_IF(NOTICE, !st.IsOk()) << st;
                    last_lsn = log_header.end_lsn;
                    const auto pos = std::make_pair(fno, off);
                    recovery_recs.emplace(pos, log_header.checksum);
                    ASSERT_EQ(log_header.end_lsn, end_lsn_vec[idx++]);

                    ASSERT_TRUE(!db::check_is_corrupt(log_header, db::kLogHeaderSize));
                    ASSERT_EQ(log_header.key_crc, db::get_crc(reinterpret_cast<const void*>(key.data()), key.size()));
                    ASSERT_EQ(log_header.buf_crc, db::get_crc(reinterpret_cast<const void*>(value.data()), value.size()));

                    // A block that follows skipped empty blocks comes back with its start_lsn
                    // patched to the empty range start and the checksum recomputed, so the
                    // appended checksum only holds for blocks that were not patched.
                    auto ait = append_recs.find(pos);
                    ASSERT_TRUE(ait != append_recs.end());
                    auto sit = append_start_lsns.find(pos);
                    ASSERT_TRUE(sit != append_start_lsns.end());
                    if (log_header.start_lsn == sit->second) {
                        ASSERT_EQ(log_header.checksum, ait->second);
                    }
                }
                std::free(buf);
                if (st.IsEof()) {
                    ASSERT_EQ(last_lsn, lsn);
                    break;
                }
            }

            ASSERT_EQ(recovery_recs.size(), append_recs.size());
            for (auto& it : recovery_recs) {
                auto fit = append_recs.find(it.first);
                ASSERT_TRUE(fit != append_recs.end());
            }

        } END_OF_CASE;

        const auto rblock_size = _append_db->_random_access_blocks_size.load();
        {
            for (auto& it : end_lsn_vec) {
                auto st = _append_db->SetCheckPointLsn(it, it, false);
                LOG_IF(NOTICE, !st.IsOk()) << st;
                ASSERT_TRUE(st.IsOk());
            }

            ASSERT_EQ(_append_db->_checkpoint_block->lsn(), lsn);

            uint64_t db_size2 = 0;
            st = _append_db->GetSize(&db_size2);
            LOG_IF(NOTICE, !st.IsOk()) << st;
            ASSERT_TRUE(st.IsOk());
            ASSERT_EQ(db_size + 512, db_size2);

            ASSERT_EQ(rblock_size, _append_db->_random_access_blocks_size.load());
        } END_OF_CASE;

        {
            auto st = _append_db->RecoverFinish();
            LOG_IF(NOTICE, !st.IsOk()) << st;
            ASSERT_TRUE(st.IsOk());
        } END_OF_CASE;

        {
            ASSERT_EQ(_append_db->_checkpoint_block->lsn(), lsn);

            for (auto& it : end_lsn_vec) {
                auto st = _append_db->SetCheckPointLsn(it, it, false);
                LOG_IF(NOTICE, !st.IsOk()) << st;
                ASSERT_TRUE(st.IsOk());
            }

            ASSERT_EQ(_append_db->_checkpoint_block->lsn(), lsn);

            uint64_t db_size2 = 0;
            st = _append_db->GetSize(&db_size2);
            LOG(NOTICE) << "db size:" << db_size2
                << ", purge db size:" << FLAGS_psvr_append_file_block_size;
            LOG_IF(NOTICE, !st.IsOk()) << st;
            ASSERT_TRUE(st.IsOk());
            ASSERT_GT(db_size, db_size2);

            ASSERT_NE(rblock_size, _append_db->_random_access_blocks_size);
            for (auto rblock : _append_db->_random_access_blocks) {
                LOG(NOTICE) << "random block file:" << rblock->file_name()
                    << " lsn:" << rblock->start_lsn() << "," << rblock->end_lsn()
                    << " size:" << rblock->file_size();
            }
            ASSERT_EQ(1, _append_db->_random_access_blocks_size);
        } END_OF_CASE;

    } END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_footer_slots_lookup_and_recover) {
    FLAGS_psvr_append_file_block_size = 8UL << 20;
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    _append_db->Init(1000);

    const uint32_t record_num = 8;
    std::vector<uint64_t> starts;
    std::vector<uint64_t> offs;
    uint64_t lsn = 1000;
    for (uint32_t i = 0; i < record_num; ++i) {
        auto lb = create_log_block(lsn, lsn + 10, true, 0, false, 200 << 10);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(lb, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        ASSERT_TRUE(_append_db->Append(header, key, value, &fno, &off, false).IsOk());
        starts.push_back(header.start_lsn);
        offs.push_back(off);
        lsn += 10;
    }
    ASSERT_TRUE(_append_db->SetCheckPointLsn(starts[4], starts[4], false).IsOk());
    ASSERT_TRUE(_append_db->Close().IsOk());

    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    ASSERT_EQ(checkpoint_lsn, starts[4]);
    ASSERT_NE(_append_db->_recover_info, nullptr);
    ASSERT_EQ(_append_db->_recover_info->seek_off, offs[4]);

    auto rblock = _append_db->_random_access_blocks.front();
    uint64_t slot_off = 0;
    ASSERT_FALSE(rblock->FindSlotOffset(starts.front(), &slot_off));
    bool used = false;
    for (size_t i = 0; i < starts.size(); ++i) {
        slot_off = 0;
        if (!rblock->FindSlotOffset(starts[i], &slot_off)) {
            continue;
        }
        used = true;
        ASSERT_LE(slot_off, offs[i]);
        db::LogHeader header;
        base::Slice buf;
        ASSERT_TRUE(rblock->Read(slot_off, db::kLogHeaderSize, &buf,
                reinterpret_cast<char*>(&header)).IsOk());
        ASSERT_EQ(buf.size(), db::kLogHeaderSize);
        ASSERT_LE(header.start_lsn, starts[i]);
    }
    ASSERT_TRUE(used);

    db::LogHeader fetched;
    base::Slice key;
    base::Slice value;
    char* data = nullptr;
    uint64_t fno = 0;
    uint64_t offset = 0;
    ASSERT_TRUE(_append_db->FetchRedoLog(starts[5], &fetched, &key, &value, &data,
            fno, offset, nullptr).IsOk());
    ASSERT_EQ(fetched.start_lsn, starts[5]);
    free(data);

    data = nullptr;
    fno = rblock->file_no();
    offset = offs.front() + 1;
    ASSERT_TRUE(_append_db->FetchRedoLog(starts[5], &fetched, &key, &value, &data,
            fno, offset, nullptr).IsOk());
    ASSERT_EQ(fetched.start_lsn, starts[5]);
    free(data);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_footer_slots_invalid_ignored) {
    FLAGS_psvr_append_file_block_size = 8UL << 20;
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    _append_db->Init(1000);

    std::vector<uint64_t> starts;
    uint64_t lsn = 1000;
    for (uint32_t i = 0; i < 4; ++i) {
        auto lb = create_log_block(lsn, lsn + 10, true, 0, false, 200 << 10);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(lb, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        ASSERT_TRUE(_append_db->Append(header, key, value, &fno, &off, false).IsOk());
        starts.push_back(header.start_lsn);
        lsn += 10;
    }
    const std::string path = _append_db->_write_block->file_name();
    ASSERT_TRUE(_append_db->Close().IsOk());

    const uint64_t file_size = std::filesystem::file_size(path);
    int fd = open(path.c_str(), O_RDWR);
    ASSERT_GE(fd, 0);
    db::BlockFooter footer;
    ASSERT_TRUE(db::preadx(fd, &footer, db::kBlockFooterSize,
            file_size - db::kBlockFooterSize).IsOk());
    bool corrupted = false;
    for (auto& slot : footer.slots) {
        if (slot.offset != 0) {
            slot.offset = 1;
            corrupted = true;
            break;
        }
    }
    ASSERT_TRUE(corrupted);
    db::make_checksum(&footer, db::kBlockFooterSize);
    ASSERT_TRUE(db::pwritex(fd, &footer, db::kBlockFooterSize,
            file_size - db::kBlockFooterSize).IsOk());
    close(fd);

    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    auto rblock = _append_db->_random_access_blocks.front();
    for (const auto& start_lsn : starts) {
        uint64_t slot_off = 0;
        ASSERT_FALSE(rblock->FindSlotOffset(start_lsn, &slot_off));
    }

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_footer_slots_absent) {
    FLAGS_psvr_append_file_block_size = 8UL << 20;
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    _append_db->Init(1000);

    std::vector<uint64_t> starts;
    uint64_t lsn = 1000;
    for (uint32_t i = 0; i < 8; ++i) {
        auto lb = create_log_block(lsn, lsn + 10, true, 0, false, 200 << 10);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(lb, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        ASSERT_TRUE(_append_db->Append(header, key, value, &fno, &off, false).IsOk());
        starts.push_back(header.start_lsn);
        lsn += 10;
    }
    const std::string path = _append_db->_write_block->file_name();
    ASSERT_TRUE(_append_db->Close().IsOk());

    const uint64_t file_size = std::filesystem::file_size(path);
    int fd = open(path.c_str(), O_RDWR);
    ASSERT_GE(fd, 0);
    db::BlockFooter footer;
    ASSERT_TRUE(db::preadx(fd, &footer, db::kBlockFooterSize,
            file_size - db::kBlockFooterSize).IsOk());
    memset(footer.slots, 0, sizeof(footer.slots));
    db::make_checksum(&footer, db::kBlockFooterSize);
    ASSERT_TRUE(db::pwritex(fd, &footer, db::kBlockFooterSize,
            file_size - db::kBlockFooterSize).IsOk());
    close(fd);

    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    auto rblock = _append_db->_random_access_blocks.front();
    uint64_t slot_off = 0;
    ASSERT_FALSE(rblock->FindSlotOffset(starts.back(), &slot_off));

    db::LogHeader fetched;
    base::Slice key;
    base::Slice value;
    char* data = nullptr;
    uint64_t fno = 0;
    uint64_t offset = 0;
    ASSERT_TRUE(_append_db->FetchRedoLog(starts.back(), &fetched, &key, &value, &data,
            fno, offset, nullptr).IsOk());
    ASSERT_EQ(fetched.start_lsn, starts.back());
    free(data);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_batch_append_footer_slots) {
    FLAGS_psvr_append_file_block_size = 8UL << 20;
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    _append_db->Init(1000);

    std::vector<db::LogHeader> headers;
    std::vector<base::Slice> keys;
    std::vector<base::Slice> values;
    std::vector<LogBlockPtr> blocks;
    uint64_t lsn = 1000;
    for (uint32_t i = 0; i < 4; ++i) {
        auto lb = create_log_block(lsn, lsn + 10, true, 0, false, 200 << 10);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(lb, &header, &key, &value);
        blocks.push_back(lb);
        headers.push_back(header);
        keys.push_back(key);
        values.push_back(value);
        lsn += 10;
    }
    std::vector<uint64_t> fnos(headers.size());
    std::vector<uint64_t> offs(headers.size());
    ASSERT_TRUE(_append_db->BatchAppend(headers, keys, values, &fnos, &offs).IsOk());
    const std::string path = _append_db->_write_block->file_name();
    ASSERT_TRUE(_append_db->Close().IsOk());

    const uint64_t file_size = std::filesystem::file_size(path);
    int fd = open(path.c_str(), O_RDONLY);
    ASSERT_GE(fd, 0);
    db::BlockFooter footer;
    ASSERT_TRUE(db::preadx(fd, &footer, db::kBlockFooterSize,
            file_size - db::kBlockFooterSize).IsOk());
    close(fd);
    const uint64_t slot_size = (8UL << 20) / db::kBlockFooterSlotNum;
    size_t first = 0;
    while (first < offs.size() && offs[first] <= slot_size) {
        ++first;
    }
    ASSERT_LT(first, offs.size());
    const uint64_t slot = offs[first] / slot_size;
    ASSERT_EQ(footer.slots[0].offset, 0);
    ASSERT_EQ(footer.slots[slot].offset, offs[first]);
    ASSERT_EQ(footer.slots[slot].start_lsn, headers[first].start_lsn);

    std::filesystem::remove_all(_dir / "psvr_test/db");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_block_slots_file) {
    std::filesystem::create_directory(_dir / "psvr_test");
    const std::string path = (_dir / "psvr_test/append_slots").string();
    db::BlockFooterSlot slots[db::kBlockFooterSlotNum] = {};
    slots[1].start_lsn = 1010;
    slots[1].offset = 4096 + 100;
    {
        db::BlockSlotsBlock block(path);
        ASSERT_TRUE(block.Open().IsOk());
        block.NewSlots()->Reset(slots);
        ASSERT_TRUE(block.Update(1, 1000).IsOk());
        block.NewSlots();
        ASSERT_TRUE(block.Update(2, 2000).IsOk());
        ASSERT_TRUE(block.Close().IsOk());
    }
    {
        db::BlockSlotsBlock block(path);
        ASSERT_TRUE(block.Open().IsOk());
        db::BlockFooterSlot loaded[db::kBlockFooterSlotNum] = {};
        bool found = false;
        ASSERT_TRUE(block.Load(1, 1000, loaded, &found).IsOk());
        ASSERT_FALSE(found);
        ASSERT_TRUE(block.Load(2, 2000, loaded, &found).IsOk());
        ASSERT_TRUE(found);
        ASSERT_EQ(loaded[1].offset, 0);
        ASSERT_TRUE(block.Close().IsOk());
    }

    ASSERT_EQ(std::filesystem::file_size(path), db::kBlockSlotsSize * 2);
    db::BlockSlots sectors[2];
    int fd = open(path.c_str(), O_RDWR);
    ASSERT_GE(fd, 0);
    ASSERT_TRUE(db::preadx(fd, &sectors, db::kBlockSlotsSize * 2, 0).IsOk());
    const uint32_t newest = sectors[0].seq > sectors[1].seq ? 0 : 1;
    const uint64_t zero = 0;
    ASSERT_TRUE(db::pwritex(fd, &zero, sizeof(zero),
            newest * db::kBlockSlotsSize).IsOk());
    close(fd);

    {
        db::BlockSlotsBlock block(path);
        ASSERT_TRUE(block.Open().IsOk());
        db::BlockFooterSlot loaded[db::kBlockFooterSlotNum] = {};
        bool found = false;
        ASSERT_TRUE(block.Load(1, 1000, loaded, &found).IsOk());
        ASSERT_TRUE(found);
        ASSERT_EQ(loaded[1].start_lsn, slots[1].start_lsn);
        ASSERT_EQ(loaded[1].offset, slots[1].offset);
        ASSERT_TRUE(block.Load(2, 2000, loaded, &found).IsOk());
        ASSERT_FALSE(found);
        ASSERT_TRUE(block.Close().IsOk());
    }

    std::filesystem::remove_all(_dir / "psvr_test");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_slots_persist_after_kill) {
    FLAGS_psvr_append_file_block_size = 8UL << 20;
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    _append_db->Init(1000);

    std::vector<uint64_t> starts;
    std::vector<uint64_t> offs;
    uint64_t lsn = 1000;
    for (uint32_t i = 0; i < 8; ++i) {
        auto lb = create_log_block(lsn, lsn + 10, true, 0, false, 200 << 10);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(lb, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        ASSERT_TRUE(_append_db->Append(header, key, value, &fno, &off, false).IsOk());
        starts.push_back(header.start_lsn);
        offs.push_back(off);
        lsn += 10;
    }
    ASSERT_TRUE(_append_db->SetCheckPointLsn(starts[4], starts[4], false).IsOk());

    const std::filesystem::path src = _dir / "psvr_test";
    const std::filesystem::path dst = _dir / "psvr_test_copy";
    std::filesystem::remove_all(dst);
    std::filesystem::copy(src, dst,
            std::filesystem::copy_options::recursive |
            std::filesystem::copy_options::overwrite_existing);
    ASSERT_TRUE(_append_db->Close().IsOk());

    AppendDBEngine engine;
    gaia_apply::lsn_t ckp = 0;
    gaia_apply::lsn_t max_lsn = 0;
    ASSERT_TRUE(engine.Open(dst.string(), 0, &ckp, &max_lsn).IsOk());
    ASSERT_EQ(ckp, starts[4]);
    ASSERT_NE(engine._recover_info, nullptr);
    ASSERT_EQ(engine._recover_info->seek_off, offs[4]);
    auto rblock = engine._random_access_blocks.front();
    uint64_t slot_off = 0;
    ASSERT_TRUE(rblock->FindSlotOffset(starts[5], &slot_off));

    const std::string block_path = (dst / "db/1.db").string();
    const uint64_t fixed_size = std::filesystem::file_size(block_path);
    db::BlockFooter footer;
    int ffd = open(block_path.c_str(), O_RDONLY);
    ASSERT_GE(ffd, 0);
    ASSERT_TRUE(db::preadx(ffd, &footer, db::kBlockFooterSize,
            fixed_size - db::kBlockFooterSize).IsOk());
    close(ffd);
    ASSERT_EQ(footer.log_num, 8);
    ASSERT_TRUE(engine.Close().IsOk());

    std::filesystem::remove_all(dst);
    std::filesystem::remove_all(_dir / "psvr_test");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_slots_persist_mismatch) {
    FLAGS_psvr_append_file_block_size = 8UL << 20;
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    _append_db->Init(1000);

    std::vector<uint64_t> starts;
    std::vector<uint64_t> offs;
    uint64_t lsn = 1000;
    for (uint32_t i = 0; i < 8; ++i) {
        auto lb = create_log_block(lsn, lsn + 10, true, 0, false, 200 << 10);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(lb, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        ASSERT_TRUE(_append_db->Append(header, key, value, &fno, &off, false).IsOk());
        starts.push_back(header.start_lsn);
        offs.push_back(off);
        lsn += 10;
    }
    ASSERT_TRUE(_append_db->SetCheckPointLsn(starts[4], starts[4], false).IsOk());

    const std::filesystem::path src = _dir / "psvr_test";
    const std::filesystem::path dst = _dir / "psvr_test_copy";
    std::filesystem::remove_all(dst);
    std::filesystem::copy(src, dst,
            std::filesystem::copy_options::recursive |
            std::filesystem::copy_options::overwrite_existing);
    ASSERT_TRUE(_append_db->Close().IsOk());

    db::BlockFooterSlot slots[db::kBlockFooterSlotNum] = {};
    slots[1].start_lsn = starts[3];
    slots[1].offset = offs[3];
    {
        db::BlockSlotsBlock block((dst / "append_slots").string());
        ASSERT_TRUE(block.Open().IsOk());
        block.NewSlots()->Reset(slots);
        ASSERT_TRUE(block.Update(1, starts.front() + 1).IsOk());
        ASSERT_TRUE(block.Close().IsOk());
    }

    AppendDBEngine engine;
    gaia_apply::lsn_t ckp = 0;
    gaia_apply::lsn_t max_lsn = 0;
    ASSERT_TRUE(engine.Open(dst.string(), 0, &ckp, &max_lsn).IsOk());
    ASSERT_EQ(ckp, starts[4]);
    ASSERT_NE(engine._recover_info, nullptr);
    ASSERT_EQ(engine._recover_info->seek_off, offs[4]);
    auto rblock = engine._random_access_blocks.front();
    uint64_t slot_off = 0;
    ASSERT_FALSE(rblock->FindSlotOffset(starts[5], &slot_off));
    ASSERT_TRUE(engine.Close().IsOk());

    std::filesystem::remove_all(dst);
    std::filesystem::remove_all(_dir / "psvr_test");
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_BatchAppend) {
    std::vector<db::LogHeader> headers;
    std::vector<base::Slice> keys;
    std::vector<base::Slice> values;
    std::vector<uint64_t> fnos;
    std::vector<uint64_t> offs;

    ASSERT_TRUE(_append_db->BatchAppend(headers, keys, values, &fnos, &offs).IsOk());

    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open((_dir / "psvr_test/db").string(), 0,
            &checkpoint_lsn, &max_apply_lsn).IsOk());
    _append_db->Init(1000);

    auto first_block = create_log_block(1000, 1010, true, 1, false);
    auto second_block = create_log_block(1010, 1020, true, 1, false);
    db::LogHeader first_header;
    db::LogHeader second_header;
    base::Slice first_key;
    base::Slice first_value;
    base::Slice second_key;
    base::Slice second_value;
    CreateAppendLog(first_block, &first_header, &first_key, &first_value);
    CreateAppendLog(second_block, &second_header, &second_key, &second_value);

    headers = {first_header, second_header};
    keys = {first_key, second_key};
    values = {first_value, second_value};
    fnos.resize(headers.size());
    offs.resize(headers.size());

    _append_db->_disable = 1;
    auto st = _append_db->BatchAppend(headers, keys, values, &fnos, &offs);
    ASSERT_EQ(st.code, db::Code::kInvalid);
    _append_db->_disable = 0;

    st = _append_db->BatchAppend(headers, keys, values, &fnos, &offs);
    ASSERT_TRUE(st.IsOk());
    ASSERT_EQ(fnos.size(), 2);
    ASSERT_EQ(offs.size(), 2);
    ASSERT_EQ(fnos[0], fnos[1]);
    ASSERT_LT(offs[0], offs[1]);
    ASSERT_EQ(_append_db->_next_write_lsn, 1020);

    headers[1].start_lsn = 9999;
    st = _append_db->BatchAppend(headers, keys, values, &fnos, &offs);
    ASSERT_EQ(st.code, db::Code::kMisMacth);
}

TEST_F(AppendDBEngineTests, test_DumpAppendBlockMetadata) {
    db::BlockHeader header(100);
    db::make_checksum(&header, db::kBlockHeaderSize);
    std::ostringstream output;
    db::DumpBlockHeader(header, output);
    ASSERT_TRUE(output.str().find("start_lsn:100") != std::string::npos);

    header.magic = 0;
    header.checksum = 0;
    output.str("");
    output.clear();
    db::DumpBlockHeader(header, output);
    ASSERT_TRUE(output.str().find("expect_magic") != std::string::npos);
    ASSERT_TRUE(output.str().find("calc_checksum") != std::string::npos);

    db::BlockFooter footer;
    db::make_checksum(&footer, db::kBlockFooterSize);
    output.str("");
    output.clear();
    db::DumpBlockFooter(footer, output);
    ASSERT_TRUE(output.str().find("log_num:0") != std::string::npos);

    footer.magic = 0;
    footer.checksum = 0;
    output.str("");
    output.clear();
    db::DumpBlockFooter(footer, output);
    ASSERT_TRUE(output.str().find("expect_magic") != std::string::npos);
    ASSERT_TRUE(output.str().find("calc_checksum") != std::string::npos);

    db::CheckPoint checkpoint;
    db::make_checksum(&checkpoint, db::kCheckPointSize);
    output.str("");
    output.clear();
    db::DumpCheckPoint(checkpoint, output);
    ASSERT_TRUE(output.str().find("lsn:0") != std::string::npos);

    checkpoint.magic = 0;
    checkpoint.checksum = 0;
    output.str("");
    output.clear();
    db::DumpCheckPoint(checkpoint, output);
    ASSERT_TRUE(output.str().find("expect_magic") != std::string::npos);
    ASSERT_TRUE(output.str().find("calc_checksum") != std::string::npos);
}

// FetchRedoLog with a real read-ahead buffer: an empty block is skipped forward to
// the next block carrying data, and the sequential fetches are served from the buffer.
TEST_F(AppendDBEngineTests, test_fetch_redo_log_with_read_buf) {
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    auto st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
    ASSERT_TRUE(st.IsOk());
    _append_db->Init(8092);

    // An empty block followed by two data blocks with different payload sizes.
    struct BlockInfo {
        uint64_t start_lsn = 0;
        size_t value_size = 0;
    };
    std::vector<BlockInfo> infos;
    uint64_t lsn = 8092;
    for (int i = 0; i < 3; ++i) {
        LogBlockPtr log_block;
        if (i == 0) {
            log_block = create_empty_log_block(lsn, lsn + 1, true);
            lsn += 1;
        } else {
            log_block = create_log_block(lsn, lsn + 500, true, 3, false, i == 1 ? 2048 : 1024);
            lsn += 500;
        }
        db::LogHeader log_header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(log_block, &log_header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        st = _append_db->Append(log_header, key, value, &fno, &off, false);
        ASSERT_TRUE(st.IsOk());
        infos.push_back({log_header.start_lsn, value.size()});
    }
    ASSERT_TRUE(infos[0].value_size == 0);

    // A small buffer so the block boundaries cross the read-ahead window.
    AppendReadBuf read_buf(1024);
    uint64_t block_no = 0;
    uint64_t block_offset = 0;
    auto fetch = [&](uint64_t seek_lsn, size_t expect_size) {
        db::LogHeader log_header;
        base::Slice key;
        base::Slice value;
        char* buf = nullptr;
        auto fst = _append_db->FetchRedoLog(seek_lsn, &log_header, &key, &value, &buf,
                block_no, block_offset, &read_buf);
        LOG_IF(NOTICE, !fst.IsOk()) << fst;
        ASSERT_TRUE(fst.IsOk());
        ASSERT_EQ(value.size(), expect_size);
        if (buf) {
            std::free(buf);
        }
    };

    // The empty block is skipped, the first data block is returned with the LSN range
    // patched to stay contiguous.
    fetch(infos[0].start_lsn, infos[1].value_size);
    fetch(infos[1].start_lsn, infos[1].value_size);
    fetch(infos[2].start_lsn, infos[2].value_size);
    END_OF_CASE;
}

// RecoverLog must return exactly the blocks that were appended, in order, with the
// same LSN ranges. A small deterministic case makes any mismatch easy to see.
TEST_F(AppendDBEngineTests, test_recover_log_sequence) {
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    auto st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
    ASSERT_TRUE(st.IsOk());
    _append_db->Init(8092);

    std::vector<std::pair<uint64_t, uint64_t>> ranges;
    uint64_t lsn = 8092;
    for (int i = 0; i < 4; ++i) {
        LogBlockPtr log_block = create_log_block(lsn, lsn + 200, true, 1, false, 1024);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(log_block, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        st = _append_db->Append(header, key, value, &fno, &off, false);
        ASSERT_TRUE(st.IsOk());
        LOG(NOTICE) << "append#" << i << " fno:" << fno << " off:" << off
            << " range:[" << header.start_lsn << "," << header.end_lsn << "]"
            << " key_size:" << header.key_size << " value_size:" << header.value_size;
        ranges.emplace_back(header.start_lsn, header.end_lsn);
        lsn += 200;
    }

    st = _append_db->Close();
    ASSERT_TRUE(st.IsOk());
    st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
    ASSERT_TRUE(st.IsOk());

    for (size_t i = 0; i < ranges.size(); ++i) {
        db::LogHeader h;
        base::Slice key;
        base::Slice value;
        char* buf = nullptr;
        uint64_t fno = 0;
        uint64_t off = 0;
        auto rst = _append_db->RecoverLog(&h, &key, &value, &buf, &fno, &off);
        LOG(NOTICE) << "recover#" << i << " st:" << rst << " fno:" << fno << " off:" << off
            << " range:[" << h.start_lsn << "," << h.end_lsn << "]"
            << " key_size:" << h.key_size << " value_size:" << h.value_size;
        ASSERT_TRUE(rst.IsOk());
        ASSERT_EQ(h.start_lsn, ranges[i].first);
        ASSERT_EQ(h.end_lsn, ranges[i].second);
        // RecoverLog only records the next position; the caller advances it.
        uint64_t next_lsn = 0;
        auto pst = _append_db->PreRecoverNextLog(&next_lsn);
        ASSERT_TRUE(pst.IsOk());
        if (buf) {
            std::free(buf);
        }
    }
    END_OF_CASE;
}

// A file that ends with one or more empty blocks must still advance the recovered
// LSN past them: the trailing empty blocks are merged into a single empty header
// whose LSN range covers them all, so the final recovered position reaches the last
// block's end_lsn instead of returning Eof with the LSN stuck before the empty range.
TEST_F(AppendDBEngineTests, test_recover_log_ends_with_empty_block) {
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    auto st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
    ASSERT_TRUE(st.IsOk());
    _append_db->Init(8092);

    // Two non-empty blocks, then two trailing empty blocks.
    std::vector<std::pair<uint64_t, uint64_t>> ranges;
    uint64_t lsn = 8092;
    for (int i = 0; i < 2; ++i) {
        LogBlockPtr log_block = create_log_block(lsn, lsn + 200, true, 1, false, 1024);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(log_block, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        st = _append_db->Append(header, key, value, &fno, &off, false);
        ASSERT_TRUE(st.IsOk());
        ranges.emplace_back(header.start_lsn, header.end_lsn);
        lsn += 200;
    }
    const uint64_t empty_start_lsn = lsn;
    for (int i = 0; i < 2; ++i) {
        LogBlockPtr log_block = create_empty_log_block(lsn, lsn + 1, true);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(log_block, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        st = _append_db->Append(header, key, value, &fno, &off, false);
        ASSERT_TRUE(st.IsOk());
        lsn += 1;
    }

    st = _append_db->Close();
    ASSERT_TRUE(st.IsOk());
    st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
    ASSERT_TRUE(st.IsOk());

    // Non-empty blocks come back first, unchanged.
    for (size_t i = 0; i < ranges.size(); ++i) {
        db::LogHeader h;
        base::Slice key;
        base::Slice value;
        char* buf = nullptr;
        uint64_t fno = 0;
        uint64_t off = 0;
        auto rst = _append_db->RecoverLog(&h, &key, &value, &buf, &fno, &off);
        ASSERT_TRUE(rst.IsOk());
        ASSERT_EQ(h.start_lsn, ranges[i].first);
        ASSERT_EQ(h.end_lsn, ranges[i].second);
        uint64_t next_lsn = 0;
        auto pst = _append_db->PreRecoverNextLog(&next_lsn);
        ASSERT_TRUE(pst.IsOk());
        ASSERT_EQ(next_lsn, h.end_lsn);
        if (buf) {
            std::free(buf);
        }
    }

    // Trailing empty blocks are merged into one empty header whose LSN range covers
    // them all, and the recovered LSN advances to the final end_lsn.
    {
        db::LogHeader h;
        base::Slice key;
        base::Slice value;
        char* buf = nullptr;
        uint64_t fno = 0;
        uint64_t off = 0;
        auto rst = _append_db->RecoverLog(&h, &key, &value, &buf, &fno, &off);
        ASSERT_TRUE(rst.IsOk()) << rst;
        ASSERT_EQ(h.key_size + h.value_size, 0u);
        ASSERT_EQ(h.start_lsn, empty_start_lsn);
        ASSERT_EQ(h.end_lsn, lsn);
        uint64_t next_lsn = 0;
        auto pst = _append_db->PreRecoverNextLog(&next_lsn);
        ASSERT_TRUE(pst.IsOk());
        ASSERT_EQ(next_lsn, lsn);
        if (buf) {
            std::free(buf);
        }
    }

    // The next call reports Eof now that the trailing empty range is consumed.
    {
        db::LogHeader h;
        base::Slice key;
        base::Slice value;
        char* buf = nullptr;
        uint64_t fno = 0;
        uint64_t off = 0;
        auto rst = _append_db->RecoverLog(&h, &key, &value, &buf, &fno, &off);
        ASSERT_TRUE(rst.IsEof());
    }

    END_OF_CASE;
}

// Same as above but with block payloads large enough to bypass the read-ahead
// buffer (>= 2/3 of it), which is the shape used by test_DB.
TEST_F(AppendDBEngineTests, test_recover_log_sequence_large_blocks) {
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    auto st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
    ASSERT_TRUE(st.IsOk());
    _append_db->Init(8092);

    std::vector<std::pair<uint64_t, uint64_t>> ranges;
    uint64_t lsn = 8092;
    for (int i = 0; i < 30; ++i) {
        LogBlockPtr log_block = create_log_block(lsn, lsn + 200000, true, 1, false, 262144);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(log_block, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        st = _append_db->Append(header, key, value, &fno, &off, false);
        ASSERT_TRUE(st.IsOk());
        ranges.emplace_back(header.start_lsn, header.end_lsn);
        lsn += 200000;
    }

    st = _append_db->Close();
    ASSERT_TRUE(st.IsOk());
    st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
    ASSERT_TRUE(st.IsOk());

    for (size_t i = 0; i < ranges.size(); ++i) {
        db::LogHeader h;
        base::Slice key;
        base::Slice value;
        char* buf = nullptr;
        uint64_t fno = 0;
        uint64_t off = 0;
        auto rst = _append_db->RecoverLog(&h, &key, &value, &buf, &fno, &off);
        LOG(NOTICE) << "recover#" << i << " st:" << rst << " fno:" << fno << " off:" << off
            << " range:[" << h.start_lsn << "," << h.end_lsn << "]"
            << " expect:[" << ranges[i].first << "," << ranges[i].second << "]";
        ASSERT_TRUE(rst.IsOk());
        ASSERT_EQ(h.start_lsn, ranges[i].first);
        ASSERT_EQ(h.end_lsn, ranges[i].second);
        uint64_t next_lsn = 0;
        auto pst = _append_db->PreRecoverNextLog(&next_lsn);
        ASSERT_TRUE(pst.IsOk());
        if (buf) {
            std::free(buf);
        }
    }
    END_OF_CASE;
}

// Same as above but with a small append block size so the data spans several
// rblocks: this exercises the rblock switch inside RecoverLog.
TEST_F(AppendDBEngineTests, test_recover_log_sequence_multi_rblock) {
    FLAGS_psvr_append_file_block_size = 1 << 20;
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    auto st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
    ASSERT_TRUE(st.IsOk());
    _append_db->Init(8092);

    std::vector<std::pair<uint64_t, uint64_t>> ranges;
    uint64_t lsn = 8092;
    for (int i = 0; i < 12; ++i) {
        LogBlockPtr log_block = create_log_block(lsn, lsn + 200000, true, 1, false, 262144);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(log_block, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        st = _append_db->Append(header, key, value, &fno, &off, false);
        ASSERT_TRUE(st.IsOk());
        LOG(NOTICE) << "append#" << i << " fno:" << fno << " off:" << off;
        ranges.emplace_back(header.start_lsn, header.end_lsn);
        lsn += 200000;
    }
    LOG(NOTICE) << "rblock count:" << _append_db->_random_access_blocks.size();

    st = _append_db->Close();
    ASSERT_TRUE(st.IsOk());
    st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
    ASSERT_TRUE(st.IsOk());

    for (size_t i = 0; i < ranges.size(); ++i) {
        db::LogHeader h;
        base::Slice key;
        base::Slice value;
        char* buf = nullptr;
        uint64_t fno = 0;
        uint64_t off = 0;
        auto rst = _append_db->RecoverLog(&h, &key, &value, &buf, &fno, &off);
        LOG(NOTICE) << "recover#" << i << " st:" << rst << " fno:" << fno << " off:" << off
            << " range:[" << h.start_lsn << "," << h.end_lsn << "]"
            << " expect:[" << ranges[i].first << "," << ranges[i].second << "]";
        ASSERT_TRUE(rst.IsOk());
        ASSERT_EQ(h.start_lsn, ranges[i].first);
        ASSERT_EQ(h.end_lsn, ranges[i].second);
        uint64_t next_lsn = 0;
        auto pst = _append_db->PreRecoverNextLog(&next_lsn);
        ASSERT_TRUE(pst.IsOk());
        if (buf) {
            std::free(buf);
        }
    }
    END_OF_CASE;
}

// A file that ends with an empty block and whose successor starts with an empty
// block must merge the empty range across the rblock boundary: RecoverLog keeps
// first_start_lsn / log_block_n across the switch and returns one empty header
// covering both blocks.
TEST_F(AppendDBEngineTests, test_recover_log_empty_across_rblock_boundary) {
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    auto st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
    ASSERT_TRUE(st.IsOk());
    _append_db->Init(8092);

    // Force max_size down to kBlockMinSize (8MB) so the small payload below
    // already crosses the rblock boundary.
    const uint64_t old_block_size = FLAGS_psvr_append_file_block_size;
    FLAGS_psvr_append_file_block_size = 1 << 20;

    // kBlockMinSize == 8MB, kBlockHeaderSize == 4096, kLogHeaderSize == 128.
    // A large non-empty block fills rblock 0 so the next empty block (128 bytes)
    // lands at its tail and the one after crosses into rblock 1's head.
    const uint64_t buf_len = 8384160;
    uint64_t lsn = 8092;
    {
        LogBlockPtr log_block = create_log_block(lsn, lsn + 200000, true, 1, false, buf_len);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(log_block, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        st = _append_db->Append(header, key, value, &fno, &off, false);
        ASSERT_TRUE(st.IsOk());
        lsn += 200000;
    }
    const uint64_t empty_start_lsn = lsn;
    for (int i = 0; i < 2; ++i) {
        LogBlockPtr log_block = create_empty_log_block(lsn, lsn + 1, true);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(log_block, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        st = _append_db->Append(header, key, value, &fno, &off, false);
        ASSERT_TRUE(st.IsOk());
        lsn += 1;
    }
    ASSERT_GE(_append_db->_random_access_blocks.size(), 2u);

    st = _append_db->Close();
    ASSERT_TRUE(st.IsOk());

    // Run the same on-disk data across several max_empty_block_num values: the
    // empty blocks split at the configured limit and otherwise merge into one.
    const int32_t old_max_empty_num = FLAGS_psvr_append_recover_max_empty_block_num;
    const std::vector<int32_t> max_empty_nums = {0, 1, 2, 3};
    for (int32_t max_empty_num : max_empty_nums) {
        FLAGS_psvr_append_recover_max_empty_block_num = max_empty_num;
        st = _append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn);
        ASSERT_TRUE(st.IsOk());

        // The non-empty block comes back first, unchanged.
        {
            db::LogHeader h;
            base::Slice key;
            base::Slice value;
            char* buf = nullptr;
            uint64_t fno = 0;
            uint64_t off = 0;
            auto rst = _append_db->RecoverLog(&h, &key, &value, &buf, &fno, &off);
            ASSERT_TRUE(rst.IsOk()) << rst;
            ASSERT_EQ(h.start_lsn, 8092u);
            ASSERT_EQ(h.end_lsn, 8092u + 200000u);
            uint64_t next_lsn = 0;
            ASSERT_TRUE(_append_db->PreRecoverNextLog(&next_lsn).IsOk());
            ASSERT_EQ(next_lsn, h.end_lsn);
            if (buf) {
                std::free(buf);
            }
        }

        auto recover_one_empty = [&](uint64_t expect_start, uint64_t expect_end) {
            db::LogHeader h;
            base::Slice key;
            base::Slice value;
            char* buf = nullptr;
            uint64_t fno = 0;
            uint64_t off = 0;
            auto rst = _append_db->RecoverLog(&h, &key, &value, &buf, &fno, &off);
            ASSERT_TRUE(rst.IsOk()) << rst;
            ASSERT_EQ(h.key_size + h.value_size, 0u);
            ASSERT_EQ(h.start_lsn, expect_start);
            ASSERT_EQ(h.end_lsn, expect_end);
            uint64_t next_lsn = 0;
            ASSERT_TRUE(_append_db->PreRecoverNextLog(&next_lsn).IsOk());
            ASSERT_EQ(next_lsn, expect_end);
            if (buf) {
                std::free(buf);
            }
        };

        if (max_empty_num <= 1) {
            // max_empty_num == 0 is clamped to 1, so it splits the same way: one
            // empty block per read, each coming back on its own.
            recover_one_empty(empty_start_lsn, empty_start_lsn + 1);
            recover_one_empty(empty_start_lsn + 1, empty_start_lsn + 2);
        } else {
            // The empty blocks (rblock 0 tail + rblock 1 head) merge into one.
            recover_one_empty(empty_start_lsn, lsn);
        }

        st = _append_db->Close();
        ASSERT_TRUE(st.IsOk());
    }
    FLAGS_psvr_append_recover_max_empty_block_num = old_max_empty_num;
    FLAGS_psvr_append_file_block_size = old_block_size;

    END_OF_CASE;
}

// The read-ahead buffer is owned by _recover_info, which Close/Clear/RecoverFinish may
// reset at any time: the reader must fail fast instead of touching a destroyed buffer.
TEST_F(AppendDBEngineTests, test_recover_log_from_rblock_without_read_buf) {
    ASSERT_TRUE(_append_db->_recover_info == nullptr);

    // The buffer is checked before the block is touched, so no block is needed here.
    db::LogHeader h;
    base::Slice key;
    base::Slice value;
    char* buf = nullptr;
    uint64_t next_off = 0;
    auto st = _append_db->RecoverLogFromRBlock(nullptr, db::kBlockHeaderSize,
            &h, &key, &value, &buf, &next_off);
    ASSERT_TRUE(st.IsInvalid());
    ASSERT_TRUE(buf == nullptr);
    END_OF_CASE;
}

// ---------------------------------------------------------------------------
// AppendReadBuf is the in-memory read-ahead buffer of the append reads. The fake
// block below serves Read() from a memory image so the tests can check both the
// served bytes and the read-ahead behaviour (the offset/length of every read).
// ---------------------------------------------------------------------------
class AppendReadBufTests : public PsvrTest {
public:
    static constexpr uint64_t kBufSize = 1024;                  // == db::kReadBufMinSize
    static constexpr uint64_t kHeader = db::kLogHeaderSize;
    static constexpr uint64_t kDirectSize = kBufSize * 2 / 3;   // >= it bypasses the buffer

    void SetUp() {}
    void TearDown() {}

    // A deterministic image so the served bytes can be checked.
    void MakeFile(size_t size) {
        _file.resize(size);
        for (size_t i = 0; i < size; ++i) {
            _file[i] = static_cast<char>((i * 131 + 17) & 0xff);
        }
    }

    // Read() of the fake block: serve [off, off + n) from the image, short at EOF.
    db::Status OnRead(uint64_t off, size_t n, base::Slice* result, char* dst) {
        ++_read_calls;
        _last_off = off;
        _last_n = n;
        size_t avail = 0;
        if (off < _file.size()) {
            avail = std::min<size_t>(n, _file.size() - off);
            std::memcpy(dst, _file.data() + off, avail);
        }
        *result = base::Slice(dst, avail);
        return db::Status();
    }

    std::shared_ptr<MockRandomAccessBlock> MakeRBlock(uint64_t fno) {
        auto rblock = std::make_shared<MockRandomAccessBlock>("test/fake.db", fno, -1, 0);
        EXPECT_CALL(*rblock, Read(_, _, _, _)).WillRepeatedly(
                Invoke([this](uint64_t off, size_t n, base::Slice* result, char* dst) {
                    return OnRead(off, n, result, dst);
                }));
        return rblock;
    }

    // The served bytes must be exactly file[off, off + len).
    void ExpectServed(uint64_t off, size_t len, const base::Slice& served) {
        ASSERT_EQ(served.size(), len);
        ASSERT_EQ(std::memcmp(served.data(), _file.data() + off, len), 0);
    }

    void ExpectRead(int calls, uint64_t off, size_t n) {
        ASSERT_EQ(_read_calls, calls);
        ASSERT_EQ(_last_off, off);
        ASSERT_EQ(_last_n, n);
    }

    std::string _file;
    int _read_calls = 0;
    uint64_t _last_off = 0;
    size_t _last_n = 0;
};

// The first read misses and refills one full buffer; the following reads are served
// from it; a header landing at the window end keeps the remainder and reads ahead a
// full buffer again.
TEST_F(AppendReadBufTests, test_get_buf_size_sequential) {
    MakeFile(8192);
    auto rblock = MakeRBlock(3);
    AppendReadBuf buf(kBufSize);
    char dst[8192];
    base::Slice served;

    ASSERT_TRUE(buf.GetBufSize(rblock, 100, kHeader, &served, dst).IsOk());
    ExpectServed(100, kHeader, served);
    ExpectRead(1, 100, kBufSize);

    ASSERT_TRUE(buf.GetBufSize(rblock, 100 + kHeader, 500, &served, dst).IsOk());
    ExpectServed(100 + kHeader, 500, served);
    ExpectRead(1, 100, kBufSize);

    ASSERT_TRUE(buf.GetBufSize(rblock, 100 + kHeader + 500, 296, &served, dst).IsOk());
    ExpectServed(100 + kHeader + 500, 296, served);
    ExpectRead(1, 100, kBufSize);

    // The cursor now sits 100 bytes before the window end: the header read moves the
    // leftover bytes to the front and reads the rest of a full buffer.
    const uint64_t cursor = 100 + kHeader + 500 + 296;        // 1024
    const uint64_t left = kBufSize - (kHeader + 500 + 296);   // 100
    ASSERT_TRUE(buf.GetBufSize(rblock, cursor, kHeader, &served, dst).IsOk());
    ExpectServed(cursor, kHeader, served);
    ExpectRead(2, cursor + left, kBufSize - left);

    ASSERT_TRUE(buf.GetBufSize(rblock, cursor + kHeader, 200, &served, dst).IsOk());
    ExpectServed(cursor + kHeader, 200, served);
    ExpectRead(2, cursor + left, kBufSize - left);
    END_OF_CASE;
}

TEST_F(AppendReadBufTests, test_skip_zero) {
    MakeFile(8192);
    auto rblock = MakeRBlock(3);
    AppendReadBuf buf(kBufSize);
    char dst[8192];
    base::Slice served;

    ASSERT_TRUE(buf.GetBufSize(rblock, 100, kHeader, &served, dst).IsOk());
    ExpectServed(100, kHeader, served);
    ExpectRead(1, 100, kBufSize);

    buf.Skip(0);
    const uint64_t off = 100 + kHeader;
    ASSERT_TRUE(buf.GetBufSize(rblock, off, kHeader, &served, dst).IsOk());
    ExpectServed(off, kHeader, served);
    ExpectRead(1, 100, kBufSize);
    END_OF_CASE;
}

TEST_F(AppendReadBufTests, test_skip_within_buf) {
    MakeFile(8192);
    auto rblock = MakeRBlock(3);
    AppendReadBuf buf(kBufSize);
    char dst[8192];
    base::Slice served;

    ASSERT_TRUE(buf.GetBufSize(rblock, 100, kHeader, &served, dst).IsOk());
    ExpectServed(100, kHeader, served);
    ExpectRead(1, 100, kBufSize);

    buf.Skip(500);
    const uint64_t off = 100 + kHeader + 500;
    ASSERT_TRUE(buf.GetBufSize(rblock, off, kHeader, &served, dst).IsOk());
    ExpectServed(off, kHeader, served);
    ExpectRead(1, 100, kBufSize);
    END_OF_CASE;
}

TEST_F(AppendReadBufTests, test_skip_to_buf_end) {
    MakeFile(8192);
    auto rblock = MakeRBlock(3);
    AppendReadBuf buf(kBufSize);
    char dst[8192];
    base::Slice served;

    ASSERT_TRUE(buf.GetBufSize(rblock, 100, kHeader, &served, dst).IsOk());
    ExpectServed(100, kHeader, served);
    ExpectRead(1, 100, kBufSize);

    buf.Skip(kBufSize - kHeader);
    const uint64_t off = 100 + kBufSize;
    ASSERT_TRUE(buf.GetBufSize(rblock, off, kHeader, &served, dst).IsOk());
    ExpectServed(off, kHeader, served);
    ExpectRead(2, off, kBufSize);
    END_OF_CASE;
}

TEST_F(AppendReadBufTests, test_skip_beyond_buf) {
    MakeFile(8192);
    auto rblock = MakeRBlock(3);
    AppendReadBuf buf(kBufSize);
    char dst[8192];
    base::Slice served;

    ASSERT_TRUE(buf.GetBufSize(rblock, 100, kHeader, &served, dst).IsOk());
    ExpectServed(100, kHeader, served);
    ExpectRead(1, 100, kBufSize);

    const uint64_t skip = kBufSize + 500;
    buf.Skip(skip);
    const uint64_t off = 100 + kHeader + skip;
    ASSERT_TRUE(buf.GetBufSize(rblock, off, kHeader, &served, dst).IsOk());
    ExpectServed(off, kHeader, served);
    ExpectRead(2, off, kBufSize);
    END_OF_CASE;
}

// A data read straddling the window end: the leftover bytes are flushed into dst and
// the rest comes from a refilled buffer (the remainder stays at the buffer front).
TEST_F(AppendReadBufTests, test_get_buf_size_straddle) {
    MakeFile(8192);
    auto rblock = MakeRBlock(3);
    AppendReadBuf buf(kBufSize);
    char dst[8192];
    base::Slice served;

    ASSERT_TRUE(buf.GetBufSize(rblock, 0, kHeader, &served, dst).IsOk());
    ExpectServed(0, kHeader, served);
    ASSERT_TRUE(buf.GetBufSize(rblock, kHeader, 800, &served, dst).IsOk());
    ExpectServed(kHeader, 800, served);
    ExpectRead(1, 0, kBufSize);

    // 96 bytes are left in the window, the read needs 400
    const uint64_t off = kBufSize - 96;
    const uint64_t left = kBufSize - off;
    ASSERT_TRUE(buf.GetBufSize(rblock, off, 400, &served, dst).IsOk());
    ExpectServed(off, 400, served);
    ExpectRead(2, off + left, kBufSize - left);
    END_OF_CASE;
}

// A read at or above 2/3 of the buffer bypasses it and reads exactly `size` into dst.
TEST_F(AppendReadBufTests, test_get_buf_size_direct) {
    MakeFile(8192);
    auto rblock = MakeRBlock(3);
    AppendReadBuf buf(kBufSize);
    char dst[8192];
    base::Slice served;

    ASSERT_TRUE(buf.GetBufSize(rblock, 100, kHeader, &served, dst).IsOk());
    ExpectServed(100, kHeader, served);
    ExpectRead(1, 100, kBufSize);

    // Above the threshold (682) the buffer is bypassed: exactly `size` is read.
    const size_t direct = kDirectSize + 18;   // 700
    ASSERT_TRUE(buf.GetBufSize(rblock, 5000, direct, &served, dst).IsOk());
    ExpectServed(5000, direct, served);
    ExpectRead(2, 5000, direct);

    // the buffer was dropped, the next read refills it
    ASSERT_TRUE(buf.GetBufSize(rblock, 5700, kHeader, &served, dst).IsOk());
    ExpectServed(5700, kHeader, served);
    ExpectRead(3, 5700, kBufSize);
    END_OF_CASE;
}

// read_ahead=false: the buffer is still used when it already covers the range, but
// nothing is read ahead -- every disk read is exactly the requested size.
TEST_F(AppendReadBufTests, test_get_buf_size_no_read_ahead) {
    MakeFile(8192);
    auto rblock = MakeRBlock(3);
    AppendReadBuf buf(kBufSize);
    char dst[8192];
    base::Slice served;

    ASSERT_TRUE(buf.GetBufSize(rblock, 100, kHeader, &served, dst, false).IsOk());
    ExpectServed(100, kHeader, served);
    ExpectRead(1, 100, kHeader);

    ASSERT_TRUE(buf.GetBufSize(rblock, 228, kHeader, &served, dst, false).IsOk());
    ExpectServed(228, kHeader, served);
    ExpectRead(2, 228, kHeader);

    // one read ahead, then served back from the buffer without any disk read
    ASSERT_TRUE(buf.GetBufSize(rblock, 356, 100, &served, dst).IsOk());
    ExpectServed(356, 100, served);
    ExpectRead(3, 356, kBufSize);

    ASSERT_TRUE(buf.GetBufSize(rblock, 456, 800, &served, dst, false).IsOk());
    ExpectServed(456, 800, served);
    ExpectRead(3, 356, kBufSize);

    // 124 bytes are left in the window: branch 2 reads only the missing 4 bytes
    const uint64_t off = 456 + 800;
    const uint64_t left = kBufSize - 100 - 800;
    ASSERT_TRUE(buf.GetBufSize(rblock, off, kHeader, &served, dst, false).IsOk());
    ExpectServed(off, kHeader, served);
    ExpectRead(4, off + left, kHeader - left);

    ASSERT_TRUE(buf.GetBufSize(rblock, off + kHeader, 300, &served, dst, false).IsOk());
    ExpectServed(off + kHeader, 300, served);
    ExpectRead(5, off + kHeader, 300);
    END_OF_CASE;
}

// A short read at EOF keeps the read position at `off`: the caller retries and the
// bytes already read come from the buffer instead of being read again.
TEST_F(AppendReadBufTests, test_get_buf_size_short_read) {
    MakeFile(2000);
    auto rblock = MakeRBlock(3);
    AppendReadBuf buf(kBufSize);
    char dst[8192];
    base::Slice served;

    ASSERT_TRUE(buf.GetBufSize(rblock, 1900, kHeader, &served, dst).IsOk());
    ExpectServed(1900, 100, served);
    ExpectRead(1, 1900, kBufSize);

    ASSERT_TRUE(buf.GetBufSize(rblock, 1900, kHeader, &served, dst).IsOk());
    ExpectServed(1900, 100, served);
    ExpectRead(2, 2000, kBufSize - 100);

    // a direct read (>= 2/3 of the buffer) that is short at EOF keeps it as well:
    // 100 bytes come from the buffer, the other 700 hit EOF
    ASSERT_TRUE(buf.GetBufSize(rblock, 1900, 800, &served, dst).IsOk());
    ExpectServed(1900, 100, served);
    ExpectRead(3, 2000, 700);
    END_OF_CASE;
}

// A request larger than the read-ahead buffer must still be served in full: the
// buffer can only ever hold _read_buf_size bytes, so the part that does not fit has
// to be read directly. A log block's data can exceed the buffer (up to ~512KB vs the
// 128KB recover buffer), so the recover path relies on this.
TEST_F(AppendReadBufTests, test_get_buf_size_larger_than_buf) {
    MakeFile(8192);
    auto rblock = MakeRBlock(3);
    AppendReadBuf buf(kBufSize);
    char dst[8192];
    base::Slice served;

    ASSERT_TRUE(buf.GetBufSize(rblock, 0, kHeader, &served, dst).IsOk());
    ExpectServed(0, kHeader, served);
    ExpectRead(1, 0, kBufSize);

    // 1500 > kBufSize: 896 bytes are still buffered, the remaining 604 do not fit.
    const uint64_t off = kHeader;
    ASSERT_TRUE(buf.GetBufSize(rblock, off, 1500, &served, dst).IsOk());
    ExpectServed(off, 1500, served);
    END_OF_CASE;
}

// Switching to another block file invalidates the buffer (it is keyed by file_no).
TEST_F(AppendReadBufTests, test_get_buf_size_block_switch) {
    MakeFile(4096);
    auto rblock3 = MakeRBlock(3);
    auto rblock4 = MakeRBlock(4);
    AppendReadBuf buf(kBufSize);
    char dst[8192];
    base::Slice served;

    ASSERT_TRUE(buf.GetBufSize(rblock3, 100, kHeader, &served, dst).IsOk());
    ExpectServed(100, kHeader, served);
    ExpectRead(1, 100, kBufSize);

    // another block file: the buffered window cannot be used
    ASSERT_TRUE(buf.GetBufSize(rblock4, 100, kHeader, &served, dst).IsOk());
    ExpectServed(100, kHeader, served);
    ExpectRead(2, 100, kBufSize);

    ASSERT_TRUE(buf.GetBufSize(rblock3, 228, kHeader, &served, dst).IsOk());
    ExpectServed(228, kHeader, served);
    ExpectRead(3, 228, kBufSize);
    END_OF_CASE;
}

// Init() clamps a too small buffer up to db::kReadBufMinSize.
TEST_F(AppendReadBufTests, test_init_min_size) {
    MakeFile(8192);
    auto rblock = MakeRBlock(3);
    AppendReadBuf buf(1);
    char dst[8192];
    base::Slice served;

    ASSERT_TRUE(buf.GetBufSize(rblock, 100, kHeader, &served, dst).IsOk());
    ExpectServed(100, kHeader, served);
    ExpectRead(1, 100, db::kReadBufMinSize);
    END_OF_CASE;
}

// A failing read is reported to the caller from every read site of GetBufSize.
TEST_F(AppendReadBufTests, test_get_buf_size_read_error) {
    MakeFile(8192);
    char dst[8192];
    base::Slice served;

    // the refill read fails
    {
        auto rblock = std::make_shared<MockRandomAccessBlock>("test/fake.db", 3, -1, 0);
        EXPECT_CALL(*rblock, Read(_, _, _, _))
                .WillOnce(Return(db::Status(db::Code::kIOError, "boom")));
        AppendReadBuf buf(kBufSize);
        auto st = buf.GetBufSize(rblock, 100, kHeader, &served, dst);
        ASSERT_TRUE(st.IsIOError());
    } END_OF_CASE;

    // the direct read fails
    {
        auto rblock = std::make_shared<MockRandomAccessBlock>("test/fake.db", 3, -1, 0);
        EXPECT_CALL(*rblock, Read(_, _, _, _))
                .WillOnce(Return(db::Status(db::Code::kIOError, "boom")));
        AppendReadBuf buf(kBufSize);
        auto st = buf.GetBufSize(rblock, 100, 700, &served, dst);
        ASSERT_TRUE(st.IsIOError());
    } END_OF_CASE;

    // the header read of branch 2 fails
    {
        auto rblock = std::make_shared<MockRandomAccessBlock>("test/fake.db", 3, -1, 0);
        EXPECT_CALL(*rblock, Read(_, _, _, _))
                .WillOnce(Invoke([this](uint64_t off, size_t n, base::Slice* result, char* d) {
                    return OnRead(off, n, result, d);
                }))
                .WillOnce(Return(db::Status(db::Code::kIOError, "boom")));
        AppendReadBuf buf(kBufSize);
        ASSERT_TRUE(buf.GetBufSize(rblock, 100, kHeader, &served, dst).IsOk());
        ASSERT_TRUE(buf.GetBufSize(rblock, 228, 896, &served, dst).IsOk());
        auto st = buf.GetBufSize(rblock, 1124, kHeader, &served, dst);
        ASSERT_TRUE(st.IsIOError());
    } END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_recover_start_seek_by_anchor) {
    FLAGS_psvr_append_seek_anchor_chunk_size = 1UL << 20;
    std::vector<uint64_t> starts;
    std::vector<uint64_t> offs;
    BuildSealedBlock(50, 1000, &starts, &offs);

    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    ASSERT_TRUE(_append_db->SetCheckPointLsn(starts[30], 0, false).IsOk());
    ASSERT_TRUE(_append_db->Close().IsOk());

    AppendDBEngine engine;
    ASSERT_TRUE(engine.Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    ASSERT_EQ(checkpoint_lsn, starts[30]);
    ASSERT_NE(engine._recover_info, nullptr);
    ASSERT_EQ(engine._recover_info->seek_off, offs[30]);
    ASSERT_TRUE(engine.Close().IsOk());
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_recover_start_seek_block_start) {
    FLAGS_psvr_append_seek_anchor_chunk_size = 1UL << 20;
    std::vector<uint64_t> starts;
    std::vector<uint64_t> offs;
    BuildSealedBlock(8, 1000, &starts, &offs);

    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    ASSERT_TRUE(_append_db->Close().IsOk());

    AppendDBEngine engine;
    ASSERT_TRUE(engine.Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    ASSERT_EQ(checkpoint_lsn, starts[0]);
    ASSERT_NE(engine._recover_info, nullptr);
    ASSERT_EQ(engine._recover_info->seek_off, db::kBlockHeaderSize);
    ASSERT_TRUE(engine.Close().IsOk());
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_fetch_redo_log_seek_by_anchor) {
    FLAGS_psvr_append_seek_anchor_chunk_size = 1UL << 20;
    std::vector<uint64_t> starts;
    std::vector<uint64_t> offs;
    BuildSealedBlock(50, 1000, &starts, &offs);

    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());

    const std::vector<uint32_t> indexes = {0, 1, 25, 30};
    for (const auto idx : indexes) {
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        char* data = nullptr;
        uint64_t fno = 0;
        uint64_t offset = 0;
        ASSERT_TRUE(_append_db->FetchRedoLog(starts[idx], &header, &key, &value, &data,
                fno, offset, nullptr).IsOk());
        ASSERT_EQ(header.start_lsn, starts[idx]);
        ASSERT_EQ(fno, 1);
        ASSERT_EQ(offset, offs[idx] + db::kLogHeaderSize + key.size() + value.size());
        free(data);
    }
    ASSERT_TRUE(_append_db->Close().IsOk());
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_recover_start_seek_anchor_probe_failed) {
    FLAGS_psvr_append_seek_anchor_chunk_size = 1UL << 20;
    std::vector<uint64_t> starts;
    std::vector<uint64_t> offs;
    BuildSealedBlock(50, 1000, &starts, &offs);

    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    ASSERT_TRUE(_append_db->SetCheckPointLsn(starts[2], 0, false).IsOk());
    ASSERT_TRUE(_append_db->Close().IsOk());

    const std::string path = _data_path + "/db/1.db";
    const uint64_t file_size = std::filesystem::file_size(path);
    const uint64_t data_end = file_size - db::kBlockFooterSize;
    const uint64_t zero_off = 1UL << 20;
    ASSERT_GT(data_end, zero_off);
    std::vector<char> zeros(data_end - zero_off, 0);
    int fd = open(path.c_str(), O_RDWR);
    ASSERT_GE(fd, 0);
    ASSERT_TRUE(db::pwritex(fd, zeros.data(), zeros.size(), zero_off).IsOk());
    close(fd);

    AppendDBEngine engine;
    ASSERT_TRUE(engine.Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    ASSERT_EQ(checkpoint_lsn, starts[2]);
    ASSERT_NE(engine._recover_info, nullptr);
    ASSERT_EQ(engine._recover_info->seek_off, offs[2]);
    ASSERT_TRUE(engine.Close().IsOk());
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_recover_start_seek_fake_anchor) {
    FLAGS_psvr_append_seek_anchor_chunk_size = 6UL << 20;
    std::vector<uint64_t> starts;
    std::vector<uint64_t> offs;
    BuildSealedBlock(50, 1000, &starts, &offs);

    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    ASSERT_TRUE(_append_db->SetCheckPointLsn(starts[30], 0, false).IsOk());
    ASSERT_TRUE(_append_db->Close().IsOk());

    const std::string path = _data_path + "/db/1.db";
    const uint64_t fake_off = db::kBlockHeaderSize + (6UL << 20);
    db::LogHeader fake;
    fake.magic = db::kLogHeaderMagic;
    fake.proto_version = db::kLogHeaderVserion;
    fake.start_lsn = starts[0];
    fake.end_lsn = starts[1];
    fake.key_size = 16;
    fake.value_size = 16;
    db::make_checksum(&fake, db::kLogHeaderSize);
    int fd = open(path.c_str(), O_RDWR);
    ASSERT_GE(fd, 0);
    ASSERT_TRUE(db::pwritex(fd, &fake, db::kLogHeaderSize, fake_off).IsOk());
    close(fd);

    AppendDBEngine engine;
    ASSERT_TRUE(engine.Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    ASSERT_EQ(checkpoint_lsn, starts[30]);
    ASSERT_NE(engine._recover_info, nullptr);
    ASSERT_EQ(engine._recover_info->seek_off, offs[30]);
    ASSERT_TRUE(engine.Close().IsOk());
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_recover_start_seek_slot_narrow) {
    FLAGS_psvr_append_file_block_size = 32UL << 20;
    FLAGS_psvr_append_seek_anchor_chunk_size = 256UL << 10;
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    _append_db->Init(1000);

    std::vector<uint64_t> starts;
    std::vector<uint64_t> offs;
    uint64_t lsn = 1000;
    for (uint32_t i = 0; i < 20; ++i) {
        auto lb = create_log_block(lsn, lsn + 10, true, 0, false, 200 << 10);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(lb, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        ASSERT_TRUE(_append_db->Append(header, key, value, &fno, &off, false).IsOk());
        starts.push_back(header.start_lsn);
        offs.push_back(off);
        lsn += 10;
    }
    ASSERT_TRUE(_append_db->SetCheckPointLsn(starts[10], starts[10], false).IsOk());
    ASSERT_TRUE(_append_db->Close().IsOk());

    AppendDBEngine engine;
    ASSERT_TRUE(engine.Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    ASSERT_EQ(checkpoint_lsn, starts[10]);
    ASSERT_NE(engine._recover_info, nullptr);
    ASSERT_EQ(engine._recover_info->seek_off, offs[10]);
    ASSERT_TRUE(engine.Close().IsOk());
    END_OF_CASE;
}

TEST_F(AppendDBEngineTests, test_recover_start_seek_slot_near) {
    FLAGS_psvr_append_file_block_size = 8UL << 20;
    FLAGS_psvr_append_seek_anchor_chunk_size = 64UL << 10;
    std::filesystem::create_directory(_dir / "psvr_test/db");
    gaia_apply::lsn_t checkpoint_lsn = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    ASSERT_TRUE(_append_db->Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    _append_db->Init(1000);

    std::vector<uint64_t> starts;
    std::vector<uint64_t> offs;
    uint64_t lsn = 1000;
    for (uint32_t i = 0; i < 40; ++i) {
        auto lb = create_log_block(lsn, lsn + 10, true, 0, false, 20 << 10);
        db::LogHeader header;
        base::Slice key;
        base::Slice value;
        CreateAppendLog(lb, &header, &key, &value);
        uint64_t fno = 0;
        uint64_t off = 0;
        ASSERT_TRUE(_append_db->Append(header, key, value, &fno, &off, false).IsOk());
        starts.push_back(header.start_lsn);
        offs.push_back(off);
        lsn += 10;
    }
    ASSERT_TRUE(_append_db->SetCheckPointLsn(starts[18], starts[18], false).IsOk());
    ASSERT_TRUE(_append_db->Close().IsOk());

    AppendDBEngine engine;
    ASSERT_TRUE(engine.Open(_data_path, 0, &checkpoint_lsn, &max_apply_lsn).IsOk());
    ASSERT_EQ(checkpoint_lsn, starts[18]);
    ASSERT_NE(engine._recover_info, nullptr);
    ASSERT_EQ(engine._recover_info->seek_off, offs[18]);
    ASSERT_TRUE(engine.Close().IsOk());
    END_OF_CASE;
}

}
}
