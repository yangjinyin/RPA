/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/compress.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/common.h"
#include "psvr/model.h"
#include "psvr/segment.h"
#include "psvr/thread_pool.hpp"

namespace psvr {

class Compressor;
using CompressorPtr = std::shared_ptr<Compressor>;

class Compressor : public Model<Compressor> {
public:
struct Context;
struct TrimFreeExtentTask;

enum class Action {
    kCalcPriority = 1,
    kStoreCompress,
    kCompressSegment,
    kCalcPriorityForFreeExtent,
    kTrimFreeExtent,
};

private:
struct Task;
struct Store;

using QuotaThreadType = QuotaThread<Context*, std::shared_ptr<FlowQuota>>;
using QuotaThreadTypePtr = std::shared_ptr<QuotaThreadType>;
using ThreadPoolType = ThreadPoolExecutor<Context, thread::TaskContext>;
using ThreadPoolTypePtr = std::shared_ptr<ThreadPoolType>;

public:
    Compressor(ClientPtr client, ControlWeakPtr control);
    FUNC_MOCK ~Compressor() {
        if (!_stopped) {
            Stop();
        }
    }

    virtual bool SetUp() override;
    virtual bool PrepareTask() override;
    virtual void TearDown() override;
    virtual void Join() override;

    bool IncOrDecThreadNum();

    double GetCompressRate();
    double GetStoreCompressRate(int32_t store_id);

    void GetTasks(pspb::ListCompressSegmentResponse* response);
    bool AddSegmentToCompressList(SegmentPtr segment, bool is_prior = false);
    bool DropSegmentFromCompressList(SegmentPtr segment);

    FUNC_MOCK bool Execute(Context* ctx);
private:
    void Expose();
    void SetCtxClientId(Context* ctx);
    void Schedule(Context* ctx TRACE_FILE_LINE_DC, uint64_t delay_us = 0, bool is_retry = false);
    void OnCompletion(Context* ctx);

    void CalcPriority(Context* ctx);
    void StoreCompress(Context* ctx);

    bool CheckQuota(Context* ctx, int32_t store_id);
    void OnGetQuota(Context* ctx);
    void OnEvent(Context* ctx, uint32_t space_id);

    void FinishCompressSegment(Context* ctx, bool succ);
    void CompressSegment(Context* ctx);

    void CalcPriorityForFreeExtent(Context* ctx);
    void TrimFreeExtent(Context* ctx);
    void FinishTrimFreeExtent(Context* ctx, bool succ = false);

private:
    uint32_t _thread_num;
    ThreadPoolTypePtr _thread_pool;
    QuotaThreadTypePtr _quota_thread;
    std::shared_ptr<FlowQuota> _flow;
    std::vector<std::shared_ptr<Store>> _stores;
    std::shared_ptr<TrimFreeExtentTask> _trim_free_extent_task;
    // Stat
    StatLatency _stat_compress_segment_lat;
    bvar::PassiveStatus<double> _stat_compress_segment_rate;
    StatSize _stat_compress_segment_size;
    StatSize _stat_compress_segment_valid_page_size;
    StatLatency _stat_compress_page_lat;
    StatLatency _stat_trim_free_extent_lat;
    StatCount _stat_compress_page_error_count;
    StatCount _stat_compress_interrupt_by_quota_count;
};

bool operator>=(std::shared_ptr<FlowQuota> quota, Compressor::Context* ctx);

}
