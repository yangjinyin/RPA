/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file tools/src/checksum_read_file.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <sys/ioctl.h>
#include <termios.h>
#include <algorithm>
#include <atomic>
#include <filesystem>
#include <fstream>
#include <limits>
#include <memory>
#include <mutex>
#include <sys/stat.h>
#include <thread>
#define __SYSMACROS_DEPRECATED_INCLUSION
#include <sys/sysmacros.h>
#include <baidu/rpc/server.h>
#include <gaiadb/utils/ut.h>
#include <psvr/version.h>
#include "psvr/common.h"
#include "psvr/utils.h"
#include "psvr/option.h"
#include "psvr/page_op.h"
#include "psvr/compress_utils.h"
#include "psvr/rlimit.h"
#include "psvr/rpc_client.hpp"
#include "psvr/psminfo.h"
#include "psvr/quota.h"
#include "psvr/stat.h"
#include "psvr/thread_pool.hpp"

namespace psvr {

#define PAGE_SIZE (16*1024lu)
#define EXTENT_SIZE (1lu<<20)
#define DEFAULT_SEG_EXTENT_NUM 32768
#define MAX_RETRY_TIMES 3u
#define MAX_RPC_RETRY_TIMES 10u
#define LINK_BUF_CAPACITY 2097152

class ToolLogSink : public logging::LogSink {
public:

virtual bool OnLogMessage(int, const char*, int, const base::StringPiece&) override {
    // ignore logs data
    return true;
}

};

class ChecksumReadFile;
struct Buf;

int32_t test_ChecksumReadFile();

struct ReadContext : public psvr::thread::TaskContext {
    uint64_t off;
    uint64_t size;
    psvr::Timer timer;
    gaia_apply::byte* mem;
    Buf* link_buf;
    std::atomic<uint64_t>* refresh_node;
    uint32_t retry_times;

    ReadContext(uint64_t _off, uint64_t _size)
        : off(_off), size(_size), timer(base::Timer::STARTED),
        mem(nullptr), link_buf(nullptr), refresh_node(nullptr),
        retry_times(0) {}
};

class ChecksumReadFile {
friend int32_t test_ChecksumReadFile();
public:
    ChecksumReadFile() {}
    virtual ~ChecksumReadFile() {}

    const char* description() {
        return "read file content to stdout, err to stderr, and check content data if file is idb type";
    }

    void help() {
        printf("Usage:  gaiatool ChecksumReadFile [OPTION]...\n");
        printf("%s.\n", description());
        printf("  %-40s %s\n", "-f --file (file_path)", "ibd file path name");
        printf("  %-40s %s\n", "-o --offset (uint64_t)", "ibd file check start offset");
        printf("  %-40s %s\n", "-b --buf (uint64_t)", "read max size, unit is MB");
        printf("  %-40s %s\n", "--rlim-max (uint64_t)", "use virt memory max size, unit is MB");
        printf("  %-40s %s\n", "--rlim-cur (uint64_t)", "use virt memory current size, unit is MB");
        printf("  %-40s %s\n", "-M --manager-address (string)", "the cluster manager address, like: bns://gaiadbxxxxx-0000.gaia.all:8330");
        printf("  %-40s %s\n", "-c --cluster-id (string)", "the cluster id, like gaiadbxxxxx");
        printf("  %-40s %s\n", "-s --segment-id (uint32_t)", "the segment id");
        printf("  %-40s %s\n", "-l --backup-start-lsn (uint64_t)", "the backup start lsn");
        printf("  %-40s %s\n", "-t --timeout (uint32_t)", "rpc timeout, default 3000ms, unit is ms");
        printf("  %-40s %s\n", "-T --backup-timeout (uint32_t)", "backup task timeout, default 900s, unit is s");
        printf("  %-40s %s\n", "-q --quota (int64_t)", "rpc read flow control size, default 64MB, unit is MB");
        printf("  %-40s %s\n", "-d --debug", "show debug message to stderr");
        printf("  %-40s %s\n", "-p --port", "brpc service port for debug");
        printf("  %-40s %s\n", "-n --bthread-concurrency (uint32_t)",
                "bthread worker concurrency for brpc monitor server, default 2");
        printf("  %-40s %s\n", "-L --link-buf-capacity (uint64_t)",
                "link buffer capacity, unit is MB, default 2MB");
        printf("\nEXAMPLES\n");
        printf("  %s\n", "gaiatool ChecksumReadFile [--offset file_offset] [--buf buf_size_mb] [--file] file_path");
        printf("  %s\n", "gaiatool ChecksumReadFile [--offset file_offset] [--buf buf_size_mb] --manager-address bns_address --cluster-id cls_id --segment-id seg_id [--timeout ms] [--quota mb]");
    }

    const struct option* options() {
        static struct option options[] = {
            {"help", 1, NULL, 'h'},
            {"file", 1, NULL, 'f'},
            {"offset", 1, NULL, 'o'},
            {"buf", 1, NULL, 'b'},
            {"hard-memory-limit", 1, &long_opt_val, 1},
            {"soft-memory-limit", 1, &long_opt_val, 2},
            {"manager-address", 1, NULL, 'M'},
            {"cluster-id", 1, NULL, 'c'},
            {"segment-id", 1, NULL, 's'},
            {"backup-start-lsn", 1, NULL, 'l'},
            {"timeout", 1, NULL, 't'},
            {"backup-timeout", 1, NULL, 'T'},
            {"quota", 1, NULL, 'q'},
            {"debug", 0, NULL, 'd'},
            {"port", 1, NULL, 'p'},
            {"bthread-concurrency", 1, NULL, 'n'},
            {"link-buf-capacity", 1, NULL, 'L'},
            PSVR_ARGS_OPTION_END
        };
        return options;
    }

    int Parser(int ch, const char* opt) {
        switch(ch) {
        case 'f':
            _file_name = opt;
            break;
        case 'o':
            _offset = std::strtoull(opt, nullptr, 10);
            break;
        case 'b':
            _max_read_size = MBToByte(std::strtoull(opt, nullptr, 10));
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id = std::strtoul(opt, nullptr, 10);
            break;
        case 'l':
            _backup_start_lsn = std::strtoull(opt, nullptr, 10);
            break;
        case 't':
            _timeout_ms = std::strtoul(opt, nullptr, 10);
            break;
        case 'T':
            _backup_timeout_s = std::strtoul(opt, nullptr, 10);
            break;
        case 'q':
            _quota = std::strtoll(opt, nullptr, 10) * 1024 * 1024;
            break;
        case 'd':
            _debug = true;
            break;
        case 'p':
            _port = std::strtoll(opt, nullptr, 10);
            break;
        case 'n':
            _bthread_concurrency = std::strtoul(opt, nullptr, 10);
            break;
        case 'L':
            _link_buf_capacity = MBToByte(std::strtoull(opt, nullptr, 10));
            break;
        case 0:
            switch (long_opt_val) {
            case 1:
                _rlim_max = MBToByte(std::strtoull(opt, nullptr, 10));
                break;
            case 2:
                _rlim_cur = MBToByte(std::strtoull(opt, nullptr, 10));
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    int Run();

    int SetFileName(const char* file_name) {
        if (_file_name.empty()) {
            _file_name = file_name;
            return 0;
        }

        fprintf(stderr, "Error, duplicate set file name\n");
        return 1;
    }

private:
    bool GetSegmentSize(std::vector<base::EndPoint>* seg_nodes, uint64_t* segment_size);
    bool GetSegmentNodes(std::vector<base::EndPoint>* seg_nodes, uint64_t* segment_size);
    void Read(ReadContext* ctx);
    int Remote();

private:
    volatile bool _stopped {false};
    int64_t _start_time {0};
    std::string _file_name {};
    inline static int long_opt_val {0};
    uint64_t _offset {0};
    uint64_t _max_read_size {0};
    uint64_t _rlim_max {0};
    uint64_t _rlim_cur {0};
    std::atomic<uint32_t> _inflight_ctx_num {0};
    psvr::ThreadPoolExecutor<ReadContext, psvr::thread::TaskContext> _thread_pool {};
    PsmInfoPtr _psm_info {nullptr};
    std::string _manager_address {};
    std::string _cluster_id {};
    uint32_t _segment_id {0};
    uint64_t _backup_start_lsn {0};
    std::shared_mutex _shared_mutex {};
    std::vector<base::EndPoint> _segment_nodes {};
    uint32_t _timeout_ms {3000};
    int64_t _backup_timeout_s {900};
    psvr::RpcClient _rpc_client;
    int64_t _quota {67108864};
    std::string _err {};
    bool _debug {false};
    uint32_t _port {0};
    uint32_t _bthread_concurrency {2};
    uint64_t _link_buf_capacity {LINK_BUF_CAPACITY};
};

struct BufMem {
    size_t m_unit;
    size_t m_free_list_size;
    std::list<gaia_apply::byte*> m_free_list;
    std::map<uint64_t, gaia_apply::byte*> m_data_map;
    std::shared_mutex m_mutex;

    BufMem(size_t size) {
        m_unit = MBToByte(1);
        m_free_list_size = size / m_unit;
        for (size_t i = 0; i < m_free_list_size; ++i) {
            m_free_list.push_back(new gaia_apply::byte[m_unit]);
        }
    }

    ~BufMem() {
        while (m_free_list_size > 0) {
            delete[] m_free_list.back();
            m_free_list.pop_back();
            --m_free_list_size;
        }
        for (auto& it : m_data_map) {
            delete[] it.second;
        }
    }

    gaia_apply::byte* GetMem(uint64_t position) {
        gaia_apply::byte* mem = nullptr;
        {
            std::unique_lock lk(m_mutex);
            if (m_free_list_size > 0) {
                --m_free_list_size;
                mem = m_free_list.back();
                m_free_list.pop_back();
            }
        }
        if (!mem) {
            mem = new gaia_apply::byte[m_unit];
        }
        {
            std::unique_lock lk(m_mutex);
            m_data_map[position] = mem;
        }
        return mem;
    }

    gaia_apply::byte* Slot(uint64_t position) {
        std::unique_lock lk(m_mutex);
        return m_data_map[position];
    }

    void PutMem(uint64_t end_position) {
        std::unique_lock lk(m_mutex);
        auto it = m_data_map.begin();
        while (it != m_data_map.end()) {
            if (it->first + m_unit > end_position) {
                break;
            }
            m_free_list.push_front(it->second);
            ++m_free_list_size;
            it = m_data_map.erase(it);
        }
    }

};

struct Buf {
    BufMem m_data;
    const size_t m_capacity;
    std::atomic<uint32_t> *m_links;
    alignas(BAIDU_CACHELINE_SIZE) std::atomic<uint64_t> m_tail;

    Buf(size_t buf_size) : m_data(buf_size), m_capacity(buf_size), m_tail(0) {
        assert((m_capacity & (m_capacity - 1)) == 0);
        m_links = new std::atomic<uint32_t>[m_capacity];
        for (size_t i = 0; i < m_capacity; ++i) {
            m_links[i].store(0, std::memory_order_relaxed);
        }
        std::atomic_thread_fence(std::memory_order_release);
    }
    ~Buf() {
        delete [] m_links;
    }

    void reset_tail(uint64_t position) {
        for (size_t i = 0; i < m_capacity; ++i) {
            m_links[i].store(0, std::memory_order_relaxed);
        }
        m_tail.store(position);
    }

    bool has_space(uint64_t position) {
        auto tail = m_tail.load();
        if (tail + m_capacity > position) {
            return true;
        }
        return false;
    }

    gaia_apply::byte* alloc_space_buf(uint64_t position) {
        return m_data.GetMem(position);
    }

    size_t slot_index(uint64_t position) {
        return (position) & (m_capacity - 1);
    }

    void add_link(uint64_t from, uint64_t to) {
        assert(to > from);
        assert(to - from <= std::numeric_limits<uint64_t>::max());
        const auto index = slot_index(from);
        auto &slot = m_links[index];
        slot.store(to - from);
    }

    bool next_position(uint64_t position, uint64_t &next) {
        const auto index = slot_index(position);
        auto &slot = m_links[index];
        const auto distance = slot.load();
        assert(position < std::numeric_limits<uint64_t>::max() - distance);
        next = position + distance;
        return distance == 0;
    }

    void claim_position(uint64_t position) {
        const auto index = slot_index(position);
        auto &slot = m_links[index];
        slot.store(0);
    }

    template<typename StopCondition>
    bool advance_tail_until(StopCondition stop_condition) {
        auto stop_fn = [this, &stop_condition](uint64_t from, uint64_t to) {
            return stop_condition(m_data.Slot(from), to - from, from);
        };

        auto position = m_tail.load(std::memory_order_acquire);
        while (true) {
            uint64_t next;

            bool stop = next_position(position, next);

            if (stop || stop_fn(position, next)) {
                break;
            }

            claim_position(position);

            position = next;
        }

        if (position > m_tail.load()) {
            m_tail.store(position);
            m_data.PutMem(position);
            return true;
        }

        return false;
    }
};

static bvar::LatencyRecorder stat_read_lat("gaiatool_read", psvr::kSlaWindowSize);
static psvr::StatBw stat_bw("gaiatool_write_buf_bw", psvr::kSlaWindowSize);
static psvr::StatCount stat_err_cnt("gaiatool_read_fail_count", psvr::kSlaWindowSize);
static psvr::StatCount stat_link_buf_full_cnt("gaiatool_linkbuf_full_count", psvr::kSlaWindowSize);
static psvr::StatCount stat_quota_limit_cnt("gaiatool_quota_limit_count", psvr::kSlaWindowSize);
static psvr::StatQps stat_make_read_context_qps("gaiatool_make_read_qps", psvr::kSlaWindowSize);

bool ChecksumReadFile::GetSegmentSize(std::vector<base::EndPoint>* seg_nodes, uint64_t* segment_size) {
    std::vector<base::EndPoint> nodes;
    if (!_psm_info->GetOrRefreshNodes(&nodes)) {
        _err.assign("get manager nodes failed");
        return false;
    }
    psvr::RpcStatus status;
    gaiapb::ListSegmentRequest request;
    gaiapb::ListSegmentResponse response;
    request.set_cluster_id(_cluster_id);
    for (size_t i = 0; i < nodes.size(); ++i) {
        _rpc_client.Call(get_log_id(), nodes[i], &gaiapb::QueryService_Stub::list_segment, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && response.status().code() == gaiadb::GIE_OK) {
            bool got = false;
            for (auto& seg : response.segments()) {
                if (seg.segment_id() == _segment_id) {
                    got = true;
                    const uint32_t used_extent_size = seg.has_max_allocated_extent_no() ?
                        seg.max_allocated_extent_no() + 1 : seg.total_extent_num();
                    *segment_size = used_extent_size * EXTENT_SIZE;
                    for (auto& rep : seg.replica_addrs()) {
                        base::EndPoint ep;
                        base::str2endpoint(rep.c_str(), &ep);
                        seg_nodes->emplace_back(ep);
                    }
                    break;
                }
            }
            return got;
        }
    }
    _psm_info->SetFailed();
    _err.assign("get segment nodes from manager failed");
    return false;
}

/*
 * get the node list of segment id
 */
bool ChecksumReadFile::GetSegmentNodes(std::vector<base::EndPoint>* seg_nodes, uint64_t* segment_size) {
    std::vector<base::EndPoint> nodes;
    if (!_psm_info->GetOrRefreshNodes(&nodes)) {
        _err.assign("get manager nodes failed");
        return false;
    }
    psvr::RpcStatus status;
    gaiapb::GetSegmentRequest request;
    gaiapb::GetSegmentResponse response;
    request.set_cluster_id(_cluster_id);
    request.set_segment_id(_segment_id);
    for (size_t i = 0; i < nodes.size(); ++i) {
        _rpc_client.Call(get_log_id(), nodes[i], &gaiapb::QueryService_Stub::get_segment, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && response.status().code() == gaiadb::GIE_OK) {
            uint32_t max_extent_num = 0;
            for (auto& ps : response.page_servers()) {
                base::EndPoint ep;
                base::str2endpoint(ps.addr().c_str(), &ep);
                seg_nodes->emplace_back(ep);
                if (ps.has_max_extent_num()) {
                    max_extent_num = std::max(max_extent_num, ps.max_extent_num());
                }
            }
            _psm_info->MoveLeaderToFirst(i, nodes[i]);
            if (response.has_max_allocated_extent_no()) {
                max_extent_num = response.max_allocated_extent_no() + 1;
            } else if (max_extent_num == 0) {
                max_extent_num = DEFAULT_SEG_EXTENT_NUM;
            }
            *segment_size = max_extent_num * EXTENT_SIZE;
            return !seg_nodes->empty();
        }
    }
    _psm_info->SetFailed();
    _err.assign("get segment nodes from manager failed");
    return false;
}

void ChecksumReadFile::Read(ReadContext* ctx) {
    thread_local std::vector<base::EndPoint> segment_nodes {};
    thread_local uint64_t segment_version = 0;
    if (segment_nodes.empty() || segment_version != ctx->refresh_node->load()) {
        std::shared_lock slk(_shared_mutex);
        segment_nodes = _segment_nodes;
        segment_version = ctx->refresh_node->load();
    }

    psvr::RpcStatus status;
    pspb::ReadRequest request;
    pspb::ReadResponse response;

    request.set_cluster_id(_cluster_id);
    request.set_segment_id(_segment_id);
    request.set_offset(ctx->off);
    request.set_size(ctx->size);

    std::random_shuffle(segment_nodes.begin(), segment_nodes.end(), base::fast_rand_less_than);
    for (auto& ep : segment_nodes) {
        _rpc_client.Call(get_log_id(), ep, &pspb::QueryService_Stub::Read, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            continue;
        }
        const auto& rc = response.status().code();
        if (rc == pspb::Status::SUCCESS) {
            if (response.gc_lsn() < _backup_start_lsn) {
                continue;
            }

            const uint32_t calc_crc = gaiadb::common::ut_crc32(
                    reinterpret_cast<const gaia_apply::byte*>(response.data().c_str()), response.size());
            if (calc_crc != response.data_crc()) {
                continue;
            }

            const size_t read_size = response.size();
            assert(read_size == ctx->size);
            bool data_is_error = false;
            for (uint64_t check_off = 0; check_off < read_size; check_off += PAGE_SIZE) {
                bool is_empty = false;
                auto frame = reinterpret_cast<const gaia_apply::byte*>(response.data().c_str()) + check_off;
                if (psvr::page_is_corrupted(frame, PAGE_SIZE, &is_empty)) {
                    data_is_error = true;
                    break;
                }
                //if (_debug) {
                    //auto space_id = gaia_apply::page_get_space_id(frame);
                    //auto page_no = gaia_apply::page_get_page_no(frame);
                    //auto lsn = gaia_apply::mach_read_from_8(frame + gaia_apply::FIL_PAGE_LSN);
                    //fprintf(stderr, "off:%ld, space_id:%u, page_no:%u, lsn:%lu\n", ctx->off + check_off,
                            //space_id, page_no, lsn);
                //}
            }

            if (data_is_error) {
                continue;
            }

            std::unique_ptr<ReadContext> ctx_guard(ctx);
            if (!ctx->mem) {
                ctx->mem = ctx->link_buf->alloc_space_buf(ctx->off);
            }
            std::memcpy(ctx->mem, reinterpret_cast<const gaia_apply::byte*>(response.data().c_str()), read_size);
            ctx->link_buf->add_link(ctx->off, ctx->off + ctx->size);
            stat_read_lat << ctx->timer.u_elapsed();
            _inflight_ctx_num.fetch_sub(1);
            return;
        } else if (rc == pspb::Status::LIMIT) {
            break;
        }

        if (rc == pspb::Status::NOT_EXISTS) {
            ctx->refresh_node->compare_exchange_strong(segment_version, segment_version + 1);
        }
    }

    if (BAIDU_UNLIKELY(_stopped)) {
        delete ctx;
        _inflight_ctx_num.fetch_sub(1);
        return;
    }

    stat_err_cnt << 1;
    _thread_pool.Schedule(ctx, get_delay_us(++ctx->retry_times));
}

int ChecksumReadFile::Remote() {
    psvr::FlowQuota flow("gaiatool_quota", &_quota);
    if (_link_buf_capacity < EXTENT_SIZE || _link_buf_capacity % EXTENT_SIZE != 0) {
        fprintf(stderr, "Error, link buffer capacity:%lu size invalid\n", _link_buf_capacity);
        return 1;
    }
    if (_quota > 0 && static_cast<uint64_t>(_quota) < EXTENT_SIZE) {
        fprintf(stderr, "Error, flow quota:%ld size invalid\n", _quota);
        return 1;
    }

    struct MonitorServer {
        baidu::rpc::Server server;
        bool started {false};

        ~MonitorServer() {
            if (started) {
                server.Stop(0);
                server.Join();
            }
        }
    } monitor_server;

    if (_port > 0) {
        baidu::rpc::ServerOptions options;
        options.idle_timeout_sec = -1;
        options.num_threads = _bthread_concurrency;
        if (monitor_server.server.Start(_port, &options) != 0) {
            fprintf(stderr, "Error, start brpc monitor server on port:%d failed\n", _port);
            return 1;
        }
        monitor_server.started = true;
    }

    Buf link_buf(_link_buf_capacity);
    link_buf.reset_tail(_offset);

    _psm_info = std::make_shared<PsmInfo>(_manager_address);
    uint64_t segment_size = 0;
    for (uint32_t i = 0; i < MAX_RETRY_TIMES; ++i) {
        if (GetSegmentSize(&_segment_nodes, &segment_size)) {
            break;
        }
        sleep_for(second2microseconds(i + 1));
    }
    if (_segment_nodes.empty()) {
        fprintf(stderr, "Error, get segment_id:%u nodes failed, %s\n", _segment_id, _err.c_str());
        return 1;
    }

    if (_debug) {
        fprintf(stderr, "segment size:%lu, replicas num:%lu, quota:%ld\n",
                segment_size, _segment_nodes.size(), _quota);
    }

    if (segment_size == 0 && _offset == 0) {
        if (_debug) {
            fprintf(stderr, "segment size is zero, finish it");
        }
        return 0;
    }

    if (segment_size % PAGE_SIZE != 0) {
        fprintf(stderr, "Error, get segment_id:%u size:%lu invalid\n", _segment_id, segment_size);
        return 1;
    }

    if (_offset >= segment_size) {
        fprintf(stderr, "Error, offset:%lu over segment size:%lu\n", _offset, segment_size);
        return 1;
    }

    if (_max_read_size == 0 || _offset + _max_read_size > segment_size) {
        _max_read_size = segment_size - _offset;
    }

    typename thread::Executor<ReadContext, psvr::thread::TaskContext>::TaskFn fn
        = std::bind(&ChecksumReadFile::Read, this, std::placeholders::_1);
    if (!_thread_pool.Start("remote_read", 50, 2, true, fn)) {
        fprintf(stderr, "Error, thread pool start failed\n");
        return 1;
    }

    uint64_t segment_version = 0;
    std::atomic<uint64_t> refresh_node {segment_version};

    uint64_t last_write_off = _offset;
    auto write_data_fn = [&last_write_off](gaia_apply::byte* data, uint64_t size, uint64_t from) {
        assert(from == last_write_off);
        uint64_t write_n = fwrite(data, sizeof(gaia_apply::byte), size, stdout);
        while (write_n < size) {
            write_n += fwrite(data + write_n, sizeof(gaia_apply::byte), size - write_n, stdout);
        }
        last_write_off = from + size;
        stat_bw << size;
        return false;
    };

    int64_t last_show_time = base::cpuwide_time_s();
    auto show_fn = [this, &last_show_time](uint64_t rsize) {
        if (_debug) {
            const int64_t cur_time = base::cpuwide_time_s();
            if (cur_time - last_show_time < 2) {
                return;
            }
            last_show_time = cur_time;

            fprintf(stderr, "lat:%ld us, qps:%ld, bw:%ld, err_count:%u, file_size:%lu, read_size:%lu\r",
                    stat_read_lat.latency(), stat_read_lat.qps(), stat_bw.get_value(), stat_err_cnt.get_value(),
                    _max_read_size, rsize);
            fflush(stderr);
        }
    };

    auto release_fn = [this]() {
        while (_inflight_ctx_num.load() > 0) {
            sleep_for(millisecond2microseconds(50));
        }
        return 1;
    };

    uint32_t retry_n = 0;
    uint64_t read_size = 0;
    while (read_size < _max_read_size) {
        show_fn(link_buf.m_tail.load(std::memory_order_relaxed));
        size_t buf_size = MBToByte(1);
        if (_offset + read_size + buf_size > segment_size) {
            buf_size = segment_size - _offset - read_size;
        }
        PSVR_ASSERT(buf_size % PAGE_SIZE == 0);

        if (_backup_timeout_s && base::cpuwide_time_s() - _start_time > _backup_timeout_s) {
            _stopped = true;
            fprintf(stderr, "Error, task timeout:%ld, cost:%ld\n",
                    _backup_timeout_s, base::cpuwide_time_s() - _start_time);
            return release_fn();
        }

        if (segment_version != refresh_node.load()) {
            if (_debug) {
                fprintf(stderr, "refresh segment nodes, version:%lu\n", segment_version);
            }
            uint64_t tmp = 0;
            for (uint32_t i = 0; i < MAX_RETRY_TIMES; ++i) {
                std::vector<base::EndPoint> segment_nodes {};
                if (GetSegmentNodes(&segment_nodes, &tmp)) {
                    std::unique_lock lk(_shared_mutex);
                    _segment_nodes = segment_nodes;
                    segment_version = refresh_node.load();
                    break;
                }
                sleep_for(second2microseconds(i + 1));
            }
        }

        if (_quota > 0) {
            const uint64_t delay_us = flow.GetQuota(buf_size);
            if (delay_us > 0) {
                psvr::sleep_for(delay_us);
                stat_quota_limit_cnt << 1;
                continue;
            }
        }

        retry_n = 0;
        while (!link_buf.has_space(_offset + read_size)) {
            for (uint32_t i = 0; i < MAX_RETRY_TIMES; ++i) {
                if (link_buf.advance_tail_until(write_data_fn)) {
                    break;
                }
                stat_link_buf_full_cnt << 1;
                sleep_for(get_delay_us(++retry_n));
            }
        }

        stat_make_read_context_qps << 1;

        auto ctx = new ReadContext(_offset + read_size, buf_size);
        ctx->link_buf = &link_buf;
        ctx->refresh_node = &refresh_node;
        if (_thread_pool.Execute(ctx)) {
            _inflight_ctx_num.fetch_add(1);
            read_size += buf_size;
        } else {
            delete ctx;
        }
    }

    if (read_size < _max_read_size) {
        _stopped = true;
        fprintf(stderr, "Error, remote read total size:%lu small, expect:%lu \n", read_size, _max_read_size);
        return release_fn();
    }

    if (_debug) {
        fprintf(stderr, "wai async read contexts finish\n");
    }

    retry_n = 0;
    while (link_buf.m_tail.load() < _offset + _max_read_size) {
        if (!link_buf.advance_tail_until(write_data_fn)) {
            sleep_for(get_delay_us(++retry_n));
        }
        show_fn(link_buf.m_tail.load(std::memory_order_relaxed));
        if (_backup_timeout_s && base::cpuwide_time_s() - _start_time > _backup_timeout_s) {
            _stopped = true;
            fprintf(stderr, "Error, task timeout:%ld, cost:%ld\n",
                    _backup_timeout_s, base::cpuwide_time_s() - _start_time);
            return release_fn();
        }
    }

    if (link_buf.m_tail.load() < _offset + _max_read_size) {
        _stopped = true;
        fprintf(stderr, "Error, remote read total size:%lu small, expect:%lu \n", link_buf.m_tail.load(), _offset + _max_read_size);
        return release_fn();
    }

    fflush(stdout);
    return 0;
}

/*
 *  only write file data to stdout.
 *  write error msg to stderr;
 */
int ChecksumReadFile::Run() {
    _start_time = base::cpuwide_time_s();
    if (_rlim_max > 0 || _rlim_cur > 0) {
        int rc = set_memory_limit(_rlim_cur, _rlim_max);
        if (rc) {
            fprintf(stderr, "Error, set memory limit failed, rc:%d, err:%s\n",
                    rc, strerror(errno));
            return 1;
        }
    }

    const auto file_name_size = _file_name.size();
    if (!_manager_address.empty()) {
        if (file_name_size > 0) {
            fprintf(stderr, "Error, --file and --manager-address can not input at the same time\n");
            return 1;
        }
        if (_cluster_id.empty()) {
            fprintf(stderr, "Error, miss --cluster-id or is empty\n");
            return 1;
        }
        if (_segment_id == 0) {
            fprintf(stderr, "Error, miss --segment-id or is zero\n");
            return 1;
        }

        if (_backup_start_lsn == 0) {
            fprintf(stderr, "Error, miss --backup-start-lsn or is zero\n");
            return 1;
        }

        return Remote();
    }

    if (file_name_size < 1) {
        fprintf(stderr, "Error, miss --file or file name is empty\n");
        return 1;
    }

    auto check_is_ibd_file = [](const std::string& name, size_t size) -> bool {
        // suf name == '.ibd'
        return (size > 4
                && name[size - 4] == '.'
                && name[size - 3] == 'i'
                && name[size - 2] == 'b'
                && name[size - 1] == 'd');
    };

    const bool is_ibd_file = check_is_ibd_file(_file_name, file_name_size);
    if (is_ibd_file && (_offset % PAGE_SIZE != 0 || _max_read_size % PAGE_SIZE != 0)) {
        fprintf(stderr, "Error, read ibd file offset:%ld and buf:%ld must align PageSize(%ld)\n",
                _offset, _max_read_size, PAGE_SIZE);
        return 1;
    }

    int fd = open(_file_name.c_str(), O_RDONLY, 0644);
    if (fd < 0) {
        fprintf(stderr, "Error, open file failed, err:%s\n", strerror(errno));
        return 1;
    }

    std::shared_ptr<std::nullptr_t> guard_fp(nullptr, [&fd](std::nullptr_t) { close(fd); } );

    struct stat sbuf;
    if (fstat(fd, &sbuf) != 0) {
        fprintf(stderr, "Error, stat file failed, err:%s\n", strerror(errno));
        return 1;
    }

    const size_t file_size = sbuf.st_size;
    if (file_size == 0 && _offset == 0) {
        return 0;
    }

    if (_offset >= file_size) {
        fprintf(stderr, "Error, offset:%lu over file size:%lu\n", _offset, file_size);
        return 1;
    }

    if (_max_read_size == 0 || _offset + _max_read_size > file_size) {
        _max_read_size = file_size - _offset;
    }

    const size_t buf_size = MBToByte(1);
    PSVR_ASSERT(buf_size % PAGE_SIZE == 0);
    std::unique_ptr<gaia_apply::byte[]> buf(new gaia_apply::byte[buf_size]);
    gaia_apply::byte* buf_ptr = buf.get();

    void* decompressed_buf = std::aligned_alloc(PAGE_SIZE, PAGE_SIZE);
    if (!buf_ptr || !decompressed_buf) {
        fprintf(stderr, "Error, alloc memory failed, size:%lu, %lu\n", buf_size, PAGE_SIZE);
        return 1;
    }

    std::shared_ptr<std::nullptr_t> guard_decompressed_buf(nullptr, [&decompressed_buf](std::nullptr_t) { std::free(decompressed_buf); });

    auto check_page_valid_fn = [&decompressed_buf](gaia_apply::byte* f_buf, ssize_t f_buf_size) -> bool {
        for (ssize_t n = 0; n < f_buf_size; n += PAGE_SIZE) {
            if (!psvr::decompress_page(f_buf + n,
                        static_cast<gaia_apply::byte*>(decompressed_buf), PAGE_SIZE)) {
                return false;
            }
            bool is_empty = false;
            if (psvr::page_is_corrupted(static_cast<gaia_apply::byte*>(f_buf) + n,
                        PAGE_SIZE, &is_empty)) {
                return false;
            }
        }
        return true;
    };

    uint32_t retry_nr = 0;
    uint64_t read_size = 0;
    while (read_size < _max_read_size) {
        ssize_t read_n = pread(fd, buf_ptr, buf_size, _offset + read_size);
        //fprintf(stderr, "debug: offset:%lu, buf_size:%lu, read_n:%ld\n", _offset + read_size, buf_size, read_n);
        if (read_n == 0) {
            break;  // end of file
        } else if (read_n < 0) {  // error
            if (++retry_nr > MAX_RETRY_TIMES) {
                fprintf(stderr, "Error, read error, err:%s\n", strerror(errno));
                return 1;
            }
            sleep_for(millisecond2microseconds(10 * retry_nr));
        } else {        // read ok
            if (is_ibd_file) {
                if (read_n % PAGE_SIZE != 0) {
                    if (++retry_nr > MAX_RETRY_TIMES) {
                        fprintf(stderr, "Error, read idb data size:%ld error\n", read_n);
                        return 1;
                    }
                    sleep_for(millisecond2microseconds(10 * retry_nr));
                    continue;
                }
                if (!check_page_valid_fn(buf_ptr, read_n)) {
                    if (++retry_nr > MAX_RETRY_TIMES) {
                        fprintf(stderr, "Error, check idb data checksum failed\n");
                        return 1;
                    }
                    sleep_for(millisecond2microseconds(10 * retry_nr));
                    continue;
                }
            }

            const size_t read_n2 = static_cast<size_t>(read_n);
            size_t write_n = fwrite(buf_ptr, sizeof(gaia_apply::byte), read_n2, stdout);
            while (write_n < read_n2) {
                write_n += fwrite(buf_ptr + read_n2, sizeof(gaia_apply::byte), read_n2 - write_n, stdout);
            }
            read_size += read_n2;
            retry_nr = 0;
        }

        if (_backup_timeout_s && base::cpuwide_time_s() - _start_time > _backup_timeout_s) {
            _stopped = true;
            fprintf(stderr, "Error, task timeout:%ld, cost:%ld\n", _backup_timeout_s, base::cpuwide_time_s() - _start_time);
            return 1;
        }
    }

    if (read_size < _max_read_size) {
        fprintf(stderr, "Error, read total size:%lu small, expect:%lu \n", read_size, _max_read_size);
        return 1;
    }
    fflush(stdout);
    return 0;
}

namespace {

class TestManagerService : public gaiapb::QueryService {
public:
    TestManagerService(std::string page_server_addr, uint32_t segment_id, uint32_t total_extent_num)
            : _page_server_addr(std::move(page_server_addr)),
            _segment_id(segment_id), _total_extent_num(total_extent_num) {}

    void list_segment(::google::protobuf::RpcController*,
            const gaiapb::ListSegmentRequest*,
            gaiapb::ListSegmentResponse* response,
            ::google::protobuf::Closure* done) override {
        brpc::ClosureGuard done_guard(done);
        ++_list_count;
        response->mutable_status()->set_code(gaiadb::GIE_OK);
        auto* segment = response->add_segments();
        segment->set_segment_id(_segment_id);
        segment->set_free_extent_num(0);
        segment->set_total_extent_num(_total_extent_num);
        segment->add_replica_addrs(_page_server_addr);
    }

    uint32_t list_count() const {
        return _list_count.load();
    }

private:
    std::string _page_server_addr;
    uint32_t _segment_id;
    uint32_t _total_extent_num;
    std::atomic<uint32_t> _list_count {0};
};

class TestPageServerService : public pspb::QueryService {
public:
    explicit TestPageServerService(bool block_until_stopped = false)
            : _block_until_stopped(block_until_stopped) {}

    void Read(::google::protobuf::RpcController*,
            const pspb::ReadRequest* request,
            pspb::ReadResponse* response,
            ::google::protobuf::Closure* done) override {
        brpc::ClosureGuard done_guard(done);
        ++_read_count;
        {
            std::unique_lock<std::mutex> lk(_mutex);
            _offsets.emplace_back(request->offset());
        }
        if (_block_until_stopped) {
            sleep_for(second2microseconds(2));
        }
        std::string data(request->size(), '\0');
        response->mutable_status()->set_code(pspb::Status::SUCCESS);
        response->set_size(request->size());
        response->set_data(data);
        response->set_data_crc(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()), data.size()));
        response->set_gc_lsn(std::numeric_limits<uint64_t>::max());
    }

    uint32_t read_count() const {
        return _read_count.load();
    }

    std::vector<uint64_t> offsets() {
        std::unique_lock<std::mutex> lk(_mutex);
        return _offsets;
    }

private:
    bool _block_until_stopped;
    std::atomic<uint32_t> _read_count {0};
    std::mutex _mutex;
    std::vector<uint64_t> _offsets;
};

bool StartTestServer(baidu::rpc::Server* server, google::protobuf::Service* service, int* port) {
    if (server->AddService(service, baidu::rpc::SERVER_DOESNT_OWN_SERVICE) != 0) {
        return false;
    }
    baidu::rpc::ServerOptions options;
    options.num_threads = 4;
    options.idle_timeout_sec = -1;
    for (int p = 38080; p < 38180; ++p) {
        if (server->Start(p, &options) == 0) {
            *port = p;
            return true;
        }
    }
    return false;
}

}  // namespace

int32_t test_ChecksumReadFile() {
    std::filesystem::create_directories("./test_ChecksumReadFile");

    {
        const char* name = "./test_ChecksumReadFile/buf";
        int fd = open(base::string_printf("%s.%s", name, "out").c_str(),
                O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);

        if (fd < 0) {
            fprintf(stderr, "open file:%s failed, %m\n", name);
            return 1;
        }

        gaia_apply::byte* buf_data = new gaia_apply::byte[1<<20];
        Buf buf(8388608);

        size_t off = 0;
        buf.reset_tail(off);
        for (size_t i = 0; i < 19;) {
            auto next_off = off + (1lu<<20);
            if (!buf.has_space(next_off)) {
                auto rc = buf.advance_tail_until([&fd](gaia_apply::byte* data, uint64_t size, uint64_t from){
                        fprintf(stderr, "write size:%lu off:%lu\n", size, from);
                        return pwrite(fd, data, size, from) != static_cast<ssize_t>(size);
                    });
                if (!rc) {
                    fprintf(stderr, "buf has space:%lu failed\n", next_off - off);
                    return 1;
                }
                continue;
            }

            memset(buf_data, 0x41 + i, 1<<20);

            fprintf(stderr, "add link, from:%lu to:%lu\n", off, next_off);
            memcpy(buf.alloc_space_buf(off), buf_data, 1<<20);

            buf.add_link(off, next_off);

            off = next_off;
            ++i;
        }
        buf.advance_tail_until([&fd](gaia_apply::byte* data, uint64_t size, uint64_t from){
                fprintf(stderr, "write size:%lu off:%lu\n", size, from);
                return pwrite(fd, data, size, from) != static_cast<ssize_t>(size);
            });
        close(fd);
        if (buf.m_tail.load() == off) {
            fprintf(stderr, "test link buf ok\n");
        } else {
            fprintf(stderr, "test link buf fail, size:%lu, tail:%lu\n", off, buf.m_tail.load());
        }
    }

    auto create_file_fn = [](const char* name, size_t size, bool set_crc = false) {
        int fd = open(base::string_printf("%s", name).c_str(),
                O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
        if (fd < 0) {
            assert(false);
            return;
        }
        if (ftruncate(fd, size) != 0) {
            assert(false);
            return;
        }
        // write data
        size_t buf_size = PAGE_SIZE;
        std::unique_ptr<char[]> buf(new char[buf_size]);
        memset(buf.get(), 'a', buf_size);

        size_t write_size = 0;
        while (write_size < size) {
            size_t buf_n = std::min(buf_size, size - write_size);

            if (buf_n == PAGE_SIZE && set_crc) {
                auto frame = reinterpret_cast<gaia_apply::byte*>(buf.get());
                gaia_apply::mach_write_to_4(frame + gaia_apply::FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, 1);
                gaia_apply::mach_write_to_4(frame + gaia_apply::FIL_PAGE_OFFSET, 2);
                page_set_page_lsn(frame, PAGE_SIZE, 10000);
                if (!page_reset_checksum(frame, PAGE_SIZE, 1, 2, 10000)) {
                    assert(false);
                }
            }

            ssize_t write_n = pwrite(fd, buf.get(), buf_n, write_size);
            if (write_n > 0) {
                write_size += static_cast<size_t>(write_n);
            } else if (write_n < 0) {
                assert(false);
            }
        }
        close(fd);
    };

    auto dup_out_fn = [](const char* name) {
        int fd = open(base::string_printf("%s.%s", name, "out").c_str(),
                O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
        if (fd < 0) {
            assert(false);
            return;
        }
        if (dup2(fd, 1) != 1) {
            assert(false);
            return;
        }
        close(fd);
    };

    auto get_file_size = [](const char* name) -> size_t {
        struct ::stat sbuf;
        if (::stat(base::string_printf("%s.%s", name, "out").c_str(), &sbuf) == 0) {
            return sbuf.st_size;
        }
        return 0;
    };

    {
        // read small file
        const char* file_name = "./test_ChecksumReadFile/small";
        size_t file_size = 12;
        create_file_fn(file_name, file_size);
        dup_out_fn(file_name);

        ChecksumReadFile cmd;
        cmd._file_name = file_name;
        {
            assert(0 == cmd.Run());
            assert(file_size == get_file_size(file_name));
            fprintf(stderr, "test small offset=0 ok\n");
        }
    }

    {
        // read small file, offset !=0
        const char* file_name = "./test_ChecksumReadFile/small2";
        size_t file_size = 12;
        create_file_fn(file_name, file_size);
        dup_out_fn(file_name);

        ChecksumReadFile cmd;
        cmd._file_name = file_name;
        cmd._offset = 10;
        {
            assert(0 == cmd.Run());
            assert((file_size - cmd._offset) == get_file_size(file_name));
            fprintf(stderr, "test small offset!=0 ok\n");
        }
    }

    {
        // read small file, offset > size
        const char* file_name = "./test_ChecksumReadFile/small3";
        size_t file_size = 12;
        create_file_fn(file_name, file_size);
        dup_out_fn(file_name);

        ChecksumReadFile cmd;
        cmd._file_name = file_name;
        cmd._offset = 12;
        {
            assert(0 != cmd.Run());
            assert(0 == get_file_size(file_name));
            fprintf(stderr, "test small offset>size ok\n");
        }
    }

    {
        // read idb file, invalid offset
        const char* file_name = "./test_ChecksumReadFile/data.ibd";
        size_t file_size = 12;
        create_file_fn(file_name, file_size);
        dup_out_fn(file_name);

        ChecksumReadFile cmd;
        cmd._file_name = file_name;
        cmd._offset = 1024;
        {
            assert(0 != cmd.Run());
            assert(0 == get_file_size(file_name));
            fprintf(stderr, "test invalid ibd offset ok\n");
        }
    }

    {
        // read idb file, invalid file data
        const char* file_name = "./test_ChecksumReadFile/data1.ibd";
        size_t file_size = PAGE_SIZE * 128 - 1;
        create_file_fn(file_name, file_size);
        dup_out_fn(file_name);

        ChecksumReadFile cmd;
        cmd._file_name = file_name;
        {
            assert(0 != cmd.Run());
            assert(0 == get_file_size(file_name));
            fprintf(stderr, "test ibd invalid file size ok\n");
        }
    }

    {
        // read idb file, invalid file size
        const char* file_name = "./test_ChecksumReadFile/data2.ibd";
        size_t file_size = PAGE_SIZE * 128 - 1;
        create_file_fn(file_name, file_size, true);
        dup_out_fn(file_name);

        ChecksumReadFile cmd;
        cmd._file_name = file_name;
        {
            assert(0 != cmd.Run());
            fflush(stdout);
            assert((PAGE_SIZE * 64) == get_file_size(file_name));
            fprintf(stderr, "test ibd invalid file size ok\n");
        }
    }

    {
        // read idb file, ok
        const char* file_name = "./test_ChecksumReadFile/data3.ibd";
        size_t file_size = PAGE_SIZE * 1024;
        create_file_fn(file_name, file_size, true);
        dup_out_fn(file_name);

        ChecksumReadFile cmd;
        cmd._file_name = file_name;
        {
            assert(0 == cmd.Run());
            assert((file_size) == get_file_size(file_name));
            fprintf(stderr, "test ibd file ok\n");
        }
    }

    {
        TestPageServerService page_service;
        baidu::rpc::Server page_server;
        int page_port = 0;
        assert(StartTestServer(&page_server, &page_service, &page_port));

        TestManagerService manager_service(
                base::string_printf("127.0.0.1:%d", page_port), 1, 4);
        baidu::rpc::Server manager_server;
        int manager_port = 0;
        assert(StartTestServer(&manager_server, &manager_service, &manager_port));

        const char* file_name = "./test_ChecksumReadFile/remote_success";
        dup_out_fn(file_name);

        ChecksumReadFile cmd;
        cmd._manager_address = base::string_printf("gaia://127.0.0.1:%d", manager_port);
        cmd._cluster_id = "test_cluster";
        cmd._segment_id = 1;
        cmd._backup_start_lsn = 1;
        cmd._offset = EXTENT_SIZE;
        cmd._max_read_size = EXTENT_SIZE * 2;
        cmd._timeout_ms = 1000;
        cmd._backup_timeout_s = 10;
        int rc = cmd.Run();
        assert(0 == rc);
        assert(cmd._offset != 0);
        const size_t expected_file_size = cmd._max_read_size;
        assert(expected_file_size == get_file_size(file_name));
        assert(page_service.read_count() == 2);
        auto offsets = page_service.offsets();
        std::sort(offsets.begin(), offsets.end());
        assert(offsets.size() == 2);
        assert(offsets[0] == EXTENT_SIZE);
        assert(offsets[1] == EXTENT_SIZE * 2);
        fprintf(stderr, "test remote success offset!=0 ok\n");

        page_server.Stop(0);
        page_server.Join();
        manager_server.Stop(0);
        manager_server.Join();
    }

    {
        TestPageServerService page_service(true);
        baidu::rpc::Server page_server;
        int page_port = 0;
        assert(StartTestServer(&page_server, &page_service, &page_port));

        TestManagerService manager_service(
                base::string_printf("127.0.0.1:%d", page_port), 2, 4);
        baidu::rpc::Server manager_server;
        int manager_port = 0;
        assert(StartTestServer(&manager_server, &manager_service, &manager_port));

        const char* file_name = "./test_ChecksumReadFile/remote_timeout";
        dup_out_fn(file_name);

        ChecksumReadFile cmd;
        cmd._manager_address = base::string_printf("gaia://127.0.0.1:%d", manager_port);
        cmd._cluster_id = "test_cluster";
        cmd._segment_id = 2;
        cmd._backup_start_lsn = 1;
        cmd._max_read_size = EXTENT_SIZE * 2;
        cmd._timeout_ms = 1000;
        cmd._backup_timeout_s = 1;

        const char* err_file_name = "./test_ChecksumReadFile/remote_timeout.err";
        int saved_stderr = dup(2);
        assert(saved_stderr >= 0);
        int err_fd = open(err_file_name, O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
        assert(err_fd >= 0);
        assert(dup2(err_fd, 2) == 2);
        close(err_fd);

        std::thread run_thread([&cmd]() {
            assert(0 != cmd.Run());
        });
        while (page_service.read_count() == 0) {
            sleep_for(20);
        }
        sleep_for(second2microseconds(2));
        run_thread.join();
        assert(dup2(saved_stderr, 2) == 2);
        close(saved_stderr);

        std::ifstream err_file(err_file_name);
        std::string err_content(
                (std::istreambuf_iterator<char>(err_file)),
                std::istreambuf_iterator<char>());
        assert(err_content.find("Error, task timeout") != std::string::npos);
        assert(cmd._inflight_ctx_num.load() == 0);
        fprintf(stderr, "test remote early exit ok\n");

        page_server.Stop(0);
        page_server.Join();
        manager_server.Stop(0);
        manager_server.Join();
    }

    std::filesystem::remove_all("./test_ChecksumReadFile");
    return 0;
}

} // end of ns psvr

int main (int argc, char** argv) {
    psvr::ToolLogSink log_sink;
    logging::SetLogSink(&log_sink);

    gaiadb::common::ut_crc32_init();

    psvr::ChecksumReadFile cmd;
    if (argc < 2) {
        fprintf(stderr, "Error, miss command name, see help\n");
        cmd.help();
        return -1;
    }

    const std::string cmd_name(argv[1]);
    if (cmd_name == "test") {
        return psvr::test_ChecksumReadFile();
    }

    if (cmd_name == "version") {
        fprintf(stderr, "%s\n", psvr::get_version().c_str());
        return 1;
    }

    if (cmd_name != "ChecksumReadFile") {
        fprintf(stderr, "Error, not found command name, see help\n");
        return 1;
    }

    optind = 2;     // shift cmd name
    const struct option* opts = cmd.options();
    const char* stopts = psvr::build_short_options(opts);

    int option = 0;
    while ((option = getopt_long_only(argc, argv, stopts, opts, NULL)) != -1) {
        int ret = cmd.Parser(option, optarg);
        if (ret == 0) {
            continue;
        } else {
            fprintf(stderr, "Error, %s parse args failed, option:%d, optarg:%s\n",
                    cmd_name.c_str(), option, optarg);
            return 1;
        }
    }

    if (optind < argc) {
        if (cmd.SetFileName(argv[optind]) != 0) {
            return 1;
        }
    }

    return cmd.Run();
}

