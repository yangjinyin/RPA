/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file rpl/rpl0conductor.cc
 Gaiadb redo log replication

 Authors: wanglonglong01@baidu.com, qiaohongyu@baidu.com
 *******************************************************/

#include "rpl0conductor.h"
#include <gflags/gflags.h>
#include "rpl0apply.h"
#include "rpl0rpl.h"
#include "sql/current_thd.h"
#include "sql/log.h"
#include "log0log.h"
#include "baidu/rpc/reloadable_flags.h"
#include <bthread.h>
#include "ha_prototypes.h"
#include "gaia_rpl_msg.h"
#include "sql/statement_outline/outline_manager.h"
#include "bthread0op.h"

namespace rpl {

DEFINE_bool(rpl_enable_ignore_delta_replay, true,
            "ignore delta replay when recycling assembly slowly");
BAIDU_RPC_VALIDATE_GFLAG(rpl_enable_ignore_delta_replay,
                         baidu::rpc::PassValidate);

static bool PercentValidate(const char*, uint64_t val) {
  return val < 100;
}

DEFINE_uint64(rpl_rbio_refer_asmb_max_rate, 80,
             "asmb used rate exceed it, disable rbio refer asmb");
BAIDU_RPC_VALIDATE_GFLAG(rpl_rbio_refer_asmb_max_rate,
                         PercentValidate);

DEFINE_uint64(rpl_force_recycle_asmb_max_rate, 90,
             "assembly used rate exceed it, enable force recycle");
BAIDU_RPC_VALIDATE_GFLAG(rpl_force_recycle_asmb_max_rate,
                         PercentValidate);


RplConductor *g_rpl_conductor = &(RplConductor::get_instance());

RplAssemblyBus::RplAssemblyBus() {
  asmb_vec_ = static_cast<RplAssembly *>(
      ut::zalloc_withkey(UT_NEW_THIS_FILE_PSI_KEY, RPL_ASMB_BUCKETS * sizeof(RplAssembly)));
  for (uint64_t i = 0; i < RPL_ASMB_BUCKETS; ++i) {
    new (&asmb_vec_[i])(RplAssembly);
  }
}

RplAssemblyBus::~RplAssemblyBus() {
  for (uint64_t i = 0; i < RPL_ASMB_BUCKETS; ++i) {
    asmb_vec_[i].~RplAssembly();
  }
}

void RplState::init(lsn_t start_lsn) {
  ls_dispatch_lsn.store(start_lsn);
  fetch_lsn.store(start_lsn);
  parse_lsn.store(start_lsn);
  copy_lsn.store(start_lsn);
  apply_lsn.store(start_lsn);
  flush_lsn.store(start_lsn);
  master_vdl.store(start_lsn);
  read_lsn.store(start_lsn);
}

bool RplAssemblyBus::init() { return true; }

bool RplAssemblyBus::cleanup() {
  for (uint64_t i = 0; i < RPL_ASMB_BUCKETS; ++i) {
    asmb_vec_[i].cleanup();
  }
  return true;
}

bool RplAssemblyBus::can_advance_parse() {
  bool ret = true;
  auto gc_index = gc_index_.load();
  auto parse_index = parse_index_.load();
  if (parse_index + 1 >= gc_index + RPL_ASMB_BUCKETS) {
    ret = false;
  }
  return ret;
}

RplAssembly *RplAssemblyBus::pick_to_apply_assembly() {
  bool parse_finished = true;
  uint64_t parse_index = parse_index_.load();
  uint64_t apply_index = apply_index_.load();
  // new batch is unprepred
  if (apply_index + 1 > parse_index) {
    parse_finished = false;
  }
  if (!parse_finished) {
    return nullptr;
  }
  RplAssembly *asmb = &asmb_vec_[apply_index % RPL_ASMB_BUCKETS];
  ut_a(asmb->state == AssemblyState::ASSEMBLY_STATE_PARSED);
  return asmb;
}

RplAssembly *RplAssemblyBus::pick_to_parse_assembly() {
  bool gc_finished = true;
  uint64_t gc_index = gc_index_.load();
  uint64_t parse_index = parse_index_.load();
  // new batch is unprepared
  if (parse_index + 1 >= gc_index + RPL_ASMB_BUCKETS) {
    gc_finished = false;
  }
  if (!gc_finished) {
    return nullptr;
  }
  RplAssembly *asmb = &asmb_vec_[parse_index % RPL_ASMB_BUCKETS];
  ut_a(asmb->state == AssemblyState::ASSEMBLY_STATE_UNINITED);
  return asmb;
}

void RplAssemblyBus::advance_apply() {
  auto index = apply_index_.load();
  auto asmb = &asmb_vec_[index % RPL_ASMB_BUCKETS];
  g_rpl_conductor->update_read_lsn(asmb->end_lsn);
  apply_index_.fetch_add(1);
  LOG(TRACE) << "apply_index update to: " << index + 1;
}

void RplAssemblyBus::advance_parse() {
  auto index = parse_index_.fetch_add(1);
  LOG(TRACE) << "parse_index update to: " << index + 1;
}

bool RplAssemblyBus::recycle_assembly(RplAssembly *assembly) {
  LOG(TRACE) << "recycle assembly " << assembly->lsn_range()
             << ", epoch: " << assembly->epoch;

  ScopedBvarTimerAdder adder(&g_rpl_metric->recycle_periods);
  ScopedLatencyRecorder lat(&g_rpl_metric->recycle_assembly);

  RplAssembly *asmb = nullptr;
  bool apply_finished = true;
  uint64_t gc_index = 0;
  uint64_t parse_index = 0;
  uint64_t apply_index = 0;
  {
    ScopedLatencyRecorder _(&g_rpl_metric->recycle_assembly_check);
    gc_index = gc_index_.load();
    parse_index = parse_index_.load();
    apply_index = apply_index_.load();
    asmb = &asmb_vec_[gc_index % RPL_ASMB_BUCKETS];
    ut_a(assembly == asmb);
    ut_a(asmb->state == AssemblyState::ASSEMBLY_STATE_APPLIED);
    if (gc_index + 1 >= apply_index) {
      apply_finished = false;
    }
  }

  g_rpl_metric->gc_2_parse_index_gap << parse_index - gc_index;
  g_rpl_metric->gc_2_apply_index_gap << apply_index - gc_index;

  if (!apply_finished) {
    return false;
  }

  {
    ScopedLatencyRecorder _(&g_rpl_metric->recycle_assembly_wait_ref);
    while (asmb->apply_refer_num.load() > 0) {
      std::this_thread::sleep_for(std::chrono::microseconds(20));
      LOG_EVERY_N(WARNING, 5000) << "gc index: " << gc_index << " wait assembly "
                                 << asmb->lsn_range() << " to release apply reference:"
                                 << asmb->apply_refer_num.load();
    }
    while (asmb->bp_refer_num.load() > 0) {
      std::this_thread::sleep_for(std::chrono::microseconds(20));
      LOG_EVERY_N(WARNING, 5000) << "gc index: " << gc_index << " wait assembly "
                                 << asmb->lsn_range() << " to release bp reference:"
                                 << asmb->bp_refer_num.load();
    }

    uint64_t force_recycle_num = RPL_ASMB_BUCKETS *
                                 FLAGS_rpl_force_recycle_asmb_max_rate / 100;
    while (asmb->rbio_refer_num.load() > 0) {
      /** force recycle when enabled and not recycle rate over 90% (default) */
      if (FLAGS_rpl_enable_ignore_delta_replay &&
          gc_index_.load() + force_recycle_num < apply_index_.load()) {
        g_rpl_metric->force_recycle_count << 1;
        break;
      }
      std::this_thread::sleep_for(std::chrono::microseconds(20));
      LOG_EVERY_N(WARNING, 5000) << "gc index: " << gc_index << " wait assembly "
        << asmb->lsn_range() << " to release rbio reference:"
        << asmb->rbio_refer_num.load()
        << ", apply_index:" << apply_index_.load();
    }
  }
  {
    ScopedLatencyRecorder _(&g_rpl_metric->recycle_assembly_release);
    asmb->mutex.lock();
    int count = 0;
    while (asmb->apply_refer_num.load() > 0
        || asmb->bp_refer_num.load() > 0) {
      UT_RELAX_CPU();
      if (count++ >= 16) {
        count = 0;
        asmb->mutex.unlock();
        std::this_thread::sleep_for(std::chrono::microseconds(100));
        asmb->mutex.lock();
      }
    }
    auto rbio_refer_num = asmb->rbio_refer_num.exchange(0);
    asmb->cleanup();
    auto index = gc_index_.fetch_add(1);
    asmb->mutex.unlock();
    LOG(TRACE) << "gc_index update to: " << index + 1
               << " rbio_refer_num:" << rbio_refer_num;
  }
  return true;
}

void RplAssemblyBus::recycle_before_lsn(lsn_t lsn) {
  std::vector<RplAssembly *> to_gc_asmbs;
  size_t to_gc_asmbs_n = 0;
  uint64_t start_index = 0;
  uint64_t stop_index = 0;
  uint64_t parse_index = 0;
  bool force_recycle = false;
  uint64_t force_recycle_num = RPL_ASMB_BUCKETS *
                               FLAGS_rpl_force_recycle_asmb_max_rate / 100;

retry_force:
  start_index = gc_index_.load();
  stop_index = apply_index_.load();
  for (auto i = start_index; i < stop_index; ++i) {
    auto offset = i % RPL_ASMB_BUCKETS;
    auto asmb = &asmb_vec_[offset];
    if (asmb->state.load() != AssemblyState::ASSEMBLY_STATE_APPLIED) {
      // asmb state maybe in ASSEMBLY_STATE_PREPARED
      break;
    }
    if (asmb->end_lsn <= lsn ||
        (force_recycle &&
         (i + force_recycle_num) < stop_index)) {
      to_gc_asmbs.push_back(asmb);
      ++to_gc_asmbs_n;
    } else {
      break;
    }
  }

  /** If ps lowest lsn falls behine me, but I no longer need it (applied),
   *  so retry by force recycle mode */
  if (FLAGS_rpl_enable_ignore_delta_replay &&
      to_gc_asmbs_n == 0 && !force_recycle &&
      (start_index + force_recycle_num) < stop_index) {
    force_recycle = true;
    goto retry_force;
  }

  parse_index = parse_index_.load();
  g_rpl_metric->gc_2_parse_index_gap << parse_index - start_index;
  g_rpl_metric->gc_2_apply_index_gap << stop_index - stop_index;

  for (RplAssembly *asmb : to_gc_asmbs) {
    if (!recycle_assembly(asmb)) {
      break;
    }
  }

}

#define NO_REFER_TYPE 0
#define RBIO_REFER_TYPE 1
#define APPLY_REFER_TYPE 2

uint32_t RplAssemblyBus::rbio_apply_register(lsn_t &vlsn,
    uint64_t *refed_index, lsn_t *lowest_lsn) {
  auto index = apply_index_.load();
  if (index == 0) {
    vlsn = rpl_sys->init_lsn();
    *refed_index = 0;
    *lowest_lsn = vlsn;
    return NO_REFER_TYPE;
  }

  vlsn = g_rpl_conductor->read_lsn();
  *lowest_lsn = rpl_sys->lowest_lsn();
  auto start_index = gc_index_.load();
  uint64_t stop_index = apply_index_.load();

  const bool enable_ignore_refer = FLAGS_rpl_enable_ignore_delta_replay;

  if (enable_ignore_refer) {
    uint64_t max_use_num = RPL_ASMB_BUCKETS *
                           FLAGS_rpl_rbio_refer_asmb_max_rate / 100;
    if (start_index + max_use_num < stop_index) {
      start_index += max_use_num;
    }
  }

  RplAssembly *refer_asmb = nullptr;
  uint64_t ref_count = 0;
  uint32_t ref_type = NO_REFER_TYPE;
  for (auto i = start_index; i <= stop_index; ++i) {
    auto offset = i % RPL_ASMB_BUCKETS;
    auto asmb = &asmb_vec_[offset];
    std::shared_lock _(asmb->mutex);
    if (asmb->snapshot_index != (int64_t)i ||
        asmb->state.load() < AssemblyState::ASSEMBLY_STATE_PREPARED) {
      // apply process:
      // 1) in prepare: set asmb state to ASSEMBLY_STATE_PREPARED
      // 2) in finish: set apply_index + 1
      // already gced because of gc_index change, it is safe for rbio because
      // the request is send after we saw the ps lowest_lsn advance
      continue;
    }
    if (asmb->start_lsn >= *lowest_lsn) {
      // get the smallest batch assembly that may be between (ps_lowest, read_lsn)
      refer_asmb = asmb;
      *refed_index = i;
      *lowest_lsn = asmb->start_lsn;
      if (enable_ignore_refer) {
        ref_count = asmb->rbio_refer_num.fetch_add(1) + 1;
        ref_type = RBIO_REFER_TYPE;
      } else {
        ref_count = asmb->apply_refer_num.fetch_add(1) + 1;
        ref_type = APPLY_REFER_TYPE;
      }
      break;
    }
  }

  if (!refer_asmb) {
    // all assembly end_lsn <= lowest, can be gced safely: Rbio wil return a page
    // that does not need further apply
    return ref_type;
  }
  LOG(TRACE) << "assembly index: " << (*refed_index)
             << ", " << refer_asmb->lsn_range()
             << " increase ref_count to: " << ref_count
             << " by ref_type:" << ref_type;
  return ref_type;
}

void RplAssemblyBus::release_asmb_rbio_refer(uint64_t refed_index, bool locked) {
  auto asmb = &asmb_vec_[refed_index % RPL_ASMB_BUCKETS];
  if (!locked) {
    asmb->mutex.lock_shared();
  }
  if (asmb->snapshot_index == (int64_t)refed_index) {
    ut_a(asmb->rbio_refer_num > 0);
    auto count = asmb->rbio_refer_num.fetch_sub(1);
    LOG(TRACE) << "assembly index: " << refed_index << ", " << asmb->lsn_range()
      << " decrease ref_count to: " << count - 1;
  }
  if (!locked) {
    asmb->mutex.unlock_shared();
  }
}

/**
 * return
 * -1: error, missing redo
 * 0 : ok, not apply redo
 * 1 : ok, applied redo
 */
int32_t RplAssemblyBus::rbio_further_apply(uint32_t refed_type, uint64_t refed_index,
                                           buf_block_t *block, lsn_t start_lsn,
                                           lsn_t end_lsn) {
  if (refed_type == RBIO_REFER_TYPE) {
    release_asmb_rbio_refer(refed_index, false);
  }

  ut_a(refed_type != NO_REFER_TYPE);
  if (end_lsn <= start_lsn) {
    return 0;
  }

  LOG(TRACE) << "page: " << block->page.id << " further apply: [" << start_lsn
             << ", " << end_lsn << ")";
  ScopedLatencyRecorder total_lat(&g_rpl_metric->further_rbio_apply);
  std::vector<RplAssembly *> to_apply_asmbs;
  auto start_index = gc_index_.load();
  uint64_t stop_index = apply_index_.load();

  if (refed_index < start_index) {
    ut_a(refed_type != APPLY_REFER_TYPE);
    // force recycle
    return -1;
  }

  size_t refer_asmb_num = 0;
  for (auto i = start_index; i <= stop_index; ++i) {
    auto offset = i % RPL_ASMB_BUCKETS;
    auto asmb = &asmb_vec_[offset];
    std::shared_lock _(asmb->mutex);
    if (asmb->snapshot_index != (int64_t)i ||
        asmb->state.load() < AssemblyState::ASSEMBLY_STATE_PREPARED) {
      // already gced or not prepared for apply
      if (i >= refed_index && i != stop_index) {
        ut_a(refer_asmb_num == 0);
        ut_a(refed_type != APPLY_REFER_TYPE);
        // force recycle
        return -1;
      }
      continue;
    }

    if (asmb->start_lsn >= end_lsn) {
      ut_a(i != start_index);
      break;
    } else if (asmb->end_lsn <= start_lsn) {
      ut_a(refer_asmb_num == 0);
      continue;
    } else {
      auto bf = asmb->apply_refer_num.fetch_add(1);
      to_apply_asmbs.push_back(asmb);
      ++refer_asmb_num;
      LOG(TRACE) << "asmb apply refer add 1," << bf
        << ", refed_index:" << refed_index
        << ", asmb:" << asmb->snapshot_index
        << ", " << asmb->lsn_range();
    }
  }
  ut_a(to_apply_asmbs.size() > 0);
  ut_a(to_apply_asmbs.front()->start_lsn <= start_lsn);
  ut_a(to_apply_asmbs.back()->end_lsn >= end_lsn);

  block->page.in_rbio_further_apply = true;
  buf_block_fix(block);
  for (RplAssembly *asmb : to_apply_asmbs) {
    asmb->apply_materialize(block);
    auto bf = asmb->apply_refer_num.fetch_sub(1);
    LOG(TRACE) << "asmb apply refer sub 1, " << bf
      << ", refed_index:" << refed_index
      << ", asmb:" << asmb->snapshot_index
      << ", " << asmb->lsn_range();
  }
  buf_block_unfix(block);
  block->page.in_rbio_further_apply = false;
  return 1;
}

void RplAssemblyBus::rbio_finish_apply(uint32_t refed_type, uint64_t refed_index) {
  if (refed_type != APPLY_REFER_TYPE) {
    return;
  }
  RplAssembly *asmb = &asmb_vec_[refed_index % RPL_ASMB_BUCKETS];
  ut_a(asmb->snapshot_index == (int64_t)refed_index);
  ut_a(asmb && asmb->apply_refer_num > 0);
  auto count = asmb->apply_refer_num.fetch_sub(1) - 1;
  LOG(TRACE) << "assembly index: " << refed_index << ", " << asmb->lsn_range()
             << " decrease ref_count to: " << count;
}

void RplAssemblyBus::bp_get_further_apply(buf_block_t *block) {
  if (!block || is_apply_thread) {
    return;
  }

  ScopedLatencyRecorder total_lat(&g_rpl_metric->further_bp_get_apply);
  auto index = apply_index_.load();
  if (index == 0) {
    return;
  }

  RplAssembly *asmb = &asmb_vec_[(index - 1) % RPL_ASMB_BUCKETS];
  {
    std::shared_lock _(asmb->mutex);
    if (asmb->snapshot_index != (int64_t)(index - 1)) {
      return;
    }
    asmb->bp_refer_num.fetch_add(1);
  }

  std::shared_ptr<void> _(nullptr,
                          [asmb](...) { asmb->bp_refer_num.fetch_sub(1); });

  auto wait_lsn = asmb->end_lsn;
  auto page_records = asmb->get_page_records(block->page.id);
  if (!page_records || !page_records->n_record) {
    block->update_applied_lsn(wait_lsn);
    return;
  }

  while (block->applied_lsn.load() < wait_lsn) {
    auto success = rw_lock_x_lock_nowait(&block->lock, UT_LOCATION_HERE);
    if (success) {
      asmb->apply_materialize(block);
      rw_lock_x_unlock(&block->lock);
    } else {
      std::thread::id thread_id = std::this_thread::get_id();;
      bool is_recursive = block->lock.recursive;
      os_rmb;
      std::thread::id writer_thread = block->lock.writer_thread.load();
      if (is_recursive && writer_thread == thread_id) {
        LOG(WARNING) << "bp_get_further_apply, acquire x lock falid and use "
                        "this page directly"
                     << ", page:" << block->page.id
                     << ", thread_id:" << thread_id
                     << ", block->lock.lock_word:" << block->lock.lock_word
                     << ", block->lock.sx_recursive"
                     << block->lock.sx_recursive;
        break;
      }
      // in aio, maybe running in bthread
      gaia::this_thread::sleep_for(std::chrono::microseconds(20));
      LOG_EVERY_N(WARNING, 5000)
          << "buf pool page " << block->page.id
          << " wait for apply, applied_lsn: " << block->applied_lsn.load()
          << ", wait_lsn: " << wait_lsn;
    }
  }
}

RplConductor &RplConductor::get_instance() {
  static RplConductor s_rpl_conductor;
  return s_rpl_conductor;
}

bool RplConductor::init(lsn_t start_lsn) {
  rpl_state_.init(start_lsn);
  assembly_bus_.init();

  Conductor::init();

  LOG(NOTICE) << "rpl start from: " << std::dec << start_lsn
      << ", log_buf_size:" << log_buf_size();
  return true;
}

bool RplConductor::cleanup() {
  assembly_bus_.cleanup();
  Conductor::cleanup();
  return true;
}

#define update_if_bigger(var, n)   \
  lsn_t old = var.load();          \
  do {                             \
    if (n <= old) {                \
      break;                       \
    }                              \
  } while (!var.compare_exchange_strong(old, n))

void RplConductor::update_ls_dispatch_lsn(lsn_t ls_dispatch_lsn) {
  update_if_bigger(rpl_state_.ls_dispatch_lsn, ls_dispatch_lsn);
}

void RplConductor::update_fetch_lsn(lsn_t fetch_lsn) {
  update_if_bigger(rpl_state_.fetch_lsn, fetch_lsn);
}

void RplConductor::update_parse_lsn(lsn_t parse_lsn) {
  update_if_bigger(rpl_state_.parse_lsn, parse_lsn);
}

void RplConductor::update_copy_lsn(lsn_t copy_lsn) {
  update_if_bigger(rpl_state_.copy_lsn, copy_lsn);
}

void RplConductor::update_apply_lsn(lsn_t apply_lsn) {
  update_if_bigger(rpl_state_.apply_lsn, apply_lsn);
}

void RplConductor::update_flush_lsn(lsn_t flush_lsn) {
  update_if_bigger(rpl_state_.flush_lsn, flush_lsn);
}

void RplConductor::update_master_vdl(lsn_t master_vdl) {
  update_if_bigger(rpl_state_.master_vdl, master_vdl);
}

void RplConductor::update_read_lsn(lsn_t read_lsn) {
  update_if_bigger(rpl_state_.read_lsn, read_lsn);
}

void RplConductor::set_max_trx_no(trx_id_t trx_no) {
  ut_a(trx_no >= rpl_state_.max_trx_no);
  rpl_state_.max_trx_no.store(trx_no);
}

lsn_t RplConductor::ls_dispatch_lsn() { return rpl_state_.ls_dispatch_lsn.load(); }

lsn_t RplConductor::fetch_lsn() const { return rpl_state_.fetch_lsn.load(); }

lsn_t RplConductor::parse_lsn() { return rpl_state_.parse_lsn.load(); }

lsn_t RplConductor::copy_lsn() const { return rpl_state_.copy_lsn.load(); }

lsn_t RplConductor::apply_lsn() { return rpl_state_.apply_lsn.load(); }

lsn_t RplConductor::flush_lsn() { return rpl_state_.flush_lsn.load(); }

lsn_t RplConductor::master_vdl() { return rpl_state_.master_vdl.load(); }

lsn_t RplConductor::read_lsn() { return rpl_state_.read_lsn.load(); }

trx_id_t RplConductor::max_trx_no() { return rpl_state_.max_trx_no.load(); }

bool RplConductor::log_buf_has_space_for_lsn(lsn_t fetch_lsn, lsn_t& copy_lsn) {
  copy_lsn = rpl_state_.copy_lsn.load();
  return log_translate_lsn_to_sn(fetch_lsn) + 2 * OS_FILE_LOG_BLOCK_SIZE <=
         log_translate_lsn_to_sn(copy_lsn) + log_buf_size();
}

bool RplConductor::log_buf_reach_lsn(lsn_t lsn) {
  return rpl_state_.fetch_lsn.load() >= lsn;
}

void RplConductor::set_trx_sys_max_id_inited() {
  trx_sys_max_id_inited_.store(true);
}

bool RplConductor::trx_sys_max_id_inited() {
  return trx_sys_max_id_inited_.load();
}

void RplConductor::recycle_assembly(RplAssembly *assembly) {
  assembly_bus_.recycle_assembly(assembly);
}

void RplConductor::recycle_assembly_before_lsn(lsn_t lsn) {
  assembly_bus_.recycle_before_lsn(lsn);
}

void RplConductor::apply_rpl_msg(uint8_t type, uint8_t flags,
                                 const byte *payload, uint64_t payload_len) {
  switch (static_cast<gaia_rpl_msg_type_t>(type)) {
    case GAIA_RPL_MSG_OUTLINE_RELOAD: {
      const bool retain_counters =
          (flags & GAIA_RPL_MSG_F_OUTLINE_RETAIN_COUNTERS) != 0;
      rpl_reload_outline(retain_counters);
      break;
    }
    default:
      sql_print_warning(
          "[Statement Outline] Ignore unknown secondary rpl msg type:%u "
          "flags:%u payload_len:%llu",
          static_cast<unsigned>(type), static_cast<unsigned>(flags),
          static_cast<unsigned long long>(payload_len));
      break;
  }
  static_cast<void>(payload);
}

void RplConductor::rpl_reload_outline(bool retain_counters) {
  if (outline_reload_rules_background(retain_counters)) {
    sql_print_error(
        "[Statement Outline] Secondary redo outline reload failed");
  }
}

}  // namespace rpl
