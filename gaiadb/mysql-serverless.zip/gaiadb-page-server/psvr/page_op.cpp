/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/page_op.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/page_op.h"
#include "psvr/page.h"

namespace psvr {

namespace apply = gaia_apply;

db::Status page_apply_log_record(const LogRecord& record,
        BufBlockPtr buf_block, gaia_apply::lsn_t* page_lsn) {
    db::Status st;
    if (!buf_block || !page_lsn) {
        st.Reset(db::Code::kInvalid, "invalid apply page argument");
        return st;
    }
    if (record.type != gaia_apply::MLOG_INIT_FILE_PAGE2
            && record.has_page_check_bits
            && record.last_page_lsn != *page_lsn) {
        st.Reset(db::Code::kApplyError, "mismatch page last lsn");
        return st;
    }

    INIT_APPLY_RAW_ARG(false);
    RESET_APPLY_RAW_ARG(false);
    gaia_apply::byte* rec_ptr =
            const_cast<gaia_apply::byte*>(record.body);
    gaia_apply::byte* result =
            gaia_apply::recv_parse_or_apply_log_rec_body(
                    record.type, rec_ptr, rec_ptr + record.body_len,
                    record.space_id, record.page_no,
                    buf_block.get() APPLY_RAW_ARG_NAME_CC);
    if (!result || APPLY_RAW_IS_ERROR()) {
        st.Reset(db::Code::kApplyError, "apply lib error");
        return st;
    }

    *page_lsn = record.end_lsn;
    buf_block_set_page_lsn(buf_block, *page_lsn);
    gaia_apply::page_zip_des_t* page_zip =
            buf_block_get_page_zip(buf_block.get());
    if (page_zip) {
        gaia_apply::mach_write_to_8(
                page_zip->data + gaia_apply::FIL_PAGE_LSN, *page_lsn);
    }
    return st;
}

/** Calculates the CRC32 checksum of a page. The value is stored to the page
when it is written to a file and also checked for a match when reading from
the file. When reading we allow both normal CRC32 and CRC-legacy-big-endian
variants. Note that we must be careful to calculate the same value on 32-bit
and 64-bit architectures.
@param[in]	page			buffer page (UNIV_PAGE_SIZE bytes)
@param[in]	use_legacy_big_endian	if true then use big endian
byteorder when converting byte strings to integers
@return checksum */
uint32_t calc_page_crc32(const apply::byte* page) {
    /* Since the field apply::FIL_PAGE_FILE_FLUSH_LSN, and in versions <= 4.1.x
    FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, are written outside the buffer pool
    to the first pages of data files, we have to skip them in the page
    checksum calculation.
    We must also skip the field apply::FIL_PAGE_SPACE_OR_CHKSUM where the
    checksum is stored, and also the last 8 bytes of page because
    there we store the old formula checksum. */
    // c1: [4byte - 26byte], [apply::FIL_PAGE_OFFSET - apply::FIL_PAGE_TYPE]
    const uint32_t c1 = gaiadb::common::ut_crc32(page + apply::FIL_PAGE_OFFSET,
            apply::FIL_PAGE_FILE_FLUSH_LSN - apply::FIL_PAGE_OFFSET);
    // c2: [38byte - (16kb - 8byte)], exclude fil header and tail
    const uint32_t c2 = gaiadb::common::ut_crc32(page + apply::FIL_PAGE_DATA,
            apply::FLAGS_univ_page_size - apply::FIL_PAGE_DATA - apply::FIL_PAGE_END_LSN_OLD_CHKSUM);
    return c1 ^ c2;
}

bool check_page_crc32(const apply::byte* const page,
        apply::ulint crc1, apply::ulint crc2) {
    return crc1 == crc2
        && crc1 == calc_page_crc32(page);
}

bool buf_block_reset_checksum(apply::buf_block_t* block,
        const apply::lsn_t newest_lsn) {
    return page_reset_checksum(block->frame, block->page.size.logical(),
            block->page.id.space(), block->page.id.page_no(), newest_lsn);
}

bool page_reset_checksum(apply::byte* page, uint64_t logical_size,
        apply::space_id_t space_id, apply::page_no_t page_no,
        apply::lsn_t newest_lsn) {
    /* Different from mysql8, in mysql8 page_lsn always aligned with mtr_end
     * in PS, we require master/slave read aligned mtr, so PS self don't need to care mtr*/
    if (apply::mach_read_from_8(page + apply::FIL_PAGE_LSN) != newest_lsn) {
        LOG(ERROR) << "lsn mismatch,"
            << " newest_lsn:[" << newest_lsn
            << "] old:[" << apply::mach_read_from_8(page + apply::FIL_PAGE_LSN)
            << "]";
        return false;
    }
    if (std::memcmp(page + apply::FIL_PAGE_LSN + 4,
                page + logical_size - apply::FIL_PAGE_END_LSN_OLD_CHKSUM + 4, 4)) {
        LOG(ERROR) << "lsn compare failed,"
            << " p1:[" << apply::mach_read_from_4(page + apply::FIL_PAGE_LSN + 4)
            << "] p2:[" << apply::mach_read_from_4(page
                    + logical_size - apply::FIL_PAGE_END_LSN_OLD_CHKSUM + 4)
            << "]";
        return false;
    }
    // We don't support page != 16KB
    /* The page type could be garbage in old files
       created before MySQL 5.5. Such files always
       had a page size of 16 kilobytes. */
    apply::ulint page_type = apply::fil_page_get_type(page);
    apply::ulint reset_type = page_type;

    switch (page_no % apply::FLAGS_univ_page_size) {
    case 0:
        reset_type = (page_no == 0) ? apply::FIL_PAGE_TYPE_FSP_HDR : apply::FIL_PAGE_TYPE_XDES;
        break;
    case 1:
        reset_type = apply::FIL_PAGE_IBUF_BITMAP;
        break;
    default:
        switch (page_type) {
        case apply::FIL_PAGE_INDEX:
        case apply::FIL_PAGE_RTREE:
        case apply::FIL_PAGE_SDI:
        case apply::FIL_PAGE_UNDO_LOG:
        case apply::FIL_PAGE_INODE:
        case apply::FIL_PAGE_IBUF_FREE_LIST:
        case apply::FIL_PAGE_TYPE_ALLOCATED:
        case apply::FIL_PAGE_TYPE_SYS:
        case apply::FIL_PAGE_TYPE_TRX_SYS:
        case apply::FIL_PAGE_TYPE_BLOB:
        case apply::FIL_PAGE_TYPE_ZBLOB:
        case apply::FIL_PAGE_TYPE_ZBLOB2:
        case apply::FIL_PAGE_SDI_BLOB:
        case apply::FIL_PAGE_SDI_ZBLOB:
        case apply::FIL_PAGE_TYPE_LOB_INDEX:
        case apply::FIL_PAGE_TYPE_LOB_DATA:
        case apply::FIL_PAGE_TYPE_LOB_FIRST:
        case apply::FIL_PAGE_TYPE_ZLOB_FIRST:
        case apply::FIL_PAGE_TYPE_ZLOB_DATA:
        case apply::FIL_PAGE_TYPE_ZLOB_INDEX:
        case apply::FIL_PAGE_TYPE_ZLOB_FRAG:
        case apply::FIL_PAGE_TYPE_ZLOB_FRAG_ENTRY:
        case apply::FIL_PAGE_TYPE_RSEG_ARRAY:
            break;
        case apply::FIL_PAGE_TYPE_FSP_HDR:
        case apply::FIL_PAGE_TYPE_XDES:
        case apply::FIL_PAGE_IBUF_BITMAP:
            /* These pages should have predetermined page numbers (see above). */
        default:
            reset_type = apply::FIL_PAGE_TYPE_UNKNOWN;
            break;
        }
    }

    if (page_type != reset_type) {
        LOG(WARNING) << "resetting invalid space:[" << space_id
            << "] page:[" << page_no
            << "] type:[" << page_type
            << "] reset_type:[" << reset_type << "] when flushing.";
        INIT_APPLY_RAW_ARG(false);
        apply::fil_page_set_type(page, reset_type APPLY_RAW_ARG_NAME_CC);
        if (APPLY_RAW_IS_ERROR()) {
            return false;
        }
    }

    uint32_t checksum = calc_page_crc32(page);
    apply::mach_write_to_4(page + apply::FIL_PAGE_SPACE_OR_CHKSUM, checksum);

    /* With the InnoDB checksum, we overwrite the first 4 bytes of
    the end lsn field to store the old formula checksum. Since it
    depends also on the field apply::FIL_PAGE_SPACE_OR_CHKSUM, it has to
    be calculated after storing the new formula checksum.

    In other cases we write the same value to both fields.
    If CRC32 is used then it is faster to use that checksum
    (calculated above) instead of calculating another one.
    We can afford to store something other than
    buf_calc_page_old_checksum() or BUF_NO_CHECKSUM_MAGIC in
    this field because the file will not be readable by old
    versions of MySQL/InnoDB anyway (older than MySQL 5.6.3) */
    apply::mach_write_to_4(page + apply::FLAGS_univ_page_size - apply::FIL_PAGE_END_LSN_OLD_CHKSUM,
            checksum);
    return true;
}

bool page_is_corrupted(const apply::byte* page, apply::uint logical_size, bool* is_empty) {
    *is_empty = false;
    if (std::memcmp(page + apply::FIL_PAGE_LSN + 4,
                page + logical_size - apply::FIL_PAGE_END_LSN_OLD_CHKSUM + 4,
                4)) {
        // Stored log sequence numbers at the start and the end of page mismatch
        LOG(WARNING) << "page is corrupted, mismatch page lsn";
        return true;
    }
    auto c1 = apply::mach_read_from_4(page + apply::FIL_PAGE_SPACE_OR_CHKSUM);
    auto c2 = apply::mach_read_from_4(page + logical_size - apply::FIL_PAGE_END_LSN_OLD_CHKSUM);
    // declare empty pages non-corrupted
    if (c1 == 0 && c2 == 0
            && apply::mach_read_from_8(page + apply::FIL_PAGE_LSN) == 0) {
        // make sure that the page is really empty
        bool empty = true;
        for (apply::ulint i = 0; i < logical_size; i++) {
            /* The FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID has been
               repurposed for page compression. It can be set for decompressed empty pages. */
            // https://dev.mysql.com/doc/internals/en/innodb-fil-header.html
            if ((i < apply::FIL_PAGE_FILE_FLUSH_LSN || i >= apply::FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID)
                    && page[i] != 0) {
                empty = false;
                break;
            }
        }
        if (empty) {
            *is_empty = true;
            return false;
        }
    }
    LOG_IF(WARNING, (c1 != c2)) << "buf page crc mismatch";
    return !check_page_crc32(page, c1, c2);
}

}
