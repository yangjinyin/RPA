/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test_ibd_file.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <thread>
#include "test/test_common.h"
#include <gaiadb/utils/queue.hpp>

namespace psvr {

template<typename T>
using RetRing = gaiadb::common::RetRing<T>;

namespace test {

class QueueTests : public ::testing::Test {
 public:
    QueueTests() {}
    virtual ~QueueTests() {}

    void SetUp() {}

    void TearDown() {
    }

private:
};

struct QueueItem {
    uint32_t idx = 0;
    QueueItem(uint32_t n) : idx(n) {}
};

TEST_F(QueueTests, test_queue_1) {
    psvr::RetRing<QueueItem*> ring;
    uint32_t size = 1024 + 10;
    ASSERT_TRUE(ring.InitWithExactSize(size, gaiadb::common::RING_TYPE_SP_SC));
    for (uint32_t i = 0; i < size; ++i) {
        ASSERT_EQ(1, ring.Enqueue(new QueueItem(i)));
    }
    QueueItem* items[1024];
    uint32_t free_n = 1024;
    while (true) {
        uint32_t num = std::min(1024u, free_n);
        uint32_t n = ring.DequeueBulk(items, num, &free_n);
        if (n == 0 && free_n == 0) {
            break;
        }
        ASSERT_LE(n, 1024);
        for (uint32_t i = 0; i < n; ++i) {
            delete items[i];
        }
    }
}

TEST_F(QueueTests, test_queue) {
    psvr::RetRing<QueueItem*> ring;
    uint32_t size = 15;
    ASSERT_TRUE(ring.InitWithExactSize(size, gaiadb::common::RING_TYPE_SP_SC));

    ASSERT_EQ(size + 1, ring.size());

    for (uint32_t i = 0; i < size; ++i) {
        QueueItem* item = new QueueItem(i);
        ASSERT_EQ(1, ring.Enqueue(item));
    }
    ASSERT_EQ(0, ring.free_count());
    {
        QueueItem item(size + 1);
        ASSERT_EQ(0, ring.Enqueue(&item));
    }

    QueueItem* items[size];
    for (uint32_t i = 0; i < size; ++i) {
        ASSERT_EQ(1, ring.Dequeue(&items[i]));
    }
    {
        QueueItem* item;
        ASSERT_EQ(0, ring.Dequeue(&item));
    }

    ASSERT_EQ(size, ring.EnqueueBulk(items, size));
    {
        QueueItem item(size + 1);
        ASSERT_EQ(0, ring.Enqueue(&item));
    }
    ASSERT_EQ(size, ring.DequeueBulk(items, size));
    {
        QueueItem* item;
        ASSERT_EQ(0, ring.Dequeue(&item));
    }

    {
        ASSERT_EQ(1, ring.Enqueue(items[0]));
        QueueItem* item;
        ASSERT_EQ(1, ring.Dequeue(&item));
    }

    for (uint32_t i = 0; i < size; ++i) {
        delete items[i];
    }
}

void prod_func(std::atomic<uint32_t>* n, volatile bool* is_stoped, psvr::RetRing<QueueItem*>* ring) {
    while (!*is_stoped) {
        for (uint32_t i = 1; i < 32; ++i) {
            QueueItem* items[i];
            for (uint32_t j = 0; j < i; ++j) {
                items[j] = new QueueItem(j);
            }
            auto sz = ring->EnqueueBulk(items, i);
            if (sz) {
                ASSERT_EQ(sz, i);
                n->fetch_add(sz);
            }
        }
    }
}

void cons_func(std::atomic<uint32_t>* n, volatile bool* is_stoped, psvr::RetRing<QueueItem*>* ring) {
    while (!*is_stoped) {
        for (uint32_t i = 1; i < 32; ++i) {
            QueueItem* items[i];
            auto sz = ring->DequeueBulk(items, i);
            if (sz > 0) {
                ASSERT_EQ(sz, i);
                for (uint32_t j = 0; j < i; ++j) {
                    delete items[j];
                }
                n->fetch_add(sz);
            }
        }
    }
}

TEST_F(QueueTests, test_queue_sp_sz) {
    psvr::RetRing<QueueItem*> ring;
    uint32_t size = 63;
    ASSERT_TRUE(ring.InitWithExactSize(size, gaiadb::common::RING_TYPE_SP_SC));

    ASSERT_EQ(size + 1, ring.size());

    std::atomic<uint32_t> prod_sz = 0;
    std::atomic<uint32_t> cons_sz = 0;
    volatile bool is_stoped = false;
    auto prod = std::thread(prod_func, &prod_sz, &is_stoped, &ring);
    auto cons = std::thread(cons_func, &cons_sz, &is_stoped, &ring);

    LOG(NOTICE) << "thread testing .... 3s";
    usleep(3 * 1000 * 1000);
    is_stoped = true;
    prod.join();
    cons.join();

    auto sz = ring.count();
    ASSERT_EQ(prod_sz.load(), sz + cons_sz.load());
    ASSERT_GT(prod_sz.load(), 0);
    ASSERT_GT(cons_sz.load(), 0);
    ASSERT_GE(prod_sz.load(), cons_sz.load());
}

TEST_F(QueueTests, test_queue_mp_sc) {
    psvr::RetRing<QueueItem*> ring;
    uint32_t size = 63;
    ASSERT_TRUE(ring.InitWithExactSize(size, gaiadb::common::RING_TYPE_MP_SC));

    ASSERT_EQ(size + 1, ring.size());

    std::atomic<uint32_t> prod_sz = 0;
    std::atomic<uint32_t> cons_sz = 0;
    volatile bool is_stoped = false;
    auto prod1 = std::thread(prod_func, &prod_sz, &is_stoped, &ring);
    auto prod2 = std::thread(prod_func, &prod_sz, &is_stoped, &ring);
    auto prod3 = std::thread(prod_func, &prod_sz, &is_stoped, &ring);
    auto cons = std::thread(cons_func, &cons_sz, &is_stoped, &ring);

    LOG(NOTICE) << "thread testing .... 3s";
    usleep(3 * 1000 * 1000);
    is_stoped = true;
    prod1.join();
    prod2.join();
    prod3.join();
    cons.join();

    auto sz = ring.count();
    ASSERT_EQ(prod_sz.load(), sz + cons_sz.load());
    ASSERT_GT(prod_sz.load(), 0);
    ASSERT_GT(cons_sz.load(), 0);
    ASSERT_GE(prod_sz.load(), cons_sz.load());
}

TEST_F(QueueTests, test_queue_mp_mc) {
    psvr::RetRing<QueueItem*> ring;
    uint32_t size = 127;
    ASSERT_TRUE(ring.InitWithExactSize(size, gaiadb::common::RING_TYPE_MP_MC));

    ASSERT_EQ(size + 1, ring.size());

    std::atomic<uint32_t> prod_sz = 0;
    std::atomic<uint32_t> cons_sz = 0;
    volatile bool is_stoped = false;
    auto prod1 = std::thread(prod_func, &prod_sz, &is_stoped, &ring);
    auto prod2 = std::thread(prod_func, &prod_sz, &is_stoped, &ring);
    auto prod3 = std::thread(prod_func, &prod_sz, &is_stoped, &ring);
    auto cons1 = std::thread(cons_func, &cons_sz, &is_stoped, &ring);
    auto cons2 = std::thread(cons_func, &cons_sz, &is_stoped, &ring);
    auto cons3 = std::thread(cons_func, &cons_sz, &is_stoped, &ring);
    auto cons4 = std::thread(cons_func, &cons_sz, &is_stoped, &ring);

    LOG(NOTICE) << "thread testing .... 3s";
    usleep(3 * 1000 * 1000);
    is_stoped = true;
    prod1.join();
    prod2.join();
    prod3.join();
    cons1.join();
    cons2.join();
    cons3.join();
    cons4.join();

    auto sz = ring.count();
    ASSERT_EQ(prod_sz.load(), sz + cons_sz.load());
    ASSERT_GT(prod_sz.load(), 0);
    ASSERT_GT(cons_sz.load(), 0);
    ASSERT_GE(prod_sz.load(), cons_sz.load());
}

}
}
