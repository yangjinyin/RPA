#!/bin/bash

TARGET_BIN=page_server
RETRY_LIMIT=60
CHECK_WORK=1

if [ -n "$2" ]; then
    if [ "$2" != "--not_check" ]; then
        echo "Usage: $0 {start|stop|restart|pid} [--not_check]"
        exit 1
    fi
    CHECK_WORK=0
fi

cd `dirname $0` || exit 1
work_dir=`pwd -P`
bin_dir="${work_dir}/bin"
bin_exe="${bin_dir}/${TARGET_BIN}"
pid_file="${bin_exe}.pid"
lock_file="${bin_exe}.lock"
conf_dir="${work_dir}/conf"
conf_file="${conf_dir}/${TARGET_BIN}.conf"

export LD_LIBRARY_PATH="${work_dir}/lib":$LD_LIBRARY_PATH

[[ -d status/${TARGET_BIN} ]] || mkdir -p status/${TARGET_BIN}

proc_is_me() {
    local pid=$1
    if [ -z "$pid" ]; then
        return 1
    fi
    if [ ! -d "/proc/$pid" ]; then
        return 1
    fi
    #like: /xxx/page_server (deleted)
    local exe_path=`readlink -f "/proc/$pid/exe" | awk '{print $1}'`
    if [ "x$exe_path" != "x$bin_exe" ]; then
        return 1
    fi
    return 0
}

version_at_least() {
    local current=$1
    local minimum=$2
    local current_parts
    local minimum_parts
    local i

    if [[ "x$current" = "xunknown version" ]]; then
        return 0
    fi

    if [[ ! $current =~ ^[0-9]+(\.[0-9]+){3}$ ]]; then
        return 1
    fi

    IFS='.' read -r -a current_parts <<< "$current"
    IFS='.' read -r -a minimum_parts <<< "$minimum"
    for ((i=0; i<4; i++)); do
        if ((10#${current_parts[$i]} > 10#${minimum_parts[$i]})); then
            return 0
        fi
        if ((10#${current_parts[$i]} < 10#${minimum_parts[$i]})); then
            return 1
        fi
    done
    return 0
}

dblwr_is_on() {
    local val
    local version

    if [ ! -f "$conf_file" ]; then
        return 1
    fi

    val=$(grep -E '^[[:space:]]*--psvr_enable_append_file=' "$conf_file" \
        | tail -n 1 | cut -d'=' -f2- | xargs echo)
    val=${val,,}
    if [ "$val" = "0" ] || [ "$val" = "false" ]; then
        return 1
    fi

    val=$(grep -E '^[[:space:]]*--psvr_dblwr_max_page_num=' "$conf_file" \
        | tail -n 1 | cut -d'=' -f2- | xargs echo)
    if [ -n "$val" ] && { [[ ! $val =~ ^[0-9]+$ ]] || ((10#$val == 0)); }; then
        return 1
    fi

    version=$("$bin_exe" -v 2>&1 \
        | awk -F': *' '$1 == "VERSION" {print $2; exit}')
    version_at_least "$version" "4.2.4.1"
}

retry_stop_proc() {
    local pid=$1
    local proc=$2

    proc_nr=`ps -p $pid -f | grep $proc | wc -l`
    if [ $proc_nr -eq 1 ]; then
        echo -n "Kill proc:$proc by pid:$pid "
        if [ "$proc" = "$bin_exe" ] && dblwr_is_on; then
            kill -9 "$pid"
        else
            kill "$pid"
        fi
    fi
    for ((i=0; i<$RETRY_LIMIT; i++)); do
        proc_nr=`ps -p $pid -f | grep $proc | wc -l`
        if [ $proc_nr -eq 0 ]; then
            echo "ok"
            return 0
        fi
        echo -n "."
        sleep 1
    done
    echo "failed"
    return 1
}

start() {
    # check if the process is already exist
    if [ -f "${pid_file}" ]; then
        pid=`cat ${pid_file} | head -n 1`
        proc_is_me $pid
        if [ $? -eq 0 ]; then
            echo "[ERROR] ${TARGET_BIN}.pid exist, pid[${pid}]."\
                "The process[${pid_path}] is running!"
            exit 1
        fi
        echo "[WARNING] pid file exists, but proc:$pid not found."
    fi

    # check if the flagfile is exist
    if [ ! -f ${conf_file} ]; then
        echo "[ERROR] Not found ${conf_file}. Start failed."
        exit 1
    fi

    # try to start page_server with daemon
    if [ ! -d ${work_dir}/log ]; then
        mkdir -p ${work_dir}/log
    fi

    echo -n "Start proc:$bin_exe "
    ./supervise.${TARGET_BIN} -p status/${TARGET_BIN} \
        -f "${bin_exe} --flagfile=${conf_file}" \
        -r "${work_dir}/restart_checker.sh" \
        </dev/null &>/dev/null &

    for ((i=0; i<$RETRY_LIMIT; i++)); do
        if [ -f ${pid_file} ];then
            pid=`cat ${pid_file} | head -n 1`
            proc_is_me $pid
            if [ $? -eq 0 ]; then
                echo "successfully"
                return 0
            fi
        fi
        echo -n "."
        sleep 1
    done

    echo "failed. check timeout";
    exit 1
}

stop() {
    if [ ! -f ${pid_file} ]; then
        echo "[WARNING] Not found ${pid_file}"
        exit 0
    fi

    local pid=$(cat ${pid_file})
    proc_is_me $pid
    if [ $? -ne 0 ]; then
        echo "[WARNING] Not found ${pid_file} proc running"
        exit 0
    fi

    local ppid=`ps -p ${pid} -o ppid= | xargs echo`
    if [ -z "$ppid" ] || [[ 1 -eq $ppid ]]; then
        echo "[WARNING] supervise.${TARGET_BIN} is already exited unexpectedly!"
        ppid=""
    fi

    # If supervise proc exists, kill it first
    if [ -n "$ppid" ]; then
        retry_stop_proc $ppid "supervise.${TARGET_BIN}"
        if [ $? -eq 1 ]; then
            echo "[ERROR] Stop supervise.${TARGET_BIN} failed"
            exit 1
        else
            echo "[SUCC] Kill supervise.${TARGET_BIN}:$ppid done"
        fi
    fi

    # kill page_server processs
    retry_stop_proc $pid "$bin_exe"
    if [ $? -eq 1 ]; then
        echo "[ERROR] Stop $bin_exe failed"
        exit 1
    else
        echo "[SUCC] Kill $bin_exe: $pid done"
    fi
    return 0
}

showpid() {
    if [ ! -f ${pid_file} ]; then
        echo "[WARNING] Not found ${pid_file}"
        exit 1
    fi
    local pid=`cat ${pid_file}`
    # check if page_server process with pid is already run. if not ,rm the pid file
    proc_is_me $pid
    if [ $? -eq 0 ]; then
        echo $pid
        return 0
    fi
    echo "[WARNING] The ${TARGET_BIN} process with the pid[${pid}] isn't running."
    exit 1
}

if [ $CHECK_WORK -eq 1 ]; then
    if [ "`whoami`" != "work" ]; then
        echo "Need work account to execute, current is "`whoami`
        exit 1;
    fi
fi

case C"$1" in
    Cstart)
        start
        ;;
    Cstop)
        stop
        ;;
    Crestart)
        stop
        start
        ;;
    Cpid)
        showpid
        ;;
    C*)
        echo "Usage: $0 {start|stop|restart|pid} [--not_check]"
        ;;
esac
