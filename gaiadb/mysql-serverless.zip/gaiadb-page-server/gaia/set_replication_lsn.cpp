/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_replication_lsn.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/set_replication_lsn.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int SetReplicationLsn::Run() {
    RpcStatus status;
    gaiapb::SetReplicationLsnRequest request;
    gaiapb::SetReplicationLsnResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_apply_lsn < 1) {
        print_error("miss or error --apply-lsn");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Set replication lsn:%lu?", _apply_lsn);
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    request.set_log_id(_log_id);
    request.set_apply_lsn(_apply_lsn);
    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::set_replication_lsn, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " update replication  lsn failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("update failed, all nodes failed");
    return Output(response);
}

int SetReplicationLsn::Format(const gaiapb::SetReplicationLsnResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
