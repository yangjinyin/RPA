/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/quota.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/common.h"
#include "psvr/utils.h"

namespace psvr {

bvar::Vector<int64_t, 2> get_quota_stat_fn(void* arg);
bvar::Vector<int64_t, 2> get_flow_quota_stat_fn(void* arg);

// stat Quota
class Quota {
public:
    Quota(const int64_t* total_ptr)
        : _total_ptr(total_ptr),
        _total(*_total_ptr),
        _remain(*_total_ptr),
        _stat_quota(&get_quota_stat_fn, this) {}
    Quota(const base::StringPiece& name,
        const int64_t* total_ptr)
        : Quota(total_ptr) {
        expose(name);
    }
    Quota(const base::StringPiece& prefix,
        const base::StringPiece& name,
        const int64_t* total_ptr)
        : Quota(total_ptr) {
        expose_as(prefix, name);
    }
    FUNC_MOCK ~Quota() {
        hide();
    }

    int expose(const base::StringPiece& name) {
        return expose_as(base::StringPiece(), name);
    }

    int expose_as(const base::StringPiece& prefix, const base::StringPiece& name) {
#ifndef GTEST
        const int rc = _stat_quota.expose_as(prefix, name);
        _stat_quota.set_vector_names("total,remain");
        return rc;
#else
        return 0;
#endif
    }

    bool hide() {
        return _stat_quota.hide();
    }

    int64_t total() const { return _total; }
    int64_t remain() const { return _remain.load(std::memory_order_relaxed); }

    bool Enable(int64_t size) {
        if (_total >= size) {
            return true;
        }
        Update();
        return _total >= size;
    }

    FUNC_MOCK bool Acquire(int64_t size) {
        int64_t left = _remain.load(std::memory_order_acquire);
        do {
            if (left < size) {
                Update();
                break;
            }
        } while (!_remain.compare_exchange_strong(left, left - size, std::memory_order_acq_rel));
        return left >= size;
    }

    FUNC_MOCK void Release(int64_t size) {
        _remain.fetch_add(size, std::memory_order_relaxed);
        Update();
    }

private:
    void Update() {
        const int64_t new_total = *_total_ptr;
        int64_t old_total = _total;
        if (BAIDU_UNLIKELY(new_total != old_total) && new_total >= 0) {
            if (_total.compare_exchange_strong(old_total, new_total)) {
                const int64_t diff = new_total - old_total;
                int64_t left = _remain.load(std::memory_order_acquire);
                while (!_remain.compare_exchange_weak(left, left + diff, std::memory_order_acq_rel)) {
                    // pass
                }
            }
        }
    }

private:
    const int64_t* _total_ptr;
    std::atomic<int64_t> _total;
    std::atomic<int64_t> _remain;
    bvar::PassiveStatus<bvar::Vector<int64_t, 2>> _stat_quota;
};

class FlowQuota {
public:
    FlowQuota(const int64_t* max_per_second_quota_ptr, bool with_lock = false)
        : _max_per_second_quota_ptr(max_per_second_quota_ptr),
        _stat_used_size_per_seoncd(),
        _stat_flow_quota(&get_flow_quota_stat_fn, this) {
        _capacity = *max_per_second_quota_ptr;
        _tokens = 0;
        _fill_rate = _capacity * 1.0 / 1000.0 / 1000.0;    // to us
        _last_time = base::monotonic_time_us();
        _with_lock = with_lock;
    }
    FlowQuota(const base::StringPiece& name,
        const int64_t* max_per_second_quota_ptr,
        bool with_lock = false)
        : FlowQuota(max_per_second_quota_ptr, with_lock) {
        expose(name);
    }
    FlowQuota(const base::StringPiece& prefix,
        const base::StringPiece& name,
        const int64_t* max_per_second_quota_ptr,
        bool with_lock = false)
        : FlowQuota(max_per_second_quota_ptr, with_lock) {
        expose_as(prefix, name);
    }
    FUNC_MOCK ~FlowQuota() {
        hide();
    }

    int expose(const base::StringPiece& name) {
        return expose_as(base::StringPiece(), name);
    }

    int expose_as(const base::StringPiece& prefix, const base::StringPiece& name) {
#ifndef GTEST
        const int rc = _stat_flow_quota.expose_as(prefix, name);
        _stat_flow_quota.set_vector_names("total,used");
        return rc;
#else
        return 0;
#endif
    }

    bool hide() { return _stat_flow_quota.hide(); }

    bvar::PerSecondEx<bvar::Adder<int64_t>>& stat_used_size_per_seoncd() {
        return _stat_used_size_per_seoncd;
    }

    int64_t max_per_second_quota() const { return *_max_per_second_quota_ptr; }

    FUNC_MOCK uint64_t GetQuota(int64_t quota) {
        if (max_per_second_quota() != _capacity) {
            if (_with_lock) {
                std::unique_lock lk(_shared_mutex);
                _capacity = *_max_per_second_quota_ptr;
                _fill_rate = _capacity * 1.0 / 1000.0 / 1000.0;    // to us
            } else {
                _capacity = *_max_per_second_quota_ptr;
                _fill_rate = _capacity * 1.0 / 1000.0 / 1000.0;    // to us
            }
            if (_fill_rate <= 0.0) {
                return 0;
            }
        }
        if (quota > _capacity) {
            return 0;
        }
        int64_t cur_tokens = 0;
        if (_with_lock) {
            std::unique_lock lk(_shared_mutex);
            cur_tokens = GetCurTokens();
            if (quota <= cur_tokens) {
                _tokens -= quota;
            }
        } else {
            cur_tokens = GetCurTokens();
            if (quota <= cur_tokens) {
                _tokens -= quota;
            }
        }

        if (quota <= cur_tokens) {
            _stat_used_size_per_seoncd << quota;
            return 0;
        } else {
            return std::max(50lu, static_cast<uint64_t>((quota / _fill_rate)));
        }
    }

private:
    int64_t GetCurTokens() {
        if (_tokens < _capacity) {
            int64_t now = base::monotonic_time_us();
            double delta = _fill_rate * (now - _last_time);
            _tokens = std::min(static_cast<double>(_capacity), _tokens + delta);
            if (delta > 0.0) {
                _last_time = now;
            }
        }
        return static_cast<int64_t>(_tokens);
    }

private:
    const int64_t* _max_per_second_quota_ptr;  // per second
    int64_t _capacity;
    double _tokens;
    double _fill_rate;
    int64_t _last_time;
    bool _with_lock;
    rwlock_t _shared_mutex;

    bvar::PerSecondEx<bvar::Adder<int64_t>> _stat_used_size_per_seoncd;
    bvar::PassiveStatus<bvar::Vector<int64_t, 2>> _stat_flow_quota;
};


}
