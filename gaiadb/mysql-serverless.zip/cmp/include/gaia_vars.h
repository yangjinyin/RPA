#ifndef _gaia_vars_h
#define _gaia_vars_h
#include <stdint.h>

static const uint64_t KB = 1024;
static const uint64_t MB = KB * 1024;
static const uint64_t GB = MB * 1024;
static const uint64_t TB = GB * 1024;

#endif