/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/rpc_client.hpp
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gaiadb/utils/rpc_client.hpp>

namespace psvr {

using RpcCode = gaiadb::common::RpcCode;
using RpcStatus = gaiadb::common::RpcStatus;

inline const char* RpcCode2Str(const RpcCode& rc) {
    return gaiadb::common::RpcCode2Str(rc);
}

using RpcClient = gaiadb::common::RpcClient;

}
