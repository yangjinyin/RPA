#!/usr/bin/env bash
set -euo pipefail

CONF_PATH="/home/work/page_server/conf/page_server.conf"
SSH_OPTS="-o ConnectTimeout=5 -o StrictHostKeyChecking=no"

usage() {
    cat <<'EOF'
Usage:
  ./check_page_server_conf_consistency.sh <bns> [conf_path]

Examples:
  ./check_page_server_conf_consistency.sh group.example.all
  ./check_page_server_conf_consistency.sh group.example.all /home/work/page_server/conf/page_server.conf

Notes:
  - Requires get_instance_by_service in PATH.
  - Requires SSH access to each BNS node.
  - The script compares gflags semantics, not raw file content:
    - ignores blank lines
    - ignores comment lines beginning with #
    - ignores leading/trailing whitespace around keys and values
    - ignores order differences
    - parses lines in the form --key=value
EOF
}

if [[ $# -lt 1 || $# -gt 2 ]]; then
    usage
    exit 1
fi

BNS="$1"
if [[ $# -eq 2 ]]; then
    CONF_PATH="$2"
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

NODE_LIST="$TMP_DIR/nodes.txt"
RESULT_TSV="$TMP_DIR/result.tsv"
FAILED_LOG="$TMP_DIR/failed.log"

extract_nodes() {
    awk '
        /^[[:space:]]*$/ { next }
        /^#/ { next }
        {
            for (i = 1; i <= NF; i++) {
                field = $i
                gsub(/^\[/, "", field)
                gsub(/\]$/, "", field)

                if (field ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+(:[0-9]+)?$/) {
                    sub(/:[0-9]+$/, "", field)
                    print field
                    next
                }

                if (field ~ /^[A-Za-z0-9._-]+(:[0-9]+)?$/ && field !~ /^[0-9]+$/) {
                    sub(/:[0-9]+$/, "", field)
                    print field
                    next
                }
            }
        }
    ' | sort -u
}

if ! command -v get_instance_by_service >/dev/null 2>&1; then
    echo "ERROR: get_instance_by_service not found in PATH" >&2
    exit 2
fi

normalize_gflags() {
    awk '
        function trim(s) {
            gsub(/^[[:space:]]+/, "", s)
            gsub(/[[:space:]]+$/, "", s)
            return s
        }
        /^[[:space:]]*$/ { next }
        /^[[:space:]]*#/ { next }
        {
            line = trim($0)
            if (line !~ /^--[^=]+=.*$/) {
                next
            }
            eq = index(line, "=")
            key = trim(substr(line, 3, eq - 3))
            if (key == "psvr_topology_zone") {
                next
            }
            value = trim(substr(line, eq + 1))
            print key "=" value
        }
    ' | LC_ALL=C sort
}

if ! command -v sha256sum >/dev/null 2>&1; then
    echo "ERROR: sha256sum not found in PATH" >&2
    exit 2
fi

echo "Fetching BNS instances: $BNS" >&2
if ! get_instance_by_service "$BNS" 2>"$TMP_DIR/bns.err" | extract_nodes >"$NODE_LIST"; then
    echo "ERROR: failed to fetch BNS instances" >&2
    cat "$TMP_DIR/bns.err" >&2 || true
    exit 3
fi

if [[ ! -s "$NODE_LIST" ]]; then
    echo "ERROR: no nodes parsed from BNS: $BNS" >&2
    echo "Raw error output:" >&2
    cat "$TMP_DIR/bns.err" >&2 || true
    exit 3
fi

NODE_COUNT="$(wc -l <"$NODE_LIST")"
echo "Found $NODE_COUNT node(s)" >&2
: >"$RESULT_TSV"
: >"$FAILED_LOG"

while IFS= read -r node; do
    safe_node="${node//[^A-Za-z0-9_.-]/_}"
    out_file="$TMP_DIR/${safe_node}.conf"

    normalized_file="$TMP_DIR/${safe_node}.normalized"

    if ssh -n $SSH_OPTS "$node" "test -r '$CONF_PATH' && cat '$CONF_PATH'" >"$out_file" 2>"$TMP_DIR/${safe_node}.err"; then
        normalize_gflags <"$out_file" >"$normalized_file"
        hash="$(sha256sum "$normalized_file" | awk '{print $1}')"
        printf '%s\t%s\t%s\n' "$hash" "$node" "$normalized_file" >>"$RESULT_TSV"
        echo "OK     $node  $hash" >&2
    else
        echo "FAILED $node" >&2
        {
            echo "===== $node ====="
            cat "$TMP_DIR/${safe_node}.err"
            echo
        } >>"$FAILED_LOG"
    fi
done <"$NODE_LIST"

SUCCESS_COUNT="$(wc -l <"$RESULT_TSV")"
FAILED_COUNT="$(grep -c '^===== ' "$FAILED_LOG" || true)"
UNIQUE_HASH_COUNT="$(cut -f1 "$RESULT_TSV" | sort -u | wc -l)"

echo
echo "Summary"
echo "  BNS:           $BNS"
echo "  Config path:   $CONF_PATH"
echo "  Total nodes:   $NODE_COUNT"
echo "  Success nodes: $SUCCESS_COUNT"
echo "  Failed nodes:  $FAILED_COUNT"
echo "  Unique config: $UNIQUE_HASH_COUNT"

if [[ "$SUCCESS_COUNT" -eq 0 ]]; then
    echo
echo "No config file was fetched successfully."
    if [[ -s "$FAILED_LOG" ]]; then
        echo
echo "Failures:"
        cat "$FAILED_LOG"
    fi
    exit 4
fi

echo
echo "Config groups:"
cut -f1 "$RESULT_TSV" | sort | uniq -c | while read -r count hash; do
    echo "  $hash  nodes=$count"
    awk -F '\t' -v h="$hash" '$1 == h { print "    " $2 }' "$RESULT_TSV"
done

if [[ -s "$FAILED_LOG" ]]; then
    echo
echo "Failures:"
    cat "$FAILED_LOG"
fi

if [[ "$UNIQUE_HASH_COUNT" -eq 1 && "$FAILED_COUNT" -eq 0 ]]; then
    echo
echo "Result: CONSISTENT"
    echo
    echo "Normalized key/value list:"
    awk -F '\t' 'NR == 1 { print $3 }' "$RESULT_TSV" | while IFS= read -r normalized_file; do
        cat "$normalized_file"
    done
    exit 0
fi

echo
echo "Result: INCONSISTENT"

HASH_COUNTS="$TMP_DIR/hash_counts.tsv"
cut -f1 "$RESULT_TSV" | sort | uniq -c | awk '{ print $2 "\t" $1 }' >"$HASH_COUNTS"
base_hash="$(sort -t $'\t' -k2,2nr "$HASH_COUNTS" | awk -F '\t' 'NR==1 {print $1}')"
base_count="$(awk -F '\t' -v h="$base_hash" '$1 == h { print $2; exit }' "$HASH_COUNTS")"
base_node="$(awk -F '\t' -v h="$base_hash" '$1 == h { print $2; exit }' "$RESULT_TSV")"
base_file="$(awk -F '\t' -v h="$base_hash" '$1 == h { print $3; exit }' "$RESULT_TSV")"

echo
echo "Diff against majority/base group: $base_node ($base_hash, nodes=$base_count)"
awk -F '\t' -v h="$base_hash" '$1 != h { print $2 "\t" $3 "\t" $1 }' "$RESULT_TSV" | while IFS=$'\t' read -r node file hash; do
    echo
    echo "--- diff: $base_node vs $node ($hash) ---"
    diff -u --label "$base_node:$CONF_PATH" --label "$node:$CONF_PATH" "$base_file" "$file" || true
done

exit 5
