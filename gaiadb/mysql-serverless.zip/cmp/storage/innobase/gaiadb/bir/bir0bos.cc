#include "bir0async_binlog.h"
#include <ctype.h>
#include <base/base64.h>
#include <openssl/hmac.h>
#include <baidu/rpc/uri.h>
#include <baidu/rpc/details/http_message.h>
#include <openssl/aes.h>
#include "gaiadb/common/global_flags.h"
#include "rpl0rpl.h"
#include "rpl0parse.h"
#include "gaiadb/redo_fetch/fetch_mdc_object.h"
#include "gaiadb/redo_fetch/fetch_mdc_utils.h"

namespace bir {

void BirAsyncBinlog::binlog_bos_routine() {
  while (!is_stop()) {
    std::unique_lock<std::mutex> lock(thd_mutex());
    variables_cv_.wait(lock, [&] { 
      return is_stop() || (binlog_ready_.load() && !binlog_to_bos_.empty());});

    if (is_stop()) {
      break;
    }

    lock.unlock();

    LOG(NOTICE) << "bir_binlog_bos_routine. binlog_to_bos_.size(): " 
                << binlog_to_bos_.size();

    while (!binlog_to_bos_.empty() && !is_stop()) {
      BinlogToBosTask binlog_to_bos(binlog_to_bos_.front());
      if (bos::write_to_bos(binlog_to_bos.file_name, binlog_to_bos.file_size)) {
        if (check_binlog_file_exist(binlog_to_bos.file_name.c_str())) {
          LOG(WARNING) << "put_object failed, filename: " 
                       << binlog_to_bos.file_name;
          continue;
        }
      }
      binlog_to_bos_.pop();
      // After successful upload, the result is passed to PSM, 
      // and the upload index corresponds to the end_time in BOS.
      BinlogInRedoInfoMeta binlog_meta;
      binlog_meta.last_bos_index_id = binlog_to_bos.index_id;
      LOG(WARNING) << "binlog_to_bos end_time: " << binlog_to_bos.end_time
                   << ", last_bos_index_id: " << binlog_meta.last_bos_index_id;
      retry_operation(
        bir::MAX_RETRYS, gaiadb_update_binlog_in_redo_info_v2, 
        &binlog_meta, binlog_to_bos.end_time);
    }
  }
}
}
