/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_get_lowest_replica.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "gaia/get_lowest_replica.h"

namespace psvr {
namespace test {

class PsvrGetLowestReplicaTests : public PsvrTest {
 public:
    PsvrGetLowestReplicaTests() {
    }
    virtual ~PsvrGetLowestReplicaTests() {}

    void SetUp() {
        _get_lowest_replica = new gaia::GetLowestReplica();
    }

    void TearDown() {
        delete _get_lowest_replica;
        _get_lowest_replica = nullptr;
    }

private:
    gaia::GetLowestReplica* _get_lowest_replica { nullptr };
};

TEST_F(PsvrGetLowestReplicaTests, test_ALL) {
    {
        gaiapb::ListPageServerResponse rsp;
        rsp.mutable_status()->set_code(0);
        rsp.set_cn_lowest_lsn(100000000);
        {
            auto pb = rsp.add_page_servers();
            pb->set_addr("127.0.0.1:1");
            pb->set_segment_id(1);
            pb->set_replica_id(0);
            pb->set_checkpoint_lsn(100);
            pb->set_apply_lsn(100000000);
            pb->set_fetch_lsn(100000000);
            pb->set_state(gaiadb::NODE_ACTIVE);
        }
        {
            auto pb = rsp.add_page_servers();
            pb->set_addr("127.0.0.1:2");
            pb->set_segment_id(2);
            pb->set_replica_id(1);
            pb->set_checkpoint_lsn(50);
            pb->set_apply_lsn(100000000);
            pb->set_fetch_lsn(100000000);
            pb->set_state(gaiadb::NODE_ACTIVE);
        }

        {
            // test 0
            pspb::LowestNode result;
            _get_lowest_replica->_min_distance = 51;
            _get_lowest_replica->FindLowestNode(rsp, &result);
            ASSERT_EQ(result.status().code(), pspb::Status::SUCCESS);
            ASSERT_EQ(0, result.lowest_nodes_size());
        }

        {
            // test 1
            pspb::LowestNode result;
            _get_lowest_replica->_min_distance = 50;
            _get_lowest_replica->FindLowestNode(rsp, &result);
            ASSERT_EQ(result.status().code(), pspb::Status::SUCCESS);
            LOG(TRACE) << pb2jsonstr(result);
            ASSERT_EQ(1, result.lowest_nodes_size());
            ASSERT_EQ(result.lowest_nodes(0).addr(), "127.0.0.1:2");
            ASSERT_EQ(result.lowest_nodes(0).segment_id(), 2);
            ASSERT_EQ(result.lowest_nodes(0).replica_id(), 1);
            ASSERT_EQ(result.lowest_nodes(0).checkpoint_lsn(), 50);
        }

        {
            auto pb = rsp.add_page_servers();
            pb->set_addr("127.0.0.1:3");
            pb->set_segment_id(3);
            pb->set_replica_id(2);
            pb->set_checkpoint_lsn(70);
            pb->set_apply_lsn(100000000);
            pb->set_fetch_lsn(100000000);
            pb->set_state(gaiadb::NODE_ACTIVE);
        }

        {
            // test 0
            pspb::LowestNode result;
            _get_lowest_replica->_min_distance = 21;
            _get_lowest_replica->FindLowestNode(rsp, &result);
            ASSERT_EQ(result.status().code(), pspb::Status::SUCCESS);
            ASSERT_EQ(0, result.lowest_nodes_size());
        }
        {
            // test 2
            pspb::LowestNode result;
            _get_lowest_replica->_min_distance = 20;
            _get_lowest_replica->FindLowestNode(rsp, &result);
            LOG(TRACE) << pb2jsonstr(rsp);
            LOG(TRACE) << pb2jsonstr(result);
            ASSERT_EQ(result.status().code(), pspb::Status::SUCCESS);
            ASSERT_EQ(1, result.lowest_nodes_size());
            ASSERT_EQ(result.lowest_nodes(0).addr(), "127.0.0.1:2");
            ASSERT_EQ(result.lowest_nodes(0).segment_id(), 2);
            ASSERT_EQ(result.lowest_nodes(0).replica_id(), 1);
            ASSERT_EQ(result.lowest_nodes(0).checkpoint_lsn(), 50);
        }

        {
            auto pb = rsp.add_page_servers();
            pb->set_addr("127.0.0.1:4");
            pb->set_segment_id(4);
            pb->set_replica_id(2);
            pb->set_checkpoint_lsn(30);
            pb->set_apply_lsn(100000000);
            pb->set_fetch_lsn(100000000);
            pb->set_state(gaiadb::NODE_ACTIVE);
        }

        {
            auto pb = rsp.add_page_servers();
            pb->set_addr("127.0.0.1:5");
            pb->set_segment_id(5);
            pb->set_replica_id(2);
            pb->set_checkpoint_lsn(110);
            pb->set_apply_lsn(100000000);
            pb->set_fetch_lsn(100000000);
            pb->set_state(gaiadb::NODE_ACTIVE);
        }

        {
            // test 3
            pspb::LowestNode result;
            _get_lowest_replica->_min_distance = 20;
            _get_lowest_replica->FindLowestNode(rsp, &result);
            LOG(TRACE) << pb2jsonstr(result);
            ASSERT_EQ(result.status().code(), pspb::Status::SUCCESS);
            ASSERT_EQ(1, result.lowest_nodes_size());
            ASSERT_EQ(result.lowest_nodes(0).addr(), "127.0.0.1:4");
            ASSERT_EQ(result.lowest_nodes(0).segment_id(), 4);
            ASSERT_EQ(result.lowest_nodes(0).replica_id(), 2);
            ASSERT_EQ(result.lowest_nodes(0).checkpoint_lsn(), 30);
        }

        {
            auto pb = rsp.add_page_servers();
            pb->set_addr("127.0.0.1:6");
            pb->set_segment_id(6);
            pb->set_replica_id(2);
            pb->set_checkpoint_lsn(30);
            pb->set_apply_lsn(100000000);
            pb->set_fetch_lsn(100000000);
            pb->set_state(gaiadb::NODE_ACTIVE);
        }

        {
            // test 3
            pspb::LowestNode result;
            _get_lowest_replica->_min_distance = 10;
            _get_lowest_replica->FindLowestNode(rsp, &result);
            LOG(TRACE) << pb2jsonstr(result);
            ASSERT_EQ(result.status().code(), pspb::Status::SUCCESS);
            ASSERT_EQ(2, result.lowest_nodes_size());
        }

    }
}


}
}
