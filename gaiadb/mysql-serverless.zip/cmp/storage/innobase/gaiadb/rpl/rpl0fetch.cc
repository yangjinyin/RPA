/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file rpl/rpl0fetch.cc
 Gaiadb redo log replication

 Created 10/12/2021 Hongyu Qiao
 *******************************************************/

#include "rpl0fetch.h"
#include "log0log.h"
#include "os0thread.h"
#include "rpl0conductor.h"
#include "rpl0metric.h"
#include "rpl0rpl.h"

#ifdef UNIV_DEBUG
#include "rpl0pv.h"
#endif
#include <future>

DEFINE_bool(secondary_exit_if_slow_node, false,
            "exit if secondary is slow node");
BAIDU_RPC_VALIDATE_GFLAG(secondary_exit_if_slow_node,
                         baidu::rpc::PassValidate);

DEFINE_bool(secondary_mock_fetch_fail, false,
            "secondary mock fail to fetch redo");
BAIDU_RPC_VALIDATE_GFLAG(secondary_mock_fetch_fail,
                         baidu::rpc::PassValidate);

namespace rpl {

static bvar::Adder<uint32_t> stat_rpl_get_log_error_count;
static bvar::Window<bvar::Adder<uint32_t>> stat_rpl_get_log_error_count_w(
    "cmp_rpl_fetch_log_error_count", &stat_rpl_get_log_error_count, 10);

static bvar::Adder<uint32_t> stat_rpl_get_log_from_backup_zone_count;
static bvar::Window<bvar::Adder<uint32_t>>
    stat_rpl_get_log_from_backup_zone_count_w(
        "cmp_rpl_fetch_log_from_backup_zone_count",
        &stat_rpl_get_log_from_backup_zone_count, 10);

static bvar::Adder<uint32_t> stat_rpl_get_log_from_lz_count;
static bvar::Window<bvar::Adder<uint32_t>> stat_rpl_get_log_from_lz_count_w(
    "cmp_rpl_fetch_log_from_lz_count",
    &stat_rpl_get_log_from_lz_count, 10);

static const char *const fetcher_str = "rpl_fetcher";
DEFINE_uint64(rpl_fetcher_switch_ls_count, 500,
              "auto switch ls node when request times reach this threshold");
BAIDU_RPC_VALIDATE_GFLAG(rpl_fetcher_switch_ls_count, baidu::rpc::PassValidate);

DEFINE_uint64(rpl_get_log_consecutive_time_from_backup_zone, 1,
              "consecutive times of requesting one backup zone log service");
BAIDU_RPC_VALIDATE_GFLAG(rpl_get_log_consecutive_time_from_backup_zone,
                         baidu::rpc::PassValidate);

DEFINE_uint64(rpl_get_log_consecutive_time, 4096,
              "consecutive times of requesting one log service");
BAIDU_RPC_VALIDATE_GFLAG(rpl_get_log_consecutive_time,
                         baidu::rpc::PassValidate);

DEFINE_uint64(rpl_get_log_depth, 12,
              "get log rpc task depth");
BAIDU_RPC_VALIDATE_GFLAG(rpl_get_log_depth,
                         baidu::rpc::PassValidate);

DEFINE_int64(rpl_interval_sleep_us_redo_not_enough, 200,
             "rpl interval sleep us and retry next check redo size");
BAIDU_RPC_VALIDATE_GFLAG(rpl_interval_sleep_us_redo_not_enough,
                         baidu::rpc::PositiveInteger);

DEFINE_int64(rpl_max_sleep_us_redo_not_enough, 3000,
             "rpl max interval sleep us");
BAIDU_RPC_VALIDATE_GFLAG(rpl_max_sleep_us_redo_not_enough,
                         baidu::rpc::PositiveInteger);

DEFINE_uint64(rpl_fetch_redo_min_size_no_sleep, 512,
              "fetch redo size lower than it, will sleep next fetch");
BAIDU_RPC_VALIDATE_GFLAG(rpl_fetch_redo_min_size_no_sleep,
                         baidu::rpc::PassValidate);

DEFINE_int64(rpl_fetch_sleep_us_buf_is_full, 1000,
             "sleep us and retry next check buf is full");
BAIDU_RPC_VALIDATE_GFLAG(rpl_fetch_sleep_us_buf_is_full,
                         baidu::rpc::PositiveInteger);


bvar::Status<uint64_t> stat_rpl_get_log_depth("cmp_rpl_get_log_cur_depth_num", 0);

RplFetcher *g_rpl_fetcher = &(RplFetcher::get_instance());

bool rpl_get_log_service_peers(std::vector<gaiadb::common::PeerZone> &peers) {
  ut_a(psmcli != nullptr);
  peers.clear();
  auto ret = psmcli->get_log_services(peers);
  if (gaiadb::GIE_OK != ret || peers.size() == 0) {
    return false;
  }
  std::random_shuffle(peers.begin(), peers.end());
  return true;
}

void rpl_fetcher() {
  DBUG_ENTER(fetcher_str);
  pthread_setname_np(pthread_self(), fetcher_str);
#ifdef UNIV_LINUX_ONLY
  setpriority(PRIO_PROCESS, (pid_t)syscall(SYS_gettid), -20);
#endif
  g_rpl_fetcher->routine();

  ib_info(ER_IB_GAIA_MSG_RPL) << "Gaia replication fetcher threads stopped";
  DBUG_VOID_RETURN;
}

RplFetcher::RplFetcher() {}

bool RplFetcher::init() {
  return true;
}

bool RplFetcher::cleanup() {
  return true;
}

RplFetcher::~RplFetcher() {}

RplFetcher &RplFetcher::get_instance() {
  static RplFetcher s_rpl_fetcher;
  return s_rpl_fetcher;
}

static void update_fetch_speed(uint64_t fetched_size) {
  static uint64_t bytes_fetched = 0;
  static uint64_t last_stat_ts = my_micro_time();

  bytes_fetched += fetched_size;
  auto now = my_micro_time();
  // update per 1s
  if (now > last_stat_ts && now - last_stat_ts > 1000000) {
    auto time_diff = now - last_stat_ts;
    auto fetch_speed = bytes_fetched * 1000000 / time_diff;
    rpl_sys->set_fetch_speed(fetch_speed);
    bytes_fetched = 0;
    last_stat_ts = now;
  }
}

void sleep_buf_not_enough(uint32_t wait_count) {
  uint32_t max_count = FLAGS_rpl_max_sleep_us_redo_not_enough /
                       FLAGS_rpl_interval_sleep_us_redo_not_enough + 1;
  if (wait_count == 0 || wait_count > max_count) {
    wait_count = max_count;
  }
  int64_t sleep_us =
    FLAGS_rpl_interval_sleep_us_redo_not_enough * wait_count;
  if (sleep_us > FLAGS_rpl_max_sleep_us_redo_not_enough) {
    sleep_us = FLAGS_rpl_max_sleep_us_redo_not_enough;
  }
  std::this_thread::sleep_for(std::chrono::microseconds(sleep_us));
}

struct rpl_fetch_rpc_ctx {
  std::promise<void>& fetch_promise;
  std::atomic<uint64_t>& unfinish_num;
  baidu::rpc::Controller cntl;
  log_service::sec_get_log_request request;
  log_service::sec_get_log_response response;

  rpl_fetch_rpc_ctx(
    std::promise<void>& promise, std::atomic<uint64_t>& task_count)
    : fetch_promise(promise), unfinish_num(task_count),
    cntl(), request(), response() {}
};

static void on_fetch_log(
    std::shared_ptr<rpl_fetch_rpc_ctx> rpc_ctx) {
  g_rpl_metric->fetch_get_log << rpc_ctx->cntl.latency_us();
  if (rpc_ctx->unfinish_num.fetch_sub(1, std::memory_order_relaxed) == 1) {
    rpc_ctx->fetch_promise.set_value();
  }
}

static void async_fetch_log(
    const gaiadb::common::PeerZone& ls_replica,
    std::shared_ptr<rpl_fetch_rpc_ctx> rpc_ctx) {
  using stub = log_service::SecondaryService_Stub;
  static gaiadb::common::RpcClient rpl_client;

  LOG(TRACE) << "fetch log, start_lsn: " << rpc_ctx->request.start_lsn()
    << ", from: " << ls_replica.addr;

  {
    ScopedBvarTimerAdder adder(&g_rpl_metric->fetch_periods_rpc);
    auto closure = brpc::NewCallback(&on_fetch_log, rpc_ctx);
    rpl_client.Call(&rpc_ctx->cntl, ls_replica.addr, &stub::get_log, &rpc_ctx->request,
        &rpc_ctx->response, closure);
  }
}

/** return true is ok, false is stopped */
static bool do_fetch_until_success(LogServerInfo &ls_info,
    lsn_t request_lsn, uint64_t req_blocks_n,
    log_service::sec_get_log_response &response) {
  static uint32_t req_count = 0;
  static std::vector<std::shared_ptr<rpl_fetch_rpc_ctx>> rpl_fetch_rpc_ctx_vec;
  static uint64_t last_succ_depth_num = 0;
  static lsn_t last_request_lsn = 0;

  bool fetch_empty = false;
  uint64_t succ_depth_num = 0;
  uint64_t ls_vdl = 0;
  do {
    ++req_count;
    update_fetch_speed(0);

    response.Clear();
    response.set_block_num(0);
    // 1. get log services nodes list
    ScopedBvarTimerAdder adder(&g_rpl_metric->fetch_periods_pick_server);
    if (ls_info.need_refresh_replicas()) {
      if (!ls_info.refresh_replicas()) {
        if (req_count % 128 == 0) {
          ib_error(ER_IB_GAIA_MSG_RPL)
            << "Gaia replication fetch log failed: "
            "rpc failed on get log serice addr";
        }
        std::this_thread::sleep_for(std::chrono::microseconds(1000 * 100));  // sleep 100ms if psm do not work
        ls_info.reuse_maybe_error_replicas();
      }
    } else if (ls_info.refresh_zone()) {
      ls_info.resort_replicas();
    }
    if (ls_info.replicas.empty()) {
      continue; // empty nodes list
    }
    // 2. send multi async rpc
    auto max_depth = std::max(FLAGS_rpl_get_log_depth, srv_rpl_fetch_rpc_depth);
    if (fetch_empty || last_request_lsn == request_lsn) {
      max_depth = 1;  // if primary has no redo logs, only sent once;
    } else {
      max_depth = std::min(last_succ_depth_num + 1, max_depth); // increase steps
    }
    const auto depth = std::max(1lu, max_depth);
    stat_rpl_get_log_depth.set_value(depth);

    std::promise<void> get_log_promise;
    std::future<void> get_log_future;
    std::atomic<uint64_t> finish_num = 0;

    rpl_fetch_rpc_ctx_vec.clear();
    get_log_future = get_log_promise.get_future();
    finish_num.store(depth);

    auto start_lsn = request_lsn;
    auto &ls_replica = ls_info.get_replica();
    for (uint64_t i = 0; i < depth; ++i) {
      std::shared_ptr<rpl_fetch_rpc_ctx> rpc_ctx(
          new rpl_fetch_rpc_ctx(get_log_promise, finish_num));
      auto& request = rpc_ctx->request;
      request.set_start_lsn(start_lsn);
      request.set_expect_blocks(req_blocks_n);
      request.set_block_no(log_block_convert_lsn_to_hdr_no(start_lsn));
      request.set_server_id(1);
      if (ls_info.has_zone && ls_replica.has_zone()) {
        request.mutable_zone()->set_region(ls_replica.region);
        request.mutable_zone()->set_available_zone(ls_replica.available_zone);
      }
      // send async rpc
      async_fetch_log(ls_replica, rpc_ctx);
      rpl_fetch_rpc_ctx_vec.emplace_back(rpc_ctx);
      // set next rpc fetch start lsn
      start_lsn += req_blocks_n * OS_FILE_LOG_BLOCK_SIZE;
    }
    get_log_future.get();  // wait all rpc done
    // 3. check multi rpc responses
    succ_depth_num = 0;
    uint32_t valid_block_num = 0;
    for (uint64_t i = 0; i < depth; ++i) {
      auto rpc_ctx = rpl_fetch_rpc_ctx_vec[i];
      const auto& cntl = rpc_ctx->cntl;
      if (cntl.Failed()) {
        stat_rpl_get_log_error_count << 1;
        LOG(WARNING) << "Gaia replication fetch log failed: rpc "
          "failed on requesting logs at lsn = "
          << rpc_ctx->request.start_lsn() << cntl.ErrorText();
        ++ls_info.fetch_invalid_count;
        if (i == 0) {
          ls_info.fetch_error();
        }
        break;
      }

      if (unlikely(FLAGS_secondary_mock_fetch_fail)) {
        break;
      }

      const auto& sub_response = rpc_ctx->response;
      if (sub_response.has_from_lz() && sub_response.from_lz()) {
        stat_rpl_get_log_from_lz_count << 1;
      }
      if (sub_response.has_refresh_zone() && sub_response.refresh_zone() &&
          ls_info.has_zone && sub_response.has_zone()) {
        ++ls_info.fetch_invalid_count;
      }
      const auto sub_request_lsn = rpc_ctx->request.start_lsn();
      ls_vdl = std::max(ls_vdl, sub_response.master_vdl());
      const uint32_t sub_block_num = sub_response.block_num();
      if (sub_response.master_vdl() < sub_request_lsn || sub_block_num == 0) {
        if (i == 0
            && sub_response.has_cn_lowest_gc_lsn()
            && ut_uint64_align_down(sub_response.cn_lowest_gc_lsn(), OS_FILE_LOG_BLOCK_SIZE) > sub_request_lsn) {
          LOG_EVERY_SECOND(WARNING) << "fetch redo slow,"
            << " request_lsn:" << sub_request_lsn
            << " cn_lowest_gc_lsn:" << sub_response.cn_lowest_gc_lsn();
          if (FLAGS_secondary_exit_if_slow_node) {
            ib_error(ER_IB_GAIA_MSG_RPL) << "is slow cn, exit now";
            std::quick_exit(0);
          }
        }
        break;
      }

      LOG(TRACE) << "fetch log succ, start_lsn" << sub_request_lsn
        << ", idx: " << i << "," << depth
        << ", from: " << base::endpoint2str(ls_replica.addr)
        << ", block_nums: " << sub_block_num
        << ", master_vdl: " << sub_response.master_vdl();

      ++succ_depth_num;
      valid_block_num += sub_block_num;

      if (i == 0) {
        response.set_block_no(sub_response.block_no());
        response.set_lowest_lsn(sub_response.lowest_lsn());
        response.set_dispatch_lsn(sub_response.dispatch_lsn());
      }

      response.set_master_vdl(sub_response.master_vdl());
      response.mutable_blocks()->append(sub_response.blocks());
      auto sub_last_block = reinterpret_cast<const byte*>(
          sub_response.blocks().c_str() + (sub_block_num - 1) * OS_FILE_LOG_BLOCK_SIZE);
      if (sub_block_num < req_blocks_n ||
          log_block_get_data_len(sub_last_block) != OS_FILE_LOG_BLOCK_SIZE) {
        break;  // incomplete block num or last block incomplete data
      }
      ut_a(sub_block_num == req_blocks_n);
      if (sub_response.master_vdl() < (rpc_ctx->request.start_lsn()
            + req_blocks_n * OS_FILE_LOG_BLOCK_SIZE)) {
        break;  // vdl < block end lsn
      }
    } // end of loop rpc responses

    {
      static bvar::WindowEx<bvar::IntRecorder, 1> rpl_fetch_succ_depth("cmp_rpl_fetch_succ_depth");
      rpl_fetch_succ_depth << succ_depth_num;
    }

    // 4. check result
    // succ fetch valid redo logs
    if (valid_block_num > 0) {
      response.set_block_num(valid_block_num);
      ls_info.fetch_success();
      break;
    }

    /* if log service vdl > request_lsn and response is empty,
     * the target node is a slow node, switch to another node */
    if (ls_vdl > request_lsn) {
      ls_info.fetch_error();
      continue;
    }

    // need retry
    fetch_empty = true;
    if (req_count % 1024 == 0) {
      ScopedBvarTimerAdder _(&g_rpl_metric->fetch_error_wait);
      ib_warn(ER_IB_GAIA_MSG_RPL)
        << "Log Fetcher: VDL being back-off or less than request lsn."
        << "VDL received=" << response.master_vdl()
        << ", request lsn=" << request_lsn;
      std::this_thread::sleep_for(std::chrono::microseconds(10 * 1000));
      /* retry next node to avoid unknow error */
      ls_info.fetch_error();
    } else {
      sleep_buf_not_enough(req_count);
    }

    if (unlikely(FLAGS_secondary_mock_fetch_fail)) {
      break;
    }

  } while (!rpl_sys->should_stop());

  // succ or stop
  req_count = 0;
  last_succ_depth_num = succ_depth_num;
  last_request_lsn = request_lsn;
  return response.block_num() > 0;
}

static bool log_block_verify_checksum(const byte *block) {
  return (!srv_log_checksums ||
          log_block_get_checksum(block) == log_block_calc_checksum(block));
}

// return start_lsn + copied_size
lsn_t copy_to_log_buffer_for_block(lsn_t start_lsn, lsn_t end_lsn,
                         const byte *source, uint64_t nblocks,
                         byte *dest, uint64_t dest_size,
                         bool need_check) {
  LOG(TRACE) << "copy_to_log_buffer_for_block, start_lsn: " << start_lsn
             << ", end_lsn: " << end_lsn;
  if (end_lsn <= start_lsn) {
    return end_lsn;
  }
  lsn_t next_fetch = start_lsn;
  uint32_t start_block_no = log_block_convert_lsn_to_hdr_no(start_lsn);

  for (size_t i = 0; i < nblocks; i++) {
    auto block = source + i * OS_FILE_LOG_BLOCK_SIZE;
    auto block_no = log_block_get_hdr_no(block);

    if (block_no != log_block_no_advance(start_block_no, i) || !log_block_verify_checksum(block)) {
      ib_warn(ER_IB_GAIA_MSG_RPL)
          << "Log Fetcher: log block corrupted. block no: " << block_no
          << ", expect: " << log_block_no_advance(start_block_no, i);
      break;
    }
    lsn_t block_lsn = ut_uint64_align_down(start_lsn, OS_FILE_LOG_BLOCK_SIZE) +
                      i * OS_FILE_LOG_BLOCK_SIZE;
    if (block_lsn >= end_lsn) {
      break;
    }
#ifdef UNIV_DEBUG
    DBUG_EXECUTE_IF("fetcher_write_redo_block",
                    { fetcher_write_redo_block(block, block_lsn); });
#endif
    lsn_t copy_lsn = block_lsn + LOG_BLOCK_HDR_SIZE;
    if (block_no == start_block_no) {
      copy_lsn = start_lsn;
    }
    if (need_check) {
      ut_a(log_is_data_lsn(copy_lsn));
    }
    sn_t sn = log_translate_lsn_to_sn(copy_lsn);
    byte *ptr = dest + (sn % dest_size);
    byte *buf_end = dest + dest_size;
    uint32_t block_offset = copy_lsn % OS_FILE_LOG_BLOCK_SIZE;
    uint32_t copy_len =
        OS_FILE_LOG_BLOCK_SIZE - block_offset - LOG_BLOCK_TRL_SIZE;
    if (block_lsn + OS_FILE_LOG_BLOCK_SIZE > end_lsn) {
      if (need_check) {
        ut_a(log_is_data_lsn(end_lsn));
      }
      copy_len = log_translate_lsn_to_sn(end_lsn) - sn;
    }
    //    LOG(TRACE) << "copy block: " << block_lsn
    //               << ", copy_start_lsn: " << copy_lsn
    //               << ", block_offset: " << block_offset
    //               << ", copy_len: " << copy_len
    //               << ", copy_offset: " << sn % dest_size;
    next_fetch =
        log_translate_sn_to_lsn(log_translate_lsn_to_sn(copy_lsn + copy_len));
    if (ptr + copy_len > buf_end) {
      auto first_len = buf_end - ptr;
      std::memcpy(ptr, block + block_offset, first_len);
      // round back to begin of ring buffer
      ptr = dest;
      block_offset += first_len;
      copy_len -= first_len;
    }
    std::memcpy(ptr, block + block_offset, copy_len);
  }
  return next_fetch;
}

void RplFetcher::routine() {
  ut_a(g_rpl_conductor->fetch_lsn() > LOG_START_LSN);

  uint32_t wait_for_more_data_count = 0;
  LogServerInfo ls_info;

  if (!ls_info.refresh_replicas()) {
    ib_fatal(UT_LOCATION_HERE, ER_IB_GAIA_MSG_RPL)
      << "Gaia replication system can't get log service addr from manager";
  }

  for (; !rpl_sys->should_stop();) {
    auto master_vdl = g_rpl_conductor->master_vdl();
    auto fetch_lsn = g_rpl_conductor->fetch_lsn();

    g_rpl_conductor->resize_buf_if(true);

    lsn_t request_lsn = ut_uint64_align_down(fetch_lsn, OS_FILE_LOG_BLOCK_SIZE);
    log_service::sec_get_log_response response;
    // 2. repeat fetch until success and has block data
    const bool fetch_ok = do_fetch_until_success(ls_info,
        request_lsn, RplConst::RPL_FETCH_BLOCK_NUMS, response);
    if (!fetch_ok) {
      continue;   // fetcher is stopped, coredump if use response data.
    }

    g_rpl_conductor->update_master_vdl(response.master_vdl());

    master_vdl = g_rpl_conductor->master_vdl();

    // 3. wait space in rpl_sys_t::log_buf and copy data
    const byte *source =
        reinterpret_cast<const byte *>(response.blocks().c_str());

    ut_a(response.block_num() > 0);
    const byte *last_block = reinterpret_cast<const byte *>(
        source + (response.block_num() - 1) * OS_FILE_LOG_BLOCK_SIZE);
    auto last_block_data_len = log_block_get_data_len(last_block);
    lsn_t end_lsn = request_lsn +
              (response.block_num() - 1) * OS_FILE_LOG_BLOCK_SIZE +
              last_block_data_len;
    LOG(TRACE) << "request_lsn: " << request_lsn
               << ", fetch_lsn:" << fetch_lsn
               << ", master_vdl: " << master_vdl << ", end_lsn: " << end_lsn
               << ", final end_lsn: " << std::min(end_lsn, master_vdl);
    end_lsn = std::min(end_lsn, master_vdl);
    if (end_lsn <= fetch_lsn) {
      ScopedBvarTimerAdder _(&g_rpl_metric->fetch_vdl_wait);
      sleep_buf_not_enough(++wait_for_more_data_count);
      continue;
    }

    bool has_space = false;
    {
      ScopedLatencyRecorder _(&g_rpl_metric->fetch_space_wait);
      do {
        lsn_t copy_lsn = 0;
        if (g_rpl_conductor->log_buf_has_space_for_lsn(end_lsn, copy_lsn)) {
          has_space = true;
          break;
        }
        LOG_EVERY_SECOND(WARNING) << "wait for log buf space for,"
          << " fetch_end_lsn:" << end_lsn
          << " buf_free_end_lsn:" << copy_lsn;
        std::this_thread::sleep_for(std::chrono::microseconds(FLAGS_rpl_fetch_sleep_us_buf_is_full));
        update_fetch_speed(0);
      } while (!rpl_sys->should_stop());
    }

    /** stop next steps if not space for copy redo. */
    if (!has_space) {
      continue;
    }

    {
      ScopedLatencyRecorder _(&g_rpl_metric->fetch_buffer_copy);
      auto next_fetch = copy_to_log_buffer_for_block(
          fetch_lsn, end_lsn, source, response.block_num(),
          g_rpl_conductor->log_buf(), g_rpl_conductor->log_buf_size());

      g_rpl_conductor->update_fetch_lsn(next_fetch);
      if (response.has_dispatch_lsn()) {
        g_rpl_conductor->update_ls_dispatch_lsn(response.dispatch_lsn());
      }
      g_rpl_metric->fetch_lsn_diff_vdl << master_vdl - next_fetch;
      g_rpl_metric->parse_lsn_diff_fetch_lsn
          << g_rpl_conductor->fetch_lsn() - g_rpl_conductor->parse_lsn();
      LOG(TRACE) << "copy redo [" << fetch_lsn << ", " << next_fetch << ")";
    }

    if ((end_lsn - fetch_lsn) > FLAGS_rpl_fetch_redo_min_size_no_sleep) {
      wait_for_more_data_count = 0;
    } else {
      sleep_buf_not_enough(++wait_for_more_data_count);
    }

    // 4. update stat info
    auto now_lsn = g_rpl_conductor->fetch_lsn();
    auto fetch_size =
        log_translate_lsn_to_sn(now_lsn) - log_translate_lsn_to_sn(fetch_lsn);
    update_fetch_speed(fetch_size);
  }
}

}  // namespace rpl
