/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_segment_replica.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class UpdateSegmentReplica : public Command {
public:
    UpdateSegmentReplica() {
        SetName("update-segment-replica");
        SetDesc("update an existing replica of segment endpoint information");
        SetDescCn("更新分片副本的端点地址信息");

        AddPsmClusterOption();
        AddRequiredArgOption("segment-id", NULL, 's', "update in the segment", kuint32_t);
        AddRequiredArgOption("replica-id", &_long_opt_val, kOptMax + 2, "will update replica id", kuint32_t);
        AddRequiredArgOption("replica-new-addr", &_long_opt_val, kOptMax + 3, "the new endpoint information", kip_port);
        
        AddExample("--manager-address \"bns://xxx\" --segment-id xx --replica-id x --replica-new-addr xx:1902");
    }
    virtual ~UpdateSegmentReplica() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 's':
            _segment_id = std::strtoul(opt, NULL, 10);
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 2:
                _replica_id.Set(std::strtoul(opt, NULL, 10));
                break;
            case kOptMax + 3:
                _replica_new_addr = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::AckResponse& rsp);

private:
    std::string _manager_address {};
    uint32_t _segment_id {0};
    VarOptional<uint32_t> _replica_id;
    std::string _replica_new_addr {};
};

}
}
