/*****************************************************************************
Copyright (c) 2022, Baidu Inc. All Rights Reserved.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file include/rpl0rpl.h
 Gaiadb binlog in redo flush and sync

 Created 10/21/2021 Hongyu Qiao
 *******************************************************/

#include "rpl0parse.h"
#include "rpl0rpl.h"
#include "rpl0conductor.h"
#include "rpl0fetch.h"
#include "srv0srv.h"
#include "log0log.h"
#include "log0files_io.h"
#include "sql/binlog.h"
#include "gaiadb.h"
#include "base/endpoint.h"
#include "log0recv.h"
#include "gaiadb.h"
#include "gaiadb_manager.h"

namespace rpl {
static const char *const binlog_flusher_str = "rpl_binlog_flusher";

/* gaiadb replication log binlog flush thread */
void rpl_binlog_flusher() {
  DBUG_ENTER("rpl_binlog_flusher");
  setpriority(PRIO_PROCESS, (pid_t)syscall(SYS_gettid), -20);
#ifdef UNIV_LINUX_ONLY
  pthread_setname_np(pthread_self(), binlog_flusher_str);
#endif
  ib_info(ER_IB_GAIA_MSG_RPL)
      << "Gaia replication binlog flusher threads started";

  for (uint64_t step = 0;; ++step) {

    if (RplSys::get_instance().should_stop()) {
      break;
    }
    lsn_t flushed_lsn = g_rpl_conductor->flush_lsn();
    lsn_t parsed_lsn = g_rpl_conductor->parse_lsn();

    std::pair<bool, BinlogInRedoInfo> primary_result = gaiadb_get_primary_binlog_in_redo_info();
    BinlogInRedoInfo primary_info = primary_result.second;

    if (parsed_lsn <= flushed_lsn 
        || (primary_result.first && primary_info.binlog_sync_lsn <= binlog_in_redo_meta.sync_lsn)) {
      std::this_thread::sleep_for(std::chrono::microseconds(20));
      continue;
    }

    if (srv_gaia_binlog_in_redo_log) {
      mutex_enter(g_rpl_conductor->binlog_mutex());
      g_rpl_conductor->binlog_recover()->sync();
      mutex_exit(g_rpl_conductor->binlog_mutex());
    }
    binlog_in_redo_meta.sync_lsn = parsed_lsn;
    g_rpl_conductor->update_flush_lsn(parsed_lsn);
  }
  ib_info(ER_IB_GAIA_MSG_RPL)
      << "Gaia replication binlog flusher threads stopped";
  DBUG_VOID_RETURN;
}

struct BinlogRecoverFromRedo {
  using stub = log_service::SecondaryService_Stub;

  LogServerInfo ls_info;
  gaiadb::common::RpcClient rpl_client;
  uint32_t req_count;
  /* for fetch */
  ut::aligned_array_pointer<byte, OS_FILE_LOG_BLOCK_SIZE> log_buf;
  size_t log_buf_size;
  /* for parse */
  ut::aligned_array_pointer<byte, OS_FILE_LOG_BLOCK_SIZE> parse_log_buf;
  size_t parse_log_buf_size;
  size_t parse_data_pos;
  size_t parse_data_len;

  lsn_t fetch_lsn;
  lsn_t parse_lsn;
  lsn_t copy_lsn;

  BinlogRecoverFromRedo()
    : req_count(0),
    log_buf_size(0),
    parse_log_buf_size(0),
    parse_data_pos(0),
    parse_data_len(0),
    fetch_lsn(0),
    parse_lsn(0),
    copy_lsn(0) {}
  ~BinlogRecoverFromRedo() {}

  void init(lsn_t lsn, size_t buf_size) {
    fetch_lsn = lsn;
    parse_lsn = lsn;
    copy_lsn = lsn;

    log_buf_size = ut_uint64_align_up(buf_size, OS_FILE_LOG_BLOCK_SIZE);
    parse_log_buf_size = log_buf_size * 2;
    /* buf will auto release */
    log_buf.alloc_withkey(UT_NEW_THIS_FILE_PSI_KEY, ut::Count{log_buf_size});
    parse_log_buf.alloc_withkey(UT_NEW_THIS_FILE_PSI_KEY, ut::Count{parse_log_buf_size});

    if (!ls_info.refresh_replicas()) {
      ib_fatal(UT_LOCATION_HERE, ER_GAIA_BINLOG_IN_REDO)
        << "Gaia binlog recover can't get log service addr from manager";
    }
  }

  bool log_buf_has_space_for_lsn(lsn_t lsn) {
    return log_translate_lsn_to_sn(lsn) + 2 * OS_FILE_LOG_BLOCK_SIZE <=
      log_translate_lsn_to_sn(copy_lsn) + log_buf_size;
  }

  /**
   * retry if return < 0
   * return 0 is ok
   * return > 0 maybe corrupted
   */
  int32_t fetch_log(lsn_t end_lsn) {
    lsn_t start_lsn = fetch_lsn;
    lsn_t request_lsn = ut_uint64_align_down(start_lsn, OS_FILE_LOG_BLOCK_SIZE);
    uint32_t req_blocks_n = (end_lsn - request_lsn) / OS_FILE_LOG_BLOCK_SIZE;
    if (req_blocks_n > RplConst::RPL_FETCH_BLOCK_NUMS) {
      req_blocks_n = RplConst::RPL_FETCH_BLOCK_NUMS;
    }

    baidu::rpc::Controller cntl;
    log_service::sec_get_log_request request;
    log_service::sec_get_log_response response;

    if (ls_info.need_refresh_replicas()) {
      if (!ls_info.refresh_replicas()) {
        if (req_count % 128 == 0) {
          ib_error(ER_IB_GAIA_MSG_RPL)
            << "Gaia binlog recover fetch log failed: "
            "rpc failed on get log serice addr";
        }
        std::this_thread::sleep_for(std::chrono::microseconds(1000 * 100));  // sleep 100ms if psm do not work
        ls_info.reuse_maybe_error_replicas();
      }
    } else if (ls_info.refresh_zone()) {
      ls_info.resort_replicas();
    }
    if (ls_info.replicas.empty()) {
      return -1; // empty nodes list
    }

    auto &ls_replica = ls_info.get_replica();

    request.set_start_lsn(request_lsn);
    request.set_expect_blocks(std::max(1u, req_blocks_n));
    request.set_block_no(log_block_convert_lsn_to_hdr_no(request_lsn));
    request.set_server_id(1);
    if (ls_info.has_zone && ls_replica.has_zone()) {
      request.mutable_zone()->set_region(ls_replica.region);
      request.mutable_zone()->set_available_zone(ls_replica.available_zone);
    }

    LOG(TRACE) << "fetch log, start_lsn: " << start_lsn
      << ", from: " << ls_replica.addr;
    rpl_client.Call(&cntl, ls_replica.addr, &stub::get_log, &request,
        &response, nullptr);

    if (cntl.Failed()) {
      LOG(WARNING) << "Gaia binlog recover fetch log failed: rpc "
        "failed on requesting logs at lsn = "
        << start_lsn << "," <<  cntl.ErrorText();
      ++ls_info.fetch_invalid_count;
      return -1;
    }

    if (response.has_refresh_zone() && response.refresh_zone() &&
        ls_info.has_zone && response.has_zone()) {
      ++ls_info.fetch_invalid_count;
    }

    LOG(TRACE) << "fetch log ok, start_lsn" << start_lsn
      << ", from: " << base::endpoint2str(ls_replica.addr)
      << ", block_nums: " << response.block_num()
      << ", master_vdl: " << response.master_vdl();

    lsn_t ls_vdl = response.master_vdl();
    uint32_t valid_block_num = response.block_num();
    if (ls_vdl < start_lsn || valid_block_num == 0) {
      ls_info.fetch_error();
      ib_fatal(UT_LOCATION_HERE, ER_GAIA_BINLOG_IN_REDO)
        << "Gaia binlog recover system can't get enough data from log service,"
        << " vdl:" << ls_vdl
        << ", start_lsn:" << start_lsn
        << ", valid_block_num:" << valid_block_num;
      return 1;
    }

    const byte *source = reinterpret_cast<const byte *>(response.blocks().c_str());
    const byte *last_block = source + (valid_block_num - 1) * OS_FILE_LOG_BLOCK_SIZE;
    uint32_t last_block_data_len = log_block_get_data_len(last_block);
    lsn_t each_end_lsn = request_lsn +
        (valid_block_num - 1) * OS_FILE_LOG_BLOCK_SIZE +
        last_block_data_len;
    each_end_lsn = std::min({end_lsn, each_end_lsn, ls_vdl});

    ls_info.fetch_success();
    LOG(TRACE) << "request_lsn: " << request_lsn
               << ", end_lsn: " << end_lsn
               << ", final end_lsn: " << each_end_lsn;

    if (each_end_lsn < start_lsn) {
      ib_fatal(UT_LOCATION_HERE, ER_GAIA_BINLOG_IN_REDO)
        << "Gaia binlog recover system can't get enough data from log service,"
        << " each_end_lsn:" << each_end_lsn
        << ", vdl:" << ls_vdl
        << ", start_lsn:" << start_lsn
        << ", end_lsn:" << end_lsn;
      return 1;
    }

    if (log_buf_has_space_for_lsn(each_end_lsn)) {
      fetch_lsn = copy_to_log_buffer_for_block(start_lsn, each_end_lsn, source, valid_block_num,
          log_buf, log_buf_size, false/*need check data in log*/);
    }
    return 0;
  }

  lsn_t copy_fetch_buf(bool move) {
    if (copy_lsn >= fetch_lsn) {
      return 0;
    }

    if (move && parse_data_pos > 0) {
      ut_a(parse_data_len >= parse_data_pos);
      std::memmove(parse_log_buf, parse_log_buf + parse_data_pos,
          parse_data_len - parse_data_pos);
      parse_data_len -= parse_data_pos;
      parse_data_pos = 0;
    }

    byte *log_buf_end = log_buf + log_buf_size;

    sn_t start_sn = log_translate_lsn_to_sn(copy_lsn);
    sn_t fetch_sn = log_translate_lsn_to_sn(fetch_lsn);

    auto copy_size = fetch_sn - start_sn;
    auto remain_size = parse_log_buf_size - parse_data_len;
    if (copy_size > remain_size) {
      copy_size = remain_size;
    }

    byte *ptr = log_buf + (start_sn % log_buf_size);
    byte *end_ptr = ptr + copy_size;

    if (end_ptr <= log_buf_end) {
      std::memcpy(parse_log_buf + parse_data_len, ptr, copy_size);
    } else {
      auto part_size = log_buf_end - ptr;
      std::memcpy(parse_log_buf + parse_data_len, ptr, part_size);
      std::memcpy(parse_log_buf + parse_data_len + part_size, log_buf, copy_size - part_size);
    }
    parse_data_len += copy_size;

    copy_lsn = recv_calc_lsn_on_data_add(copy_lsn, copy_size);
    LOG(TRACE) << "copy buf size:" << copy_size
      << ", fetch_lsn:" << fetch_lsn << ", copy_lsn:" << copy_lsn;
    return copy_size;
  }

  bool parse_log(bool binlog_in_redo) {
    uint64_t expect_parse_len = (8<<20);
    sn_t fetch_sn = log_translate_lsn_to_sn(fetch_lsn);
    sn_t start_sn = log_translate_lsn_to_sn(parse_lsn);

    copy_fetch_buf(true);

    byte *ptr = parse_log_buf + parse_data_pos;
    byte *buf_end = parse_log_buf + parse_data_len;

    if (fetch_sn - start_sn < expect_parse_len) {
      expect_parse_len = fetch_sn - start_sn;
    }
    byte *end_ptr = ptr + expect_parse_len;
    if (end_ptr > buf_end) {
      end_ptr = buf_end;
    }

    auto record_start_lsn = parse_lsn;
    auto cur_ptr = ptr;
    for (; cur_ptr <= end_ptr; ) {
      mlog_id_t type;
      page_no_t page_no;
      space_id_t space_id;
      byte *body;
      uint32_t check_bits_len = 0;
      uint64_t len = parse_one_log_rec(cur_ptr, end_ptr, &type, &space_id,
          &page_no, &body, &check_bits_len);
      if (len == 0) {
        break;
      }
      switch (type) {
        case MLOG_GAIA_BINLOG_DATA: {
          uint32_t index_num;
          uint64_t pos;
          innodb::binlog_redo_op_t binlog_redo_op_type;
          uint64_t body_len;
          uint32_t check_bits_len;
          byte *body_ptr = mlog_parse_initial_binlog_log_record(
              cur_ptr, end_ptr, &type, &binlog_redo_op_type, &index_num, &pos, &body_len,
              &check_bits_len);
          ut_a(body_ptr);
          if (binlog_in_redo) {
            mutex_enter(g_rpl_conductor->binlog_mutex());
            g_rpl_conductor->binlog_recover()->apply(binlog_redo_op_type, index_num, pos, body_ptr,
                body_len, check_bits_len);
            mutex_exit(g_rpl_conductor->binlog_mutex());
          }
          break;
        }
        default:
          break;
      }

      // check record start lsn
      lsn_t real_rec_start_lsn = 0;
      switch (check_bits_len) {
      case 0:
        /* don't has check bits */
        break;
      case (innodb::RECORD_CHECK_BITS_LEN + innodb::PAGE_CHECK_BITS_LEN):
        [[fallthrough]];
      case innodb::RECORD_CHECK_BITS_LEN:
        real_rec_start_lsn = mach_read_from_8(cur_ptr + len - check_bits_len);
        break;
      default:
        LOG(ERROR) << "invalid check bits len: " << check_bits_len;
        ut_error;
      }

      if (real_rec_start_lsn != 0 && real_rec_start_lsn != record_start_lsn) {
        LOG(ERROR) << "record start lsn mismatch"
          << ", real_rec_start_lsn: " << real_rec_start_lsn
          << ", record_start_lsn: " << record_start_lsn;
        ut_error;
      }
      record_start_lsn = recv_calc_lsn_on_data_add(record_start_lsn, len);

      cur_ptr += len;
    }
    size_t total_len = cur_ptr - ptr;
    ut_a(total_len <= parse_data_len - parse_data_pos);
    parse_data_pos += total_len;
    parse_lsn = recv_calc_lsn_on_data_add(parse_lsn, total_len);
    return total_len > 0;
  }

};

bool rpl_binlog_in_redo_flusher(bool binlog_in_redo) {
  if (!binlog_in_redo) {
    ib_system(ER_GAIA_BINLOG_IN_REDO) << "binlog in redo recover disabled";
    return false;
  }
  size_t buf_size = srv_log_buffer_size;
  lsn_t start_lsn = binlog_in_redo_meta.sync_lsn;
retry_resize_buf:
  BinlogRecoverFromRedo binlog_recover;
  binlog_recover.init(start_lsn, buf_size);
  const lsn_t end_lsn = rpl::get_apply_lsn();
  ib_info(ER_GAIA_BINLOG_IN_REDO) << "binlog in redo recover, start_lsn:" << start_lsn
      << " end_lsn:" << end_lsn;
  if (!binlog_recover.log_buf) {
    LOG(ERROR) << "init binlog recover buf failed";
    return true;
  }
  while (binlog_recover.parse_lsn < end_lsn) {
    if (binlog_recover.fetch_log(end_lsn) > 0) {
      ib_warn(ER_GAIA_BINLOG_IN_REDO) << "binlog in redo recover failed";
      return true;
    }
    if (!binlog_recover.parse_log(binlog_in_redo)) {
      if (binlog_recover.parse_data_len - binlog_recover.parse_data_pos > buf_size / 2) {
        buf_size = buf_size * 1.382;
        start_lsn = binlog_recover.parse_lsn;
        ib_warn(ER_GAIA_BINLOG_IN_REDO) << "binlog in redo recover resize buf,"
          << " buf_len:" << binlog_recover.parse_data_len
          << " buf_pos:" << binlog_recover.parse_data_pos
          << " buf_size:" << buf_size;
        goto retry_resize_buf;
      }
      continue;
    }

    mutex_enter(g_rpl_conductor->binlog_mutex());
    g_rpl_conductor->binlog_recover()->sync();
    mutex_exit(g_rpl_conductor->binlog_mutex());
  }
  ib_system(ER_GAIA_BINLOG_IN_REDO) << "binlog in redo recover done";
  return false;
}

}  // namespace rpl
