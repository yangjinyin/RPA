#include "bir0async_binlog.h"
#include <ctype.h>
#include <base/base64.h>
#include <openssl/hmac.h>
#include <baidu/rpc/uri.h>
#include <baidu/rpc/details/http_message.h>
#include <openssl/aes.h>
#include "gaiadb/common/global_flags.h"
#include "rpl0rpl.h"
#include "rpl0parse.h"
#include "gaiadb/redo_fetch/fetch_mdc_object.h"
#include "gaiadb/redo_fetch/fetch_mdc_utils.h"
#include "rpl0conductor.h"
namespace bir {

void BirAsyncBinlog::fetch_routine() {
  while (!is_stop()) {

    resize_buf_if(false);
    lsn_t next_fetch = fetch_lsn_;
    bool last_fetch_from_bos = false;
    if (fetch_log(&last_fetch_from_bos) > 0) {
      LOG(ERROR) << "binlog in redo recover failed";
      return;
    }
    if (is_stop()) {
      break;
    }

    if (next_fetch >= fetch_lsn_) {
      std::this_thread::sleep_for(std::chrono::microseconds(1000));
    }
  }
}

// By default, fetching is performed according to RplConst::RPL_FETCH_BLOCK_NUMS.
int32_t BirAsyncBinlog::fetch_log(bool *last_fetch_from_bos, lsn_t end_lsn) {

  rpl::LogServerInfo ls_info;
  if (!ls_info.refresh_replicas()) {
    LOG(ERROR)
      << "Gaia binlog recover can't get log service addr from manager";
  }
  uint32_t wait_for_more_data_count = 0;
  uint32_t max_count = rpl::FLAGS_rpl_max_sleep_us_redo_not_enough /
                       rpl::FLAGS_rpl_interval_sleep_us_redo_not_enough + 1;

  int ret = FETCH_ERROR::SUCCESS;
  if (*last_fetch_from_bos) {
    ret = fetch_mdc_log();
    if (ret == FETCH_ERROR::SUCCESS) {
      LOG(NOTICE) << "fetch mdc log ok";
      return 0;
    } else{
      *last_fetch_from_bos = false;
    }
  }

  // ls: -2: The lsn is not found; -1: Returns failure; 0: Success; 
  // >0: Insufficient data retrieved, sleep is required before continuing execution.
  
  while ((ret = fetch_ls_log(ls_info, ret, end_lsn)) > 0 && !is_stop()) {
    if (wait_for_more_data_count > max_count) {
      wait_for_more_data_count = 0;
    }
    rpl::sleep_buf_not_enough(++wait_for_more_data_count);
  }
  if (ret == FETCH_ERROR::SUCCESS) { 
    LOG(TRACE) << "fetch ls log ok";
  } else if (ret == FETCH_ERROR::NOT_FOUND_LSN) {
    ret = fetch_lz_log(ls_info);
    if (ret == FETCH_ERROR::SUCCESS) {
      LOG(TRACE) << "fetch lz log ok";
    } else if (ret == FETCH_ERROR::NOT_FOUND_LSN) {
      ret = fetch_mdc_log();
      if (ret == FETCH_ERROR::SUCCESS) {
        *last_fetch_from_bos = true;
        LOG(TRACE) << "fetch mdc log ok";
      }
    }
  }

  LOG_IF(WARNING, ret != FETCH_ERROR::SUCCESS)
    << "Gaia bir binlog recover fetch failed,"
    << ", fetch_lsn:" << fetch_lsn_
    << ", parse_lsn:" << parse_lsn_
    << ", copy_lsn:" << copy_lsn_;

  return 0;
}

int32_t BirAsyncBinlog::copy_to_fetch_log_buf(
  const char *buffer, uint32_t valid_block_num, lsn_t ls_vdl, lsn_t target_lsn) {
  lsn_t start_lsn = fetch_lsn_;
  lsn_t request_lsn = ut_uint64_align_down(start_lsn, OS_FILE_LOG_BLOCK_SIZE);
  const byte *source = reinterpret_cast<const byte *>(buffer);
  const byte *last_block = source + (valid_block_num - 1) * OS_FILE_LOG_BLOCK_SIZE;
  uint32_t last_block_data_len = log_block_get_data_len(last_block);
  lsn_t each_end_lsn = request_lsn +
      (valid_block_num - 1) * OS_FILE_LOG_BLOCK_SIZE +
      last_block_data_len;
  if (target_lsn != 0) {
    each_end_lsn = std::min({target_lsn, each_end_lsn, ls_vdl});
  } else {
    each_end_lsn = std::min({each_end_lsn, ls_vdl});
  }

  if (each_end_lsn <= start_lsn) {
    return FETCH_ERROR::DATA_NOT_ENOUGH;
  }

  if (log_buf_has_space_for_lsn(each_end_lsn)) {
    fetch_lsn_ = rpl::copy_to_log_buffer_for_block(
        start_lsn, each_end_lsn, source, valid_block_num,
        log_buf(), log_buf_size(), false/*need check data in log*/);
  } else {
    LOG_EVERY_SECOND(NOTICE) << "wait for log buf space for,"
      << " fetch_end_lsn:" << each_end_lsn
      << " buf_end_lsn:" << copy_lsn_;
    std::this_thread::sleep_for(std::chrono::microseconds(1000));
  }
  return FETCH_ERROR::SUCCESS;
}

// fetch landing zone

uint32_t BirAsyncBinlog::calc_redo_buf_real_block_num(const std::string& redo_buf) {
    const byte* first_block = reinterpret_cast<const byte*>(&redo_buf[0]);
    uint32_t block_num = redo_buf.size() / OS_FILE_LOG_BLOCK_SIZE;
    for (uint32_t i = 0; i < block_num; ++i) {
        const byte* block = first_block + i * OS_FILE_LOG_BLOCK_SIZE;
        if (log_block_get_data_len(block) == 0) {
            return i;
        }
    }
    return block_num;
}

bool BirAsyncBinlog::log_buf_has_space_for_lsn(lsn_t lsn) {
  return log_translate_lsn_to_sn(lsn) + 2 * OS_FILE_LOG_BLOCK_SIZE <=
    log_translate_lsn_to_sn(copy_lsn_) + log_buf_size();
}

}
