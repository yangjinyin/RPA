/***************************************************************************
 * Copyright (c) Baidu.com, Inc. All Rights Reserved
 **************************************************************************/
/**
 * @file gaia/get_page_server_compress_config.cpp
 * @author yukeyong@baidu.com
 * @brief
 */

#include "gaia/get_page_server_compress_config.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int GetPageServerCompressConfig::Run() {
    RpcStatus status;

    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    if (_cluster_id.empty()) {
        print_error("miss --cluster-id");
        return 1;
    }

    pspb::GetCompressConfigRequest request;
    pspb::GetCompressConfigResponse response;

    request.set_log_id(_log_id);
    request.set_cluster_id(_cluster_id);
    if (_segment_id.has_val) {
        request.set_segment_id(_segment_id.val);
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    _client.Call(
            _log_id,
            node,
            &pspb::QueryService_Stub::GetCompressConfig,
            &request,
            &response,
            nullptr,
            &status,
            _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int GetPageServerCompressConfig::Format(const pspb::GetCompressConfigResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.segments_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName(
                {"cluster_id", "segment_id", "compress_enable", "compress_type", "compress_level"},
                true);
        for (auto& seg : rsp.segments()) {
            table.AddRowsValue(
                    {seg.cluster_id(),
                     seg.segment_id(),
                     seg.compress_cfg().enable(),
                     seg.compress_cfg().type(),
                     seg.compress_cfg().level()});
        }
        table.Display();
    }
    return 0;
}

}  // namespace gaia
}  // namespace psvr
