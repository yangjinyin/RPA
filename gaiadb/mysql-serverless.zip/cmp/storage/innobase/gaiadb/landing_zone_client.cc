/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/landing_zone_client.cc
 client for read/write landing_zone

 Created 11/1/2022 Hongyu Qiao
 *******************************************************/
#include <gaiadb/rpc_client/rpc_call.h>

#include "landing_zone_client.h"
#include "gaiadb/proto/log_service/lsrv_message_service.pb.h"
#include "gaiadb/proto/log_service/lsrv_error_code.pb.h"
#include "log0buf.h"
#include "log0write.h"
#include "log0log.h"

#define LOG_SERVICE_TRACKER_REFRESH_INTERVAL_IN_SECONDS 10

DEFINE_bool(enable_quorum_mode, false, "enable quorum io stack");

namespace landing_zone {

DEFINE_int32(gaia_redo_store_replicas, 3, "replicas of gaiadb redo log storage");

DEFINE_bool(write_with_polar_client, false, "pwrite rquest with use polar client");
BAIDU_RPC_VALIDATE_GFLAG(write_with_polar_client, baidu::rpc::PassValidate);

static bvar::LatencyRecorder gaia_write_rpc_lat("gaia_write_rpc");

static const uint32_t VDL_TIMER_INTERVAL_MS = 5;
static const uint32_t VDL_TIMER_WAKE_UP_TIMES_IN_1S = 1000 / VDL_TIMER_INTERVAL_MS;

inline base::EndPoint node2endpoint(const log_service::NodeId& id) {
  base::EndPoint addr;
  addr.ip.s_addr = id.ip();
  addr.port = id.port();
  return addr;
}

SendVDLTimer::SendVDLTimer() : _landing_zone_client(nullptr), _vdl_sync_by_timer(0), _wakeup_times(0) {}

SendVDLTimer::~SendVDLTimer() { destroy(); }

void SendVDLTimer::run() {
  if(!srv_rpl_primary){
      return;
  }
  ut_a(log_sys != nullptr);
  ut_a(_landing_zone_client != nullptr);

  bool force_sync_vdl_in_1s_window = false;
  if (_wakeup_times.fetch_add(1) == VDL_TIMER_WAKE_UP_TIMES_IN_1S - 1) {
    _wakeup_times.store(0);
    force_sync_vdl_in_1s_window = true;
  }

  auto vdl = log_get_vdl(*log_sys);
  if (force_sync_vdl_in_1s_window || (vdl > _vdl_sync_by_timer.load() && vdl > _landing_zone_client->get_vdl_sync_by_pwrite())) {
      if (0 == _landing_zone_client->send_vdl(log_get_vdl(*log_sys))) {
          LOG(TRACE) << "SendVDLTimer send vdl to log_service: " << vdl;
          _vdl_sync_by_timer.store(vdl);
      } else {
          LOG(WARNING) << "SendVDLTimer send vdl to log_service failed: " << vdl;
      }
  } else {
      LOG(TRACE) << "SendVDLTimer has ignored to send vdl to log_service: " << vdl;
  }
}

void SendVDLTimer::on_destroy() {
  LOG(TRACE) << "SendVDLTimer destroy";
}

void SendVDLTimer::set_landing_zone_client(LandingZoneClient* lz_client) {
  _landing_zone_client = lz_client;
}

// TODO: log-service advance VDL instead of primary to reduce master-slave latency
void SendVDLTimer::start_timer() {
  //5ms
  init(VDL_TIMER_INTERVAL_MS);
  start();
  LOG(TRACE) << "SendVDLTimer start";
}

LogServiceRaftLeaderTracker::LogServiceRaftLeaderTracker()
        : _psm_client(nullptr) {
  LOG(NOTICE) << "LogServiceRaftLeaderTracker " << std::hex << this << " created";
}

LogServiceRaftLeaderTracker::~LogServiceRaftLeaderTracker() { destroy(); }

void LogServiceRaftLeaderTracker::on_destroy() {
  LOG(NOTICE) << "LogServiceRaftLeaderTracker " << std::hex << this << " destroyed";
}

void LogServiceRaftLeaderTracker::run() { (void)refresh_leader();}

bool LogServiceRaftLeaderTracker::check(gaiadb::psm_client::Psmgr_client* client) {
  _psm_client = client;
  if (!refresh_leader()) {
      LOG(WARNING) << "LogServiceRaftLeaderTracker init failed,"
                      " first refresh leader failed";
      return false;
  }
  LOG(NOTICE) << "LogServiceRaftLeaderTracker init success";
  return true;
}

base::EndPoint LogServiceRaftLeaderTracker::get_leader() {
  std::lock_guard<bthread::Mutex> guard(_lock);
  return _leader_addr;
}

void LogServiceRaftLeaderTracker::get_peers(std::vector<gaiadb::common::PeerZone> *ls_peers) {
  ls_peers->clear();
  std::lock_guard<bthread::Mutex> guard(_lock);
  *ls_peers = _ls_peers;
}

bool LogServiceRaftLeaderTracker::refresh_peers() {
  std::vector<gaiadb::common::PeerZone> endpoints;
  if (gaiadb::GIE_OK !=
          _psm_client->get_log_services(endpoints)) {
      LOG(WARNING) << "LogServiceRaftLeaderTracker get log_service peers failed";
      return false;
  }
  if (endpoints.empty()) {
      LOG(WARNING) << "LogServiceRaftLeaderTracker get log_service peers size=0";
      return false;
  }
  std::lock_guard<bthread::Mutex> guard(_lock);
  _ls_peers.swap(endpoints);
  return true;
}

bool LogServiceRaftLeaderTracker::refresh_leader() {
  std::vector<gaiadb::common::PeerZone> endpoints;
  if (!refresh_peers()) {
      return false;
  }
  get_peers(&endpoints);
  std::map<base::EndPoint, int> candidates;
  for (auto& peer: endpoints) {
      std::shared_ptr<baidu::rpc::Channel> channel_ptr;
      if (!gaiadb::common::RpcChannelCache<
              gaiadb::common::DESTINATION::LOG_SERVICE>::GetInstance()->get_rpc_channel(
                  peer.addr, &channel_ptr)) {
          LOG(WARNING) << "LogServiceRaftLeaderTracker create channel failed: " << peer;
          return false;
      }

      log_service::lsrv_empty_message request;
      log_service::check_leader_response response;
      log_service::LogServiceService_Stub stub(channel_ptr.get());
      baidu::rpc::Controller cntl;
      stub.check_leader(&cntl, &request, &response, nullptr);

      if (cntl.Failed()) {
          continue;
      }

      if (0 == response.status().code()) {
          candidates[peer.addr]++;
      } else if (response.status().has_leader_hint()) {
          log_service::NodeId leader_addr = response.status().leader_hint();
          candidates[node2endpoint(leader_addr)]++;
      }
  }

  bool ok = false;
  base::EndPoint leader;

  int max_vote = 0;
  for (auto candidate_it = candidates.begin();
      candidate_it != candidates.end(); ++candidate_it) {
      if (candidate_it->second > max_vote) {
          leader = candidate_it->first;
          max_vote = candidate_it->second;
          ok = true;
      }
  }

  std::random_shuffle(endpoints.begin(), endpoints.end());
  {
      std::lock_guard<bthread::Mutex> guard(_lock);
      if (ok) {
          _leader_addr = leader;
      } else {
          _leader_addr = endpoints[0].addr;
      }
  }
  if (ok) {
      LOG_EVERY_SECOND(TRACE) << "refresh log_service raft leader: " << leader;
  } else {
      LOG(WARNING) << "refresh log_service raft leader failed";
  }
  return ok;
}

LandingZoneClient::LandingZoneClient()
  : _epoch(0), _membership_epoch(0), _psm_client(nullptr), _vdl_sync_by_pwrite(0)
  , last_increase_epoch_lsn_(0) {}

LandingZoneClient::~LandingZoneClient() {}

lsn_t LandingZoneClient::last_increase_epoch_lsn() {
  return last_increase_epoch_lsn_.load();
}

bool LandingZoneClient::init(gaiadb::psm_client::Psmgr_client* client) {
  ut_a(client != nullptr);
  _psm_client = client;
  _send_vdl_timer.set_landing_zone_client(this);
  if (!_ls_tracker.check(client)) {
      LOG(WARNING) << "LogServiceRaftLeaderTracker check failed";
      return false;
  }
  _ls_tracker.init(LOG_SERVICE_TRACKER_REFRESH_INTERVAL_IN_SECONDS * 1000);
  _ls_tracker.start();
  return true;
}

void LandingZoneClient::start_send_vdl_timer() {
  _send_vdl_timer.start_timer();
}

void LandingZoneClient::stop_send_vdl_timer() {
  _ls_tracker.destroy();
  _send_vdl_timer.destroy();
}

struct PreadContext {
  ::log_service::pread_response response;
  baidu::rpc::Controller cntl;
};

static bool compare_and_deal_response(std::vector<PreadContext>& contexts,
                               byte* buffer, uint64_t len, uint64_t start_lsn) {

  uint64_t max_end_lsn = start_lsn;
  int result_index = -1;
  for (decltype(contexts.size()) i = 0; i < contexts.size(); ++i) {
      auto& cntl = contexts[i].cntl;
      auto& response = contexts[i].response;
      if (cntl.Failed()) {
          LOG(WARNING) << "pread failed, errno: " << cntl.ErrorCode()
                       << ", error: " << cntl.ErrorText();
          continue;
      }
      if (response.status().code() != log_service::GIE_OK) {
          LOG(WARNING) << "pread failed, errno: " << response.status().code()
                       << ", error: " << response.status().msg()
                       << ", server: " << base::endpoint2str(cntl.remote_side());
          continue;
      }
      LOG(TRACE) << "pread success from " << base::endpoint2str(cntl.remote_side())
                 << ", start_lsn: " << start_lsn << ", len: " << len;
      uint64_t end_lsn = start_lsn;
      const byte* buf = reinterpret_cast<const byte*>(response.buffer().c_str());
      for (lsn_t lsn = start_lsn;
              lsn < start_lsn + response.read_size();
              lsn += OS_FILE_LOG_BLOCK_SIZE) {
          if (log_block_get_data_len(buf + lsn - start_lsn) > 0) {
              end_lsn = lsn + log_block_get_data_len(buf + lsn - start_lsn);
          } else {
              break;
          }
      }
      LOG(TRACE) << "end_lsn of " << base::endpoint2str(cntl.remote_side()) << ":" << end_lsn;
      if (end_lsn >= max_end_lsn) {
          result_index = i;
          max_end_lsn = end_lsn;
      }
  }
  if (result_index >= 0) {
      memcpy(buffer, contexts[result_index].response.buffer().c_str(), len);
      return true;
  }
  return false;
}

int LandingZoneClient::pread(uint64_t start_lsn, uint64_t offset,
                             uint64_t len, byte* buffer) {
  log_service::pread_request request;
  request.set_cluster_id(_psm_client->get_cluster_id());
  request.set_offset(offset);
  request.set_len(len);
  request.set_lsn(start_lsn);
  request.set_epoch(_epoch.load());
  if (FLAGS_enable_quorum_mode) {
      request.set_enable_quorum(true);
  }
  if (!FLAGS_enable_quorum_mode || offset < LOG_FILE_HDR_SIZE) {
      baidu::rpc::Controller cntl;
      cntl.set_log_id(redo_log_id++);
      log_service::pread_response response;

      auto endpoint = _ls_tracker.get_leader();
      LOG(TRACE) << "landing_zone pread start_lsn:" << start_lsn;
      gaiadb::common::issue_rpc<
          log_service::pread_request,
          log_service::pread_response,
          log_service::LandingZoneService_Stub,
          gaiadb::common::DESTINATION::LOG_SERVICE>(
                  endpoint, &log_service::LandingZoneService_Stub::pread,
                  &request, &response, nullptr, nullptr, nullptr, nullptr, &cntl);
      if (cntl.Failed()) {
          LOG(WARNING) << "landing zone pread failed, offset: "
                       << offset << ", len: " << len
                       << ", error: " << cntl.ErrorText();
          return -1;
      }
      if (response.status().code() != log_service::GIE_OK) {
          LOG(WARNING) << "landing zone pread failed, offset: "
                       << offset << ", len: " << len
                       << ", error: " << response.status().msg();
          return -1;
      }
      if (len != response.read_size()) {
          LOG(WARNING) << "landing zone pread failed, offset: "
                       << offset << ", len: " << len
                       << ", error: len != response.read_size";
          return -1;
      }
      memcpy(buffer, response.buffer().c_str(), len);

      return 0;

  } else {
      std::vector<gaiadb::common::PeerZone> ls_peers;
      for (int retries = 0; retries < 5; retries++) {
          _ls_tracker.get_peers(&ls_peers);
          std::random_shuffle(ls_peers.begin(), ls_peers.end());
          if (_psm_client->has_zone()) {
            std::string region;
            std::string available_zone;
            if (_psm_client->get_zone(&region, &available_zone)
                && !region.empty() && !available_zone.empty()) {
              gaiadb::common::sort_peer_zone_vector(ls_peers, region, available_zone);
            }
          }
          int quorum_read_set = ls_peers.size() / 2 + 1;
          std::vector<PreadContext> contexts{(uint64_t)quorum_read_set};
          for (int i = 0; i < quorum_read_set; i++) {
              LOG(TRACE) << "read lz from " << ls_peers[i]
                  << ", lsn: " << start_lsn << ", len: " << len;
              gaiadb::common::issue_rpc<
                  log_service::pread_request,
                  log_service::pread_response,
                  log_service::LandingZoneService_Stub,
                  gaiadb::common::DESTINATION::LOG_SERVICE>(
                          ls_peers[i].addr, &log_service::LandingZoneService_Stub::pread,
                          &request, &contexts[i].response, nullptr, nullptr, nullptr,
                          nullptr, &contexts[i].cntl);
          }
          if (compare_and_deal_response(contexts, buffer, len, start_lsn)) {
              return 0;
          }
          LOG(WARNING)
              << "compare and deal response failed, start_lsn: " << start_lsn
              << ", len: " << len;
          std::this_thread::sleep_for(std::chrono::milliseconds(200));
      }
  }
  return -1;
}

void pwrite_internal_callback(
        baidu::rpc::Controller *cntl,
        log_service::pwrite_request *request,
        log_service::pwrite_response *response,
        PwriteCallback callback, PwriteContext* context) {

    std::unique_ptr<baidu::rpc::Controller> cntl_guard(cntl);
    std::unique_ptr<log_service::pwrite_request> request_guard(request);
    std::unique_ptr<log_service::pwrite_response> response_guard(response);
    if (cntl->Failed()) {
        LOG_EVERY_N(WARNING, 1000) << "landing zone async pwrite failed, lsn: "
                                   << request->lsn()
                                   << ", error: " << cntl->ErrorText();
        callback(false, context);
    } else if (response->status().code() != log_service::GIE_OK) {
        LOG_EVERY_N(WARNING, 1000) << "landing zone async pwrite failed, lsn: "
                                   << request->lsn()
                                   << ", server: " << base::endpoint2str(cntl->remote_side())
                                   << ", error: " << response->status().msg();
        if (response->status().code() == log_service::GIE_EPOCH_NOT_VALID) {
            LOG_EVERY_N(WARNING, 1000) << "landing zone async pwrite failed, invalid epoch"
                                          ", server: " << cntl->remote_side();
        }
        if (response->status().code() == log_service::GIE_MEMBERSHIP_EPOCH_INVALID) {
            if (response->has_membership_epoch()) {
                g_landing_zone_client.set_membership_epoch(response->membership_epoch());
            }
            LOG_EVERY_N(WARNING, 1000) << "landing zone async pwrite failed, invalid membership_epoch"
                         << ", server: " << cntl->remote_side();
        }
        callback(false, context);
    } else if (response->write_size() != request->len()) {
        LOG_EVERY_N(WARNING, 1000) << "landing zone async pwrite failed, error:  write_size != len"
                     << ", server: " << base::endpoint2str(cntl->remote_side());
        callback(false, context);
    } else {
        if (request->vdl() > 0) {
            g_landing_zone_client.set_vdl_sync_by_pwrite(request->vdl());
        }
        gaia_write_rpc_lat << cntl->latency_us();
        callback(true, context);
    }
}

static void on_polar_pwrite(std::promise<void>* polar_sync_promise) {
    polar_sync_promise->set_value();
}

int LandingZoneClient::peer_pwrite_proc(lsn_t vdl, uint64_t epoch, uint64_t mb_epoch, lsn_t start_lsn,
        uint64_t offset, uint64_t len, byte* buffer, PwriteCallback callback,
        PwriteContext* context, const base::EndPoint& endpoint) {
    if (nullptr != callback) {
        log_service::pwrite_request* request = new log_service::pwrite_request();
        log_service::pwrite_response* response = new log_service::pwrite_response();
        baidu::rpc::Controller *cntl = new baidu::rpc::Controller;
        cntl->set_log_id(LandingZoneClient::redo_log_id++);
        request->set_cluster_id(_psm_client->get_cluster_id());
        request->set_offset(offset);
        request->set_vdl(vdl);
        request->set_len(len);
        request->set_lsn(start_lsn);
        request->set_epoch(epoch);
        request->set_membership_epoch(mb_epoch);
        request->set_buffer(buffer, len);
        request->set_vcl(context->written_lsn);
        if (FLAGS_enable_quorum_mode) {
            request->set_enable_quorum(true);
        }

        if (log_sys != nullptr) {
            ++log_sys->fly_write_request_cnt;
        }

        google::protobuf::Closure *done = baidu::rpc::NewCallback(
                &pwrite_internal_callback, cntl, request, response, callback, context);
        if (FLAGS_write_with_polar_client && gaiadb::polar::enable_polar()) {
            polar_rpc_client_.Call(cntl, endpoint, &log_service::LandingZoneService_Stub::pwrite,
                    request, response, done);
        } else {
            gaiadb::common::issue_rpc<log_service::pwrite_request,
                log_service::pwrite_response,
                log_service::LandingZoneService_Stub,
                gaiadb::common::DESTINATION::LOG_SERVICE>(
                        endpoint,
                        &log_service::LandingZoneService_Stub::pwrite,
                        request, response, done, nullptr, nullptr,
                        nullptr, cntl);
        }
        LOG(TRACE) << "landing_zone async pwrite, start_lsn:" << start_lsn
                   << ", len:" << len;
        return 0;
    } else {
        log_service::pwrite_request request;
        log_service::pwrite_response response;
        baidu::rpc::Controller cntl;

        cntl.set_log_id(LandingZoneClient::redo_log_id++);
        request.set_cluster_id(_psm_client->get_cluster_id());
        request.set_offset(offset);
        request.set_vdl(vdl);
        request.set_len(len);
        request.set_lsn(start_lsn);
        request.set_epoch(epoch);
        request.set_membership_epoch(mb_epoch);
        request.set_buffer(buffer, len);
        if (offset < LOG_FILE_HDR_SIZE) {
            cntl.set_timeout_ms(500);
        }
        if (FLAGS_write_with_polar_client && gaiadb::polar::enable_polar()) {
            std::promise<void> polar_sync_promise;
            std::future<void> polar_sync_future = polar_sync_promise.get_future();
            auto done = baidu::rpc::NewCallback(&on_polar_pwrite, &polar_sync_promise);
            polar_rpc_client_.Call(&cntl, endpoint, &log_service::LandingZoneService_Stub::pwrite,
                    &request, &response, done);
            polar_sync_future.get();
        } else {
            gaiadb::common::issue_rpc<
                log_service::pwrite_request,
                log_service::pwrite_response,
                log_service::LandingZoneService_Stub,
                gaiadb::common::DESTINATION::LOG_SERVICE>(
                        endpoint, &log_service::LandingZoneService_Stub::pwrite,
                        &request, &response, nullptr, nullptr, nullptr, nullptr, &cntl);
        }
        if (cntl.Failed()) {
            LOG(WARNING) << "landing_zone sync pwrite failed, lsn: "
                                       << start_lsn << ", error: "<< cntl.ErrorText();
            return -1;
        } else if (response.status().code() != log_service::GIE_OK) {
            LOG(WARNING) << "landing_zone sync call pwrite failed, lsn: "
                                       << start_lsn << " error: " << response.status().msg();
            if (response.status().code() == log_service::GIE_EPOCH_NOT_VALID) {
                LOG(WARNING) << "invalid write epoch";
            }
            if (response.status().code() == log_service::GIE_MEMBERSHIP_EPOCH_INVALID) {
                g_landing_zone_client.set_membership_epoch(response.membership_epoch());
            }
            return -1;
        } else if (response.write_size() != request.len()){
            LOG(WARNING) << "landing zone sync pwrite failed, error:  write_size != len"
                         << ", server: " << base::endpoint2str(endpoint);
            return -1;
        } else {
            if (request.vdl() > 0) {
                g_landing_zone_client.set_vdl_sync_by_pwrite(request.vdl());
            }
        }
        gaia_write_rpc_lat << cntl.latency_us();
        LOG(TRACE) << "landing zone sync pwrite success, lsn: " << start_lsn;
    }
    return 0;
}

// pwrite support sync mode or async mode.
// If user passes in a nullptr as the callback
// pwrite is called in sync mode. Otherwise it is called in async mode
int LandingZoneClient::pwrite(uint64_t start_lsn, uint64_t offset, uint64_t len,
                              byte *buffer, PwriteCallback callback,
                              PwriteContext* context) {
    assert(nullptr != log_sys);
    auto vdl = log_get_vdl(*log_sys);
    ut_a(vdl <= log_sys->flushed_to_disk_lsn.load());
    auto mb_epoch = _membership_epoch.load(std::memory_order_relaxed);
    auto epoch = _epoch.load(std::memory_order_relaxed);
    auto quorum_number = FLAGS_gaia_redo_store_replicas / 2 + 1;

    if (start_lsn >= LOG_FILE_HDR_SIZE && FLAGS_enable_quorum_mode) {
        // data write, use quorum set strategy
        std::vector<gaiadb::common::PeerZone> ls_peers;
        _ls_tracker.get_peers(&ls_peers);
        if (_psm_client->has_zone()) {
          std::string region;
          std::string available_zone;
          if (_psm_client->get_zone(&region, &available_zone)
              && !region.empty() && !available_zone.empty()) {
            gaiadb::common::sort_peer_zone_vector(ls_peers, region, available_zone);
          }
        }

        if (nullptr != callback) {
            // async call
            context->set_node_count(ls_peers.size());
            for (auto& peer : ls_peers) {
                peer_pwrite_proc(vdl, epoch, mb_epoch, start_lsn, offset, len,
                                 buffer, callback, context, peer.addr);
            }
        } else {
            int success_count = 0;
            for (auto& peer : ls_peers) {
                if (0 == peer_pwrite_proc(vdl, epoch, mb_epoch, start_lsn, offset, len,
                                          buffer, callback, context, peer.addr)) {
                    success_count++;
                }
            }
            if (success_count < quorum_number) {
                LOG(WARNING) << "landing_zone pwrite does not reach quorum set "
                                " mem_epoch:" << _membership_epoch;
                return -1;
            }
        }
    } else {
      // write header, use raft leader write strategy
      auto ls_leader = _ls_tracker.get_leader();
      int ret = 0;
      ret = peer_pwrite_proc(vdl, epoch, mb_epoch, start_lsn, offset, len,
                              buffer, callback, context, ls_leader);
      if (ret != 0) {
          LOG_EVERY_SECOND(WARNING) << "landing zone sync pwrite header failed";
          return ret;
      }
    }
    return 0;
}

// 0 success, -1 failed
int LandingZoneClient::increase_epoch() {
    baidu::rpc::Controller cntl;
    log_service::lsrv_empty_message request;
    log_service::query_epoch_response response;
    cntl.set_log_id(redo_log_id++);
    auto endpoint = _ls_tracker.get_leader();
    gaiadb::common::issue_rpc<
        log_service::lsrv_empty_message,
        log_service::query_epoch_response,
        log_service::LandingZoneService_Stub,
        gaiadb::common::DESTINATION::LOG_SERVICE>(
                endpoint, &log_service::LandingZoneService_Stub::query_epoch,
                &request, &response, nullptr, nullptr, nullptr, nullptr, &cntl);
    if (cntl.Failed()) {
        LOG(WARNING) << "landing zone call query_epoch failed, error: "
                     << cntl.ErrorText();
        return -1;
    }
    if (response.status().code() != log_service::GIE_OK) {
        LOG(WARNING) << "landing zone call query_epoch failed, error: "
                     << response.status().msg();
        return -1;
    }
    cntl.Reset();
    uint64_t last_epoch = response.epoch();
    if (!FLAGS_enable_quorum_mode) {
        log_service::increase_epoch_request increase_epoch_request;
        log_service::increase_epoch_response increase_epoch_response;
        cntl.set_log_id(redo_log_id++);
        increase_epoch_request.set_cluster_id(_psm_client->get_cluster_id());
        increase_epoch_request.set_last_epoch(response.epoch());
        gaiadb::common::issue_rpc<
            log_service::increase_epoch_request,
            log_service::increase_epoch_response,
            log_service::LandingZoneService_Stub,
            gaiadb::common::DESTINATION::LOG_SERVICE>(
                    endpoint, &log_service::LandingZoneService_Stub::increase_epoch,
                    &increase_epoch_request, &increase_epoch_response, nullptr, nullptr,
                    nullptr, nullptr, &cntl);
        if (cntl.Failed()) {
            LOG(WARNING) << "landing zone call increase_epoch failed, error: "
                         << cntl.ErrorText();
            return -1;
        }
        if (increase_epoch_response.status().code() != log_service::GIE_OK) {
            LOG(WARNING) << "landing zone call increase_epoch failed, error: "
                         << response.status().msg();
            return -1;
        }
        if (increase_epoch_response.has_write_lsn()) {
            last_increase_epoch_lsn_.store(increase_epoch_response.write_lsn());
        }
        _epoch.store(increase_epoch_response.epoch());
    } else {
        log_service::increase_epoch_prepare_request prepare_request;
        log_service::increase_epoch_prepare_response prepare_response;
        cntl.set_log_id(redo_log_id++);
        prepare_request.set_cluster_id(_psm_client->get_cluster_id());
        prepare_request.set_last_epoch(last_epoch);
        gaiadb::common::issue_rpc<
            log_service::increase_epoch_prepare_request,
            log_service::increase_epoch_prepare_response,
            log_service::LandingZoneService_Stub,
            gaiadb::common::DESTINATION::LOG_SERVICE>(
                    endpoint, &log_service::LandingZoneService_Stub::increase_epoch_prepare,
                    &prepare_request, &prepare_response, nullptr, nullptr,
                    nullptr, nullptr, &cntl);
        if (cntl.Failed()) {
            LOG(WARNING) << "landing zone call increase_epoch_prepare failed, error: "
                         << cntl.ErrorText();
            return -1;
        }
        if (prepare_response.status().code() != log_service::GIE_OK) {
            LOG(WARNING) << "landing zone call increase_epoch_prepare failed, error: "
                         << response.status().msg();
            return -1;
        }
        LOG(NOTICE) << "landing zone call increase_epoch_prepare success";

        log_service::increase_epoch_commit_request commit_request;
        log_service::increase_epoch_commit_response commit_response;
        cntl.Reset();
        cntl.set_log_id(redo_log_id++);
        commit_request.set_last_epoch(last_epoch);
        commit_request.set_quorum_write_lsn(prepare_response.quorum_write_lsn());
        if (prepare_response.has_data()) {
            commit_request.set_data(prepare_response.data());
            commit_request.set_len(prepare_response.len());
        }
        gaiadb::common::issue_rpc<
            log_service::increase_epoch_commit_request,
            log_service::increase_epoch_commit_response,
            log_service::LandingZoneService_Stub,
            gaiadb::common::DESTINATION::LOG_SERVICE>(
                    endpoint, &log_service::LandingZoneService_Stub::increase_epoch_commit,
                    &commit_request, &commit_response, nullptr, nullptr,
                    nullptr, nullptr, &cntl);
        if (cntl.Failed()) {
            LOG(WARNING) << "landing zone call increase_epoch_commit failed, error: "
                         << cntl.ErrorText();
            return -1;
        }
        if (commit_response.status().code() != log_service::GIE_OK) {
            LOG(WARNING) << "landing zone call increase_epoch_commit failed, error: "
                         << commit_response.status().msg();
            return -1;
        }
        _epoch.store(commit_response.epoch());
        last_increase_epoch_lsn_.store(commit_response.write_lsn());
        LOG(NOTICE) << "landing zone call increase_epoch_commit success, epoch now: "
                    << commit_response.epoch()
                    << ", increase_epoch_lsn: " << commit_response.write_lsn();
    }
    return 0;
}

int LandingZoneClient::init_membership_epoch() {
    baidu::rpc::Controller cntl;
    log_service::lsrv_empty_message request;
    log_service::query_membership_epoch_response response;

    auto endpoint = _ls_tracker.get_leader();

    gaiadb::common::issue_rpc<
        log_service::lsrv_empty_message,
        log_service::query_membership_epoch_response,
        log_service::LandingZoneService_Stub,
        gaiadb::common::DESTINATION::LOG_SERVICE>(
                endpoint, &log_service::LandingZoneService_Stub::query_membership_epoch,
                &request, &response, nullptr, nullptr, nullptr, nullptr, &cntl);
    if (cntl.Failed()) {
        LOG(WARNING) << "landing zone query membership epoch failed, errno: "
                     << cntl.ErrorCode() << ", error: " << cntl.ErrorText();
        return -1;
    }
    if (response.status().code() != log_service::GIE_OK) {
        LOG(WARNING) << "landing zone query failed";
        return -1;
    }
    set_membership_epoch(response.membership_epoch());
    return 0;
}

void LandingZoneClient::set_membership_epoch(uint64_t membership_epoch) {
    uint64_t epoch = _membership_epoch.load();
    do {
        if (membership_epoch <= epoch) {
            return;
        }
    } while (!_membership_epoch.compare_exchange_strong(epoch, membership_epoch));
    DLOG(TRACE) << "membership_epoch set to " << membership_epoch;
}
// 0 success, -1 failed
int LandingZoneClient::send_vdl(uint64_t vdl) {

    log_service::send_vdl_request request;

    request.set_cluster_id(_psm_client->get_cluster_id());
    request.set_vdl(vdl);
    request.set_epoch(_epoch.load());
    request.set_membership_epoch(_membership_epoch.load(std::memory_order_relaxed));
    if (FLAGS_enable_quorum_mode) {
        request.set_enable_quorum(true);
    }
    std::vector<base::EndPoint> ls_peers;
    auto leader = _ls_tracker.get_leader();

    baidu::rpc::Controller cntl;
    cntl.set_log_id(redo_log_id++);
    log_service::send_vdl_response response;
    gaiadb::common::issue_rpc<
        log_service::send_vdl_request,
        log_service::send_vdl_response,
        log_service::LandingZoneService_Stub,
        gaiadb::common::DESTINATION::LOG_SERVICE>(
                leader, &log_service::LandingZoneService_Stub::send_vdl,
                &request, &response, nullptr, nullptr, nullptr, nullptr, &cntl);
    if (cntl.Failed()) {
        LOG(WARNING) << "landing zone send_vdl failed, error: " << cntl.ErrorText();
        return -1;
    }
    if (response.status().code() != log_service::GIE_OK) {
        if (response.status().code() == log_service::GIE_EPOCH_NOT_VALID) {
            LOG(WARNING) << "landing zone send_vdl failed, error: "
                << response.status().msg();
            std::quick_exit(0);
        }
        if (response.status().code() == log_service::GIE_MEMBERSHIP_EPOCH_INVALID) {
            LOG(WARNING) << "landing zone send_vdl failed, error: "
                << response.status().msg();
            if (response.has_membership_epoch()) {
                set_membership_epoch(response.membership_epoch());
            }
        } else {
          LOG(WARNING) << "landing zone send_vdl failed, error: "
            << response.status().msg();
        }
    }
    return 0;
}

uint64_t LandingZoneClient::get_vdl_sync_by_pwrite() {
    return _vdl_sync_by_pwrite.load();
}

void LandingZoneClient::set_vdl_sync_by_pwrite(uint64_t vdl) {
    uint64_t old = 0;
    do {
        old = _vdl_sync_by_pwrite.load();
        if (vdl <= old) {
            break;
        }
        LOG(TRACE) << "set _vdl_sync_by_pwrite to: " << vdl;
    } while (!_vdl_sync_by_pwrite.compare_exchange_strong(old, vdl));
}

const LogInfo LandingZoneClient::get_log_info() {
  auto leader = _ls_tracker.get_leader();

  std::shared_ptr<baidu::rpc::Channel> channel_ptr;
  if (!gaiadb::common::RpcChannelCache<
          gaiadb::common::DESTINATION::LOG_SERVICE>::GetInstance()->get_rpc_channel(
              leader, &channel_ptr)) {
      LOG(WARNING) << "LogServiceRaftLeaderTracker create channel failed: " << leader;
      return LogInfo{0, 0};
  }

  log_service::lsrv_empty_message request;
  log_service::lsrv_status_response response;
  log_service::LogServiceService_Stub stub(channel_ptr.get());
  baidu::rpc::Controller cntl;
  stub.query_status(&cntl, &request, &response, nullptr);
  if (cntl.Failed()) {
    LOG(WARNING) << "landing zone lsrv_status failed, error: " << cntl.ErrorText();
    return LogInfo{0, 0};
  }
  if (response.status().code() != log_service::GIE_OK) {
    LOG(WARNING) << "landing zone lsrv_status failed, error: "
               << response.status().msg();
    return LogInfo{0, 0};
  } else {
    return {response.write_lsn(), response.checkpoint_lsn()};
  }
}

std::atomic<uint64_t> LandingZoneClient::redo_log_id(0);

LandingZoneClient g_landing_zone_client;

static bool advance_written_lsn(lsn_t new_lsn) {
  lsn_t old_written_lsn = log_sys->write_lsn.load();
  do {
    if (new_lsn <= old_written_lsn) {
      return false;
    }
  } while (!log_sys->write_lsn.compare_exchange_strong(old_written_lsn, new_lsn));
  return true;
}

static void write_log_callback(bool ok, landing_zone::PwriteContext *context) {
  std::shared_ptr<void> guard_cnt(nullptr, [](...) {
    if (log_sys != nullptr) {
      --log_sys->fly_write_request_cnt;
    }
  });

  lsn_t new_written_lsn = context->write_lsn;

  if (!FLAGS_enable_quorum_mode) {
    std::unique_ptr<landing_zone::PwriteContext> guard(context);
    int64_t start_time = context->start_time;
    log_sys->log_writer_file_write << (base::monotonic_time_us() - start_time);
    LOG(TRACE) << "write redo on landing_zone callback, end_lsn:"
               << new_written_lsn;

    if (log_sys == nullptr) {
      return;
    }
    if (ok) {
      lsn_t old_written_lsn = 0;
      do {
        old_written_lsn = log_sys->write_lsn.load();
        if (new_written_lsn <= old_written_lsn) {
          break;
        }
      } while (!log_sys->write_lsn.compare_exchange_strong(old_written_lsn,
                                                           new_written_lsn));
      Log_files_write_impl::notify_about_advanced_write_lsn(
          *log_sys, old_written_lsn, new_written_lsn);

      // LOG_SYNC_POINT("log_writer_before_buf_limit_update");

      log_update_buf_limit(*log_sys, new_written_lsn);
      // auto write_lsn = log_sys->write_lsn.load(std::memory_order_relaxed);
      // if (write_lsn >= new_written_lsn) {
      //   log_sys->log_writer_lsn_async_distance << (write_lsn -
      //   new_written_lsn);
      // }
    } else {
      if (new_written_lsn > log_sys->write_lsn.load()) {
        // mark write callback error when new_written_lsn >
        // log_sys->written_lsn because when new_written_lsn <=
        // log_sys->written_lsn it means up to log_sys->written_lsn,
        // data already write to landing_zone, error should ignore
        // only call cas once, if cas failed, it means another
        // callback failed before this
        bool _false = false;
        log_sys->write_callback_err.compare_exchange_strong(_false, true);
      }
      LOG(WARNING) << "write landing zone failed, end_lsn: "
                    << new_written_lsn;
      // log_sys->log_writer_errors << 1;
    }

    srv_stats.os_log_pending_writes.dec();
    srv_stats.log_writes.inc();
    return;
  }
  int64_t start_time = context->start_time;

  if (log_sys == nullptr) {
    LOG(WARNING) << "log_sys is null";
    ok = false; // do not return early, count down has to be calculated to
                // release context
  }

  LOG(TRACE) << "write redo on landing_zone callback, end_lsn:"
             << new_written_lsn;

  // make sure success_count is updated before finish_count, so relaxed order is
  // ok
  uint64_t finish_count = 0;
  uint64_t success_count = 0;
  do {
    auto old_pwrite_status =
        context->pwrite_status.load(std::memory_order_acquire);
    finish_count = (old_pwrite_status >> 32) + 1;
    success_count = ok ? (old_pwrite_status & 0xFFFFFFFF) + 1
                       : (old_pwrite_status & 0xFFFFFFFF);
    auto new_pwrite_status = (finish_count << 32) | success_count;
    if (context->pwrite_status.compare_exchange_strong(old_pwrite_status,
                                                       new_pwrite_status)) {
      break;
    }
  } while (true);

  uint64_t quorum_number = landing_zone::FLAGS_gaia_redo_store_replicas / 2 + 1;
  if (static_cast<int32_t>(finish_count) ==
      context->node_count) { // all request bas been procssed
    if (success_count < quorum_number && log_sys) {
      // error, quorum set not reached
      if (new_written_lsn > log_sys->write_lsn.load()) {
        LOG(WARNING)
            << "pwrite failed: no reach quorum set, written_lsn:"
            << new_written_lsn << ", quorum_num: " << quorum_number
            << ", success_count: " << success_count
            << ", finish_count: " << finish_count;
        // mark write callback error when new_written_lsn >
        // log_sys->written_lsn because when new_written_lsn <=
        // log_sys->written_lsn it means up to log_sys->written_lsn,
        // data already write to landing_zone, error should ignore
        // only call cas once, if cas failed, it means another
        // callback failed before this
        bool _error = false;
        log_sys->write_callback_err.compare_exchange_strong(_error,
                                                            true);
      }
      // log_sys->log_writer_errors << 1;
    }
    srv_stats.os_log_pending_writes.dec();
    srv_stats.log_writes.inc();
  }
  // we must use success_count snapshot value instead of a atomic read here
  if (ok && success_count == quorum_number && log_sys) { // quorum_set reached
    auto cost_time = base::monotonic_time_us() - start_time;
    log_sys->log_writer_reach_quorum_cost_us << cost_time;
    lsn_t old_written_lsn = log_sys->write_lsn.load();

    if (advance_written_lsn(new_written_lsn)) {
      Log_files_write_impl::notify_about_advanced_write_lsn(
          *log_sys, old_written_lsn, new_written_lsn);

      // LOG_SYNC_POINT("log_writer_before_buf_limit_update");

      log_update_buf_limit(*log_sys, new_written_lsn);

      // auto write_lsn = log_sys->write_lsn.load(std::memory_order_relaxed);
      // if (write_lsn >= new_written_lsn) {
      //   log_sys->log_writer_lsn_async_distance << (write_lsn -
      //   new_written_lsn);
      // }
    }
  }
  auto count = context->count_down.fetch_sub(1, std::memory_order_acq_rel);
  if (count == 1) {
    auto cost_time = base::monotonic_time_us() - start_time;
    log_sys->log_writer_file_write << cost_time;
    LOG(TRACE) << "all peers of write request processed, delete context";
    delete context;
  }
}

dberr_t landing_zone_read(byte* buf, os_offset_t offset, ulint n, uint64_t start_lsn) {
  auto ret = g_landing_zone_client.pread(start_lsn, offset, n, buf);
  if (ret != 0) {
    LOG(WARNING) << "landing zone pread failed, offset: " << offset
      << ", len: " << n;
    return (DB_ERROR);
  }
  return (DB_SUCCESS);
}

dberr_t landing_zone_write(byte *buf, os_offset_t offset, ulint n,
                           uint64_t start_lsn, uint64_t new_written_lsn) {
  PwriteCallback cb_write_log = nullptr;
  PwriteContext *context = nullptr;
  if (offset >= LOG_FILE_HDR_SIZE) {
    cb_write_log = write_log_callback;
    int64_t start_time = base::monotonic_time_us();
    context = new PwriteContext(new_written_lsn, start_time,
                                landing_zone::FLAGS_gaia_redo_store_replicas);
    context->written_lsn = log_sys->write_lsn.load();
  }
  auto ret = g_landing_zone_client.pwrite(start_lsn, offset, n, reinterpret_cast<byte*>(buf), cb_write_log, context);
  if (cb_write_log == nullptr) {
    delete context;
  }
  if (ret != 0) {
    LOG(WARNING) << "landing zone pwrite failed, offset: " << offset
      << ", len: " << n << ", start_lsn: " << start_lsn;
    return (DB_ERROR);
  }
  return (DB_SUCCESS);
}

void recovered_lsn_valid(lsn_t lsn) {
  lsn_t epoch_lsn = landing_zone::g_landing_zone_client.last_increase_epoch_lsn();
  if (epoch_lsn > 0) {
    LOG(NOTICE) << "recovered_lsn: " << lsn << ", epoch_lsn: " << epoch_lsn;
    ut_a(lsn == epoch_lsn);
  }
}

lsn_t get_last_increase_epoch_lsn() {
    return landing_zone::g_landing_zone_client.last_increase_epoch_lsn();
}

void landing_zone_timer_start() {
  landing_zone::g_landing_zone_client.start_send_vdl_timer();
}

void landing_zone_timer_stop() {
  landing_zone::g_landing_zone_client.stop_send_vdl_timer();
}

} // namespace landing_zone
