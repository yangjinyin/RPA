/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test_thread_pool.cpp
* @author yukeyong@baidu.com
* @brief
*/


#include "test/test_common.h"
#include "psvr/thread_pool.hpp"

namespace psvr {
namespace test {

struct TestTask : public thread::TaskContext {
    uint32_t num {0};
    int64_t t2 {0};
    bool sleep {false};
    gaiadb::common::Condition wl;
};

class ThreadPoolTests : public PsvrTest {
 public:
    ThreadPoolTests() : _executor(nullptr) {}

    virtual ~ThreadPoolTests() {}

    void SetUp() {
        _executor = new ThreadPoolExecutor<TestTask>;
    }

    void TearDown() {
        delete _executor;
        _executor = nullptr;
    }

    void OnCompletion(TestTask* ctx) {
        {
            std::unique_lock<std::mutex> lm(ctx->wl.mutex());
            ++ctx->num;
            if (ctx->sleep) {
                sleep_for(1000);
            }
        }
        ctx->wl.notify();
    }

private:
    ThreadPoolExecutor<TestTask>* _executor;
};

TEST_F(ThreadPoolTests, test_Timer) {
    thread::Timer<TestTask>* timer = new thread::Timer<TestTask>("xx");
    typename thread::Timer<TestTask>::TaskFn fn = [this] (TestTask* ctx) {
        {
            std::unique_lock<std::mutex> lm(ctx->wl.mutex());
            ctx->t2 = base::cpuwide_time_us();
        }
        ctx->wl.notify();
        return true;
    };
    timer->Start(10000, fn);

    printf("cpuwide_time_ms:%lu\n", base::cpuwide_time_ms());
    printf("clock_cycles:%lu\n", base::detail::clock_cycles());

    //printf("CalcCpuFreq:%lu\n", gaiadb::common::thread::CalcCpuFreq());
    //printf("_tick_precision:%lu\n", timer->_tick_precision);
    //printf("_cycles_in_tick:%lu\n", timer->_cycles_in_tick);
    //printf("_sleep_ns:%lu\n", timer->_sleep_ns);

    TestTask* ctx = new TestTask;
    TestTask* ctx2 = new TestTask;
    auto t1 = base::cpuwide_time_us();
    {
        std::unique_lock<std::mutex> lm(ctx->wl.mutex());
        timer->AddTask(ctx, 1100000, &ctx->task_id);
        timer->AddTask(ctx2, 500000, &ctx->task_id);
        ctx->wl.wait_with_lock(lm);
    }

    ASSERT_GT(ctx->t2 - t1, 1000000);
    ASSERT_GT(ctx2->t2 - t1, 400000);
    timer->Stop();
    delete ctx;
    delete timer;
}

TEST_F(ThreadPoolTests, test_NoShared) {
    typename thread::Executor<TestTask>::TaskFn fn = std::bind(&ThreadPoolTests::OnCompletion,
            this, std::placeholders::_1);
    bool rc = _executor->Start("xx", 10, 1, fn);
    ASSERT_TRUE(rc);

    TestTask* ctx = new TestTask;
    ctx->client_id = 1;
    {
        std::unique_lock<std::mutex> lm(ctx->wl.mutex());
        rc = _executor->Execute(ctx);
        ASSERT_TRUE(rc);
        ctx->wl.wait_with_lock(lm);
        ASSERT_EQ(1, ctx->num);
    }

    {
        std::unique_lock<std::mutex> lm(ctx->wl.mutex());
        rc = _executor->EmergentExecute(ctx);
        ASSERT_TRUE(rc);
        ctx->wl.wait_with_lock(lm);
        ASSERT_EQ(2, ctx->num);
    }

    {
        std::unique_lock<std::mutex> lm(ctx->wl.mutex());
        rc = _executor->Schedule(ctx, 100);
        ASSERT_TRUE(rc);
        ctx->wl.wait_with_lock(lm);
        ASSERT_EQ(3, ctx->num);
    }

    {
        std::unique_lock<std::mutex> lm(ctx->wl.mutex());
        rc = _executor->Schedule(ctx, 3000);
        ASSERT_TRUE(rc);
        rc = _executor->Cancel(ctx);
        ASSERT_TRUE(rc);
        ASSERT_EQ(3, ctx->num);
    }

    _executor->Stop(true);
}

TEST_F(ThreadPoolTests, test_NoShared_Bulk) {
    typename thread::Executor<TestTask>::TaskFn fn = std::bind(&ThreadPoolTests::OnCompletion,
            this, std::placeholders::_1);
    bool rc = _executor->Start("xx", 10, 3, fn);
    ASSERT_TRUE(rc);

    TestTask* ctx = new TestTask;
    for (uint32_t i = 0; i < 3; ++i) {
        ctx->client_id = i;
        std::unique_lock<std::mutex> lm(ctx->wl.mutex());
        rc = _executor->Execute(ctx);
        ASSERT_TRUE(rc);
        ctx->wl.wait_with_lock(lm);
        ASSERT_EQ(i + 1, ctx->num);
        ASSERT_EQ(i, ctx->run_thread_id);
    }

    for (uint32_t i = 0; i < 3; ++i) {
        ctx->client_id = i;
        std::unique_lock<std::mutex> lm(ctx->wl.mutex());
        rc = _executor->Schedule(ctx, 100);
        ASSERT_TRUE(rc);
        ctx->wl.wait_with_lock(lm);
        ASSERT_EQ(i + 4, ctx->num);
        ASSERT_EQ(i, ctx->run_thread_id);
    }
}

TEST_F(ThreadPoolTests, test_Shared_Bulk) {
    typename thread::Executor<TestTask>::TaskFn fn = std::bind(&ThreadPoolTests::OnCompletion,
            this, std::placeholders::_1);
    bool rc = _executor->Start("xx", 10, 3, true, fn);
    ASSERT_TRUE(rc);

    std::list<TestTask*> ctxs;
    for (uint32_t i = 0; i < 100; ++i) {
        TestTask* ctx = new TestTask;
        ctx->client_id = i;
        rc = _executor->Execute(ctx);
        ASSERT_TRUE(rc);
        ctxs.push_back(ctx);
    }

    while (true) {
        bool finish = true;
        for (auto& ctx : ctxs) {
            std::unique_lock<std::mutex> lm(ctx->wl.mutex());
            if (!ctx->num) {
                finish = false;
                break;
            }
        }
        if (finish) {
            break;
        }
        sleep_for(SLEEP_INTERVAL);
    }

    for (auto& ctx : ctxs) {
        ctx->num = 0;
        rc = _executor->Schedule(ctx, 100);
        ASSERT_TRUE(rc);
    }

    while (true) {
        bool finish = true;
        for (auto& ctx : ctxs) {
            std::unique_lock<std::mutex> lm(ctx->wl.mutex());
            if (!ctx->num) {
                finish = false;
                break;
            }
        }
        if (finish) {
            break;
        }
        sleep_for(SLEEP_INTERVAL);
    }
}

bool OnTimer(GroupThreadPoolExecutor<TestTask, TestTask>* group_executor, TestTask* ctx) {
    return group_executor->EmergentExecute(0, ctx);
}

TEST_F(ThreadPoolTests, test_GroupThreadPoolExecutor) {
    GroupThreadPoolExecutor<TestTask, TestTask> group_executor;
    typename thread::Executor<TestTask>::TaskFn fn = std::bind(&ThreadPoolTests::OnCompletion,
            this, std::placeholders::_1);

    std::shared_ptr<thread::Timer<TestTask>> timer(new thread::Timer<TestTask>("shared"));
    typename thread::Timer<TestTask>::TaskFn timer_fn = std::bind(OnTimer, &group_executor, std::placeholders::_1);
    timer->Start(20, timer_fn);

    ASSERT_TRUE(group_executor.Start(2, "group_test", timer, 2, fn, false));

    TestTask* ctx = new TestTask;
    {
        std::unique_lock<std::mutex> lm(ctx->wl.mutex());
        auto nr = group_executor.GetThreadQueueSize(0, ctx->client_id);
        ASSERT_EQ(0, nr);
    }
    {
        std::unique_lock<std::mutex> lm(ctx->wl.mutex());
        group_executor.Execute(0, ctx);
        ctx->wl.wait_with_lock(lm);
        ASSERT_EQ(1, ctx->num);
    }
    {
        std::unique_lock<std::mutex> lm(ctx->wl.mutex());
        group_executor.Execute(1, ctx);
        ctx->wl.wait_with_lock(lm);
        ASSERT_EQ(2, ctx->num);
    }

    {
        std::unique_lock<std::mutex> lm(ctx->wl.mutex());
        group_executor.EmergentExecute(1, ctx);
        ctx->wl.wait_with_lock(lm);
        ASSERT_EQ(3, ctx->num);
    }

    {
        std::unique_lock<std::mutex> lm(ctx->wl.mutex());
        group_executor.Schedule(1, ctx, 100);
        ctx->wl.wait_with_lock(lm);
        ASSERT_EQ(4, ctx->num);

        ASSERT_FALSE(group_executor.Cancel(1, ctx));
    }
    delete ctx;
    {
        std::vector<TestTask*> tasks;
        auto t = std::thread([&group_executor, &tasks]() {
                    for (int i = 0; i < 100; ++i) {
                        TestTask* _ctx = new TestTask;
                        _ctx->sleep = true;
                        if (!group_executor.Execute(i, _ctx)) {
                            delete _ctx;
                            break;
                        }
                        tasks.push_back(_ctx);
                    }
                });

        sleep_for(10000);
        group_executor.IncThread(0, 1);
        sleep_for(10000);
        auto stop_ts = group_executor.DecThread(1, 1);
        sleep_for(10000);
        for (auto th : stop_ts) {
            th->Join();
        }

        timer->Stop();
        group_executor.Stop(true);
        t.join();

        uint32_t nr = 0;
        group_executor.RecycleTask([&nr](TestTask* _ctx) {
                    ++nr;
                });
        for (auto& _ctx : tasks) {
            delete _ctx;
        }
    }
}

struct ConditionTask {
    bool ret;

    ConditionTask(bool _ret) : ret(_ret) {}

    operator bool() {
        return ret;
    }
};

struct ConditionQueue2 : public ConditionQueue<ConditionTask, ConditionQueue2> {
    void Push(const ConditionTask& task) {
        std::unique_lock lk(_mutex);
        _tasks.push_back(task);
        ++_push_size;
    }

    void PopIf(Fn& fn) {
        std::unique_lock lk(_mutex);
        for (auto it = _tasks.begin(); it != _tasks.end();) {
            if (*it) {
                fn(*it);
                it = _tasks.erase(it);
                ++_pop_size;
            } else {
                ++it;
            }
        }
    }

    void Clear(Fn& fn) {
        std::unique_lock lk(_mutex);
        for (auto it = _tasks.begin(); it != _tasks.end();) {
            fn(*it);
            it = _tasks.erase(it);
            ++_pop_size;
        }
        LOG(NOTICE) << "queue push size:" << _push_size;
        LOG(NOTICE) << "queue pop size:" << _pop_size;
    }

    std::list<ConditionTask> _tasks;
    std::mutex _mutex;
    size_t _push_size {0};
    size_t _pop_size {0};
};

TEST_F(ThreadPoolTests, test_GroupConditionThread) {
    int64_t sleep_us = 1000;
    GroupConditionThread<ConditionTask, ConditionQueue2> condi_thread_pool;

    std::atomic<int64_t> nr = 0;
    typename ConditionThread<ConditionTask, ConditionQueue2>::Fn fn = [&nr](const ConditionTask&) {
        ++nr;
    };

    condi_thread_pool.Start(2, "test", fn, &sleep_us);

    for (int64_t i = 0; i < 1000; ++i) {
        condi_thread_pool.Schedule(i, ConditionTask(i%2));
    }

    sleep_for(1000000);
    while (nr != 500) {
        sleep_for(100000);
        LOG(NOTICE) << "1 nr:" << nr;
    }

    condi_thread_pool.Stop(false);
    condi_thread_pool.Stop(true);
    sleep_for(1000000);

    while (nr != 1000) {
        sleep_for(100000);
        LOG(NOTICE) << "2 nr:" << nr;
    }
}

struct QuotaTask {
    int32_t num;
};

bool operator>=(std::shared_ptr<FlowQuota> quota, QuotaTask* ctx) {
    return quota->GetQuota(ctx->num) == 0;
}

TEST_F(ThreadPoolTests, test_QuotaThread) {
    QuotaThread<QuotaTask*, std::shared_ptr<FlowQuota>> quota_thread;
    int64_t sleep_us = 1000;
    quota_thread.Start("test", [](QuotaTask* task){
                delete task;
            }, &sleep_us);

    int64_t quota_value = 1000;
    std::shared_ptr<FlowQuota> quota(new FlowQuota(&quota_value));

    for (int32_t i = 0; i < 100; ++i){
        QuotaTask* ctx = new QuotaTask;
        ctx->num = 100;
        if (quota_thread.GetQuota(ctx, quota)) {
            delete ctx;
        }
        sleep_for(100);
    }

    quota_thread.Stop(true);
}


}
}
