/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file mock_control.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "psvr/control_context.h"

namespace psvr {
namespace test {

class MockControl : public Control {
    MockControl(ClientPtr client, bool multi_type) : Control(client, multi_type) {}
    virtual ~MockControl() {}

    void MockDispatch(Control::Context* ctx) {
        delete ctx;
    }

    MOCK_METHOD1(Dispatch, void(Control::Context*));
    MOCK_METHOD1(RefreshPsmInfo, void(PsmInfoPtr));

    MOCK_METHOD0(Start, bool());
    MOCK_METHOD0(Stop, void());

};

}
}
