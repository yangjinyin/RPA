/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_compute_node.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/update_compute_node.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int UpdateComputeNode::Run() {
    RpcStatus status;
    gaiapb::UpdateComputeNodeRequest request;
    gaiapb::AckResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_addr.empty()) {
        print_error("miss --addr");
        return 1;
    }

    if (!_is_primary.has_val) {
        print_error("miss --is-primary");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Update addr:%s is_primary:%s?", _addr.c_str(), _is_primary.val ? "true" : "false");
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    request.set_addr(_addr);
    request.set_is_primary(_is_primary.val);
    request.set_log_id(_log_id);
    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::update_compute_node, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " update compute node failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("update compute node failed, all nodes failed");
    return Output(response);
}

int UpdateComputeNode::Format(const gaiapb::AckResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
