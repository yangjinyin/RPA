/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/record_op.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <psvr0recv.h>

#include "psvr/dbengine.h"

namespace psvr {

struct LogRecord;

class LogRecordIteratorInterface {
public:
    virtual ~LogRecordIteratorInterface() = default;
    virtual bool Valid() const = 0;
    virtual void Next() = 0;
    virtual const LogRecord& Get() const = 0;
    virtual const db::Status& Status() const = 0;
};

constexpr gaia_apply::lsn_t LOG_START_LSN = 16 * gaia_apply::OS_FILE_LOG_BLOCK_SIZE;    // 16 * 512 = 8KB

constexpr uint32_t LOG_BLOCK_DATA_SIZE = (gaia_apply::OS_FILE_LOG_BLOCK_SIZE
    - gaia_apply::LOG_BLOCK_HDR_SIZE - gaia_apply::LOG_BLOCK_TRL_SIZE); // 512 - 12 - 4 = 496 byte

inline gaia_apply::lsn_t get_record_end_lsn(const gaia_apply::byte *ptr) {
    return gaia_apply::mach_read_from_8(ptr);
}

inline bool mtr_page_modification_type(gaia_apply::mlog_id_t rec_type) {
    switch (rec_type) {
    case gaia_apply::MLOG_LSN:
    case gaia_apply::MLOG_MULTI_REC_END:
    case gaia_apply::MLOG_GAIA_TRX_BEGIN:
    case gaia_apply::MLOG_GAIA_TRX_COMMIT:
    case gaia_apply::MLOG_GAIA_MDL_EXCLUSIVE:
    case gaia_apply::MLOG_GAIA_TRX_LIST_CLEAN:
    case gaia_apply::MLOG_DUMMY_RECORD:
    case gaia_apply::MLOG_INDEX_LOAD:
    case gaia_apply::MLOG_FILE_CREATE:
    case gaia_apply::MLOG_FILE_RENAME:
    case gaia_apply::MLOG_GAIA_TIME_STAMP:
    case gaia_apply::MLOG_GAIA_ALLOC_EXTENT:
    case gaia_apply::MLOG_FILE_DELETE:
        return false;
    default:
        return true;
    }
}

inline gaia_apply::lsn_t log_translate_lsn_to_sn(gaia_apply::lsn_t lsn) {
    /* Calculate sn of the beginning of log block, which contains
    the provided lsn value. */
    const uint64_t sn = lsn / gaia_apply::OS_FILE_LOG_BLOCK_SIZE * LOG_BLOCK_DATA_SIZE;
    /* Calculate offset for the provided lsn within the log block.
    The offset includes LOG_BLOCK_HDR_SIZE bytes of block's header. */
    const uint32_t diff = lsn % gaia_apply::OS_FILE_LOG_BLOCK_SIZE;
    if (diff < gaia_apply::LOG_BLOCK_HDR_SIZE) {
        return 0;
    }
    if (diff > gaia_apply::OS_FILE_LOG_BLOCK_SIZE - gaia_apply::LOG_BLOCK_TRL_SIZE) {
        return 0;
    }
    /* Add the offset but skip bytes of block's header. */
    return sn + diff - gaia_apply::LOG_BLOCK_HDR_SIZE;
}

inline gaia_apply::lsn_t log_translate_sn_to_lsn(gaia_apply::lsn_t sn) {
    return sn / LOG_BLOCK_DATA_SIZE * gaia_apply::OS_FILE_LOG_BLOCK_SIZE
        + sn % LOG_BLOCK_DATA_SIZE + gaia_apply::LOG_BLOCK_HDR_SIZE;
}

inline bool log_lsn_validate(gaia_apply::lsn_t lsn) {
    const uint32_t offset = lsn % gaia_apply::OS_FILE_LOG_BLOCK_SIZE;
    return lsn >= LOG_START_LSN && offset >= gaia_apply::LOG_BLOCK_HDR_SIZE
        && offset < gaia_apply::OS_FILE_LOG_BLOCK_SIZE - gaia_apply::LOG_BLOCK_TRL_SIZE;
}


}
