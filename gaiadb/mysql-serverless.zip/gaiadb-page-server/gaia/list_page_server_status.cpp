/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server_status.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_page_server_status.h"
#include "psvr/psminfo.h"
#include <array>
#include <cstdio>
#include <cerrno>

namespace psvr {
namespace gaia {

static std::array<std::string, 6> format_stage_infos(
        const google::protobuf::RepeatedPtrField<pspb::SegmentStageInfo>& stage_infos) {
    std::array<std::string, 6> result {};
    for (const auto& stage_info : stage_infos) {
        size_t index = 0;
        if (stage_info.stage() >= pspb::ParseStageUnInit) {
            index = 1;
        }
        if (stage_info.stage() >= pspb::AppendStageUnInit) {
            index = 2;
        }
        if (stage_info.stage() >= pspb::GCStageUnInit) {
            index = 3;
        }
        if (stage_info.stage() >= pspb::RecoverStageUnInit) {
            index = 4;
        }
        if (stage_info.stage() >= pspb::DblwrStageUnInit) {
            index = 5;
        }
        result[index] = pspb::SegmentStage_Name(stage_info.stage());
        if (stage_info.has_action()) {
            result[index].append(":");
            result[index].append(stage_info.action());
        }
        if (stage_info.has_queue_size()) {
            result[index].append("/queue_size=");
            result[index].append(std::to_string(stage_info.queue_size()));
        }
        if (stage_info.has_file_no()) {
            result[index].append("/file_no=");
            result[index].append(std::to_string(stage_info.file_no()));
        }
        if (stage_info.has_size()) {
            result[index].append("/size=");
            result[index].append(std::to_string(stage_info.size()));
        }
        if (stage_info.has_time()) {
            result[index].append("/time=");
            result[index].append(std::to_string(stage_info.time()));
        }
        if (stage_info.has_quota_state()) {
            result[index].append("/quota_state=");
            result[index].append(pspb::QuotaState_Name(stage_info.quota_state()));
        }
    }
    return result;
}

void ListPageServerStatus::Done(pspb::BatchGetStatusResponse_ServerStatus* server_status,
        pspb::GetStatusResponse* response, RpcStatus* status) {
    if (!status->IsOk()) {
        LOG(WARNING) << "rpc failed:" << status;
        response->mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response->mutable_status()->set_msg(status->msg);
        response->set_fetch_lsn(0);
        response->set_shred_lsn(0);
        response->set_apply_lsn(0);
        response->set_cn_lowest_lsn(0);
        response->set_checkpoint_lsn(0);
    }
    server_status->mutable_status()->CopyFrom(*response);
    _task_count.fetch_sub(1, std::memory_order_release);
    delete response;
    delete status;
}

void ListPageServerStatus::Done2(pspb::BatchMultiGetStatusResponse_ServerStatus* server_status,
        pspb::MultiGetStatusResponse* response, RpcStatus* status) {
    if (!status->IsOk()) {
        LOG(WARNING) << "rpc failed:" << status;
        response->mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response->mutable_status()->set_msg(status->msg);
    }
    server_status->mutable_status()->CopyFrom(*response);
    _task_count.fetch_sub(1, std::memory_order_release);
    delete response;
    delete status;
}

int ListPageServerStatus::Execute(const base::EndPoint& node,
        pspb::GetStatusResponse* response, RpcStatus* status, ggpb::Closure* closure) {
    pspb::GetStatusRequest request;
    request.set_log_id(_log_id);
    if (_segments.size()) {
        print_error("--multi-segment is disable in single type\n");
        return 1;
    }
    if ((_cluster_id.size() && !_segment_id.has_val)
            || (_cluster_id.empty() && _segment_id.has_val)) {
        print_error("--cluster-id and --segment-id should always appear in pairs in single type");
        return 1;
    }

    if (_segment_id.has_val) {
        if (_segment_id.val < 1) {
            print_error("error --segment-id:%u", _segment_id.val);
            return 1;
        }
        request.set_cluster_id(_cluster_id);
        request.set_segment_id(_segment_id.val);
    }
    _client.Call(_log_id++, node, &pspb::QueryService_Stub::GetServerStatus, &request, response,
            closure, status, _timeout_ms);
    return 0;
}

int ListPageServerStatus::Execute(const base::EndPoint& node,
        pspb::MultiGetStatusResponse* response, RpcStatus* status, ggpb::Closure* closure) {
    pspb::MultiGetStatusRequest request;

    request.set_log_id(_log_id);
    if (_segments.size() && _cluster_id.size()) {
        print_error("choice one between --multi-segment and --cluster-id");
        return 1;
    }

    if (_segments.size()) {
        std::string error;
        bool ret = JsonToProtoMessage(_segments, &request, &error);
        if (!ret) {
            print_error("--multi-segment convert to json error, %s", error.c_str());
            return 1;
        }
    } else if (_cluster_id.size()) {
        auto segment_pb = request.add_segments();
        segment_pb->set_cluster_id(_cluster_id);
        if (_segment_id.has_val) {
            if (_segment_id.val < 1) {
                print_error("error --segment-id:%u", _segment_id.val);
                return 1;
            }
            segment_pb->set_segment_id(_segment_id.val);
        }
    }

    if (_show_store) {
        request.set_get_store_info(true);
    }
    if (_only_show_store) {
        request.set_only_get_store_info(true);
    }
    if (_show_stage_infos) {
        request.set_show_stages(true);
    }
    _client.Call(_log_id++, node, &pspb::QueryService_Stub::MultiGetServerStatus, &request, response,
            closure, status, _timeout_ms);
    return 0;
}

int ListPageServerStatus::Run() {
    if (_cluster_addr.empty() && (_address.empty() || _port < 1)) {
        print_error("miss --cluster-addr or (--address and --port)");
        return 1;
    }

    // get one
    if (_cluster_addr.empty()) {
        base::EndPoint node;
        int ret = base::str2endpoint(_address.c_str(), _port, &node);
        if (ret != 0) {
            print_error("--address and --port convert to endpoint error");
            return 1;
        }
        if (!_multi_type) {
            pspb::GetStatusResponse response;
            RpcStatus status;
            ret = Execute(node, &response, &status, nullptr);
            if (ret) {
                return ret;
            }
            if (!status.IsOk()) {
                response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
                response.mutable_status()->set_msg(status.msg);
            }
            return Output(response);
        } else {
            pspb::MultiGetStatusResponse response;
            RpcStatus status;
            ret = Execute(node, &response, &status, nullptr);
            if (ret) {
                return ret;
            }
            if (!status.IsOk()) {
                response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
                response.mutable_status()->set_msg(status.msg);
            }
            return Output(response);
        }
    }

    // get all
    PsmInfo psm_info(_cluster_addr, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--cluster-addr parse failed, cant get server list");
        return 1;
    }

    auto wait_finish_fn = [this] () {
        while (!_stopped) {
            if (_task_count.load(std::memory_order_acquire) == 0) {
                break;
            } else {
                gaiadb::common::pause();    // x86
            }
        }
        if (_stopped) {
            print_error("quit by signal");
            return 1;
        }
        return 0;
    };

    _task_count.store(nodes.size());
    if (!_multi_type) {
        if (!_segment_id.has_val || _cluster_id.empty()) {
            print_error("missing --cluster-id or --segment-id");
            return 1;
        }

        pspb::BatchGetStatusResponse response;
        response.set_log_id(_log_id);
        for (auto& node : nodes) {
            auto server_status = response.add_server_status();
            server_status->set_addr(gaiadb::common::endpoint2str(node));
            pspb::GetStatusResponse* rsp = new pspb::GetStatusResponse;
            RpcStatus* status = new RpcStatus;
            auto closure = brpc::NewCallback(this, &ListPageServerStatus::Done, server_status, rsp, status);
            int ret = Execute(node, rsp, status, closure);
            if (ret) {
                status->Reset(RpcCode::kInvalidArgs, "invalid");
                closure->Run();
            }
        }
        if (wait_finish_fn()) {
            return 1;
        }
        return Output(response);
    } else {
        pspb::BatchMultiGetStatusResponse  response;
        response.set_log_id(_log_id);
        for (auto& node : nodes) {
            auto server_status = response.add_server_status();
            server_status->set_addr(gaiadb::common::endpoint2str(node));
            pspb::MultiGetStatusResponse* rsp = new pspb::MultiGetStatusResponse;
            RpcStatus* status = new RpcStatus;
            auto closure = brpc::NewCallback(this, &ListPageServerStatus::Done2, server_status, rsp, status);
            int ret = Execute(node, rsp, status, closure);
            if (ret) {
                status->Reset(RpcCode::kInvalidArgs, "invalid");
                closure->Run();
            }
        }
        if (wait_finish_fn()) {
            return 1;
        }

        // sort by topology_zone in cluster-addr mode
        std::sort(response.mutable_server_status()->begin(),
                response.mutable_server_status()->end(),
                [](const pspb::BatchMultiGetStatusResponse::ServerStatus& lhs,
                    const pspb::BatchMultiGetStatusResponse::ServerStatus& rhs){
                    if (lhs.status().status().code() == pspb::Status_ReturnCode_SUCCESS
                            && rhs.status().status().code() == pspb::Status_ReturnCode_SUCCESS) {
                        return lhs.status().topology_zone() < rhs.status().topology_zone();
                    } else {
                        return lhs.addr() < rhs.addr();
                    }
                });

        return Output(response);
    }
}

int ListPageServerStatus::Format(const pspb::GetStatusResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"fetch_lsn:", rsp.fetch_lsn()});
    table.AddRowsValue({"apply_lsn:", rsp.apply_lsn()});
    table.AddRowsValue({"append_lsn:", rsp.append_lsn()});
    table.AddRowsValue({"checkpoint_lsn:", rsp.checkpoint_lsn()});
    table.AddRowsValue({"append_checkpoint_lsn:", rsp.append_checkpoint_lsn()});
    table.AddRowsValue({"append_db_size:", rsp.append_db_size()});
    table.AddRowsValue({"cn_lowest_lsn:", rsp.cn_lowest_lsn()});
    table.Display();
    return 0;
}

int ListPageServerStatus::Format(const pspb::BatchGetStatusResponse& rsp) {
    Table __table(_raw_with_table, 2);
    __table.AddRowsValue({"log_id:", _log_id});
    __table.Display();

    Table table(_raw_with_table, 0);
    table.AddRowsWithName({"node", "fetch_lsn", "apply_lsn", "append_lsn",
            "checkpoint_lsn", "append_checkpoint_lsn", "db_checkpoint_lsn",
            "append_db_size", "cn_lowest_lsn"}, true);
    for (int32_t i = 0; i < rsp.server_status_size(); ++i) {
        const auto& server_status = rsp.server_status(i);
        const auto& rsp2 = server_status.status();
        if (rsp2.status().code() != pspb::Status_ReturnCode_SUCCESS) {
            table.AddRowsValue({
                        server_status.addr(),
                        RowStr(pspb::Status_ReturnCode_Name(rsp2.status().code()), rsp2.status().msg()),
                        "", "", "", "", "", ""
                    });
        } else {
            table.AddRowsValue({
                    server_status.addr(),
                    rsp2.fetch_lsn(),
                    rsp2.apply_lsn(),
                    rsp2.append_lsn(),
                    rsp2.checkpoint_lsn(),
                    rsp2.append_checkpoint_lsn(),
                    rsp2.db_checkpoint_lsn(),
                    rsp2.append_db_size(),
                    rsp2.cn_lowest_lsn()});
        }
    }
    table.Display();
    return 0;
}

int ListPageServerStatus::Format(const pspb::MultiGetStatusResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.status().code() == pspb::Status_ReturnCode_SUCCESS) {

        Table table1(_raw_with_table, 2);
        table1.AddRowsValue({"topology_zone:", rsp.topology_zone()});
        table1.AddRowsValue({"topology_to_offline:", rsp.topology_to_offline()});
        table1.AddRowsValue({"git_commit:", get_unknown_type(rsp.has_git_commit(), rsp.git_commit())});
        table1.AddRowsValue({"pkg_version:", get_unknown_type(rsp.has_pkg_version(), rsp.pkg_version())});
        table1.Display();

        if (rsp.segments_size()) {
            Table table2(_raw_with_table, 0);
            if (_show_stage_infos) {
                table2.AddRowsWithName({"cluster_id", "segment_id", "replica_id", "version",
                        "fetch_lsn", "apply_lsn", "append_lsn", "checkpoint_lsn",
                        "append_checkpoint_lsn", "db_checkpoint_lsn", "cn_lowest_lsn",
                        "FetchStage", "ParseStage", "AppendStage", "GCStage", "RecoverStage", "DblwrStage"}, true);
            } else {
                table2.AddRowsWithName({"cluster_id", "segment_id", "replica_id", "version",
                        "fetch_lsn", "apply_lsn", "append_lsn", "checkpoint_lsn",
                        "append_checkpoint_lsn", "db_checkpoint_lsn", "cn_lowest_lsn",
                        "store_id", "segment_size", "physical_size", "append_size", "status", "init_flag",
                        "init_lsn_ok", "in_recovery", "compress_num", "manager_address"}, true);
            }

            for (int32_t i = 0; i < rsp.segments_size(); ++i) {
                const auto& seg_pb = rsp.segments(i);
                if (seg_pb.status().code() == pspb::Status_ReturnCode_SUCCESS) {
                    if (_show_stage_infos) {
                        const auto stage_actions = format_stage_infos(seg_pb.stage_infos());
                        table2.AddRowsValue({seg_pb.cluster_id(), seg_pb.segment_id(), seg_pb.replica_id(), seg_pb.version(),
                                seg_pb.fetch_lsn(), seg_pb.apply_lsn(), seg_pb.append_lsn(),
                                seg_pb.checkpoint_lsn(), seg_pb.append_checkpoint_lsn(), seg_pb.db_checkpoint_lsn(),
                                seg_pb.cn_lowest_lsn(), stage_actions[0], stage_actions[1],
                                stage_actions[2], stage_actions[3], stage_actions[4], stage_actions[5]});
                    } else {
                        table2.AddRowsValue({seg_pb.cluster_id(), seg_pb.segment_id(), seg_pb.replica_id(), seg_pb.version(),
                                seg_pb.fetch_lsn(), seg_pb.apply_lsn(), seg_pb.append_lsn(),
                                seg_pb.checkpoint_lsn(), seg_pb.append_checkpoint_lsn(),
                                seg_pb.db_checkpoint_lsn(), seg_pb.cn_lowest_lsn(),
                                seg_pb.store_id(), RowSize(seg_pb.segment_size(), _human_readable),
                                RowSize(seg_pb.segment_physical_size(), _human_readable),
                                RowSize(seg_pb.append_db_size(), _human_readable),
                                seg_pb.segment_status(), seg_pb.init_flag(),
                                get_unknown_type(seg_pb.has_init_lsn_ok(), seg_pb.init_lsn_ok()),
                                get_unknown_type(seg_pb.has_in_recovery(), seg_pb.in_recovery()),
                                get_unknown_type(seg_pb.has_compress_num(), seg_pb.compress_num()),
                                seg_pb.manager_address()});
                    }
                } else {
                    if (seg_pb.has_segment_id()) {
                        table2.AddRowsValue({
                                    seg_pb.cluster_id(),
                                    seg_pb.segment_id(),
                                    RowStr(pspb::Status_ReturnCode_Name(seg_pb.status().code()), seg_pb.status().msg())
                                });
                    } else {
                        table2.AddRowsValue({
                                    seg_pb.cluster_id(),
                                    RowStr(pspb::Status_ReturnCode_Name(seg_pb.status().code()), seg_pb.status().msg())
                                });
                    }
                }
            }

            table2.Display();
        }

        if (rsp.stores_size()) {
            Table table2(_raw_with_table, 0);
            table2.AddRowsWithName({
                    "store_id", "status",
                    "size_type", "store_size", "physical_store_size",
                    "logic_used_size", "physical_used_size", "physical_used_rate", "free_size", "compress_rate",
                    "capacity_status", "capacity", "used_capacity",
                    "store_path", "io_error_count"});
            for (int32_t i = 0; i < rsp.stores_size(); ++i) {
                const auto& store_pb = rsp.stores(i);
                table2.AddRowsValue({
                        store_pb.store_id(),
                        store_pb.active() ? "active" : "inactive",
                        store_pb.specify_store_size() ? "manual" : "auto",
                        RowSize(store_pb.store_size(), _human_readable),
                        RowSize(store_pb.physical_store_size(), _human_readable),
                        RowSize(store_pb.logic_used_size(), _human_readable),
                        RowSize(store_pb.physical_used_size(), _human_readable),
                        RowPercent(store_pb.physical_used_size(), store_pb.physical_store_size()),
                        RowSize(store_pb.free_size(), _human_readable),
                        get_unknown_type(store_pb.has_compress_rate(), store_pb.compress_rate()),
                        store_pb.capacity() > -1 ? "on" : "off",
                        store_pb.capacity(), store_pb.used_capacity(),
                        store_pb.store_path(),
                        store_pb.io_error_count()});
            }

            table2.Display();
        }
    }
    return 0;
}

int ListPageServerStatus::Format(const pspb::BatchMultiGetStatusResponse& rsp) {
    // output iplist file if specified
    if (!_output_iplist.empty()) {
        // check if file exists
        FILE* check_fp = fopen(_output_iplist.c_str(), "r");
        if (check_fp) {
            fclose(check_fp);
            if (!execute_confirm("File %s already exists, do you want to truncate it?", _output_iplist.c_str())) {
                print_error("user cancel, exit");
                return 1;
            }
        }

        FILE* fp = fopen(_output_iplist.c_str(), "w");
        if (!fp) {
            print_error("open iplist file %s failed, error: %s", _output_iplist.c_str(), strerror(errno));
            return 1;
        }

        // group by topology_zone
        std::map<int32_t, std::vector<std::string>> zone_addrs;
        for (int32_t j = 0; j < rsp.server_status_size(); ++j) {
            const auto& server_status = rsp.server_status(j);
            const auto& rsp2 = server_status.status();
            if (rsp2.status().code() != pspb::Status_ReturnCode_SUCCESS) {
                fclose(fp);
                print_error("server %s status failed, code: %s, msg: %s",
                        server_status.addr().c_str(),
                        pspb::Status_ReturnCode_Name(rsp2.status().code()).c_str(),
                        rsp2.status().msg().c_str());
                return 1;
            }
            zone_addrs[rsp2.topology_zone()].push_back(server_status.addr());
        }

        // output grouped by topology_zone
        for (const auto& [zone, addrs] : zone_addrs) {
            fprintf(fp, "topology_zone: %d\n", zone);
            for (const auto& addr : addrs) {
                fprintf(fp, "%s\n", addr.c_str());
            }
            fprintf(fp, "\n");
        }

        fclose(fp);
        std::cout << "output iplist to file: " << _output_iplist << std::endl;
        return 0;  // exit early in iplist mode, do not display store info
    }

    Table __table(_raw_with_table, 2);
    __table.AddRowsValue({"log_id:", _log_id});
    __table.Display();
    for (int32_t j = 0; j < rsp.server_status_size(); ++j) {
        const auto& server_status = rsp.server_status(j);
        const auto& rsp2 = server_status.status();

        Table table(_raw_with_table, 0);
        if (rsp2.status().code() != pspb::Status_ReturnCode_SUCCESS) {
            table.AddRowsWithName({"no", "node", ""});
            table.AddRowsValue({
                        j + 1, server_status.addr(),
                        RowStr(pspb::Status_ReturnCode_Name(rsp2.status().code()), rsp2.status().msg())
                    });
        } else {
            table.AddRowsWithName({"no", "node", "zone", "offline", "git_commit", "pkg_version"});
            table.AddRowsValue({j + 1, server_status.addr(), rsp2.topology_zone(), rsp2.topology_to_offline(),
                    get_unknown_type(rsp2.has_git_commit(), rsp2.git_commit()),
                    get_unknown_type(rsp2.has_pkg_version(), rsp2.pkg_version())});
        }
        table.Display();

        if (rsp2.segments_size()) {
            Table table2(_raw_with_table, 0);
            if (_show_stage_infos) {
                table2.AddRowsWithName({
                        "cluster_id", "segment_id", "replica_id", "version",
                        "fetch_lsn", "apply_lsn", "checkpoint_lsn", "append_checkpoint_lsn", "db_checkpoint_lsn",
                        "cn_lowest_lsn", "FetchStage", "ParseStage", "AppendStage",
                        "GCStage", "RecoverStage", "DblwrStage"
                }, true);
            } else {
                table2.AddRowsWithName({
                        "cluster_id", "segment_id", "replica_id", "version",
                        "fetch_lsn", "apply_lsn", "checkpoint_lsn", "append_checkpoint_lsn",
                        "db_checkpoint_lsn", "cn_lowest_lsn",
                        "store_id", "segment_size", "physical_size", "append_size", "status", "init_flag",
                        "init_lsn_ok", "in_recovery", "compress_num", "manager_address"
                }, true);
            }
            for (int32_t i = 0; i < rsp2.segments_size(); ++i) {
                const auto& seg_pb = rsp2.segments(i);
                if (seg_pb.status().code() != pspb::Status_ReturnCode_SUCCESS) {
                    if (seg_pb.has_segment_id()) {
                        table2.AddRowsValue({
                                seg_pb.cluster_id(), seg_pb.segment_id(),
                                RowStr(pspb::Status_ReturnCode_Name(seg_pb.status().code()), seg_pb.status().msg())
                                });
                    } else {
                        table2.AddRowsValue({
                                seg_pb.cluster_id(),
                                RowStr(pspb::Status_ReturnCode_Name(seg_pb.status().code()), seg_pb.status().msg())
                                });
                    }
                    continue;
                }
                if (_show_stage_infos) {
                    const auto stage_actions = format_stage_infos(seg_pb.stage_infos());
                    table2.AddRowsValue({
                            seg_pb.cluster_id().c_str(), seg_pb.segment_id(), seg_pb.replica_id(), seg_pb.version(),
                            seg_pb.fetch_lsn(), seg_pb.apply_lsn(), seg_pb.checkpoint_lsn(),
                            seg_pb.append_checkpoint_lsn(), seg_pb.db_checkpoint_lsn(), seg_pb.cn_lowest_lsn(),
                            stage_actions[0], stage_actions[1], stage_actions[2],
                            stage_actions[3], stage_actions[4], stage_actions[5]
                            });
                } else {
                    table2.AddRowsValue({
                            seg_pb.cluster_id().c_str(), seg_pb.segment_id(), seg_pb.replica_id(), seg_pb.version(),
                            seg_pb.fetch_lsn(), seg_pb.apply_lsn(), seg_pb.checkpoint_lsn(),
                            seg_pb.append_checkpoint_lsn(), seg_pb.db_checkpoint_lsn(),
                            seg_pb.cn_lowest_lsn(), seg_pb.store_id(),
                            RowSize(seg_pb.segment_size(), _human_readable),
                            RowSize(seg_pb.segment_physical_size(), _human_readable),
                            RowSize(seg_pb.append_db_size(), _human_readable),
                            seg_pb.segment_status(), seg_pb.init_flag(),
                            get_unknown_type(seg_pb.has_init_lsn_ok(), seg_pb.init_lsn_ok()),
                            get_unknown_type(seg_pb.has_in_recovery(), seg_pb.in_recovery()),
                            get_unknown_type(seg_pb.has_compress_num(), seg_pb.compress_num()),
                            seg_pb.manager_address()
                            });
                }
            }
            table2.Display();
        }

        if (rsp2.stores_size()) {
            Table table2(_raw_with_table, 0);
            table2.AddRowsWithName({
                    "store_id", "status",
                    "size_type", "store_size", "physical_store_size",
                    "logic_used_size", "physical_used_size", "physical_used_rate", "free_size", "compress_rate",
                    "capacity_status", "capacity", "used_capacity",
                    "store_path", "io_error_count"});

            for (int32_t i = 0; i < rsp2.stores_size(); ++i) {
                const auto& store_pb = rsp2.stores(i);
                table2.AddRowsValue({
                        store_pb.store_id(),
                        store_pb.active() ? "active" : "inactive",
                        store_pb.specify_store_size() ? "manual" : "auto",
                        RowSize(store_pb.store_size(), _human_readable),
                        RowSize(store_pb.physical_store_size(), _human_readable),
                        RowSize(store_pb.logic_used_size(), _human_readable),
                        RowSize(store_pb.physical_used_size(), _human_readable),
                        RowPercent(store_pb.physical_used_size(), store_pb.physical_store_size()),
                        RowSize(store_pb.free_size(), _human_readable),
                        get_unknown_type(store_pb.has_compress_rate(), store_pb.compress_rate()),
                        store_pb.capacity() > -1 ? "on" : "off",
                        store_pb.capacity(), store_pb.used_capacity(),
                        store_pb.store_path(),
                        store_pb.io_error_count()
                });
            }

            table2.Display();
        }
    }
    return 0;
}

}
}
