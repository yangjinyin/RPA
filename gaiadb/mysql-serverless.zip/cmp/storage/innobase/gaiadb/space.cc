/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/space.cc
 The interface to the gaiadb storage

 Created 10/28/2022 Hongyu Qiao
 *******************************************************/
#include <gaiadb/psm_client/client.h>
#include <base/logging.h>
#include "fsp0types.h"
#include "gaiadb.h"
#include "space.h"

/** Extent space size to psm
@param[in]      space_id        id of the space
@param[in]      start           extent start offset
@param[in]      len             extent length
@return DB_SUCCESS if all OK */
dberr_t gaiadb_space_extent(space_id_t space_id,
                            os_offset_t start,
                            os_offset_t len) {
  //space size must align by 1M
  ut_a(start % (FSP_EXTENT_SIZE * UNIV_PAGE_SIZE) == 0);
  auto extent_start = start / (FSP_EXTENT_SIZE * UNIV_PAGE_SIZE);
  auto extent_len = len / (FSP_EXTENT_SIZE * UNIV_PAGE_SIZE);
  if (len % (FSP_EXTENT_SIZE * UNIV_PAGE_SIZE)) {
    extent_len++;
  }
  int32_t ret = gaiadb::GIE_OK;
  auto expect_space_size = extent_start + extent_len;
  do {
    ret = psmcli->extend_space(space_id, extent_start, extent_len);
    if (ret == gaiadb::GIE_OK) {
      break;
    } else if (ret == gaiadb::GIE_EXIST) {
      // refresh the space size
      LOG(WARNING) << "Manager: extend space size not exist"
                   << ". space_id:" << space_id
                   << ", extent_start:" << extent_start
                   << ", extent_len:" << extent_len;
      psmcli->drop_space_cache(space_id);
      page_no_t new_space_size = 0;
      while (psmcli->get_space_size(space_id, new_space_size)
            != gaiadb::GIE_OK) {
          LOG(WARNING) << "Get space size failed, space_id:" << space_id;
          std::this_thread::sleep_for(srv_space_request_interval);
          continue;
      }
      break;
    } else {
      LOG(WARNING) << "Manager: request extent space size failed,"
                   << " ret:" << ret << " space_id:" << space_id
                   << ", extent_start:" << extent_start
                   << ", extent_len:" << extent_len;
      psmcli->drop_space_cache(space_id);
      page_no_t new_space_size = 0;
      while (psmcli->get_space_size(space_id, new_space_size)
            != gaiadb::GIE_OK) {
          LOG(WARNING) << "Get space size failed, space_id:" << space_id;
          std::this_thread::sleep_for(srv_space_request_interval);
          continue;
      }
      if (new_space_size != extent_start) {
        extent_start = new_space_size;
        if (extent_start >= expect_space_size) {
          ret = gaiadb::GIE_OK;
          break;
        }
        extent_len = expect_space_size - extent_start;
        std::this_thread::sleep_for(srv_space_request_interval);
        continue;
      }
    }
  } while (true);

  switch(ret) {
    case gaiadb::GIE_OK:
    case gaiadb::GIE_EXIST:
      LOG(TRACE) << "Manager: extent space size success:"
        << ret << " space_id:" << space_id << " start offset: "
        << extent_start << " length: " << extent_len;
      return (DB_SUCCESS);
    default:
      LOG(ERROR) << "Manager: extent space failed:"
        << ret << " space_id:" << space_id << " start offset: "
        << extent_start << " length: " << extent_len;
      ut_ad(false);
      return (DB_ERROR);
  }
}

/** This function returns size about the specified space
@param[in]      space_id        id of the space
@return space size in bytes */
os_offset_t gaiadb_space_get_size(space_id_t space_id) {
  uint32_t extent_size = 0;
  int32_t ret = gaiadb::GIE_OK;
  do {
    ret = psmcli->get_space_size(space_id, extent_size);
    if (ret != gaiadb::GIE_OK) {
      LOG(ERROR) << "Manager: request get space size failed: "
        << ret << " space_id:" << space_id;
      std::this_thread::sleep_for(srv_space_request_interval);
    }
  } while (ret != gaiadb::GIE_OK
      && ret != gaiadb::GIE_SPACE_NOT_EXIST);

  switch(ret) {
    case gaiadb::GIE_OK:
      LOG(TRACE) << "Manager: request get space size success, space_id:"
        << space_id << ", extent_size:"<<extent_size;
      break;
    case gaiadb::GIE_SPACE_NOT_EXIST:
      LOG(ERROR) << "Manager: request get space size but not exist, space_id:"
        << space_id;
    return ((os_offset_t)-1);
  }

  return ((os_offset_t)extent_size * FSP_EXTENT_SIZE * UNIV_PAGE_SIZE);
}

/** Create a space to psm
@param[in]      space_id        Tablespace ID
@param[in]      extent_size            Initial size of the tablespace in extents,
@return DB_SUCCESS or error code */
dberr_t gaiadb_create_space(space_id_t space_id, uint32_t extent_size,
    bool is_tde, uint32_t tde_from_space) {
  gaiadb::psm_client::Space_meta space_meta;
  space_meta.logical_page_size = UNIV_PAGE_SIZE;
  space_meta.physical_page_size = UNIV_PAGE_SIZE;
  space_meta.is_compressed = false;
  space_meta.is_encrypted = is_tde;
  int32_t ret = gaiadb::GIE_OK;

  gaiadb::psm_client::Encryption_from encrypt_from{};
  if (tde_from_space != SPACE_UNKNOWN) {
    encrypt_from.has_space = true;
    encrypt_from.space_from = tde_from_space;
  }

  if (is_tde) {
    bool enable;
    do {
      ret = psmcli->get_tde_enable_status(enable);
      if (ret != gaiadb::GIE_OK) {
        LOG(ERROR) << "Manager: request get tde enable status failed: "
          << ret << " space_id:" << space_id;
        std::this_thread::sleep_for(srv_delay_send_request);
      }
    } while (ret != gaiadb::GIE_OK);

    if (!enable) {
      LOG(ERROR) << "Manager: tde is not enable in manager, Cannot create tde tablespace!";
      return DB_ERROR;
    }
  }

  do {
    ret = psmcli->create_space(space_id, extent_size, space_meta, 0, encrypt_from);
    if (ret != gaiadb::GIE_OK) {
      LOG(ERROR) << "Manager: request create space failed: "
        << ret << " space_id:" << space_id;
      std::this_thread::sleep_for(srv_space_request_interval);
    }
  } while (ret != gaiadb::GIE_OK
      && ret != gaiadb::GIE_EXIST);

  switch(ret) {
    case gaiadb::GIE_OK:
      LOG(TRACE) << "Manager: request create space success, space_id:"
        << space_id << ", is_tde:" << is_tde << ", tde_from_space:" << tde_from_space;
      return DB_SUCCESS;
    case gaiadb::GIE_EXIST:
      LOG(NOTICE) << "Manager: request create space but exist, space_id:"
        << space_id << ", is_tde:" << is_tde << ", tde_from_space:" << tde_from_space;
      return DB_TABLESPACE_EXISTS;
    default:
      return DB_ERROR;
  }
}

/** Drop a space from psm
@param[in]      space_id        Tablespace ID
@return DB_SUCCESS or error code */
dberr_t gaiadb_drop_space(space_id_t space_id) {
  int32_t ret = gaiadb::GIE_OK;
  do {
    ret = psmcli->delete_space(space_id);
    if (ret != gaiadb::GIE_OK) {
      LOG(ERROR) << "Manager: request delete space failed: "
        << ret << " space_id:" << space_id;
      std::this_thread::sleep_for(srv_space_request_interval);
    }
  } while (ret != gaiadb::GIE_OK
      && ret != gaiadb::GIE_SPACE_NOT_EXIST);

  switch(ret) {
    case gaiadb::GIE_OK:
      LOG(TRACE) << "Manager: request delete space success, space_id:"
        << space_id;
      return DB_SUCCESS;
    case gaiadb::GIE_SPACE_NOT_EXIST:
      LOG(NOTICE) << "Manager: request delete space not exist, space_id:"
        << space_id;
      return DB_TABLESPACE_DELETED;
    default:
      return DB_ERROR;
  }
}

/** This function check exist space
@param[in]      space_id        id of the space
@return true if all OK */
bool gaiadb_space_exist(space_id_t space_id) {
  auto exist = psmcli->is_space_exist(space_id);
  if (!exist) {
    int32_t ret = gaiadb::GIE_OK;
    std::shared_ptr<gaiadb::psm_client::Space_meta> space_meta;
    do {
      ret = psmcli->get_space_meta(space_id, false, space_meta);
      if (ret != gaiadb::GIE_OK && ret != gaiadb::GIE_SPACE_NOT_EXIST) {
        LOG(ERROR) << "Manager: request get space failed: "
        << ret << " space_id:" << space_id;
        std::this_thread::sleep_for(srv_space_request_interval);
      }
    } while (ret != gaiadb::GIE_OK && ret != gaiadb::GIE_SPACE_NOT_EXIST);
    switch(ret) {
      case gaiadb::GIE_OK:
      LOG(TRACE) << "Manager: request get space success, space_id:"
        << space_id;
      exist = true;
      break;
    case gaiadb::GIE_SPACE_NOT_EXIST:
      LOG(NOTICE) << "Manager: request get space not exist, space_id:"
        << space_id;
      exist = false;
      break;
    default:
      exist = false;
    }
  }
  return exist;
}
