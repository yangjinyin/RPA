/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/rw16k.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <memory>
#include <iostream>
#include <filesystem>
#include <sys/stat.h>
#include <psvr/config.h>
#include <psvr/compress_utils.h>
#include <psvr/stat.h>
#include <psvr/thread_pool.hpp>
#include <psvr/namespace.h>

namespace psvr {

DEFINE_int32(compress_store_num, 8, "gc store size");
DEFINE_int32(compress_thread_num, 8, "gc thread num per store");
DEFINE_int64(compress_quota_per_thread, (10 << 20), "compress max bw, kb");

struct DemoContext : public thread::TaskContext {
    size_t thread_pool_idx {0};
    size_t idx {0};
};

static void rand_make_data(gaia_apply::byte* page, uint32_t size) {
    for (uint32_t i = 0; i < size; ++i) {
        page[i] = ((base::fast_rand() + i) % 5) + 'a';
    }
}

constexpr static size_t kPageSize = (16<<10);

class Demo {
public:
    Demo() : _buf(nullptr), _dst_buf(nullptr), _stat_avg(kSlaWindowSize) {
        _timer.reset(new thread::Timer<thread::TaskContext>("shared"));
        _thread_pool.reset(new GroupThreadPoolExecutor<DemoContext, thread::TaskContext>);
    }
    ~Demo() {
        std::free(_buf);
        std::free(_dst_buf);
    }

    bool OnTimer(thread::TaskContext* ctx) {
        DemoContext* ctx2 = static_cast<DemoContext*>(ctx);
        return _thread_pool->EmergentExecute(ctx2->thread_pool_idx, ctx2);
    }

    void OnCompletion(DemoContext* ctx) {
        gaia_apply::byte* buf = _buf + ((ctx->thread_pool_idx * FLAGS_compress_thread_num + ctx->idx) * kPageSize);
        auto flw = _stores_flow[ctx->thread_pool_idx * FLAGS_compress_thread_num + ctx->idx];
        gaia_apply::byte* dst = _dst_buf + ((ctx->thread_pool_idx * FLAGS_compress_thread_num + ctx->idx) * kPageSize * 2);

        auto ms = flw->GetQuota(kPageSize);
        if (ms) {
            _thread_pool->Schedule(ctx->thread_pool_idx, ctx, ms * 1000);
            return;
        }

        auto compress_type = FLAGS_psvr_gc_compress_type;
        auto compress_level = FLAGS_psvr_gc_compress_level;
        if (compress_type == PSVR_COMPRESS_TYPE_ZSTD) {
            compress_level = FLAGS_psvr_gc_compress_zstd_level;
        } else if (compress_type == PSVR_COMPRESS_TYPE_LZ4) {
            compress_level = FLAGS_psvr_gc_compress_lz4_level;
        } else {
            // Add new type need to update it.
            compress_level = FLAGS_psvr_gc_compress_level;
        }

        Timer compress_timer(base::Timer::STARTED);
        gaia_apply::ulint compressed_size = 0;
        bool ret = compress_data(compress_type, compress_level, buf, kPageSize, dst, kPageSize * 2, &compressed_size);
        if (!ret) {
            std::cout << "compress fail, idx:" << ctx->thread_pool_idx << " idx2:" << ctx->idx << std::endl;
        }
        ret = decompress_data(compress_type, dst, compressed_size, kPageSize, buf);
        if (!ret) {
            std::cout << "decompress fail, idx:" << ctx->thread_pool_idx << " idx2:" << ctx->idx << std::endl;
        }

        _stat_lat << compress_timer.u_elapsed();
        _stat_avg << compressed_size;
        _thread_pool->Execute(ctx->thread_pool_idx, ctx);
    }

    int Run() {
        const int32_t nr = FLAGS_compress_store_num * FLAGS_compress_thread_num;
        if (nr < 1) {
            return -1;
        }

        _buf = static_cast<gaia_apply::byte*>(std::malloc(nr * kPageSize));
        _dst_buf = static_cast<gaia_apply::byte*>(std::malloc(nr * kPageSize * 2));
        if (!_buf || !_dst_buf) {
            return -2;
        }
        rand_make_data(_buf, nr * kPageSize);

        for (int32_t i = 0; i < nr; ++i) {
            _stores_flow.emplace_back(new FlowQuota(&FLAGS_compress_quota_per_thread));
        }

        typename thread::Timer<thread::TaskContext>::TaskFn timer_fn = std::bind(&Demo::OnTimer,
                this, ARG::_1);
        _timer->Start(FLAGS_psvr_timer_tick_interval, timer_fn);

        // IO will block thread on bad store, so let GC tasks for each store run disjointly
        typename thread::Executor<DemoContext, thread::TaskContext>::TaskFn fn
            = std::bind(&Demo::OnCompletion, this, std::placeholders::_1);
        // the last group thread pool for exec empty log block
        if (!_thread_pool->Start(FLAGS_compress_store_num, "compress", _timer, FLAGS_compress_thread_num, fn)) {
            return -3;
        }

        for (int32_t i = 0; i < FLAGS_compress_store_num; ++i) {
            for (int32_t j = 0; j < FLAGS_compress_thread_num; ++j) {
                DemoContext* ctx = new DemoContext;
                ctx->thread_pool_idx = i;
                ctx->idx = j;
                _thread_pool->Execute(i, ctx);
            }
        }

        std::cout << "start test compress cpu used."
            << " store:" << FLAGS_compress_store_num
            << " store_thread:" << FLAGS_compress_thread_num
            << std::endl;
        while (1) {
            int64_t total = 0;
            for (auto& flw : _stores_flow) {
                total += flw->stat_used_size_per_seoncd().get_value();
            }
            std::cout << "Compress BW:" << (total >> 20) << " MB"
                << " QPS:" << _stat_lat.qps()
                << " Avg_Lat:" << _stat_lat.latency() << " us"
                << " Avg_Size:" << _stat_avg.get_value()
                << std::endl;
            sleep_for(1 * 1000 * 1000);
        }
    }

private:
    std::shared_ptr<GroupThreadPoolExecutor<DemoContext, thread::TaskContext>> _thread_pool;
    std::shared_ptr<thread::Timer<thread::TaskContext>> _timer;
    gaia_apply::byte* _buf;
    gaia_apply::byte* _dst_buf;
    std::vector<std::shared_ptr<FlowQuota>> _stores_flow;
    StatLatency _stat_lat;
    StatAvg _stat_avg;
};

}

int main(int argc, char *argv[]) {
    const char* psvr_proc_name = strrchr(argv[0], '/');
    if (nullptr == psvr_proc_name) {
        psvr_proc_name = argv[0];
    } else {
        psvr_proc_name++;
    }
    std::string help_str;
    base::string_printf(&help_str,
            "Usage: %s [OPTIONS...]\n"
            "Options:\n"
            " -psvr_gc_compress_type=<type>             compress type\n"
            " -compress_store_num=8                     compress group num\n"
            " -compress_thread_num=8                    compress group thread num\n"
            " -compress_quota_per_thread=134217728      thread quota\n",
            psvr_proc_name);
    google::SetUsageMessage(help_str);

    google::ParseCommandLineFlags(&argc, &argv, true);

    psvr::Demo demo;
    return demo.Run();
}

