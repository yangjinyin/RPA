/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file /home/yukeyong/baidu/dba/gaiadb-page-server/psvr/fetch.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <base/rand_util.h>
#include "psvr/config.h"
#include "psvr/control.h"
#include "psvr/utils.h"
#include "psvr/segment_manager.h"
#include "psvr/fetch_context.h"

namespace psvr {

#define define_cluster_or_return_invalid(_ctx) \
    ClusterPtr cluster = _ctx->cluster.lock();  \
    while (!cluster) { \
        CtxGuard ctx_guard(_ctx);   \
        LOG(WARNING) << "cluster invalid," \
            << " id:[" << _ctx->cluster_id \
            << "] batch_idx:[" << _ctx->batch_idx \
            << "] batch_version:[" << _ctx->batch_version \
            << "]"; \
        return; \
    }

static const uint32_t kQuotaSegment = 1;
static const uint32_t kQuotaCluster = 2;
static const uint32_t kQuotaGlobal = 4;

static bvar::Adder<int64_t> l_stat_log_block_used_count("psvr_log_block_used_count");
static bvar::Adder<int64_t> l_stat_log_block_used_mem_byte("psvr_log_block_used_mem_byte");
// Recover redo (fetch from peer / append recover) is a subset of the log blocks above,
// counted separately so its memory footprint can be observed on its own.
static bvar::Adder<int64_t> l_stat_log_block_recover_used_count("psvr_log_block_recover_used_count");
static bvar::Adder<int64_t> l_stat_log_block_recover_used_mem_byte("psvr_log_block_recover_used_mem_byte");

static uint64_t fetch_get_delay_us(uint32_t retry_times,
        uint64_t retry_interval_us = FLAGS_psvr_fetcher_delay_min_us,
        uint64_t max_delay_us = FLAGS_psvr_fetcher_delay_max_us) {
    return get_delay_us(retry_times, retry_interval_us, max_delay_us);
}

static uint32_t kExtraThreadNum = 1;

enum class BatchFetchType : uint32_t {
    kNone = 0,
    kBatchALl = 1,
    kBatchCluster = 2,
};

bool FetcherType::IsSingleSegment() {
    return FLAGS_psvr_fetch_batch_type == static_cast<int32_t>(BatchFetchType::kNone);
}
bool FetcherType::IsBatchByAll() {
    return FLAGS_psvr_fetch_batch_type == static_cast<int32_t>(BatchFetchType::kBatchALl);
}
bool FetcherType::IsBatchByCluster() {
    return FLAGS_psvr_fetch_batch_type == static_cast<int32_t>(BatchFetchType::kBatchCluster);
}
int32_t FetcherType::SingleSegment() {
    return static_cast<int32_t>(BatchFetchType::kNone);
}
int32_t FetcherType::BatchByAll() {
    return static_cast<int32_t>(BatchFetchType::kBatchALl);
}
int32_t FetcherType::BatchByCluster() {
    return static_cast<int32_t>(BatchFetchType::kBatchCluster);
}

struct LogBlockDeleter {
    FetcherWeakPtr fetcher;
    ClusterWeakPtr cluster;
    SegmentWeakPtr segment;
    uint32_t quota_flags;

    LogBlockDeleter(FetcherPtr _fetcher,
        ClusterPtr _cluster,
        SegmentPtr _segment,
        uint32_t _quota_flags)
        : fetcher(_fetcher),
        cluster(_cluster),
        segment(_segment),
        quota_flags(_quota_flags) {}

    void operator()(LogBlock* log_block) const;
};

void LogBlockDeleter::operator()(LogBlock* log_block) const {
    auto ftc = fetcher.lock();
    if (!ftc) {
        delete log_block;
        return;
    }
    auto cls = cluster.lock();
    const auto quota_size = log_block->quota_size;
    const bool is_recover_redo = log_block->from_append_file != FROM_NONE;
    if (quota_flags > 0 && quota_size > 0) {
        auto seg = segment.lock();
        if ((quota_flags & kQuotaSegment) && seg) {
            seg->PutQuota(quota_size);
        }
        if ((quota_flags & kQuotaCluster) && cls) {
            cls->PutQuota(quota_size, is_recover_redo);
        }
        if ((quota_flags & kQuotaGlobal) && ftc) {
            ftc->PutQuota(quota_size, is_recover_redo);
        }
    }
    l_stat_log_block_used_count << -1;
    l_stat_log_block_used_mem_byte << -quota_size;
    if (is_recover_redo) {
        l_stat_log_block_recover_used_count << -1;
        l_stat_log_block_recover_used_mem_byte << -quota_size;
    }
    if (cls) {
        set_cluster_stat(cls, stat_log_block_size, -1);
    }
    delete log_block;
}

// Recovery fetches (local append recover, and catch-up from peer) run on the
// dedicated append-recover thread pool, isolated from the steady-state fetch pool.
static inline bool is_recovery_action(Fetcher::Context* ctx) {
    return ctx->action == Fetcher::Action::kAppendRecover
        || ctx->action == Fetcher::Action::kGetRedoRecLog
        || ctx->action == Fetcher::Action::kDisposeRedoRecLog;
}

static const char* action2str(Fetcher::Action action) {
    switch (action) {
    case Fetcher::Action::kGetLogService:
        return "kGetLogService";
    case Fetcher::Action::kDisposeLogService:
        return "kDisposeLogService";
    case Fetcher::Action::kFetchRedoLog:
        return "kFetchRedoLog";
    case Fetcher::Action::kDisposeLogBlock:
        return "kDisposeLogBlock";
    case Fetcher::Action::kBatchMonitor:
        return "kBatchMonitor";
    case Fetcher::Action::kBatchGetLogService:
        return "kBatchGetLogService";
    case Fetcher::Action::kBatchDisposeLogService:
        return "kBatchDisposeLogService";
    case Fetcher::Action::kBatchFetchRedoLog:
        return "kBatchFetchRedoLog";
    case Fetcher::Action::kBatchDisposeLogBlock:
        return "kBatchDisposeLogBlock";
    case Fetcher::Action::kCheckReopenSegment:
        return "kCheckReopenSegment";
    case Fetcher::Action::kPreReopenSegment:
        return "kPreReopenSegment";
    case Fetcher::Action::kReopenSegment:
        return "kReopenSegment";
    case Fetcher::Action::kRestartSegment:
        return "kRestartSegment";
    case Fetcher::Action::kAppendRecover:
        return "kAppendRecover";
    case Fetcher::Action::kGetRedoRecLog:
        return "kGetRedoRecLog";
    case Fetcher::Action::kDisposeRedoRecLog:
        return "kDisposeRedoRecLog";
    default:
        return "unknown";
    }
}

const char* Fetcher::action2str(Fetcher::Action action) {
    return psvr::action2str(action);
}

bool Fetcher::BatchManager::Add(SegmentPtr segment, int32_t* batch_idx, uint64_t* version) {
    std::unique_lock lk(_shared_mutex);
    auto cluster = segment->cluster();
    auto it = _batch_clusters.find(segment->cluster_id());
    if (it == _batch_clusters.end()) {
        it = _batch_clusters.emplace(cluster->name(), std::make_shared<Batch>(++_version, cluster)).first;
    } else if (it->second->cluster.expired()) {
        {
            auto tmp_batch = it->second;
            std::unique_lock batch_lk(tmp_batch->shared_mutex);
            _batch_clusters.erase(it);
        }
        it = _batch_clusters.emplace(cluster->name(), std::make_shared<Batch>(++_version, cluster)).first;
    }
    int32_t max_segment_size = std::max(1, FLAGS_psvr_fetch_batch_segment_count);
    auto batch = it->second;
    std::unique_lock batch_lk(batch->shared_mutex);
    *version = batch->version;
    for (int32_t i = 0; i < batch->size; ++i) {
        auto& member = batch->members[i];
        if (member->size < max_segment_size) {
            *batch_idx = i;
            auto fit = member->segments.emplace(segment->segment_id(), segment);
            if (fit.second) {
                ++member->size;
            } else {
                fit.first->second = segment;
            }
            return false;
        }
    }

    *batch_idx = batch->size;
    ++batch->size;
    batch->members.emplace_back(std::make_shared<Member>());
    ++batch->members.back()->size;
    auto fit = batch->members.back()->segments.emplace(segment->segment_id(), segment);
    PSVR_ASSERT(fit.second);
    return true;
}

bool Fetcher::BatchManager::Exist(ClusterPtr cluster,
        int32_t batch_idx, uint64_t* version, rwlock_t** shared_mutex,
        rwlock_t** batch_shared_mutex) {
    std::shared_lock slk(_shared_mutex);
    auto it = _batch_clusters.find(cluster->name());
    if (it == _batch_clusters.end()) {
        return false;
    }
    auto batch = it->second;
    batch->shared_mutex.lock();
    if (batch->cluster.lock() == cluster) {
        if (batch_idx < batch->size) {
            *version = batch->version;
            *shared_mutex = slk.release();
            *batch_shared_mutex = &batch->shared_mutex;
            return true;
        }
    }
    batch->shared_mutex.unlock();
    return false;
}

bool Fetcher::BatchManager::RemoveNoLock(ClusterPtr cluster, SegmentPtr segment) {
    auto it = _batch_clusters.find(cluster->name());
    if (it == _batch_clusters.end()) {
        return false;
    }
    auto batch = it->second;
    int32_t batch_idx = segment->fetch_batch_idx();
    if (batch_idx >= 0 && batch_idx < batch->size) {
        if (batch->members[batch_idx]->segments.erase(segment->segment_id())) {
            --batch->members[batch_idx]->size;
            return true;
        }
    }
    for (int32_t i = 0; i < batch->size; ++i) {
        if (batch->members[i]->segments.erase(segment->segment_id())) {
            --batch->members[i]->size;
            return true;
        }
    }
    return false;
}

int32_t Fetcher::BatchManager::Get(ClusterPtr cluster, int32_t batch_idx,
        std::list<SegmentWeakPtr>* segments, uint64_t* version) {
    std::shared_lock slk(_shared_mutex);
    auto it = _batch_clusters.find(cluster->name());
    if (it == _batch_clusters.end()) {
        return -1;
    }
    auto batch = it->second;
    std::shared_lock batch_slk(batch->shared_mutex);
    *version = batch->version;
    if (batch_idx >= batch->size) {
        return -2;
    }
    if (batch->cluster.lock() != cluster) {
        return -3;
    }
    for (auto& mit : batch->members[batch_idx]->segments) {
        segments->emplace_front(mit.second);
    }
    return batch->members[batch_idx]->size;
}

int32_t Fetcher::BatchManager::TrimBatch(const std::string& cluster_id,
        uint64_t version, uint64_t* new_version) {
    std::unique_lock lk(_shared_mutex);
    auto it = _batch_clusters.find(cluster_id);
    if (it == _batch_clusters.end()) {
        return 0;
    }
    auto batch = it->second;
    std::unique_lock batch_lk(batch->shared_mutex);
    if (batch->version > version) {
        return 0;
    }
    int32_t max_segment_size = std::max(1, FLAGS_psvr_fetch_batch_segment_count);
    if (batch->size == 0) {
        batch->version = ++_version;
        _batch_clusters.erase(it);
        return 0;
    } else if (batch->size == 1
            && batch->members[0]->size <= max_segment_size) {
        auto member = batch->members[0];
        auto m_it = member->segments.begin();
        while (m_it != member->segments.end()) {
            if (m_it->second.expired()) {
                --member->size;
                m_it = member->segments.erase(m_it);
            } else {
                ++m_it;
            }
        }
        PSVR_ASSERT(member->size >= 0);
        if (member->size == 0) {
            --batch->size;
            batch->members.pop_back();
            batch->version = ++_version;
            _batch_clusters.erase(it);
        }
        return 0;   // dont change version
    } else {
        std::map<uint32_t, SegmentWeakPtr> extra_segments;
        size_t num = 0;
        for (int32_t i = 0; i < batch->size; ++i) {
            auto member = batch->members[i];
            for (auto mit : member->segments) {
                extra_segments[mit.first] = mit.second;
            }
            num += member->size;

            member->segments.clear();
            member->size = 0;
        }
        PSVR_ASSERT(num == extra_segments.size());
        {
            auto extra_it = extra_segments.begin();
            for (auto& member : batch->members) {
                while (extra_it != extra_segments.end()) {
                    if (member->size >= max_segment_size) {
                        break;
                    }
                    if (!extra_it->second.expired()) {
                        ++member->size;
                        member->segments.emplace(extra_it->first, extra_it->second);
                    }
                    ++extra_it;
                }
                if (extra_it == extra_segments.end()) {
                    break;
                }
            }
            while (extra_it != extra_segments.end()) {
                auto member = batch->members.back();
                if (member->size >= max_segment_size) {
                    ++batch->size;
                    batch->members.emplace_back(std::make_shared<Member>());
                    member = batch->members.back();
                }
                if (!extra_it->second.expired()) {
                    ++member->size;
                    member->segments.emplace(extra_it->first, extra_it->second);
                }
                ++extra_it;
            }
        }
        {
            for (int32_t i = batch->size - 1; i >= 0; --i) {
                if (batch->members[i]->size == 0) {
                    --batch->size;
                    batch->members.pop_back();
                } else {
                    break;
                }
            }
        }
        batch->version = ++_version;
        *new_version = batch->version;
        if (batch->size == 0) {
            _batch_clusters.erase(it);
        }
        return batch->size;
    }
}

void Fetcher::BatchManager::BuildTrims() {
    std::shared_lock slk(_shared_mutex);
    for (auto& it : _batch_clusters) {
        AddTrimCluster(it.first, it.second->version);
    }
}

void Fetcher::BatchManager::AddTrimCluster(ClusterPtr cluster, uint64_t version) {
    AddTrimCluster(cluster->name(), version);
}

void Fetcher::BatchManager::AddTrimCluster(const std::string& cluster_id, uint64_t version) {
    std::unique_lock lk(_trims_shared_mutex);
    _trims.emplace(Trim {cluster_id, version});
}

bool Fetcher::BatchManager::TrimFirst(std::string* cluster_id, uint64_t* version) {
    std::shared_lock slk(_trims_shared_mutex);
    auto it = _trims.begin();
    if (it != _trims.end()) {
        *cluster_id = it->cluster_id;
        *version = it->version;
        return true;
    }
    return false;
}

void Fetcher::BatchManager::TrimPop(const std::string& cluster_id, uint64_t version) {
    std::unique_lock lk(_trims_shared_mutex);
    auto it = _trims.begin();
    while (it != _trims.end()) {
        if (cluster_id == it->cluster_id && version == it->version) {
            _trims.erase(it);
            return;
        }
        ++it;
    }
}

Fetcher::Fetcher(ClientPtr client, ControlWeakPtr control)
    : Model<Fetcher>(client, control),
    _fetch_quota(new Quota(&FLAGS_psvr_fetch_max_buf_size)),
    _recover_redo_quota(new Quota(&FLAGS_psvr_recover_redo_max_buf_size)),
    _thread_num(FLAGS_psvr_fetcher_thread_num),
    _append_thread_num(1),
    _batch_manager(nullptr),
    _stat_batch_fetch_disposer_lat(kSlaWindowSize),
    _stat_fetch_task_lat(kSlaWindowSize),
    _stat_fetch_rpc_lat(kSlaWindowSize),
    _stat_fetch_rpc_callback_cost_lat(kSlaWindowSize),
    _stat_fetch_rpc_disposer_wait_lat(kSlaWindowSize),
    _stat_fetch_redo_rec_log_lat(kSlaWindowSize),
    _stat_fetch_append_recover_lat(kSlaWindowSize),
    _stat_fetch_log_buf_size(kSlaWindowSize),
    _stat_fetch_log_lsn_size_kb(kSlaWindowSize),
    _stat_fetch_size_per_node(kSlaWindowSize),
    _stat_fetch_empty_qps(kSlaWindowSize),
    _stat_fetch_by_server_push_qps(kSlaWindowSize),
    _stat_fetch_error_count(kSlaWindowSize),
    _stat_fetch_redo_rec_log_error_count(kSlaWindowSize),
    _stat_fetch_quota_fail_seg_count(kSlaWindowSize),
    _stat_fetch_quota_fail_cluster_count(kSlaWindowSize),
    _stat_fetch_quota_fail_global_count(kSlaWindowSize) {
    _thread_pool.reset(new ThreadPoolType);
    _append_recover_thread_pool.reset(new ThreadPoolType);
    _batch_manager.reset(new BatchManager);
    Expose();
}

void Fetcher::Expose() {
#ifndef GTEST
    _fetch_quota->expose("psvr_fetch_quota_total_remain");
    _recover_redo_quota->expose("psvr_recover_quota_total_remain");
    _stat_batch_fetch_disposer_lat.expose("psvr_batch_fetch_disposer");
    _stat_fetch_task_lat.expose("psvr_fetch_task");
    _stat_fetch_rpc_lat.expose("psvr_fetch_rpc");
    _stat_fetch_rpc_callback_cost_lat.expose("psvr_fetch_rpc_callback_cost");
    _stat_fetch_rpc_disposer_wait_lat.expose("psvr_fetch_rpc_disposer_wait");
    _stat_fetch_redo_rec_log_lat.expose("psvr_fetch_redo_rec_log");
    _stat_fetch_append_recover_lat.expose("psvr_fetch_append_recover");
    _stat_fetch_log_buf_size.expose("psvr_fetch_log_buf_size");
    _stat_fetch_log_lsn_size_kb.expose("psvr_fetch_lsn_size_kb");
    _stat_fetch_size_per_node.expose("psvr_fetch_size_per_node");
    _stat_fetch_empty_qps.expose("psvr_fetch_empty_qps"),
    _stat_fetch_by_server_push_qps.expose("psvr_fetch_by_server_push_qps"),
    _stat_fetch_error_count.expose("psvr_fetch_error_count");
    _stat_fetch_redo_rec_log_error_count.expose("fetch_redo_rec_log_error_count");
    _stat_fetch_quota_fail_seg_count.expose("psvr_fetch_quota_fail_seg_count");
    _stat_fetch_quota_fail_cluster_count.expose("psvr_fetch_quota_fail_cluster_count");
    _stat_fetch_quota_fail_global_count.expose("psvr_fetch_quota_fail_global_count");
#endif
}

bool Fetcher::SetUp() {
    ControlPtr control = _control.lock();
    if (!control) {
        LOG(ERROR) << "failed, control is release";
        return false;
    }
    if (control->multi_type()) {
        _thread_num = FLAGS_multi_psvr_fetcher_thread_num_per_store * _store_count;
        _append_thread_num = FLAGS_multi_psvr_append_recover_thread_num_pre_store * _store_count;
    }
    if (_thread_num < 1 || _append_thread_num < 1) {
        LOG(ERROR) << "failed, fethcer thread num == 0";
        return false;
    }
    // start a shared thread pool
    typename ThreadPoolType::TaskFn fn
        = std::bind(&Fetcher::OnCompletion, this, std::placeholders::_1);
    if (!_thread_pool->Start("fetcher", control->timer(), _thread_num + kExtraThreadNum,
                FLAGS_multi_psvr_fetcher_thread_enable_shared, fn)) {
        LOG(ERROR) << "fetcher thread pool start failed";
        return false;
    }
    if (!_append_recover_thread_pool->Start("append_recover", control->timer(),
                _append_thread_num, true, fn)) {
        LOG(ERROR) << "append db recover thread pool start failed";
        _thread_pool->Stop(true);
        return false;
    }
    return true;
}

bool Fetcher::PrepareTask() {
    if (!FetcherType::IsSingleSegment()) {
        LOG(NOTICE) << "schedule a batch fetch monitor ctx";
        auto ctx = new Context(Action::kBatchMonitor);
        ctx->fix_client_id = 0;
        Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(FLAGS_psvr_fetch_batch_monitor_s));
    }
    return true;
}

void Fetcher::TearDown() {
    LOG(NOTICE) << "fetcher will stop ...";
    _thread_pool->Stop(false);
    _append_recover_thread_pool->Stop(false);
    _fetch_quota->hide();
    _recover_redo_quota->hide();
    _stat_batch_fetch_disposer_lat.hide();
    _stat_fetch_task_lat.hide();
    _stat_fetch_rpc_lat.hide();
    _stat_fetch_rpc_callback_cost_lat.hide();
    _stat_fetch_rpc_disposer_wait_lat.hide();
    _stat_fetch_redo_rec_log_lat.hide();
    _stat_fetch_append_recover_lat.hide();
    _stat_fetch_log_buf_size.hide();
    _stat_fetch_log_lsn_size_kb.hide();
    _stat_fetch_size_per_node.hide();
    _stat_fetch_empty_qps.hide();
    _stat_fetch_by_server_push_qps.hide();
    _stat_fetch_error_count.hide();
    _stat_fetch_redo_rec_log_error_count.hide();
    _stat_fetch_quota_fail_seg_count.hide();
    _stat_fetch_quota_fail_cluster_count.hide();
    _stat_fetch_quota_fail_global_count.hide();
}

void Fetcher::Join() {
    LOG(NOTICE) << "fetcher will join ...";
    _thread_pool->Stop(true);
    _append_recover_thread_pool->Stop(true);
    LOG(NOTICE) << "fetcher will join ok";
}

bool Fetcher::IncOrDecThreadNum() {
    bool ret = false;
    {
        uint32_t cfg_n = FLAGS_multi_psvr_fetcher_thread_num_per_store * _store_count;
        auto cur_n = IncOrDecSingleThreadNum(_thread_num, cfg_n, _thread_pool,
            [this](Context* ctx) {
                Schedule(ctx TRACE_FILE_LINE_CC);
            });

        LOG_IF(NOTICE, cfg_n != cur_n) << "fetcher thread num per store changed,"
            << " old:[" << (cur_n / _store_count)
            << "] new:[" << (cfg_n / _store_count)
            << "]";
        ret = cfg_n != cur_n;
    }
    {
        uint32_t cfg_n = FLAGS_multi_psvr_append_recover_thread_num_pre_store * _store_count;
        auto cur_n = IncOrDecSingleThreadNum(_append_thread_num, cfg_n, _append_recover_thread_pool,
            [this](Context* ctx) {
                Schedule(ctx TRACE_FILE_LINE_CC);
            });

        LOG_IF(NOTICE, cfg_n != cur_n) << "fetcher append thread num per store changed,"
            << " old:[" << (cur_n / _store_count)
            << "] new:[" << (cfg_n / _store_count)
            << "]";
        ret = ret || cfg_n != cur_n;
    }
    return ret;
}

void Fetcher::SetCtxClientId(Context* ctx) {
    if (ctx->fix_client_id > -1) {
        ctx->client_id = ctx->fix_client_id;
        return;
    }
    const auto thread_num = is_recovery_action(ctx)
        ? _append_thread_num : _thread_num;
    if (auto cluster = ctx->cluster.lock(); cluster) {
        ctx->client_id = cluster->hash_val() % thread_num + ctx->shift_client_id;
        return;
    }
    if (auto segment = ctx->segment.lock(); segment) {
        ctx->client_id = segment->hash_val() % thread_num + ctx->shift_client_id;
        return;
    }
    static std::atomic<uint32_t> round_robin_id = 0;
    auto idx = round_robin_id.fetch_add(1, std::memory_order_relaxed);
    ctx->client_id = idx % thread_num + ctx->shift_client_id;
}

void Fetcher::Dispatch(SegmentPtr segment TRACE_FILE_LINE_DC, bool force_single) {
    if (FLAGS_psvr_enable_append_file && FLAGS_psvr_dblwr_max_page_num > 0) {
        define_control_or_return_invalid(nullptr);
        control->gc()->DumpDblwrBuf(segment);
    }

    if (!segment->AppendRecoverFetchFinish()) {
        LOG(NOTICE) << segment << " start append recover,"
            << " start_lsn:[" << segment->fetch_lsn() << "]";
        auto ctx = new Context(Action::kAppendRecover, segment);
        ctx->log_id = get_log_id();
        Schedule(ctx TRACE_FILE_LINE_ARG_CC, millisecond2microseconds(1ul));
        return;
    }

    if (!segment->cluster()->use_batch_fetch() || force_single) {
        // each segment only one ctx
        LOG(NOTICE) << segment << " start fetch,"
            << " start_lsn:[" << segment->fetch_lsn() << "]"
            << TRACE_FILE_LINE_LOG_STR;
        auto ctx = new Context(Action::kGetLogService, segment);
        ctx->log_id = get_log_id();
        ctx->shift_client_id = kExtraThreadNum;
        ctx->get_log_ctx.request.set_segment_id(segment->segment_id());
        ctx->get_log_ctx.request.set_cluster_id(segment->cluster_id());
        if (!force_single) {
            segment->set_fetch_ctx(ctx);
        }
        Schedule(ctx TRACE_FILE_LINE_ARG_CC, millisecond2microseconds(1ul));
    } else {
        int32_t batch_idx = -1;
        uint64_t batch_version = 0;
        segment_set_stage_info_with_action(segment, pspb::FetchStageSchedule, Action::kBatchGetLogService);
        if (_batch_manager->Add(segment, &batch_idx, &batch_version)) {
            LOG(NOTICE) << "dispath cluster fetch task,"
                << " id:[" << segment->cluster()->name()
                << "] batch_idx:[" << batch_idx
                << "] batch_version:[" << batch_version
                << "] start_lsn:[" << segment->fetch_lsn()
                << "]" << TRACE_FILE_LINE_LOG_STR;
            auto ctx = new Context(Action::kBatchGetLogService);
            ctx->log_id = get_log_id();
            ctx->shift_client_id = kExtraThreadNum;
            ctx->cluster = segment->cluster();
            ctx->cluster_id = segment->cluster_id();
            ctx->batch_idx = batch_idx;
            ctx->batch_version = batch_version;
            Schedule(ctx TRACE_FILE_LINE_ARG_CC, millisecond2microseconds(1ul));
        }
        segment->set_fetch_batch_idx(batch_idx);
        LOG(NOTICE) << segment << " use batch fetch,"
            << " batch_idx:[" << batch_idx
            << "] batch_version:[" << batch_version
            << "] start_lsn:[" << segment->fetch_lsn()
            << "]" << TRACE_FILE_LINE_LOG_STR;
    }
}

void Fetcher::Wakeup(SegmentPtr segment) {
    if (segment->wakeup_fetch()) {
        return;
    }
    Context* ctx = static_cast<Context*>(segment->fetch_ctx());
    if (ctx && GetThreadPool(ctx)->Cancel(ctx)) {
        Execute(ctx);
    }
}

const Fetcher::ThreadPoolTypePtr& Fetcher::GetThreadPool(Context* ctx) const {
    if (is_recovery_action(ctx)) {
        return _append_recover_thread_pool;
    }
    return _thread_pool;
}

bool Fetcher::Execute(Context* ctx) {
    SegmentPtr segment = ctx->segment.lock();
    segment_set_stage_info_with_action(segment, pspb::FetchStageSchedule, ctx->action);
    if (!GetThreadPool(ctx)->EmergentExecute(ctx)) {
        if (_stopped) {
            std::unique_ptr<Context> ctx_guard(ctx);
        } else {
            psvr_terminate();
        }
        return false;
    }
    return true;
}

void Fetcher::Schedule(Context* ctx TRACE_FILE_LINE_DC, uint64_t delay_us, bool is_retry) {
    PSVR_LOG_CTX(TRACE, ctx) << "ctx action:[" << static_cast<uint32_t>(ctx->action) << "," << action2str(ctx->action)
        << "] retry_times:[" << ctx->retry_times
        << "] ctx:[" << ctx
        << "]" << TRACE_FILE_LINE_LOG_STR;
    define_control_or_return_invalid(ctx);
    SetCtxClientId(ctx);
    if (is_retry) {
        ++ctx->retry_times;
    }

    SegmentPtr segment = ctx->segment.lock();
    segment_set_stage_info_with_action(segment, pspb::FetchStageSchedule, ctx->action);

    if (delay_us == 0) {
        if (GetThreadPool(ctx)->Execute(ctx)) {
            return;
        }
    } else {
        if (segment) {
            segment->clear_wakeup_fetch();
        }
        if (GetThreadPool(ctx)->Schedule(ctx, delay_us)) {
            return;
        }
    }

    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }

    PSVR_LOG_CTX(ERROR, ctx) << "dispatch segment to fetcher pool failed,"
        << TRACE_FILE_LINE_LOG_STR;
    psvr_terminate();
}

void Fetcher::OnCompletion(Context* ctx) {
    PSVR_LOG_CTX(TRACE, ctx) << "ctx action:[" << static_cast<uint32_t>(ctx->action) << "," << action2str(ctx->action)
        << "] retry_times:[" << ctx->retry_times
        << "] ctx:[" << ctx
        << "]";
    if (BAIDU_UNLIKELY(_stopped)) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }
    SegmentPtr segment = ctx->segment.lock();
    segment_set_stage_info_with_action(segment, pspb::FetchStageDo, ctx->action);
    switch(ctx->action) {
    case Action::kGetLogService:
        return GetLogService(ctx);
    case Action::kDisposeLogService:
        return DisposeLogService(ctx);
    case Action::kFetchRedoLog:
        return FetchLogBlock(ctx);
    case Action::kDisposeLogBlock:
        return DisposeLogBlock(ctx);
    case Action::kBatchMonitor:
        return BatchMonitor(ctx);
    case Action::kBatchGetLogService:
        return BatchGetLogService(ctx);
    case Action::kBatchDisposeLogService:
        return BatchDisposeLogService(ctx);
    case Action::kBatchFetchRedoLog:
        return BatchFetchRedoLog(ctx);
    case Action::kBatchDisposeLogBlock:
        return BatchDisposeLogBlock(ctx);
    case Action::kCheckReopenSegment:
        return CheckReopenSegment(ctx);
    case Action::kPreReopenSegment:
        return PreReopenSegment(ctx);
    case Action::kReopenSegment:
        return ReopenSegment(ctx);
    case Action::kRestartSegment:
        return RestartSegment(ctx);
    case Action::kAppendRecover:
        return AppendRecover(ctx);
    case Action::kGetRedoRecLog:
        return GetRedoRecLog(ctx);
    case Action::kDisposeRedoRecLog:
        return DisposeRedoRecLog(ctx);
    default:
        PSVR_ASSERT(false);
    }
}

void Fetcher::DoReopenSegment(SegmentPtr segment TRACE_FILE_LINE_DC,
        const pspb::ReopenSegmentRequest* request,
        pspb::ReopenSegmentResponse* response,
        ggpb::Closure* done) {
    if (!segment->GetPreDisable()) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::ERROR, "get lock fail");
        LOG(WARNING) << segment << " reopen to get pre disable lock failed, maybe in reopening";
        return;
    }

    const auto force = request->has_force() && request->force();
    const auto not_recover = request->has_not_recover() && request->not_recover();

    if (force) {
        if (!segment->PreDisable()) {
            baidu::rpc::ClosureGuard done_guard(done);
            set_rpc_status(response->mutable_status(), pspb::Status::ERROR, "predisable fail");
            LOG(WARNING) << segment << " reopen pre disable failed";
            segment->PutPreDisable();
            return;
        }
    }

    set_rpc_status(response->mutable_status(), pspb::Status::RPC_ERROR, "wait result");
    LOG(WARNING) << segment << " start to reopen,"
        << " force:[" << force
        << "] not_recover:[" << not_recover
        << "]";
    auto ctx = new Context(
            force ? Action::kPreReopenSegment : Action::kCheckReopenSegment,
            segment);
    ctx->fix_client_id = 0;
    ctx->reopen_force = force;
    ctx->reopen_not_recover = not_recover;
    ctx->reopen_response = response;
    ctx->reopen_done = done;
    Schedule(ctx TRACE_FILE_LINE_ARG_CC);
}

void Fetcher::DoReopenSegment(SegmentPtr segment TRACE_FILE_LINE_DC,
        bool force, bool not_recover) {
    if (!segment->GetPreDisable()) {
        LOG(WARNING) << segment << " reopen to get pre disable lock failed, maybe in reopening";
        return;
    }

    if (force) {
        if (!segment->PreDisable()) {
            LOG(WARNING) << segment << " reopen pre disable failed";
            segment->PutPreDisable();
            return;
        }
    }

    LOG(WARNING) << segment << " start to reopen,"
        << " force:[" << force
        << "] not_recover:[" << not_recover
        << "]";
    auto ctx = new Context(
            force ? Action::kPreReopenSegment : Action::kCheckReopenSegment,
            segment);
    ctx->fix_client_id = 0;
    ctx->reopen_force = force;
    ctx->reopen_not_recover = not_recover;
    Schedule(ctx TRACE_FILE_LINE_ARG_CC);
}

void Fetcher::BatchMonitor(Context* ctx) {
    define_control_or_return_invalid(ctx);
    static int32_t s_last_segment_count = -1;
    if (s_last_segment_count == -1) {
        s_last_segment_count = FLAGS_psvr_fetch_batch_segment_count;
    } else if (s_last_segment_count != FLAGS_psvr_fetch_batch_segment_count) {
        LOG(NOTICE) << "fetch batch count changed,"
            << " old:[" << s_last_segment_count
            << "] new:[" << FLAGS_psvr_fetch_batch_segment_count
            << "]";
        s_last_segment_count = FLAGS_psvr_fetch_batch_segment_count;
        _batch_manager->BuildTrims();
    }

    std::string cluster_id {};
    uint64_t version = 0;
    if (_batch_manager->TrimFirst(&cluster_id, &version)) {
        ClusterPtr cluster = control->segment_manager()->GetCluster(cluster_id);
        if (cluster) {
            uint64_t new_version = 0;
            int32_t size = _batch_manager->TrimBatch(cluster_id, version, &new_version);
            for (int32_t i = 0; i < size; ++i) {
                LOG(NOTICE) << "dispath cluster fetch task,"
                    << " id:[" << cluster->name()
                    << "] batch_idx:[" << i
                    << "] batch_version:[" << new_version
                    << "]";
                auto sub_ctx = new Context(Action::kBatchGetLogService);
                sub_ctx->log_id = get_log_id();
                sub_ctx->shift_client_id = kExtraThreadNum;
                sub_ctx->cluster = cluster;
                sub_ctx->cluster_id = cluster->name();
                sub_ctx->batch_idx = i;
                sub_ctx->batch_version = new_version;
                Schedule(sub_ctx TRACE_FILE_LINE_CC);
            }
            LOG(NOTICE) << "fetch trim cluster,"
                << " id:[" << cluster->name()
                << "] size:[" << size
                << "] version:[" << version
                << "] new_version:[" << new_version
                << "]";
        }
        _batch_manager->TrimPop(cluster_id, version);
    }

    Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(FLAGS_psvr_fetch_batch_monitor_s));
}

void Fetcher::StartFetchRedoLog(Context* ctx,
        const std::vector<gaiadb::common::PeerZone>& new_nodes, uint32_t idx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    if (new_nodes.empty()) {
        PSVR_LOG_CTX(WARNING, ctx) << segment << " failed to get log service addr,"
            << " size:[" << new_nodes.size()
            << "]";
        _stat_fetch_error_count << 1;
        // psm not found log service, we wait it
        ctx->action = Action::kGetLogService;
        Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        return;
    }

    // reset context for start fetch logblock
    auto& get_log_ctx = ctx->get_log_ctx;
    get_log_ctx.idx = idx % new_nodes.size();
    get_log_ctx.servers.clear();
    ctx->has_zone = control->dbd_zone()->has_zone();
    ctx->zone_count = 0;
    ctx->last_zone_version = control->dbd_zone()->version();

    std::string region;
    std::string available_zone;
    if (ctx->has_zone) {
        control->dbd_zone()->Get(&region, &available_zone);
    }

    for (auto& node : new_nodes) {
        get_log_ctx.servers.emplace_back(node);
        if (ctx->has_zone && region == node.region
                && available_zone == node.available_zone) {
            ++ctx->zone_count;
        }
    }

    if (ctx->zone_count && !region.empty() && !available_zone.empty()) {
        gaiadb::common::sort_peer_zone_vector(get_log_ctx.servers, region, available_zone);
    }

    ctx->ls_nodes_status.Reset(get_log_ctx.servers.size());
    // start to fetch log block
    ctx->enable_server_push = false;
    ctx->retry_times = 0;
    ctx->continuous_empty_fetch_count = 0;
    ctx->node_fetch_count = 0;
    ctx->node_fetch_begin_time = 0;
    ctx->abnormal_fetch_begin_time = 0;
    ctx->action = Action::kFetchRedoLog;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Fetcher::GetLogService(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    PsmInfoPtr psm_info = segment->GetPsmInfo();
    std::shared_ptr<LogServices> log_services = segment->cluster()->log_services();
    std::vector<gaiadb::common::PeerZone> new_nodes;
    uint64_t version = ctx->log_service_nodes_version;
    if (log_services->Get(&new_nodes, &version)
            && !new_nodes.empty()
            && version != ctx->log_service_nodes_version) {
        // Get logservice nodes is successful and the data version is updated by other
        ctx->log_service_nodes_version = version;
        StartFetchRedoLog(ctx, new_nodes, log_services->get_nodes_start_idx());
        return;
    }
    LOG(TRACE) << segment << " get log servers from cache fail,"
        << " new_nodes_size:[" << new_nodes.size()
        << "] version:[" << version
        << "] log_service_nodes_version:[" << ctx->log_service_nodes_version
        << "]";
    if (!log_services->GetRefreshLock(segment)) {
        if (new_nodes.empty()) {
            PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << segment << " not get refresh ls nodes lock, retry it";
            Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        } else {
            ctx->log_service_nodes_version = version;
            StartFetchRedoLog(ctx, new_nodes, log_services->get_nodes_start_idx());
        }
        return;
    }

    std::vector<base::EndPoint> nodes;
    if (!psm_info->GetOrRefreshNodes(&nodes)) {
        PSVR_LOG_CTX(WARNING, ctx) << segment << " not found manager nodes, retry it";
        _stat_fetch_error_count << 1;
        log_services->PutRefreshLock();
        control->RefreshPsmInfo(psm_info);
        Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        return;
    }

    auto* rpc_ctx = new RpcBatchGetLogServiceCtx;
    rpc_ctx->log_id = ctx->log_id;
    rpc_ctx->servers = std::move(nodes);
    rpc_ctx->request.set_log_id(ctx->log_id);

    segment_set_stage_info_with_action(segment, pspb::FetchStageRPC, ctx->action);
    auto closure = brpc::NewCallback(this, &Fetcher::OnGetLogService, ctx, rpc_ctx);
    _client->ListLogService(rpc_ctx, closure);
}

void Fetcher::OnGetLogService(Context* ctx, RpcBatchGetLogServiceCtx* rpc_ctx) {
    define_control_or_return_invalid(ctx);
    ctx->rpc_get_log_service_ctx.reset(rpc_ctx);
    ctx->action = Action::kDisposeLogService;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Fetcher::DisposeLogService(Context* ctx) {
    RpcBatchGetLogServiceCtx* rpc_ctx = ctx->rpc_get_log_service_ctx.release();
    std::unique_ptr<RpcBatchGetLogServiceCtx> rpc_ctx_guard(rpc_ctx);
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    PsmInfoPtr psm_info = segment->GetPsmInfo();
    std::shared_ptr<LogServices> log_services = segment->cluster()->log_services();
    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        _stat_fetch_error_count << 1;
        if (rpc_ctx->RetryNext()) {
            segment_set_stage_info_with_action(segment, pspb::FetchStageRPC, ctx->action);
            auto closure = brpc::NewCallback(this, &Fetcher::OnGetLogService, ctx, rpc_ctx_guard.release());
            _client->ListLogService(rpc_ctx, closure);
        } else {
            log_services->PutRefreshLock();
            control->RefreshPsmInfo(psm_info);
            ctx->action = Action::kGetLogService;
            Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        }
        return;
    }

    PSVR_LOG_CTX(NOTICE, ctx) << segment << " get log service addr ok,"
        << rpc_ctx;
    psm_info->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());
    const gaiapb::LogServiceBatchGetResponse& response = rpc_ctx->response;
    std::vector<gaiadb::common::PeerZone> new_nodes;
    for (int32_t i = 0; i < response.log_services_size(); ++i) {
        const auto& log_service = response.log_services(i);
        base::EndPoint ep;
        base::str2endpoint(log_service.addr().c_str(), &ep);
        new_nodes.emplace_back(ep, log_service.zone().region(), log_service.zone().available_zone());
    }
    if (!new_nodes.empty()) {
        set_segment_cluster_statistic(segment, stat_get_log_service_count, 1);
        log_services->Set(new_nodes, &ctx->log_service_nodes_version);
    }
    log_services->PutRefreshLock();
    StartFetchRedoLog(ctx, new_nodes, log_services->get_nodes_start_idx());
}

void Fetcher::FetchLogBlock(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);
    do {
        // if zone meta changed, refresh log service
        if (ctx->last_zone_version != control->dbd_zone()->version()) {
            LOG_EVERY_N(NOTICE, 8) << segment << " last zone version changed";
            break;
        }

        const size_t ls_peers_size = ctx->get_log_ctx.servers.size();
        if (ls_peers_size != FLAGS_psvr_single_az_raft_replica_size
                && ls_peers_size != FLAGS_psvr_with_backup_az_raft_replica_size
                && ctx->abnormal_fetch_begin_time == 0) {
            ctx->abnormal_fetch_begin_time = base::cpuwide_time_us()
                + (base::RandUint64() % FLAGS_psvr_fetch_abnormal_max_time_us);
            LOG_EVERY_N(NOTICE, 16) << segment << " miss log service nodes size,"
                << " ls_peers_size:[" << ls_peers_size
                << "]";
        }

        if (ctx->abnormal_fetch_begin_time > 0
                && base::cpuwide_time_us() - ctx->abnormal_fetch_begin_time >= FLAGS_psvr_fetch_abnormal_max_time_us) {
            LOG_EVERY_N(NOTICE, 16) << segment << " fetch log abnormal,"
                << " ls_peers_size:[" << ls_peers_size
                << "] abnormal_fetch_begin_time:[" << ctx->abnormal_fetch_begin_time
                << "]";
            break;
        }

        segment->set_last_fetch_time(base::cpuwide_time_us());

        auto& request = ctx->get_log_ctx.request;
        uint64_t log_id = get_log_id();
        const auto& log_service_peer = ctx->get_log_ctx.current_server();

        ctx->get_log_ctx.timeout_ms = gaiadb::common::FLAGS_gaia_call_timeout_ms;
        request.set_enable_server_push(false);
        if (FLAGS_psvr_fetch_enable_server_push
                && ctx->enable_server_push) {
            request.set_enable_server_push(true);
            request.set_server_push_timeout_ms(FLAGS_psvr_fetch_server_push_timeout_ms);
            ctx->get_log_ctx.timeout_ms = FLAGS_psvr_fetch_server_push_timeout_ms + 2000;    // add extra
        }

        if (log_service_peer.has_zone() && control->dbd_zone()->has_zone()) {
            request.mutable_zone()->set_region(log_service_peer.region);
            request.mutable_zone()->set_available_zone(log_service_peer.available_zone);
        } else {
            request.clear_zone();
        }

        request.set_fetch_lsn(segment->fetch_lsn());
        request.set_log_id(log_id);
        request.set_replica_id(segment->replica_id());
        request.set_parse_lsn(segment->parse_lsn());
        request.set_checkpoint_lsn(segment->gc_lsn());

        ctx->get_log_ctx.status.Reset(RpcCode::kCntlFailed, "init msg");
        ctx->get_log_ctx.response.Clear();
        ctx->stat_timer.reset();
        if (ctx->node_fetch_begin_time == 0) {
            ctx->node_fetch_begin_time = base::cpuwide_time_us()
                + (base::RandUint64() % FLAGS_psvr_fetch_max_time_us);
        }

        segment_set_stage_info_with_action(segment, pspb::FetchStageRPC, ctx->action);
        ctx->cntl.Reset();
        ctx->get_log_ctx.controller = &ctx->cntl;
        ggpb::Closure* closure = brpc::NewCallback(this, &Fetcher::OnFetchLogBlock, ctx);
        _client->GetLog(&ctx->get_log_ctx, closure);
        return;
    } while (0);

    ctx->retry_times = 0;
    ctx->action = Action::kGetLogService;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Fetcher::OnFetchLogBlock(Context* ctx) {
    TimerGuard lat_timer(_stat_fetch_rpc_callback_cost_lat);
    define_control_or_return_invalid(ctx);
    ctx->callback_time = base::cpuwide_time_us();
    // transter ctx to fetcher threads, release bthread
    ctx->action = Action::kDisposeLogBlock;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

bool Fetcher::CheckQuota(SegmentPtr segment, ClusterPtr cluster,
        bool is_recover_redo, int64_t quota_size, uint32_t& quota_flags) {
    do {
        if (segment->EnableQuota(quota_size)) {
            if (!segment->GetQuota(quota_size)) {
                segment->set_fetch_quota_state(pspb::QuotaLimitBySeg);
                _stat_fetch_quota_fail_seg_count << 1;
                LOG_EVERY_N(WARNING, 1024) << segment << " fetch log block get quota failed,"
                    << " quota_size:[" << quota_size
                    << "] parser_unfinished_tasks_count:[" << segment->fetch_log_block_queue().Size()
                    << "] gc_unfinished_tasks_count:[" << segment->parse_log_block_queue().Size()
                    << "]";
                break;
            }
            quota_flags |= kQuotaSegment;
        }

        if (cluster->EnableQuota(quota_size, is_recover_redo)) {
            if (!cluster->GetQuota(quota_size, is_recover_redo)) {
                segment->set_fetch_quota_state(pspb::QuotaLimitByCluster);
                _stat_fetch_quota_fail_cluster_count << 1;
                LOG_EVERY_N(WARNING, 128) << segment << " fetch log block get cluster quota failed,"
                    << " quota_size:[" << quota_size
                    << "] parser_unfinished_tasks_count:[" << segment->fetch_log_block_queue().Size()
                    << "] gc_unfinished_tasks_count:[" << segment->parse_log_block_queue().Size()
                    << "]";
                break;
            }
            quota_flags |= kQuotaCluster;
        }
        if (EnableQuota(quota_size, is_recover_redo)) {
            if (!GetQuota(quota_size, is_recover_redo)) {
                segment->set_fetch_quota_state(pspb::QuotaLimitByGlobal);
                _stat_fetch_quota_fail_global_count << 1;
                LOG(WARNING) << segment << " fetch log block get global quota failed,"
                    << " quota_size:[" << quota_size
                    << "] parser_unfinished_tasks_count:[" << segment->fetch_log_block_queue().Size()
                    << "] gc_unfinished_tasks_count:[" << segment->parse_log_block_queue().Size()
                    << "]";
                break;
            }
            quota_flags |= kQuotaGlobal;
        }
        segment->set_fetch_quota_state(pspb::QuotaOk);
        return true;
    } while (0);

    if (quota_flags & kQuotaSegment) {
        segment->PutQuota(quota_size);
    }
    if (quota_flags & kQuotaCluster) {
        cluster->PutQuota(quota_size, is_recover_redo);
    }
    return false;
}

void Fetcher::DisposeLogBlock(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    TimePointGuard tp_guard(ctx->callback_time, FLAGS_psvr_enable_fetch_annotate);
    ADD_TRACE_TP(tp_guard.tp(), "wait");

    TimerGuard lat_timer(_stat_fetch_rpc_disposer_wait_lat, ctx->callback_time);
    auto cluster = segment->cluster();
    uint64_t rsp_last_lsn = 0;
    bool fetch_log_empty = false;
    bool fetch_error = true;
    bool limit_quota = false;
    auto& get_log_ctx = ctx->get_log_ctx;
    ctx->get_log_ctx.controller = nullptr;
    do {
        const auto& log_service_peer = get_log_ctx.current_server();
        auto& request = get_log_ctx.request;

        if (!get_log_ctx.status.IsOk()) {
            if (ctx->cntl.ErrorCode() == lspb::GIT_INVALID_LSN
                    && FLAGS_psvr_enable_append_file) {
                ctx->action = Action::kGetRedoRecLog;
                Schedule(ctx TRACE_FILE_LINE_CC);
                return;
            }
            PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << segment << " fetch log failed,"
                << " log_id:[" << request.log_id()
                << "] addr:[" << log_service_peer
                << "] fetch_lsn:[" << request.fetch_lsn()
                << "] lowest_ps_lsn:[" << segment->GetClusterPsLowestLsn()
                << "] error:[" << ctx->cntl.ErrorText()
                << "]";
            ctx->ls_nodes_status.SetIdx(get_log_ctx.idx);
            if (request.fetch_lsn() < segment->GetClusterPsLowestLsn()) {
                segment->set_is_invalid_start_lsn(true);
                if (FLAGS_multi_psvr_enable_reopen_segment) {
                    DoReopenSegment(segment TRACE_FILE_LINE_CC);
                }
            }
            break;
        }

        ctx->ls_nodes_status.ClearIdx(get_log_ctx.idx);
        auto& response = get_log_ctx.response;
        rsp_last_lsn = response.last_lsn();
        // update cn_lowest_lsn
        cluster->set_cn_lowest_lsn(response.cn_lowest_lsn());
        cluster->set_cn_lowest_gc_lsn(response.cn_lowest_gc_lsn());
        cluster->set_ps_lowest_gc_lsn(response.ps_lowest_gc_lsn());
        if (response.has_vdl()) {
            cluster->set_max_get_log_lsn(response.dispatch_lsn());
            segment->set_ls_lsn(response.vdl(), response.write_lsn(),
                    response.parse_lsn(), response.dispatch_lsn());
        } else {
            cluster->set_max_get_log_lsn(rsp_last_lsn);
            segment->set_is_invalid_start_lsn(false);
        }
        // if mismatch zone, inc fail times, dont refresh ls ASAP
        if (response.has_refresh_zone() && response.refresh_zone()
                && control->dbd_zone()->has_zone()
                && response.has_zone()) {
            LOG_EVERY_SECOND(TRACE) << segment << " mismatch zone from ls";
        }

        uint32_t quota_flags = 0;
        size_t quota_size = 0;
        const uint32_t rsp_total_len = response.total_len();
        const uint32_t rsp_data_len = response.data_returned().size();

        ctx->enable_server_push = false;
        if (response.has_enable_server_push() && response.enable_server_push()) {
            ctx->enable_server_push = true;
        }
        if (request.enable_server_push()) {
            _stat_fetch_by_server_push_qps << 1;
        }

        ADD_TRACE_TP(tp_guard.tp(), "pre_check");

#define FETCH_LOG_COMMON_STR \
    << " log_id:[" << request.log_id() \
    << "] addr:[" << log_service_peer   \
    << "] fetch_lsn:[" << request.fetch_lsn() \
    << "] last_lsn:[" << rsp_last_lsn \
    << "] record_num:[" << response.record_num() \
    << "] data_len:[" << rsp_total_len << ", " << rsp_data_len \
    << "] has_zone:[" << ctx->has_zone  \
    << "] zone_count:[" << ctx->zone_count \
    << "]"

        if (response.record_num() < 1) {
            if (rsp_total_len != 0) { // No more data, check total_len for safe
                PSVR_LOG_CTX(FATAL, ctx) << segment << " rsp data length invalid,"
                    FETCH_LOG_COMMON_STR;
                break;
            }
            if (segment->fetch_lsn() >= rsp_last_lsn) {
                PSVR_LOG_EVERY_SECOND_CTX(NOTICE, ctx) << segment << " fetch empty,"
                    FETCH_LOG_COMMON_STR;

                LOG(TRACE) << segment << " fetch empty,"
                    FETCH_LOG_COMMON_STR;

                fetch_error = false;
                fetch_log_empty = true;
                break;
            } // else: Some redo logs that do not belong to me, just push my fetch lsn!
            ADD_TRACE_TP(tp_guard.tp(), "empty_check");
        } else {
            if (segment->fetch_lsn() >= rsp_last_lsn) {
                LOG(FATAL) << segment << " rsp last lsn invalid,"
                    FETCH_LOG_COMMON_STR;
                break;
            }
            if (rsp_total_len != response.data_returned().size()) {
                LOG(FATAL) << segment << " rsp data size invalid,"
                    FETCH_LOG_COMMON_STR;
                break;
            }
            const auto* log_block_data = reinterpret_cast<const gaia_apply::byte*>(&response.data_returned()[0]);
            const uint32_t checksum = gaiadb::common::ut_crc32(log_block_data, rsp_total_len);
            if (checksum != response.data_checksum()) {
                LOG_EVERY_N(ERROR, 128) << segment << " log block checksum error,"
                    FETCH_LOG_COMMON_STR
                    << " data_crc:[" << checksum
                    << "] rsp_crc:[" << response.data_checksum()
                    << "]";
                break;
            }
            quota_size = calc_log_block_quota_size(rsp_total_len, response.record_num());
            if (!CheckQuota(segment, cluster, false, quota_size, quota_flags)) {
                limit_quota = true;
                fetch_error = false;
                break;
            }
            ADD_TRACE_TP(tp_guard.tp(), "non_empty_check");
        }

        fetch_error = false;
        PSVR_LOG_EVERY_SECOND_CTX(NOTICE, ctx) << segment << " add log block to fetcher list,"
            FETCH_LOG_COMMON_STR;

        l_stat_log_block_used_count << 1;
        set_cluster_stat(cluster, stat_log_block_size, 1);
        LogBlockDeleter log_block_deleter(shared_this(), cluster, segment, quota_flags);
        LogBlockPtr log_block(new LogBlock(request.log_id(), request.fetch_lsn(), rsp_last_lsn), log_block_deleter);
        log_block->fetch_from = log_service_peer.addr;
        log_block->quota_size = quota_size;
        l_stat_log_block_used_mem_byte << quota_size;
        if (rsp_total_len > 0) {
            bool ret = log_block->set_data(base::Slice(response.data_returned()),
                    response.record_num(), response.data_checksum());
            if (!ret) {
                PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << segment << " alloc memory failed on fetching,"
                    FETCH_LOG_COMMON_STR;
                break;
            }
        }

        TP_INIT_IF(log_block->tp, FLAGS_psvr_enable_logblock_annotate);
        // add to segment list and tell parser
        if (!segment->AddFetchLogBlock(log_block)) {
            PSVR_LOG_CTX(ERROR, ctx) << segment << " add logblock failed,"
                FETCH_LOG_COMMON_STR;
            break;
        }

        if (ctx->continuous_empty_fetch_count > 0) {
            ctx->continuous_empty_fetch_count = 0;
        }

        control->parser()->Dispatch(segment TRACE_FILE_LINE_CC, log_block->end_lsn);

        _stat_fetch_log_buf_size << rsp_total_len;
        _stat_fetch_log_lsn_size_kb << ToKB(log_block->lsn_length());
    } while (0);

#define FETCH_SWITCH_NEXT()  \
do { \
    _stat_fetch_size_per_node << ctx->node_fetch_count; \
    set_cluster_ls_stat(cluster, get_log_ctx.idx, stat_fetch_switch_count, 1);  \
    ctx->enable_server_push = false; \
    ctx->node_fetch_count = 0;   \
    ctx->node_fetch_begin_time = 0; \
    ctx->continuous_empty_fetch_count = 0; \
    get_log_ctx.idx = (get_log_ctx.idx + 1) % get_log_ctx.servers.size(); \
    if (ctx->fetch_from_backup_zone(get_log_ctx.idx) \
            && ctx->abnormal_fetch_begin_time == 0) {  \
        get_log_ctx.idx = 0;  \
    } \
} while (0)

    set_cluster_ls_stat(cluster, get_log_ctx.idx, stat_fetch_rpc_lat, get_log_ctx.latency_us);
    ++ctx->node_fetch_count;
    if (BAIDU_UNLIKELY(fetch_error)) {
        _stat_fetch_error_count << 1;
        if (ctx->abnormal_fetch_begin_time == 0) {
            ctx->abnormal_fetch_begin_time = base::cpuwide_time_us()
                + (base::RandUint64() % FLAGS_psvr_fetch_abnormal_max_time_us);
        }
        FETCH_SWITCH_NEXT();
    } else {
        int64_t exec_time = base::cpuwide_time_us() - ctx->node_fetch_begin_time;
        if ((ctx->fetch_from_backup_zone(get_log_ctx.idx) && exec_time >= FLAGS_psvr_fetch_max_time_us_from_backup)
                || exec_time >= FLAGS_psvr_fetch_max_time_us) {
            FETCH_SWITCH_NEXT();
        } else if (fetch_log_empty
                && rsp_last_lsn < cluster->max_get_log_lsn()
                && (++ctx->continuous_empty_fetch_count >= FLAGS_psvr_fetch_empty_consecutive_time
#define LS_MAX_LAG_LSN 500lu
                    || rsp_last_lsn + MBToByte(LS_MAX_LAG_LSN) <= cluster->max_get_log_lsn())) {
            FETCH_SWITCH_NEXT();
        }

        _stat_fetch_task_lat << ctx->stat_timer.u_elapsed();
        _stat_fetch_rpc_lat << get_log_ctx.latency_us;
    }
#undef LS_MAX_LAG_LSN
#undef FETCH_SWITCH_NEXT

    ADD_TRACE_TP(tp_guard.tp(), "done");
    if (FLAGS_psvr_fetch_long_query_time_us > 0
            && TP_ELAPSED(tp_guard.tp(), FLAGS_psvr_fetch_long_query_time_us)) {
        LOG(NOTICE) << segment << " slow fetch request," << tp_guard.tp();
    }

    if (fetch_log_empty) {
        _stat_fetch_empty_qps << 1;
    }

    // reset action to fetch next log block
    ctx->action = Action::kFetchRedoLog;
    if (limit_quota || ctx->ls_nodes_status.IsFull()) {
        Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
    } else {
        ctx->retry_times = 0;
        Schedule(ctx TRACE_FILE_LINE_CC, fetch_log_empty ? FLAGS_psvr_fetch_delay_empty :  FLAGS_psvr_fetch_delay_non_empty);
    }
}

void Fetcher::OnGetPeersEvent(Context *ctx) {
    ctx->fetch_redo_rec_err_num = 0;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Fetcher::GetRedoRecLog(Context *ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    if (!ctx->rpc_get_redo_rec_log_ctx) {
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
    }

    auto& rpc_ctx = ctx->rpc_get_redo_rec_log_ctx;
    auto& req = ctx->rpc_get_redo_rec_log_ctx->request;
    auto& rsp = ctx->rpc_get_redo_rec_log_ctx->response;

    if (FLAGS_psvr_fetch_redo_rec_log_timeout_ms > 0) {
        rpc_ctx->timeout_ms = FLAGS_psvr_fetch_redo_rec_log_timeout_ms;
    }

    if (rpc_ctx->servers.empty() || ctx->fetch_redo_rec_err_num) {
        // First fetch keeps the order maintained by _peer_info.replicas, retries
        // shuffle to spread across peers.
        bool ret = segment->GetPeerNodes(&rpc_ctx->servers, !rpc_ctx->servers.empty());
        if (!ret || ctx->fetch_redo_rec_err_num >= FLAGS_psvr_refresh_peers_err_times) {
            if (rpc_ctx->servers.empty()) {
                auto closure = brpc::NewCallback(this, &Fetcher::OnGetPeersEvent, ctx);
                control->parser()->AddGetPeerEvent(segment TRACE_FILE_LINE_CC, closure, &ctx->st);
                return;
            } else {
                control->parser()->AddGetPeerEvent(segment TRACE_FILE_LINE_CC, nullptr, nullptr);
            }
            ctx->fetch_redo_rec_err_num = 0;
        }
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();
        rsp.Clear();
    }


    req.set_cluster_id(segment->cluster_id());
    req.set_segment_id(segment->segment_id());
    req.set_fetch_lsn(segment->fetch_lsn());

    if (rsp.has_next_append_db_block_no()) {
        req.set_append_db_block_no(rsp.next_append_db_block_no());
    }
    if (rsp.has_next_append_db_block_offset()) {
        req.set_append_db_block_offset(rsp.next_append_db_block_offset());
    }

    req.set_last_data_len(ctx->last_data_len);

    segment_set_stage_info_with_action(segment, pspb::FetchStageRPC, ctx->action);
    ggpb::Closure* closure = brpc::NewCallback(this, &Fetcher::OnFetchRedoRecLog, ctx);
    _client->GetRedoRecLog(ctx->rpc_get_redo_rec_log_ctx.get(), closure);
}

void Fetcher::OnFetchRedoRecLog(Context* ctx) {
    define_control_or_return_invalid(ctx);
    // transter ctx to fetcher threads, release bthread
    ctx->action = Action::kDisposeRedoRecLog;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Fetcher::DisposeRedoRecLog(Context *ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    auto& rpc_ctx = ctx->rpc_get_redo_rec_log_ctx;
    auto& req = ctx->rpc_get_redo_rec_log_ctx->request;
    auto& rsp = ctx->rpc_get_redo_rec_log_ctx->response;

#define FETCH_REDO_REC_LOG_COMMON_LOG_STR    \
    << " log_id:[" << rpc_ctx->log_id   \
    << "] idx:[" << rpc_ctx->idx        \
    << "] server:[" << rpc_ctx->current_server()        \
    << "] replicas_num:[" << rpc_ctx->servers.size()    \
    << "] fetch_lsn:[" << segment->fetch_lsn()

    PSVR_LOG_CTX(TRACE, ctx) << segment << " fetch redo rec log rsp info,"
        FETCH_REDO_REC_LOG_COMMON_LOG_STR
        << "] " << rpc_ctx->status
        << rsp.status();

    _stat_fetch_redo_rec_log_lat << rpc_ctx->latency_us;

    ctx->last_data_len = 0;

    bool switch_peer_if_fail = true;
    bool delay_retry = false;
    do {
        if (!rpc_ctx->status.IsOk()) {
            PSVR_LOG_CTX(WARNING, ctx) << segment << " fetch redo rec log rpc failed,"
                FETCH_REDO_REC_LOG_COMMON_LOG_STR
                << "] " << rpc_ctx->status;
            _stat_fetch_redo_rec_log_error_count << 1;
            ++ctx->fetch_redo_rec_err_num;
            segment->SetPeerNodeFailed(rpc_ctx->idx, rpc_ctx->current_server());
            break;
        }

        if (rsp.status().code() != pspb::Status::SUCCESS) {
            _stat_fetch_redo_rec_log_error_count << 1;
            if (rsp.status().code() == pspb::Status::RECOVERY_FINISH) {
                PSVR_LOG_CTX(NOTICE, ctx) << segment << " fetch redo rec log finish,"
                    FETCH_REDO_REC_LOG_COMMON_LOG_STR
                    << "] " << rpc_ctx->status;
                if (segment->fetch_batch_idx() > -1) {
                    std::unique_ptr<Context> ctx_guard(ctx);
                    Dispatch(segment TRACE_FILE_LINE_CC);
                } else {
                    ctx->rpc_get_redo_rec_log_ctx.reset();
                    ctx->action = Action::kFetchRedoLog;
                    Schedule(ctx TRACE_FILE_LINE_CC);
                }
                return;
            }
            if (rsp.status().code() != pspb::Status::LIMIT) {
                if (rsp.status().code() == pspb::Status::NOT_EXISTS) {
                    ++ctx->fetch_redo_rec_err_num;
                    segment->SetPeerNodeFailed(rpc_ctx->idx, rpc_ctx->current_server());
                }
                PSVR_LOG_CTX(WARNING, ctx) << segment << " fetch redo rec log rsp failed,"
                    FETCH_REDO_REC_LOG_COMMON_LOG_STR
                    << "] " << rsp.status();
                rsp.Clear();
            } else {
                PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << segment << " fetch redo rec log rsp failed,"
                    FETCH_REDO_REC_LOG_COMMON_LOG_STR
                    << "] " << rsp.status();
                delay_retry = true;
                switch_peer_if_fail = false;
            }
            break;
        }

        ctx->last_data_len = rsp.data_len();

        // check rsp
        if (rsp.data_len()) {
            const auto* data = reinterpret_cast<const gaia_apply::byte*>(&rsp.data()[0]);
            if (rsp.data_checksum() != gaiadb::common::ut_crc32(data, rsp.data_len())) {
                PSVR_LOG_CTX(WARNING, ctx) << segment << " fetch redo rec log data checksum mismatch,"
                    FETCH_REDO_REC_LOG_COMMON_LOG_STR
                    << "] rsp:[" << rsp.data_checksum()
                    << "] calc:[" << gaiadb::common::ut_crc32(data, rsp.data_len())
                    << "]";
                break;
            }
        }

        if (rsp.key_len()) {
            const auto* data = reinterpret_cast<const gaia_apply::byte*>(&rsp.key()[0]);
            if (rsp.key_checksum() != gaiadb::common::ut_crc32(data, rsp.key_len())) {
                PSVR_LOG_CTX(WARNING, ctx) << segment << " fetch redo rec log key checksum mismatch,"
                    FETCH_REDO_REC_LOG_COMMON_LOG_STR
                    << "] rsp:[" << rsp.key_checksum()
                    << "] calc:[" << gaiadb::common::ut_crc32(data, rsp.key_len())
                    << "]";
                break;
            }
        }

        // ok
        switch_peer_if_fail = false;

        auto cluster = segment->cluster();
        uint32_t quota_flags = 0;
        size_t quota_size = 0;
        if (rsp.data_len()) {
            quota_size = calc_log_block_quota_size(rsp.data_len(), rsp.record_num());
            if (!CheckQuota(segment, cluster, true, quota_size, quota_flags)) {
                delay_retry = true;
                break;
            }
        }

        l_stat_log_block_used_count << 1;
        set_cluster_stat(cluster, stat_log_block_size, 1);
        LogBlockDeleter log_block_deleter(shared_this(), cluster, segment, quota_flags);
        LogBlockPtr log_block(new LogBlock(req.log_id(), req.fetch_lsn(), rsp.last_lsn()), log_block_deleter);
        log_block->fetch_from = rpc_ctx->current_server().addr;
        log_block->quota_size = quota_size;
        l_stat_log_block_used_mem_byte << quota_size;
        if (rsp.data_len() > 0) {
            bool ret = log_block->set_data(base::Slice(rsp.data()),
                    rsp.record_num(), rsp.data_checksum());
            if (!ret) {
                PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << segment << " alloc memory failed on fetching,"
                    FETCH_REDO_REC_LOG_COMMON_LOG_STR
                    << "] data_len:[" << rsp.data_len()
                    << "]";
                break;
            }
        }

        AppendInfo& append_info = log_block->append_info;
        append_info.fno = 0;
        append_info.off = 0;
        append_info.fold_size = rsp.fold_size();

        if (rsp.key_len() > 0) {
            if (!log_block->set_key(base::Slice(rsp.key()))) {
                PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << segment << " alloc memory failed on fetching,"
                    FETCH_REDO_REC_LOG_COMMON_LOG_STR
                    << "] key_len:[" << rsp.key_len()
                    << "]";
                break;
            }
            PSVR_ASSERT(append_info.buf != nullptr);
            auto& offset_cache = log_block->fold_space_page_offset_cache;
            offset_cache.Init(append_info.fold_size, append_info.buf);
            PSVR_ASSERT(offset_cache.is_init());
        }

        log_block->from_append_file = FROM_PEER;
        l_stat_log_block_recover_used_count << 1;
        l_stat_log_block_recover_used_mem_byte << quota_size;

        TP_INIT_IF(log_block->tp, FLAGS_psvr_enable_logblock_annotate);
        // add to segment list and tell parser
        if (!segment->AddFetchLogBlock(log_block)) {
            PSVR_LOG_CTX(ERROR, ctx) << segment << " add logblock failed,"
                FETCH_REDO_REC_LOG_COMMON_LOG_STR;
            break;
        }

        control->parser()->Dispatch(segment TRACE_FILE_LINE_CC, log_block->end_lsn);
        segment->set_is_invalid_start_lsn(false);

        if (FLAGS_psvr_fetch_redo_rec_max_time_s > 0 &&
                ctx->fetch_redo_rec_begin_time + FLAGS_psvr_fetch_redo_rec_max_time_s < base::cpuwide_time_s()) {
            switch_peer_if_fail = true;
        }

        _stat_fetch_log_buf_size << rsp.data_len();
        _stat_fetch_log_lsn_size_kb << ToKB(log_block->lsn_length());

    } while (false);

    // clear big data
    rsp.clear_data();
    rsp.clear_key();

    if (switch_peer_if_fail) {
        rsp.Clear();
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();
        if (!rpc_ctx->RetryNext()) {
            ctx->rpc_get_redo_rec_log_ctx.reset();
            delay_retry = true;
        }
    }

    ctx->action = Action::kGetRedoRecLog;
    if (delay_retry) {
        Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
    } else {
        ctx->retry_times = 0;
        Schedule(ctx TRACE_FILE_LINE_CC);
    }
}

void Fetcher::BatchStartFetchRedoLog(Context* ctx,
        const std::vector<gaiadb::common::PeerZone>& new_nodes, uint32_t idx) {
    define_control_or_return_invalid(ctx);
    define_cluster_or_return_invalid(ctx);

    if (new_nodes.empty()) {
        PSVR_LOG_CTX(WARNING, ctx) << "fail to get cluster log service addr,"
            << " id:[" << cluster->name()
            << "] batch_idx:[" << ctx->batch_idx
            << "] size:[" << new_nodes.size()
            << "]";
        _stat_fetch_error_count << 1;
        // psm not found log service, we wait it
        ctx->action = Action::kBatchGetLogService;
        Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        return;
    }

    // reset context for start fetch logblock
    if (!ctx->batch_get_log_ctx) {
        ctx->batch_get_log_ctx.reset(new RpcBatchGetLogCtx);
    }
    auto& batch_get_log_ctx = ctx->batch_get_log_ctx;
    batch_get_log_ctx->idx = idx % new_nodes.size();
    batch_get_log_ctx->servers.clear();

    ctx->has_zone = control->dbd_zone()->has_zone();
    ctx->zone_count = 0;
    ctx->last_zone_version = control->dbd_zone()->version();

    std::string region;
    std::string available_zone;
    if (ctx->has_zone) {
        control->dbd_zone()->Get(&region, &available_zone);
    }

    for (auto& node : new_nodes) {
        batch_get_log_ctx->servers.emplace_back(node);
        if (ctx->has_zone && region == node.region
                && available_zone == node.available_zone) {
            ++ctx->zone_count;
        }
    }

    if (ctx->zone_count && !region.empty() && !available_zone.empty()) {
        gaiadb::common::sort_peer_zone_vector(batch_get_log_ctx->servers, region, available_zone);
    }

    ctx->ls_nodes_status.Reset(batch_get_log_ctx->servers.size());
    // start to fetch log block
    ctx->enable_server_push = false;
    ctx->retry_times = 0;
    ctx->continuous_empty_fetch_count = 0;
    ctx->node_fetch_count = 0;
    ctx->node_fetch_begin_time = 0;
    ctx->abnormal_fetch_begin_time = 0;
    ctx->action = Action::kBatchFetchRedoLog;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Fetcher::BatchGetLogService(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_cluster_or_return_invalid(ctx);

    std::shared_ptr<LogServices> log_services = cluster->log_services();
    std::vector<gaiadb::common::PeerZone> new_nodes;
    uint64_t version = ctx->log_service_nodes_version;
    if (log_services->Get(&new_nodes, &version)
            && !new_nodes.empty()
            && version != ctx->log_service_nodes_version) {
        // Get logservice nodes is successful and the data version is updated by other
        ctx->log_service_nodes_version = version;
        BatchStartFetchRedoLog(ctx, new_nodes, log_services->get_nodes_start_idx());
        return;
    }

    LOG(TRACE) << "cluster get log servers from cache fail,"
        << " id:[" << cluster->name()
        << "] batch_idx:[" << ctx->batch_idx
        << "] new_nodes_size:[" << new_nodes.size()
        << "] version:[" << version
        << "] log_service_nodes_version:[" << ctx->log_service_nodes_version
        << "]";

    std::list<SegmentWeakPtr> segments;
    uint64_t batch_version = 0;
    int32_t size = _batch_manager->Get(cluster, ctx->batch_idx, &segments, &batch_version);
    if (size < 0 || batch_version != ctx->batch_version) {
        std::unique_ptr<Context> ctx_guard(ctx);
        LOG(WARNING) << "cluster not segments or version changed,"
            << " id:[" << cluster->name()
            << "] batch_idx:[" << ctx->batch_idx
            << "] size:[" << size
            << "] batch_version:[" << batch_version << "," << ctx->batch_version
            << "]";
        return;
    }

    for (auto& weak_seg : segments) {
        auto segment = weak_seg.lock();
        if (!segment) {
            continue;
        }
        PsmInfoPtr psm_info = segment->GetPsmInfo();
        if (!psm_info) {
            continue;
        }
        std::vector<base::EndPoint> nodes;
        if (!psm_info->GetOrRefreshNodes(&nodes)) {
            LOG(NOTICE) << "cluster get psm nodes failed,"
                << " id:" << cluster->name()
                << "] batch_idx:[" << ctx->batch_idx
                << "]";
            control->RefreshPsmInfo(psm_info);
            Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
            return;
        }

        ctx->psm_info = psm_info;

        auto* rpc_ctx = new RpcBatchGetLogServiceCtx;
        rpc_ctx->log_id = ctx->log_id;
        rpc_ctx->servers = std::move(nodes);
        rpc_ctx->request.set_log_id(ctx->log_id);

        auto closure = brpc::NewCallback(this, &Fetcher::OnBatchGetLogService, ctx, rpc_ctx);
        _client->ListLogService(rpc_ctx, closure);
        return;
    }

    if (size == 0) {
        _batch_manager->AddTrimCluster(cluster, ctx->batch_version);
        LOG(NOTICE) << "cluster fetch batch empty,"
            << " id:[" << cluster->name()
            << "] batch_idx:[" << ctx->batch_idx
            << "] batch_version:[" << ctx->batch_version
            << "] size:[" << size
            << "]";
    } else {
        // all failed
        LOG_EVERY_SECOND(WARNING) << "cluster get psm failed,"
            << " id:[" << cluster->name()
            << "] batch_idx:[" << ctx->batch_idx
            << "]";
    }
    Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
}

void Fetcher::OnBatchGetLogService(Context* ctx, RpcBatchGetLogServiceCtx* rpc_ctx) {
    define_control_or_return_invalid(ctx);
    ctx->rpc_get_log_service_ctx.reset(rpc_ctx);
    ctx->action = Action::kBatchDisposeLogService;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Fetcher::BatchDisposeLogService(Context* ctx) {
    RpcBatchGetLogServiceCtx* rpc_ctx = ctx->rpc_get_log_service_ctx.release();
    std::unique_ptr<RpcBatchGetLogServiceCtx> rpc_ctx_guard(rpc_ctx);
    define_control_or_return_invalid(ctx);
    define_cluster_or_return_invalid(ctx);

    PsmInfoPtr psm_info = ctx->psm_info;
    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        _stat_fetch_error_count << 1;
        if (rpc_ctx->RetryNext()) {
            auto closure = brpc::NewCallback(this, &Fetcher::OnBatchGetLogService, ctx, rpc_ctx_guard.release());
            _client->ListLogService(rpc_ctx, closure);
        } else {
            control->RefreshPsmInfo(psm_info);
            ctx->action = Action::kBatchGetLogService;
            Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        }
        return;
    }

    PSVR_LOG_CTX(NOTICE, ctx) << "clsuter get log service addr ok,"
        << " name:[" << cluster->name()
        << "] batch_idx:[" << ctx->batch_idx
        << "]" << rpc_ctx;
    psm_info->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());
    const gaiapb::LogServiceBatchGetResponse& response = rpc_ctx->response;
    std::vector<gaiadb::common::PeerZone> new_nodes;
    for (int32_t i = 0; i < response.log_services_size(); ++i) {
        const auto& log_service = response.log_services(i);
        base::EndPoint ep;
        base::str2endpoint(log_service.addr().c_str(), &ep);
        new_nodes.emplace_back(ep, log_service.zone().region(), log_service.zone().available_zone());
    }

    std::shared_ptr<LogServices> log_services = cluster->log_services();
    if (!new_nodes.empty()) {
        set_cluster_stat(cluster, stat_get_log_service_count, 1);
        log_services->Set(new_nodes, &ctx->log_service_nodes_version);
    }
    // finish get log service ndoes
    ctx->psm_info.reset();
    BatchStartFetchRedoLog(ctx, new_nodes, log_services->get_nodes_start_idx());
}

void Fetcher::BatchFetchRedoLog(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_cluster_or_return_invalid(ctx);

    do {
        // if zone meta changed, refresh log service
        if (ctx->last_zone_version != control->dbd_zone()->version()) {
            LOG_EVERY_N(NOTICE, 8) << "cluster last zone version changed,"
                << " id:[" << cluster->name()
                << "] batch_idx:[" << ctx->batch_idx
                << "]";
            break;
        }

        const size_t ls_peers_size = ctx->batch_get_log_ctx->servers.size();
        if (ls_peers_size != FLAGS_psvr_single_az_raft_replica_size
                && ls_peers_size != FLAGS_psvr_with_backup_az_raft_replica_size
                && ctx->abnormal_fetch_begin_time == 0) {
            ctx->abnormal_fetch_begin_time = base::cpuwide_time_us()
                + (base::RandUint64() % FLAGS_psvr_fetch_abnormal_max_time_us);
            LOG_EVERY_N(NOTICE, 16) << "cluster miss log service nodes size,"
                << " id:[" << cluster->name()
                << "] batch_idx:[" << ctx->batch_idx
                << "] ls_peers_size:[" << ls_peers_size
                << "]";
        }

        if (ctx->abnormal_fetch_begin_time > 0
                && base::cpuwide_time_us() - ctx->abnormal_fetch_begin_time >= FLAGS_psvr_fetch_abnormal_max_time_us) {
            LOG_EVERY_N(NOTICE, 16) << "cluster fetch log abnormal,"
                << " id:[" << cluster->name()
                << "] batch_idx:[" << ctx->batch_idx
                << "] ls_peers_size:[" << ls_peers_size
                << "] abnormal_fetch_begin_time:[" << ctx->abnormal_fetch_begin_time
                << "]";
            break;
        }

        std::list<SegmentWeakPtr> segments;
        uint64_t batch_version = 0;
        int32_t size = _batch_manager->Get(cluster, ctx->batch_idx, &segments, &batch_version);
        if (size < 0 || ctx->batch_version != batch_version) {
            std::unique_ptr<Context> ctx_guard(ctx);
            LOG(WARNING) << "cluster not segments or version changed,"
                << " id:[" << cluster->name()
                << "] batch_idx:[" << ctx->batch_idx
                << "] batch_version:[" << ctx->batch_version << "," << batch_version
                << "] size:[" << size
                << "]";
            return;
        }

        if (size == 0) {
            _batch_manager->AddTrimCluster(cluster, ctx->batch_version);
            LOG(NOTICE) << "cluster fetch batch empty,"
                << " id:[" << cluster->name()
                << "] batch_idx:[" << ctx->batch_idx
                << "] batch_version:[" << ctx->batch_version
                << "] size:[" << size
                << "]";
            break;
        }

        uint64_t log_id = get_log_id();
        auto& request = ctx->batch_get_log_ctx->request;
        request.set_cluster_id(cluster->name());
        request.set_enable_server_push(true);
        request.set_server_push_timeout_ms(FLAGS_psvr_fetch_server_push_timeout_ms);
        request.set_log_id(log_id);
        request.set_max_fetch_lsn(0);
        request.set_min_fetch_lsn(std::numeric_limits<uint64_t>::max());
        // clear segments
        request.clear_segments();
        ctx->batch_segments.clear();
        for (auto& weak_seg : segments) {
            auto segment = weak_seg.lock();
            if (segment_is_valid_exclude(segment, fSegmentIsDisable)) {
                segment->set_last_fetch_time(base::cpuwide_time_us());
                auto fetch_lsn = segment->fetch_lsn();
                // add segment to pb
                auto pb_seg = request.add_segments();
                pb_seg->set_segment_id(segment->segment_id());
                pb_seg->set_fetch_lsn(fetch_lsn);
                pb_seg->set_replica_id(segment->replica_id());
                pb_seg->set_parse_lsn(segment->parse_lsn());
                pb_seg->set_checkpoint_lsn(segment->gc_lsn());
                // update max or min
                if (fetch_lsn > request.max_fetch_lsn()) {
                    request.set_max_fetch_lsn(fetch_lsn);
                }
                if (fetch_lsn < request.min_fetch_lsn()) {
                    request.set_min_fetch_lsn(fetch_lsn);
                }
                segment_set_stage_info_with_action(segment, pspb::FetchStageSchedule, ctx->action);
                // add segment to ctx
                ctx->batch_segments.emplace(segment->segment_id(), segment);
            }
        }

        if (size != request.segments_size()) {
            _batch_manager->AddTrimCluster(cluster, ctx->batch_version);
            LOG(NOTICE) << "cluster fetch batch size changed,"
                << " id:[" << cluster->name()
                << "] batch_idx:[" << ctx->batch_idx
                << "] batch_version:[" << ctx->batch_version
                << "] size:[" << size << "," << request.segments_size()
                << "]";
        }

        if (request.segments_size() == 0) {
            LOG(TRACE) << "cluster not segments or version changed,"
                << " id:[" << cluster->name()
                << "] batch_idx:[" << ctx->batch_idx
                << "] batch_version:[" << batch_version
                << "]";
            break;
        }

        ctx->batch_get_log_ctx->log_id = log_id;
        ctx->batch_get_log_ctx->status.Reset(RpcCode::kCntlFailed, "init msg");
        ctx->batch_get_log_ctx->response.Clear();
        ctx->batch_get_log_ctx->timeout_ms = FLAGS_psvr_fetch_server_push_timeout_ms + 2000;    // add extra
        ctx->stat_timer.reset();
        if (ctx->node_fetch_begin_time == 0) {
            ctx->node_fetch_begin_time = base::cpuwide_time_us()
                + (base::RandUint64() % FLAGS_psvr_fetch_max_time_us);
        }

        ggpb::Closure* closure = brpc::NewCallback(this, &Fetcher::OnBatchFetchRedoLog, ctx);
        _client->BatchGetLog(ctx->batch_get_log_ctx.get(), closure);
        return;
    } while (0);

    ctx->retry_times = 0;
    ctx->action = Action::kBatchGetLogService;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Fetcher::OnBatchFetchRedoLog(Context* ctx) {
    TimerGuard lat_timer(_stat_fetch_rpc_callback_cost_lat);
    define_control_or_return_invalid(ctx);
    ctx->action = Action::kBatchDisposeLogBlock;
    ctx->callback_time = base::cpuwide_time_us();
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Fetcher::BatchDisposeLogBlock(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_cluster_or_return_invalid(ctx);

    TimePointGuard tp_guard(ctx->callback_time, FLAGS_psvr_enable_fetch_annotate);
    ADD_TRACE_TP(tp_guard.tp(), "wait");
    TimerGuard lat_timer(_stat_batch_fetch_disposer_lat);

    auto& batch_get_log_ctx = ctx->batch_get_log_ctx;
    int32_t fetch_succ_segment_count = 0;
    int32_t fetch_data_segment_count = 0;
    bool limit_quota = false;
    const auto& log_service_peer = batch_get_log_ctx->current_server();

#define BATCH_FETCH_LOG_COMMON_STR  \
    << " log_id:[" << request.log_id()  \
    << "] id:[" << cluster->name()   \
    << "] ls_addr:[" << log_service_peer \
    << "] batch_idx:[" << ctx->batch_idx \
    << "] batch_version:[" << ctx->batch_version \
    << "]"

    do {
        auto& request = batch_get_log_ctx->request;
        if (!batch_get_log_ctx->status.IsOk()) {
            ctx->ls_nodes_status.SetIdx(batch_get_log_ctx->idx);
            PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << "cluster fetch log failed,"
                BATCH_FETCH_LOG_COMMON_STR
                << " " << batch_get_log_ctx->status;
            break;
        }

        ctx->ls_nodes_status.ClearIdx(batch_get_log_ctx->idx);
        ++fetch_succ_segment_count;     // mark rpc succ
        ADD_TRACE_TP(tp_guard.tp(), "loop_start");

        auto& response = batch_get_log_ctx->response;
        cluster->set_cn_lowest_lsn(response.cn_lowest_lsn());
        cluster->set_cn_lowest_gc_lsn(response.cn_lowest_gc_lsn());
        cluster->set_ps_lowest_gc_lsn(response.ps_lowest_gc_lsn());
        cluster->set_max_get_log_lsn(response.dispatch_lsn());

        uint64_t batch_version = 0;
        rwlock_t* shared_mutex = nullptr;
        rwlock_t* batch_shared_mutex = nullptr;
        if (!_batch_manager->Exist(cluster, ctx->batch_idx, &batch_version,
                    &shared_mutex, &batch_shared_mutex)) {
            std::unique_ptr<Context> ctx_guard(ctx);
            LOG(WARNING) << "cluster batch not exists,"
                BATCH_FETCH_LOG_COMMON_STR;
            return;
        }

        std::shared_lock slk(*shared_mutex, std::adopt_lock);
        std::unique_lock lk(*batch_shared_mutex, std::adopt_lock);
        if (ctx->batch_version != batch_version) {
            std::unique_ptr<Context> ctx_guard(ctx);
            LOG(WARNING) << "cluster batch version changed,"
                BATCH_FETCH_LOG_COMMON_STR
                << " new_batch_version:[" << batch_version
                << "]";
            return;
        }

        auto GetSegmentFn = [&ctx](uint32_t id_) -> SegmentPtr {
            if (auto it = ctx->batch_segments.find(id_);
                    it != ctx->batch_segments.end()) {
                return it->second.lock();
            }
            return nullptr;
        };

        uint32_t segment_invalid_lsn_n = 0;
        auto segment_manager = control->segment_manager();
        for (int32_t i = 0; i < response.segments_size(); ++i) {
            const auto& segment_pb = response.segments(i);
            auto segment = GetSegmentFn(segment_pb.segment_id());
            if (!segment) {
                LOG(TRACE) << "cluster not exists segment,"
                    BATCH_FETCH_LOG_COMMON_STR
                    << " segment_id:[" << segment_pb.segment_id()
                    << "]";
                continue;
            }
            segment_set_stage_info_with_action(segment, pspb::FetchStageSchedule, ctx->action);
            const auto fetch_lsn = segment->fetch_lsn();
            if (!segment_pb.is_ok()) {
                if (segment_pb.has_error_code()
                        && segment_pb.error_code() == lspb::GIT_INVALID_LSN
                        && FLAGS_psvr_enable_append_file) {
                    if (_batch_manager->RemoveNoLock(cluster, segment)) {
                        ++segment_invalid_lsn_n;
                        Dispatch(segment TRACE_FILE_LINE_CC, true);
                    }
                    continue;
                }

                if (fetch_lsn < segment->GetClusterPsLowestLsn()) {
                    segment->set_is_invalid_start_lsn(true);
                    if (FLAGS_multi_psvr_enable_reopen_segment) {
                        DoReopenSegment(segment TRACE_FILE_LINE_CC);
                    }
                }
                LOG(ERROR) << "cluster segment fetch rsp error,"
                    BATCH_FETCH_LOG_COMMON_STR
                    << " segment_id:[" << segment_pb.segment_id()
                    << "] fetch_lsn:[" << fetch_lsn
                    << "]";
                continue;
            }

            segment->set_ls_lsn(response.vdl(), response.write_lsn(),
                    response.parse_lsn(), response.dispatch_lsn());

            const uint32_t rsp_total_len = segment_pb.total_len();
            const uint64_t rsp_last_lsn = segment_pb.last_lsn();
            uint32_t quota_flags = 0;
            size_t quota_size = 0;
            if (segment_pb.record_num() == 0) {
                if (rsp_last_lsn <= fetch_lsn) {
                    LOG(TRACE) << segment << " fetch empty,"
                        BATCH_FETCH_LOG_COMMON_STR
                        << "] fetch_lsn:[" << fetch_lsn
                        << "] last_lsn:[" << rsp_last_lsn
                        << "]";
                    continue;
                }
            } else {
                if (fetch_lsn >= rsp_last_lsn) {
                    LOG(FATAL) << segment << " fetch rsp last lsn invalid,"
                        BATCH_FETCH_LOG_COMMON_STR
                        << "] fetch_lsn:[" << fetch_lsn
                        << "] last_lsn:[" << rsp_last_lsn
                        << "]";
                    continue;
                }
                if (rsp_total_len != segment_pb.data_returned().size()) {
                    LOG(FATAL) << segment << " fetch rsp data size invalid,"
                        BATCH_FETCH_LOG_COMMON_STR
                        << "] fetch_lsn:[" << fetch_lsn
                        << "] last_lsn:[" << rsp_last_lsn
                        << "]";
                    continue;
                }
                const auto* log_block_data = reinterpret_cast<const gaia_apply::byte*>(&segment_pb.data_returned()[0]);
                const uint32_t checksum = gaiadb::common::ut_crc32(log_block_data, rsp_total_len);
                if (checksum != segment_pb.data_checksum()) {
                    LOG_EVERY_N(ERROR, 128) << segment << " fetch log block data checksum error,"
                        BATCH_FETCH_LOG_COMMON_STR
                        << "] fetch_lsn:[" << fetch_lsn
                        << "] last_lsn:[" << rsp_last_lsn
                        << "] data_crc:[" << checksum
                        << "] rsp_crc:[" << segment_pb.data_checksum()
                        << "]";
                    continue;
                }
                quota_size = calc_log_block_quota_size(rsp_total_len, segment_pb.record_num());
                if (!CheckQuota(segment, cluster, false, quota_size, quota_flags)) {
                    limit_quota = true;
                    continue;
                }
            }

            ++fetch_data_segment_count;
            PSVR_LOG_EVERY_SECOND_CTX(NOTICE, ctx) << segment << " add log block to fetcher list,"
                BATCH_FETCH_LOG_COMMON_STR
                << "] fetch_lsn:[" << fetch_lsn
                << "] last_lsn:[" << rsp_last_lsn
                << "]";

            l_stat_log_block_used_count << 1;
            set_cluster_stat(cluster, stat_log_block_size, 1);
            LogBlockDeleter log_block_deleter(shared_this(), cluster, segment, quota_flags);
            LogBlockPtr log_block(new LogBlock(request.log_id(), fetch_lsn, rsp_last_lsn), log_block_deleter);
            log_block->fetch_from = log_service_peer.addr;
            log_block->quota_size = quota_size;
            l_stat_log_block_used_mem_byte << quota_size;
            if (rsp_total_len > 0) {
                bool ret = log_block->set_data(base::Slice(segment_pb.data_returned()),
                        segment_pb.record_num(), segment_pb.data_checksum());
                if (!ret) {
                    LOG(WARNING) << segment << " alloc memory failed on fetching,"
                        BATCH_FETCH_LOG_COMMON_STR
                        << " fetch_lsn:[" << fetch_lsn
                        << "] last_lsn:[" << rsp_last_lsn
                        << "]";
                    continue;
                }
            }

            TP_INIT_IF(log_block->tp, FLAGS_psvr_enable_logblock_annotate);
            // add to segment list and tell parser
            if (!segment->AddFetchLogBlock(log_block)) {
                PSVR_LOG_CTX(ERROR, ctx) << segment << " add logblock failed,"
                    BATCH_FETCH_LOG_COMMON_STR
                    << " fetch_lsn:[" << fetch_lsn
                    << "] last_lsn:[" << rsp_last_lsn
                    << "]";
                continue;
            }

            LOG_EVERY_SECOND(NOTICE) << segment << " add log block,"
                BATCH_FETCH_LOG_COMMON_STR
                << " fetch_lsn:[" << fetch_lsn
                << "] last_lsn:[" << rsp_last_lsn
                << "]";

            control->parser()->Dispatch(segment TRACE_FILE_LINE_CC, log_block->end_lsn);

            _stat_fetch_log_buf_size << rsp_total_len;
            _stat_fetch_log_lsn_size_kb << ToKB(log_block->lsn_length());
        } // end of for segments

        LOG_EVERY_SECOND(NOTICE) << "cluster fetch logs ok,"
            BATCH_FETCH_LOG_COMMON_STR
            << "] segment_num:[" << request.segments_size()
            << "] fetch_succ:[" << fetch_succ_segment_count
            << "] rsp_segment_count:[" << response.segments_size()
            << "] fetch_data_segment_count:[" << fetch_data_segment_count
            << "]";

        if (segment_invalid_lsn_n > 0) {
            _batch_manager->AddTrimCluster(cluster, ctx->batch_version);
        }

        if (ctx->continuous_empty_fetch_count > 0 && fetch_data_segment_count > 0) {
            ctx->continuous_empty_fetch_count = 0;
        }

        ADD_TRACE_TP(tp_guard.tp(), "loop_end");
        // if mismatch zone, inc fail times, dont refresh ls ASAP
        if (response.has_refresh_zone() && response.refresh_zone()
                && control->dbd_zone()->has_zone()
                && response.has_zone()) {
            LOG_EVERY_SECOND(TRACE) << "cluster mismatch zone from ls,"
                BATCH_FETCH_LOG_COMMON_STR;
        }
        _stat_fetch_by_server_push_qps << 1;
    } while (0);

#define FETCH_SWITCH_NEXT()  \
do { \
    _stat_fetch_size_per_node << ctx->node_fetch_count; \
    set_cluster_ls_stat(cluster, batch_get_log_ctx->idx, stat_fetch_switch_count, 1);  \
    ctx->enable_server_push = false; \
    ctx->node_fetch_count = 0;   \
    ctx->node_fetch_begin_time = 0; \
    ctx->continuous_empty_fetch_count = 0; \
    batch_get_log_ctx->idx = (batch_get_log_ctx->idx + 1) % batch_get_log_ctx->servers.size(); \
    if (ctx->fetch_from_backup_zone(batch_get_log_ctx->idx) \
            && ctx->abnormal_fetch_begin_time == 0) {  \
        batch_get_log_ctx->idx = 0;  \
    } \
} while (0)

    set_cluster_ls_stat(cluster, batch_get_log_ctx->idx, stat_fetch_rpc_lat, batch_get_log_ctx->latency_us);
    ++ctx->node_fetch_count;
    if (BAIDU_UNLIKELY(fetch_succ_segment_count == 0)) {
        _stat_fetch_error_count << 1;
        if (ctx->abnormal_fetch_begin_time == 0) {
            ctx->abnormal_fetch_begin_time = base::cpuwide_time_us()
                + (base::RandUint64() % FLAGS_psvr_fetch_abnormal_max_time_us);
        }
        FETCH_SWITCH_NEXT();
    } else {
        int64_t exec_time = base::cpuwide_time_us() - ctx->node_fetch_begin_time;
        if ((ctx->fetch_from_backup_zone(batch_get_log_ctx->idx) && exec_time >= FLAGS_psvr_fetch_max_time_us_from_backup)
                || exec_time >= FLAGS_psvr_fetch_max_time_us) {
            FETCH_SWITCH_NEXT();
        } else if (fetch_data_segment_count == 0
                && ++ctx->continuous_empty_fetch_count >= FLAGS_psvr_fetch_empty_consecutive_time) {
            FETCH_SWITCH_NEXT();
        }

        _stat_fetch_task_lat << ctx->stat_timer.u_elapsed();
        _stat_fetch_rpc_lat << batch_get_log_ctx->latency_us;
    }
#undef FETCH_SWITCH_NEXT

    ADD_TRACE_TP(tp_guard.tp(), "done");
    if (FLAGS_psvr_fetch_long_query_time_us > 0
            && TP_ELAPSED(tp_guard.tp(), FLAGS_psvr_fetch_long_query_time_us)) {
        LOG(NOTICE) << "cluster slow batch fetch request,"
            << " id:[" << cluster->name()
            << "] batch_idx:[" << ctx->batch_idx
            << "]" << tp_guard.tp();
    }

    if (fetch_data_segment_count == 0) {
        _stat_fetch_empty_qps << 1;
    }

    // reset action to fetch next log block
    ctx->action = Action::kBatchFetchRedoLog;
    if (limit_quota || ctx->ls_nodes_status.IsFull()) {
        Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
    } else {
        ctx->retry_times = 0;
        Schedule(ctx TRACE_FILE_LINE_CC,
                fetch_data_segment_count == 0 ? FLAGS_psvr_fetch_delay_empty :  FLAGS_psvr_fetch_delay_non_empty);
    }
}

void Fetcher::AppendRecover(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    const gaia_apply::lsn_t start_lsn = segment->fetch_lsn();
    db::LogHeader log_header;
    AppendInfo append_info;
    char* log_buf = nullptr;
    base::Slice offset_cache;
    base::Slice redo;
    db::Status st;
    {
        TimerGuard lat_timer(_stat_fetch_append_recover_lat);
        st = segment->AppendRecover(start_lsn,
            &log_header, &append_info, &offset_cache, &redo, &log_buf);
    }

    std::unique_ptr<char, void(*)(char*)> log_buf_ptr(log_buf, [](char* p) { std::free(p); });

    if (st.IsEof()) {
        if (segment->AppendRecoverFetchFinish()) {
            st = segment->FinishAppendRecover();
            if (!st.IsOk()) {
                LOG(ERROR) << segment << " finish append recover failed, " << st;
                Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
                return;
            }

            std::unique_ptr<Context> ctx_guard(ctx);
            LOG(NOTICE) << segment << " finish to recover append db";
            Dispatch(segment TRACE_FILE_LINE_CC);
            return;
        }
    }

    if (!st.IsOk()) {
        LOG(ERROR) << segment << " append recover failed, " << st
            << " fetch_lsn:[" << segment->fetch_lsn()
            << "] start_checkpoint_lsn:[" << segment->start_checkpoint_lsn()
            << "]";
        Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        return;
    }

    auto cluster = segment->cluster();
    uint32_t quota_flags = 0;
    const size_t quota_size = calc_log_block_quota_size(redo.size(), log_header.records_count);
    if (!CheckQuota(segment, cluster, true, quota_size, quota_flags)) {
        Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        return;
    }

    l_stat_log_block_used_count << 1;
    set_cluster_stat(cluster, stat_log_block_size, 1);
    LogBlockDeleter log_block_deleter(shared_this(), cluster, segment, quota_flags);
    LogBlockPtr log_block(new LogBlock(get_log_id(), log_header.start_lsn, log_header.end_lsn), log_block_deleter);
    base::EndPoint from(base::int2ip(log_header.fetch_from_ip), log_header.fetch_from_port);
    log_block->fetch_from = from;
    log_block->quota_size = quota_size;
    l_stat_log_block_used_mem_byte << quota_size;
    if (!log_block->set_data(redo, log_header.records_count, log_header.buf_crc)) {
        LOG(ERROR) << segment << " log block set data failed";
        Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        return;
    }
    log_block->append_info = append_info;
    if (offset_cache.size()) {
        if (!log_block->set_key(offset_cache)) {
            LOG(ERROR) << segment << " log block set data failed";
            Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
            return;
        }
    }

    log_block->from_append_file = FROM_LOCAL;
    l_stat_log_block_recover_used_count << 1;
    l_stat_log_block_recover_used_mem_byte << quota_size;

    if (!segment->AddFetchLogBlock(log_block)) {
        LOG(ERROR) << segment << " add logblock failed,"
            << " start_lsn:[" << log_header.start_lsn
            << "] end_lsn:[" << log_header.end_lsn
            << "] redo_size:[" << log_block->data_length()
            << "]";
        Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        return;
    }

    segment->AppendPreRecoverNextLog();
    segment->set_is_invalid_start_lsn(false);

    control->parser()->Dispatch(segment TRACE_FILE_LINE_CC, log_block->end_lsn);

    _stat_fetch_log_buf_size << redo.size();
    _stat_fetch_log_lsn_size_kb << ToKB(log_block->lsn_length());

    Schedule(ctx TRACE_FILE_LINE_CC);
}

#define SET_RPC_REOPEN_RESPONSE(code, msg)  \
    if (ctx->reopen_response) { \
        ctx->reopen_response->mutable_status()->set_code(code); \
        ctx->reopen_response->mutable_status()->set_msg(msg);   \
    }

void Fetcher::CheckReopenSegment(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);
    if (segment->fetch_lsn() >= segment->GetClusterPsLowestLsn()) {
        std::unique_ptr<Context> ctx_guard(ctx);
        SET_RPC_REOPEN_RESPONSE(pspb::Status::ERROR, "check fail, segment is ok");
        segment->PutPreDisable();
        LOG(NOTICE) << segment << " reopen check failed,"
            << " fetch_lsn:[" << segment->fetch_lsn()
            << "] ps_lowest_lsn:[" << segment->GetClusterPsLowestLsn()
            << "]";
        return;
    }
    if (++ctx->retry_times > static_cast<uint32_t>(FLAGS_multi_psvr_enable_reopen_check_times)) {
        if (!segment->PreDisable()) {
            std::unique_ptr<Context> ctx_guard(ctx);
            SET_RPC_REOPEN_RESPONSE(pspb::Status::ERROR, "pre disable fail");
            segment->PutPreDisable();
            LOG(WARNING) << segment << " reopen pre disable failed";
        } else {
            ctx->retry_times = 0;
            ctx->action = Action::kPreReopenSegment;
            Schedule(ctx TRACE_FILE_LINE_CC);
        }
    } else {
        Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(1));
    }
}

void Fetcher::PreReopenSegment(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid_exclude(ctx, fSegmentIsDisable);

    PsmInfoPtr psm_info = segment->GetPsmInfo();
    std::vector<base::EndPoint> nodes;
    if (!psm_info->GetOrRefreshNodes(&nodes)) {
        PSVR_LOG_CTX(WARNING, ctx) << segment << " not found manager nodes, retry it";
        control->RefreshPsmInfo(psm_info);
        Schedule(ctx TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        return;
    }

    if (ctx->reopen_not_recover) {
        auto* rpc_ctx = new RpcGetPageServerCtx;
        rpc_ctx->log_id = ctx->log_id;
        rpc_ctx->servers = std::move(nodes);
        rpc_ctx->request.set_addr(control->myself_str());
        rpc_ctx->request.set_is_need_map(false);
        rpc_ctx->request.set_cluster_id(segment->cluster_id());
        rpc_ctx->request.set_segment_id(segment->segment_id());

        segment_set_stage_info_with_action(segment, pspb::FetchStageRPC, ctx->action);
        auto closure = brpc::NewCallback(this, &Fetcher::OnLoadSegment, ctx, rpc_ctx);
        _client->GetSegmentInfo(rpc_ctx, closure);
    } else {
        auto* rpc_ctx = new RpcSetReplicaRecovery;
        rpc_ctx->log_id = ctx->log_id;
        rpc_ctx->servers = std::move(nodes);
        rpc_ctx->request.set_log_id(ctx->log_id);
        rpc_ctx->request.set_segment_id(segment->segment_id());
        rpc_ctx->request.set_cluster_id(segment->cluster_id());
        rpc_ctx->request.set_replica_id(segment->replica_id());
        rpc_ctx->request.set_addr(control->myself_str());
        if (!ctx->reopen_force) {
            rpc_ctx->request.set_checkpoint_lsn(segment->gc_lsn());
        }
        if (segment->version() > 0) {
            rpc_ctx->request.set_version(segment->version());
        }

        segment_set_stage_info_with_action(segment, pspb::FetchStageRPC, ctx->action);
        auto closure = brpc::NewCallback(this, &Fetcher::OnSetReplicaRecovery, ctx, rpc_ctx);
        _client->SetReplicaRecovery(rpc_ctx, closure);
    }
}

void Fetcher::OnSetReplicaRecovery(Context* ctx, RpcSetReplicaRecovery* rpc_ctx) {
    define_control_or_return_invalid(ctx);
    ctx->rpc_set_replica_recovery_ctx.reset(rpc_ctx);
    ctx->action = Action::kReopenSegment;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Fetcher::ReopenSegment(Context* ctx) {
    RpcSetReplicaRecovery* rpc_ctx = ctx->rpc_set_replica_recovery_ctx.release();
    std::unique_ptr<RpcSetReplicaRecovery> rpc_ctx_guard(rpc_ctx);
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid_exclude(ctx, fSegmentIsDisable);

    std::unique_ptr<Context> ctx_guard(ctx);
    PsmInfoPtr psm_info = segment->GetPsmInfo();

    bool not_exists = false;
    bool rpc_ok = false;
    if (rpc_failed(rpc_ctx, &not_exists, &rpc_ok)) {
        if (not_exists) {
            SET_RPC_REOPEN_RESPONSE(pspb::Status::ERROR, "not exists segment in psm");
            segment->PutPreDisable();
            LOG(NOTICE) << segment << " reopen failed, not exists on manager";
        } else if (rpc_ok && rpc_ctx->response.status().code() == gaiadb::GIE_INVALID) {
            SET_RPC_REOPEN_RESPONSE(pspb::Status::ERROR, "segment meta is error");
            segment->PutPreDisable();
            LOG(WARNING) << segment << " reopen failed, set recovery failed, maybe invalid segment,"
                << rpc_ctx->response.status();
        } else if (rpc_ctx->RetryNext()) {
            segment_set_stage_info_with_action(segment, pspb::FetchStageRPC, ctx->action);
            auto closure = brpc::NewCallback(this, &Fetcher::OnSetReplicaRecovery,
                    ctx_guard.release(), rpc_ctx_guard.release());
            _client->SetReplicaRecovery(rpc_ctx, closure);
        } else {
            ctx->action = Action::kPreReopenSegment;
            Schedule(ctx_guard.release() TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        }
        return;
    }

    psm_info->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());
    const gaiapb::SetReplicaRecoveryResponse& response = rpc_ctx->response;
    const auto& info = response.page_server();
    do {
        SegmentPtr new_segment(new Segment(control->weak_this(),
                    segment->cluster_id(),
                    segment->segment_id(),
                    segment->replica_id(),
                    info.version(),
                    segment->segment_size(),
                    segment->enable_punch_hole(),
                    Segment::Status::kCreating,
                    segment->db_path(),
                    segment->store_id(),
                    segment->cluster()));
        if (!segment->Disable()) {
            SET_RPC_REOPEN_RESPONSE(pspb::Status::ERROR, "disable fail");
            LOG(WARNING) << segment << " reopen to disable failed";
            break;
        }
        segment->CopyTo(new_segment);
        if (!new_segment->ReOpen(info)) {
            SET_RPC_REOPEN_RESPONSE(pspb::Status::ERROR, "reopen fail");
            LOG(WARNING) << new_segment << " reopen failed";
            break;
        }
        if (!control->segment_manager()->ReplaceSegment(segment, new_segment)) {
            SET_RPC_REOPEN_RESPONSE(pspb::Status::ERROR, "replace fail");
            LOG(WARNING) << new_segment << " reopen to replace failed";
            break;
        }

        SET_RPC_REOPEN_RESPONSE(pspb::Status::SUCCESS, "ok");
        LOG(NOTICE) << new_segment << " reopen ok";
        control->StartWorking(new_segment TRACE_FILE_LINE_CC);
        return;
    } while (0);

    // if reopen failed, maybe io error, stop here.
}

void Fetcher::OnLoadSegment(Context* ctx, RpcGetPageServerCtx* rpc_ctx) {
    define_control_or_return_invalid(ctx);
    ctx->rpc_segment_replica_ctx.reset(rpc_ctx);
    ctx->action = Action::kRestartSegment;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Fetcher::RestartSegment(Context* ctx) {
    RpcGetPageServerCtx* rpc_ctx = ctx->rpc_segment_replica_ctx.release();
    std::unique_ptr<RpcGetPageServerCtx> rpc_ctx_guard(rpc_ctx);
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid_exclude(ctx, fSegmentIsDisable);

    std::unique_ptr<Context> ctx_guard(ctx);
    PsmInfoPtr psm_info = segment->GetPsmInfo();

    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        if (not_exists) {
            SET_RPC_REOPEN_RESPONSE(pspb::Status::ERROR, "segment not exists in manager");
            segment->PutPreDisable();
            LOG(NOTICE) << segment << " reopen failed, not exists on manager";
        } else if (rpc_ctx->RetryNext()) {
            segment_set_stage_info_with_action(segment, pspb::FetchStageRPC, ctx->action);
            auto closure = brpc::NewCallback(this, &Fetcher::OnLoadSegment,
                    ctx_guard.release(), rpc_ctx_guard.release());
            _client->GetSegmentInfo(rpc_ctx, closure);
        } else {
            ctx->action = Action::kPreReopenSegment;
            Schedule(ctx_guard.release() TRACE_FILE_LINE_CC, fetch_get_delay_us(ctx->retry_times), true);
        }
        return;
    }

    psm_info->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());
    const auto& info = rpc_ctx->response.page_server();
    do {
        SegmentPtr new_segment(new Segment(control->weak_this(),
                    segment->cluster_id(),
                    segment->segment_id(),
                    segment->replica_id(),
                    segment->version(),
                    segment->segment_size(),
                    segment->enable_punch_hole(),
                    Segment::Status::kPrepare,
                    segment->db_path(),
                    segment->store_id(),
                    segment->cluster()));
        segment->CopyTo(new_segment);
        if (!new_segment->LoadEngineWithMeta(info)) {
            SET_RPC_REOPEN_RESPONSE(pspb::Status::ERROR, "restart fail");
            LOG(WARNING) << new_segment << " reopen failed";
            break;
        }
        if (!control->segment_manager()->ReplaceSegment(segment, new_segment)) {
            SET_RPC_REOPEN_RESPONSE(pspb::Status::ERROR, "replace fail");
            LOG(WARNING) << new_segment << " reopen to replace failed";
            break;
        }

        SET_RPC_REOPEN_RESPONSE(pspb::Status::SUCCESS, "ok");
        LOG(NOTICE) << new_segment << " reopen ok";
        control->StartWorking(new_segment TRACE_FILE_LINE_CC);
        return;
    } while (0);

    // if restart failed, maybe io error, stop here.
}

}
/* vim: set expandtab ts=4 sw=4 sts=4 tw=140: */
