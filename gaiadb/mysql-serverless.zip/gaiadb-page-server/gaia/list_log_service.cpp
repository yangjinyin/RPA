/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_log_service.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_log_service.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ListLogService::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (_addr.empty()) {
        gaiapb::LogServiceBatchGetRequest request;
        gaiapb::LogServiceBatchGetResponse response;

        request.set_log_id(_log_id);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_log_service, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                if (_with_status) {
                    log_service::batch_lsrv_status_response batch_ls_response;
                    log_service::lsrv_empty_message ls_request;
                    log_service::lsrv_status_response ls_response;
                    for (auto& ls : response.log_services()) {
                        base::EndPoint ls_node;
                        base::str2endpoint(ls.addr().c_str(), &ls_node);
                        _client.Call(_log_id, ls_node, &log_service::LogServiceService_Stub::query_status, &ls_request, &ls_response,
                                nullptr, &status, _timeout_ms);
                        if (!status.IsOk()) {
                            ls_response.mutable_status()->set_code(2);
                            ls_response.mutable_status()->set_msg("query fail");
                        }

                        auto rsp_node = batch_ls_response.add_nodes();
                        rsp_node->set_addr(ls.addr());
                        rsp_node->mutable_info()->CopyFrom(ls_response);
                    }
                    return Output(batch_ls_response);
                } else {
                    return Output(response);
                }
            } else {
                LOG(WARNING) << node << " list log service failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("list failed, all nodes failed");
        return Output(response);
    } else {
        gaiapb::GetLogServiceRequest request;
        gaiapb::GetLogServiceResponse response;

        request.set_log_id(_log_id);
        request.set_addr(_addr);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_log_service, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                if (_with_status) {
                    log_service::lsrv_empty_message ls_request;
                    log_service::lsrv_status_response ls_response;
                    base::EndPoint ls_node;
                    base::str2endpoint(_addr.c_str(), &ls_node);
                    _client.Call(_log_id, ls_node, &log_service::LogServiceService_Stub::query_status, &ls_request, &ls_response,
                            nullptr, &status, _timeout_ms);
                    if (status.IsOk()
                            && !rsp_is_retry(ls_response.status())) {
                        return Output(ls_response);
                    }
                    ls_response.mutable_status()->set_code(log_service::GIE_FAIL);
                    ls_response.mutable_status()->set_msg("list failed, all ls nodes failed");
                    return Output(ls_response);
                } else {
                    return Output(response);
                }
            } else {
                LOG(WARNING) << node << " get log service failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("get failed, all nodes failed");
        return Output(response);
    }
}

int ListLogService::Format(const gaiapb::GetLogServiceResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    {
        Table table(_raw_with_table, 2);
        if (rsp.has_is_primary_cluster()) {
            table.AddRowsValue({"cluster_role:", rsp.is_primary_cluster() ? "primay" : "standby"});
        }
        if (rsp.has_segment_max_extent_num()) {
            table.AddRowsValue({"seg_extent_num:", rsp.segment_max_extent_num()});
        }
        table.AddRowsValue({"zone:", GetZoneStr(rsp)});
        table.Display();
    }
    return 0;
}

int ListLogService::Format(const gaiapb::LogServiceBatchGetResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.has_is_primary_cluster()) {
        Table table(_raw_with_table, 2);
        table.AddRowsValue({"cluster_role:", rsp.is_primary_cluster() ? "primay" : "standby"});
        table.Display();
    }
    if (rsp.log_services_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({"node", "state", "seg_extent_num", "zone"}, true);
        for (auto& ls : rsp.log_services()) {
            table.AddRowsValue({
                        ls.addr(),
                        gaiadb::NodeState_Name(ls.state()),
                        ls.segment_max_extent_num(),
                        GetZoneStr(ls)
                    });
        }
        table.Display();
    }
    return 0;
}

int ListLogService::Format(const log_service::lsrv_status_response& rsp) {
    SHOW_LS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    {
        Table table(_raw_with_table, 3);
        table.AddRowsValue({"write_lsn:", rsp.write_lsn()});
        table.AddRowsValue({"vdl:", rsp.vdl()});
        table.AddRowsValue({"parse_lsn:", rsp.parse_lsn(), rsp.write_lsn() - rsp.parse_lsn()});
        table.AddRowsValue({"dispatch_lsn:", rsp.dispatch_lsn(), rsp.write_lsn() - rsp.dispatch_lsn()});
        table.AddRowsValue({"archive_lsn:", rsp.archive_lsn()});
        table.AddRowsValue({"gc_lsn:", rsp.gc_lsn()});
        table.AddRowsValue({"cn_lowest_lsn:", rsp.cn_lowest_lsn(), rsp.vdl() - rsp.cn_lowest_lsn()});
        table.AddRowsValue({"ps_lowest_lsn:", rsp.ps_lowest_lsn(), rsp.vdl() - rsp.ps_lowest_lsn()});
        if (rsp.has_cn_lowest_gc_lsn()) {
            table.AddRowsValue({"cn_lowest_gc_lsn:", rsp.cn_lowest_gc_lsn(), rsp.vdl() - rsp.cn_lowest_gc_lsn()});
            table.AddRowsValue({"ps_lowest_gc_lsn:", rsp.ps_lowest_gc_lsn(), rsp.vdl() - rsp.ps_lowest_gc_lsn()});
        }
        table.AddRowsValue({"link_buf_tail:", rsp.link_buf_tail()});
        table.AddRowsValue({"epoch:", rsp.epoch()});
        table.AddRowsValue({"in_increase_epoch:", rsp.in_increase_epoch() ? "yes" : "no"});
        table.AddRowsValue({"checkpoint_lsn:", rsp.checkpoint_lsn()});
        table.AddRowsValue({"quorum_enabled:", rsp.quorum_enabled() ? "yes" : "no"});
        table.AddRowsValue({"in_gossip:", rsp.in_gossip() ? "yes" : "no"});
        table.AddRowsValue({"zone:", GetZoneStr(rsp)});
        table.Display();
    }
    return 0;
}

int ListLogService::Format(const log_service::batch_lsrv_status_response& rsp) {
    Table __header(_raw_with_table, 2);
    __header.AddRowsValue({"log_id:", _log_id});
    __header.Display();
    Table table(_raw_with_table, 0);
    table.AddRowsWithName({"addr", "write_lsn", "vdl", "parse_lsn", "dispatch_lsn",
            "archive_lsn", "gc_lsn", "lowest_lz_lsn", "cn_lowest_lsn", "ps_lowest_lsn", "cn_lowest_gc_lsn", "ps_lowest_gc_lsn",
            "link_buf_tail", "epoch", "in_increase_epoch", "checkpoint_lsn", "quorum_enabled", "in_gossip", "zone",
            "lz_num", "lz_max_num"}, true);
    for (auto& ls : rsp.nodes()) {
        if (static_cast<log_service::GaiaErrno>(ls.info().status().code()) == log_service::GIE_OK) {
            table.AddRowsValue({
                    ls.addr(),
                    ls.info().write_lsn(),
                    ls.info().vdl(),
                    ls.info().parse_lsn(),
                    ls.info().dispatch_lsn(),
                    ls.info().archive_lsn(),
                    ls.info().gc_lsn(),
                    ls.info().lowest_lz_lsn(),
                    ls.info().cn_lowest_lsn(),
                    ls.info().ps_lowest_lsn(),
                    get_unknown_type(ls.info().has_cn_lowest_gc_lsn(), ls.info().cn_lowest_gc_lsn()),
                    get_unknown_type(ls.info().has_ps_lowest_gc_lsn(), ls.info().ps_lowest_gc_lsn()),
                    ls.info().link_buf_tail(),
                    ls.info().epoch(),
                    ls.info().in_increase_epoch(),
                    ls.info().checkpoint_lsn(),
                    ls.info().quorum_enabled(),
                    ls.info().in_gossip(),
                    GetZoneStr(ls.info()),
                    ls.info().used_lz_file_num(),
                    ls.info().max_lz_file_num(),
                    });
        } else {
            table.AddRowsValue({ls.addr(), RowStr(ls.info().status().msg())});
        }
    }
    table.Display();
    return 0;
}

}
}
