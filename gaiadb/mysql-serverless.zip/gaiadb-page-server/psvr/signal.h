/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/signal.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gaiadb/utils/signal.h>

namespace psvr {

using SignalStop = gaiadb::common::SignalStop;

}
