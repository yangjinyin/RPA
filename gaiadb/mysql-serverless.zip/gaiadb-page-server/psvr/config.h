/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/config.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <cstdint>
#include <gflags/gflags.h>
#include "gaiadb/common/global_flags.h" // common flags

namespace psvr {

constexpr uint32_t kMaxThreadNum = 128;

// log config
DECLARE_string(psvr_comlog_path);
DECLARE_string(psvr_comlog_process);
DECLARE_int32(psvr_comlog_split_type);
DECLARE_bool(psvr_comlog_enable_async);
DECLARE_bool(psvr_comlog_enable_wf);
DECLARE_int32(psvr_comlog_cut_size_mb);
DECLARE_int32(psvr_comlog_quota_size);
DECLARE_int32(psvr_comlog_quota_day);

DECLARE_bool(psvr_enable_spd_log);
DECLARE_int64(psvr_spd_log_max_items_num);
DECLARE_int64(psvr_spd_log_thread_num);
DECLARE_int32(psvr_spd_log_flush_second);

DECLARE_bool(psvr_is_multi_type);

// for single-segment begin
DECLARE_string(psvr_page_store_dir);
DECLARE_uint64(psvr_page_store_file_size);
DECLARE_uint64(psvr_ckp_file_size);
// for single-segment end

DECLARE_int32(psvr_bthread_num);
DECLARE_bool(enable_server_rdma);

DECLARE_string(psvr_interfaces);
DECLARE_string(psvr_rbio_server_ip);
DECLARE_int32(psvr_rbio_server_port);

DECLARE_int32(psvr_annotate_max_num);
DECLARE_bool(psvr_enable_logblock_annotate);
DECLARE_bool(psvr_enable_fetch_annotate);
DECLARE_bool(psvr_enable_gc_annotate);
DECLARE_bool(psvr_enable_recover_annotate);
DECLARE_bool(psvr_enable_rbio_annotate);

DECLARE_int64(psvr_logblock_long_query_time_us);

DECLARE_int32(multi_psvr_gc_trash_segment_interval_second);
DECLARE_int64(multi_psvr_segment_in_trash_second);
DECLARE_int32(multi_psvr_gc_trash_segment_num);
DECLARE_int32(multi_psvr_monitor_store_statistic_interval_second);
DECLARE_int32(multi_psvr_monitor_segment_statistic_interval_second);
DECLARE_int64(psvr_retry_delay_us_when_segment_not_enabled);
DECLARE_int64(psvr_clear_space_status_interval_ms);
DECLARE_int64(psvr_dblwr_dump_pick_interval_second);
DECLARE_bool(psvr_get_extent_map_with_high_performance);
DECLARE_bool(psvr_enable_unknown_extent_to_garbage);

DECLARE_string(psvr_zone_region);
DECLARE_string(psvr_zone_available_zone);

DECLARE_int64(psvr_db_file_block_size);
DECLARE_bool(psvr_enable_empty_db_file_on_creating);
DECLARE_bool(psvr_enable_fdatasync);
DECLARE_bool(psvr_disable_sync);
DECLARE_bool(psvr_enable_sync_directory);
DECLARE_bool(psvr_sync_on_recovery_or_compression);
DECLARE_uint64(psvr_sync_size_on_recovery_or_compression);

DECLARE_string(psvr_store_config_file);
DECLARE_int32(psvr_topology_zone);
DECLARE_bool(psvr_topology_to_offline);

DECLARE_bool(multi_psvr_enable_cleanup_store_incomplete_segment);
DECLARE_bool(multi_psvr_enable_remove_garbage_segment);

DECLARE_bool(psvr_auto_enable_segment_statistic);
DECLARE_bool(psvr_auto_enable_cluster_statistic);

DECLARE_bool(psvr_disable_buf);
DECLARE_int64(psvr_init_page_buf_size);
DECLARE_int64(multi_psvr_init_page_buf_size);

DECLARE_bool(psvr_enable_get_all_spaces_on_load);
DECLARE_int32(psvr_get_extent_size);
DECLARE_int64(psvr_query_metadata_quota_per_cluster);
DECLARE_int64(psvr_query_metadata_quota_per_cluster_on_restart);
DECLARE_int64(psvr_query_metadate_quota_per_cluster_on_restart_valid_seconds);

DECLARE_uint64(psvr_single_az_raft_replica_size);
DECLARE_uint64(psvr_with_backup_az_raft_replica_size);

DECLARE_int32(psvr_batch_heartbeat_max_segment_size);

DECLARE_int32(psvr_space_page_slice_count);
DECLARE_int32(psvr_segment_page_lock_slice_count);

DECLARE_int32(psvr_timer_tick_interval);
DECLARE_int32(psvr_control_thread_num);
DECLARE_int32(psvr_fetcher_thread_num);
DECLARE_int32(psvr_parser_thread_num);
DECLARE_int32(psvr_gc_thread_num);
DECLARE_int32(psvr_rbio_thread_num);

DECLARE_int32(multi_psvr_control_thread_num);
DECLARE_bool(multi_psvr_fetcher_thread_enable_shared);
DECLARE_int32(multi_psvr_fetcher_thread_num_per_store);
DECLARE_bool(multi_psvr_parser_thread_enable_shared);
DECLARE_int32(multi_psvr_parser_thread_num_per_store);
DECLARE_bool(multi_psvr_gc_thread_enable_shared);
DECLARE_int32(multi_psvr_gc_thread_num_per_group);
DECLARE_int32(multi_psvr_gc_prior_thread_num_per_group);
DECLARE_int32(multi_psvr_dblwr_dump_num_per_group);
DECLARE_bool(multi_psvr_rbio_thread_enable_shared);
DECLARE_int32(multi_psvr_rbio_thread_num_per_group);
DECLARE_int32(multi_psvr_recover_thread_num);
DECLARE_int32(multi_psvr_dst_recover_thread_num);
DECLARE_int32(multi_psvr_src_recover_thread_num);
DECLARE_int32(multi_psvr_compress_thread_num);

DECLARE_int32(multi_psvr_get_metadata_thread_num);
DECLARE_int64(multi_psvr_store_reserve_size);

DECLARE_int32(multi_psvr_gc_condition_thread_num);
DECLARE_int32(multi_psvr_rbio_condition_thread_num);
DECLARE_int32(multi_psvr_recover_condition_thread_num);

DECLARE_int32(multi_psvr_gc_group_num);
DECLARE_int32(multi_psvr_rbio_group_num);

DECLARE_bool(multi_psvr_enable_reopen_segment);
DECLARE_int32(multi_psvr_enable_reopen_check_times);

DECLARE_int64(psvr_fetch_max_buf_size);
DECLARE_int64(psvr_cluster_fetch_max_buf_size);
DECLARE_int64(psvr_segment_fetch_max_buf_size);
DECLARE_int64(psvr_segment_fetch_max_buf_size_by_append);

DECLARE_int64(psvr_recover_redo_max_buf_size);
DECLARE_int64(psvr_cluster_recover_redo_max_buf_size);

DECLARE_int64(psvr_fetch_max_time_us);
DECLARE_int64(psvr_fetch_max_time_us_from_backup);
DECLARE_int64(psvr_fetch_abnormal_max_time_us);
DECLARE_int32(psvr_fetch_empty_consecutive_time);
DECLARE_int64(psvr_fetch_redo_rec_max_time_s);

DECLARE_int32(psvr_fetch_batch_type);
DECLARE_string(psvr_fetch_batch_cluster_type_config_file);
DECLARE_int64(psvr_fetch_batch_monitor_s);
DECLARE_int32(psvr_fetch_batch_segment_count);

DECLARE_bool(psvr_fetch_enable_server_push);
DECLARE_int64(psvr_fetch_server_push_timeout_ms);
DECLARE_uint64(psvr_fetch_delay_empty);
DECLARE_uint64(psvr_fetch_delay_non_empty);
DECLARE_int64(psvr_fetch_long_query_time_us);
DECLARE_int32(psvr_fetch_redo_rec_log_timeout_ms);

DECLARE_uint64(psvr_fetcher_delay_min_us);
DECLARE_uint64(psvr_fetcher_delay_max_us);
DECLARE_uint64(psvr_parser_delay_min_us);
DECLARE_uint64(psvr_parser_delay_max_us);
DECLARE_uint64(psvr_gc_delay_min_us);
DECLARE_uint64(psvr_gc_delay_max_us);
DECLARE_uint64(psvr_gc_delay_max_us_for_append);
DECLARE_uint64(psvr_dblwr_dump_delay_min_us);
DECLARE_uint64(psvr_dblwr_dump_delay_max_us);
DECLARE_uint64(psvr_recover_delay_min_us);
DECLARE_uint64(psvr_recover_delay_max_us);
DECLARE_uint64(psvr_rbio_delay_min_us);
DECLARE_uint64(psvr_rbio_delay_max_us);

DECLARE_bool(psvr_gc_enable_punch_hole);
DECLARE_bool(psvr_dblwr_enable_punch_hole);
DECLARE_bool(psvr_enable_fallocate_extent_first_page);
DECLARE_int32(psvr_gc_compress_type);
DECLARE_int32(psvr_gc_compress_level);
DECLARE_int32(psvr_gc_compress_lz4_level);
DECLARE_int32(psvr_gc_compress_zstd_level);

DECLARE_int64(psvr_gc_delay_for_recovery_us);
DECLARE_int32(psvr_gc_delay_max_times_for_recovery);
DECLARE_int64(psvr_gc_long_query_time_us);
DECLARE_int64(psvr_gc_page_long_query_time_us);

DECLARE_int32(psvr_gc_parallel_num);

DECLARE_uint64(psvr_gc_delay_lsn_size);
DECLARE_int64(psvr_gc_delay_time_us);

DECLARE_uint64(psvr_gc_delay_append_lsn_size);
DECLARE_uint64(psvr_gc_delay_append_data_size);
DECLARE_int64(psvr_gc_delay_append_time_us);
DECLARE_uint64(psvr_gc_nowait_peer_recovery_window_s);

DECLARE_bool(psvr_gc_clear_ignore_cluster_space);
DECLARE_bool(psvr_gc_corrupted_enable_recover);

DECLARE_int32(psvr_gc_wait_lsn_max_times);
DECLARE_int64(psvr_gc_wait_lsn_sleep_interval_us);
DECLARE_int32(psvr_rbio_wait_lsn_max_times);
DECLARE_int64(psvr_rbio_wait_lsn_sleep_interval_us);
DECLARE_int32(psvr_recover_wait_lsn_max_times);
DECLARE_int64(psvr_recover_wait_lsn_sleep_interval_us);

DECLARE_int64(psvr_parser_wait_quota_sleep_interval_us);
DECLARE_int64(psvr_recover_wait_quota_sleep_interval_us);
DECLARE_int64(psvr_compress_wait_quota_sleep_interval_us);

DECLARE_bool(psvr_recover_enable_check);
DECLARE_bool(psvr_recover_enable_incremental_completion);
DECLARE_bool(psvr_recover_use_attachment);
DECLARE_bool(psvr_stop_recovery_work);
DECLARE_int64(psvr_recover_check_interval);
DECLARE_bool(psvr_recover_block_if_check_fail);
DECLARE_int64(psvr_recover_check_max_speed);
DECLARE_int64(psvr_recover_long_query_time_us);
DECLARE_int64(psvr_recover_read_max_speed);
DECLARE_int64(psvr_recover_read_store_max_speed);
DECLARE_int64(psvr_get_redo_log_max_speed);
DECLARE_int64(psvr_get_redo_log_store_max_speed);
DECLARE_int64(psvr_recover_write_max_speed);
DECLARE_int64(psvr_recover_write_store_max_speed);

DECLARE_int64(psvr_recover_src_max_speed);
DECLARE_int64(psvr_recover_dst_max_speed);
DECLARE_int64(psvr_recover_src_store_max_speed);
DECLARE_int64(psvr_recover_dst_store_max_speed);

DECLARE_int64(psvr_recover_check_task_interval_second);
DECLARE_int32(psvr_recover_max_inflight_task_size);
DECLARE_int32(psvr_recover_task_parallel_num_per_store);
DECLARE_int64(psvr_recover_call_timeout_ms);
DECLARE_int32(psvr_recover_max_wait_lsn_size);
DECLARE_uint64(psvr_recover_max_read_for_recovery_num);
DECLARE_uint64(psvr_recover_max_read_for_backup_num);
DECLARE_uint64(psvr_recover_max_write_for_backup_num);
DECLARE_uint64(psvr_recover_max_read_redo_log_num);

DECLARE_bool(psvr_recover_disabled_as_data_source);
DECLARE_bool(psvr_rbio_disabled_as_data_source);

DECLARE_bool(psvr_enable_compression);
DECLARE_bool(psvr_enable_check_compress_data);
DECLARE_int64(psvr_compress_max_speed);
DECLARE_int64(psvr_compress_store_max_speed);
DECLARE_int64(psvr_compress_store_inflight_num);
DECLARE_uint64(psvr_compress_calc_priority_interval_second);
DECLARE_uint64(psvr_compress_store_max_task_num);
DECLARE_int64(psvr_compress_segment_min_interval_second);
DECLARE_int32(psvr_stat_update_page_interval_second);

DECLARE_bool(psvr_enable_trim_free_extent);
DECLARE_uint64(psvr_trim_free_extent_calc_priority_interval_second);
DECLARE_int64(psvr_trim_free_extent_min_interval_us);
DECLARE_int32(psvr_trim_free_extent_max_task_num_per_store);
DECLARE_uint64(psvr_update_lowest_lsn_interval_second);

DECLARE_bool(psvr_rbio_enable_wait_queue);
DECLARE_int64(psvr_rbio_max_tasks_size);
DECLARE_int64(multi_psvr_rbio_max_tasks_size);
DECLARE_int64(psvr_rbio_store_max_tasks_size);
DECLARE_int64(psvr_rbio_thread_max_queue_size);
DECLARE_int64(psvr_rbio_long_query_time_us);
DECLARE_int64(psvr_rbio_long_query_time_print_detail_us);
DECLARE_int64(psvr_rbio_long_write_page_us);
DECLARE_int64(psvr_rbio_max_timeout_ms);
DECLARE_bool(psvr_rbio_enable_direct_get_meta);
DECLARE_int32(psvr_rbio_response_compress_type);
DECLARE_bool(psvr_rbio_transfer_req_in_recovery);

DECLARE_bool(psvr_enable_append_file);
DECLARE_int32(multi_psvr_append_thread_num_per_group);
DECLARE_uint64(psvr_append_file_block_size);
DECLARE_int32(multi_psvr_append_recover_thread_num_pre_store);
DECLARE_bool(psvr_append_disable_cache_key);
DECLARE_uint64(psvr_append_merge_max_buf_size);
DECLARE_uint64(psvr_append_recover_read_buf_size);
DECLARE_uint64(psvr_append_open_read_buf_size);
DECLARE_int32(psvr_append_recover_max_empty_block_num);
DECLARE_uint64(psvr_append_seek_anchor_chunk_size);
DECLARE_bool(psvr_append_enable_slots);
DECLARE_bool(psvr_append_fix_footer_backward_scan);
DECLARE_uint64(psvr_append_fix_footer_backward_scan_min_file_size);
DECLARE_uint64(psvr_append_fix_footer_max_truncate_size);

DECLARE_int32(psvr_dblwr_max_page_num);
DECLARE_int32(psvr_dblwr_dump_max_num_per_round);
DECLARE_int32(psvr_dblwr_buf_file_limit_per_segment);
DECLARE_int64(psvr_dblwr_seal_timeout_us);
DECLARE_uint64(psvr_dblwr_seal_interval_second);

DECLARE_int32(psvr_refresh_peers_err_times);

DECLARE_bool(psvr_enable_encrypt);

DECLARE_bool(psvr_mock_rbio_timeout);
DECLARE_uint64(psvr_mock_rbio_sleep_us);

DECLARE_bool(psvr_in_chaos);

bool ConfigArgsSinkCheck();
void ResetConfigFlagsForHddStore();

}
