/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/add_segment.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/add_segment.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int AddSegment::Run() {
    RpcStatus status;
    gaiapb::AddSegmentRequest request;
    gaiapb::AddSegmentResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_replicas.size() < 1) {
        print_error("miss --replica or replica size < 1");
        return 1;
    }

    if ((_regions.size() || _available_zones.size())
            && _regions.size() != _available_zones.size()) {
        print_error("mismatch --region and --available-zone size");
        return 1;
    }

    if (_regions.size() && _regions.size() != _replicas.size()) {
        print_error("mismatch --replica and zone size");
        return 1;
    }

    if (_multi_type) {
        if (_task_id == 0) {
            print_error("miss --task-id in multi type");
            return 1;
        }
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    request.set_log_id(_log_id);
    auto segment_pb = request.add_segments();
    if (_task_id) {
        segment_pb->set_task_id(_task_id);
    }

    uint32_t size = _replicas.size();
    for (uint32_t i = 0; i < size; ++i) {
        if (_regions.size()) {
            auto replica_pb = segment_pb->add_replicas();
            replica_pb->set_addr(_replicas[i]);
            replica_pb->mutable_zone()->set_region(_regions[i]);
            replica_pb->mutable_zone()->set_available_zone(_available_zones[i]);
        } else {
            segment_pb->add_replica_addrs(_replicas[i]);
        }
    }

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::add_segment, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " add segment failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("add failed, all nodes failed");
    return Output(response);
}

int AddSegment::Format(const gaiapb::AddSegmentResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.tasks_size()) {
        printf("%-15s %s\n", "task_id",  "segment_id");
        for (auto& task : rsp.tasks()) {
            printf("%-15lu %u\n", task.task_id(), task.segment_id());
        }
    } else if (rsp.segment_ids_size()) {
        printf("segment_id\n");
        for (auto& id : rsp.segment_ids()) {
            printf("%u\n", id);
        }
    }
    return 0;
}

}
}
