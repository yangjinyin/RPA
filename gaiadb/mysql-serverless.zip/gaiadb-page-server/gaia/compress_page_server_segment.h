/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/compress_page_server_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class CompressPageServerSegment : public Command {
public:
    CompressPageServerSegment() {
        SetName("compress-ps-segment");
        SetDesc("add or remove a segment to/from the compression list on page server");
        SetDescCn("在存储节点服务器上添加或移除分片的压缩配置信息");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "segment cluster id", kstring);
        AddRequiredArgOption("segment-id", NULL, 's', "segment id", kint32_t);
        AddNoArgOption("remove", &_long_opt_val, kOptMax + 1,
                "remove it from compression list, if specified",
                kGroup2Scope);
        AddNoArgOption("is-prior", &_long_opt_val, kOptMax + 2,
                "add segment to compression list header, if specified",
                kGroup3Scope);

        AddExample("-a <ip> -p <port> --cluster-id <cluster_id> --segment-id <segment_id>");
        AddExample("-a <ip> -p <port> --cluster-id <cluster_id> --segment-id <segment_id> --remove");
    }
    virtual ~CompressPageServerSegment() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtol(opt, NULL, 10));
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _remove = true;
                break;
            case kOptMax + 2:
                _is_prior = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::AddCompressSegmentResponse& rsp);
    int Format(const pspb::DropCompressSegmentResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
    bool _is_prior {false};
    bool _remove {false};
};

}
}
