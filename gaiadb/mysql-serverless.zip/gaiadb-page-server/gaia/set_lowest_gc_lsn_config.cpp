/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_lowest_gc_config.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/set_lowest_gc_lsn_config.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int SetLowestGcLsnConfig::Run() {
    RpcStatus status;
    gaiapb::SetLowestGcLsnConfigRequest request;
    gaiapb::SetLowestGcLsnConfigResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (!_status.has_val) {
        print_error("miss --status");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("%s lowest gc lsn?", _status.val ? "Enable" : "Disable");
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    request.set_log_id(_log_id);
    request.set_status(_status.val);

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::set_lowest_gc_lsn_config, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " set lowest gc lsn config failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("set failed, all nodes failed");
    return Output(response);
}

int SetLowestGcLsnConfig::Format(const gaiapb::SetLowestGcLsnConfigResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
