/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/include/table.h
 The interface for table related

 Created 12/16/2022 Shenghu Zhu
 *******************************************************/
#include <cstddef> 
#include "gaiadb_table.h"
#include "my_io.h"
#include "sql_table.h"
#include "dict0types.h"

void parse_filename(const char *filename, size_t filename_length,
                    const char **schema_name, size_t *schema_name_length,
                    const char **table_name, size_t *table_name_length,
                    const char **partition_name, size_t *partition_name_length,
                    const char **subpartition_name,
                    size_t *subpartition_name_length) {
  const char *parse_ptr;
  size_t parse_length;
  const char *id_ptr = NULL;
  size_t id_length = 0;
  const char *ptr = NULL;

  parse_ptr = filename;
  parse_length = filename_length;

  while ((ptr = strchr(parse_ptr, '/'))) {
    id_ptr = parse_ptr;
    id_length = (ptr - parse_ptr);

    parse_ptr += (id_length + 1);
    parse_length -= (id_length + 1);
  }

  *schema_name = id_ptr;
  *schema_name_length = id_length;

  ptr = strchr(parse_ptr, '#');

  if (ptr != NULL) {
    id_ptr = parse_ptr;
    id_length = (ptr - parse_ptr);

    parse_ptr += (id_length);
    parse_length -= (id_length);
  } else {
    id_ptr = parse_ptr;
    id_length = parse_length;

    parse_ptr = NULL;
    parse_length = 0;
  }

  *table_name = id_ptr;
  *table_name_length = id_length;

  if ((parse_length >= 4) && (native_strncasecmp(parse_ptr, "#TMP", 4) == 0)) {
    parse_ptr += 4;
    parse_length -= 4;
  }

  if ((parse_length >= 4) && (native_strncasecmp(parse_ptr, "#REN", 4) == 0)) {
    parse_ptr += 4;
    parse_length -= 4;
  }

  if ((parse_length >= 3) &&
      (native_strncasecmp(parse_ptr, dict_name::PART_SEPARATOR, dict_name::PART_SEPARATOR_LEN) == 0 ||
       native_strncasecmp(parse_ptr, dict_name::ALT_PART_SEPARATOR, dict_name::PART_SEPARATOR_LEN) == 0)) {
    parse_ptr += dict_name::PART_SEPARATOR_LEN;
    parse_length -= dict_name::PART_SEPARATOR_LEN;

    ptr = strchr(parse_ptr, '#');

    if (ptr != NULL) {
      id_ptr = parse_ptr;
      id_length = (ptr - parse_ptr);

      parse_ptr += (id_length);
      parse_length -= (id_length);
    } else {
      id_ptr = parse_ptr;
      id_length = parse_length;

      parse_ptr = NULL;
      parse_length = 0;
    }
  } else {
    id_ptr = NULL;
    id_length = 0;
  }

  *partition_name = id_ptr;
  *partition_name_length = id_length;

  if ((parse_length >= 4) &&
      (native_strncasecmp(parse_ptr, dict_name::ALT_SUB_PART_SEPARATOR, dict_name::SUB_PART_SEPARATOR_LEN) == 0 ||
       native_strncasecmp(parse_ptr, dict_name::SUB_PART_SEPARATOR, dict_name::SUB_PART_SEPARATOR_LEN) == 0)) {
    parse_ptr += dict_name::SUB_PART_SEPARATOR_LEN;
    parse_length -= dict_name::SUB_PART_SEPARATOR_LEN;

    id_ptr = parse_ptr;
    id_length = parse_length;

    parse_ptr = NULL;
    parse_length = 0;
  } else {
    id_ptr = NULL;
    id_length = 0;
  }

  *subpartition_name = id_ptr;
  *subpartition_name_length = id_length;
}

std::string fil_convert_filename_to_tablename(const std::string& tablespace_name) {
  std::string name_after_converting;
  name_after_converting.resize(FN_REFLEN);
  auto size = fil_convert_filename_to_tablename(tablespace_name.c_str(), &(name_after_converting[0]));
  name_after_converting.resize(size);
  return name_after_converting;
}

/** convert filename to tablename, and return the tablename's length.
 * assume that the input string is in filename format.
 * eg. "abc@002fdef/xyz@002f123#P#p1_234#SP#p1s2_34", after converting: "abc/def/xyz/123#P#p1_234#SP#p1s2_34"
 * 
 * @param [in]  tablespace_name  the name need to be converted
 * @param [in,out] name_after_converting  name after converting
 * @return the length after converting
 */
std::size_t fil_convert_filename_to_tablename(const char* tablespace_name, char* name_after_converting) {
  const char *p1, *p2, *p3, *p4;
  size_t s1, s2, s3, s4;
  // parse tablespace_name to schema, table, partition and sub_partition
  parse_filename(tablespace_name, strlen(tablespace_name), &p1, &s1, &p2, &s2, &p3, &s3, &p4, &s4);

  my_array_t<char> schema_before(s1 + 1, true);
  memcpy(schema_before.ptr, p1, s1);

  my_array_t<char> table_before(s2 + 1, true);
  memcpy(table_before.ptr, p2, s2);

  my_array_t<char> partition_before(s3 + 1, true);
  if (p3) {
    memcpy(partition_before.ptr, p3, s3);
  }

  my_array_t<char> sub_partition_before(s4 + 1, true);
  if (p4) {
    memcpy(sub_partition_before.ptr, p4, s4);
  }

  // convert schema
  my_array_t<char> schema(NAME_LEN + 1);
  size_t schema_len = filename_to_tablename(schema_before.ptr, schema.ptr, schema.size);
  // convert table
  my_array_t<char> table(NAME_LEN + 1);
  size_t table_len = filename_to_tablename(table_before.ptr, table.ptr, table.size);
  // convert partition
  my_array_t<char> partition(NAME_LEN + 1);
  size_t partition_len = filename_to_tablename(partition_before.ptr, partition.ptr, partition.size);
  // convert sub partition
  my_array_t<char> sub_partition(NAME_LEN + 1);
  size_t sub_partition_len = filename_to_tablename(sub_partition_before.ptr, sub_partition.ptr, sub_partition.size);

  size_t total_len = 0;
  // copy to name_after_converting
  // schema_len's max is 193, less than name_after_converting's size: 512. Therefore, no need to check
  memcpy(name_after_converting, schema.ptr, schema_len);
  total_len += schema_len;
  if (s2 == 0) { //no table part
    goto ret;
  }
  memset(name_after_converting + total_len, '/', 1);
  total_len += 1;
  // max length of "${schema}/${table}" is 193 + 1 + 193 = 387, less than name_after_converting's size: 512. 
  //Therefore, no need to check
  memcpy(name_after_converting + total_len, table.ptr, table_len);
  total_len += table_len;
  if (s3 == 0) { //no partition part
    goto ret;
  }
  memcpy(name_after_converting + total_len, "#P#", 3);
  total_len += 3;

  if (total_len + partition_len >= FN_REFLEN) {// if is longer than name_after_converting, truncate
    memcpy(name_after_converting + total_len, partition.ptr, FN_REFLEN - total_len);
    total_len = FN_REFLEN;
  } else { //enough space for partition
    memcpy(name_after_converting + total_len, partition.ptr, partition_len);
    total_len += partition_len;
    if (s4 == 0) { //no sub_partition part
      goto ret;
    }
    if (total_len + 4 >= FN_REFLEN) {
      memcpy(name_after_converting + total_len, "#SP#", FN_REFLEN - total_len);
      total_len = FN_REFLEN;
    } else { //enough space for "#SP#"
      memcpy(name_after_converting + total_len, "#SP#", 4);
      total_len += 4;
      if (total_len + sub_partition_len >= FN_REFLEN) {
        memcpy(name_after_converting + total_len, sub_partition.ptr, FN_REFLEN - total_len);
        total_len = FN_REFLEN;
      } else { //enough space for sub_partition
        memcpy(name_after_converting + total_len, sub_partition.ptr, sub_partition_len);
        total_len += sub_partition_len;
      }
    }
  }

ret:
  return total_len;
}
