/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_compress.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/compress_context.h"
#include <gaiadb/psm_client/config.h>
#include "test/mock_thread_pool.h"
#include "test/mock_recover.h"
#include "bmock.h"

namespace psvr {
namespace test {

class CompressTests : public PsvrTest {
 public:
    CompressTests() {}
    virtual ~CompressTests() {}

    void SetUp() {
        _compressor.reset(new Compressor(_mock_client, _control));
        _mock_thread_pool = new MockExecutor<Compressor::Context, thread::TaskContext>;
        _compressor->_thread_pool.reset(_mock_thread_pool);
        gaia_apply::page_size_t page_size(16<<10, 16<<10, false);

        _mock_flow_cntl = new MockFlowQuota;
        _compressor->_flow.reset(_mock_flow_cntl);

        _mock_quota_thread = new MockQuotaThread<Compressor::Context*, std::shared_ptr<FlowQuota>>;
        _compressor->_quota_thread.reset(_mock_quota_thread);

        _compressor->_stores.emplace_back(std::make_shared<Compressor::Store>(0));
        _compressor->_stores[0]->task_quota = std::make_shared<Quota>(&FLAGS_psvr_compress_store_inflight_num);
        _compressor->_stores[0]->flow_quota = _compressor->_flow;

        _control->_segment_manager.reset(new SegmentManager);
        _control->segment_manager()->Start(1);

        gaiadb::psm_client::FLAGS_heartbeat_interval_second = 0;
        gaiadb::psm_client::FLAGS_heartbeat_interval_ms = 100;

        // The mock objects created by BMOCK_*_METHOD attach their hooks at static-init
        // time, so they would stay in effect for the whole binary. Stop them all here and
        // let each test enable only the ones it injects with BMOCK_*_RESUME.
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        BMOCK_NS_STOP(psvr, page_is_compressed, bool(const gaia_apply::byte*));
        BMOCK_STOP(bthread_timer_add, int(bthread_timer_t*, timespec, void (*on_timer)(void*), void*));
        BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
    }

    void TearDown() {
    }

private:
    CompressorPtr _compressor;
    MockExecutor<Compressor::Context, thread::TaskContext>* _mock_thread_pool;
    MockQuotaThread<Compressor::Context*, std::shared_ptr<FlowQuota>>* _mock_quota_thread;
    MockFlowQuota* _mock_flow_cntl;
};

BMOCK_NS_METHOD3(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
BMOCK_NS_METHOD1(psvr, page_is_compressed, bool(const gaia_apply::byte*));
BMOCK_METHOD4(bthread_timer_add, int(bthread_timer_t*, timespec, void (*on_timer)(void*), void*));

bool MockExecuteOk(Compressor::Context* ctx) {
    delete ctx;
    return true;
}

bool MockScheduleOk(thread::TaskContext* ctx, uint64_t) {
    delete ctx;
    return true;
}

bool MockGetQuotaFail(Compressor::Context* ctx, std::shared_ptr<FlowQuota>) {
    delete ctx;
    return false;
}

static void set_page_data(gaia_apply::byte* page) {
    INIT_APPLY_RAW_ARG(false);
    memset(page, 0x1, 16384);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_SPACE_OR_CHKSUM, 0);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_OFFSET, 1);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_PREV, 0);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_NEXT, 2);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_LSN, 1024);
    gaia_apply::mach_write_to_2(page + gaia_apply::FIL_PAGE_TYPE, gaia_apply::FIL_PAGE_INODE APPLY_RAW_ARG_NAME_CC);
    gaia_apply::mach_write_to_8(page + gaia_apply::FIL_PAGE_FILE_FLUSH_LSN, 0);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_SPACE_ID, 2);

    uint32_t crc = calc_page_crc32(page);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_SPACE_OR_CHKSUM, crc);
    gaia_apply::mach_write_to_4(page + (16<<10) - gaia_apply::FIL_PAGE_END_LSN_OLD_CHKSUM, crc);

    memcpy(page + (16<<10) - gaia_apply::FIL_PAGE_END_LSN_OLD_CHKSUM + 4, page + gaia_apply::FIL_PAGE_LSN + 4, 4);
}

void set_buf_block(BufBlockPtr buf_block, gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no, const gaia_apply::page_size_t& page_size, gaia_apply::lsn_t lsn = 1024) {
    init_buf_block(buf_block, space_id, page_no, page_size);
    gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, space_id);
    gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_OFFSET, page_no);
    page_set_page_lsn(buf_block->frame, page_size.physical(), lsn);
}

TEST_F(CompressTests, test_Quota) {
    Compressor::Context ctx(Compressor::Action::kCompressSegment);
    EXPECT_CALL(*_mock_flow_cntl, GetQuota(_)).WillOnce(Return(0));
    bool ret = _compressor->_flow >= &ctx;
    ASSERT_TRUE(ret);

    ctx.quota_size = GAIADB_EXTENT_SIZE;
    EXPECT_CALL(*_mock_flow_cntl, GetQuota(GAIADB_EXTENT_SIZE)).WillOnce(Return(0));
    ret = _compressor->_flow >= &ctx;
    ASSERT_TRUE(ret);

    EXPECT_CALL(*_mock_flow_cntl, GetQuota(GAIADB_EXTENT_SIZE)).WillOnce(Return(1));
    ret = _compressor->_flow >= &ctx;
    ASSERT_FALSE(ret);
    END_OF_CASE;
}

TEST_F(CompressTests, test_TrimFreeExtentTask) {
    Compressor::TrimFreeExtentTask task(2);

    ASSERT_TRUE(task.CanRun(0, 1));
    ASSERT_FALSE(task.CanRun(0, 1));
    ASSERT_TRUE(task.CanRun(1, 1));

    task.Finish(0);
    ASSERT_TRUE(task.CanRun(0, 1));
    task.Finish(0);
    task.Finish(1);
    END_OF_CASE;
}

TEST_F(CompressTests, test_FreeExtentActions) {
    const bool old_enable_trim_free_extent = FLAGS_psvr_enable_trim_free_extent;
    FLAGS_psvr_enable_trim_free_extent = false;
    _compressor->_stopped = false;
    _compressor->_trim_free_extent_task.reset(new Compressor::TrimFreeExtentTask(1));

    EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
        .WillOnce(Invoke(MockScheduleOk));
    auto priority_ctx = new Compressor::Context(Compressor::Action::kCalcPriorityForFreeExtent);
    _compressor->OnCompletion(priority_ctx);

    FLAGS_psvr_enable_trim_free_extent = true;
    EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
        .WillOnce(Invoke(MockScheduleOk));
    auto empty_priority_ctx = new Compressor::Context(Compressor::Action::kCalcPriorityForFreeExtent);
    _compressor->OnCompletion(empty_priority_ctx);

    auto segment = create_mock_segment_by_cluster("c1", 1);
    auto trim_ctx = new Compressor::Context(Compressor::Action::kTrimFreeExtent, 0);
    trim_ctx->compress_task.reset(new Compressor::Task(segment));
    ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
    segment.reset();
    _compressor->OnCompletion(trim_ctx);

    auto invalid_trim_segment = create_mock_segment_by_cluster("c1", 2);
    auto invalid_trim_ctx = new Compressor::Context(Compressor::Action::kTrimFreeExtent, 0);
    invalid_trim_ctx->compress_task.reset(new Compressor::Task(invalid_trim_segment));
    ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
    invalid_trim_segment.reset();
    _compressor->OnCompletion(invalid_trim_ctx);

    _compressor->_stopped = true;
    FLAGS_psvr_enable_trim_free_extent = old_enable_trim_free_extent;
    END_OF_CASE;
}

TEST_F(CompressTests, test_TrimFreeExtentScan) {
    const bool old_enable_trim_free_extent = FLAGS_psvr_enable_trim_free_extent;
    FLAGS_psvr_enable_trim_free_extent = true;
    _compressor->_stopped = false;
    _compressor->_trim_free_extent_task.reset(new Compressor::TrimFreeExtentTask(1));
    EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
        .Times(AnyNumber())
        .WillRepeatedly(Return(_buf_block));
    _cluster->_in_backup._in_backup.store(-1);
    _cluster->_in_backup._change_time.store(
            base::cpuwide_time_us() - get_heartbeat_interval_us() * 11);
    _cluster->_in_backup._lease.store(base::cpuwide_time_us() + get_heartbeat_interval_us() * 1000);

    {
        auto segment = create_mock_segment_by_cluster("c1", 1);
        auto ctx = new Compressor::Context(Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, 0, 16384, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kIOError)));
        _compressor->OnCompletion(ctx);
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 2);
        auto ctx = new Compressor::Context(Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, 0, 16384, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(Return(true));
        _compressor->OnCompletion(ctx);
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 3);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto ctx = new Compressor::Context(Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(16384), Return(db::Status(db::Code::kOk))))
            .WillOnce(Return(db::Status(db::Code::kIOError)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        EXPECT_CALL(*segment, TrimPhysicalPageData(_, 1, 1, 0, 16384, true))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        _compressor->OnCompletion(ctx);
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 4);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, 0, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(16384),
                    Return(db::Status(db::Code::kOk))));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        EXPECT_CALL(*segment,
                TrimPhysicalPageData(_, 1, 1, 0, 16384, true))
            .WillOnce(Return(db::Status(db::Code::kRetry)));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
            .WillOnce(Invoke(MockScheduleOk));

        _compressor->OnCompletion(ctx);

        ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 5);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, 0, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(0),
                    Return(db::Status(db::Code::kOk))));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));

        _compressor->OnCompletion(ctx);

        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 6);
        segment->SetSpaceSafeTrimLsn(1, 1);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(16384),
                    Return(db::Status(db::Code::kOk))))
            .WillOnce(Return(db::Status(db::Code::kIOError)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpaceStatus(1))
            .WillOnce(Return(kSpaceStatusDeleted | kSpaceStatusWithPSM));
        EXPECT_CALL(*segment,
                TrimPhysicalPageData(_, 1, 1, 0, 16384, false))
            .WillOnce(Return(db::Status(db::Code::kOk)));

        _compressor->OnCompletion(ctx);

        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 7);
        auto ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        auto page_lock = segment->GetPageLock(0);
        db::PageUniqueLock lock(page_lock);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
            .WillOnce(Invoke(MockScheduleOk));

        _compressor->OnCompletion(ctx);

        ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 8);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, 0, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(16384),
                    Return(db::Status(db::Code::kOk))));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpaceStatus(1))
            .WillOnce(Return(kSpaceStatusDeleted | kSpaceStatusWithPSM));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
            .WillOnce(Invoke(MockScheduleOk));

        _compressor->OnCompletion(ctx);

        ASSERT_EQ(segment->GetSpaceSafeTrimLsn(1), 0);
        ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 9);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        _cluster->set_cn_lowest_lsn(100);
        _cluster->set_last_lsn_update_time(base::cpuwide_time_us());
        auto ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ctx->trim_space_id = 1;
        ctx->trim_space_id_time =
                _cluster->last_lsn_update_time() - 1;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(16384),
                    Return(db::Status(db::Code::kOk))))
            .WillOnce(Return(db::Status(db::Code::kIOError)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpaceStatus(1))
            .WillOnce(Return(kSpaceStatusDeleted | kSpaceStatusWithPSM));
        EXPECT_CALL(*segment,
                TrimPhysicalPageData(_, 1, 1, 0, 16384, false))
            .WillOnce(Return(db::Status(db::Code::kOk)));

        _compressor->OnCompletion(ctx);

        ASSERT_EQ(segment->GetSpaceSafeTrimLsn(1), 100);
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    _compressor->_stopped = true;
    FLAGS_psvr_enable_trim_free_extent = old_enable_trim_free_extent;
    BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    END_OF_CASE;
}

TEST_F(CompressTests, test_TrimFreeExtentBranches) {
    const bool old_enable_trim_free_extent =
            FLAGS_psvr_enable_trim_free_extent;
    FLAGS_psvr_enable_trim_free_extent = true;
    _compressor->_stopped = false;
    _compressor->_trim_free_extent_task.reset(
            new Compressor::TrimFreeExtentTask(1));
    EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
        .Times(AnyNumber())
        .WillRepeatedly(Return(_buf_block));
    _cluster->_in_backup._in_backup.store(-1);
    _cluster->_in_backup._change_time.store(
            base::cpuwide_time_us() - get_heartbeat_interval_us() * 11);
    _cluster->_in_backup._lease.store(base::cpuwide_time_us() + get_heartbeat_interval_us() * 1000);

    {
        auto segment = create_mock_segment_by_cluster("c1", 20);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto* ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, 0, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(16384),
                    Return(db::Status(db::Code::kOk))));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        EXPECT_CALL(*segment,
                TrimPhysicalPageData(_, 1, 1, 0, 16384, true))
            .WillOnce(Return(db::Status(db::Code::kIOError)));

        _compressor->OnCompletion(ctx);

        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 21);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto task = std::make_shared<Compressor::Task>(segment);
        auto* ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task = task;
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, 0, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(16384),
                    Return(db::Status(db::Code::kOk))));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpaceStatus(1))
            .WillOnce(Return(kSpaceStatusWork));
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
            .WillOnce(Invoke(MockGetQuotaFail));

        _compressor->OnCompletion(ctx);

        ASSERT_EQ(task->offset, GAIADB_EXTENT_SIZE);
        ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 22);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto* ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, 0, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(16384),
                    Return(db::Status(db::Code::kOk))));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpaceStatus(1))
            .WillOnce(Return(kSpaceStatusUnknown));
        auto get_space_meta = [](SegmentPtr TRACE_FILE_LINE_DTC,
                gaia_apply::space_id_t, ggpb::Closure* closure,
                pspb::Status* status) {
            status->set_code(pspb::Status::SUCCESS);
            closure->Run();
        };
        EXPECT_CALL(*_mock_parser,
                AddGetSpaceMetaEvent(_ TRACE_MOCK_ARG_CC, 1, _, _))
            .WillOnce(Invoke(get_space_meta));
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(MockExecuteOk));

        _compressor->OnCompletion(ctx);

        ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 23);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto* ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, 0, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(16384),
                    Return(db::Status(db::Code::kOk))));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .Times(AnyNumber())
            .WillRepeatedly(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpaceStatus(1))
            .WillOnce(Return(kSpaceStatusDeleted));
        auto get_space_meta = [](SegmentPtr TRACE_FILE_LINE_DTC,
                gaia_apply::space_id_t, ggpb::Closure* closure,
                pspb::Status* status) {
            status->set_code(pspb::Status::INVALID);
            closure->Run();
        };
        EXPECT_CALL(*_mock_parser,
                AddGetSpaceMetaEvent(_ TRACE_MOCK_ARG_CC, 1, _, _))
            .WillOnce(Invoke(get_space_meta));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
            .WillOnce(Invoke(MockScheduleOk));

        _compressor->OnCompletion(ctx);

        ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 24);
        segment->SetSpaceSafeTrimLsn(1, 1);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto page = segment->_space_page_manager->GetOrCreatePage(1, 1);
        LogRecord record(gaia_apply::MLOG_LSN, nullptr, 0, 10, 20,
                1, 1, false, 0);
        page->AppendLogRecord(&record);
        auto task = std::make_shared<Compressor::Task>(segment);
        auto* ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task = task;
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, 0, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(16384),
                    Return(db::Status(db::Code::kOk))));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpaceStatus(1))
            .WillOnce(Return(kSpaceStatusDeleted | kSpaceStatusWithPSM));
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
            .WillOnce(Invoke(MockGetQuotaFail));

        _compressor->OnCompletion(ctx);

        ASSERT_EQ(task->offset, GAIADB_EXTENT_SIZE);
        ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 25);
        segment->SetSpaceSafeTrimLsn(1, 1);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto* ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, 0, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(16384),
                    Return(db::Status(db::Code::kOk))));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpaceStatus(1))
            .WillOnce(Return(kSpaceStatusDeleted | kSpaceStatusWithPSM));
        EXPECT_CALL(*segment,
                TrimPhysicalPageData(_, 1, 1, 0, 16384, false))
            .WillOnce(Return(db::Status(db::Code::kRetry)));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
            .WillOnce(Invoke(MockScheduleOk));

        _compressor->OnCompletion(ctx);

        ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 26);
        segment->SetSpaceSafeTrimLsn(1, 1);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto* ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, 0, 16384, _, _, _))
            .WillOnce(DoAll(SetArgPointee<5>(16384),
                    Return(db::Status(db::Code::kOk))));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpaceStatus(1))
            .WillOnce(Return(kSpaceStatusDeleted | kSpaceStatusWithPSM));
        EXPECT_CALL(*segment,
                TrimPhysicalPageData(_, 1, 1, 0, 16384, false))
            .WillOnce(Return(db::Status(db::Code::kIOError)));

        _compressor->OnCompletion(ctx);

        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 27);
        auto* ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ctx->compress_task->offset = ctx->compress_task->size;
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));

        _compressor->OnCompletion(ctx);

        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    const bool old_sync_on_recovery_or_compression =
            FLAGS_psvr_sync_on_recovery_or_compression;
    const bool old_disable_sync = FLAGS_psvr_disable_sync;
    FLAGS_psvr_sync_on_recovery_or_compression = true;
    FLAGS_psvr_disable_sync = true;
    {
        auto segment = create_mock_segment_by_cluster("c1", 28);
        segment->SetSpaceSafeTrimLsn(1, 1);
        set_buf_block(_buf_block, 1, 1, gaia_page_size());
        auto task = std::make_shared<Compressor::Task>(segment);
        auto* ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task = task;
        ctx->has_quota = true;
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, 16384, _, _, _))
            .Times(GAIADB_EXTENT_SIZE / 16384)
            .WillRepeatedly(DoAll(SetArgPointee<5>(16384),
                    Return(db::Status(db::Code::kOk))));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .Times(GAIADB_EXTENT_SIZE / 16384)
            .WillRepeatedly(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpaceStatus(1))
            .Times(GAIADB_EXTENT_SIZE / 16384)
            .WillRepeatedly(
                    Return(kSpaceStatusDeleted | kSpaceStatusWithPSM));
        EXPECT_CALL(*segment,
                TrimPhysicalPageData(_, 1, 1, _, 16384, false))
            .Times(GAIADB_EXTENT_SIZE / 16384)
            .WillRepeatedly(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
            .WillOnce(Return(true))
            .WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(MockExecuteOk));

        _compressor->OnCompletion(ctx);

        ASSERT_EQ(task->offset, GAIADB_EXTENT_SIZE);
        ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;
    FLAGS_psvr_sync_on_recovery_or_compression =
            old_sync_on_recovery_or_compression;
    FLAGS_psvr_disable_sync = old_disable_sync;

    _compressor->_stopped = true;
    FLAGS_psvr_enable_trim_free_extent = old_enable_trim_free_extent;
    BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    END_OF_CASE;
}

TEST_F(CompressTests, test_TrimFreeExtentQuotaAndBuffer) {
    const bool old_enable_trim_free_extent =
            FLAGS_psvr_enable_trim_free_extent;
    FLAGS_psvr_enable_trim_free_extent = true;
    _compressor->_stopped = false;
    _compressor->_trim_free_extent_task.reset(
            new Compressor::TrimFreeExtentTask(1));
    _cluster->_in_backup._in_backup.store(-1);
    _cluster->_in_backup._change_time.store(
            base::cpuwide_time_us() - get_heartbeat_interval_us() * 11);
    _cluster->_in_backup._lease.store(base::cpuwide_time_us() + get_heartbeat_interval_us() * 1000);

    {
        auto segment = create_mock_segment_by_cluster("c1", 29);
        auto* ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(nullptr));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
            .WillOnce(Invoke(MockScheduleOk));

        std::thread trim_thread([&]() {
            _compressor->OnCompletion(ctx);
        });
        trim_thread.join();

        ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 30);
        auto* ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(_buf_block));
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
            .WillOnce(Return(false));

        std::thread trim_thread([&]() {
            _compressor->OnCompletion(ctx);
        });
        trim_thread.join();

        ASSERT_EQ(ctx->interrupt_by_quota_count, 1);
        delete ctx;
        ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    _compressor->_stopped = true;
    FLAGS_psvr_enable_trim_free_extent = old_enable_trim_free_extent;
    END_OF_CASE;
}

TEST_F(CompressTests, test_TrimFreeExtentEarlyExit) {
    const bool old_enable_trim_free_extent =
            FLAGS_psvr_enable_trim_free_extent;
    _compressor->_stopped = false;
    _compressor->_trim_free_extent_task.reset(
            new Compressor::TrimFreeExtentTask(1));
    EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
        .Times(AnyNumber())
        .WillRepeatedly(Return(_buf_block));

    {
        FLAGS_psvr_enable_trim_free_extent = false;
        auto segment = create_mock_segment_by_cluster("c1", 1);
        auto ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));

        _compressor->OnCompletion(ctx);

        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        FLAGS_psvr_enable_trim_free_extent = true;
        auto segment = create_mock_segment_by_cluster("c1", 2);
        segment->_recovery_info.stopped = false;
        auto ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));

        _compressor->OnCompletion(ctx);

        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 3);
        _cluster->_in_backup._in_backup.store(1);
        _cluster->_in_backup._lease.store(base::cpuwide_time_us() + get_heartbeat_interval_us() * 1000);
        auto ctx = new Compressor::Context(
                Compressor::Action::kTrimFreeExtent, 0);
        ctx->compress_task.reset(new Compressor::Task(segment));
        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));

        _compressor->OnCompletion(ctx);

        ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
        _compressor->_trim_free_extent_task->Finish(0);
    } END_OF_CASE;

    _compressor->_stopped = true;
    FLAGS_psvr_enable_trim_free_extent = old_enable_trim_free_extent;
    END_OF_CASE;
}

TEST_F(CompressTests, test_CalcPriorityForFreeExtent) {
    const bool old_enable_trim_free_extent =
            FLAGS_psvr_enable_trim_free_extent;
    const uint32_t old_max_task_num =
            FLAGS_psvr_trim_free_extent_max_task_num_per_store;
    FLAGS_psvr_enable_trim_free_extent = true;
    FLAGS_psvr_trim_free_extent_max_task_num_per_store = 1;
    _compressor->_stopped = false;
    _compressor->_trim_free_extent_task.reset(
            new Compressor::TrimFreeExtentTask(1));

    auto segment = create_mock_segment_by_cluster(
            "c1", 10, "./data/", 32ul << 30, Segment::Status::kOpen);
    segment->_psm_info = g_mock_psminfo;
    segment->_segment_physical_size.store(32ul << 30, std::memory_order_relaxed);
    _control->_segment_manager->AddSegment(segment);
    _cluster->_in_backup._in_backup.store(-1);
    _cluster->_in_backup._change_time.store(
            base::cpuwide_time_us() - get_heartbeat_interval_us() * 11);
    _cluster->_in_backup._lease.store(base::cpuwide_time_us() + get_heartbeat_interval_us() * 1000);

    EXPECT_CALL(*g_mock_psminfo, GetOrRefreshNodes(_, _))
        .WillOnce(Invoke([](std::vector<base::EndPoint>* nodes, bool) {
            base::ip_t ip;
            if (base::str2ip("127.0.0.1", &ip) != 0) {
                return false;
            }
            nodes->emplace_back(ip, 8080);
            return true;
        }));
    EXPECT_CALL(*_mock_client, ListSegment(_, _))
        .WillOnce(Invoke([](RpcListSegmentCtx* ctx, ggpb::Closure*) {
            ctx->status = RpcCode::kSuccess;
            ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
            auto* segment = ctx->response.add_segments();
            segment->set_segment_id(10);
            segment->set_total_extent_num(4);
            segment->set_free_extent_num(3);
        }));
    EXPECT_CALL(*_mock_thread_pool, Execute(_))
        .WillOnce(Invoke(MockExecuteOk));
    EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
        .WillOnce(Invoke(MockScheduleOk));

    auto* ctx = new Compressor::Context(
            Compressor::Action::kCalcPriorityForFreeExtent);
    _compressor->OnCompletion(ctx);

    ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
    ASSERT_GT(segment->stat_last_trim_extent_time(), 0);

    _compressor->_stopped = true;
    FLAGS_psvr_enable_trim_free_extent = old_enable_trim_free_extent;
    FLAGS_psvr_trim_free_extent_max_task_num_per_store = old_max_task_num;
    END_OF_CASE;
}

TEST_F(CompressTests, test_CalcPriorityForFreeExtentFilters) {
    const bool old_enable_trim_free_extent =
            FLAGS_psvr_enable_trim_free_extent;
    const uint32_t old_max_task_num =
            FLAGS_psvr_trim_free_extent_max_task_num_per_store;
    const int64_t old_min_interval =
            FLAGS_psvr_trim_free_extent_min_interval_us;
    FLAGS_psvr_enable_trim_free_extent = true;
    FLAGS_psvr_trim_free_extent_max_task_num_per_store = 1;
    FLAGS_psvr_trim_free_extent_min_interval_us = 1;
    _compressor->_stopped = false;
    _compressor->_trim_free_extent_task.reset(
            new Compressor::TrimFreeExtentTask(1));

    auto valid = create_mock_segment_by_cluster(
            "c1", 30, "./data/", 32ul << 30, Segment::Status::kOpen);
    valid->_psm_info = g_mock_psminfo;
    auto recovery = create_mock_segment_by_cluster(
            "c1", 31, "./data/", 32ul << 30, Segment::Status::kOpen);
    recovery->_psm_info = g_mock_psminfo;
    recovery->_recovery_status = gaiadb::RECOVERY_IN;
    auto inactive = create_mock_segment_by_cluster(
            "c1", 32, "./data/", 32ul << 30, Segment::Status::kCreating);
    inactive->_psm_info = g_mock_psminfo;
    auto recent = create_mock_segment_by_cluster(
            "c1", 33, "./data/", 32ul << 30, Segment::Status::kOpen);
    recent->_psm_info = g_mock_psminfo;
    recent->set_stat_last_trim_extent_time(
            base::cpuwide_time_us() + 1000000);
    auto store_full = create_mock_segment_by_cluster(
            "c1", 34, "./data/", 32ul << 30, Segment::Status::kOpen);
    store_full->_psm_info = g_mock_psminfo;
    valid->_segment_physical_size.store(32ul << 30, std::memory_order_relaxed);
    recovery->_segment_physical_size.store(32ul << 30, std::memory_order_relaxed);
    inactive->_segment_physical_size.store(32ul << 30, std::memory_order_relaxed);
    recent->_segment_physical_size.store(32ul << 30, std::memory_order_relaxed);
    store_full->_segment_physical_size.store(32ul << 30, std::memory_order_relaxed);

    _control->segment_manager()->AddSegment(valid);
    _control->segment_manager()->AddSegment(recovery);
    _control->segment_manager()->AddSegment(inactive);
    _control->segment_manager()->AddSegment(recent);
    _control->segment_manager()->AddSegment(store_full);
    _cluster->_in_backup._in_backup.store(-1);
    _cluster->_in_backup._change_time.store(
            base::cpuwide_time_us() - get_heartbeat_interval_us() * 11);
    _cluster->_in_backup._lease.store(base::cpuwide_time_us() + get_heartbeat_interval_us() * 1000);

    EXPECT_CALL(*g_mock_psminfo, GetOrRefreshNodes(_, _))
        .WillOnce(Invoke([](std::vector<base::EndPoint>* nodes, bool) {
            base::ip_t ip;
            if (base::str2ip("127.0.0.1", &ip) != 0) {
                return false;
            }
            nodes->emplace_back(ip, 8080);
            return true;
        }));
    EXPECT_CALL(*_mock_client, ListSegment(_, _))
        .WillOnce(Invoke([](RpcListSegmentCtx* rpc_ctx, ggpb::Closure*) {
            rpc_ctx->status = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
            for (uint32_t segment_id : {30, 31, 32, 33, 34}) {
                auto* segment = rpc_ctx->response.add_segments();
                segment->set_segment_id(segment_id);
                segment->set_total_extent_num(4);
                segment->set_free_extent_num(3);
            }
        }));
    EXPECT_CALL(*_mock_thread_pool, Execute(_))
        .WillOnce(Invoke(MockExecuteOk));
    EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
        .WillOnce(Invoke(MockScheduleOk));

    auto* ctx = new Compressor::Context(
            Compressor::Action::kCalcPriorityForFreeExtent);
    _compressor->OnCompletion(ctx);

    ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
    _compressor->_trim_free_extent_task->Finish(0);
    FLAGS_psvr_enable_trim_free_extent = old_enable_trim_free_extent;
    FLAGS_psvr_trim_free_extent_max_task_num_per_store = old_max_task_num;
    FLAGS_psvr_trim_free_extent_min_interval_us = old_min_interval;
    _compressor->_stopped = true;
    END_OF_CASE;
}

TEST_F(CompressTests, test_CalcPriorityForFreeExtentRpcErrorAndBackup) {
    const bool old_enable_trim_free_extent =
            FLAGS_psvr_enable_trim_free_extent;
    FLAGS_psvr_enable_trim_free_extent = true;
    _compressor->_stopped = false;
    _compressor->_trim_free_extent_task.reset(
            new Compressor::TrimFreeExtentTask(1));

    auto segment = create_mock_segment_by_cluster(
            "c1", 50, "./data/", 32ul << 30, Segment::Status::kOpen);
    segment->_psm_info = g_mock_psminfo;
    _control->segment_manager()->AddSegment(segment);
    _cluster->_in_backup._in_backup.store(1);
    _cluster->_in_backup._lease.store(base::cpuwide_time_us() + get_heartbeat_interval_us() * 1000);

    EXPECT_CALL(*g_mock_psminfo, GetOrRefreshNodes(_, _))
        .Times(2)
        .WillRepeatedly(Invoke([](std::vector<base::EndPoint>* nodes, bool) {
            base::ip_t ip;
            if (base::str2ip("127.0.0.1", &ip) != 0) {
                return false;
            }
            nodes->emplace_back(ip, 8080);
            return true;
        }));
    EXPECT_CALL(*_mock_client, ListSegment(_, _))
        .WillOnce(Invoke([](RpcListSegmentCtx* rpc_ctx, ggpb::Closure*) {
            rpc_ctx->status = RpcCode::kCntlFailed;
        }))
        .WillOnce(Invoke([](RpcListSegmentCtx* rpc_ctx, ggpb::Closure*) {
            rpc_ctx->status = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_TIMEOUT);
        }));
    EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
        .Times(2)
        .WillRepeatedly(Invoke(MockScheduleOk));

    auto* ctx = new Compressor::Context(
            Compressor::Action::kCalcPriorityForFreeExtent);
    _compressor->OnCompletion(ctx);
    ctx = new Compressor::Context(
            Compressor::Action::kCalcPriorityForFreeExtent);
    _compressor->OnCompletion(ctx);

    ASSERT_EQ(segment->stat_last_trim_extent_time(), 0);
    ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
    _compressor->_trim_free_extent_task->Finish(0);
    _compressor->_stopped = true;
    FLAGS_psvr_enable_trim_free_extent = old_enable_trim_free_extent;
    END_OF_CASE;
}

TEST_F(CompressTests, test_CalcPriorityForFreeExtentSortBySize) {
    const bool old_enable_trim_free_extent =
            FLAGS_psvr_enable_trim_free_extent;
    const uint32_t old_max_task_num =
            FLAGS_psvr_trim_free_extent_max_task_num_per_store;
    FLAGS_psvr_enable_trim_free_extent = true;
    FLAGS_psvr_trim_free_extent_max_task_num_per_store = 1;
    _compressor->_stopped = false;
    _compressor->_trim_free_extent_task.reset(
            new Compressor::TrimFreeExtentTask(1));

    auto more_free = create_mock_segment_by_cluster(
            "c1", 60, "./data/", 32ul << 30, Segment::Status::kOpen);
    auto less_free = create_mock_segment_by_cluster(
            "c1", 61, "./data/", 32ul << 30, Segment::Status::kOpen);
    more_free->_psm_info = g_mock_psminfo;
    less_free->_psm_info = g_mock_psminfo;
    more_free->_segment_physical_size.store(32ul << 30, std::memory_order_relaxed);
    less_free->_segment_physical_size.store(32ul << 30, std::memory_order_relaxed);
    _control->segment_manager()->AddSegment(less_free);
    _control->segment_manager()->AddSegment(more_free);
    _cluster->_in_backup._in_backup.store(-1);
    _cluster->_in_backup._change_time.store(
            base::cpuwide_time_us() - get_heartbeat_interval_us() * 11);
    _cluster->_in_backup._lease.store(base::cpuwide_time_us() + get_heartbeat_interval_us() * 1000);

    EXPECT_CALL(*g_mock_psminfo, GetOrRefreshNodes(_, _))
        .WillOnce(Invoke([](std::vector<base::EndPoint>* nodes, bool) {
            base::ip_t ip;
            if (base::str2ip("127.0.0.1", &ip) != 0) {
                return false;
            }
            nodes->emplace_back(ip, 8080);
            return true;
        }));
    EXPECT_CALL(*_mock_client, ListSegment(_, _))
        .WillOnce(Invoke([](RpcListSegmentCtx* rpc_ctx, ggpb::Closure*) {
            rpc_ctx->status = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
            auto* first = rpc_ctx->response.add_segments();
            first->set_segment_id(60);
            first->set_total_extent_num(4);
            first->set_free_extent_num(3);
            auto* second = rpc_ctx->response.add_segments();
            second->set_segment_id(61);
            second->set_total_extent_num(4);
            second->set_free_extent_num(1);
        }));
    EXPECT_CALL(*_mock_thread_pool, Execute(_))
        .WillOnce(Invoke(MockExecuteOk));
    EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
        .WillOnce(Invoke(MockScheduleOk));

    auto* ctx = new Compressor::Context(
            Compressor::Action::kCalcPriorityForFreeExtent);
    _compressor->OnCompletion(ctx);

    ASSERT_GT(more_free->stat_last_trim_extent_time(), 0);
    ASSERT_EQ(less_free->stat_last_trim_extent_time(), 0);
    ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
    _compressor->_trim_free_extent_task->Finish(0);
    _compressor->_stopped = true;
    FLAGS_psvr_enable_trim_free_extent = old_enable_trim_free_extent;
    FLAGS_psvr_trim_free_extent_max_task_num_per_store = old_max_task_num;
    END_OF_CASE;
}

TEST_F(CompressTests, test_CalcPriorityForFreeExtentMultipleStores) {
    const bool old_enable_trim_free_extent =
            FLAGS_psvr_enable_trim_free_extent;
    const uint32_t old_max_task_num =
            FLAGS_psvr_trim_free_extent_max_task_num_per_store;
    FLAGS_psvr_enable_trim_free_extent = true;
    FLAGS_psvr_trim_free_extent_max_task_num_per_store = 1;
    _compressor->_stopped = false;
    _compressor->_store_count = 2;
    _compressor->_trim_free_extent_task.reset(
            new Compressor::TrimFreeExtentTask(2));
    _control->_segment_manager.reset(new SegmentManager);
    _control->segment_manager()->Start(2);

    auto first = std::make_shared<Segment>(_control, "c1", 70,
            Segment::kUnknownReplicaID, Segment::kUnknownVersion,
            32ul << 30, true, Segment::Status::kOpen, "./data/c1/70", 0,
            _cluster);
    auto same_store_second = std::make_shared<Segment>(_control, "c1", 71,
            Segment::kUnknownReplicaID, Segment::kUnknownVersion,
            32ul << 30, true, Segment::Status::kOpen, "./data/c1/71", 0,
            _cluster);
    auto same_store_third = std::make_shared<Segment>(_control, "c1", 72,
            Segment::kUnknownReplicaID, Segment::kUnknownVersion,
            32ul << 30, true, Segment::Status::kOpen, "./data/c1/72", 0,
            _cluster);
    auto second_store = std::make_shared<Segment>(_control, "c1", 73,
            Segment::kUnknownReplicaID, Segment::kUnknownVersion,
            32ul << 30, true, Segment::Status::kOpen, "./data/c1/73", 1,
            _cluster);
    first->_psm_info = g_mock_psminfo;
    same_store_second->_psm_info = g_mock_psminfo;
    same_store_third->_psm_info = g_mock_psminfo;
    second_store->_psm_info = g_mock_psminfo;
    first->_segment_physical_size.store(32ul << 30, std::memory_order_relaxed);
    same_store_second->_segment_physical_size.store(32ul << 30, std::memory_order_relaxed);
    same_store_third->_segment_physical_size.store(32ul << 30, std::memory_order_relaxed);
    second_store->_segment_physical_size.store(32ul << 30, std::memory_order_relaxed);
    _control->segment_manager()->AddSegment(first);
    _control->segment_manager()->AddSegment(same_store_second);
    _control->segment_manager()->AddSegment(same_store_third);
    _control->segment_manager()->AddSegment(second_store);
    _cluster->_in_backup._in_backup.store(-1);
    _cluster->_in_backup._change_time.store(
            base::cpuwide_time_us() - get_heartbeat_interval_us() * 11);
    _cluster->_in_backup._lease.store(base::cpuwide_time_us() + get_heartbeat_interval_us() * 1000);
    ASSERT_TRUE(_compressor->_trim_free_extent_task->CanRun(0, 1));
    ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));

    EXPECT_CALL(*g_mock_psminfo, GetOrRefreshNodes(_, _))
        .WillOnce(Invoke([](std::vector<base::EndPoint>* nodes, bool) {
            base::ip_t ip;
            if (base::str2ip("127.0.0.1", &ip) != 0) {
                return false;
            }
            nodes->emplace_back(ip, 8080);
            return true;
        }));
    EXPECT_CALL(*_mock_client, ListSegment(_, _))
        .WillOnce(Invoke([](RpcListSegmentCtx* rpc_ctx, ggpb::Closure*) {
            rpc_ctx->status = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
            for (uint32_t segment_id : {70, 71, 72, 73}) {
                auto* segment = rpc_ctx->response.add_segments();
                segment->set_segment_id(segment_id);
                segment->set_total_extent_num(4);
                segment->set_free_extent_num(3);
            }
        }));
    EXPECT_CALL(*_mock_thread_pool, Execute(_))
        .Times(1)
        .WillRepeatedly(Invoke(MockExecuteOk));
    EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
        .WillOnce(Invoke(MockScheduleOk));

    auto* ctx = new Compressor::Context(
            Compressor::Action::kCalcPriorityForFreeExtent);
    _compressor->OnCompletion(ctx);

    ASSERT_EQ(first->stat_last_trim_extent_time(), 0);
    ASSERT_EQ(same_store_second->stat_last_trim_extent_time(), 0);
    ASSERT_EQ(same_store_third->stat_last_trim_extent_time(), 0);
    ASSERT_GT(second_store->stat_last_trim_extent_time(), 0);
    ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(0, 1));
    ASSERT_FALSE(_compressor->_trim_free_extent_task->CanRun(1, 1));
    _compressor->_trim_free_extent_task->Finish(0);
    _compressor->_trim_free_extent_task->Finish(1);
    _compressor->_stopped = true;
    FLAGS_psvr_enable_trim_free_extent = old_enable_trim_free_extent;
    FLAGS_psvr_trim_free_extent_max_task_num_per_store = old_max_task_num;
    END_OF_CASE;
}

TEST_F(CompressTests, test_Start_Stop) {
    {
        EXPECT_CALL(*_mock_quota_thread, Start(_, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, _)).WillOnce(Return(false));
        ASSERT_FALSE(_compressor->Start(1));
    }

    {
        EXPECT_CALL(*_mock_quota_thread, Start(_, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
            .WillOnce(Invoke(MockScheduleOk))
            .WillOnce(Invoke(MockScheduleOk))
            .WillOnce(Invoke(MockScheduleOk));
        ASSERT_TRUE(_compressor->Start(1));
        ASSERT_EQ(_compressor->GetCompressRate(), 0.0);
    }
    {
        _compressor->_control.reset();
        ASSERT_FALSE(_compressor->Start(1));
    }
    {
        EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillOnce(Return());
        _compressor->Stop();
    }
}

TEST_F(CompressTests, test_IncOrDecThreadNum) {
    _compressor->_store_count = FLAGS_multi_psvr_compress_thread_num + 1;
    _compressor->_thread_num = FLAGS_multi_psvr_compress_thread_num;
    {
        _compressor->_stopped = false;
        FLAGS_multi_psvr_compress_thread_num = 0;
        _compressor->IncOrDecThreadNum();
        FLAGS_multi_psvr_compress_thread_num = _compressor->_thread_num;
    }
    {
        // inc
        FLAGS_multi_psvr_compress_thread_num += 1;
        EXPECT_CALL(*_mock_thread_pool, IncThread(_)).WillOnce(Return(true));
        _compressor->IncOrDecThreadNum();
    }
    {
        // dec
        std::vector<MockExecutor<Compressor::Context, thread::TaskContext>::ThreadType> vec;
        FLAGS_multi_psvr_compress_thread_num -= 1;
        EXPECT_CALL(*_mock_thread_pool, DecThread(_)).WillOnce(Return(vec));
        _compressor->IncOrDecThreadNum();
    }
    _compressor->_stopped = true;
}


BMOCK_NS_METHOD1(gaiadb::common, terminate, void(int));

TEST_F(CompressTests, test_Execute) {
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillOnce(Return());
    {
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_))
            .WillOnce(Invoke(MockExecuteOk));
        auto ctx = new Compressor::Context(Compressor::Action::kCalcPriority);
        _compressor->Execute(ctx);
    }
    {
        _compressor->_stopped = true;
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_))
            .WillOnce(Return(false));
        auto ctx = new Compressor::Context(Compressor::Action::kCalcPriority);
        _compressor->Execute(ctx);
    }
    {
        _compressor->_stopped = false;
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_))
            .WillOnce(Return(false));
        BMOCK_NS_RESUME(gaiadb::common, terminate, void(int));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaiadb::common, terminate), terminate(_))
            .WillOnce(Return());
        auto ctx = new Compressor::Context(Compressor::Action::kCalcPriority);
        _compressor->Execute(ctx);
        delete ctx;
    }
    BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
}

TEST_F(CompressTests, test_CompressList) {
    {
        SegmentPtr segment = create_segment();
        ASSERT_TRUE(_compressor->AddSegmentToCompressList(segment));
        ASSERT_FALSE(_compressor->AddSegmentToCompressList(segment));
        ASSERT_FALSE(_compressor->AddSegmentToCompressList(segment, true));
    }
    {
        SegmentPtr segment = create_segment();
        ASSERT_TRUE(_compressor->AddSegmentToCompressList(segment, true));
        ASSERT_FALSE(_compressor->AddSegmentToCompressList(segment));
        ASSERT_FALSE(_compressor->AddSegmentToCompressList(segment, true));
    }

    SegmentPtr segment = create_segment();
    ASSERT_TRUE(_compressor->AddSegmentToCompressList(segment, true));
    pspb::ListCompressSegmentResponse response;
    _compressor->GetTasks(&response);
    ASSERT_EQ(1, response.segments_size());

    ASSERT_TRUE(_compressor->DropSegmentFromCompressList(segment));
}

TEST_F(CompressTests, test_CompressHelpers) {
    _compressor->_stopped = false;
    ASSERT_EQ(_compressor->GetStoreCompressRate(-1), 0.0);
    ASSERT_EQ(_compressor->GetStoreCompressRate(1), 0.0);
    ASSERT_EQ(_compressor->GetCompressRate(), 0.0);

    _compressor->_stores[0]->compress_rate = 2.5;
    ASSERT_EQ(_compressor->GetStoreCompressRate(0), 2.5);
    ASSERT_EQ(_compressor->GetCompressRate(), 2.5);

    auto segment = create_segment_by_cluster("c1", 1);
    ASSERT_FALSE(_compressor->DropSegmentFromCompressList(segment));
    ASSERT_TRUE(_compressor->AddSegmentToCompressList(segment));

    pspb::ListCompressSegmentResponse response;
    _compressor->GetTasks(&response);
    ASSERT_EQ(response.segments_size(), 1);

    segment.reset();
    response.Clear();
    _compressor->GetTasks(&response);
    ASSERT_EQ(response.segments_size(), 0);

    _compressor->_stopped = true;
    ASSERT_EQ(_compressor->GetStoreCompressRate(0), 0.0);
    ASSERT_EQ(_compressor->GetCompressRate(), 0.0);
    END_OF_CASE;
}

TEST_F(CompressTests, test_Schedule) {
    {
        auto* ctx = new Compressor::Context(Compressor::Action::kStoreCompress);
        _compressor->Schedule(ctx TRACE_FILE_LINE_CC, 10, false);
    }

    _compressor->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillOnce(Return());
    {
        auto* ctx = new Compressor::Context(Compressor::Action::kCalcPriority);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _compressor->Schedule(ctx TRACE_FILE_LINE_CC, 0, true);
    }

    {
        auto* ctx = new Compressor::Context(Compressor::Action::kCompressSegment);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _compressor->Schedule(ctx TRACE_FILE_LINE_CC, 10, false);
    }
}

TEST_F(CompressTests, test_OnCompletion) {
    {
        // stopped
        _compressor->_stopped = true;
        auto* ctx = new Compressor::Context(Compressor::Action::kCompressSegment);
        _compressor->OnCompletion(ctx);
    }
}

TEST_F(CompressTests, test_CalcPriority) {
    _compressor->_stopped = false;
    FLAGS_psvr_enable_append_file = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillOnce(Return());
    {
        // disable it
        FLAGS_psvr_enable_compression = false;
        auto* ctx = new Compressor::Context(Compressor::Action::kCalcPriority, 0);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _compressor->OnCompletion(ctx);
        FLAGS_psvr_enable_compression = true;
    }
    {
        // dblwr enabled: skip compression scheduling
        FLAGS_psvr_enable_append_file = true;
        FLAGS_psvr_dblwr_max_page_num = 128;
        auto* ctx = new Compressor::Context(Compressor::Action::kCalcPriority, 0);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _compressor->OnCompletion(ctx);
        FLAGS_psvr_enable_append_file = false;
    }
    {
        // not segments
        FLAGS_psvr_compress_store_max_task_num = 1;
        auto* ctx = new Compressor::Context(Compressor::Action::kCalcPriority, 0);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _compressor->OnCompletion(ctx);
    }

    {
        // in recovery
        std::shared_ptr<MockSegment> mock_segment = nullptr;
        mock_segment = create_mock_segment_by_cluster("c1", 1);
        mock_segment->_recovery_status = gaiadb::RECOVERY_IN;
        EXPECT_CALL(*mock_segment, UpdateStatCompress(_, _)).WillRepeatedly(Return());
        _control->_segment_manager->AddSegment(mock_segment);
    }
    {
        // not acitve
        std::shared_ptr<MockSegment> mock_segment = nullptr;
        mock_segment = create_mock_segment_by_cluster("c1", 2);
        EXPECT_CALL(*mock_segment, UpdateStatCompress(_, _)).WillRepeatedly(Return());
        _control->_segment_manager->AddSegment(mock_segment);
    }
    {
        // is stoped
        std::shared_ptr<MockSegment> mock_segment = nullptr;
        mock_segment = create_mock_segment_by_cluster("c1", 3);
        mock_segment->_stopped = true;
        mock_segment->_stat_compress.sort_data_size_mb = 0;
        mock_segment->_stat_compress.sort_last_compress_time_s = base::gettimeofday_s();
        EXPECT_CALL(*mock_segment, UpdateStatCompress(_, _)).WillRepeatedly(Return());
        _control->_segment_manager->AddSegment(mock_segment);
    }
    {
        // data size small
        std::shared_ptr<MockSegment> mock_segment = nullptr;
        mock_segment = create_mock_segment_by_cluster("c1", 4);
        mock_segment->_status = Segment::Status::kOpen;
        mock_segment->_stat_compress.sort_data_size_mb = 10 << 20;
        mock_segment->_stat_compress.sort_last_compress_time_s = base::gettimeofday_s();
        EXPECT_CALL(*mock_segment, UpdateStatCompress(_, _)).WillRepeatedly(Return());
        _control->_segment_manager->AddSegment(mock_segment);
    }

    {
        // not data_updated
        std::shared_ptr<MockSegment> mock_segment = nullptr;
        mock_segment = create_mock_segment_by_cluster("c1", 5);
        mock_segment->_status = Segment::Status::kOpen;
        mock_segment->_stat_compress.sort_data_size_mb = 32<<20;
        mock_segment->_stat_compress.data_updated = false;
        mock_segment->_stat_compress.sort_compress_times = 1;
        mock_segment->_stat_compress.sort_drop_space_num = 1;
        mock_segment->_stat_compress.sort_update_extent_num = 1;
        mock_segment->_stat_compress.sort_last_compress_time_s = base::gettimeofday_s();
        EXPECT_CALL(*mock_segment, UpdateStatCompress(_, _)).WillRepeatedly(Return());
        _control->_segment_manager->AddSegment(mock_segment);
    }

    {
        // sort_last_compress_time_s
        std::shared_ptr<MockSegment> mock_segment = nullptr;
        mock_segment = create_mock_segment_by_cluster("c1", 6);
        mock_segment->_status = Segment::Status::kOpen;
        mock_segment->_stat_compress.sort_data_size_mb = 32<<20;
        mock_segment->_stat_compress.data_updated = false;
        mock_segment->_stat_compress.sort_compress_times = 1;
        mock_segment->_stat_compress.sort_drop_space_num = 1;
        mock_segment->_stat_compress.sort_update_extent_num = 1;
        mock_segment->_stat_compress.sort_last_compress_time_s = base::gettimeofday_s() + 1;
        EXPECT_CALL(*mock_segment, UpdateStatCompress(_, _)).WillRepeatedly(Return());
        _control->_segment_manager->AddSegment(mock_segment);
    }

    {
        // sort_data_size_mb
        std::shared_ptr<MockSegment> mock_segment = nullptr;
        mock_segment = create_mock_segment_by_cluster("c1", 7);
        mock_segment->_status = Segment::Status::kOpen;
        mock_segment->_stat_compress.sort_data_size_mb = 22<<20;
        mock_segment->_stat_compress.data_updated = false;
        mock_segment->_stat_compress.sort_compress_times = 1;
        mock_segment->_stat_compress.sort_drop_space_num = 1;
        mock_segment->_stat_compress.sort_update_extent_num = 1;
        mock_segment->_stat_compress.sort_last_compress_time_s = base::gettimeofday_s();
        EXPECT_CALL(*mock_segment, UpdateStatCompress(_, _)).WillRepeatedly(Return());
        _control->_segment_manager->AddSegment(mock_segment);
    }

    {
        // sort_update_extent_num
        std::shared_ptr<MockSegment> mock_segment = nullptr;
        mock_segment = create_mock_segment_by_cluster("c1", 8);
        mock_segment->_status = Segment::Status::kOpen;
        mock_segment->_stat_compress.sort_data_size_mb = 32<<20;
        mock_segment->_stat_compress.data_updated = false;
        mock_segment->_stat_compress.sort_compress_times = 1;
        mock_segment->_stat_compress.sort_drop_space_num = 1;
        mock_segment->_stat_compress.sort_update_extent_num = 2;
        mock_segment->_stat_compress.sort_last_compress_time_s = base::gettimeofday_s();
        EXPECT_CALL(*mock_segment, UpdateStatCompress(_, _)).WillRepeatedly(Return());
        _control->_segment_manager->AddSegment(mock_segment);
    }

    {
        // sort_drop_space_num
        std::shared_ptr<MockSegment> mock_segment = nullptr;
        mock_segment = create_mock_segment_by_cluster("c1", 9);
        mock_segment->_status = Segment::Status::kOpen;
        mock_segment->_stat_compress.sort_data_size_mb = 32<<20;
        mock_segment->_stat_compress.data_updated = false;
        mock_segment->_stat_compress.sort_compress_times = 1;
        mock_segment->_stat_compress.sort_drop_space_num = 2;
        mock_segment->_stat_compress.sort_update_extent_num = 1;
        mock_segment->_stat_compress.sort_last_compress_time_s = base::gettimeofday_s();
        EXPECT_CALL(*mock_segment, UpdateStatCompress(_, _)).WillRepeatedly(Return());
        _control->_segment_manager->AddSegment(mock_segment);
    }

    {
        // sort_compress_times
        std::shared_ptr<MockSegment> mock_segment = nullptr;
        mock_segment = create_mock_segment_by_cluster("c1", 10);
        mock_segment->_status = Segment::Status::kOpen;
        mock_segment->_stat_compress.sort_data_size_mb = 32<<20;
        mock_segment->_stat_compress.data_updated = false;
        mock_segment->_stat_compress.sort_compress_times = 2;
        mock_segment->_stat_compress.sort_drop_space_num = 1;
        mock_segment->_stat_compress.sort_update_extent_num = 1;
        mock_segment->_stat_compress.sort_last_compress_time_s = base::gettimeofday_s();
        EXPECT_CALL(*mock_segment, UpdateStatCompress(_, _)).WillRepeatedly(Return());
        _control->_segment_manager->AddSegment(mock_segment);
    }

    FLAGS_psvr_compress_store_max_task_num = 2;
    {
        FLAGS_psvr_recover_enable_check = true;
        auto* ctx = new Compressor::Context(Compressor::Action::kCalcPriority, 0);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _compressor->OnCompletion(ctx);
    }

    FLAGS_psvr_compress_store_max_task_num = 3;
    {
        FLAGS_psvr_recover_enable_check = false;
        auto* ctx = new Compressor::Context(Compressor::Action::kCalcPriority, 0);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _compressor->OnCompletion(ctx);
    }

}

TEST_F(CompressTests, test_StoreCompress) {
    _compressor->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillOnce(Return());

    {
        // invalid segment
        {
            auto segment = create_segment_by_cluster("c1", 1);
            _compressor->AddSegmentToCompressList(segment);
        }
        auto segment2 = create_segment_by_cluster("c1", 2);
        _compressor->AddSegmentToCompressList(segment2);

        auto segment3 = create_segment_by_cluster("c1", 3);
        _compressor->AddSegmentToCompressList(segment3);

        FLAGS_psvr_compress_store_inflight_num = 1;
        _compressor->_stores[0]->task_quota->Release(0);
        {
            auto* ctx = new Compressor::Context(Compressor::Action::kStoreCompress, 0);
            EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
            EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
            _compressor->OnCompletion(ctx);
        } END_OF_CASE;
        FLAGS_psvr_compress_store_inflight_num = 2;
        _compressor->_stores[0]->task_quota->Release(0);
        {
            auto* ctx = new Compressor::Context(Compressor::Action::kStoreCompress, 0);
            EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
                .WillOnce(Invoke(MockScheduleOk));
            EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
            _compressor->OnCompletion(ctx);
        } END_OF_CASE;
    }
}

TEST_F(CompressTests, test_FinishCompressSegment) {
    auto segment = create_segment_by_cluster("c1", 1);
    _compressor->AddSegmentToCompressList(segment);

    auto segment2 = create_segment_by_cluster("c1", 2);
    _compressor->AddSegmentToCompressList(segment2);

    {
        _compressor->_stopped = true;
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[segment->store_id()]->compress_tasks.back();
        _compressor->FinishCompressSegment(ctx, false);
    }
    {
        _compressor->_stopped = false;
        EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillOnce(Return());

        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[segment->store_id()]->compress_tasks.back();
        _compressor->FinishCompressSegment(ctx, false);
    }
}

TEST_F(CompressTests, test_CompressSegment) {
    _compressor->_stopped = false;
    _cluster->set_enable_encypt();
    FLAGS_psvr_enable_append_file = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillOnce(Return());

    {
        auto segment = create_segment_by_cluster("c1", 1);
        _compressor->AddSegmentToCompressList(segment);

        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(nullptr));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));

        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[segment->store_id()]->compress_tasks.front();
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // segment is valid
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(_buf_block));
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // segment is invalid
        auto segment = create_segment_by_cluster("c1", 1);
        segment->_stopped = true;
        _compressor->AddSegmentToCompressList(segment);
        segment = nullptr;

        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // segment is stopped
        auto segment = create_segment_by_cluster("c1", 1);
        segment->_stopped = true;
        _compressor->AddSegmentToCompressList(segment);

        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // disable
        FLAGS_psvr_enable_compression = false;
        auto segment = create_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // disable 2
        FLAGS_psvr_enable_compression = true;
        auto segment = create_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(false, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // in check or recovery
        FLAGS_psvr_enable_compression = true;
        auto segment = create_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        segment->TurnOnRecovery(true);
        _compressor->AddSegmentToCompressList(segment);
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // disable segment compress
        FLAGS_psvr_enable_compression = true;
        auto segment = create_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(false, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // update frequently
        FLAGS_psvr_enable_compression = true;
        auto segment = create_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        segment->_stat_compress.sort_update_extent_num = 20000;
        _compressor->AddSegmentToCompressList(segment);
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // finished
        FLAGS_psvr_enable_compression = false;
        auto segment = create_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        ctx->compress_task->offset = ctx->compress_task->size;
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // dblwr enabled: skip compression
        FLAGS_psvr_enable_compression = true;
        FLAGS_psvr_enable_append_file = true;
        FLAGS_psvr_dblwr_max_page_num = 128;
        auto segment = create_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        _compressor->OnCompletion(ctx);
        FLAGS_psvr_enable_append_file = false;
    } END_OF_CASE;

    {
        // get quota fail
        FLAGS_psvr_enable_compression = true;
        auto segment = create_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        ctx->compress_task->offset = 0;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Invoke(MockGetQuotaFail));
        _compressor->OnCompletion(ctx);
        {
            // get quota fail2
            ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = 0;

            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true)).WillOnce(Invoke(MockGetQuotaFail));
            _compressor->OnCompletion(ctx);
        }
        _compressor->_stores[0]->compress_tasks.clear();
    } END_OF_CASE;
    {
        // read fail
        auto segment = create_mock_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        ctx->compress_task->offset = 0;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true)).WillOnce(Return(true));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kBusy)));
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // page_is_corrupted
        auto segment = create_mock_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        ctx->compress_task->offset = 0;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true)).WillOnce(Return(true));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(Return(true));
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // page is empty & trim fail
        auto segment = create_mock_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        ctx->compress_task->offset = 0;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true)).WillOnce(Return(true));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        EXPECT_CALL(*segment, TrimPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kBusy)));
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        segment->SetSpaceSafeTrimLsn(1, 1);

        auto cluster = segment->cluster();
        ASSERT_TRUE(cluster->in_backup());

        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);

        {
            // space_status_is_unknown
            EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
            EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusUnknown));
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
            auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, ggpb::Closure* closure, pspb::Status* status) {
                if (status) {
                    status->set_code(pspb::Status::INVALID);
                }
                if (closure) {
                    closure->Run();
                }
            };
            EXPECT_CALL(*_mock_parser, AddGetSpaceMetaEvent(_ TRACE_MOCK_ARG_CC, _, _, _)).WillOnce(Invoke(fun1));
            EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = 0;
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true)).WillOnce(Return(true));
            _compressor->OnCompletion(ctx);
        } END_OF_CASE;

        {
            // page empty & trim ok
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(DoAll(SetArgPointee<5>(0), Return(db::Status(db::Code::kOk))));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = 0;
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
                .WillOnce(Return(true))
                .WillOnce(Return(true))
                .WillOnce(Invoke(MockGetQuotaFail));
            _compressor->OnCompletion(ctx);
        } END_OF_CASE;

        {
            // page empty & trim ok
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
            EXPECT_CALL(*segment, TrimPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));

            _compressor->AddSegmentToCompressList(segment);
            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = 0;
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
                .WillOnce(Return(true))
                .WillOnce(Return(true))
                .WillOnce(Invoke(MockGetQuotaFail));
            _compressor->OnCompletion(ctx);
        } END_OF_CASE;

        {
            // space_encrypt_status_unknown
            EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusUnknown));
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
            auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, ggpb::Closure* closure, pspb::Status* status) {
                if (status) {
                    status->set_code(pspb::Status::SUCCESS);
                }
                if (closure) {
                    closure->Run();
                }
            };
            EXPECT_CALL(*_mock_parser, AddGetSpaceMetaEvent(_ TRACE_MOCK_ARG_CC, _, _, _)).WillOnce(Invoke(fun1));
            EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = 0;
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true)).WillOnce(Return(true));
            _compressor->OnCompletion(ctx);
        } END_OF_CASE;

        {
            // space_status_is_unknown
            EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
            EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusUnknown));
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
            auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, ggpb::Closure* closure, pspb::Status* status) {
                if (status) {
                    status->set_code(pspb::Status::SUCCESS);
                }
                if (closure) {
                    closure->Run();
                }
            };
            EXPECT_CALL(*_mock_parser, AddGetSpaceMetaEvent(_ TRACE_MOCK_ARG_CC, _, _, _)).WillOnce(Invoke(fun1));
            EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = 0;
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true)).WillOnce(Return(true));
            _compressor->OnCompletion(ctx);
        } END_OF_CASE;

        {
            // space_status_is_deleted & no with psm
            EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
            EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusDeleted));
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
            auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, ggpb::Closure* closure, pspb::Status* status) {
                if (status) {
                    status->set_code(pspb::Status::SUCCESS);
                }
                if (closure) {
                    closure->Run();
                }
            };
            EXPECT_CALL(*_mock_parser, AddGetSpaceMetaEvent(_ TRACE_MOCK_ARG_CC, _, _, _)).WillOnce(Invoke(fun1));
            EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = 0;
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true)).WillOnce(Return(true));
            _compressor->OnCompletion(ctx);
        } END_OF_CASE;

        {
            // in backup & not trim
            EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
            EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusDeleted | kSpaceStatusWithPSM));
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = (16<<10);
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
                //.WillOnce(Return(true))
                //.WillOnce(Return(true))
                .WillOnce(Return(true))
                .WillOnce(Return(true));
            //EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

            _compressor->OnCompletion(ctx);
        } END_OF_CASE;

        {
            _compressor->AddSegmentToCompressList(segment);
            // space_status_is_deleted & with psm & trim ok
            EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
            EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusDeleted | kSpaceStatusWithPSM));
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

            EXPECT_CALL(*segment, TrimPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));

            segment->cluster()->in_backup().Update(false);
            sleep_for(get_heartbeat_interval_us() * 11);
            segment->cluster()->in_backup().Update(false);
            // Keep the lease fresh: subsequent sub-cases in this test rely on the
            // not-in-backup state set above, and InBackup::operator bool() flips
            // back to true once lease + 3*heartbeat_interval expires.
            _cluster->_in_backup._lease.store(base::cpuwide_time_us() + get_heartbeat_interval_us() * 1000);

            EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = (16<<10);
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
                .WillOnce(Return(true))
                .WillOnce(Return(true))
                .WillOnce(Return(true))
                .WillOnce(Return(true));
            _compressor->OnCompletion(ctx);
        } END_OF_CASE;

        {
            _compressor->AddSegmentToCompressList(segment);
            // has space & page rec not empty
            EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
            EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusDeleted | kSpaceStatusWithPSM));
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

            auto page = segment->_space_page_manager->GetOrCreatePage(1, 1);
            LogRecord rec(gaia_apply::MLOG_LSN, nullptr, 0, 99999, 999999, 1/*space*/, 1/*page_no*/, false, 0);
            page->AppendLogRecord(&rec);
            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = (16<<10);
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
                .WillOnce(Return(true))
                .WillOnce(Return(true))
                .WillOnce(Return(true))
                .WillOnce(Return(true));
            EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

            _compressor->OnCompletion(ctx);
        } END_OF_CASE;

        {
            // has space & page_is_compressed
            FLAGS_psvr_enable_check_compress_data = false;
            EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
            EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(DoAll(SetArgPointee<4>(true), Return(db::Status(db::Code::kOk))));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

            EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = 0;
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
                .WillOnce(Return(true))
                .WillOnce(Return(true))
                .WillOnce(Return(true)).WillOnce(Return(true));
            _compressor->OnCompletion(ctx);
        } END_OF_CASE;

        {
            // has space & write ok & FLAGS_psvr_enable_check_compress_data = false
            FLAGS_psvr_enable_check_compress_data = false;
            EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
            EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

            EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));

            EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = 0;
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
                .WillOnce(Return(true))
                .WillOnce(Return(true))
                .WillOnce(Return(true)).WillOnce(Return(true));
            _compressor->OnCompletion(ctx);
        } END_OF_CASE;

        {
            // has space & write ok & FLAGS_psvr_enable_check_compress_data = false
            FLAGS_psvr_enable_check_compress_data = false;
            EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
            EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

            EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));

            EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = 0;
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
                .WillOnce(Return(true))
                .WillOnce(Return(true))
                .WillOnce(Return(true)).WillOnce(Return(true));
            _compressor->OnCompletion(ctx);

        } END_OF_CASE;

        {
            // has space & write ok & FLAGS_psvr_enable_check_compress_data = true
            FLAGS_psvr_enable_check_compress_data = true;
            EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
            EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _))
                .WillOnce(Return(db::Status(db::Code::kOk)))
                .WillOnce(Return(db::Status(db::Code::kOk)));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
                .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)))
                .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

            EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));

            EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = 0;
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
                .WillOnce(Return(true))
                .WillOnce(Return(true))
                .WillOnce(Return(true)).WillOnce(Return(true));
            _compressor->OnCompletion(ctx);

        } END_OF_CASE;

        {
            // has space & write fail
            EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
            EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
            EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
            BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

            EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kBusy)));

            auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
            ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
            ctx->compress_task->offset = 0;
            EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true)).WillOnce(Return(true));
            _compressor->OnCompletion(ctx);
        } END_OF_CASE;

    } END_OF_CASE;

    {
        // space_status_is_deleted & trim fail
        auto segment = create_mock_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        segment->SetSpaceSafeTrimLsn(1, 1);
        EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusDeleted | kSpaceStatusWithPSM));
        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        ctx->compress_task->offset = 0;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true)).WillOnce(Return(true));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, TrimPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kBusy)));
        _compressor->OnCompletion(ctx);
    } END_OF_CASE;

    {
        FLAGS_psvr_enable_compression = true;
        ASSERT_TRUE(FLAGS_psvr_enable_check_compress_data);
        // has space & write ok & FLAGS_psvr_enable_check_compress_data = true && read fail
        auto segment = create_mock_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)))
            .WillOnce(Return(db::Status(db::Code::kBusy)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));

        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        ctx->compress_task->offset = 0;
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true)).WillOnce(Return(true));
        _compressor->OnCompletion(ctx);
        ASSERT_FALSE(FLAGS_psvr_enable_compression);

    } END_OF_CASE;

    {
        // has space & write ok & FLAGS_psvr_enable_check_compress_data = true && is corrupted
        FLAGS_psvr_enable_compression = true;
        ASSERT_TRUE(FLAGS_psvr_enable_check_compress_data);
        auto segment = create_mock_segment_by_cluster("c1", 1);
        segment->SetCompressConfigNoLock(true, "zstd", 6);
        _compressor->AddSegmentToCompressList(segment);
        EXPECT_CALL(*segment, GetSpaceEncryptStatus(_)).WillOnce(Return(kSpaceEncryptStatusWithPSM));
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(true)));

        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));

        auto ctx= new Compressor::Context(Compressor::Action::kCompressSegment, 0);
        ctx->compress_task = _compressor->_stores[0]->compress_tasks.front();
        ctx->compress_task->offset = 0;
        ctx->has_quota = true;
        _compressor->OnCompletion(ctx);
        ASSERT_FALSE(FLAGS_psvr_enable_compression);

        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    } END_OF_CASE;
}

}
}
