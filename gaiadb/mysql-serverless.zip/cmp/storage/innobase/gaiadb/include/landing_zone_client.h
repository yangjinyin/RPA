/*****************************************************************************

Copyright (c) 2022, Baidu and/or its affiliates. All Rights Reserved.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file gaiadb/include/landing_zone_client.h
 client for read/write landing_zone

 Created 11/1/2022 Hongyu Qiao
 *******************************************************/

#ifndef landing_zone_client_h
#define landing_zone_client_h
#include "gaiadb/psm_client/client.h"
#include <gflags/gflags.h>
#include <future>
#include "gaiadb/polar/utils.h"
#include "log0types.h"

DECLARE_bool(enable_quorum_mode);

namespace landing_zone {

class LandingZoneClient;

struct LogInfo {
    lsn_t written_lsn;
    lsn_t checkpoint_lsn;
};

class SendVDLTimer : public raft::RepeatedTimerTask {
public:
    SendVDLTimer();

    virtual ~SendVDLTimer();

    void set_landing_zone_client(LandingZoneClient* lz_client);

    void start_timer();

protected:
    virtual void run() override;

    virtual void on_destroy() override;
private:
    DISALLOW_COPY_AND_ASSIGN(SendVDLTimer);
    LandingZoneClient* _landing_zone_client;
    std::atomic<uint64_t> _vdl_sync_by_timer;
    std::atomic<uint64_t> _wakeup_times;
};

class LogServiceRaftLeaderTracker : public raft::RepeatedTimerTask {
public:
    LogServiceRaftLeaderTracker();
    ~LogServiceRaftLeaderTracker();

    bool check(gaiadb::psm_client::Psmgr_client* client);

    base::EndPoint get_leader();

    void get_peers(std::vector<gaiadb::common::PeerZone> *ls_peers);

    bool refresh_leader();
protected:
    virtual void run() override;

    virtual void on_destroy() override;

    bool refresh_peers();
private:
    bthread::Mutex _lock;
    base::EndPoint _leader_addr;
    std::vector<gaiadb::common::PeerZone> _ls_peers;
    gaiadb::psm_client::Psmgr_client* _psm_client;
};

DECLARE_int32(gaia_redo_store_replicas);

struct PwriteContext;
typedef void (*PwriteCallback)(bool ok, PwriteContext* context);

struct PwriteContext {
    PwriteContext(lsn_t lsn, uint64_t time, int nodes)
        : write_lsn(lsn), start_time(time), node_count(nodes),
          pwrite_status(0), count_down(nodes),
          ls_cost_array_index(0), ls_cost(nullptr), written_lsn(0) {
              if (FLAGS_enable_quorum_mode) {
                ls_cost = new std::string[FLAGS_gaia_redo_store_replicas];
              }
    }

    ~PwriteContext() {
        if (ls_cost != nullptr) {
            delete []ls_cost;
        }
    }

    void set_node_count(int nodes) {
        if (node_count != nodes) {
            node_count = nodes;
            count_down.store(nodes, std::memory_order_relaxed);
        }
    }

    void add_ls_cost (std::string cost) {
        auto index = ls_cost_array_index.fetch_add(1, std::memory_order_relaxed);
        if (ls_cost != nullptr && index < FLAGS_gaia_redo_store_replicas) {
            ls_cost[index] = cost;
        }
    }

    const lsn_t write_lsn;              // update written_lsn in async callback
    const uint64_t start_time;          // for cost time calculation
    int32_t node_count;
    std::atomic<uint64_t> pwrite_status; // high 32bit means finish_count
                                         // low 32bit means success_count
                                        
    std::atomic<int32_t> count_down;    // count down to release PwriteContext, should deal
                                        // cluster node count change during self-healing

    std::atomic<int32_t> ls_cost_array_index;
    std::string* ls_cost; //point to an array for recording log service  pwrite detail cost
    uint64_t written_lsn;
};

class LandingZoneClient {
public:
    LandingZoneClient();

    ~LandingZoneClient();

    bool init(gaiadb::psm_client::Psmgr_client* client);

    void start_send_vdl_timer();

    void stop_send_vdl_timer();

    int pread(
            uint64_t start_lsn,
            uint64_t offset,
            uint64_t len,
            byte* buffer);

    int pwrite(
        uint64_t start_lsn,
        uint64_t offset,
        uint64_t len,
        byte* buffer,
        PwriteCallback callback,
        PwriteContext* context);

    int peer_pwrite_proc(lsn_t vdl, uint64_t epoch, uint64_t mb_epoch, lsn_t start_lsn,
            uint64_t offset, uint64_t len, byte* buffer, PwriteCallback callback,
            PwriteContext* context, const base::EndPoint& endpoint);

    // 0 success, -1 failed
    int increase_epoch();

    void set_membership_epoch(uint64_t membership_epoch);

    // 0 success, -1 failed
    int send_vdl(uint64_t vdl);

    uint64_t get_vdl_sync_by_pwrite();

    void set_vdl_sync_by_pwrite(uint64_t vdl);

    int init_membership_epoch();

    lsn_t last_increase_epoch_lsn();

    static std::atomic<uint64_t> redo_log_id;

    void refresh_ls_leader() { _ls_tracker.refresh_leader(); }

    const LogInfo get_log_info();

private:
    DISALLOW_COPY_AND_ASSIGN(LandingZoneClient);
    std::atomic<uint64_t> _epoch;
    std::atomic<uint64_t> _membership_epoch;
    gaiadb::psm_client::Psmgr_client* _psm_client;
    LogServiceRaftLeaderTracker _ls_tracker;
    SendVDLTimer _send_vdl_timer;
    std::atomic<uint64_t> _vdl_sync_by_pwrite;
    std::atomic<lsn_t> last_increase_epoch_lsn_;
    gaiadb::polar::RpcClient polar_rpc_client_;
};

extern LandingZoneClient g_landing_zone_client;

dberr_t landing_zone_read(byte* buf, os_offset_t offset,
    ulint n, uint64_t start_lsn);
dberr_t landing_zone_write(byte* buf, os_offset_t offset,
    ulint n, uint64_t start_lsn, uint64_t new_write_lsn);
void recovered_lsn_valid(lsn_t lsn);
lsn_t get_last_increase_epoch_lsn();
void landing_zone_timer_start();
void landing_zone_timer_stop();
} // namespace landing_zone

#endif // ut0landing_zone_client_h
