/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_zone.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/clear_zone.h"

namespace psvr {
namespace gaia {

int ClearZone::Run() {
    RpcStatus status;

    if (_address.empty() || _port < 1) {
        print_error("miss --address and --port");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    if (_type.empty()) {
        print_error("miss --type");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Clear node %s:%d zone?", _address.c_str(), _port);
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    if (_type == "ls") {
        lspb::lsrv_clear_zone_request request;
        lspb::lsrv_clear_zone_response response;

        if (!_cluster_id.empty()) {
            request.set_cluster_id(_cluster_id);
        }

        _client.Call(_log_id, node, &lspb::LogServiceService_Stub::clear_zone, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        }
        response.mutable_status()->set_code(lspb::GIE_FAIL);
        response.mutable_status()->set_msg("clear failed");
        return Output(response);
    } else if (_type == "cmp") {
        computenode::clear_zone_request request;
        computenode::clear_zone_response response;

        if (!_cluster_id.empty()) {
            request.set_cluster_id(_cluster_id);
        }

        _client.Call(_log_id, node, &computenode::StatusQueryService_Stub::clear_zone, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        }
        response.mutable_status()->set_code(1);
        response.mutable_status()->set_msg("clear failed");
        return Output(response);
    } else if (_type == "rpl") {
        replicate::pb::ClearZoneRequest request;
        replicate::pb::ClearZoneResponse response;

        request.set_log_id(_log_id);

        _client.Call(_log_id, node, &replicate::pb::ReplicationService_Stub::ClearZone, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        }
        response.mutable_status()->set_code(replicate::pb::RPC_ERROR);
        response.mutable_status()->set_msg("clear failed");
        return Output(response);
    } else if (_type == "ps") {
        pspb::ClearZoneRequest request;
        pspb::ClearZoneResponse response;

        request.set_log_id(_log_id);

        _client.Call(_log_id, node, &pspb::ManagerService_Stub::ClearZone, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        }
        response.mutable_status()->set_code(pspb::Status::RPC_ERROR);
        response.mutable_status()->set_msg("set failed");
        return Output(response);
    } else {
        print_error("invalid --type)");
        return 1;
    }
}

int ClearZone::Format(const lspb::lsrv_clear_zone_response& rsp) {
    SHOW_LS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

int ClearZone::Format(const computenode::clear_zone_response& rsp) {
    SHOW_CMP_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

int ClearZone::Format(const replicate::pb::ClearZoneResponse& rsp) {
    SHOW_RPL_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

int ClearZone::Format(const pspb::ClearZoneResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
