/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/append_file_utils.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class AppendFileUtils : public Command {
public:
    AppendFileUtils() {
        SetName("append-file-utils");
        SetDesc("append file utils");
        SetDescCn("追加文件存储引擎工具");
        
        AddRequiredArgOption("file", &_long_opt_val, kOptMax + 1, "append db file path name", kstring);
        AddRequiredArgOption("type", &_long_opt_val, kOptMax + 2, "file type: (checkpoint / db / dblwr / slots)", kenum);
        AddNoArgOption("parse", &_long_opt_val, kOptMax + 3, "parse records", kGroup2Scope);
        AddRequiredArgOption("space-id", &_long_opt_val, kOptMax + 4,
                "only parse this space records", kuint32_t, kGroup3Scope);
        AddRequiredArgOption("page-no", &_long_opt_val, kOptMax + 5,
                "only parse this page records", kuint32_t, kGroup3Scope);

        AddExample("--file <file_path> --type db");
        AddExample("--file <file_path> --type db --parse");
        AddExample("--file <file_path> --type db --parse --space-id id --page-no no");
        AddExample("--file <file_path> --type dblwr");
        AddExample("--file <file_path> --type slots");
    }
    virtual ~AppendFileUtils() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _file = opt;
                break;
            case kOptMax + 2:
                _type = opt;
                break;
            case kOptMax + 3:
                _parse = true;
                break;
            case kOptMax + 4:
                _space_id = std::strtoul(opt, NULL, 10);;
                break;
            case kOptMax + 5:
                _page_no = std::strtoul(opt, NULL, 10);;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    std::string _file {};
    std::string _type {};
    bool _parse {false};
    uint32_t _space_id {std::numeric_limits<uint32_t>::max()};
    uint32_t _page_no {std::numeric_limits<uint32_t>::max()};
};

}
}
