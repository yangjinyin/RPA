#!/bin/bash

work_dir=$(dirname $0)
#set -x
TARGET_BIN="page_server"
exec > ${work_dir}/log/restart_checker.log 2>&1
core_file=$(find $work_dir -name "core.page_server.*" -daystart -ctime 0)
if [ -z $core_file ]; then
    core_file=$(find $work_dir -name "core.*" -daystart -ctime 0)
fi
if [[ -n ${core_file} ]]; then
    echo "Core Dump. Try to stop."
    pid=$$
    ppid=$(ps -p ${pid} -o ppid=;)
    ps -p $ppid -f | grep supervise.${TARGET_BIN} > /dev/null
    if [ $? -ne 0 ]; then
        echo "[NOTE] This script can only be called by supervise.${TARGET_BIN}."
        exit 1
    fi
    kill -9 $ppid
    ps -p $ppid -f | grep supervise.${TARGET_BIN} > /dev/null
    if [ $? -ne 0 ]; then
    	echo "[SUCC] supervise.${TARGET_BIN} is killed"
    fi
fi
