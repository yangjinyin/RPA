/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_cluster_role.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/set_cluster_role.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int SetClusterRole::Run() {
    RpcStatus status;
    gaiapb::SetClusterRoleRequest request;
    gaiapb::SetClusterRoleResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_role.empty()) {
        print_error("miss --role");
        return 1;
    }

    if (_role != "PRIMARY" && _role != "STANDBY" && _role != "UNDETERMINDED") {
        print_error("error --role, %s", _role.c_str());
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    request.set_log_id(_log_id);
    if (_role == "UNDETERMINDED") {
        request.set_cluster_role(gaiadb::CLUSTER_UNDETERMINDED);
    } else if (_role == "PRIMARY") {
        request.set_cluster_role(gaiadb::CLUSTER_PRIMARY);
    } else  if (_role == "STANDBY") {
        request.set_cluster_role(gaiadb::CLUSTER_STANDBY);
    }

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::set_cluster_role, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " set cluster role failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("set failed, all nodes failed");
    return Output(response);
}

int SetClusterRole::Format(const gaiapb::SetClusterRoleResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
