/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_dbd_zone.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "gaiadb/common/types.h"

namespace psvr {
namespace test {

class MockDoublyBufferedNodeZone : public gaiadb::common::DoublyBufferedNodeZone {
public:
  MockDoublyBufferedNodeZone() : gaiadb::common::DoublyBufferedNodeZone() {}

  MOCK_METHOD0(Clear, bool());
  MOCK_METHOD2(Set, bool(const std::string&, const std::string&));
  MOCK_METHOD2(Get, bool(std::string*, std::string*));

};

}
}
