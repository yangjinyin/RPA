/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/do_takeover_compute_node.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class DoTakeOverComputeNode : public Command {
public:
    DoTakeOverComputeNode() {
        SetName("do-takeover-compute-node");
        SetDesc("do takeover on secondary compute node");
        SetDescCn("在备计算节点上执行热接管操作");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "cluster name", kstring);
        AddRequiredArgOption("task-id", &_long_opt_val, kOptMax + 2, "task name", kstring);
        
        AddExample("-a <ip> -p <port> --cluster-id x --task-id x");
    }
    virtual ~DoTakeOverComputeNode() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 2:
                _task_id = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const computenode::takeover_primary_response& rsp);

private:
    std::string _address {};
    int32_t _port {-1};
    std::string _cluster_id {};
    std::string _task_id {};
};

}
}
