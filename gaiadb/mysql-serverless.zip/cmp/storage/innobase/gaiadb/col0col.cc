/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/include/col0col.h
 The general function for column index

 Created 8/8/2023 guolingjie
 *******************************************************/

#include "col0col.h"
#include "dict0dict.h"

#include "sql/range_optimizer/columnar_index_scan.h"
#include "dict0types.h"
#include "formula_client.h"
#include "gaiadb.h"
#include "gaiadb/proto/formula/query.pb.h"
#include "mysqld.h"
#include "que0que.h"
#include "sql/field.h"
#include "sql/item_strfunc.h"
#include "sql/item_sum.h"
#include "sql/item_regexp_func.h"
#include "sql/item_timefunc.h"
#include "sql/key.h"
#include "sql/protocol_classic.h"
#include "sql/sql_optimizer.h"
#include "sql/sql_table.h"
#include "sql/table.h"
#include "sql_string.h"
#include "takeover.h"

extern rpc_t rpc_sys;
extern bool gaia_enable_columnar_order_by_innodb_rules;
#define CREATE_REQUEST_INTERVAL 100000

#define LOG_ERR_AND_RETURN_FALSE                                         \
  LOG(WARNING) << "general formual pb error"                       \
               << ", file: " << __FILE__ << ", line: " << __LINE__ \
               << ", function: " << __FUNCTION__                  \
               << ", sql: " << current_thd->query().str;      \
  return -1;

#define IF_ERROR_RETURN_FALSE(condition) \
  if (condition != 0) {                       \
    return -1;                        \
  }

std::string match_string_from_record(dtuple_t *tuple, dict_index_t *index) {
  std::stringstream ss;
  ss << *tuple;
  return ss.str();
}

row_search_result row_search_column_index_entry(dtuple_t *tuple,
                                                dict_index_t *index,
                                                uint32_t &info_bits) {
  info_bits = 0;
  LOG(TRACE) << "match_string_from_tuple" << match_string_from_record(tuple, index);
  return ROW_FOUND;
}

dberr_t row_update_column_index_info_bits(dtuple_t *entry, dict_index_t *index,
                                          uint16_t info_bits, que_thr_t *thr,
                                          mtr_t *mtr) {
  dberr_t err = DB_SUCCESS;
  ut_a(!index->table->is_intrinsic());

  auto *trx = thr_get_trx(thr);
  mlog_write_columnar_log(mtr, COLUMNAR_INDEX_DELETE, trx->id, index, entry);

  return err;
}

namespace formula {

using PostOperations = std::stack<Item *>;

DEFINE_string(formula_db_name, "formula", "formula database name");

// return table_name with partition suffix
void get_table_with_partition(const std::string &dict_name, std::string &schema,
                              std::string &table) {
  bool is_tmp;
  std::string partition;
  dict_name::get_table(dict_name, true, schema, table, partition, is_tmp);
  table += partition;
}

void get_duckdb_table_name(const std::string &origin_table, uint32_t space_id,
                           uint64_t index_id, std::string &duckdb_table,
                           bool verbose) {
  if (!verbose) {
    duckdb_table = origin_table;
    return;
  }
  assert(verbose);
  std::stringstream ss;
  ss << origin_table << "_" << space_id << "_" << index_id;
  duckdb_table = ss.str();
}

void get_duckdb_table_name(const dict_index_t *index,
                           std::string &duckdb_schema,
                           std::string &duckdb_table, bool verbose) {
  std::string origin_table_name;
  get_table_with_partition(index->table_name, duckdb_schema, origin_table_name);
  get_duckdb_table_name(origin_table_name, index->space, index->id,
                        duckdb_table, verbose);
}

void get_duckdb_table_name(const dict_index_t *index, std::string &full_name,
                           bool verbose) {
  std::stringstream ss;
  std::string schema;
  std::string origin_table;
  std::string duckdb_table;

  get_table_with_partition(index->table_name, schema, origin_table);
  get_duckdb_table_name(origin_table, index->space, index->id, duckdb_table,
                        verbose);

  ss << schema << "/" << duckdb_table;

  full_name = ss.str();
}

bool convert_charset(String *str, const CHARSET_INFO *cast_cs) {
  String tmp_str;
  uint dummy_err;

  if (tmp_str.copy(str->ptr(), str->length(), str->charset(), cast_cs,
                   &dummy_err)) {
    return false;
  }
  const CHARSET_INFO *tmp_cs = tmp_str.charset();
  size_t valid_length;
  bool length_error;

  // check valid
  if (validate_string(tmp_cs, tmp_str.ptr(), tmp_str.length(), &valid_length,
                      &length_error)) {
    const char *str_end = tmp_str.ptr() + tmp_str.length();
    const char *print_byte = tmp_str.ptr() + valid_length;
    THD *thd = current_thd;
    char hexbuf[7];
    size_t diff = std::min(size_t(str_end - print_byte), size_t(3));
    octet2hex(hexbuf, print_byte, diff);
    if (length_error) {
      my_error(ER_INVALID_CHARACTER_STRING, MYF(0), tmp_cs->csname, hexbuf);
      return false;
    }
    if (length_error) {
      if (thd->is_strict_mode()) {
        return false;
      } else {
        tmp_str.length(valid_length);
      }
    }
    push_warning_printf(
        thd, Sql_condition::SL_WARNING, ER_INVALID_CHARACTER_STRING,
        ER_THD(thd, ER_INVALID_CHARACTER_STRING), tmp_cs->csname, hexbuf);
  }

  *str = tmp_str;
  str->set_charset(cast_cs);

  return true;
}

static String replay_post_operations(PostOperations &post_ops,
                                     const std::string &field_val,
                                     const CHARSET_INFO *cs) {
  String str = String(field_val.c_str(), field_val.size(), cs);

  while (!post_ops.empty()) {
    Item *item = post_ops.top();
    post_ops.pop();
    if (item->real_item()->type() == Item::FUNC_ITEM) {
      Item_func *item_func = static_cast<Item_func *>(item->real_item());
      switch (item_func->functype()) {
        case Item_func::COLLATE_FUNC: {
          // unreachable! COLLATE should be executed before
          assert(false);

          auto *collate_item =
              static_cast<Item_func_set_collation *>(item_func);
          str.set_charset(collate_item->collation.collation);
          break;
        }
        case Item_func::UNKNOWN_FUNC: {
          std::string func_name{item_func->func_name()};
          if (func_name.compare("convert") == 0) {
            [[maybe_unused]] auto *convert_item =
                static_cast<Item_func_conv_charset *>(item_func);
            assert(convert_charset(&str, convert_item->get_cast_cs()));
          } else {
            assert(false);
          }
          break;
        }
        default:
          assert(false);
      }
    } else {
      assert(false);
    }
  }

  return str;
}

static int create_express(Item *cond, formula_pb::ParsedExpression *expr,
                          uint32_t level, bool select_field,
                          PostOperations *post_ops);

std::string string_convert(String *str) {
  if (!str) {
    return std::string();
  }

  if (str->charset() == &my_charset_bin) {
    return std::string(str->ptr(), str->length());
  }

  char tmp_buf[8192];
  uint num_errors;
  size_t len =
      copy_and_convert(tmp_buf, sizeof(tmp_buf), &my_charset_utf8mb3_general_ci,
                       reinterpret_cast<const char *>(str->ptr()),
                       str->length(), str->charset(), &num_errors);
  return std::string(tmp_buf, len);
}

int create_field_or_constant(Item *item, formula_pb::ParsedExpression *expr) {
  auto *real_item = item->real_item();
  if (real_item->type() == Item::FIELD_ITEM) {
    expr->set_expression_type(formula_pb::COLUMN_REF);
    auto *column_ref = expr->mutable_column_ref_expression();
    auto *field_item = (Item_field *)real_item;
    auto *field = field_item->field;

    auto tbl_name = field->orig_table_name ?
                    field->orig_table_name :
                    field->table->s->table_name.str;
    column_ref->add_column_names(tbl_name);
    column_ref->add_column_names(field->field_name);
    return 0;
  } else if (real_item->type() == Item::INT_ITEM) {
    expr->set_expression_type(formula_pb::VALUE_CONSTANT);
    auto *constant_val = expr->mutable_constant_expression()->mutable_value();
    if (real_item->unsigned_flag) {
      constant_val->set_type(formula_pb::UBIGINT);
      constant_val->set_ubigint(real_item->val_int());
    } else {
      constant_val->set_type(formula_pb::BIGINT);
      constant_val->set_bigint(real_item->val_int());
    }
    return 0;
  } else if (real_item->type() == Item::REAL_ITEM || real_item->type() == Item::DECIMAL_ITEM) {
    expr->set_expression_type(formula_pb::VALUE_CONSTANT);
    auto *constant_val = expr->mutable_constant_expression()->mutable_value();
    constant_val->set_type(formula_pb::DOUBLE);
    constant_val->set_double_(real_item->val_real());
    return 0;
  } else if (real_item->type() == Item::STRING_ITEM) {
    expr->set_expression_type(formula_pb::VALUE_CONSTANT);
    auto *constant_val = expr->mutable_constant_expression()->mutable_value();
    constant_val->set_type(formula_pb::VARCHAR);
    constant_val->set_string(string_convert(real_item->val_str(nullptr)));
    return 0;
  } else if (real_item->type() == Item::CACHE_ITEM) {
    auto *cache_item = static_cast<Item_cache *>(real_item);
    switch (cache_item->result_type()) {
      case Item_result::INT_RESULT: {
        expr->set_expression_type(formula_pb::VALUE_CONSTANT);
        auto *constant_val =
            expr->mutable_constant_expression()->mutable_value();
        if (cache_item->unsigned_flag) {
          constant_val->set_type(formula_pb::UBIGINT);
          constant_val->set_ubigint(cache_item->val_int());
        } else {
          constant_val->set_type(formula_pb::BIGINT);
          constant_val->set_bigint(cache_item->val_int());
        }
        return 0;
      }
      case Item_result::REAL_RESULT: {
        expr->set_expression_type(formula_pb::VALUE_CONSTANT);
        auto *constant_val =
            expr->mutable_constant_expression()->mutable_value();
        constant_val->set_type(formula_pb::DOUBLE);
        constant_val->set_double_(cache_item->val_real());
        return 0;
      }
      case Item_result::DECIMAL_RESULT: {
        // TODO: fix as decimal
        expr->set_expression_type(formula_pb::VALUE_CONSTANT);
        auto *constant_val =
            expr->mutable_constant_expression()->mutable_value();
        constant_val->set_type(formula_pb::DOUBLE);
        constant_val->set_double_(cache_item->val_real());
        return 0;
      }
      case Item_result::STRING_RESULT: {
        expr->set_expression_type(formula_pb::VALUE_CONSTANT);
        auto *constant_val =
            expr->mutable_constant_expression()->mutable_value();
        constant_val->set_type(formula_pb::VARCHAR);
        constant_val->set_string(string_convert(cache_item->val_str(nullptr)));
        return 0;
      }
      default:
        LOG_ERR_AND_RETURN_FALSE
    }
  } else if (real_item->type() == Item_func::FUNC_ITEM) {
    auto *func_item = static_cast<Item_func *>(real_item);
    switch (func_item->functype()) {
      case Item_func::NEG_FUNC: {
        expr->set_expression_type(formula_pb::VALUE_CONSTANT);
        auto *constant_val =
            expr->mutable_constant_expression()->mutable_value();
           constant_val->set_type(formula_pb::DOUBLE);
           constant_val->set_double_(func_item->val_real());
        return 0;
      }
      default:
        LOG_ERR_AND_RETURN_FALSE
    }
  }

  LOG_ERR_AND_RETURN_FALSE
}

int create_between(Item *cond, formula_pb::ParsedExpression *expr,
                   uint32_t level, bool select_field,
                   PostOperations *post_ops) {
  Item_func_between *const cond_func = static_cast<Item_func_between *>(cond);
  auto *between_expr = expr;
  if (cond_func->negated) {
    expr->set_expression_type(formula_pb::OPERATOR_NOT);
    between_expr = expr->mutable_operator_expression()->add_children();
  }

  between_expr->set_expression_type(formula_pb::COMPARE_BETWEEN);
  auto *bewteen_expr_handler = between_expr->mutable_between_expression();
  create_express(cond_func->arguments()[0],
                 bewteen_expr_handler->mutable_input(), level + 1, select_field,
                 post_ops);
  create_express(cond_func->arguments()[1],
                 bewteen_expr_handler->mutable_lower(), level + 1, select_field,
                 post_ops);
  create_express(cond_func->arguments()[2],
                 bewteen_expr_handler->mutable_upper(), level + 1, select_field,
                 post_ops);
  return 0;
}

int create_operator(Item *item, formula_pb::ParsedExpression *expr,
                    uint32_t level, bool select_field,
                    PostOperations *post_ops) {
  Item_func *const cond_func = static_cast<Item_func *>(item->real_item());

  switch (cond_func->functype()) {
    case Item_func::NOT_FUNC:
      expr->set_expression_type(formula_pb::OPERATOR_NOT);
      break;
    case Item_func::ISNULL_FUNC:
      expr->set_expression_type(formula_pb::OPERATOR_IS_NULL);
      break;
    case Item_func::ISNOTNULL_FUNC:
      expr->set_expression_type(formula_pb::OPERATOR_IS_NOT_NULL);
      break;
    case Item_func::IN_FUNC:
      expr->set_expression_type(formula_pb::COMPARE_IN);
      break;
    case Item_func::COALESCE_FUNC:
      expr->set_expression_type(formula_pb::OPERATOR_COALESCE);
      break;
    default:
      LOG_ERR_AND_RETURN_FALSE
  }

  auto *op_expr_handler = expr->mutable_operator_expression();
  for (uint64_t i = 0; i < cond_func->argument_count(); ++i) {
    IF_ERROR_RETURN_FALSE(create_express(cond_func->arguments()[i]->real_item(),
                                         op_expr_handler->add_children(),
                                         level + 1, select_field, post_ops))
  }

  return 0;
}

bool create_operator_in(Item *item, formula_pb::ParsedExpression *expr,
                        uint32_t level, bool select_field,
                        PostOperations *post_ops) {
  Item_func_in *const item_in = static_cast<Item_func_in *>(item->real_item());

  if (item_in->negated) {
    expr->set_expression_type(formula_pb::OPERATOR_NOT);
    auto *not_expr_handler = expr->mutable_operator_expression();
    return create_operator(item, not_expr_handler->add_children(), level + 1,
                           select_field, post_ops);
  } else {
    return create_operator(item, expr, level, select_field, post_ops);
  }
}

int create_comparison(Item *cond, formula_pb::ParsedExpression *expr,
                      uint32_t level, bool select_field,
                      PostOperations *post_ops) {
  Item_func *const cond_func = static_cast<Item_func *>(cond->real_item());
  switch (cond_func->functype()) {
    case Item_func::EQ_FUNC:
      expr->set_expression_type(formula_pb::COMPARE_EQUAL);
      break;
    case Item_func::NE_FUNC:
      expr->set_expression_type(formula_pb::COMPARE_NOTEQUAL);
      break;
    case Item_func::LT_FUNC:
      expr->set_expression_type(formula_pb::COMPARE_LESSTHAN);
      break;
    case Item_func::LE_FUNC:
      expr->set_expression_type(formula_pb::COMPARE_LESSTHANOREQUALTO);
      break;
    case Item_func::GT_FUNC:
      expr->set_expression_type(formula_pb::COMPARE_GREATERTHAN);
      break;
    case Item_func::GE_FUNC:
      expr->set_expression_type(formula_pb::COMPARE_GREATERTHANOREQUALTO);
      break;
    case Item_func::EQUAL_FUNC:
      expr->set_expression_type(formula_pb::COMPARE_EQUAL);
      break;
    default:
      LOG_ERR_AND_RETURN_FALSE
  }

  auto *compare_expr_handler = expr->mutable_comparison_expression();
  IF_ERROR_RETURN_FALSE(create_express(cond_func->arguments()[0],
                                       compare_expr_handler->mutable_left(),
                                       level + 1, select_field, post_ops))
  IF_ERROR_RETURN_FALSE(create_express(cond_func->arguments()[1],
                                       compare_expr_handler->mutable_right(),
                                       level + 1, select_field, post_ops))
  return 0;
}

int create_collate(Item *item, formula_pb::ParsedExpression *expr,
                   uint32_t level, bool select_field,
                   PostOperations *post_ops) {
  expr->set_expression_type(formula_pb::COLLATE);

  auto collate_item = static_cast<Item_func_set_collation *>(item);
  std::string collation(collate_item->collation.collation->m_coll_name);

  auto *collate_expr_handler = expr->mutable_collate_expression();
  collate_expr_handler->set_collation(collation);
  IF_ERROR_RETURN_FALSE(create_express(collate_item->arguments()[0],
                                       collate_expr_handler->mutable_child(),
                                       level + 1, select_field, post_ops))
  return 0;
}

// reconstruct the binary tree based on the list of leaf nodes, root node is
// COMPARE_EQUAL
int create_multi_equal(Item *item, formula_pb::ParsedExpression *expr,
                       uint32_t level, bool select_field,
                       PostOperations *post_ops) {
  auto *const equal_item = static_cast<Item_equal *>(item);
  auto fields = equal_item->get_fields();
  auto *local_expr = expr;

  switch (equal_item->members()) {
    case 0:
    case 1: {
      auto *compare_expr_handler = local_expr->mutable_comparison_expression();
      local_expr->set_expression_type(formula_pb::COMPARE_EQUAL);
      IF_ERROR_RETURN_FALSE(create_express(equal_item->m_const_folding[1],
                                           compare_expr_handler->mutable_left(),
                                           level + 1, select_field, post_ops))
      IF_ERROR_RETURN_FALSE(create_express(
          equal_item->m_const_folding[0], compare_expr_handler->mutable_right(),
          level + 1, select_field, post_ops))
      return 0;
    }
    default: {
      local_expr->set_expression_type(formula_pb::CONJUNCTION_AND);
      auto *conj_expr_handler = expr->mutable_conjunction_expression();
      formula_pb::ComparisonExpression *compare_expr_handler = nullptr;
      local_expr = conj_expr_handler->add_children();
      if (equal_item->get_const()) {
        compare_expr_handler = local_expr->mutable_comparison_expression();
        local_expr->set_expression_type(formula_pb::COMPARE_EQUAL);
        IF_ERROR_RETURN_FALSE(create_express(
            equal_item->get_const(), compare_expr_handler->mutable_left(),
            level + 1, select_field, post_ops));
        IF_ERROR_RETURN_FALSE(create_express(
            equal_item->get_first(), compare_expr_handler->mutable_left(),
            level + 1, select_field, post_ops));
      }
      uint32_t fields_idx = 0;
      for (auto &field : fields) {
        if (fields_idx != 0) {
          IF_ERROR_RETURN_FALSE(
              create_express(&field, compare_expr_handler->mutable_right(),
                             level + 1, select_field, post_ops));
        }

        if (fields_idx < equal_item->members() - 1) {
          local_expr = conj_expr_handler->add_children();
          local_expr->set_expression_type(formula_pb::COMPARE_EQUAL);
          compare_expr_handler = local_expr->mutable_comparison_expression();
          IF_ERROR_RETURN_FALSE(
              create_express(&field, compare_expr_handler->mutable_left(),
                             level + 1, select_field, post_ops));
        }
        fields_idx++;
      }
      return 0;
    }
  }
}

int create_case(Item *cond, formula_pb::ParsedExpression *expr, uint32_t level,
                bool select_field, PostOperations *post_ops) {
  auto case_item = static_cast<Item_func_case *>(cond);
  expr->set_expression_type(formula_pb::CASE_EXPR);
  auto *case_expr_pb = expr->mutable_case_expression();
  if (case_item->get_else_expr_num() != -1) {
    IF_ERROR_RETURN_FALSE(create_express(
        case_item->arguments()[case_item->get_else_expr_num()],
        case_expr_pb->mutable_else_expr(), level + 1, select_field, post_ops));
  }
  for (uint i = 0; i < case_item->get_ncases(); i += 2) {
    auto *check_pb = case_expr_pb->add_checks();
    IF_ERROR_RETURN_FALSE(create_express(case_item->arguments()[i],
                                         check_pb->mutable_when_expr(),
                                         level + 1, select_field, post_ops));
    IF_ERROR_RETURN_FALSE(create_express(case_item->arguments()[i + 1],
                                         check_pb->mutable_then_expr(),
                                         level + 1, select_field, post_ops));
  }
  return 0;
}

int create_if(Item *cond, formula_pb::ParsedExpression *expr, uint32_t level,
              bool select_field, PostOperations *post_ops) {
  auto case_item = static_cast<Item_func_if *>(cond);
  expr->set_expression_type(formula_pb::CASE_EXPR);
  auto *case_expr_pb = expr->mutable_case_expression();
  auto *check_pb = case_expr_pb->add_checks();
  IF_ERROR_RETURN_FALSE(create_express(case_item->arguments()[0],
                                       check_pb->mutable_when_expr(), level + 1,
                                       select_field, post_ops));
  IF_ERROR_RETURN_FALSE(create_express(case_item->arguments()[1],
                                       check_pb->mutable_then_expr(), level + 1,
                                       select_field, post_ops));
  IF_ERROR_RETURN_FALSE(create_express(case_item->arguments()[2],
                                       case_expr_pb->mutable_else_expr(),
                                       level + 1, select_field, post_ops));

  return 0;
}

void create_strptime_function(formula_pb::ParsedExpression *expr,
                              String text, const char *format) {
  expr->set_expression_type(formula_pb::FUNCTION);
  auto *func_expr = expr->mutable_function_expression();
  func_expr->set_distinct(false);
  func_expr->set_function_name("strptime");

  // add text parameter
  auto text_exp = func_expr->add_children();
  text_exp->set_expression_type(formula_pb::VALUE_CONSTANT);
  auto *text_val = text_exp->mutable_constant_expression()->mutable_value();
  text_val->set_type(formula_pb::VARCHAR);
  text_val->set_string(string_convert(&text));

  // add format parameter
  auto format_exp = func_expr->add_children();
  format_exp->set_expression_type(formula_pb::VALUE_CONSTANT);
  auto *format_val = format_exp->mutable_constant_expression()->mutable_value();
  format_val->set_type(formula_pb::VARCHAR);
  format_val->set_string(format);
}

int create_timefunc(Item *item, formula_pb::ParsedExpression *expr, uint32_t level,
                     bool select_field, PostOperations *post_ops) {
  assert(item->type() == Item::FUNC_ITEM);
  auto item_func = static_cast<Item_func *>(item);

  switch (item_func->functype()) {
    case Item_func::UNIX_TIMESTAMP_FUNC: {
      expr->set_expression_type(formula_pb::CAST);
      auto *cast_expr = expr->mutable_cast_expression();
      cast_expr->set_type(formula_pb::BIGINT);
      cast_expr->set_try_cast(false);

      auto *child = cast_expr->mutable_child();
      child->set_expression_type(formula_pb::FUNCTION);
      auto *func_expr = child->mutable_function_expression();
      func_expr->set_distinct(false);
      func_expr->set_function_name("epoch");

      if (item_func->argument_count() == 0 ||
          item_func->arguments()[0]->real_item()->type() == Item::STRING_ITEM) {
        auto ts_func = static_cast<Item_func_unix_timestamp *>(item_func);
        auto ts = static_cast<int64_t>(ts_func->val_int());

        auto ts_exp = func_expr->add_children();
        ts_exp->set_expression_type(formula_pb::VALUE_CONSTANT);
        auto *ts_val = ts_exp->mutable_constant_expression()->mutable_value();
        ts_val->set_type(formula_pb::TIMESTAMP_SEC);
        ts_val->set_bigint(ts);
      } else {
        IF_ERROR_RETURN_FALSE(create_express(item_func->arguments()[0], func_expr->add_children(),
                       level + 1, select_field, post_ops));
      }
      break;
    }
    case Item_func::DATE_FUNC: {
      std::string func_name(item_func->func_name());
      if (func_name.compare("date_literal") == 0) {
        String date_str;
        auto date_literal = static_cast<Item_date_literal *>(item_func);
        date_literal->val_str(&date_str);

        expr->set_expression_type(formula_pb::CAST);
        auto *cast_expr = expr->mutable_cast_expression();
        cast_expr->set_type(formula_pb::DATE);
        cast_expr->set_try_cast(false);

        const char *date_format = "%Y-%m-%d";
        create_strptime_function(cast_expr->mutable_child(), date_str, date_format);
      } else {
        LOG_ERR_AND_RETURN_FALSE
      }
      break;
    }
    case Item_func::DATETIME_LITERAL: {
      String datetime_str;
      auto datetime_literal = static_cast<Item_datetime_literal *>(item_func);
      datetime_literal->val_str(&datetime_str);

      const char *datetime_format = "%Y-%m-%d %H:%M:%S";
      create_strptime_function(expr, datetime_str, datetime_format);
      break;
    }
    default:
      LOG_ERR_AND_RETURN_FALSE
  }

  return 0;
}

int create_cast(Item *item, formula_pb::ParsedExpression *expr, uint32_t level,
                bool select_field, PostOperations *post_ops) {
  auto item_func = static_cast<Item_func *>(item);

  formula_pb::LogicalTypeId typid;
  std::string func_name = item_func->func_name();
  const CHARSET_INFO *cs = item_func->collation.collation;
  if (func_name.compare("cast_as_date") == 0) {
    typid = formula_pb::DATE;
  } else if (func_name.compare("cast_as_time") == 0) {
    typid = formula_pb::TIME;
  } else if (func_name.compare("cast_as_char") == 0) {
    if (cs == &my_charset_bin) {
      typid = formula_pb::BLOB;
    } else {
      typid = formula_pb::VARCHAR;
    }
  } else if (func_name.compare("cast_as_signed") == 0) {
    typid = formula_pb::BIGINT;
  } else {
    LOG_ERR_AND_RETURN_FALSE
  }

  expr->set_expression_type(formula_pb::CAST);
  auto *cast_expr = expr->mutable_cast_expression();
  cast_expr->set_type(typid);
  cast_expr->set_try_cast(false);
  
  IF_ERROR_RETURN_FALSE(create_express(item_func->arguments()[0],
                                       cast_expr->mutable_child(), level + 1,
                                       select_field, post_ops));

  return 0;
}

int create_function(Item *item, formula_pb::ParsedExpression *expr,
                     uint32_t level, bool select_field,
                     PostOperations *post_ops) {
  bool distinct = false;
  std::string formula_func_name = "";
  auto *real_item = item->real_item();
  Item_func *const item_func = static_cast<Item_func *>(real_item);
  std::string func_name{item_func->func_name()};
  switch (real_item->type()) {
    case Item::FUNC_ITEM: {
      switch (item_func->functype()) {
        case Item_func::EQ_FUNC:
        case Item_func::NE_FUNC:
        case Item_func::LT_FUNC:
        case Item_func::LE_FUNC:
        case Item_func::GT_FUNC:
        case Item_func::GE_FUNC:
        case Item_func::EQUAL_FUNC:
          return create_comparison(real_item, expr, level, select_field,
                                   post_ops);
        case Item_func::NOT_FUNC:
        case Item_func::ISNULL_FUNC:
        case Item_func::ISNOTNULL_FUNC:
          return create_operator(real_item, expr, level, select_field,
                                 post_ops);
        case Item_func::IN_FUNC:
          return create_operator_in(real_item, expr, level, select_field,
                                    post_ops);
        case Item_func::BETWEEN:
          return create_between(real_item, expr, level, select_field, post_ops);
        case Item_func::NEG_FUNC:
          return create_field_or_constant(real_item, expr);
        case Item_func::LIKE_FUNC:
          formula_func_name = "ilike_escape";
          break;
        case Item_func::COLLATE_FUNC:
          return create_collate(real_item, expr, level, select_field, post_ops);
        case Item_func::MULT_EQUAL_FUNC:
          return create_multi_equal(real_item, expr, level, select_field,
                                    post_ops);
        case Item_func::CASE_FUNC:
          return create_case(real_item, expr, level, select_field, post_ops);
        case Item_func::IF_FUNC:
          return create_if(real_item, expr, level, select_field, post_ops);
        case Item_func::COALESCE_FUNC:
          if (func_name.compare("any_value") == 0) {
            formula_func_name = func_name;
          } else if (func_name.compare("ifnull") == 0 ||
                     func_name.compare("coalesce") == 0) {
            return create_operator(real_item, expr, level, select_field,
                                   post_ops);
          }
          break;
        case Item_func::NULLIF_FUNC:
          if (func_name.compare("nullif") == 0) {
            formula_func_name = "nullif";
          }
          break;
        case Item_func::UNIX_TIMESTAMP_FUNC:
        case Item_func::DATETIME_LITERAL:
        case Item_func::DATE_FUNC:
          return create_timefunc(real_item, expr, level, select_field, post_ops);
        case Item_func::TYPECAST_FUNC:
          return create_cast(real_item, expr, level, select_field, post_ops);
        case Item_func::EXP_FUNC:
        case Item_func::LN_FUNC:
        case Item_func::LOG10_FUNC:
        case Item_func::SQRT_FUNC:
        case Item_func::POW_FUNC:
        case Item_func::ACOS_FUNC:
        case Item_func::ASIN_FUNC:
        case Item_func::COS_FUNC:
        case Item_func::SIN_FUNC:
        case Item_func::TAN_FUNC:
        case Item_func::COT_FUNC:
        case Item_func::NOW_FUNC:
        case Item_func::DEGREES_FUNC:
          if (func_name.compare("exp") == 0 ||
              func_name.compare("ln") == 0 ||
              func_name.compare("log10") == 0 ||
              func_name.compare("sqrt") == 0 ||
              func_name.compare("pow") == 0 ||
              func_name.compare("acos") == 0 ||
              func_name.compare("asin") == 0 ||
              func_name.compare("cos") == 0 ||
              func_name.compare("sin") == 0 ||
              func_name.compare("tan") == 0 ||
              func_name.compare("cot") == 0 ||
              func_name.compare("now") == 0 ||  
              func_name.compare("degrees") == 0) {
            formula_func_name = func_name;
          }
          break;
        case Item_func::LOG_FUNC:
          if (item_func->arg_count == 1) {
            formula_func_name = "ln";
          } else {
            formula_func_name = "log";
          }
          break;
        case Item_func::ATAN_FUNC:
          if (item_func->arg_count == 2) {
            formula_func_name = "atan2";
          } else {
            formula_func_name = "atan";
          }
          break;       
        case Item_func::PLUS_FUNC:
          formula_func_name = "add";
          break;
        case Item_func::MINUS_FUNC:
          formula_func_name = "subtract";
          break;
        case Item_func::MUL_FUNC:
          formula_func_name = "multiply";
          break;
        case Item_func::DIV_FUNC:
          formula_func_name = "fdiv";
          break;
        case Item_func::MOD_FUNC:
          formula_func_name = "fmod";
          break;
        case Item_func::ABS_FUNC:
          formula_func_name = "abs";
          break;
        case Item_func::CEILING_FUNC:
          formula_func_name = "ceiling";
          break;
        case Item_func::FLOOR_FUNC:
          formula_func_name = "floor";
          break;
        case Item_func::ROUND_FUNC:
          formula_func_name = "round";
          break;
        case Item_func::SIGN_FUNC:
          formula_func_name = "sign";
          break;
        case Item_func::RADIANS_FUNC:
          formula_func_name = "radians";
          break;
        case Item_func::UNKNOWN_FUNC: {
          if (func_name.compare("unhex") == 0 ||
              func_name.compare("hex") == 0 ||
              func_name.compare("concat") == 0 ||
              func_name.compare("concat_ws") == 0 ||
              func_name.compare("md5") == 0 ||
              func_name.compare("reverse") == 0 ||
              func_name.compare("replace") == 0 ||
              func_name.compare("lower") == 0 ||
              func_name.compare("upper") == 0 ||
              func_name.compare("right") == 0 ||
              func_name.compare("left") == 0 ||
              func_name.compare("lpad") == 0 ||
              func_name.compare("rpad") == 0 ||
              func_name.compare("ascii") == 0 ||
              func_name.compare("ord") == 0 ||
              func_name.compare("substr") == 0 ||
              func_name.compare("repeat") == 0 ||
              func_name.compare("log2") == 0 ||
              func_name.compare("position") == 0) {
            formula_func_name = func_name;
          } else if (func_name.compare("convert") == 0) {
            if (select_field) {
              post_ops->push(item);
            }
            return create_express(item_func->arguments()[0], expr, level + 1,
                                  select_field, post_ops);
          } else if (func_name.compare("regexp_like") == 0) {
            formula_func_name = "regexp_matches";
          } else if (func_name.compare("trim") == 0 ||
                     func_name.compare("rtrim") == 0 ||
                     func_name.compare("ltrim") == 0) {
            if (item_func->argument_count() != 1) {
              LOG_ERR_AND_RETURN_FALSE
            }
            formula_func_name = func_name;
          } else if (func_name.compare("rand") == 0) {
            formula_func_name = "random";
          } else {
            LOG_ERR_AND_RETURN_FALSE
          } 
          break;
        }
        default:
          LOG_ERR_AND_RETURN_FALSE
      }
      break;
    }
    case Item::SUM_FUNC_ITEM: {
      Item_sum *item_sum = down_cast<Item_sum *>(item_func);
      switch (item_sum->sum_func()) {
        case Item_sum::MIN_FUNC:
          formula_func_name = "min";
          break;
        case Item_sum::MAX_FUNC:
          formula_func_name = "max";
          break;
        case Item_sum::SUM_FUNC:
          formula_func_name = "sum";
          break;
        case Item_sum::SUM_DISTINCT_FUNC:
          formula_func_name = "sum";
          distinct = true;
          break;
        case Item_sum::AVG_FUNC:
          formula_func_name = "avg";
          break;
        case Item_sum::AVG_DISTINCT_FUNC:
          formula_func_name = "avg";
          distinct = true;
          break;
        case Item_sum::STD_FUNC: 
          if (func_name.compare("stddev_samp") == 0) {
            formula_func_name = "stddev_samp";
          } else {
            formula_func_name = "stddev_pop";
          }
          break;
        case Item_sum::GROUP_CONCAT_FUNC:
          formula_func_name = "group_concat";
          break;
        case Item_sum::COUNT_FUNC:
          formula_func_name = "count";
          break;
        case Item_sum::COUNT_DISTINCT_FUNC:
          distinct = true;
          formula_func_name = "count";
          break;
        default:
          LOG(ERROR) << "not support aggregation function type:"
                     << item_sum->sum_func();
          LOG_ERR_AND_RETURN_FALSE
      };
      break;
    }
    default:
      LOG_ERR_AND_RETURN_FALSE
  }

  assert(!formula_func_name.empty());
  expr->set_expression_type(formula_pb::FUNCTION);
  auto *func_expr_handler = expr->mutable_function_expression();

  func_expr_handler->set_function_name(formula_func_name);
  func_expr_handler->set_distinct(distinct);
  for (uint64_t i = 0; i < item_func->argument_count(); ++i) {
    IF_ERROR_RETURN_FALSE(create_express(item_func->arguments()[i],
                                         func_expr_handler->add_children(),
                                         level + 1, select_field, post_ops));
  }
  if (formula_func_name == "regexp_matches") {
    if (func_expr_handler->children_size() > 2) {
      LOG_ERR_AND_RETURN_FALSE
    }
    // add regexp_matches parameters
    auto case_exp = func_expr_handler->add_children();
    case_exp->set_expression_type(formula_pb::VALUE_CONSTANT);
    auto *constant_val =
        case_exp->mutable_constant_expression()->mutable_value();
    constant_val->set_type(formula_pb::VARCHAR);

    Item_func_regexp *item_regexp = down_cast<Item_func_regexp *>(item_func);
    auto icu_flags = item_regexp->get_icu_flags();
    std::string icu_flag_str = "";
    if (icu_flags & URegexpFlag::UREGEX_CASE_INSENSITIVE) {
      icu_flag_str.append("i");
    } else {
      icu_flag_str.append("c");
    }
    constant_val->set_string(icu_flag_str);
  }
  if (formula_func_name == "ilike_escape") {
    if (func_expr_handler->children_size() > 2) {
      LOG_ERR_AND_RETURN_FALSE
    }

    // add default escape parameters
    auto escape_exp = func_expr_handler->add_children();
    escape_exp->set_expression_type(formula_pb::VALUE_CONSTANT);
    auto *constant_val =
        escape_exp->mutable_constant_expression()->mutable_value();
    constant_val->set_type(formula_pb::VARCHAR);
    constant_val->set_string("\\");
  }

  return 0;
}

// return true if success
int create_express(Item *item, formula_pb::ParsedExpression *expr,
                   uint32_t level, bool select_field,
                   PostOperations *post_ops) {
  auto *real_item = item->real_item();
  formula_pb::ConjunctionExpression *conj_expr_handler = nullptr;
  if (real_item->type() == Item::COND_ITEM) {
    auto *cond_item = down_cast<Item_cond *>(real_item);
    if (cond_item->functype() == Item_func::COND_AND_FUNC) {
      conj_expr_handler = expr->mutable_conjunction_expression();
      expr->set_expression_type(formula_pb::CONJUNCTION_AND);
      auto *and_item = static_cast<Item_cond_and *>(item);
      if (and_item->cond_equal.current_level.elements != 0 &&
          and_item->argument_list()->size() == 0) {
        auto *cond_equal = &and_item->cond_equal;
        List_iterator<Item_equal> li(cond_equal->current_level);
        Item_equal *equal_item;
        while ((equal_item = li++)) {
          IF_ERROR_RETURN_FALSE(
              create_express(equal_item, conj_expr_handler->add_children(),
                             level + 1, select_field, post_ops))
        }
      }
    } else if (down_cast<Item_cond *>(real_item)->functype() ==
               Item_func::COND_OR_FUNC) {
      expr->set_expression_type(formula_pb::CONJUNCTION_OR);
      conj_expr_handler = expr->mutable_conjunction_expression();
    } else {
      LOG_ERR_AND_RETURN_FALSE
    }

    List_iterator<Item> li(*((Item_cond *)real_item)->argument_list());
    Item *child_item;
    while ((child_item = li++)) {
      IF_ERROR_RETURN_FALSE(create_express(child_item,
                                           conj_expr_handler->add_children(),
                                           level + 1, select_field, post_ops))
    }

    return 0;
  }

  switch (real_item->type()) {
    case Item::FUNC_ITEM:
    case Item::SUM_FUNC_ITEM:
      return create_function(real_item, expr, level, select_field, post_ops);
    case Item::FIELD_ITEM:
    case Item::INT_ITEM:
    case Item::STRING_ITEM:
    case Item::CACHE_ITEM:
    case Item::REAL_ITEM:
    case Item::DECIMAL_ITEM:
      return create_field_or_constant(real_item, expr);
    default:
      LOG_ERR_AND_RETURN_FALSE
  }
}

void maybe_rewrite_statement(JOIN *join, formula_pb::SelectNode *select_node) {
  // Case 1: [LIMIT] + [not ORDER BY]/[ORDER BY without pk]
  // Fixed it by adding an `ORDER BY pk` node to formula
  if (join->query_block->select_limit) {
    std::vector<Field *> pk_fields;
    std::unordered_set<uint16> pk_field_indices;
    auto *table = join->tables_list->table;
    for (uint i = 0; i < table->s->keys; ++i) {
      auto &key = table->s->key_info[i];
      if (!strcmp(key.name, primary_key_name)) {
        for (uint j = 0; j < key.actual_key_parts; ++j) {
          auto *field = key.key_part[j].field;
          pk_fields.push_back(field);
          pk_field_indices.insert(field->m_field_index);
        }
        break;
      }
    }
    assert(pk_fields.size() > 0);

    if (join->query_block->is_ordered()) {
      bool has_pk = false;
      for (ORDER *order = join->query_block->order_list.first; order;
           order = order->next) {
        auto *item = (*order->item)->real_item();
        if (item->type() == Item::FIELD_ITEM) {
          auto *field = static_cast<Item_field *>(item)->field;
          if (pk_field_indices.count(field->m_field_index) > 0) {
            has_pk = true;
            break;
          }
        }
      }

      if (has_pk) {
        return;
      }
    }

    formula_pb::ResultModifier *modifier = nullptr;
    for (int i = 0; i < select_node->modifiers_size(); ++i) {
      if (select_node->modifiers(i).type() == formula_pb::ORDER_MODIFIER) {
        modifier = select_node->mutable_modifiers(i);
        break;
      }
    }
    if (!modifier) {
      modifier = select_node->add_modifiers();
      modifier->set_type(formula_pb::ORDER_MODIFIER);
    }
    assert(modifier);

    for (auto *field : pk_fields) {
      auto *order_node = modifier->mutable_order()->add_orders();
      // order of pk is ascending
      order_node->set_order_type(formula_pb::ASCENDING);
      order_node->set_null_type(formula_pb::OrderByNull_DEFAULT);

      auto *expr = order_node->mutable_expression();
      expr->set_expression_type(formula_pb::COLUMN_REF);

      auto *column_ref = expr->mutable_column_ref_expression();
      column_ref->add_column_names(table->s->table_name.str);
      column_ref->add_column_names(field->field_name);
    }
  }
}

int handle_primary_key_scan(const dict_index_t *columnar_index,
                            const dict_index_t *cluster_index,
                            ColumnarExeContext *ctx) {
  assert(columnar_index && cluster_index && ctx);
  std::string schema_name;
  std::string table_name;
  get_duckdb_table_name(columnar_index, schema_name, table_name);

  auto *join = ctx->innodb_join;
  auto thd = join->thd;

  uint64_t sql2pb_cost_us = 0;
  uint64_t formula_exe_cost_us = 0;

  formula_pb::SelectQueryRequest request;
  baidu::rpc::Controller cntl;
  QueryContextPtr query_context =
      std::make_shared<QueryContext>(thd->m_execute_canceled, thd->killed);

  query_context->request = &request;
  query_context->space_id = columnar_index->space;
  query_context->index_id = columnar_index->id;
  query_context->log_id = thd->log_id();

  request.set_session_id(thd->thread_id());
  request.set_log_id(thd->log_id());
  auto *select_stmt = request.mutable_select_stmt();
  select_stmt->set_query_node_type(formula_pb::QueryNodeType::SELECT_NODE);
  auto *select_node = select_stmt->mutable_select_node();
  std::vector<std::stack<Item *>> post_process_fields;
  {
    hotbackup::ScopedCoster _(&sql2pb_cost_us);

    bool has_agg = false;
    for (Item *item : join->query_block->visible_fields()) {
      Item *real_item = item->real_item();
      if (real_item->has_aggregation()) {
        has_agg = true;
        break;
      }
    }

    // select list only primary key
    auto has_group_by = (join->query_block->group_list.elements > 0);
    for (auto i = 0; i < cluster_index->n_uniq; i++) {
      auto *field = cluster_index->get_field(i);
      auto *expr = select_node->add_select_list();
      if (has_group_by) {
        expr->set_expression_type(formula_pb::FUNCTION);
        auto *func_expr_handler = expr->mutable_function_expression();

        func_expr_handler->set_function_name("any_value");
        func_expr_handler->set_distinct(false);
        expr = func_expr_handler->add_children();
      }

      expr->set_expression_type(formula_pb::COLUMN_REF);
      auto *column_ref = expr->mutable_column_ref_expression();
      column_ref->add_column_names(field->name);
    }

    // table ref for from
    auto *table_ref = select_node->mutable_from_table();
    table_ref->set_type(formula_pb::BASE_TABLE_REF);
    auto *base_table_ref = table_ref->mutable_base_table_ref();
    base_table_ref->set_catalog_name(FLAGS_formula_db_name);
    base_table_ref->set_table_name(table_name);
    base_table_ref->set_schema_name(schema_name);

    // where filter
    if (join->query_block->where_cond()) {
      IF_ERROR_RETURN_FALSE(create_express(join->query_block->where_cond(),
                                           select_node->mutable_where_clause(),
                                           0, false, nullptr))
    }

    // having
    if (join->query_block->having_cond()) {
      IF_ERROR_RETURN_FALSE(create_express(join->query_block->having_cond(),
                                           select_node->mutable_having(), 0,
                                           false, nullptr))
    }

    // group by
    if (join->query_block->group_list.elements > 0) {
      auto *groups = select_node->mutable_groups();
      for (ORDER *group = join->query_block->group_list.first; group;
           group = group->next) {
        IF_ERROR_RETURN_FALSE(create_express(
            *(group->item), groups->add_group_exprs(), 0, false, nullptr))
      }
    }

    auto whether_add_any_value_fn = [has_group_by, &join](Item *item) {
      Item *real_item = item->real_item();
      bool in_group_list = false;
      if (!has_group_by) {
        return false;
      }

      for (ORDER *group = join->query_block->group_list.first;
            group != nullptr; group = group->next) {
        if (real_item == *group->item || item->eq(*group->item, false)) {
          in_group_list = true;
          break;
        }
      }
      if (!real_item->has_aggregation() && !in_group_list) {
        return true;
      }
      
      return false;
    };

    if (join->query_block->is_ordered()) {
      auto modifier = select_node->add_modifiers();
      modifier->set_type(formula_pb::ORDER_MODIFIER);
      for (ORDER *order = join->query_block->order_list.first; order;
           order = order->next) {
        auto *item = *(order->item);
        auto order_type = order->direction == enum_order::ORDER_ASC
                              ? formula_pb::ASCENDING
                              : (order->direction == enum_order::ORDER_DESC
                                     ? formula_pb::DESCENDING
                                     : formula_pb::ORDER_DEFAULT);
        auto null_type = formula_pb::OrderByNull_DEFAULT;

        auto *order_node = modifier->mutable_order()->add_orders();
        order_node->set_order_type(order_type);
        order_node->set_null_type(null_type);
        // dealing with the non-group by column appears after order by
        auto *pb_express = order_node->mutable_expression();
        if (whether_add_any_value_fn(item)) {
          pb_express->set_expression_type(formula_pb::FUNCTION);
          auto *func_expr_handler = pb_express->mutable_function_expression();

          func_expr_handler->set_function_name("any_value");
          func_expr_handler->set_distinct(false);
          pb_express = func_expr_handler->add_children();
        }
        IF_ERROR_RETURN_FALSE(
            create_express(item, pb_express, 0, false, nullptr))
      }
    }

    // could not push limit modifier if there is aggregation
    if (!has_agg && join->query_block->select_limit) {
      auto *modifier = select_node->add_modifiers();
      modifier->set_type(formula_pb::LIMIT_MODIFIER);
      auto *limit_modifier = modifier->mutable_limit();
      auto *limit_value = limit_modifier->mutable_limit();
      limit_value->set_expression_type(formula_pb::VALUE_CONSTANT);
      auto *limit_value_handler =
          limit_value->mutable_constant_expression()->mutable_value();
      limit_value_handler->set_type(formula_pb::BIGINT);

      // convert `LIMIT m, n` to `LIMIT 0, m+n` in order to get
      // enought rows for upper layer to execute `LIMIT m, n`
      int64_t rows_need =
          static_cast<int64_t>(join->query_block->get_limit(join->thd) +
                               join->query_block->get_offset(join->thd));
      limit_value_handler->set_bigint(rows_need);

      auto *offset_value = limit_modifier->mutable_offset();
      offset_value->set_expression_type(formula_pb::VALUE_CONSTANT);
      auto *offset_value_handler =
          offset_value->mutable_constant_expression()->mutable_value();
      offset_value_handler->set_type(formula_pb::BIGINT);
      offset_value_handler->set_bigint(0);
    }

    if (join->query_block->is_distinct()) {
      auto *modifier = select_node->add_modifiers();
      modifier->set_type(formula_pb::DISTINCT_MODIFIER);
      modifier->mutable_distinct();
    }

    if (gaia_enable_columnar_order_by_innodb_rules) {
      // try to rewrite parts of statement to correct inconsistent
      // results between row-based and column-based execution.
      maybe_rewrite_statement(join, select_node);
    }
  }

  // explain
  bool do_explain = thd->lex->is_explain() &&
                    !thd->lex->is_explain_analyze;
  if (do_explain) {
    select_stmt->mutable_explain_node();
  }

  {
    hotbackup::ScopedCoster _(&formula_exe_cost_us);
    FormulaClient::get_instance().query(query_context);
  }

  if (query_context->err_code != 0 || thd->m_execute_canceled.load() ||
      thd->killed.load()) {
    LOG_IF(WARNING, query_context->err_code != 0)
        << "[log_id: " << thd->log_id()
        << "] [msg: execute by formula error happend"
        << "] [formula_exe_cost_us: " << formula_exe_cost_us
        << "] [SQL: " << ctx->query_str << "]";
    return -1;
  }

  if (do_explain) {
    assert(query_context->results.size() == 1);

    ctx->get_hybrid_ctx()->explain_result =
        query_context->results[0]->rows(0).fields(0);
  } else {
    ctx->get_hybrid_ctx()->result_source = std::move(query_context->results);
  }

  return 0;
}

int handle_sql(const dict_index_t *index, ColumnarExeContext *ctx) {
  assert(index && ctx);
  std::string schema_name;
  std::string table_name;
  get_duckdb_table_name(index, schema_name, table_name);

  auto *join = ctx->innodb_join;
  auto *thd = join->thd;

  uint64_t sql2pb_cost_us = 0;
  uint64_t formula_exe_cost_us = 0;
  uint64_t pb2res_cost_us = 0;

  formula_pb::SelectQueryRequest request;
  QueryContextPtr query_context =
      std::make_shared<QueryContext>(thd->m_execute_canceled, thd->killed);
  query_context->log_id = thd->log_id();
  query_context->request = &request;

  query_context->space_id = index->space;
  query_context->index_id = index->id;

  request.set_session_id(join->thd->thread_id());
  request.set_log_id(thd->log_id());

  auto *select_stmt = request.mutable_select_stmt();
  select_stmt->set_query_node_type(formula_pb::QueryNodeType::SELECT_NODE);
  auto *select_node = select_stmt->mutable_select_node();
  uint64_t fields_cnt = 0;
  std::vector<std::stack<Item *>> post_process_fields;

  {
    std::shared_ptr<void> pb_finish_guard(nullptr, [ctx](...) {
      ctx->get_full_index_ctx()->generate_pb_finished = true;
    });
    hotbackup::ScopedCoster _(&sql2pb_cost_us);
    // Dealing with aggregation functions without group by
    bool has_aggregation = false;
    std::vector<Item *> new_select_items;
    for (Item *item : join->query_block->visible_fields()) {
      Item *real_item = item->real_item();
      if (real_item->has_aggregation()) {
        has_aggregation = true;
        break;
      }
    }
    bool has_group_by =
        (join->query_block->group_list.elements > 0 || has_aggregation);

    auto whether_add_any_value_fn = [has_group_by, &join](Item *item) {
      Item *real_item = item->real_item();
      bool in_group_list = false;
      if (!has_group_by) {
        return false;
      }

      for (ORDER *group = join->query_block->group_list.first;
            group != nullptr; group = group->next) {
        if (real_item == *group->item || item->eq(*group->item, false)) {
          in_group_list = true;
          break;
        }
      }
      if (!real_item->has_aggregation() && !in_group_list) {
        return true;
      }
      return false;
    };

    // select list
    for (Item *item : join->query_block->visible_fields()) {
      auto *pb_express = select_node->add_select_list();
      if (whether_add_any_value_fn(item)) {
        pb_express->set_expression_type(formula_pb::FUNCTION);
        auto *func_expr_handler = pb_express->mutable_function_expression();

        func_expr_handler->set_function_name("any_value");
        func_expr_handler->set_distinct(false);
        pb_express = func_expr_handler->add_children();
      }

      std::stack<Item *> post_ops;
      IF_ERROR_RETURN_FALSE(
          create_express(item, pb_express, 0, true, &post_ops))
      post_process_fields.push_back(post_ops);
      fields_cnt++;
    }

    // table ref for from
    auto *table_ref = select_node->mutable_from_table();
    table_ref->set_type(formula_pb::BASE_TABLE_REF);
    auto *base_table_ref = table_ref->mutable_base_table_ref();
    base_table_ref->set_catalog_name(FLAGS_formula_db_name);
    base_table_ref->set_table_name(table_name);
    base_table_ref->set_schema_name(schema_name);

    // where filter
    if (join->query_block->where_cond()) {
      IF_ERROR_RETURN_FALSE(create_express(join->query_block->where_cond(),
                                           select_node->mutable_where_clause(),
                                           0, false, nullptr))
    }

    // having
    if (join->query_block->having_cond()) {
      IF_ERROR_RETURN_FALSE(create_express(join->query_block->having_cond(),
                                           select_node->mutable_having(), 0,
                                           false, nullptr))
    }

    // group by
    if (join->query_block->group_list.elements > 0) {
      auto *groups = select_node->mutable_groups();
      for (ORDER *group = join->query_block->group_list.first; group;
           group = group->next) {
        IF_ERROR_RETURN_FALSE(create_express(
            *(group->item), groups->add_group_exprs(), 0, false, nullptr))
      }
    }
    
    if (join->query_block->is_ordered()) {
      auto modifier = select_node->add_modifiers();
      modifier->set_type(formula_pb::ORDER_MODIFIER);
      for (ORDER *order = join->query_block->order_list.first; order;
           order = order->next) {
        Item *item = *(order->item);

        auto order_type = order->direction == enum_order::ORDER_ASC
                              ? formula_pb::ASCENDING
                              : (order->direction == enum_order::ORDER_DESC
                                     ? formula_pb::DESCENDING
                                     : formula_pb::ORDER_DEFAULT);
        auto null_type = formula_pb::OrderByNull_DEFAULT;

        auto *order_node = modifier->mutable_order()->add_orders();
        order_node->set_order_type(order_type);
        order_node->set_null_type(null_type);
        // dealing with the non-group by column appears after order by
        auto *pb_express = order_node->mutable_expression();
        if (whether_add_any_value_fn(item)) {
          pb_express->set_expression_type(formula_pb::FUNCTION);
          auto *func_expr_handler = pb_express->mutable_function_expression();

          func_expr_handler->set_function_name("any_value");
          func_expr_handler->set_distinct(false);
          pb_express = func_expr_handler->add_children();
        }
        IF_ERROR_RETURN_FALSE(
            create_express(item, pb_express, 0, false, nullptr))
      }
    }

    if (join->query_block->select_limit) {
      auto *modifier = select_node->add_modifiers();
      modifier->set_type(formula_pb::LIMIT_MODIFIER);
      auto *limit_modifier = modifier->mutable_limit();
      auto *limit_value = limit_modifier->mutable_limit();
      limit_value->set_expression_type(formula_pb::VALUE_CONSTANT);
      auto *limit_value_handler =
          limit_value->mutable_constant_expression()->mutable_value();
      limit_value_handler->set_type(formula_pb::BIGINT);
      limit_value_handler->set_bigint(
          static_cast<int64_t>(join->query_block->get_limit(join->thd)));

      auto *offset_value = limit_modifier->mutable_offset();
      offset_value->set_expression_type(formula_pb::VALUE_CONSTANT);
      auto *offset_value_handler =
          offset_value->mutable_constant_expression()->mutable_value();
      offset_value_handler->set_type(formula_pb::BIGINT);
      offset_value_handler->set_bigint(
          static_cast<int64_t>(join->query_block->get_offset(join->thd)));
    }

    if (join->query_block->is_distinct()) {
      auto *modifier = select_node->add_modifiers();
      modifier->set_type(formula_pb::DISTINCT_MODIFIER);
      modifier->mutable_distinct();
    }

    if (gaia_enable_columnar_order_by_innodb_rules) {
      // try to rewrite parts of statement to correct inconsistent
      // results between row-based and column-based execution.
      maybe_rewrite_statement(join, select_node);
    }
  }

  // explain
  bool do_explain = thd->lex->is_explain() &&
                    !thd->lex->is_explain_analyze;
  if (do_explain) {
    select_stmt->mutable_explain_node();

    fields_cnt = 1;
  }

  {
    hotbackup::ScopedCoster _(&formula_exe_cost_us);
    FormulaClient::get_instance().query(query_context);
  }

  if (query_context->err_code != 0 || thd->m_execute_canceled.load() ||
      thd->killed.load()) {
    LOG_IF(WARNING, !thd->m_execute_canceled.load())
        << "[log_id: " << thd->log_id()
        << "] [msg: execute by formula error happend"
        << "] [formula_exe_cost_us: " << formula_exe_cost_us
        << "] [SQL: " << ctx->query_str << "]";
    return -1;
  }

  {
    hotbackup::ScopedCoster _(&pb2res_cost_us);
    auto expect_val = WriteFenceType::NONE;
    if (!thd->require_write_fence(expect_val, WriteFenceType::COLUMNAR)) {
      assert(expect_val == WriteFenceType::INNOBASE);
      LOG(WARNING) << "[log_id: " << thd->log_id()
                   << "] [msg: execute by columnar eninge may be slowly"
                   << "] [ib_query_cost: " << thd->m_current_query_cost
                   << "] [sql2pb_cost_us: " << sql2pb_cost_us
                   << "] [formula_exe_cost_us: " << formula_exe_cost_us
                   << "] [pb2res_cost_us: " << pb2res_cost_us
                   << "] [SQL: " << ctx->query_str << "]";
      return -1;
    }

    for (const auto &result_set : query_context->results) {
      assert(result_set->rows_size() > 0);

      auto column_count = static_cast<uint64_t>(
          result_set->rows(0).fields_size());
      assert(column_count == fields_cnt);

      if (do_explain) {
        assert(query_context->results.size() == 1);

        ctx->get_full_index_ctx()->explain_result = 
            result_set->rows(0).fields(0);
        goto query_end;
      }

      String packet;
      for (int row_idx = 0; row_idx < result_set->rows_size(); ++row_idx) {
        packet.length(0);
        auto &row = result_set->rows(row_idx);
        for (uint64_t column_idx = 0; column_idx < column_count; ++column_idx) {
          auto &post_ops = post_process_fields[column_idx];
          const std::string &field_val = row.fields(column_idx);
          String res =
              replay_post_operations(post_ops, field_val, thd->charset());
          if (net_store_data(reinterpret_cast<uchar *>(res.ptr()), res.length(),
                             &packet)) {
            LOG(WARNING) << "[log_id: " << thd->log_id()
                         << "] [msg: net_store_data failed"
                         << "] [SQL: " << ctx->query_str << "]";
            return -1;
          }
        }
        thd->inc_sent_row_count(1);
        if (my_net_write(&thd->net, pointer_cast<uchar *>(packet.ptr()),
                         packet.length())) {
          LOG(WARNING) << "[log_id: " << thd->log_id()
                       << "] [msg: my_net_write failed"
                       << "] [SQL: " << ctx->query_str << "]";
          return -1;
        }
      }
    }
  }

query_end:
  thd->push_warning_printf_wrap(
      "{\"log_id\": \"%ld\", \"err_no\": %d, \"message\": \"execute by "
      "columnar full index\", \"sql2pb_cost_us\": %lu, "
      "\"formula_cost_us\": %lu, "
      "\"pb2res_cost_us\": %lu, \"ib_query_estimated_cost\": %.2lf}",
      thd->log_id(),
      static_cast<uint32_t>(COLUMNAR_EXECUTE_ERR::EXECUTE_BY_FULL_INDEX),
      sql2pb_cost_us, formula_exe_cost_us, pb2res_cost_us,
      thd->m_current_query_cost);

  return 0;
}

dberr_t gaiadb_create_columnar_index(space_id_t space_id, uint64_t index_id) {
  int32_t ret = gaiadb::GIE_OK;
  do {
    ret = psmcli->create_space_columnar_index(space_id, index_id);
    if (ret != gaiadb::GIE_OK) {
      LOG(WARNING) << "Manager: request create columnar index failed: " << ret
                << ", space_id:" << space_id << ", index_id:" << index_id;
      if (ret == gaiadb::GIE_DUPLICATED || ret == gaiadb::GIE_INVALID) {
        return DB_ERROR;
      } else if (ret == gaiadb::GIE_NO_ENOUGH_RESOURCE) {
        return DB_UNSUPPORTED;
      }
      std::this_thread::sleep_for(srv_delay_send_request);
    }
  } while (ret != gaiadb::GIE_OK);

  return DB_SUCCESS;
}

dberr_t gaiadb_drop_columnar_index(uint32_t space_id, uint64_t index_id) {
  int32_t ret = psmcli->drop_space_columnar_index(space_id, index_id);
  if (ret != gaiadb::GIE_OK) {
    LOG(WARNING) << "drop columnar index failed"
        << ", space_id: " << space_id
        << ", index_id: " << index_id
        << ", ret: " << ret;
    return DB_ERROR;
  }
 
  ib_info() << "remove columnar index from psm success, space_id=" << space_id
    << ", index_id=" << index_id;
  return DB_SUCCESS;
}

dberr_t gaiadb_get_space_columnar_group(uint32_t space_id, uint64_t index_id,
                                        uint32_t &group_id) {
  if (psmcli->get_group_id_by_space_index(space_id, index_id, group_id)) {
    return DB_SUCCESS;
  }
  LOG(WARNING) << "get group id failed, may be already droped"
               << ", space_id: " << space_id << ", index_id: " << index_id;
  return DB_ERROR;
}

}  // namespace formula
