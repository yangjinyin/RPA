/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_segment_compress_config.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/set_segment_compress_config.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int SetSegmentCompressConfig::Run() {
    RpcStatus status;
    gaiapb::SetSegmentCompressConfigRequest request;
    gaiapb::SetSegmentCompressConfigResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (!_enable.has_val) {
        print_error("miss --cfg-enable");
        return 1;
    }

    if (_enable.val && (!_type.has_val || _type.val.empty())) {
        print_error("miss --cfg-type");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("%s compression ?", _enable.val ? "Enable" : "Disable");
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    request.set_log_id(_log_id);
    request.mutable_compress_cfg()->set_enable(_enable.val);
    request.mutable_compress_cfg()->set_type(_type.val);
    request.mutable_compress_cfg()->set_level(_level);

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::set_segment_compress_config, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " set segment compress config failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("set failed, all nodes failed");
    return Output(response);
}

int SetSegmentCompressConfig::Format(const gaiapb::SetSegmentCompressConfigResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    {
        Table table(_raw_with_table, 2);
        table.AddRowsValue({"enable:", rsp.compress_cfg().enable()});
        table.AddRowsValue({"type:", rsp.compress_cfg().type()});
        table.AddRowsValue({"level:", rsp.compress_cfg().level()});
        table.Display();
    }
    return 0;
}

}
}
