/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_replica_recovery_status.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/update_replica_recovery_status.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int UpdateReplicaRecoveryStatus::Run() {
    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (!_segment_id.has_val || _segment_id.val == 0) {
        print_error("miss or invalid --segment-id");
        return 1;
    }

    if (!_replica_id.has_val) {
        print_error("miss --replica-id");
        return 1;
    }

    if (_replica_addr.empty()) {
        print_error("miss --replica-addr");
        return 1;
    }

    gaiadb::RecoveryStatus recovery_status;
    if (_status.empty()) {
        print_error("miss --status");
        return 1;
    }

    if (!gaiadb::RecoveryStatus_Parse(_status, &recovery_status)) {
        print_error("invalid --status");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    RpcStatus status;
    if (!_force) {
        bool cf_ret = execute_confirm("update all replica:%s reocvery stauts to %s?", _replica_addr.c_str(), _status.c_str());
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    gaiapb::UpdateReplicaRecoveryStatusRequest request;
    gaiapb::AckResponse response;

    request.set_log_id(_log_id);
    request.set_segment_id(_segment_id.val);
    request.set_replica_id(_replica_id.val);
    request.set_addr(_replica_addr);
    request.set_status(recovery_status);

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::update_replica_recovery_status, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " set replica recovery status failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("set replica recovery status failed, all nodes failed");
    return Output(response);
}

int UpdateReplicaRecoveryStatus::Format(const gaiapb::AckResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
