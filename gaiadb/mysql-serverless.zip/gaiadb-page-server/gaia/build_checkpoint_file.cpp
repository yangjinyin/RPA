/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/build_checkpoint_file.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <sys/ioctl.h>
#include <termios.h>
#include <filesystem>
#include <gaiadb/utils/ut.h>
#include <psvr0page.h>
#include "gaia/build_checkpoint_file.h"

namespace psvr {
namespace gaia {

static void log_block_set_checksum(gaia_apply::byte *log_block, uint32_t checksum) {
    gaia_apply::mach_write_to_4(log_block + gaia_apply::OS_FILE_LOG_BLOCK_SIZE - gaia_apply::LOG_BLOCK_CHECKSUM,
                                checksum);
}

static uint32_t log_block_get_checksum(const gaia_apply::byte *log_block) {
    return gaia_apply::mach_read_from_4(log_block + gaia_apply::OS_FILE_LOG_BLOCK_SIZE - gaia_apply::LOG_BLOCK_CHECKSUM);
}

static uint32_t log_block_calc_checksum_crc32(const gaia_apply::byte *log_block) {
    return gaiadb::common::ut_crc32(log_block, gaia_apply::OS_FILE_LOG_BLOCK_SIZE - gaia_apply::LOG_BLOCK_TRL_SIZE);
}

int BuildCheckpointFile::Run() {
    gaiadb::common::ut_crc32_init();
    static gaia_apply::page_size_t univ_page_size(0, 0, false);

    if (_ckp_file.size() < 1) {
        print_error("miss --ckp-file");
        return -1;
    }

    if (_is_create) {
        _fd = open(_ckp_file.c_str(), O_CREAT | O_EXCL | O_RDWR, S_IRUSR | S_IWUSR);
    } else {
        _fd = open(_ckp_file.c_str(), O_RDONLY);
    }
    if (_fd < 0) {
        print_error("open ckp file failed, %s", strerror(errno));
        return -1;
    }

    std::shared_ptr<nullptr_t> guard_fp(nullptr,
            [this](nullptr_t) {
                if (_fd > -1) {
                    close(_fd);
                }
        });

    if (_is_create) {
        if (0 != fallocate(_fd, 0, 0, _file_size)) {
            print_error("file resize failed, %s", strerror(errno));
        }
    }

    if (std::filesystem::file_size(_ckp_file) != _file_size) {
        print_error("file size mismatch");
        return -1;
    }

    gaia_apply::page_id_t page_id{0, 0};
    gaia_apply::byte *buf = reinterpret_cast<gaia_apply::byte *>(std::aligned_alloc(512, gaia_apply::OS_FILE_LOG_BLOCK_SIZE));
    if (!buf) {
        print_error("aligned_alloc failed, %s", strerror(errno));
        return -1;
    }
    std::shared_ptr<nullptr_t> guard_buf(nullptr, [buf](nullptr_t) { std::free(buf); });

    assert(gaia_apply::LOG_CHECKPOINT_1 < univ_page_size.physical());
    assert(gaia_apply::LOG_CHECKPOINT_2 < univ_page_size.physical());

    for (int i = 0; i < 2; ++i) {
        memset(buf, 0x00, gaia_apply::OS_FILE_LOG_BLOCK_SIZE);
        if (_is_create) {
            gaia_apply::mach_write_to_8(buf + gaia_apply::LOG_CHECKPOINT_NO, i);
            gaia_apply::mach_write_to_8(buf + gaia_apply::LOG_CHECKPOINT_LSN, _lsn);
            log_block_set_checksum(buf, log_block_calc_checksum_crc32(buf));

            const uint64_t page_offset = static_cast<uint64_t>(page_id.page_no()) * univ_page_size.physical();
            const auto byte_offset = (i & 1) ? gaia_apply::LOG_CHECKPOINT_2 : gaia_apply::LOG_CHECKPOINT_1;
            const ssize_t write_size = pwrite(_fd, buf, gaia_apply::OS_FILE_LOG_BLOCK_SIZE, page_offset + byte_offset);
            if (static_cast<ssize_t>(gaia_apply::OS_FILE_LOG_BLOCK_SIZE) != write_size) {
                std::cout << "Error: write ckp lsn to file failed, err:" << strerror(errno) << "\n";
                return -1;
            }
        } else {
            const uint64_t page_offset = static_cast<uint64_t>(page_id.page_no()) * univ_page_size.physical();
            const auto byte_offset = (i & 1) ? gaia_apply::LOG_CHECKPOINT_2 : gaia_apply::LOG_CHECKPOINT_1;
            const ssize_t read_size = pread(_fd, buf, gaia_apply::OS_FILE_LOG_BLOCK_SIZE, page_offset + byte_offset);
            if (static_cast<ssize_t>(gaia_apply::OS_FILE_LOG_BLOCK_SIZE) != read_size) {
                std::cout << "Error: read ckp lsn file data failed, err:" << strerror(errno) << "\n";
                return -1;
            }
            if (gaiadb::common::ut_buf_all_zero(buf, gaia_apply::OS_FILE_LOG_BLOCK_SIZE)) {
                std::cout << "ckp file block empty, offset:" << page_offset + byte_offset << "\n";
                continue;
            }
            if (log_block_get_checksum(buf) != log_block_calc_checksum_crc32(buf)) {
                std::cout << "ckp file block crc corrput, offset:" << page_offset + byte_offset << "\n";
                continue;
            }
            const auto lsn = gaia_apply::mach_read_from_8(buf + gaia_apply::LOG_CHECKPOINT_LSN);
            std::cout << "ckp file block lsn: " << lsn << ", offset:" << page_offset + byte_offset << "\n";
        }
    }

    std::cout << "Ok, done\n";
    return 0;
}

}
}
