/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_space_extent_segment.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/get_space_extent_segment.h"
#include "psvr/psminfo.h"
#include "psvr/page_op.h"
#include "psvr/utils.h"
#include <gaiadb/utils/ut.h>

namespace psvr {
namespace gaia {

int GetSpaceExtentSegment::Run() {
    gaiadb::common::ut_crc32_init();
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_specify_space_id) {
        print_error("miss --space-id");
        return 1;
    }

    if (!_specify_page_no) {
        print_error("miss --page-no");
        return 1;
    }

    if (_check_page_data) {
        if (_cluster_id.empty()) {
            print_error("miss --cluster-id");
            return 1;
        }
    }

    gaiapb::GetSpaceExtentMapRequest request;
    gaiapb::GetSpaceExtentMapResponse response;
    request.set_space_id(_space_id);
    request.set_begin_extent_id(_page_no / GAIADB_EXTENT_PAGE_NUM);
    request.set_num(1);
    request.set_need_physical_extent_id(true);
    request.set_use_bytes(_use_bytes);

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_space_extent_map, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            LOG(NOTICE) << pb2jsonstr(response);
            gaiapb::GetSpaceExtentMapResponse response2;
            response2.mutable_status()->CopyFrom(response.status());
            response2.set_total_extent_num(response.total_extent_num());
            if (response.has_extent_map_bytes()) {
                struct ExtentMap {
                    uint32_t segment_id;
                    uint32_t extent_id;
                };
                const ExtentMap* entry = reinterpret_cast<const ExtentMap*>(response.extent_map_bytes().c_str());
                const uint32_t count = response.extent_map_bytes().length() / sizeof(*entry);
                for (uint32_t i = 0; i < count; ++i) {
                    auto m = response2.mutable_extent_map()->add_entries();
                    m->set_segment_id(entry->segment_id);
                    m->set_physical_extent_id(entry->extent_id);
                    ++entry;
                }
            } else {
                response2.mutable_extent_map()->CopyFrom(response.extent_map());
            }

            const auto& extent_map = response2.extent_map();
            if (extent_map.entries_size() > 0) {
                const auto& m = extent_map.entries(0);
                gaiapb::GetSegmentRequest sub_request;
                sub_request.set_segment_id(m.segment_id());

                for (auto& node2 : nodes) {
                    _client.Call(_log_id, node2, &gaiapb::QueryService_Stub::get_segment, &sub_request, &_response,
                            nullptr, &status, _timeout_ms);
                    if (status.IsOk()
                            && !rsp_is_retry(_response.status())) {
                        _segment_info_ok = true;
                        break;
                    } else {
                        LOG(WARNING) << node2 << " get segment failed, " << status << " " << _response.status();
                    }
                }
            }

            return Output(response2);
        } else {
            LOG(WARNING) << node << " get space extend failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("get failed, all nodes failed");
    return Output(response);
}

int GetSpaceExtentSegment::Format(const gaiapb::GetSpaceExtentMapResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    const auto& extent_map = rsp.extent_map();
    Table table(_raw_with_table, 0);
    table.AddRowsWithName({"space_id", "logical_page_no", "logical_extent_id", "physical_extent_id", "physical_offset", "segment_id"});

    uint32_t logical_extent_id = _page_no / GAIADB_EXTENT_PAGE_NUM;
    uint64_t physical_offset = 0;
    for (int32_t i = 0; i < extent_map.entries_size(); ++i) {
        const auto& m = extent_map.entries(i);
        physical_offset = (static_cast<uint64_t>(m.physical_extent_id()) << GAIADB_EXTENT_SIZE_SHIFT)
            + (_page_no % GAIADB_EXTENT_PAGE_NUM) * gaia_apply::FLAGS_univ_page_size;
        table.AddRowsValue({
                    _space_id,
                    _page_no,
                    logical_extent_id + i,
                    m.physical_extent_id(),
                    physical_offset,
                    m.segment_id(),
                });
    }
    table.AddRowsValue({"total_extent_num:", rsp.total_extent_num()});
    table.Display();
    if (_check_page_data && !_segment_info_ok) {
        print_error("error: get segment failed");
    }

    void* buf = std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size);
    gaia_apply::byte* frame = static_cast<gaia_apply::byte*>(buf);

    if (_segment_info_ok && _check_page_data) {
        std::vector<std::string> nodes;
        uint64_t segment_id = 0;

        Table table2(_raw_with_table, 0);
        table2.AddRowsWithName({
                "segment_id", "addr", "replica_id", "fetch_lsn", "apply_lsn", "checkpoint_lsn",
                "max_extent_num", "recovery_status", "state", "version", "zone"
                });
        for (auto& page_server : _response.page_servers()) {
            table2.AddRowsValue({
                    page_server.segment_id(),
                    page_server.addr(),
                    page_server.replica_id(),
                    page_server.fetch_lsn(),
                    page_server.apply_lsn(),
                    page_server.checkpoint_lsn(),
                    page_server.max_extent_num(),
                    gaiadb::RecoveryStatus_Name(page_server.recovery_status()),
                    gaiadb::NodeState_Name(page_server.state()),
                    get_unknown_type(page_server.has_version(), page_server.version(), -1),
                    GetZoneStr(page_server)
                    });

            nodes.emplace_back(page_server.addr());
            segment_id = page_server.segment_id();
        }
        table2.Display();

        pspb::ReadPageRequest read_request;
        read_request.set_physical_offset(physical_offset);
        read_request.set_log_id(_log_id);
        read_request.set_cluster_id(_cluster_id);
        read_request.set_segment_id(segment_id);
        read_request.set_request_lsn(8204);
        read_request.set_size(gaia_apply::FLAGS_univ_page_size);

        bool is_init = false;
        uint32_t last_crc = 0;
        uint32_t error_num = 0;

        std::map<std::string, std::shared_ptr<pspb::ReadPageResponse>> read_response_map;

        for (int32_t i = 0; i < 3; ++i) {
            for (auto& addr : nodes) {
                base::EndPoint node;
                base::str2endpoint(addr.c_str(), &node);

                pspb::ReadPageResponse* read_response;

                auto it = read_response_map.find(addr);
                if (it != read_response_map.end()) {
                    read_response = it->second.get();
                } else {
                    read_response = new pspb::ReadPageResponse();
                    read_response_map.emplace(addr, read_response);
                }

                RpcStatus status;
                _client.Call(_log_id++, node, &pspb::QueryService_Stub::ReadPhysicalPage, &read_request, read_response,
                        nullptr, &status, _timeout_ms);
                if (!status.IsOk()) {
                    read_response->mutable_status()->set_code(pspb::Status::RPC_ERROR);
                    read_response->mutable_status()->set_msg("rpc failed");
                    ++error_num;
                } else {
                    if (read_response->status().code() != pspb::Status_ReturnCode_SUCCESS) {
                        ++error_num;
                    } else {
                        std::memcpy(frame, read_response->data().c_str(), read_response->size());
                        if (is_init) {
                            if (last_crc != gaia_apply::mach_read_from_4(frame + gaia_apply::FIL_PAGE_SPACE_OR_CHKSUM)) {
                                ++error_num;
                            }
                        } else {
                            is_init = true;
                            last_crc = gaia_apply::mach_read_from_4(frame + gaia_apply::FIL_PAGE_SPACE_OR_CHKSUM);
                        }
#define FSP_TRX_SYS_PAGE_NO 5
#define TRX_SYS_MYSQL_LOG_INFO (gaia_apply::FLAGS_univ_page_size - 1000)
#define TRX_SYS_MYSQL_LOG_NAME 12 /*!< MySQL log file name */
#define TRX_SYS_MYSQL_LOG_NAME_LEN 512
#define TRX_SYS_TRX_NUM_GTID \
   (TRX_SYS_MYSQL_LOG_INFO + TRX_SYS_MYSQL_LOG_NAME + TRX_SYS_MYSQL_LOG_NAME_LEN)
                        if (_space_id == gaia_apply::TRX_SYS_SPACE && _page_no == FSP_TRX_SYS_PAGE_NO) {
                            auto gtid_trx_no = gaia_apply::mach_read_from_8(frame + TRX_SYS_TRX_NUM_GTID);
                            std::cout << "GTID recovery trx_no:" << gtid_trx_no << std::endl;
                        }
                    }
                }
            }

            if (error_num && i != 2) {
                error_num = 0;
                is_init = false;
                sleep_for(200000 + i * 1000000);
            } else {
                break;
            }
        }

        Table table3(_raw_with_table, 0);
        table3.AddRowsWithName({"addr", "status", "empty", "crc", "lsn", "space_id", "page_no"
                });

        for (auto& it : read_response_map) {
            auto& addr = it.first;
            auto& read_response = *it.second.get();
            if (read_response.status().code() != pspb::Status_ReturnCode_SUCCESS) {
                table3.AddRowsValue({
                        addr,
                        "error",
                        read_response.status().msg()
                        });
            } else {
                std::memcpy(frame, read_response.data().c_str(), read_response.size());
                bool is_empty = false;
                bool corrupted = page_is_corrupted(frame, read_response.size(), &is_empty);
                table3.AddRowsValue({
                        addr,
                        corrupted ? "corrupted" : "ok",
                        is_empty,
                        gaia_apply::mach_read_from_4(frame + gaia_apply::FIL_PAGE_SPACE_OR_CHKSUM),
                        gaia_apply::mach_read_from_8(frame + gaia_apply::FIL_PAGE_LSN),
                        gaia_apply::page_get_space_id(frame),
                        gaia_apply::page_get_page_no(frame)
                        });
            }
        }

        table3.Display();

        if (error_num) {
            print_error("CheckFailed");
        }
        if (last_crc == 0) {
            print_error("PageIsEmpty");
        }
        if (read_response_map.size() != 3) {
            print_error("ReplicaSizeSmall");
        }
    }

    std::free(buf);
    return 0;
}

}
}
