/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/load_page_server_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class LoadPageServerSegment : public Command {
public:
    LoadPageServerSegment() {
        SetName("load-ps-segment");
        SetDesc("load segment replica data on page server");
        SetDescCn("在存储服务器上加载分片副本数据");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "the load segment cluster id", kstring);
        AddRequiredArgOption("segment-id", NULL, 's', "the load segment id", kuint32_t);
        
        AddExample("-a <ip> -p <port> -c gaia-test-perf -s 1");
    }
    virtual ~LoadPageServerSegment() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtoul(opt, NULL, 10));
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::LoadSegmentResponse& rsp);
private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
};

}
}
