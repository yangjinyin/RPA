/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/rlimit.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <sys/time.h>
#include <sys/resource.h>

namespace psvr {

int set_memory_limit(rlim_t rlim_cur, rlim_t rlim_max);

}
