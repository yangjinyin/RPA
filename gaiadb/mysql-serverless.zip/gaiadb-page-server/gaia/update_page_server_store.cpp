/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_page_server_store.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/update_page_server_store.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int UpdatePageServerStore::Run() {
    if (!_update_all) {
        if (_store_id < 0) {
            print_error("miss or error --id");
            return 1;
        }
        if (_store_path.empty()) {
            print_error("miss --path");
            return 1;
        }
    }

    if (_store_capacity < -1 && _store_size < -1 && !_clear_io_error) {
        print_error("miss --capacity or --size");
        return 1;
    }

    if (!_cluster_addr.empty()) {
        return RunCluster();
    }

    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    return RunOne(node);
}

int UpdatePageServerStore::RunCluster() {
    PsmInfo psm_info(_cluster_addr, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--cluster-addr parse failed, cant get server list");
        return 1;
    }

    if (!_force) {
        bool cf_ret = _update_all ?
                execute_confirm("Update all stores on cluster?") :
                execute_confirm("Update store:[id=%u, path=%s] on cluster?", _store_id, _store_path.c_str());
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    bool old_force = _force;
    _force = true;
    int ret = 0;
    for (auto& node : nodes) {
        ret |= RunOne(node);
    }
    _force = old_force;
    return ret;
}

int UpdatePageServerStore::RunOne(const base::EndPoint& node) {
    RpcStatus status;
    if (_update_all) {
        pspb::UpdateAllStoreRequest request;
        pspb::UpdateAllStoreResponse response;

        request.set_log_id(_log_id);
        if (_store_capacity >= -1) {
            request.set_store_capacity(_store_capacity);
        }
        if (_store_size >= -1) {
            request.set_store_size(_store_size);
        }
        if (_clear_io_error) {
            request.set_clear_io_error(true);
        }

        if (!_force) {
            bool cf_ret = execute_confirm("Update all stores?");
            if (!cf_ret) {
                printf("quit!\n");
                return 1;
            }
        }

        _client.Call(_log_id++, node, &pspb::ManagerService_Stub::UpdateAllStore, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }
        return Output(response);
    } else {
        pspb::UpdateStoreRequest request;
        pspb::UpdateStoreResponse response;

        request.set_log_id(_log_id);
        request.set_store_id(_store_id);
        request.set_store_path(_store_path);
        if (_store_capacity >= -1) {
            request.set_store_capacity(_store_capacity);
        }
        if (_store_size >= -1) {
            request.set_store_size(_store_size);
        }
        if (_clear_io_error) {
            request.set_clear_io_error(true);
        }

        if (!request.has_store_capacity()
                && !request.has_store_size()
                && !_clear_io_error) {
            print_error("miss --capacity or --size");
            return 1;
        }

        if (!_force) {
            bool cf_ret = execute_confirm("Update store:[id=%u, path=%s]?", _store_id, _store_path.c_str());
            if (!cf_ret) {
                printf("quit!\n");
                return 1;
            }
        }

        _client.Call(_log_id++, node, &pspb::ManagerService_Stub::UpdateStore, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }
        return Output(response);
    }
}

int UpdatePageServerStore::Format(const pspb::UpdateStoreResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

int UpdatePageServerStore::Format(const pspb::UpdateAllStoreResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 0);
    table.AddRowsWithName({
            "store_id", "store_path", "active",
            "original_capacity", "original_size"}, true);
    for (auto& store : rsp.stores()) {
        table.AddRowsValue({
                    store.id(),
                    store.path(),
                    store.active(),
                    get_unknown_type(store.has_original_capacity(), store.original_capacity(), "-"),
                    get_unknown_type(store.has_original_size(), store.original_size(), "-")
                });
    }
    table.Display();

    return 0;
}

}
}
