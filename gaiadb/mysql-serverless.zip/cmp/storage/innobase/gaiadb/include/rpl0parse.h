/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file include/rpl0parse.h
 Gaiadb redo log replication

 Authors: qiaohongyu@baidu.com, wanglonglong01@baidu.com
 *******************************************************/

#pragma once

#include <boost/lockfree/spsc_queue.hpp>
#include "rpl0assemble.h"

namespace rpl {

class RplParser;
extern RplParser *g_rpl_parser;

DECLARE_bool(rpl_enable_parallel_parse);
DECLARE_int32(rpl_parser_threads);

uint64_t parse_one_log_rec(byte *ptr, byte *end_ptr, mlog_id_t *type,
                           space_id_t *space_id, page_no_t *page_no,
                           byte **body, uint32_t *check_bits_len);

struct RawRecord {
  mlog_id_t type;
  space_id_t space;
  page_no_t page_no;
  byte *body;
  byte *end_ptr;
  lsn_t start_lsn;
  lsn_t end_lsn;
  RplAssembly *asmb;
  bool ibuf_merge{false};
  ulint ibuf_entry_counter{0};
};

class ParseWorker {
 public:
  ParseWorker(int32_t index) : index_(index) {
    thd_ = std::thread(parse_worker_routine, this);
  }
  virtual ~ParseWorker() { thd_.join(); }

  void enqueue_record(RawRecord record);
  static void parse_worker_routine(ParseWorker *pw);
  void reset_state() { finished_.store(false); }
  bool finished() { return finished_.load(); }

 private:
  boost::lockfree::spsc_queue<RawRecord, boost::lockfree::capacity<1024>>
      queue_;
  int32_t index_{0};
  std::atomic<bool> finished_{false};
  std::thread thd_;
};

class RplParser {
 private:
  RplParser();
  void reset_parse_worker();
  void wait_for_all_worker_finish();

 public:
  ~RplParser();
  static RplParser &get_instance();

  bool init();

  bool cleanup();
  void routine();

  void assemble_record(mlog_id_t type, space_id_t space_id, page_no_t page_no,
                       byte *body, byte *rec_end, lsn_t start_lsn,
                       lsn_t end_lsn, RplAssembly *assembly,
                       const bool &ibuf_sec_index_page_modificiaton,
                       const ulint &ibuf_counter);

  static bool is_page_mod_record_type(mlog_id_t type);

  bool try_shadow_parse_mtr(byte *ptr, byte *end_ptr, uint64_t &mtr_len,
                            uint64_t &n_records);
  bool parse_one_mtr(byte *ptr, byte *end_ptr, uint64_t mtr_len,
                     uint64_t n_records, RplAssembly *assembly);

  bool log_corrupt();
  void set_log_corrupt(bool log_corrupt);

  void parse_mdl_log(byte *body, space_id_t space_id, RplAssembly *assembly, lsn_t lsn);
  void parse_stats_update_log(byte *body, RplAssembly *assembly);

  void update_parse_speed(uint64_t parse_size);

  void resize_buf();
  lsn_t copy_fetch_buf(bool move = true);

 private:
  DISALLOW_COPY_AND_ASSIGN(RplParser);
  lsn_t parse_scan_lsn_ = 0;
  lsn_t parse_lsn_ = 0;
  std::atomic<uint64_t> parse_epoch_{1};

  bool limit_by_parse_buffer_ = false;

  alignas(ut::INNODB_CACHE_LINE_SIZE)
  ut::aligned_array_pointer<byte, OS_FILE_LOG_BLOCK_SIZE> parse_buf_;
  ulong cur_parse_buf_size_;
  ulong buf_pos_;
  ulong buf_size_;

  std::vector<ParseWorker *> parse_workers;
};

}  // namespace rpl
