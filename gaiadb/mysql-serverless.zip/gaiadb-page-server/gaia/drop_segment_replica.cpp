/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/drop_segment_replica.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/drop_segment_replica.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int DropSegmentReplica::Run() {
    RpcStatus status;
    gaiapb::DropReplicaRequest request;
    gaiapb::AckResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_segment_id < 1) {
        print_error("miss --segment-id or error, %u", _segment_id);
        return 1;
    }

    if (!_replica_id.has_val) {
        print_error("miss --replica-id or error, %u", _replica_id.val);
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Drop this segment replica?");
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    request.set_segment_id(_segment_id);
    request.set_replica_id(_replica_id.val);
    if (_replica_addr.size()) {
        request.set_addr(_replica_addr);
    }
    if (_replica_version.has_val) {
        request.set_version(_replica_version.val);
    }
    request.set_log_id(_log_id);
    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::drop_replica, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " drop segment replica failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("drop failed, all nodes failed");
    return Output(response);
}

int DropSegmentReplica::Format(const gaiapb::AckResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
