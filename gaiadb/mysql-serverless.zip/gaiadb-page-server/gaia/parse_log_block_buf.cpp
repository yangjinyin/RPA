/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/parse_log_block_buf.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <sys/ioctl.h>
#include <termios.h>
#include <sys/stat.h>
#include "gaia/parse_apply_rec.h"
#include "gaia/parse_log_block_buf.h"

namespace psvr {
namespace gaia {

int ParseLogBlockBuf::Run() {
    gaiadb::common::ut_crc32_init();
    BufPool buf_pool;

    if (!_buf_file.size()) {
        print_error("miss --buf-file");
        return 1;
    }

    BufBlockPtr buf_block = nullptr;
    gaia_apply::lsn_t page_apply_lsn = 0;
    gaia_apply::space_id_t apply_space_id = 0;
    gaia_apply::page_no_t apply_page_no = 0;
    int tfd = -1;
    std::shared_ptr<nullptr_t> guard_tfp(nullptr,
        [&tfd](nullptr_t) {
            if (tfd > -1) {
                close(tfd);
            }
        });
    if (!_page_file.empty()) {
        buf_block = buf_pool.AllocBufBlock(gaia_apply::FLAGS_univ_page_size);
        tfd = open(_page_file.c_str(), _page_file_update ? O_RDWR : O_RDONLY, S_IRUSR | S_IWUSR);
        if (tfd < 0) {
            print_error("open buf file failed, %s", strerror(errno));
            return 1;
        }
        ssize_t r = pread(tfd, buf_block->frame, gaia_apply::FLAGS_univ_page_size, 0);
        if (r != static_cast<ssize_t>(gaia_apply::FLAGS_univ_page_size)) {
            print_error("page file size invalid");
            return 1;
        }
        page_apply_lsn = buf_block_get_page_lsn(buf_block);
        apply_space_id = gaia_apply::page_get_space_id(buf_block->frame);
        apply_page_no = gaia_apply::page_get_page_no(buf_block->frame);
    }

    int fd = -1;
    lspb::psrv_get_log_response response;
    bool make_data = true;
    if (_ls_addr.size() && _ls_port > 0 && _segment_id > 0 && _fetch_lsn > 0) {

        base::EndPoint node;
        int ret = base::str2endpoint(_ls_addr.c_str(), _ls_port, &node);
        if (ret != 0) {
            print_error("--address and --port convert to endpoint error");
            return 1;
        }

        RpcStatus status;

        lspb::psrv_get_log_request request;

        brpc::Controller cntl;
        cntl.set_timeout_ms(_timeout_ms);
        cntl.set_log_id(_log_id);

        request.set_segment_id(_segment_id);
        request.set_fetch_lsn(_fetch_lsn);

        _client.Call(&cntl, node, &lspb::PageServerService_Stub::get_log, &request, &response, nullptr);
        if (cntl.Failed()) {
            print_error("%s", cntl.ErrorText().c_str());
            return 1;
        }

        std::cout << "fetch data size:" << response.data_returned().size();
    } else if (_buf_json_file.size()) {
        int json_fd = open(_buf_json_file.c_str(), O_RDONLY, S_IRUSR | S_IWUSR);
        if (json_fd < 0) {
            print_error("open json file failed, %s", strerror(errno));
            return 1;
        }

        std::shared_ptr<nullptr_t> guard_fp(nullptr,
                [json_fd](nullptr_t) {
                    if (json_fd > -1) {
                        close(json_fd);
                    }
                });

        struct stat sbuf;
        if (fstat(json_fd, &sbuf) != 0) {
            print_error("get json file size failed, %s", strerror(errno));
            return 1;
        }

        ssize_t file_size = sbuf.st_size;
        ssize_t buf_size = file_size;
        auto json_buf = static_cast<char*>(std::malloc(buf_size));
        if (!json_buf) {
            print_error("malloc json buf size failed, %s", strerror(errno));
            return 1;
        }

        if (pread(json_fd, json_buf, file_size, 0) != static_cast<ssize_t>(file_size)) {
            print_error("read json buf size failed, %s", strerror(errno));
            return 1;
        }

        std::string json(json_buf, file_size);
        std::string error;
        if (!jsonstr2pb(json, &response, &error)) {
            print_error("parser protobuf buf failed, %s", error.c_str());
            return 1;
        }

        std::cout << "json data size:" << response.data_returned().size();

        std::free(json_buf);
    } else {
        make_data = false;
    }

    if (make_data) {
        const uint32_t rsp_total_len = response.total_len();
        const uint32_t rsp_data_len = response.data_returned().size();
        if (rsp_total_len != rsp_data_len) {
            print_error("response data size mismatch");
            return 1;
        }

        const auto* log_block_data = reinterpret_cast<const gaia_apply::byte*>(&response.data_returned()[0]);
        const uint32_t checksum = gaiadb::common::ut_crc32(log_block_data, rsp_total_len);
        if (checksum != response.data_checksum()) {
            print_error("response data checksum error");
            return 1;
        }

        auto flags = O_CREAT | O_RDWR;
        if (!_force) {
            flags |= O_EXCL;
        }
        fd = open(_buf_file.c_str(), flags, S_IRUSR | S_IWUSR);
        if (fd < 0) {
            print_error("open buf file failed, %s", strerror(errno));
            return 1;
        }

        ssize_t write_size = pwrite(fd, log_block_data, rsp_total_len, 0);
        if (static_cast<uint32_t>(write_size) != rsp_total_len) {
            print_error("pwrite file failed, %s", strerror(errno));
            return 1;
        }

        std::cout << "make data ok,"
            << " size:" << rsp_data_len
            << std::endl;

    } else {
        fd = open(_buf_file.c_str(), O_RDONLY, S_IRUSR | S_IWUSR);
        if (fd < 0) {
            print_error("open buf file failed, %s", strerror(errno));
            return 1;
        }
    }

    std::shared_ptr<nullptr_t> guard_fp(nullptr,
            [fd](nullptr_t) {
                if (fd > -1) {
                    close(fd);
                }
        });

    struct stat sbuf;
    if (fstat(fd, &sbuf) != 0) {
        print_error("get file size failed, %s", strerror(errno));
        return 1;
    }

    ssize_t file_size = sbuf.st_size;
    ssize_t buf_size = (4 << 20);
    auto buf = static_cast<gaia_apply::byte*>(std::malloc(buf_size));
    if (!buf) {
        print_error("malloc buf size failed, %s", strerror(errno));
        return 1;
    }
    std::cout << "file_size:[" << file_size << "]" << std::endl;

    ssize_t off = 0;
    ssize_t buf_off = 0;
    uint64_t apply_records_size = 0;
    while (off < file_size) {
        auto read_size = pread(fd, buf + buf_off, buf_size - buf_off, off);
        if (read_size <= 0) {
            std::cout << "read file end,"
                << " off:[" << off
                << "] file_size:[" << file_size
                << "] read_size:[" << read_size
                << "] buf_off:[" << buf_off
                << "] error:[" << strerror(errno)
                << "]" << std::endl;
            return 0;
        }

        //std::cout << "pread data,"
            //<< " off:[" << off
            //<< "] read_size:[" << read_size
            //<< "]" << std::endl;

        off += buf_size - buf_off;

        ssize_t buf_end = buf_off + read_size;
        gaia_apply::byte* start_ptr = buf + buf_off;
        gaia_apply::byte* end_ptr = buf + buf_end;
        size_t consumed_size = 0;

        if (!parse_records(start_ptr, end_ptr,
                    &page_apply_lsn, &apply_records_size,
                    buf_block, &apply_space_id, &apply_page_no,
                    0, &consumed_size)) {
            return 1;
        }

        buf_off += consumed_size;

        assert(buf_end >= buf_off);
        std::memmove(buf, buf + buf_off, buf_end - buf_off);
        buf_off = buf_end - buf_off;
    }

    if (buf_off != 0) {
        print_error("redo file ends with incomplete record, remaining:%ld",
                buf_off);
        return 1;
    }

    if (buf_block && _page_file_update && apply_records_size > 0) {
        if (!page_reset_checksum(buf_block->frame,  gaia_apply::FLAGS_univ_page_size,
                    apply_space_id, apply_page_no, page_apply_lsn)) {
            std::cout << "reset page checksum fail,"
                << " apply_records_size:[" << apply_records_size
                << "] page_apply_lsn:[" << page_apply_lsn
                << "]" << std::endl;;
            return 1;
        }
        ssize_t w = pwrite(tfd, buf_block->frame, gaia_apply::FLAGS_univ_page_size, 0);
        if (w != static_cast<ssize_t>(gaia_apply::FLAGS_univ_page_size)) {
            print_error("update page size failed");
            return 1;
        }
        std::cout << "update page ok,"
            << " apply_records_size:[" << apply_records_size
            << "] page_apply_lsn:[" << page_apply_lsn
            << "]" << std::endl;;
    }

    return 0;
}

}
}
