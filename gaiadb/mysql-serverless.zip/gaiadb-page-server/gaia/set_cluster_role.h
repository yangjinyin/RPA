/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_cluster_role.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class SetClusterRole : public Command {
public:
    SetClusterRole() {
        SetName("set-cluster-role");
        SetDesc("set cluster role information");
        SetDescCn("设置集群角色信息");

        AddPsmClusterOption();
        AddRequiredArgOption("role", &_long_opt_val, kOptMax + 1, "cluster role type", kstring);
        
        AddExample("--manager-address \"bns://xxx\" --role PRIMARY");
    }
    virtual ~SetClusterRole() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _role = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::SetClusterRoleResponse& rsp);

private:
    std::string _manager_address {};
    std::string _role {};
};

}
}
