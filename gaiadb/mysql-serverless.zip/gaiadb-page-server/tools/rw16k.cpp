/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/rw16k.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <cerrno>
#include <cstdio>
#include <unistd.h>
#include <string.h>
#include <memory>
#include <fcntl.h>
#include <fcntl.h>
#include <cstdlib>
#include "psvr/signal.h"

namespace psvr {

constexpr uint32_t kTestSize = 16 * 1024;

class T16K : public SignalStop {
public:
    T16K() : _stop(false) {}
    ~T16K() {}

    virtual void Stop () override {
        _stop = true;
    }

    int32_t Run(int32_t fd) {
        bool i = 0;
        char* buf = new char[kTestSize];
        while (!_stop) {
            memset(buf, 'a' + i, kTestSize);
            ssize_t n = pwrite(fd, buf, kTestSize, 0/*offset*/);
            if (n != static_cast<ssize_t>(kTestSize)) {
                printf("pwirte with error:%s\n", strerror(errno));
                break;
            }
            i = !i;
        }
        delete[] buf;
        return 0;
    }

    int32_t Check(int32_t fd) {
        char* buf = new char[kTestSize];
        if (pread(fd, buf, kTestSize, 0) != static_cast<ssize_t>(kTestSize)) {
            printf("pread with error:%s\n", strerror(errno));
            delete[] buf;
            return -1;
        }
        char* buf2 = new char[kTestSize];
        memset(buf2, 'a', kTestSize);
        if (memcmp(buf, buf2, kTestSize) == 0) {
            printf("check ok, 0\n");
            delete[] buf;
            delete[] buf2;
            return 0;
        }
        memset(buf2, 'a' + 1, kTestSize);
        if (memcmp(buf, buf2, kTestSize) == 0) {
            printf("check ok, 1\n");
            delete[] buf;
            delete[] buf2;
            return 0;
        }
        printf("check failed\n");
        delete[] buf;
        delete[] buf2;
        return 1;
    }

private:
    bool _stop;
};

}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("./%s <test_file_name> <flags:0/1/2>\n", argv[0]);
        printf("./Usage: kill process when write 16kb data to file (without sync), check data right\n");
        printf("    -flags:\n");
        printf("        0: check\n");
        printf("        1: run test\n");
        return -1;
    }
    char* file = argv[1];
    auto type = std::strtol(argv[2], NULL, 0);
    int32_t fd = -1;
    if (type == 1) {
        fd = open(file, O_CREAT | O_RDWR | O_EXCL, S_IRUSR | S_IWUSR);
    } else {
        fd = open(file, O_RDWR, S_IRUSR | S_IWUSR);
    }
    if (fd < 0) {
        printf("open file:%s failed:%s\n", file, strerror(errno));
        return -1;
    }
    psvr::T16K test_16k;
    if (test_16k.SignalRegister()) {
        printf("register signal failed:%d\n", getpid());
        return -1;
    }
    int32_t ret = 0;
    if (type == 1) {
        printf("run with my pid:%d\n", getpid());
        fflush(stdout);
        ret = test_16k.Run(fd);
        printf("stop run\n");
    } else {
        ret = test_16k.Check(fd);
    }
    return ret;
}
