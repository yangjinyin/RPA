/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/parse.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/config.h"
#include "psvr/control.h"
#include "psvr/utils.h"
#include "psvr/parse_context.h"

namespace psvr {

static uint64_t parse_get_delay_us(uint32_t retry_times,
        uint64_t retry_interval_us = FLAGS_psvr_parser_delay_min_us,
        uint64_t max_delay_us = FLAGS_psvr_parser_delay_max_us) {
    return get_delay_us(retry_times, retry_interval_us, max_delay_us);
}

static const char* action2str(Parser::Action action) {
    switch (action) {
    case Parser::Action::kParse:
        return "kParse";
    case Parser::Action::kDoRpcQuota:
        return "kDoRpcQuota";
    case Parser::Action::kDisposeRpcQuota:
        return "kDisposeRpcQuota";
    case Parser::Action::kDisposeGetAllSpaceId:
        return "kDisposeGetAllSpaceId";
    default:
        return "unknown";
    }
}

const char* Parser::action2str(Parser::Action action) {
    return psvr::action2str(action);
}

static inline bool parse_is_get_metadata_action(Parser::Context* ctx) {
    return (ctx->action == Parser::Action::kDoRpcQuota
            || ctx->action == Parser::Action::kDisposeRpcQuota);
}

bool operator>=(std::shared_ptr<FlowQuota> quota, Parser::Context* /*ctx*/) {
    return quota->GetQuota(1) == 0;
}

Parser::Parser(ClientPtr client, ControlWeakPtr control)
    : Model<Parser>(client, control),
    _thread_num(FLAGS_psvr_parser_thread_num),
    _metadata_thread_num(1),
    _stat_get_meta_qps(kSlaWindowSize),
    _stat_get_meta_fail_count(kSlaWindowSize),
    _stat_get_meta_limit_quota_count(kSlaWindowSize),
    _stat_parse_empty_qps(kSlaWindowSize),
    _stat_parse_log_block_lat(kSlaWindowSize),
    _stat_parse_log_block_size(kSlaWindowSize),
    _stat_parse_log_block_include_record_size(kSlaWindowSize),
    _stat_parse_error_count(kSlaWindowSize) {
    _thread_pool.reset(new ThreadPoolType);
    _rpc_quota_thread_pool.reset(new ThreadPoolType);
    _quota_thread.reset(new QuotaThreadType);
    Expose();
}

void Parser::Expose() {
#ifndef GTEST
    _stat_get_meta_qps.expose("psvr_get_meta_qps");
    _stat_get_meta_fail_count.expose("psvr_get_meta_fail_count");
    _stat_get_meta_limit_quota_count.expose("psvr_get_meta_limit_quota_count");
    _stat_parse_empty_qps.expose("psvr_parse_empty_log_block_qps");
    _stat_parse_log_block_lat.expose("psvr_parse_log_block");
    _stat_parse_log_block_size.expose("psvr_parse_log_block_size");
    _stat_parse_log_block_include_record_size.expose("psvr_parse_log_block_include_record_size");
    _stat_parse_error_count.expose("psvr_parse_error_count");
#endif
}

bool Parser::SetUp() {
    ControlPtr control = _control.lock();
    if (!control) {
        LOG(ERROR) << "failed, control is release";
        return false;
    }

    if (control->multi_type()) {
        _thread_num = FLAGS_multi_psvr_parser_thread_num_per_store * _store_count;
        _metadata_thread_num = FLAGS_multi_psvr_get_metadata_thread_num;
    }

    if (_thread_num < 1) {
        LOG(ERROR) << "failed, parser thread num == 0";
        return false;
    }

    typename QuotaThreadType::Fn quota_fn
        = std::bind(&Parser::OnGetQuota, this, std::placeholders::_1);
    _quota_thread->Start("parser_quota", quota_fn, &FLAGS_psvr_parser_wait_quota_sleep_interval_us);

    // start a shared thread pool
    typename ThreadPoolType::TaskFn fn
        = std::bind(&Parser::OnCompletion, this, std::placeholders::_1);
    if (!_thread_pool->Start("parser", control->timer(), _thread_num,
                FLAGS_multi_psvr_parser_thread_enable_shared, fn)) {
        LOG(ERROR) << "parser thread pool start failed";
        return false;
    }
    if (!_rpc_quota_thread_pool->Start("rpc_quota", control->timer(), _metadata_thread_num,
                FLAGS_multi_psvr_parser_thread_enable_shared, fn)) {
        LOG(ERROR) << "rpc quota thread pool start failed";
        _thread_pool->Stop(true);
        return false;
    }
    return true;
}

void Parser::TearDown() {
    LOG(NOTICE) << "parser will stop ...";
    _quota_thread->Stop(false);
    _thread_pool->Stop(false);
    _rpc_quota_thread_pool->Stop(false);
    _stat_get_meta_qps.hide();
    _stat_get_meta_fail_count.hide();
    _stat_get_meta_limit_quota_count.hide();
    _stat_parse_empty_qps.hide();
    _stat_parse_log_block_lat.hide();
    _stat_parse_log_block_size.hide();
    _stat_parse_log_block_include_record_size.hide();
    _stat_parse_error_count.hide();
}

void Parser::Join() {
    LOG(NOTICE) << "parser will join ...";
    _quota_thread->Stop(true);
    _thread_pool->Stop(true);
    _rpc_quota_thread_pool->Stop(true);
    LOG(NOTICE) << "parser will join ok";
}

bool Parser::IncOrDecThreadNum() {
    bool ret = false;
    {
        uint32_t cfg_n = FLAGS_multi_psvr_get_metadata_thread_num;
        uint32_t cur_n = IncOrDecSingleThreadNum(_metadata_thread_num, cfg_n, _rpc_quota_thread_pool,
                [this](Context* ctx){
                    Schedule(ctx TRACE_FILE_LINE_CC);
                });
        LOG_IF(NOTICE, cfg_n != cur_n) << "parser metadata thread num per store changed,"
            << " old:[" << cur_n
            << "] new:[" << cfg_n
            << "]";
        ret = cfg_n != cur_n;
    }
    {
        uint32_t cfg_n = FLAGS_multi_psvr_parser_thread_num_per_store * _store_count;
        uint32_t cur_n = IncOrDecSingleThreadNum(_thread_num, cfg_n, _thread_pool,
                [this](Context* ctx){
                    Schedule(ctx TRACE_FILE_LINE_CC);
                });
        LOG_IF(NOTICE, cfg_n != cur_n) << "parser thread num per store changed,"
            << " old:[" << (cur_n / _store_count)
            << "] new:[" << (cfg_n / _store_count)
            << "]";
        ret = ret || cfg_n != cur_n;
    }
    return ret;
}

void Parser::Dispatch(SegmentPtr segment TRACE_FILE_LINE_DC, gaia_apply::lsn_t lsn) {
    LOG(TRACE) << segment << " push log block to parse, lsn:[" << lsn << "]" << TRACE_FILE_LINE_LOG_STR;
    LogBlockPtr log_block = segment->NextParseLogBlock(true);
    if (log_block) {
        auto* ctx = new Context(Action::kParse, segment, log_block);
        ctx->log_id = log_block->log_id;
        Schedule(ctx TRACE_FILE_LINE_ARG_CC);
    }
}

void Parser::AddGetAllSpaceIdEvent(SegmentPtr segment TRACE_FILE_LINE_DC) {
    LogBlockPtr log_block(new LogBlock(EventOp::kGetAllSapceId,
                gaia_apply::SPACE_UNKNOWN, kSpaceStatusUnknown));
    segment->fetch_log_block_queue().PushFront(log_block);
    Dispatch(segment TRACE_FILE_LINE_ARG_CC, 0);
}

void Parser::AddGetSpaceMetaEvent(SegmentPtr segment TRACE_FILE_LINE_DC,
        gaia_apply::space_id_t id, ggpb::Closure* closure, pspb::Status* status) {
    if (!segment->GetSpaceReqLock(id)) {
        brpc::ClosureGuard closure_guard(closure);
        if (status) {
            set_rpc_status(status, pspb::Status::LIMIT, "get space req lock failed");
        }
        LOG(TRACE) << segment << " get lock failed";
        return;
    }
    ClusterPtr cluster = segment->cluster();
    auto event = cluster->rpc_quota()->CreateSpaceMetaEvent(segment, id, closure, status);
    if (event) {
        _stat_get_meta_qps << 1;
        auto* ctx = new Context(Action::kDoRpcQuota, cluster, EventOp::kGetSpaceMeta);
        ctx->client_id_rand = id;
        ctx->space_meta_event = event;
        ctx->stat_timer.reset();
        CheckQuota(cluster->rpc_quota(), ctx TRACE_FILE_LINE_ARG_CC);
    } else {
        set_segment_cluster_statistic(segment, stat_psm_req_merge_count, 1);
    }
}

void Parser::AddGetSpaceExtentEvent(SegmentPtr segment TRACE_FILE_LINE_DC, gaia_apply::space_id_t id,
        gaia_apply::page_no_t logical_page_no, ggpb::Closure* closure, pspb::Status* status) {
    return AddGetSpaceExtentEvent(segment TRACE_FILE_LINE_ARG_CC,
            id, logical_page_no, kInvalidOffset, closure, status);
}

void Parser::AddGetSpaceExtentEvent(SegmentPtr segment TRACE_FILE_LINE_DC,
        gaia_apply::space_id_t id, gaia_apply::page_no_t logical_page_no,
        uint64_t search_offset, ggpb::Closure* closure, pspb::Status* status){
    const auto begin_extent_id = calc_begin_extent_id(logical_page_no);
    LOG(TRACE) << segment << " get space extent,"
        << " space:[" << id
        << "] logical_page_no:[" << logical_page_no
        << "] search_offset:[" << search_offset
        << "] begin_extent_id:[" << begin_extent_id
        << "]" << TRACE_FILE_LINE_LOG_STR;
    if (!segment->GetSpaceExtentReqLock(id, begin_extent_id)) {
        brpc::ClosureGuard closure_guard(closure);
        if (status) {
            set_rpc_status(status, pspb::Status::LIMIT, "get space extent lock failed");
        }
        LOG(TRACE) << segment << " get lock failed or not exists space,"
            << " space:[" << id
            << "] logical_page_no:[" << logical_page_no
            << "] search_offset:[" << search_offset
            << "] begin_extent_id:[" << begin_extent_id
            << "]";
        return;
    }

    uint32_t search_extent_id = kInvalidExtentId;
    if (search_offset != kInvalidOffset) {
        search_extent_id = search_offset / GAIADB_EXTENT_SIZE;
    }

    ClusterPtr cluster = segment->cluster();
    auto event = cluster->rpc_quota()->CreateSpaceExtentEvent(segment, id, begin_extent_id,
            search_extent_id, logical_page_no, closure, status);
    if (event) {
        _stat_get_meta_qps << 1;
        auto* ctx = new Context(Action::kDoRpcQuota, cluster, EventOp::kGetSpaceExtent);
        ctx->client_id_rand = id + begin_extent_id;
        ctx->space_extent_event = event;
        ctx->stat_timer.reset();
        CheckQuota(cluster->rpc_quota(), ctx TRACE_FILE_LINE_ARG_CC);
    } else {
        set_segment_cluster_statistic(segment, stat_psm_req_merge_count, 1);
    }
}

void Parser::AddGetPeerEvent(SegmentPtr segment TRACE_FILE_LINE_DC,
        ggpb::Closure* closure, pspb::Status* status) {
    if (!segment->GetPeerReqLock()) {
        brpc::ClosureGuard closure_guard(closure);
        if (status) {
            set_rpc_status(status, pspb::Status::LIMIT, "get peer lock failed");
        }
        LOG(TRACE) << segment << " get lock failed";
        return;
    }
    ClusterPtr cluster = segment->cluster();
    auto event = cluster->rpc_quota()->CreatePeerEvent(segment, closure, status);
    if (event) {
        _stat_get_meta_qps << 1;
        auto* ctx = new Context(Action::kDoRpcQuota, cluster, EventOp::kGetPeer);
        ctx->client_id_rand = segment->segment_id();
        ctx->peer_event = event;
        ctx->stat_timer.reset();
        CheckQuota(cluster->rpc_quota(), ctx TRACE_FILE_LINE_ARG_CC);
    } else {
        set_segment_cluster_statistic(segment, stat_psm_req_merge_count, 1);
    }
}

void Parser::AddClearSapceStatusEvent(SegmentPtr segment TRACE_FILE_LINE_DC) {
    LogBlockPtr log_block(new LogBlock(EventOp::kClearSpaceStatus,
                gaia_apply::SPACE_UNKNOWN, kSpaceStatusUnknown));
    segment->fetch_log_block_queue().PushFront(log_block);
    Dispatch(segment TRACE_FILE_LINE_ARG_CC, 0);
}

const Parser::ThreadPoolTypePtr& Parser::GetThreadPool(Context* ctx) const {
    return parse_is_get_metadata_action(ctx) ? _rpc_quota_thread_pool : _thread_pool;
}

bool Parser::Execute(Context* ctx) {
    SegmentPtr segment = ctx->segment.lock();
    segment_set_stage_info_with_action(segment, pspb::ParseStageSchedule, ctx->action);
    if (!GetThreadPool(ctx)->EmergentExecute(ctx)) {
        if (_stopped) {
            std::unique_ptr<Context> ctx_guard(ctx);
        } else {
            psvr_terminate();
        }
        return false;
    }
    return true;
}

void Parser::SetCtxClientId(Context* ctx) {
    static std::atomic<uint32_t> round_robin_id = 0;
    const bool is_meta_action = parse_is_get_metadata_action(ctx);
    if (is_meta_action && ctx->cluster) {
        ctx->client_id = (ctx->cluster->hash_val() + ctx->client_id_rand) % _metadata_thread_num;
        return;
    }
    if (auto segment = ctx->segment.lock(); segment) {
        ctx->client_id = segment->hash_val() % _thread_num;
        return;
    }
    auto idx = round_robin_id.fetch_add(1, std::memory_order_relaxed);
    ctx->client_id = idx % (is_meta_action ? _metadata_thread_num : _thread_num);
}

void Parser::Schedule(Context* ctx TRACE_FILE_LINE_DC, uint64_t delay_us, bool is_retry) {
    PSVR_LOG_CTX(TRACE, ctx) << "ctx action:[" << static_cast<uint32_t>(ctx->action) << "," << action2str(ctx->action)
        << "] retry_times:[" << ctx->retry_times
        << "] ctx:[" << ctx
        << "]" << TRACE_FILE_LINE_LOG_STR;
    if (BAIDU_UNLIKELY(_stopped)) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }
    SetCtxClientId(ctx);
    if (is_retry) {
        ++ctx->retry_times;
    }
    SegmentPtr segment = ctx->segment.lock();
    segment_set_stage_info_with_action(segment, pspb::ParseStageSchedule, ctx->action);
    if (delay_us == 0) {
        if (GetThreadPool(ctx)->Execute(ctx)) {
            return;
        }
    } else {
        if (GetThreadPool(ctx)->Schedule(ctx, delay_us)) {
            return;
        }
    }

    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }

    PSVR_LOG_CTX(ERROR, ctx) << "dispatch segment to parser pool failed,"
        << TRACE_FILE_LINE_LOG_STR;
    psvr_terminate();
}

void Parser::OnCompletion(Context* ctx) {
    PSVR_LOG_CTX(TRACE, ctx) << "ctx action:[" << static_cast<uint32_t>(ctx->action) << "," << action2str(ctx->action)
        << "] retry_times:[" << ctx->retry_times
        << "] ctx:[" << ctx
        << "]";
    if (BAIDU_UNLIKELY(_stopped)) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }

    SegmentPtr segment = ctx->segment.lock();
    segment_set_stage_info_with_action(segment, pspb::ParseStageDo, ctx->action);

    switch (ctx->action) {
    case Action::kParse:
        return ParseLogBlock(ctx);
    case Action::kDisposeGetAllSpaceId:
        return DisposeGetAllSpaceId(ctx);
    case Action::kDoRpcQuota:
        switch (ctx->event) {
        case EventOp::kGetSpaceMeta:
            return GetSpaceMeta(ctx);
        case EventOp::kGetSpaceExtent:
            return GetSpaceExtent(ctx);
        case EventOp::kGetPeer:
            return GetPeer(ctx);
        default:
            PSVR_ASSERT(false);
            return;
        }
    case Action::kDisposeRpcQuota:
        switch (ctx->event) {
        case EventOp::kGetSpaceMeta:
            return DisposeGetSpaceMeta(ctx);
        case EventOp::kGetSpaceExtent:
            return DisposeGetSpaceExtent(ctx);
        case EventOp::kGetPeer:
            return DisposeGetPeer(ctx);
        default:
            PSVR_ASSERT(false);
            return;
        }
    default:
        PSVR_ASSERT(false);
        return;
    }
}

void Parser::DoNextLogBlock(Context* ctx) {
    define_segment_or_return_invalid(ctx);
    std::unique_ptr<Context> ctx_guard(ctx);
    LogBlockPtr log_block = segment->NextParseLogBlock(false);
    if (log_block) {
        ctx->SetForNextLogBlock(Action::kParse, log_block);
        ctx->log_id = log_block->log_id;
        Schedule(ctx_guard.release() TRACE_FILE_LINE_CC);
        return;
    }
    segment_set_stage_info(segment, pspb::ParseStageIdle);
}

void Parser::CheckQuota(RpcQuotaPtr rpc_quota, Context* ctx TRACE_FILE_LINE_DC) {
    if (GetQuota(rpc_quota, ctx)) {
        ctx->has_quota = true;
        Schedule(ctx TRACE_FILE_LINE_ARG_CC);
    }
}

bool Parser::GetQuota(RpcQuotaPtr rpc_quota, Context* ctx) {
    if (!_quota_thread->GetQuota(ctx, rpc_quota->flow_quota())) {
        return false;
    }
    return true;
}

void Parser::OnGetQuota(Context* ctx) {
    ctx->has_quota = true;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Parser::GetSpaceMeta(Context* ctx) {
    define_control_or_return_invalid(ctx);
    ClusterPtr cluster = ctx->cluster;
    RpcQuotaPtr rpc_quota = cluster->rpc_quota();

    if (!ctx->has_quota) {
        LOG(TRACE) << "not quota, wait retry";
        if (!GetQuota(rpc_quota, ctx)) {
            _stat_get_meta_limit_quota_count << 1;
            return;
        }
    }

    SegmentPtr segment = rpc_quota->GetSpaceMetaEventFirstSegment(ctx->space_meta_event);
    if (!segment) {
        _stat_get_meta_fail_count << 1;
        LOG(TRACE) << "all segments are invalid";
        std::unique_ptr<Context> ctx_guard(ctx);
        rpc_quota->RemoveSpaceMetaEvent(ctx->space_meta_event,
            [](SegmentPtr seg, gaia_apply::space_id_t space_id, pspb::Status* st, const EventClosureArgType&){
                if (st) {
                    set_rpc_status(st, pspb::Status::INVALID, "all segments are invalid");
                }
                seg->PutSpaceReqLock(space_id);
            });
        return;
    }

    PsmInfoPtr psm_info = segment->GetPsmInfo();
    std::vector<base::EndPoint> nodes;
    if (!psm_info->GetOrRefreshNodes(&nodes)) {
        _stat_get_meta_fail_count << 1;
        LOG(TRACE) << "refresh psm list failed";
        control->RefreshPsmInfo(psm_info);
        Schedule(ctx TRACE_FILE_LINE_CC, parse_get_delay_us(ctx->retry_times), true);
        return;
    }

    ctx->psm_info = psm_info;
    auto* rpc_ctx = new RpcGetSpaceMetaCtx;
    rpc_ctx->servers = std::move(nodes);
    rpc_ctx->request.set_space_id(ctx->space_meta_event->key());
    rpc_ctx->request.set_need_encryption_info(true);
    rpc_ctx->request.set_cluster_id(cluster->name());

    auto rpc_closure = brpc::NewCallback(this, &Parser::OnGetSpaceMeta, ctx, rpc_ctx);
    control->client()->GetSpaceMeta(rpc_ctx, rpc_closure);
}

void Parser::OnGetSpaceMeta(Context* ctx, RpcGetSpaceMetaCtx* rpc_ctx) {
    ctx->rpc_get_space_meta_ctx.reset(rpc_ctx);
    ctx->action = Action::kDisposeRpcQuota;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Parser::DisposeGetSpaceMeta(Context* ctx) {
    auto rpc_ctx = ctx->rpc_get_space_meta_ctx.release();
    std::unique_ptr<RpcGetSpaceMetaCtx> rpc_ctx_guard(rpc_ctx);
    define_control_or_return_invalid(ctx);
    ClusterPtr cluster = ctx->cluster;
    RpcQuotaPtr rpc_quota = cluster->rpc_quota();

    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        _stat_get_meta_fail_count << 1;
        set_cluster_stat(cluster, stat_psm_req_err_count, 1);
        if (!not_exists) {
            if (rpc_ctx->RetryNext()) {
                auto rpc_closure = brpc::NewCallback(this, &Parser::OnGetSpaceMeta,
                        ctx, rpc_ctx_guard.release());
                control->client()->GetSpaceMeta(rpc_ctx, rpc_closure);
            } else {
                control->RefreshPsmInfo(ctx->psm_info);
                ctx->action = Action::kDoRpcQuota;
                ctx->has_quota = false;
                Schedule(ctx TRACE_FILE_LINE_CC, parse_get_delay_us(ctx->retry_times), true);
            }
            return;
        }
    }

    std::unique_ptr<Context> ctx_guard(ctx);
    set_cluster_stat(cluster, stat_psm_req_lat, ctx->stat_timer.u_elapsed());
    ctx->psm_info->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());
    bool is_enable_encrypt = false;

    if (!not_exists) {
        const gaiapb::SpaceMeta& space_meta = rpc_ctx->response.space_meta();
        if (space_meta.physical_page_size() != gaia_apply::FLAGS_univ_page_size
                || space_meta.logical_page_size() != gaia_apply::FLAGS_univ_page_size) {
            LOG(ERROR) << "get cluster invalid space size, psm set error?"
                << " cluster:[" << cluster->name()
                << "] space:[" << rpc_ctx->request.space_id()
                << "] physical_page_size:[" << space_meta.physical_page_size()
                << "] logical_page_size:[" << space_meta.logical_page_size()
                << "] expect_size:[" << gaia_apply::FLAGS_univ_page_size
                << "]";
            return;
        }
        if (space_meta.has_encryption_info()) {
            const gaiapb::EncryptionInfo& encryption_info_pb = space_meta.encryption_info();
            EncryptHelperPtr encrypt_helper = cluster->encrypt_helper();
            if (encrypt_helper->cipher_stream().get() == nullptr &&
                !encrypt_helper->InitCipherStream(space_meta.encryption_info())) {
                LOG(ERROR) << "init cipher stream failed, cluster:[" << cluster->name()
                           << "] encryption_key:[" << encryption_info_pb.encryption_key()
                           << "] encryption_iv:[" << encryption_info_pb.encryption_iv()
                           << "] encryption_alg:[" << encryption_info_pb.encryption_alg() << "]";
                return;
            }
            is_enable_encrypt = true;
        }
    }

    rpc_quota->RemoveSpaceMetaEvent(ctx->space_meta_event,
            [this, not_exists, is_enable_encrypt](SegmentPtr seg,
                    gaia_apply::space_id_t space_id, pspb::Status* st, const EventClosureArgType&){
                if (st) {
                    set_rpc_status(st,
                            not_exists ? pspb::Status::NOT_EXISTS : pspb::Status::SUCCESS,
                            "segment:%s/%u space:%u meta %s",
                            seg->cluster_id().c_str(), seg->segment_id(), space_id,
                            not_exists ? "not exists" : "ok");
                }
                seg->InitSpaceStatusWithPsm(space_id, not_exists);
                Dispatch(seg TRACE_FILE_LINE_CC, 0);
                uint32_t encrypt_status = kSpaceEncryptStatusWithPSM;
                if (is_enable_encrypt) {
                    encrypt_status |= kSpaceEncryptStatusEnable;
                }
                seg->SetSpaceEncryptStatus(space_id, encrypt_status);
            });
}

void Parser::GetSpaceExtent(Context* ctx) {
    define_control_or_return_invalid(ctx);
    ClusterPtr cluster = ctx->cluster;
    RpcQuotaPtr rpc_quota = cluster->rpc_quota();

    if (!ctx->has_quota) {
        LOG(TRACE) << "not quota, wait retry";
        if (!GetQuota(rpc_quota, ctx)) {
            _stat_get_meta_limit_quota_count << 1;
            return;
        }
    }

    SegmentPtr segment = rpc_quota->GetSpaceExtentEventFirstSegment(ctx->space_extent_event);
    if (!segment) {
        _stat_get_meta_fail_count << 1;
        LOG(TRACE) << "all segments are invalid";
        std::unique_ptr<Context> ctx_guard(ctx);
        rpc_quota->RemoveSpaceExtentEvent(ctx->space_extent_event,
            [](SegmentPtr seg, const event_space_extent_t& fold, pspb::Status* st, const EventClosureArgType&){
                if (st) {
                    set_rpc_status(st, pspb::Status::INVALID, "all segments are invalid");
                }
                seg->PutSpaceExtentReqLock(fold.space_id, fold.begin_extent_id);
            });
        return;
    }

    PsmInfoPtr psm_info = segment->GetPsmInfo();
    std::vector<base::EndPoint> nodes;
    if (!psm_info->GetOrRefreshNodes(&nodes)) {
        _stat_get_meta_fail_count << 1;
        control->RefreshPsmInfo(psm_info);
        Schedule(ctx TRACE_FILE_LINE_CC, parse_get_delay_us(ctx->retry_times), true);
        return;
    }

    ctx->psm_info = psm_info;
    const event_space_extent_t& fold = ctx->space_extent_event->key();
    auto rpc_ctx = new RpcGetSpaceExtentMapCtx;
    rpc_ctx->servers = std::move(nodes);
    rpc_ctx->request.set_space_id(fold.space_id);
    rpc_ctx->request.set_begin_extent_id(fold.begin_extent_id);
    rpc_ctx->request.set_num(FLAGS_psvr_get_extent_size);
    rpc_ctx->request.set_need_physical_extent_id(true);
    rpc_ctx->request.set_use_bytes(FLAGS_psvr_get_extent_map_with_high_performance);
    rpc_ctx->request.set_cluster_id(cluster->name());

    auto rpc_closure = brpc::NewCallback(this, &Parser::OnGetSpaceExtent, ctx, rpc_ctx);
    control->client()->GetSpaceExtentMap(rpc_ctx, rpc_closure);
}

void Parser::OnGetSpaceExtent(Context* ctx, RpcGetSpaceExtentMapCtx* rpc_ctx) {
    ctx->rpc_get_space_extent_ctx.reset(rpc_ctx);
    ctx->action = Action::kDisposeRpcQuota;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Parser::DisposeGetSpaceExtent(Context* ctx) {
    auto rpc_ctx = ctx->rpc_get_space_extent_ctx.release();
    std::unique_ptr<RpcGetSpaceExtentMapCtx> rpc_ctx_guard(rpc_ctx);
    define_control_or_return_invalid(ctx);
    ClusterPtr cluster = ctx->cluster;
    RpcQuotaPtr rpc_quota = cluster->rpc_quota();

    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        _stat_get_meta_fail_count << 1;
        set_cluster_stat(cluster, stat_psm_req_err_count, 1);
        if (!not_exists) {
            if (rpc_ctx->RetryNext()) {
                auto rpc_closure = brpc::NewCallback(this, &Parser::OnGetSpaceExtent,
                        ctx, rpc_ctx_guard.release());
                control->client()->GetSpaceExtentMap(rpc_ctx, rpc_closure);
            } else {
                control->RefreshPsmInfo(ctx->psm_info);
                ctx->action = Action::kDoRpcQuota;
                ctx->has_quota = false;
                Schedule(ctx TRACE_FILE_LINE_CC, parse_get_delay_us(ctx->retry_times), true);
            }
            return;
        }
    }

    std::unique_ptr<Context> ctx_guard(ctx);
    set_cluster_stat(cluster, stat_psm_req_lat, ctx->stat_timer.u_elapsed());
    ctx->psm_info->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());

    rpc_quota->RemoveSpaceExtentEvent(ctx->space_extent_event,
            [this, not_exists, rpc_ctx](SegmentPtr seg,
                    const event_space_extent_t& fold, pspb::Status* st, const EventClosureArgType& arg){
                if (st) {
                    set_rpc_status(st,
                            not_exists ? pspb::Status::NOT_EXISTS : pspb::Status::SUCCESS,
                            "segment:%s/%u space:%u extent %s",
                            seg->cluster_id().c_str(), seg->segment_id(), fold.space_id,
                            not_exists ? "not exists" : "ok");
                }
                seg->SetSpaceExtent(fold, std::get<ExtentArg>(arg), not_exists, rpc_ctx->response);
                if (not_exists) {
                    Dispatch(seg TRACE_FILE_LINE_CC, 0);
                }
            });
}

void Parser::GetPeer(Context* ctx) {
    define_control_or_return_invalid(ctx);
    ClusterPtr cluster = ctx->cluster;
    RpcQuotaPtr rpc_quota = cluster->rpc_quota();

    if (!ctx->has_quota) {
        LOG(TRACE) << "not quota, wait retry";
        if (!GetQuota(rpc_quota, ctx)) {
            _stat_get_meta_limit_quota_count << 1;
            return;
        }
    }

    SegmentPtr segment = rpc_quota->GetPeerEventFirstSegment(ctx->peer_event);
    if (!segment) {
        _stat_get_meta_fail_count << 1;
        std::unique_ptr<Context> ctx_guard(ctx);
        rpc_quota->RemovePeerEvent(ctx->peer_event,
            [](SegmentPtr seg, gaiadb::common::segment_t /*segment_id*/, pspb::Status* st, const EventClosureArgType&) {
                seg->PutPeerReqLock();
                if (st) {
                    set_rpc_status(st, pspb::Status::INVALID, "segment are invalid");
                }
            });
        return;
    }

    PsmInfoPtr psm_info = segment->GetPsmInfo();
    std::vector<base::EndPoint> nodes;
    if (!psm_info->GetOrRefreshNodes(&nodes)) {
        _stat_get_meta_fail_count << 1;
        control->RefreshPsmInfo(psm_info);
        Schedule(ctx TRACE_FILE_LINE_CC, parse_get_delay_us(ctx->retry_times), true);
        return;
    }

    ctx->psm_info = psm_info;
    auto rpc_ctx = new RpcGetSegmentCtx;
    rpc_ctx->servers = std::move(nodes);
    rpc_ctx->request.set_segment_id(segment->segment_id());
    rpc_ctx->request.set_cluster_id(segment->cluster_id());

    auto rpc_closure = brpc::NewCallback(this, &Parser::OnGetPeer, ctx, rpc_ctx);
    control->client()->ListSegmentReplica(rpc_ctx, rpc_closure);
}

void Parser::OnGetPeer(Context* ctx, RpcGetSegmentCtx* rpc_ctx) {
    ctx->rpc_get_segment_ctx.reset(rpc_ctx);
    ctx->action = Action::kDisposeRpcQuota;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Parser::DisposeGetPeer(Context* ctx) {
    auto rpc_ctx = ctx->rpc_get_segment_ctx.release();
    std::unique_ptr<RpcGetSegmentCtx> rpc_ctx_guard(rpc_ctx);
    define_control_or_return_invalid(ctx);
    ClusterPtr cluster = ctx->cluster;
    RpcQuotaPtr rpc_quota = cluster->rpc_quota();

    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        _stat_get_meta_fail_count << 1;
        set_cluster_stat(cluster, stat_psm_req_err_count, 1);
        if (!not_exists) {
            if (rpc_ctx->RetryNext()) {
                auto rpc_closure = brpc::NewCallback(this, &Parser::OnGetPeer,
                        ctx, rpc_ctx_guard.release());
                control->client()->ListSegmentReplica(rpc_ctx, rpc_closure);
            } else {
                control->RefreshPsmInfo(ctx->psm_info);
                ctx->action = Action::kDoRpcQuota;
                ctx->has_quota = false;
                Schedule(ctx TRACE_FILE_LINE_CC, parse_get_delay_us(ctx->retry_times), true);
            }
            return;
        }
    }

    if (not_exists) {
        LOG(ERROR) << "segment not found on manager,"
            << " cluster:[" << cluster->name()
            << "] id:[" << ctx->peer_event->key()
            << "]";
    }

    std::unique_ptr<Context> ctx_guard(ctx);
    set_cluster_stat(cluster, stat_psm_req_lat, ctx->stat_timer.u_elapsed());
    ctx->psm_info->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());

    rpc_quota->RemovePeerEvent(ctx->peer_event,
            [this, not_exists, rpc_ctx](SegmentPtr seg,
                    gaiadb::common::segment_t segment_id, pspb::Status* st, const EventClosureArgType&){
                if (st) {
                    set_rpc_status(st,
                            not_exists ? pspb::Status::NOT_EXISTS : pspb::Status::SUCCESS,
                            "segment:%s/%u peer:%u %s",
                            seg->cluster_id().c_str(), seg->segment_id(), segment_id,
                            not_exists ? "not exists" : "ok");
                }
                seg->UpdatePeerNodes(segment_id, not_exists, rpc_ctx->response);
            });
}

void Parser::OnGetAllSpaceId(Context* ctx, RpcGetAllSpaceCtx* rpc_ctx) {
    ctx->rpc_get_all_space_id_ctx.reset(rpc_ctx);
    ctx->action = Action::kDisposeGetAllSpaceId;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Parser::DisposeGetAllSpaceId(Context* ctx) {
    auto rpc_ctx = ctx->rpc_get_all_space_id_ctx.release();
    std::unique_ptr<RpcGetAllSpaceCtx> rpc_ctx_guard(rpc_ctx);
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    bool not_exists = false;
    if (!rpc_failed(rpc_ctx, &not_exists)) {
        segment->InitAllSpaceId(rpc_ctx->response);
        LOG(NOTICE) << segment << " init all space ids";
    }
    DoNextLogBlock(ctx);
}

void Parser::ParseLogBlock(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    if (ctx->log_block->event != EventOp::kParseRecord) {
        if (ctx->log_block->event == EventOp::kGetSpaceMeta) {
            const uint32_t space_status = segment->GetSpaceStatus(ctx->log_block->event_space_id);
            if (space_status_is_unknown(space_status)
                || space_status_with_psm(space_status)
                || (space_status_is_deleted(space_status)
                    && space_status_is_deleted(ctx->log_block->space_status))) {
                segment->SetSpaceStatus(ctx->log_block->event_space_id, ctx->log_block->space_status);
            }
            DoNextLogBlock(ctx);
        } else if (ctx->log_block->event == EventOp::kClearSpaceStatus) {
            LOG(TRACE) << segment << " clear useless space status and space encrypt status";
            segment->ClearUseLessSpaceStatus();
            DoNextLogBlock(ctx);
        } else if (ctx->log_block->event == EventOp::kGetAllSapceId) {
            LOG(TRACE) << segment << " get all space ids";
            PsmInfoPtr psm_info = segment->GetPsmInfo();
            std::vector<base::EndPoint> nodes;
            if (!psm_info->GetOrRefreshNodes(&nodes)) {
                LOG(TRACE) << "refresh psm list failed";
                control->RefreshPsmInfo(psm_info);
                Schedule(ctx TRACE_FILE_LINE_CC, parse_get_delay_us(ctx->retry_times), true);
                return;
            }
            RpcGetAllSpaceCtx* rpc_ctx = new RpcGetAllSpaceCtx;
            rpc_ctx->servers = std::move(nodes);
            auto closure = brpc::NewCallback(this, &Parser::OnGetAllSpaceId, ctx, rpc_ctx);
            control->client()->GetAllSpace(rpc_ctx, closure);
        } else {
            PSVR_ASSERT(false);
        }
        return;
    }

    ctx->stat_timer.reset();
    ADD_TRACE_TP(ctx->log_block->tp, "pre_parse");
    bool ret = segment->ParseLogBlockToLogRecords(ctx->log_id, ctx->log_block);
    if (!ret) {
        PSVR_LOG_CTX(ERROR, ctx) << segment << " fail to parse log block";
        _stat_parse_error_count << 1;
        Schedule(ctx TRACE_FILE_LINE_CC, parse_get_delay_us(ctx->retry_times), true);
        return;
    }

    if (!ctx->log_block->is_parsed) {
        PSVR_LOG_CTX(ERROR, ctx) << segment << " parse ok but lb status invalid,"
            << " status:[" << ctx->log_block->is_parsed
            << "]";
        Schedule(ctx TRACE_FILE_LINE_CC, parse_get_delay_us(ctx->retry_times), true);
        return;
    }

    if (ctx->log_block->data_length()) {
        _stat_parse_log_block_lat << ctx->stat_timer.u_elapsed();
        _stat_parse_log_block_include_record_size << ctx->log_block->records_count;
    } else {
        _stat_parse_empty_qps << 1;
    }
    _stat_parse_log_block_size << ctx->log_block->data_length();

    ADD_TRACE_TP(ctx->log_block->tp, "done");
    control->gc()->Dispatch(segment TRACE_FILE_LINE_CC, ctx->log_block->end_lsn);
    DoNextLogBlock(ctx);
}

}
/* vim: set expandtab ts=4 sw=4 sts=4 tw=140: */
