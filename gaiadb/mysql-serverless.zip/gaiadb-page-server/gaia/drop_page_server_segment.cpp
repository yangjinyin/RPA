/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/drop_page_server_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/drop_page_server_segment.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int DropPageServerSegment::Run() {
    if (_cluster_addr.empty() && (_address.empty() || _port < 1)) {
        print_error("miss --address or --port");
        return 1;
    }

    if (_cluster_id.empty()) {
        print_error("miss --cluster-id or -c");
        return 1;
    }

    if (_segment_id.has_val && _segment_id.val < 1) {
        print_error("fail, error --segment-id or -s");
        return 1;
    }

    std::vector<base::EndPoint> nodes;
    if (_cluster_addr.empty()) {
        base::EndPoint node;
        int ret = base::str2endpoint(_address.c_str(), _port, &node);
        if (ret != 0) {
            print_error("--address and --port convert to endpoint error");
            return 1;
        }
        nodes.push_back(node);
    } else {
        PsmInfo psm_info(_cluster_addr, _both);
        if (!psm_info.GetOrRefreshNodes(&nodes)) {
            print_error("--cluster-addr parse failed, cant get server list from it");
            return 1;
        }

        _timeout_ms = std::max(_timeout_ms, 30000);
    }

    if (!_force) {
        bool cf_ret = _segment_id.has_val ? execute_confirm("Drop this segment:[cluster=%s, id=%u]?", _cluster_id.c_str(), _segment_id.val)
            : execute_confirm("Drop this cluster all segments:[cluster=%s]?", _cluster_id.c_str());
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    pspb::BatchDropSegmentResponse batch_rsp;
    for (auto& node : nodes) {
        RpcStatus status;
        pspb::DropSegmentRequest request;
        pspb::DropSegmentResponse response;

        request.set_log_id(_log_id);
        request.set_cluster_id(_cluster_id);
        if (_segment_id.has_val) {
            request.set_segment_id(_segment_id.val);
        }

        _client.Call(_log_id++, node, &pspb::ManagerService_Stub::DropSegment, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }

        auto rsp = batch_rsp.add_server_status();
        rsp->set_addr(gaiadb::common::endpoint2str(node));
        rsp->mutable_status()->CopyFrom(response);
    }

    if (nodes.size() == 1) {
        return Output(batch_rsp.server_status(0).status());
    }

    return Output(batch_rsp);
}

int DropPageServerSegment::Format(const pspb::DropSegmentResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.has_drop_count()) {
        Table table(_raw_with_table, 2);
        table.AddRowsValue({"drop_count:", rsp.drop_count()});
        table.Display();
    }
    return 0;
}

int DropPageServerSegment::Format(const pspb::BatchDropSegmentResponse& rsp) {
    Table __table(_raw_with_table, 2);
    __table.AddRowsValue({"log_id:", _log_id});
    __table.Display();

    for (int32_t j = 0; j < rsp.server_status_size(); ++j) {
        const auto& server_status = rsp.server_status(j);
        const auto& rsp2 = server_status.status();

        Table table(_raw_with_table, 0);
        if (rsp2.status().code() != pspb::Status_ReturnCode_SUCCESS) {
            table.AddRowsWithName({"no", "node", ""});
            table.AddRowsValue({
                        j + 1, server_status.addr(),
                        RowStr(pspb::Status_ReturnCode_Name(rsp2.status().code()), rsp2.status().msg())
                    });
        } else {
            table.AddRowsWithName({"no", "node", "drop_count"});
            table.AddRowsValue({j + 1, server_status.addr(), rsp2.drop_count()});
        }
        table.Display();
    }
    return 0;
}

}
}
