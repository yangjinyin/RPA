/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_statistic.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/get_statistic.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int GetStatistic::Run() {
    RpcStatus status;
    gaiapb::EmptyMessage request;
    gaiapb::GetStatisticResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_statistic, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " get statistic failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("get failed, all nodes failed");
    return Output(response);
}

int GetStatistic::Format(const gaiapb::GetStatisticResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"free_extent_num:", rsp.free_extent_num()});
    table.AddRowsValue({"total_extent_num:", rsp.total_extent_num()});
    char buf[32];
    snprintf(buf, sizeof(buf), "%.2f%%",
            rsp.total_extent_num() ? (100.0 * (rsp.total_extent_num() - rsp.free_extent_num()) / rsp.total_extent_num()) : 100);
    table.AddRowsValue({"usage_rate:", buf});
    table.Display();
    return 0;
}

}
}
