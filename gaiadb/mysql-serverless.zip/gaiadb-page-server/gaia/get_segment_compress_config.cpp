/***************************************************************************
 * Copyright (c) Baidu.com, Inc. All Rights Reserved
 **************************************************************************/
/**
 * @file gaia/get_segment_compress_config.cpp
 * @author yukeyong@baidu.com
 * @brief
 */

#include "gaia/get_segment_compress_config.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int GetSegmentCompressConfig::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    gaiapb::GetSegmentCompressConfigRequest request;
    gaiapb::GetSegmentCompressConfigResponse response;

    request.set_log_id(_log_id);

    for (auto& node : nodes) {
        _client.Call(
                _log_id,
                node,
                &gaiapb::QueryService_Stub::get_segment_compress_config,
                &request,
                &response,
                nullptr,
                &status,
                _timeout_ms);
        if (status.IsOk() && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " get segment compress config failed, " << status << " "
                         << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("get failed, all nodes failed");
    return Output(response);
}

int GetSegmentCompressConfig::Format(const gaiapb::GetSegmentCompressConfigResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"enable:", rsp.compress_cfg().enable()});
    table.AddRowsValue({"type:", rsp.compress_cfg().type()});
    table.AddRowsValue({"level:", rsp.compress_cfg().level()});
    table.Display();
    return 0;
}

}  // namespace gaia
}  // namespace psvr
