/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/segment_append.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <cstdlib>
#include <memory>

#include "psvr/segment.h"
#include "psvr/control.h"
#include "psvr/utils.h"
#include "psvr/record_op.h"
#include "psvr/page_op.h"
#include "psvr/append_redo_apply.h"
#include "psvr/redo_record.h"

namespace psvr {

#define set_statistic(name, val)       \
    if (_statistic) {                  \
        (_statistic->name) << (val);   \
    }

void Segment::UpdateAppendSize() {
    uint64_t append_size = 0;
    _append_db_engine->GetSize(&append_size);
    _append_db_size.store(append_size, std::memory_order_relaxed);

    // Recovery owns the frozen flag. This snapshot is intentionally passed
    // into the engine; DeleteObsoleteFiles also checks its recovery state
    // under _random_access_shared_mutex before removing blocks.
    const bool cleanup_frozen =
        _recovery_info.append_file_cleanup_frozen.load(std::memory_order_relaxed);
    db::Status st = _append_db_engine->DeleteObsoleteFiles(
        _seg_lowest_gc_lsn(), cleanup_frozen);
    if (!st.IsOk()) {
        LOG_EVERY_SECOND(WARNING) << this << " delete append db obsolete files failed," << st;
    }
}

uint64_t Segment::GetAppendUnGcSize() {
    return _append_un_gc_size.load(std::memory_order_relaxed);
}

bool Segment::AppendRecoverFetchFinish() {
    return _fetch_lsn() >= _start_lsn;
}

bool Segment::AppendRecoverParseFinish() {
    return _parse_lsn() >= _start_lsn;
}

bool Segment::AppendRecoverGcFinish() {
    // N.B.the gc_lsn needs to exceed the start_lsn to prevent the gc thread from prematurely
    // cleaning up the appenddb while the fetch thread still needs to read from it once more when
    // FLAGS_psvr_enable_append_file is changed from true to false
    return _gc_lsn() > _start_lsn;
}

db::Status Segment::AppendLog(LogBlockPtr log_block) {
    Timer timer(base::Timer::STARTED);
    std::vector<db::LogHeader> headers;
    std::vector<base::Slice> keys;
    std::vector<base::Slice> values;

    size_t n = 0;
    auto head = log_block;
    while (head) {
        db::LogHeader header;
        header.magic = db::kLogHeaderMagic;
        header.proto_version = db::kLogHeaderVserion;
        header.start_lsn = head->start_lsn;
        header.end_lsn = head->end_lsn;
        header.buf_crc = head->buf_crc;
        header.records_count = head->records_count;
        header.fetch_from_ip = base::ip2int(head->fetch_from.ip);
        header.fetch_from_port = head->fetch_from.port;

        auto& offset_cache = head->fold_space_page_offset_cache;
        header.fold_size = offset_cache.size();

        base::Slice key(static_cast<const char*>(offset_cache.buf()), offset_cache.buf_size());
        base::Slice value(reinterpret_cast<const char*>(head->buf), head->buf_size);

        header.key_crc = db::get_crc(reinterpret_cast<const void*>(key.data()), key.size());
        header.key_size = key.size();
        header.value_size = value.size();

        if (head->valid_records_count > 0) {
            PSVR_ASSERT(header.fold_size > 0);
        }

        db::make_checksum(&header, db::kLogHeaderSize);

        headers.emplace_back(header);
        keys.emplace_back(key);
        values.emplace_back(value);

        head = head->next;
        ++n;
    }

    std::vector<uint64_t> fnos(n);
    std::vector<uint64_t> offs(n);

    db::Status st = _append_db_engine->BatchAppend(headers, keys, values, &fnos, &offs);
    if (!st.IsOk()) {
        return st;
    }

    size_t idx = 0;
    head = log_block;
    while (head) {
        LOG(TRACE) << "append logblock to file ok,"
            << " fno:[" << fnos[idx]
            << "] off:[" << offs[idx]
            << "] key_size:[" << keys[idx].size()
            << "] value_size:[" << values[idx].size()
            << "] log_block:[" << head
            << "]";

        head->append_info.fno = fnos[idx];
        head->append_info.off = offs[idx] + db::kLogHeaderSize;
        head->append_info.size = headers[idx].key_size;
        head->append_info.fold_size = headers[idx].fold_size;

        if (FLAGS_psvr_append_disable_cache_key) {
            auto& offset_cache = head->fold_space_page_offset_cache;
            offset_cache.Free();
        }

        set_statistic(stat_gc_logblock_lat, head->latency_us());
        head = head->next;
        ++idx;
    }

    set_statistic(stat_gc_logblock_real_lat, timer.u_elapsed());

    return st;
}

gaia_apply::lsn_t Segment::GetAppendDBCheckPointLsn() const {
    return _append_db_engine->GetCheckPointLsn();
}

db::Status Segment::UpdateAppendDBCheckPoint(gaia_apply::lsn_t lsn, bool is_dblwr_dump) {
    db::Status st;
    if (!FLAGS_psvr_enable_append_file) {
        if (AppendRecoverGcFinish()) {
            // clear append db
            return ClearAppendDB();
        }
    }
    if (FLAGS_psvr_enable_append_file && FLAGS_psvr_dblwr_max_page_num > 0 && !is_dblwr_dump) {
        // dblwr push append checkpoint lsn
        return _dblwr->WriteCkpLsn(lsn);
    }
    const bool cleanup_frozen =
        _recovery_info.append_file_cleanup_frozen.load(std::memory_order_relaxed);
    return _append_db_engine->SetCheckPointLsn(
        lsn, _seg_lowest_gc_lsn(), cleanup_frozen);
}

db::Status Segment::ClearAppendDB() {
    return _append_db_engine->Clear();
}

db::Status Segment::GetLogBlockOffCache(LogBlockPtr log_block) {
    db::Status st;

    base::Slice data;
    const AppendInfo& append_info = log_block->append_info;
    auto& offset_cache = log_block->fold_space_page_offset_cache;
    offset_cache.Init(append_info.fold_size, append_info.buf);
    if (append_info.buf) {
        PSVR_ASSERT(offset_cache.is_init());
        return st;
    }

    st = _append_db_engine->Read(append_info.fno, append_info.off,
            &data, offset_cache.data(), append_info.size);
    if (!st.IsOk()) {
        return st;
    }

    if (!offset_cache.Decode(data.data(), data.size(), append_info.fold_size)) {
        st.Reset(db::Code::kCorrupted, "mismatch fold cahce, lsn range:%lu-%lu",
                log_block->start_lsn, log_block->end_lsn);
        return st;
    }

    if (st.IsOk()) {
        std::atomic_thread_fence(std::memory_order_acquire);
        offset_cache.set_init();
    }

    return st;
}

static db::Status RemovePrefixRec(gaia_apply::byte* start_ptr, gaia_apply::byte* end_ptr,
        gaia_apply::lsn_t fetch_lsn, base::Slice* value, db::LogHeader* log_header) {
    db::Status st;
    gaia_apply::lsn_t rec_end_lsn;
    alignas(LogRecord) unsigned char record_storage[sizeof(LogRecord)];

    if (!start_ptr || !end_ptr || start_ptr > end_ptr
            || static_cast<size_t>(end_ptr - start_ptr) < sizeof(uint64_t)) {
        st.Reset(db::Code::kCorrupted,
                "redo rec header is incomplete, start_lsn:%lu, range:%lu-%lu",
                fetch_lsn, log_header->start_lsn, log_header->end_lsn);
        return st;
    }
    rec_end_lsn = get_record_end_lsn(start_ptr);
    if (fetch_lsn < rec_end_lsn) {
        return st;
    }
    /* Parse rec from ptr */
    while (static_cast<size_t>(end_ptr - start_ptr) >= sizeof(uint64_t)) {
        /* data:    | 8bytes(end_lsn) | redo | 8bytes | redo | ... |
         * end_lsn is the end of the redo record*/
        rec_end_lsn = get_record_end_lsn(start_ptr);
        if (rec_end_lsn > fetch_lsn) {
            break;
        }

        LogRecord* record = nullptr;
        gaia_apply::ulint record_len = 0;
        st = parse_append_redo_record(
                start_ptr + 8,
                end_ptr,
                rec_end_lsn,
                record_storage,
                &record,
                &record_len);
        if (!st.IsOk()) {
            if (st.IsMissData()) {
                st.Reset(db::Code::kCorrupted,
                        "redo rec is incomplete, start_lsn:%lu, range:%lu-%lu",
                        fetch_lsn, log_header->start_lsn, log_header->end_lsn);
            }
            return st;
        }

        const auto remove_size = sizeof(uint64_t) + record_len;
        if (value->size() < remove_size) {
            record->~LogRecord();
            st.Reset(db::Code::kCorrupted,
                    "redo rec size exceeds value, start_lsn:%lu, range:%lu-%lu",
                    fetch_lsn, log_header->start_lsn, log_header->end_lsn);
            return st;
        }

        start_ptr += remove_size;
        value->remove_prefix(remove_size);

        --log_header->records_count;
        record->~LogRecord();
    }

    log_header->buf_crc = db::get_crc(reinterpret_cast<const void*>(value->data()), value->size());
    return st;
}

db::Status Segment::FetchRedoLog(gaia_apply::lsn_t fetch_lsn,
        base::Slice* key, base::Slice* value, char** buf,
        uint32_t* key_crc, uint32_t* value_crc, uint32_t* records_count, uint32_t* fold_size,
        gaia_apply::lsn_t *next_seek_lsn,
        uint64_t& block_no, uint64_t& block_offset,
        AppendReadBuf* read_buf) {

    db::Status st;
    db::LogHeader log_header;
    st = _append_db_engine->FetchRedoLog(fetch_lsn, &log_header, key, value, buf,
            block_no, block_offset, read_buf);
    std::unique_ptr<char, decltype(&std::free)> buf_guard(*buf, &std::free);
    if (!st.IsOk()) {
        // FetchRedoLog transfers buffer ownership on every return path.
        *buf = nullptr;
        return st;
    }

    do {
        st = validate_append_redo_block(log_header, *key, *value);
        if (!st.IsOk()) {
            break;
        }

        if (value->size()) {
            gaia_apply::byte* start_ptr =
                reinterpret_cast<gaia_apply::byte*>(
                        *buf + log_header.key_size);
            st = RemovePrefixRec(start_ptr, start_ptr + value->size(),
                    fetch_lsn, value, &log_header);
            if (!st.IsOk()) {
                break;
            }
        } else {
            PSVR_ASSERT_U(log_header.records_count == 0);
        }

        *key_crc = log_header.key_crc;
        *value_crc = log_header.buf_crc;
        *records_count = log_header.records_count;
        *fold_size = log_header.fold_size;
        *next_seek_lsn = log_header.end_lsn;
    } while (false);

    if (st.IsOk()) {
        buf_guard.release();
    } else {
        *buf = nullptr;
    }
    return st;
}

db::Status Segment::AppendRecover(gaia_apply::lsn_t start_lsn,
        db::LogHeader* log_header, AppendInfo* append_info,
        base::Slice* offset_cache, base::Slice* redo, char** log_buf) {
    db::Status st;

    char* buf = nullptr;
    do {
        base::Slice key;
        base::Slice value;
        uint64_t fno = 0;
        uint64_t off = 0;
        st = _append_db_engine->RecoverLog(log_header, &key, &value, &buf, &fno, &off);
        if (!st.IsOk()) {
            break;
        }

        if (log_header->start_lsn > start_lsn
                || log_header->end_lsn < start_lsn) {
            st.Reset(db::Code::kMissData, "log lsn is error, start_lsn:%lu, range:%lu-%lu, fno:%lu,%lu",
                    start_lsn, log_header->start_lsn, log_header->end_lsn, fno, off);
            break;
        }

        st = validate_append_redo_block(*log_header, key, value);
        if (!st.IsOk()) {
            break;
        }

        append_info->fno = fno;
        append_info->off = off + db::kLogHeaderSize;
        append_info->size = log_header->key_size;
        append_info->fold_size = log_header->fold_size;

        *offset_cache = key;
        *redo = value;
        *log_buf = buf;
        buf = nullptr;

    } while (false);

    if (buf) {
        std::free(buf);
    }

    return st;
}

db::Status Segment::AppendPreRecoverNextLog() {
    uint64_t next_lsn = 0;
    auto st = _append_db_engine->PreRecoverNextLog(&next_lsn);
    if (st.IsOk()) {
        if (fetch_lsn() != next_lsn) {
            st.Reset(db::Code::kCorrupted, "next log data mismatch, fetch_lsn:%lu, next_lsn:%lu",
                    fetch_lsn(), next_lsn);
        }
    }
    if (!st.IsOk()) {
        LOG(ERROR) << this << " prepare recover next log failed," << st;
    }
    return st;
}

db::Status Segment::FinishAppendRecover() {
    return _append_db_engine->RecoverFinish();
}

db::Status Segment::ApplyAppendRedoToPageNoLock(int64_t log_id,
        uint64_t physical_offset,
        gaia_apply::lsn_t start_lsn,
        gaia_apply::lsn_t apply_end_lsn,
        BufBlockPtr buf_block,
        AppendReadBuf* read_buf) {
    db::Status st;
    if (start_lsn >= apply_end_lsn) {
        return st;
    }

    if (!FLAGS_psvr_enable_append_file) {
        st.Reset(db::Code::kInvalid, "append file is disabled");
        return st;
    }

    const auto checkpoint_lsn = GetAppendDBCheckPointLsn();
    if (checkpoint_lsn > start_lsn) {
        st.Reset(db::Code::kMissData,
                "append redo start lsn is older than checkpoint, "
                "checkpoint_lsn:%lu start_lsn:%lu",
                checkpoint_lsn, start_lsn);
        return st;
    }

    AppendLogRecordIterator iter(_append_db_engine, log_id, physical_offset,
            start_lsn, apply_end_lsn, read_buf);
    st = iter.Init();
    if (!st.IsOk()) {
        return st;
    }

    uint32_t apply_size = 0;
    st = ApplyPageLogRecordsNoLock(log_id, physical_offset, apply_end_lsn,
            buf_block, iter, &apply_size);
    if (!st.IsOk()) {
        return st;
    }

    return iter.Status();
}

}
