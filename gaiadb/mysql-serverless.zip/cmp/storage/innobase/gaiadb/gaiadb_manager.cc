/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/gaiadb_manager.cc
 The general function for gaiadb manager

 Created 11/9/2022 Hongyu Qiao
 *******************************************************/
#include <gaiadb/psm_client/client.h>
#include <gaiadb/psm_client/client_inl.h>
#include <base/logging.h>
#include <gaiadb/proto/manager/common.pb.h>
#include "gaiadb.h"
#include "gaiadb_manager.h"

#define PSM_REQUEST_INTERVAL 1000 //1s

/** Create undo truncate log file to psm
@param[in]      log_file_name       undo truncate log file name
@return DB_SUCCESS if all OK */
dberr_t gaiadb_create_undo_truncate_log_file(const char *log_file_name) {
  ut_a(log_file_name != nullptr);
  int ret = 0;
  do {
    ret = psmcli->create_undo_truncate_log_file(log_file_name);
    std::this_thread::sleep_for(srv_delay_send_request);
    LOG_IF_EVERY_N(ERROR, ret == gaiadb::GIE_FAIL, 100)
        << "Manager: create undo truncate log failed : " << log_file_name;
  } while(ret == gaiadb::GIE_FAIL);

  if (ret != gaiadb::GIE_OK) {
    LOG(ERROR) << "Manager: create undo truncate log failed : " << log_file_name;
    return (DB_ERROR);
  }
  LOG(TRACE) << "Manager: create undo truncate log success : " << log_file_name;
  return (DB_SUCCESS);
}

/** Delete undo truncate log file from psm
@param[in]      log_file_name       undo truncate log file name
@return DB_SUCCESS if all OK */
dberr_t gaiadb_delete_undo_truncate_log_file(const char *log_file_name) {
  ut_a(log_file_name != nullptr);
  int ret = 0;
  do {
    ret = psmcli->delete_undo_truncate_log_file(log_file_name);
    std::this_thread::sleep_for(srv_delay_send_request);
    LOG_IF_EVERY_N(ERROR, ret == gaiadb::GIE_FAIL, 100)
        << "Manager: delete undo truncate log failed : " << log_file_name;
  } while(ret == gaiadb::GIE_FAIL);

  if (ret != gaiadb::GIE_OK) {
    LOG(TRACE) << "Manager: undo truncate log: " << log_file_name << " not exists.";
  }
  LOG(TRACE) << "Manager: delete undo truncate log success : " << log_file_name;
  return (DB_SUCCESS);
}

/** check undo truncate log file in psm
@param[in]      log_file_name       undo truncate log file name
@return DB_SUCCESS if all OK */
bool gaiadb_undo_truncate_log_file_exist(const char *log_file_name) {
  ut_a(log_file_name != nullptr);
  int ret = 0;
  do {
    ret = psmcli->undo_truncate_log_exist(log_file_name);
    std::this_thread::sleep_for(srv_delay_send_request);
    LOG_IF_EVERY_N(ERROR, ret == gaiadb::GIE_FAIL, 100)
        << "Manager: check undo truncate log failed : " << log_file_name;
  } while(ret == gaiadb::GIE_FAIL);

  if (ret == gaiadb::GIE_NOT_EXIST) {
    LOG(TRACE) << "Manager: undo truncate log not exist : " << log_file_name;
    return (false);
  }
  LOG(TRACE) << "Manager: undo truncate log exist : " << log_file_name;
  return (true);
}

/** get lowest trx_id from psm
@return lowest trx_id */
trx_id_t get_lowest_trx_id() {
    trx_id_t min_secondary_trx_id = 0;
    trx_id_t standby_cluster_lowest_trx_id = 0;
    int32_t ret = 0;
    while (true) {
      ret = psmcli->get_lowest_trx_id(&min_secondary_trx_id,
          &standby_cluster_lowest_trx_id);
      if (ret == gaiadb::GIE_OK) {
        break;
      }
      LOG(ERROR) << "get lowest_trx_id failed " << ret;
      std::this_thread::sleep_for(srv_delay_send_request);
    }
    if (standby_cluster_lowest_trx_id > 0
        && standby_cluster_lowest_trx_id < min_secondary_trx_id) {
      min_secondary_trx_id = standby_cluster_lowest_trx_id;
    }

    return min_secondary_trx_id;
 }

/** get lowest lsn from psm
@return true if success */
bool gaiadb_get_lowest_lsn(uint64_t &lowest_lsn) {
    uint64_t cs_lowest_lsn = 0;
    int32_t ret =
        psmcli->get_lowest_lsn(&lowest_lsn, nullptr, nullptr, &cs_lowest_lsn);
    if (ret != gaiadb::GIE_OK) {
      LOG(ERROR) << "get_lowest_lsn failed" << ret;
      return false;
    } else {
      lowest_lsn =
          cs_lowest_lsn != 0 ? std::min(lowest_lsn, cs_lowest_lsn) : lowest_lsn;
      return true;
    }
}

void gaiadb_wait_lowest_lsn(uint64_t expect_lsn) {
  uint64_t current_lowest_lsn = 0;
  LOG(TRACE) << "start wait lowest lsn expect: " << expect_lsn;
  do {
    if (!gaiadb_get_lowest_lsn(current_lowest_lsn)) {
      std::this_thread::sleep_for(srv_delay_send_request);
      continue;
    }
  } while (current_lowest_lsn < expect_lsn);
  LOG(TRACE) << "finish wait lowest lsn expect: " << expect_lsn
             << " current: " << current_lowest_lsn;
}


/** delete space from psm
@return true if success */
bool gaiadb_delete_space(uint32_t space_id) {
  while (true) {
    auto ret = psmcli->delete_space(space_id);
    if (ret == gaiadb::GIE_OK ||
      ret == gaiadb::GIE_SPACE_NOT_EXIST) {
      break;
    }
    LOG(ERROR) << "psm delete space failed for space id:" << space_id
               << ", return code:" << ret;
    std::this_thread::sleep_for(srv_delay_send_request);
  }
  return true;
}

/** get all space ids from psm*/
bool gaiadb_get_all_space_ids(std::vector<uint32_t>& ids) {
  int32_t ret = psmcli->get_all_space_ids(ids);
  if (ret != gaiadb::GIE_OK) {
    LOG(ERROR) << "get_all_space_ids failed" << ret;
    return false;
  } else {
    return true;
  }
}

/** get tde space ids from psm*/
bool gaiadb_get_tde_space_ids(std::vector<uint32_t>& ids) {
  int32_t ret = psmcli->get_tde_space_ids(ids);
  if (ret != gaiadb::GIE_OK) {
    LOG(ERROR) << "get_tde_space_ids failed" << ret;
    return false;
  } else {
    return true;
  }
}
