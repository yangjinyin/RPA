/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/dbengine.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <filesystem>
#include <psvr/common.h>
#include <gaiadb/utils/crc32.h>
#include <gaiadb/utils/rw_lock.h>
#include "psvr/buf.h"
#include "psvr/file_utils.h"
#include "psvr/status.h"

namespace psvr {

class DBEngine;
using DBEnginePtr = std::shared_ptr<DBEngine>;

namespace db {

void check_punch_hole_feature(const std::string& file_name, bool* enable);

class PageLock;
using PageLockPtr = std::shared_ptr<PageLock>;

class PageLock {
public:
    PageLock(uint64_t page_no, uint64_t page_size)
        : _page_no(page_no), _page_size(page_size) {}
    FUNC_MOCK ~PageLock() {}

    uint64_t page_no() const { return _page_no; }
    uint64_t page_size() const { return _page_size; }
    uint64_t offset() const { return _page_no * _page_size; }

    rwlock_t& mutex() { return _mutex; }
    void lock() { return _mutex.lock(); }
    bool try_lock() { return _mutex.try_lock(); }
    void unlock() { return _mutex.unlock(); }
    void lock_shared() { return _mutex.lock_shared(); }
    bool try_lock_shared() { return _mutex.try_lock_shared(); }
    void unlock_shared() { return _mutex.unlock_shared(); }

private:
    void Reset(uint64_t page_no, uint64_t page_size) {
        _page_no = page_no;
        _page_size = page_size;
    }
private:
    uint64_t _page_no;
    uint64_t _page_size;
    rwlock_t _mutex;
};

template<typename GuardType> class PageLockGuard {
public:
    PageLockGuard(PageLockPtr page_lock)
        : _guard(page_lock->mutex()) {}
    PageLockGuard(PageLockPtr page_lock, std::defer_lock_t type)
        : _guard(page_lock->mutex(), type) {}
    PageLockGuard(PageLockPtr page_lock, std::try_to_lock_t type)
        : _guard(page_lock->mutex(), type) {}
    PageLockGuard(PageLockPtr page_lock, std::adopt_lock_t type)
        : _guard(page_lock->mutex(), type) {}
    FUNC_MOCK ~PageLockGuard() {}

    rwlock_t* release() { return _guard.release(); }
    operator bool() const { return static_cast<bool>(_guard); }

private:
    GuardType _guard;
};

using PageSharedLock = PageLockGuard<std::shared_lock<rwlock_t>>;
using PageUniqueLock = PageLockGuard<std::unique_lock<rwlock_t>>;

using PageLockManager = ResManager<uint64_t, PageLock>;

enum class EngineType {
    kUnknown = 0,
    kFile,
};

struct OpenOptions {
    int64_t log_id {0};
// file
struct FileEngine {
    std::string name {};
    uint64_t size {0};
    bool create_ckp {false};
    std::string ckp_name {};
    uint64_t ckp_size {0};
    gaia_apply::ulint block_size {0};
    uint64_t max_size {0};
    bool enable_punch_hole {false};
};

    EngineType engine_type {EngineType::kUnknown};
    uint64_t page_size {0};
    bool create_if_missing {false};

    FileEngine file {};
};

struct ReadOptions {
    int64_t log_id {0};
    bool read_raw {false};
};

struct ReadOutputs {
    bool first_is_compressed {false};
    size_t real_write_size {0};
};

struct WriteOptions {
    int64_t log_id {0};
    bool alloc_extent_size {false};
    bool enable_compress {false};
    int32_t compress_type {0};
    int32_t compress_level {0};
    gaia_apply::space_id_t logical_space_id {0};
    gaia_apply::page_no_t logical_page_no {0};
};

struct WriteOutputs {
    size_t real_write_size {0};
};

struct TrimOptions {
    int64_t log_id {0};
    gaia_apply::space_id_t logical_space_id {0};
    gaia_apply::page_no_t logical_page_no {0};
    bool write_zero_if_disable {true};
};

struct DBEngineStatistic {
    // statistic
    bvar::IntRecorder stat_avg_write_size;
    bvar::IntRecorder stat_avg_write_real_size;
    bvar::PassiveStatus<bvar::Vector<uint64_t, 2>> stat_db_compress_size;
    StatLatency stat_db_read_lat;
    StatLatency stat_db_write_lat;
    StatLatency stat_page_compress_lat;
    StatCount stat_page_compress_fail_count;
    StatLatency stat_page_decompress_lat;
    StatBw stat_db_read_bw;
    StatBw stat_db_write_bw;
    StatCount stat_db_read_io_err_count;
    StatCount stat_db_write_io_err_count;

    DBEngineStatistic();
    FUNC_MOCK ~DBEngineStatistic() {}
};

} // end of ns db

class DBEngine : public RefCount {
public:
    DBEngine();
    virtual ~DBEngine();

    FUNC_MOCK db::Status Open(const db::OpenOptions& options);
    db::Status Close();

    uint64_t page_size() const { return _page_size; }
    gaia_apply::ulint file_block_size() const { return _file_block_size; }

    FUNC_MOCK int64_t GetSize(bool physical);

    FUNC_MOCK db::Status Read(const db::ReadOptions& options,
            uint64_t offset, uint64_t size, void* buf, db::ReadOutputs* outputs = nullptr);
    FUNC_MOCK db::Status Write(const db::WriteOptions& options,
            uint64_t offset, uint64_t size, void* buf, db::WriteOutputs* outputs = nullptr);
    FUNC_MOCK db::Status Trim(const db::TrimOptions& options, uint64_t offset, uint64_t size);
    FUNC_MOCK db::Status Sync(bool data = true);

    db::PageLockPtr GetPageLock(uint64_t physical_page_no);

private:
    db::Status OpenFile(const db::OpenOptions& options);
    int64_t GetFileSize(bool physical);
    db::Status ReadFile(const db::ReadOptions& options,
            uint64_t offset, uint64_t size, void* buf, db::ReadOutputs* outputs);
    db::Status WriteFile(const db::WriteOptions& options,
            uint64_t offset, uint64_t size, void* buf, db::WriteOutputs* outputs);
    db::Status TrimFile(const db::TrimOptions& options, uint64_t offset, uint64_t size);
    db::Status SyncFile(bool data);

private:
    db::EngineType _engine_type;
    uint64_t _page_size;
    // system file engine
    int _fd;
    std::string _file_name;
    uint64_t _file_open_size;
    uint64_t _file_max_size;
    std::string _ckp_file_name;
    gaia_apply::ulint _file_block_size;
    rwlock_t _shared_mutex;
    //
    char pad0 BAIDU_CACHELINE_ALIGNMENT;
    std::vector<std::shared_ptr<db::PageLockManager>> _page_lock_manager;
    char pad1 BAIDU_CACHELINE_ALIGNMENT;
};

}
