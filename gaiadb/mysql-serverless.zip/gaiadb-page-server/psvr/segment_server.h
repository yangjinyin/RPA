/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/segment_server.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/signal.h"
#include "psvr/common.h"
#include "psvr/client.h"
#include "psvr/control.h"

namespace psvr {

class OneSegment;
using OneSegmentPtr = std::shared_ptr<OneSegment>;
class MultiSegment;
using MultiSegmentPtr = std::shared_ptr<MultiSegment>;

bool init_logger();

class MultiSegment : public SignalStop, std::enable_shared_from_this<MultiSegment> {
public:
    MultiSegment();
    virtual ~MultiSegment();

    bool Start();
    virtual void Stop() override;

private:
    volatile bool _stopped;
    ClientPtr _client;
    ControlPtr _control;
};

// PageServer control center
class OneSegment : public SignalStop, std::enable_shared_from_this<OneSegment> {
public:
    OneSegment();
    virtual ~OneSegment();

    bool Start();
    virtual void Stop() override;

private:
    volatile bool _stopped;
    ClientPtr _client;
    ControlPtr _control;
};

}
