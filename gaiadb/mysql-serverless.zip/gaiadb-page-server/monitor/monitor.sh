#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PID_FILE="$ROOT_DIR/monitor.pid"
LOG_FILE="$ROOT_DIR/monitor.log"
PORT="${PORT:-8100}"
NODE_BIN="${NODE_BIN:-node}"

get_local_ip() {
  hostname -I 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -n 1 || true
}

service_url() {
  local ip
  ip="$(get_local_ip)"
  if [[ -z "$ip" ]]; then
    ip="127.0.0.1"
  fi
  echo "http://$ip:$PORT"
}

is_running() {
  [[ -f "$PID_FILE" ]] || return 1
  local pid
  pid="$(cat "$PID_FILE")"
  [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null
}

start() {
  if is_running; then
    echo "服务已在运行: PID $(cat "$PID_FILE"), $(service_url)"
    return 0
  fi

  if [[ -f "$PID_FILE" ]]; then
    rm -f "$PID_FILE"
  fi

  cd "$ROOT_DIR"
  PORT="$PORT" nohup "$NODE_BIN" server.js >>"$LOG_FILE" 2>&1 &
  echo $! >"$PID_FILE"
  sleep 1

  if is_running; then
    echo "服务启动成功: PID $(cat "$PID_FILE"), $(service_url)"
    echo "日志文件: $LOG_FILE"
  else
    echo "服务启动失败，请查看日志: $LOG_FILE" >&2
    rm -f "$PID_FILE"
    return 1
  fi
}

stop() {
  if ! is_running; then
    echo "服务未运行"
    rm -f "$PID_FILE"
    return 0
  fi

  local pid
  pid="$(cat "$PID_FILE")"
  kill "$pid"

  for _ in {1..10}; do
    if ! kill -0 "$pid" 2>/dev/null; then
      rm -f "$PID_FILE"
      echo "服务已停止"
      return 0
    fi
    sleep 1
  done

  kill -9 "$pid" 2>/dev/null || true
  rm -f "$PID_FILE"
  echo "服务已强制停止"
}

status() {
  if is_running; then
    echo "服务运行中: PID $(cat "$PID_FILE"), $(service_url)"
  else
    echo "服务未运行"
    return 1
  fi
}

restart() {
  stop
  start
}

logs() {
  if [[ -f "$LOG_FILE" ]]; then
    tail -n 80 "$LOG_FILE"
  else
    echo "暂无日志文件: $LOG_FILE"
  fi
}

case "${1:-}" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart)
    restart
    ;;
  status)
    status
    ;;
  logs)
    logs
    ;;
  *)
    echo "用法: $0 {start|stop|restart|status|logs}"
    echo "可选环境变量: PORT=5173 NODE_BIN=node"
    exit 1
    ;;
esac
