/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file include/rpl0apply.h
 Gaiadb redo log replication

 Created 10/12/2021 Hongyu Qiao
 *******************************************************/

#pragma once

#include "rpl0assemble.h"
#include <boost/lockfree/spsc_queue.hpp>

namespace rpl {

extern void rpl_coordinator();

class RplCoordinator;
class RplMaterializer;
extern RplCoordinator *g_rpl_coordinator;

enum ApplyState {
  UNINIT = 0,
  PICK_ASMB,
  PREPARE,
  APPLY_PAGE,
  COMMIT,
  FINISH,
  SHUTDOWN,
};

class RplCoordinator {
  RplCoordinator();

 public:
  ~RplCoordinator();
  static RplCoordinator &get_instance() {
    static RplCoordinator s_rpl_coordinator;
    return s_rpl_coordinator;
  }

  const char* apply_state_str();

  bool init();

  bool cleanup();

  RplMaterializer &slot_materializer(uint64_t slot_id);

  void routine();

  friend RplMaterializer;

public:
  THD *m_thd;

 private:
  DISALLOW_COPY_AND_ASSIGN(RplCoordinator);
  std::vector<RplMaterializer*> rpl_materializers_;
  ApplyState apply_state_;
};

class RplMaterializer {
 public:
  RplMaterializer(uint64_t id);
  ~RplMaterializer();
  bool init();
  bool cleanup();

  void routine();

  static bool apply_page(buf_block_t *block, RplAssembly *asmb);

  void add_apply_task(RplAssembly *task);

  RplAssembly *pick_one_task();

  uint64_t slot_id_;

 private:
  uint64_t index_;
  boost::lockfree::spsc_queue<RplAssembly *, boost::lockfree::capacity<RPL_ASMB_BUCKETS>>
      apply_tasks_;
};

}  // namespace rpl
