/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/include/gaiadb_utility.h

 Created 12/26/2022 Shenghu Zhu
 *******************************************************/
#ifndef gaiadb_utility_h
#define gaiadb_utility_h
#include "bvar/bvar.h"

int64_t get_cpuwide_time_s();

struct ScopedLatencyRecorder {
  uint64_t start_us;
  bvar::LatencyRecorder* bvar_instance;

  ScopedLatencyRecorder(bvar::LatencyRecorder* var) : bvar_instance(var) {
    start_us = my_micro_time();
  }
  ~ScopedLatencyRecorder() {
    (*bvar_instance) << my_micro_time() - start_us;
  }
};

struct ScopedBvarTimerAdder {
  uint64_t start_us;
  bvar::Adder<uint64_t>* bvar_instance;

  ScopedBvarTimerAdder(bvar::Adder<uint64_t>* var) : bvar_instance(var) {
    start_us = my_micro_time();
  }
  ~ScopedBvarTimerAdder() {
    (*bvar_instance) << my_micro_time() - start_us;
  }
};

struct LSNRange {
  explicit LSNRange(uint64_t start, uint64_t end)
      : start_lsn(start), end_lsn(end) {}

  friend std::ostream& operator<<(std::ostream& os, const LSNRange& range) {
    os << "[" << range.start_lsn << ", " << range.end_lsn << ")";
    return os;
  }

  uint64_t start_lsn;
  uint64_t end_lsn;
};

 #endif /* gaiadb_utility_h */