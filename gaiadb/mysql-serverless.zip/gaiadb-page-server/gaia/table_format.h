/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/table_format.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <algorithm>
#include <numeric>
#include <string>
#include <iomanip>
#include <iostream>
#include <variant>
#include <vector>
#include <initializer_list>
#include <cassert>
#include <cstring>
#include <base/string_printf.h>
#include <psvr0meta.h>
#include <gaiadb/utils/utils.h>

namespace psvr {
namespace gaia {

struct RowEmptyLine {};
inline std::ostream& operator<<(std::ostream& os, const RowEmptyLine&) {
    return os << "-";
}

struct RowStr {
    std::string str;
    RowStr(const char& c) : str(1, c) {}
    RowStr(const std::string& s) : str(s) {}
    RowStr(const char* s) : str(s) {}
    template<typename T>
    RowStr(const T& s) {
        using std::to_string;
        str = to_string(s);
    }
    RowStr(const std::string& s1, const std::string& s2) : str(s1) {
        str.append(" ").append(s2);
    }
    RowStr(const char* s1, const char* s2) : str(s1) {
        str.append(" ").append(s2);
    }
    RowStr(const std::string& s1, const char* s2) : str(s1) {
        str.append(" ").append(s2);
    }
    RowStr(const char* s1, const std::string& s2) : str(s1) {
        str.append(" ").append(s2);
    }
    template<typename T>
    RowStr(const std::string& s1, const T& s2) : str(s1) {
        str.append(" ").append(std::to_string(s2));
    }
    template<typename T>
    RowStr(const T& s1, const std::string& s2) {
        str.append(std::to_string(s1));
        str.append(" ").append(s2);
    }
    template<typename T1, typename T2>
    RowStr(const T1& s1, const T2& s2) {
        using std::to_string;
        str.append(to_string(s1));
        str.append(" ").append(to_string(s2));
    }
};

inline std::string to_string(const psvr::gaia::RowStr& value) {
    return value.str;
}

inline std::ostream& operator<<(std::ostream& os, const RowStr& row) {
    return os << row.str;
}

struct RowPercent {
    std::string str;
    RowPercent(int64_t used, int64_t total) {
        double dv = used * 100.0 / total;
        str = base::string_printf("%.2f%%", dv);
    }
};
inline std::ostream& operator<<(std::ostream& os, const RowPercent& row) {
    return os << row.str;
}

struct RowPrefix {
    std::string prefix;
    RowStr str;

    template<typename T>
    RowPrefix(const std::string& pre, const T& v)
        : prefix(pre), str(v) {}
};
inline std::ostream& operator<<(std::ostream& os, const RowPrefix& row) {
    return os << row.prefix << row.str;
}

inline std::string to_string(const psvr::gaia::RowPrefix& value) {
    std::string tmp(value.prefix);
    tmp.append(value.str.str);
    return tmp;
}

struct RowSize {
    std::string str;
    RowSize(ssize_t _s, bool human_readable = false) {
        if (_s >= 0) {
            format(static_cast<size_t>(_s), human_readable);
        } else {
            str = base::string_printf("%ld", _s);
        }
    }
    RowSize(size_t _s, bool human_readable = false) {
        format(_s, human_readable);
    }

    void format(size_t _s, bool human_readable) {
        if (!human_readable) {
            str = base::string_printf("%lu", _s);
            return;
        }
        str = gaiadb::common::human_size(_s);
    }
};
inline std::ostream& operator<<(std::ostream& os, const RowSize& row) {
    return os << row.str;
}

struct Row {
    using RowType = std::variant<RowEmptyLine, RowStr, RowPercent, RowPrefix, RowSize,
          float, double, bool, int32_t, uint32_t, int64_t, uint64_t,
          std::string, const char*, gaia_apply::byte*>;

    Row() : _width(0) {}
    ~Row() {}

    size_t width() const { return _width; }
    size_t line_cnt() const { return _lines.size(); }

    const RowType& GetLine(size_t idx) const { return _lines[idx]; }

    template<typename T>
    void AddLine(bool has, const T& v, bool calc_width = true) {
        if (has) {
            AddLine(v, calc_width);
        } else {
            AddLine("unknown", calc_width);
        }
    }

    template<typename T>
    void AddLine(const T& v, bool calc_width = true) {
        _lines.emplace_back(v);
        if (calc_width) {
            _width = std::max(_width, GetWidth(_lines.back()));
        }

        //if (std::holds_alternative<std::string>(_lines[0])) {
            //if (std::get<std::string>(_lines[0]) == "store_id") {
                //printf("_width:%lu\n", _width);
            //}
        //}
    }

    void Display(std::ostream& os, size_t idx) {
        std::visit([&os](auto&& arg) {
            using T = std::decay_t<decltype(arg)>;
            if constexpr (std::is_same_v<T, bool>) {
                os << (arg ? "true" : "false");
            } else {
                os << arg;
            }
        }, _lines[idx]);
    }

private:
    template <typename T>
    size_t GetNumberLen(T num) {
        return std::to_string(num).size();
    }

    size_t GetWidth(const RowType& row) {
        if (std::holds_alternative<bool>(row)) {
            return (std::get<bool>(row) ? 4 : 5);
        } else if (std::holds_alternative<uint32_t>(row)) {
            return GetNumberLen(std::get<uint32_t>(row));
        } else if (std::holds_alternative<uint64_t>(row)) {
            return GetNumberLen(std::get<uint64_t>(row));
        } else if (std::holds_alternative<int32_t>(row)) {
            return GetNumberLen(std::get<int32_t>(row));
        } else if (std::holds_alternative<int64_t>(row)) {
            return GetNumberLen(std::get<int64_t>(row));
        } else if (std::holds_alternative<float>(row)) {
            return GetNumberLen(std::get<float>(row));
        } else if (std::holds_alternative<double>(row)) {
            return GetNumberLen(std::get<double>(row));
        } else if (std::holds_alternative<std::string>(row)) {
            return std::get<std::string>(row).size();
        } else if (std::holds_alternative<const char*>(row)) {
            return strlen(std::get<const char*>(row));
        } else if (std::holds_alternative<gaia_apply::byte*>(row)) {
            return strlen(reinterpret_cast<const char*>(std::get<gaia_apply::byte*>(row)));
        } else if (std::holds_alternative<RowEmptyLine>(row)) {
            return 1;
        } else if (std::holds_alternative<RowStr>(row)) {
            return std::get<RowStr>(row).str.size();
        } else if (std::holds_alternative<RowPercent>(row)) {
            return std::get<RowPercent>(row).str.size();
        } else if (std::holds_alternative<RowPrefix>(row)) {
            return std::get<RowPrefix>(row).prefix.size() + std::get<RowPrefix>(row).str.str.size();
        } else if (std::holds_alternative<RowSize>(row)) {
            return std::get<RowSize>(row).str.size();
        } else {
            assert(false);
        }
        return 0;
    }

private:
    size_t _width;
    std::vector<RowType> _lines;
};

inline Row::RowType get_unknown_type(bool has, Row::RowType t, Row::RowType v = "unknown") {
    if (!has) {
        t = v;
    }
    return t;
}

// Convert any RowType variant to a string for comparison purposes.
inline std::string row_type_to_string(const Row::RowType& v) {
    std::string result;
    std::visit([&result](auto&& arg) {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, bool>) {
            result = arg ? "true" : "false";
        } else if constexpr (std::is_same_v<T, RowEmptyLine>) {
            result = "-";
        } else if constexpr (std::is_same_v<T, RowStr>) {
            result = arg.str;
        } else if constexpr (std::is_same_v<T, RowPercent>) {
            result = arg.str;
        } else if constexpr (std::is_same_v<T, RowPrefix>) {
            result = arg.prefix + arg.str.str;
        } else if constexpr (std::is_same_v<T, RowSize>) {
            result = arg.str;
        } else if constexpr (std::is_same_v<T, std::string>) {
            result = arg;
        } else if constexpr (std::is_same_v<T, const char*>) {
            result = arg ? arg : "";
        } else if constexpr (std::is_same_v<T, gaia_apply::byte*>) {
            result = arg ? reinterpret_cast<const char*>(arg) : "";
        } else {
            using std::to_string;
            result = to_string(arg);
        }
    }, v);
    return result;
}

// Compare two RowType values: numeric comparison when both are purely numeric
// strings, otherwise lexicographic string comparison.
inline int compare_row_values(const Row::RowType& a, const Row::RowType& b) {
    auto sa = row_type_to_string(a);
    auto sb = row_type_to_string(b);
    char* end_a = nullptr;
    char* end_b = nullptr;
    double da = std::strtod(sa.c_str(), &end_a);
    double db = std::strtod(sb.c_str(), &end_b);
    // Only use numeric comparison when the entire string is a valid number.
    // A partial parse (e.g. "192.168.1.1" → 192.168, or "10.5%" → 10.5)
    // falls back to lexicographic comparison to avoid incorrect results.
    if (!sa.empty() && !sb.empty()
            && end_a == sa.c_str() + sa.size()
            && end_b == sb.c_str() + sb.size()) {
        if (da < db) return -1;
        if (da > db) return 1;
        return 0;
    }
    return sa.compare(sb);
}

// Global sort configuration for Table::Display().
struct TableSortConfig {
    std::string col_name;
    bool ascending = true;
    bool enabled = false;
};

inline TableSortConfig& GetTableSortConfig() {
    static TableSortConfig config;
    return config;
}

inline void SetTableSortBy(const std::string& col_name) {
    auto& cfg = GetTableSortConfig();
    cfg.col_name = col_name;
    cfg.enabled = !col_name.empty();
}

inline void SetTableSortAscending(bool ascending) {
    GetTableSortConfig().ascending = ascending;
}

struct Table {
    Table(bool with_line, size_t size)
        : _with_line(with_line), _has_title(false),
        _row_size(0), _with_no(false), _no(0) {
        if (size) {
            AddRows(size);
        }
    }
    Table(size_t size = 0) : Table(false, size) {}

    ~Table() {}

    void AddRows(size_t size) {
        for (size_t i = 0; i < size; ++i) {
            AddRow();
        }
    }

    void AddRowsWithName(std::initializer_list<std::string> titles, bool show_no = false) {
        if (show_no) {
            _with_no = show_no;
            if (_with_line) {
                AddRow().AddLine("NO");
            } else {
                AddRow().AddLine("--");
            }
        }
        for (auto& it : titles) {
            AddRow().AddLine(it);
        }
        _has_title = true;
    }

    Row& AddRow() {
        _rows.emplace_back();
        ++_row_size;
        return _rows.back();
    }

    Row& GetRow(size_t i) {
        return _rows[i];
    }

    void AddRowsValue(std::initializer_list<Row::RowType> values) {
        size_t i = 0;
        if (_with_no) {
            _rows[i++].AddLine(++_no);
        }
        for (auto& it : values) {
            _rows[i++].AddLine(it);
        }
        for (; i < _row_size; ++i) {
            _rows[i].AddLine(RowEmptyLine());
        }
    }

    void Display();
private:

    int FindSortColumn(const std::string& col_name) const;

    void DrawHeaderOrFooter(std::ostream& os) {
        if (!_with_line) { return; }
        DrawLink(os);
        for (auto& row : _rows) {
            DrawLine(os, row.width() + 2);  // prefix blank and suffix blank
            DrawLink(os);
        }
        os << std::endl;
    }

    void DrawLine(std::ostream& os, size_t n) {
        if (!_with_line) { return; }
        for (size_t i = 0; i < n; ++i) {
            os << "-";
        }
    }

    void DrawLink(std::ostream& os) {
        if (!_with_line) { return; }
        os << "+";
    }

    void DrawSplit(std::ostream& os) {
        if (!_with_line) { return; }
        os << "|";
    }

private:
    bool _with_line;
    bool _has_title;
    size_t _row_size;
    bool _with_no;
    size_t _no;
    std::vector<Row> _rows;
};

}
}
