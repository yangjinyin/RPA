const clusterSelect = document.querySelector('#clusterSelect');
const refreshButton = document.querySelector('#refreshButton');
const refreshDataButton = document.querySelector('#refreshDataButton');
const servicePath = document.querySelector('#servicePath');
const modeButtons = Array.from(document.querySelectorAll('.mode-tabs [data-mode]'));
const currentCluster = document.querySelector('#currentCluster');
const copyClusterButton = document.querySelector('#copyClusterButton');
const nodeCount = document.querySelector('#nodeCount');
const bnsLink = document.querySelector('#bnsLink');
const offlineNodeCount = document.querySelector('#offlineNodeCount');
const disableNodeDiffCount = document.querySelector('#disableNodeDiffCount');
const diskCount = document.querySelector('#diskCount');
const disableDiskCount = document.querySelector('#disableDiskCount');
const riskDiskCount = document.querySelector('#riskDiskCount');
const clusterCapacity = document.querySelector('#clusterCapacity');
const zoneSummary = document.querySelector('#zoneSummary');
const dataStatus = document.querySelector('#dataStatus');
const clusterSource = document.querySelector('#clusterSource');
const zoneTabs = document.querySelector('#zoneTabs');
const diskFilter = document.querySelector('#diskFilter');
const nodeFilterInput = document.querySelector('#nodeFilterInput');
const topologyInfo = document.querySelector('#topologyInfo');
const notice = document.querySelector('#notice');
const loading = document.querySelector('#loading');
const tableView = document.querySelector('#tableView');
const segmentView = document.querySelector('#segmentView');
const segmentSearch = document.querySelector('#segmentSearch');
const segmentContent = document.querySelector('#segmentContent');
const poolAllocatedCapacity = document.querySelector('#poolAllocatedCapacity');
const poolRecyclingCapacity = document.querySelector('#poolRecyclingCapacity');
const poolMinBackupSpeed = document.querySelector('#poolMinBackupSpeed');
const segmentPhysicalSize = document.querySelector('#segmentPhysicalSize');
const ibdActualUsageRate = document.querySelector('#ibdActualUsageRate');
const appendDbSize = document.querySelector('#appendDbSize');
const refreshSegmentButton = document.querySelector('#refreshSegmentButton');
const recoveryView = document.querySelector('#recoveryView');
const recoveryNodeSearch = document.querySelector('#recoveryNodeSearch');
const recoveryClusterSearch = document.querySelector('#recoveryClusterSearch');
const recoverySummary = document.querySelector('#recoverySummary');
const recoveryContent = document.querySelector('#recoveryContent');
const jsonView = document.querySelector('#jsonView');
const tableViewButton = document.querySelector('#tableViewButton');
const segmentViewButton = document.querySelector('#segmentViewButton');
const recoveryViewButton = document.querySelector('#recoveryViewButton');
const jsonViewButton = document.querySelector('#jsonViewButton');

let currentData = null;
let currentRows = [];
let currentSegmentRaw = '';
let currentSegmentRows = [];
let currentRecoveryRaw = '';
let currentRecoveryRows = [];
let proxyMap = new Map();
let segmentSortState = { key: 'clusterId', direction: 'asc' };
let recoverySortState = { key: 'finishRate', direction: 'asc' };
let recoveryNodeFilterText = '';
let recoveryClusterFilterText = '';
let selectedZone = 'all';
let nodeFilterText = '';
let activeView = 'disk';
let currentMode = getModeFromUrl();
let sortState = { key: 'physicalUsage', direction: 'desc' };
let topologySortState = { key: 'zone', direction: 'asc' };

const zoneColumn = {
    key: 'zone',
    label: 'Zone',
    type: 'text',
    render: (row) => displayZone(row.zone),
};

const columns = [
    { key: 'node', label: '节点信息', type: 'text', html: (row) => renderDiskNodeCell(row) },
    { key: 'storeId', label: '磁盘ID', type: 'number', render: (row) => displayValue(row.storeId) },
    { key: 'physicalUsage', label: '物理使用率', type: 'number', html: (row) => renderPercent(row.physicalUsage) },
    {
        key: 'diskUsage',
        label: '磁盘使用率',
        headerTitle: '物理容量 * x%',
        type: 'number',
        html: (row) => renderDiskUsage(row),
        title: (row) => getDiskUsageTitle(row),
    },
    {
        key: 'availableRatio',
        label: '可使用比例',
        headerTitle: '磁盘容量 / 物理容量',
        type: 'number',
        html: (row) => renderAvailableRatio(row),
        title: (row) => getAvailableRatioTitle(row),
    },
    {
        key: 'logicUsage',
        label: '逻辑使用率',
        headerTitle: '分片数量 * 分片大小(32G) / 磁盘大小',
        type: 'number',
        html: (row) => renderPercent(row.logicUsage),
    },
    {
        key: 'physicalSizeGroup',
        label: '磁盘上限 / 使用 / 剩余',
        headerTitle: '物理容量',
        type: 'number',
        sortKeys: [
            { key: 'physicalStoreSize', label: '上限' },
            { key: 'physicalUsedSize', label: '使用' },
            { key: 'physicalFreeSize', label: '剩余' },
        ],
        render: (row) => formatPhysicalSizeGroup(row),
    },
    {
        key: 'shardUsage',
        label: '分片使用率',
        type: 'number',
        html: (row) => renderPercent(row.shardUsage),
    },
    {
        key: 'shardSizeGroup',
        label: '分片上限 / 使用 / 剩余',
        type: 'number',
        sortKeys: [
            { key: 'capacity', label: '上限' },
            { key: 'usedCapacity', label: '使用' },
            { key: 'freeCapacity', label: '剩余' },
        ],
        render: (row) => formatShardSizeGroup(row),
    },
    {
        key: 'ioErrorCount',
        label: 'IO 错误',
        type: 'number',
        render: (row) => displayValue(row.ioErrorCount),
    },
    {
        key: 'storePath',
        label: '路径',
        type: 'text',
        render: (row) => displayValue(row.storePath),
    },
];

function setNotice(message, type = 'warning') {
    notice.textContent = message || '';
    notice.classList.toggle('hidden', !message);
    notice.classList.toggle('error', type === 'error');
}

function setLoading(isLoading) {
    loading.classList.toggle('hidden', !isLoading);
    dataStatus.textContent = isLoading ? '查询中' : dataStatus.textContent;
    refreshDataButton.disabled = isLoading || !clusterSelect.value;
}

async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return;
    }

    const input = document.createElement('textarea');
    input.value = text;
    input.setAttribute('readonly', 'readonly');
    input.style.position = 'fixed';
    input.style.left = '-9999px';
    document.body.appendChild(input);
    input.select();
    document.execCommand('copy');
    input.remove();
}

function displayValue(value) {
    if (value === null || value === undefined || value === '') {
        return '-';
    }
    if (typeof value === 'object') {
        return JSON.stringify(value);
    }
    return String(value);
}

function displayZone(value) {
    return value === 'unknown' ? '未知' : displayValue(value);
}

function pick(obj, keys) {
    for (const key of keys) {
        if (obj && obj[key] !== undefined && obj[key] !== null && obj[key] !== '') {
            return obj[key];
        }
    }
    return '';
}

function pickOptional(obj, keys) {
    for (const key of keys) {
        if (obj && obj[key] !== undefined && obj[key] !== null) {
            return obj[key];
        }
    }
    return undefined;
}

function toNumber(value) {
    if (value === null || value === undefined || value === '') {
        return null;
    }
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
}

function formatBytes(value) {
    const number = toNumber(value);
    if (number === null) {
        return '-';
    }

    const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    let size = Math.abs(number);
    let unitIndex = 0;
    while (size >= 1024 && unitIndex < units.length - 1) {
        size /= 1024;
        unitIndex += 1;
    }

    const signedSize = number < 0 ? -size : size;
    const digits = size >= 100 || unitIndex === 0 ? 0 : size >= 10 ? 1 : 2;
    return `${signedSize.toFixed(digits)} ${units[unitIndex]}`;
}

function formatBytesPerSecond(value) {
    const formatted = formatBytes(value);
    return formatted === '-' ? '-' : `${formatted}/s`;
}

function formatMegabytes(value) {
    const number = toNumber(value);
    if (number === null) {
        return '-';
    }
    return formatBytes(number * 1024 * 1024);
}

function formatMegabytesPerSecond(value) {
    const number = toNumber(value);
    if (number === null) {
        return '-';
    }
    return `${number.toFixed(number >= 10 ? 1 : 2)} MB/s`;
}

function formatPercent(value) {
    const number = toNumber(value);
    if (number === null) {
        return '-';
    }
    return `${(number * 100).toFixed(2)}%`;
}

function ratio(used, total) {
    const usedNumber = toNumber(used);
    const totalNumber = toNumber(total);
    if (usedNumber === null || totalNumber === null || totalNumber <= 0) {
        return null;
    }
    return usedNumber / totalNumber;
}

function diskUsageRatio(storeSize, freeSize) {
    const storeSizeNumber = toNumber(storeSize);
    const freeSizeNumber = toNumber(freeSize);
    if (storeSizeNumber === null || freeSizeNumber === null || storeSizeNumber <= 0) {
        return null;
    }
    return (storeSizeNumber - freeSizeNumber) / storeSizeNumber;
}

function logicUsageRatio(logicUsedSize, storeSize) {
    return ratio(logicUsedSize, storeSize);
}

function subtractNullable(total, used) {
    const totalNumber = toNumber(total);
    const usedNumber = toNumber(used);
    if (totalNumber === null || usedNumber === null) {
        return null;
    }
    return totalNumber - usedNumber;
}

function formatPhysicalSizeGroup(row) {
    return [
        formatBytes(row.physicalStoreSize),
        formatBytes(row.physicalUsedSize),
        formatBytes(row.physicalFreeSize),
    ].join(' / ');
}

function formatShardSizeGroup(row) {
    return `${displayValue(row.capacity)} / ${displayValue(row.usedCapacity)} / ${displayValue(row.freeCapacity)}`;
}

function percentClass(value) {
    const number = toNumber(value);
    if (number === null) {
        return 'muted';
    }
    if (number >= 0.9) {
        return 'danger';
    }
    if (number >= 0.75) {
        return 'warning';
    }
    return 'ok';
}

function renderPercent(value, title = '') {
    const className = percentClass(value);
    const titleAttr = title ? ` title="${escapeHtml(title)}"` : '';
    return [
        `<span class="percent ${className}"${titleAttr}>`,
        escapeHtml(formatPercent(value)),
        '</span>',
    ].join('');
}

function getDiskUsageTitle(row) {
    const availableRate = ratio(row.storeSize, row.physicalStoreSize);
    return `可使用的大小, 占物理大小的 ${formatPercent(availableRate)}`;
}

function renderDiskUsage(row) {
    return renderPercent(row.diskUsage, getDiskUsageTitle(row));
}

function getAvailableRatioTitle(row) {
    return `磁盘容量占物理容量的 ${formatPercent(row.availableRatio)}`;
}

function renderAvailableRatio(row) {
    return renderPercent(row.availableRatio, getAvailableRatioTitle(row));
}

function formatBool(value) {
    if (value === true) {
        return '是';
    }
    if (value === false) {
        return '否';
    }
    return '-';
}

function formatActive(value) {
    return formatBool(value);
}

function isOfflineMachine(value) {
    return value === true || value === 'true' || value === 1 || value === '1';
}

function formatCommit(value) {

    const text = displayValue(value);
    if (text === '-') {
        return text;
    }
    const commit = text.includes('@') ? text.slice(text.indexOf('@') + 1) : text;
    return commit.slice(0, 8);
}

function normalizeZone(value) {
    if (value === null || value === undefined || value === '') {
        return 'unknown';
    }
    const text = String(value);
    const match = text.match(/zone[-_]?([0-9]+)/i);
    if (match) {
        return `zone${match[1]}`;
    }
    if (/^[0-9]+$/.test(text)) {
        return `zone${text}`;
    }
    return text;
}

function getZone(value, context = {}) {
    const explicitZone = pickOptional(value, [
        'topology_zone',
        'topologyZone',
        'zone',
        'zone_id',
        'zoneId',
        'zone_name',
        'zoneName',
    ]);
    const source = explicitZone === undefined ? context.zone : explicitZone;
    const fallback = pick(value, [
        'node',
        'node_name',
        'host',
        'hostname',
        'addr',
        'address',
        'ps',
        'server',
    ]) || context.node || '';
    return normalizeZone(source === undefined ? fallback : source);
}

function zoneSortValue(zone) {
    if (zone === 'all') {
        return -1;
    }
    const match = String(zone).match(/zone([0-9]+)/i);
    return match ? Number(match[1]) : Number.MAX_SAFE_INTEGER;
}

function flattenStores(data) {
    const rows = [];

    function walk(value, context = {}) {
        if (Array.isArray(value)) {
            value.forEach((item) => walk(item, context));
            return;
        }

        if (!value || typeof value !== 'object') {
            return;
        }

        const node = pick(value, [
            'node',
            'node_name',
            'host',
            'hostname',
            'ip',
            'addr',
            'address',
            'ps',
            'server',
        ]) || context.node;
        const zone = getZone(value, context);
        const pickedToOffline = pickOptional(value, [
            'topology_to_offline',
            'topologyToOffline',
        ]);
        const toOffline = pickedToOffline === undefined ? context.toOffline : pickedToOffline;
        const pkgVersion = pick(value, ['pkg_version', 'pkgVersion']) || context.pkgVersion;
        const gitCommit = pick(value, ['git_commit', 'gitCommit']) || context.gitCommit;
        const storeId = pick(value, ['store_id', 'storeId', 'id']);
        const storePath = pick(value, [
            'store_path',
            'path',
            'mount_path',
            'dir',
            'store_dir',
            'disk',
            'disk_name',
        ]);
        const storeSize = pick(value, ['store_size']);
        const freeSize = pick(value, ['free_size']);
        const logicUsedSize = pick(value, ['logic_used_size']);
        const physicalUsedSize = pick(value, ['physical_used_size']);
        const physicalStoreSize = pick(value, ['physical_store_size']);
        const capacity = pick(value, ['capacity']);
        const usedCapacity = pick(value, ['used_capacity']);

        if (storePath || storeId !== '' || value.store || value.disk_info || value.store_info) {
            rows.push({
                node: node || '-',
                zone,
                toOffline,
                pkgVersion,
                gitCommit,
                storeId: storeId === '' ? '-' : storeId,
                active: pick(value, ['active']),
                storePath: storePath || '-',
                storeSize,
                specifyStoreSize: pick(value, ['specify_store_size']),
                freeSize,
                logicUsedSize,
                physicalUsedSize,
                physicalStoreSize,
                capacity,
                usedCapacity,
                diskUsage: diskUsageRatio(storeSize, freeSize),
                availableRatio: ratio(storeSize, physicalStoreSize),
                logicUsage: logicUsageRatio(logicUsedSize, storeSize),
                physicalUsage: ratio(physicalUsedSize, physicalStoreSize),
                physicalFreeSize: subtractNullable(
                    physicalStoreSize,
                    physicalUsedSize
                ),
                shardUsage: ratio(usedCapacity, capacity),
                freeCapacity: subtractNullable(capacity, usedCapacity),
                ioErrorCount: pick(value, ['io_error_count']),
                compressRate: pick(value, ['compress_rate']),
                raw: value,
            });
        }

        const nextContext = { ...context, node: node || context.node, zone, toOffline, pkgVersion, gitCommit };
        Object.entries(value).forEach(([key, child]) => {
            if (key === 'raw') {
                return;
            }
            if (child && typeof child === 'object') {
                walk(child, nextContext);
            }
        });
    }

    walk(data);
    return rows.length ? rows : [{
        node: '-',
        zone: 'unknown',
        toOffline: '',
        pkgVersion: '',
        gitCommit: '',
        storeId: '-',
        active: '',
        storePath: '-',
        raw: data,
    }];
}

function getCapacitySummary(rows) {
    return rows.reduce((acc, row) => {
        acc.total += toNumber(row.physicalStoreSize) || 0;
        acc.used += toNumber(row.physicalUsedSize) || 0;
        return acc;
    }, { total: 0, used: 0 });
}

function formatCapacitySummary(summary) {
    const free = summary.total - summary.used;
    const usage = summary.total > 0 ? summary.used / summary.total : null;
    return [
        formatBytes(summary.total),
        `${formatBytes(summary.used)}(${formatPercent(usage)})`,
        formatBytes(free),
    ].join(' / ');
}

function clampZero(value) {
    return Math.max(0, value);
}

function getZoneSummaryRows(rows) {
    const zoneMap = new Map();
    rows.forEach((row) => {
        const zone = row.zone || 'unknown';
        if (!zoneMap.has(zone)) {
            zoneMap.set(zone, {
                zone,
                nodeNames: new Set(),
                physicalUsageTotal: 0,
                physicalUsageCount: 0,
                diskUsageTotal: 0,
                diskUsageCount: 0,
                ioErrorDiskCount: 0,
                freePhysicalSize: 0,
                freeShardCount: 0,
            });
        }

        const zoneRow = zoneMap.get(zone);
        if (row.node && row.node !== '-') {
            zoneRow.nodeNames.add(row.node);
        }
        const physicalUsage = toNumber(row.physicalUsage);
        const physicalStoreSize = toNumber(row.physicalStoreSize);
        const physicalUsedSize = toNumber(row.physicalUsedSize);
        const diskUsage = toNumber(row.diskUsage);
        const ioErrorCount = toNumber(row.ioErrorCount);
        const capacity = toNumber(row.capacity);
        const usedCapacity = toNumber(row.usedCapacity);
        if (physicalUsage !== null) {
            zoneRow.physicalUsageTotal += physicalUsage;
            zoneRow.physicalUsageCount += 1;
        }
        if (diskUsage !== null) {
            zoneRow.diskUsageTotal += diskUsage;
            zoneRow.diskUsageCount += 1;
        }
        if (ioErrorCount !== null && ioErrorCount > 0) {
            zoneRow.ioErrorDiskCount += 1;
        }
        if (physicalStoreSize !== null && physicalUsedSize !== null) {
            zoneRow.freePhysicalSize += clampZero(physicalStoreSize - physicalUsedSize);
        }
        if (capacity !== null && usedCapacity !== null) {
            zoneRow.freeShardCount += clampZero(capacity - usedCapacity);
        }
    });

    return [...zoneMap.values()].sort((a, b) => zoneSortValue(a.zone) - zoneSortValue(b.zone)
        || String(a.zone).localeCompare(String(b.zone), 'zh-CN', { numeric: true }));
}

function formatZoneSummaryRow(row) {
    const averageUsage = row.physicalUsageCount > 0
        ? row.physicalUsageTotal / row.physicalUsageCount
        : null;
    const averageDiskUsage = row.diskUsageCount > 0
        ? row.diskUsageTotal / row.diskUsageCount
        : null;
    return [
        `${displayZone(row.zone)}:`,
        `节点数量 ${row.nodeNames.size}`,
        `平均物理使用率 ${formatPercent(averageUsage)}`,
        `平均磁盘使用率 ${formatPercent(averageDiskUsage)}`,
        `剩余 ${formatBytes(row.freePhysicalSize)}`,
        `剩余分片 ${row.freeShardCount}`,
        `IO 错误磁盘 ${row.ioErrorDiskCount}`,
    ].join(' ');
}

function renderZoneSummary(rows) {
    const zoneRows = getZoneSummaryRows(rows);
    if (!zoneRows.length) {
        zoneSummary.textContent = '-';
        return;
    }

    zoneSummary.innerHTML = zoneRows
        .map((row) => {
            const averageUsage = row.physicalUsageCount > 0
                ? row.physicalUsageTotal / row.physicalUsageCount
                : null;
            const averageDiskUsage = row.diskUsageCount > 0
                ? row.diskUsageTotal / row.diskUsageCount
                : null;
            const summary = formatZoneSummaryRow(row);
            const usageClass = `zone-usage-${percentClass(averageUsage)}`;
            const diskUsageClass = `zone-usage-${percentClass(averageDiskUsage)}`;
            return `
                <div class="zone-summary-item" title="${escapeHtml(summary)}">
                    <strong>${escapeHtml(displayZone(row.zone))}</strong>
                    <div class="zone-summary-metrics">
                        <div class="zone-summary-metric-row">
                            <div class="zone-summary-metric">
                                <span>节点数量</span>
                                <strong>${row.nodeNames.size}</strong>
                            </div>
                            <div class="zone-summary-metric">
                                <span>平均物理使用率</span>
                                <strong class="${usageClass}">
                                    ${escapeHtml(formatPercent(averageUsage))}
                                </strong>
                            </div>
                            <div class="zone-summary-metric">
                                <span>平均磁盘使用率</span>
                                <strong class="${diskUsageClass}">
                                    ${escapeHtml(formatPercent(averageDiskUsage))}
                                </strong>
                            </div>
                        </div>
                        <div class="zone-summary-metric-row zone-summary-metric-row-bottom">
                            <div class="zone-summary-metric">
                                <span>剩余</span>
                                <strong>${escapeHtml(formatBytes(row.freePhysicalSize))}</strong>
                            </div>
                            <div class="zone-summary-metric">
                                <span>可用分片数</span>
                                <strong>${row.freeShardCount}</strong>
                            </div>
                            <div class="zone-summary-metric">
                                <span>IO 错误磁盘</span>
                                <strong>${row.ioErrorDiskCount}</strong>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        })
        .join('');
}

function summarizeRows(rows) {
    const nodeNames = new Set(rows.map((row) => row.node).filter((name) => name && name !== '-'));
    const offlineNodes = new Set(rows
        .filter((row) => row.toOffline === true && row.node && row.node !== '-')
        .map((row) => row.node));
    const disks = rows.filter((row) => row.storePath !== '-' || row.storeId !== '-');
    const disabledDiskCount = disks.filter((row) => [false, 'false', 0, '0'].includes(row.active)).length;
    const riskCount = disks.filter((row) => toNumber(row.physicalUsage) !== null && row.physicalUsage > 0.8).length;
    nodeCount.textContent = nodeNames.size || '-';
    offlineNodeCount.textContent = `预下线 ${offlineNodes.size}`;
    offlineNodeCount.classList.toggle('active', offlineNodes.size > 0);
    disableNodeDiffCount.textContent = 'disable -';
    disableNodeDiffCount.title = '';
    disableNodeDiffCount.classList.remove('active');
    disableNodeDiffCount.hidden = true;
    diskCount.textContent = disks.length || '-';
    disableDiskCount.textContent = `disable ${disabledDiskCount}`;
    disableDiskCount.classList.toggle('active', disabledDiskCount > 0);
    riskDiskCount.textContent = `风险 ${riskCount}`;
    riskDiskCount.classList.toggle('active', riskCount > 0);
    clusterCapacity.textContent = formatCapacitySummary(getCapacitySummary(disks));
    renderZoneSummary(disks);
}

function escapeHtml(value) {
    return String(value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function parsePbValue(value) {
    const trimmed = value.trim();
    if (trimmed === 'true') {
        return true;
    }
    if (trimmed === 'false') {
        return false;
    }
    if (/^-?\d+(\.\d+)?$/.test(trimmed)) {
        return Number(trimmed);
    }
    return trimmed.replace(/^"|"$/g, '');
}

function parseSegmentPb(text) {
    const segments = [];
    const lines = String(text || '').split(/\r?\n/);
    let currentServerAddr = '-';
    let currentSegment = null;
    let inSegment = false;
    let segmentDepth = 0;

    lines.forEach((line) => {
        const trimmed = line.trim();
        if (!trimmed) {
            return;
        }

        if (!inSegment) {
            const addrMatch = trimmed.match(/^addr:\s*(.+)$/);
            if (addrMatch) {
                currentServerAddr = parsePbValue(addrMatch[1]);
            }
        }

        if (trimmed === 'segments {') {
            currentSegment = { serverAddr: currentServerAddr };
            inSegment = true;
            segmentDepth = 1;
            return;
        }

        if (!inSegment || !currentSegment) {
            return;
        }

        if (trimmed.endsWith('{')) {
            segmentDepth += 1;
            return;
        }

        if (trimmed === '}') {
            segmentDepth -= 1;
            if (segmentDepth === 0) {
                segments.push(currentSegment);
                currentSegment = null;
                inSegment = false;
            }
            return;
        }

        if (segmentDepth === 1) {
            const match = trimmed.match(/^([a-zA-Z0-9_]+):\s*(.+)$/);
            if (match) {
                currentSegment[match[1]] = parsePbValue(match[2]);
            }
        }
    });

    return segments;
}

function summarizeSegments(text) {
    const segments = parseSegmentPb(text);
    const grouped = new Map();

    segments.forEach((segment) => {
        const clusterId = displayValue(segment.cluster_id);
        if (!grouped.has(clusterId)) {
            grouped.set(clusterId, {
                clusterId,
                segmentIds: new Set(),
                segmentReplicaCounts: new Map(),
                segmentCount: 0,
                recoveringCount: 0,
                abnormalCount: 0,
                distribution: new Map(),
                statusCounts: new Map(),
                managerAddresses: new Set(),
            });
        }

        const row = grouped.get(clusterId);
        row.segmentIds.add(segment.segment_id);
        row.segmentCount += 1;
        if (!row.segmentReplicaCounts.has(segment.segment_id)) {
            row.segmentReplicaCounts.set(segment.segment_id, 0);
        }
        if (segment.in_recovery === false) {
            row.segmentReplicaCounts.set(segment.segment_id, row.segmentReplicaCounts.get(segment.segment_id) + 1);
        }
        if (segment.in_recovery === true) {
            row.recoveringCount += 1;
        }
        if (segment.init_lsn_ok !== true || segment.init_flag !== 'InitSucc') {
            row.abnormalCount += 1;
        }

        const segmentStatus = displayValue(segment.segment_status) || '未知';
        row.statusCounts.set(segmentStatus, (row.statusCounts.get(segmentStatus) || 0) + 1);
        if (segment.manager_address) {
            row.managerAddresses.add(segment.manager_address);
        }

        const distributionKey = `${displayValue(segment.serverAddr)}:${displayValue(segment.store_id)}`;
        row.distribution.set(distributionKey, (row.distribution.get(distributionKey) || 0) + 1);
    });

    return [...grouped.values()].map((row) => ({
        ...row,
        uniqueSegmentCount: row.segmentIds.size,
        singleReplicaCount: [...row.segmentReplicaCounts.values()].filter((count) => count === 1).length,
        singleReplicaSegmentIds: [...row.segmentReplicaCounts.entries()]
            .filter(([, count]) => count === 1)
            .map(([segmentId]) => segmentId)
            .sort((a, b) => String(a).localeCompare(String(b), 'zh-CN', { numeric: true })),
        distributionEntries: [...row.distribution.entries()]
            .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], 'zh-CN', { numeric: true })),
        distributionText: [...row.distribution.entries()]
            .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], 'zh-CN', { numeric: true }))
            .map(([key, count]) => `${key}: ${count}`)
            .join('；'),
        statusEntries: [...row.statusCounts.entries()]
            .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], 'zh-CN', { numeric: true })),
    }));
}

function getSegmentStatusColumns(rows) {
    const totals = new Map();
    rows.forEach((row) => {
        (row.statusEntries || []).forEach(([status, count]) => {
            totals.set(status, (totals.get(status) || 0) + count);
        });
    });
    return [...totals.entries()]
        .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], 'zh-CN', { numeric: true }))
        .map(([status]) => status);
}

function getSegmentSortValue(row, key) {
    if (key.startsWith('status:')) {
        const status = key.slice('status:'.length);
        return row.statusCounts ? (row.statusCounts.get(status) || 0) : 0;
    }

    const value = row[key];
    if ([
        'uniqueSegmentCount',
        'segmentCount',
        'usedExtentNum',
        'recyclingExtentNum',
        'recoveringCount',
        'abnormalCount',
        'singleReplicaCount',
    ].includes(key)) {
        return toNumber(value) ?? Number.NEGATIVE_INFINITY;
    }
    return String(value ?? '').toLowerCase();
}

function sortSegmentRows(rows) {
    const direction = segmentSortState.direction === 'asc' ? 1 : -1;
    return [...rows].sort((a, b) => {
        const aValue = getSegmentSortValue(a, segmentSortState.key);
        const bValue = getSegmentSortValue(b, segmentSortState.key);
        if (typeof aValue === 'number' && typeof bValue === 'number') {
            return (aValue - bValue) * direction
                || String(a.clusterId).localeCompare(String(b.clusterId), 'zh-CN', { numeric: true });
        }
        return String(aValue).localeCompare(String(bValue), 'zh-CN', { numeric: true }) * direction
            || String(a.clusterId).localeCompare(String(b.clusterId), 'zh-CN', { numeric: true });
    });
}

function getSortMark(state, key) {
    if (state.key !== key) {
        return '↕';
    }
    return state.direction === 'asc' ? '↑' : '↓';
}

function renderSegmentSortButton(key, label, className = '') {
    const active = segmentSortState.key === key ? 'active' : '';
    return `
        <button
            class="sort-button ${className} ${active}"
            type="button"
            title="${escapeHtml(label)}"
            data-segment-sort-key="${escapeHtml(key)}"
        >
            <span>${escapeHtml(label)}</span>
            <span class="sort-mark">${getSortMark(segmentSortState, key)}</span>
        </button>
    `;
}

function normalizeRecoveryRows(data) {
    const rows = [];

    function walk(value, context = {}) {
        if (Array.isArray(value)) {
            value.forEach((item) => walk(item, context));
            return;
        }

        if (!value || typeof value !== 'object') {
            return;
        }

        const node = pick(value, [
            'addr',
            'address',
            'node',
            'node_name',
            'nodeName',
            'host',
            'hostname',
            'ip',
            'server',
            'server_addr',
            'serverAddr',
        ]) || context.node;
        const clusterId = pick(value, ['cluster_id', 'clusterId']);
        const segmentId = pick(value, ['segment_id', 'segmentId']);
        const recoverySize = pick(value, ['recovery_size', 'recoverySize']);

        if (clusterId !== '' && segmentId !== '' && recoverySize !== '') {
            rows.push({
                node: node || '-',
                clusterId,
                segmentId,
                storeId: pick(value, ['store_id', 'storeId']),
                segmentSize: pick(value, ['segment_size', 'segmentSize']),
                priorNum: pick(value, ['prior_num', 'priorNum']),
                isRunning: pick(value, ['is_running', 'isRunning']),
                recoverySize,
                paiallelTaskCount: pick(value, [
                    'paiallel_task_count',
                    'paiallelTaskCount',
                ]),
                finishRate: pick(value, ['finish_rate', 'finishRate']),
            });
            return;
        }

        Object.values(value).forEach((child) => {
            walk(child, { ...context, node: node || context.node });
        });
    }

    walk(data);
    return rows;
}

function getDiskMatchKey(node, storeId) {
    return `${getNodeEndpoint(node)}::${String(storeId)}`;
}

function enrichRecoveryRowsWithDiskInfo(recoveryRows, diskRows) {
    const diskMap = new Map();
    diskRows.forEach((row) => {
        diskMap.set(getDiskMatchKey(row.node, row.storeId), row);
    });

    recoveryRows.forEach((row) => {
        const disk = diskMap.get(getDiskMatchKey(row.node, row.storeId));
        row.zone = disk ? disk.zone : '';
        row.physicalUsage = disk ? disk.physicalUsage : null;
    });
}

function getMaxNodeExpectFinishTime(rows) {
    const nodeTimes = new Map();
    rows.forEach((row) => {
        const endpoint = getNodeEndpoint(row.node);
        const expectFinishTime = toNumber(row.expectFinishTime);
        if (!endpoint || expectFinishTime === null || nodeTimes.has(endpoint)) {
            return;
        }
        nodeTimes.set(endpoint, expectFinishTime);
    });

    if (!nodeTimes.size) {
        return null;
    }
    if ([...nodeTimes.values()].includes(-1)) {
        return -1;
    }
    return Math.max(...nodeTimes.values());
}

function summarizeRecoveryRows(rows) {
    const runningCount = rows.filter((row) => row.isRunning === true).length;
    const pendingCount = rows.filter((row) => row.isRunning !== true).length;
    const totalSize = rows.reduce((sum, row) => sum + (toNumber(row.segmentSize) || 0), 0);
    const recoveredSize = rows.reduce((sum, row) => sum + (toNumber(row.recoverySize) || 0), 0);
    return {
        recoveringCount: rows.length,
        runningCount,
        pendingCount,
        totalSize,
        recoveredSize,
        maxExpectFinishTime: getMaxNodeExpectFinishTime(rows),
    };
}

function getRecoveryRateValue(row) {
    const segmentSize = toNumber(row.segmentSize);
    const recoverySize = toNumber(row.recoverySize);
    if (segmentSize !== null && segmentSize > 0 && recoverySize !== null) {
        return (recoverySize / segmentSize) * 100;
    }

    return toNumber(row.finishRate);
}

function getRecoverySortValue(row, key) {
    if (key === 'node') {
        return getNodeEndpoint(row.node).toLowerCase();
    }
    if (key === 'finishRate') {
        return getRecoveryRateValue(row) ?? Number.NEGATIVE_INFINITY;
    }
    const value = row[key];
    const numericKeys = [
        'segmentId',
        'storeId',
        'segmentSize',
        'priorNum',
        'recoverySize',
        'paiallelTaskCount',
        'physicalUsage',
        'totalRecoverSize',
        'expectFinishTime',
        'recoverDstStoreMaxSpeed',
        'recoverSrcStoreMaxSpeed',
        'recoverReadStoreMaxSpeed',
    ];
    if (numericKeys.includes(key)) {
        return toNumber(value) ?? Number.NEGATIVE_INFINITY;
    }
    if (key === 'isRunning') {
        return value === true ? 1 : value === false ? 0 : -1;
    }
    return String(value ?? '').toLowerCase();
}

function sortRecoveryRows(rows) {
    const direction = recoverySortState.direction === 'asc' ? 1 : -1;
    return [...rows].sort((a, b) => {
        const aValue = getRecoverySortValue(a, recoverySortState.key);
        const bValue = getRecoverySortValue(b, recoverySortState.key);
        if (typeof aValue === 'number' && typeof bValue === 'number') {
            return (aValue - bValue) * direction;
        }
        return String(aValue).localeCompare(String(bValue), 'zh-CN', { numeric: true }) * direction;
    });
}

function renderRecoverySortButton(key, label) {
    const active = recoverySortState.key === key ? 'active' : '';
    return `
        <button
            class="sort-button ${active}"
            type="button"
            data-recovery-sort-key="${escapeHtml(key)}"
        >
            <span>${escapeHtml(label)}</span>
            <span class="sort-mark">${getSortMark(recoverySortState, key)}</span>
        </button>
    `;
}

function formatRecoveryRate(value, row = {}) {
    const number = getRecoveryRateValue({ ...row, finishRate: value });
    if (number === null) {
        return '-';
    }

    return `${number.toFixed(2)}%`;
}

function formatDurationSeconds(value) {
    const seconds = toNumber(value);
    if (seconds === null) {
        return '-';
    }
    if (seconds === -1) {
        return '-1';
    }
    if (seconds < 60) {
        return `${seconds.toFixed(0)} 秒`;
    }
    if (seconds < 3600) {
        return `${(seconds / 60).toFixed(1)} 分钟`;
    }
    if (seconds < 86400) {
        return `${(seconds / 3600).toFixed(1)} 小时`;
    }
    return `${(seconds / 86400).toFixed(1)} 天`;
}

function renderRecoveryRefreshButton() {
    return `
        <button
            id="refreshRecoveryButton"
            class="summary-icon-button"
            type="button"
            title="刷新恢复"
            aria-label="刷新恢复"
        >
            <span aria-hidden="true">↻</span>
        </button>
    `;
}

function setRecoveryRefreshDisabled(disabled) {
    const button = document.querySelector('#refreshRecoveryButton');
    if (button) {
        button.disabled = disabled;
    }
}

function filterRecoveryRows(rows) {
    const nodeKeyword = recoveryNodeFilterText.trim().toLowerCase();
    const clusterKeyword = recoveryClusterFilterText.trim().toLowerCase();
    return rows.filter((row) => {
        const nodeMatched = isNodePrefixMatched(row.node, nodeKeyword);
        const clusterMatched = !clusterKeyword || String(row.clusterId).toLowerCase().includes(clusterKeyword);
        return nodeMatched && clusterMatched;
    });
}

async function loadRecoveryVars(rows) {
    const targets = rows
        .map((row) => getNodeEndpoint(row.node))
        .filter((target) => /:\d+$/.test(target));
    if (!targets.length) {
        return;
    }

    const response = await fetch('/api/recovery-vars', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targets }),
    });
    const payload = await response.json();
    if (!response.ok) {
        throw new Error(payload.error || '恢复变量加载失败');
    }

    const varsMap = new Map((payload.vars || []).map((item) => [item.target, item.vars]));
    rows.forEach((row) => {
        const vars = varsMap.get(getNodeEndpoint(row.node)) || {};
        row.totalRecoverSize = vars.psvr_recover_left_size;
        row.expectFinishTime = vars.psvr_recover_expect_finish_time_s;
        row.recoverDstStoreMaxSpeed = vars.psvr_recover_dst_store_max_speed;
        row.recoverSrcStoreMaxSpeed = vars.psvr_recover_src_store_max_speed;
        row.recoverReadStoreMaxSpeed = vars.psvr_recover_read_store_max_speed;
    });
}

function renderRecovery() {
    const rows = sortRecoveryRows(filterRecoveryRows(currentRecoveryRows));
    const summary = summarizeRecoveryRows(rows);
    const displayedNodeMetrics = new Set();
    const body = rows.length ? rows.map((row) => {
        const endpoint = getNodeEndpoint(row.node);
        const showNodeMetrics = !displayedNodeMetrics.has(endpoint);
        displayedNodeMetrics.add(endpoint);
        const totalRecoverSize = showNodeMetrics ? formatBytes(row.totalRecoverSize) : '';
        const expectFinishTime = showNodeMetrics
            ? formatDurationSeconds(row.expectFinishTime)
            : '';
        const recoverDstStoreMaxSpeed = showNodeMetrics
            ? formatBytesPerSecond(row.recoverDstStoreMaxSpeed)
            : '';
        const recoverSrcStoreMaxSpeed = showNodeMetrics
            ? formatBytesPerSecond(row.recoverSrcStoreMaxSpeed)
            : '';
        const recoverReadStoreMaxSpeed = showNodeMetrics
            ? formatBytesPerSecond(row.recoverReadStoreMaxSpeed)
            : '';
        return `
            <tr>
                <td title="${escapeHtml(displayValue(row.node))}">${renderNodeProxyLink(row.node)}</td>
                <td>${escapeHtml(displayZone(row.zone))}</td>
                <td>${escapeHtml(displayValue(row.storeId))}</td>
                <td>${escapeHtml(formatPercent(row.physicalUsage))}</td>
                <td>${escapeHtml(displayValue(row.clusterId))}</td>
                <td>${escapeHtml(displayValue(row.segmentId))}</td>
                <td>${escapeHtml(formatBytes(row.segmentSize))}</td>
                <td>${escapeHtml(displayValue(row.priorNum))}</td>
                <td>${escapeHtml(formatBool(row.isRunning))}</td>
                <td>${escapeHtml(formatBytes(row.recoverySize))}</td>
                <td>${escapeHtml(displayValue(row.paiallelTaskCount))}</td>
                <td>${escapeHtml(formatRecoveryRate(row.finishRate, row))}</td>
                <td>${escapeHtml(totalRecoverSize)}</td>
                <td>${escapeHtml(expectFinishTime)}</td>
                <td>${escapeHtml(recoverDstStoreMaxSpeed)}</td>
                <td>${escapeHtml(recoverSrcStoreMaxSpeed)}</td>
                <td>${escapeHtml(recoverReadStoreMaxSpeed)}</td>
            </tr>
        `;
    }).join('') : '<tr><td colspan="17" class="empty-table-cell">没有恢复信息</td></tr>';

    recoverySummary.innerHTML = `
        <div><span>当前恢复中</span><strong>${summary.recoveringCount}</strong></div>
        <div><span>运行中</span><strong>${summary.runningCount}</strong></div>
        <div><span>待运行</span><strong>${summary.pendingCount}</strong></div>
        <div><span>待恢复数据</span><strong>${formatBytes(summary.totalSize)}</strong></div>
        <div><span>已恢复数据</span><strong>${formatBytes(summary.recoveredSize)}</strong></div>
        <div>
            <span>预计耗时</span>
            <div class="summary-action-row">
                <strong>${formatDurationSeconds(summary.maxExpectFinishTime)}</strong>
                ${renderRecoveryRefreshButton()}
            </div>
        </div>
    `;

    recoveryContent.innerHTML = `
        <table class="recovery-table">
            <thead>
                <tr>
                    <th>${renderRecoverySortButton('node', '节点信息')}</th>
                    <th>${renderRecoverySortButton('zone', 'Zone')}</th>
                    <th>${renderRecoverySortButton('storeId', '磁盘ID')}</th>
                    <th>${renderRecoverySortButton('physicalUsage', '物理使用率')}</th>
                    <th>${renderRecoverySortButton('clusterId', '集群名')}</th>
                    <th>${renderRecoverySortButton('segmentId', '分片ID')}</th>
                    <th>${renderRecoverySortButton('segmentSize', '数据大小')}</th>
                    <th>${renderRecoverySortButton('priorNum', '优先级')}</th>
                    <th>${renderRecoverySortButton('isRunning', '运行')}</th>
                    <th>${renderRecoverySortButton('recoverySize', '已完成')}</th>
                    <th>${renderRecoverySortButton('paiallelTaskCount', '并发数')}</th>
                    <th>${renderRecoverySortButton('finishRate', '进度')}</th>
                    <th>${renderRecoverySortButton('totalRecoverSize', '总剩余量')}</th>
                    <th>${renderRecoverySortButton('expectFinishTime', '预计耗时')}</th>
                    <th>${renderRecoverySortButton('recoverDstStoreMaxSpeed', '恢复限速')}</th>
                    <th>${renderRecoverySortButton('recoverSrcStoreMaxSpeed', '恢复源限速')}</th>
                    <th>${renderRecoverySortButton('recoverReadStoreMaxSpeed', '备份限速')}</th>
                </tr>
            </thead>
            <tbody>${body}</tbody>
        </table>
    `;
}

function isActiveDisk(row) {
    return row.active === true || row.active === 'true' || row.active === 1 || row.active === '1';
}

function getActiveDiskCount(rows) {
    return rows.filter((row) => isActiveDisk(row)).length;
}

function renderPoolCapacity(poolCapacity) {
    const usedExtentNum = toNumber(poolCapacity && poolCapacity.usedExtentNum);
    const recyclingExtentNum = toNumber(poolCapacity && poolCapacity.recyclingExtentNum);
    const activeDiskCount = getActiveDiskCount(currentRows);
    const minBackupSpeed = usedExtentNum !== null && activeDiskCount > 0
        ? usedExtentNum / activeDiskCount / 86400
        : null;
    const errors = poolCapacity && Array.isArray(poolCapacity.errors) ? poolCapacity.errors : [];
    const title = [
        `manager 数: ${poolCapacity && poolCapacity.managerCount ? poolCapacity.managerCount : 0}`,
        `启用磁盘数: ${activeDiskCount}`,
        '最小备份速率 = 总分配容量 / 启用磁盘数 / 86400',
        ...errors.map((item) => `${item.manager}: ${item.error}`),
    ].join('\n');
    const hasErrors = errors.length > 0;

    poolAllocatedCapacity.textContent = hasErrors ? '异常' : formatMegabytes(usedExtentNum);
    poolAllocatedCapacity.title = title;
    poolAllocatedCapacity.classList.toggle('metric-error', hasErrors);
    poolRecyclingCapacity.textContent = hasErrors ? '异常' : formatMegabytes(recyclingExtentNum);
    poolRecyclingCapacity.title = title;
    poolRecyclingCapacity.classList.toggle('metric-error', hasErrors);
    poolMinBackupSpeed.textContent = hasErrors ? '异常' : formatMegabytesPerSecond(minBackupSpeed);
    poolMinBackupSpeed.title = title;
    poolMinBackupSpeed.classList.toggle('metric-error', hasErrors);
}

function resetPoolCapacity(text = '-') {
    poolAllocatedCapacity.textContent = text;
    poolAllocatedCapacity.title = '';
    poolRecyclingCapacity.textContent = text;
    poolRecyclingCapacity.title = '';
    poolMinBackupSpeed.textContent = text;
    poolMinBackupSpeed.title = '';
    segmentPhysicalSize.textContent = text;
    segmentPhysicalSize.title = '';
    ibdActualUsageRate.textContent = text;
    ibdActualUsageRate.title = '';
    appendDbSize.textContent = text;
    appendDbSize.title = '';
    [poolAllocatedCapacity, poolRecyclingCapacity, poolMinBackupSpeed, ibdActualUsageRate]
        .forEach((element) => element.classList.remove('metric-error'));
}

function enrichSegmentRowsWithExtentStats(rows, poolCapacity) {
    const statsByManager = new Map(
        (poolCapacity && Array.isArray(poolCapacity.managerStats) ? poolCapacity.managerStats : [])
            .map((item) => [item.manager, item]),
    );

    rows.forEach((row) => {
        const stats = [...row.managerAddresses]
            .map((manager) => statsByManager.get(manager))
            .filter(Boolean);
        [
            ['usedExtentNum', 'hasUsedExtentNum'],
            ['recyclingExtentNum', 'hasRecyclingExtentNum'],
        ].forEach(([key, presenceKey]) => {
            const fieldExists = stats.length && stats.every((item) => item[presenceKey] === true);
            row[key] = fieldExists ? stats.reduce((sum, item) => sum + item[key], 0) : null;
        });
    });
}

function renderSegmentPhysicalSizes(text, poolCapacity) {
    const segments = parseSegmentPb(text);
    const physicalSize = segments.reduce(
        (sum, segment) => sum + (toNumber(segment.segment_physical_size) || 0),
        0,
    );
    const appendSize = segments.reduce(
        (sum, segment) => sum + (toNumber(segment.append_db_size) || 0),
        0,
    );
    const usedExtentNum = toNumber(poolCapacity && poolCapacity.usedExtentNum);
    const capacityErrors = Array.isArray(poolCapacity && poolCapacity.errors)
        ? poolCapacity.errors
        : [];
    const hasCapacityErrors = capacityErrors.length > 0;
    const allocatedBytes = usedExtentNum === null ? null : usedExtentNum * 1024 * 1024;
    const actualUsageRate = !hasCapacityErrors && allocatedBytes !== null && physicalSize > 0
        ? allocatedBytes * 3 / physicalSize
        : null;
    const title = `统计 segment 数量 = ${segments.length}`;
    const rateTitle = [
        'IBD 逻辑/物理比 = 总分配容量 × 3 / IBD 物理占用',
        `总分配容量 × 3 = ${allocatedBytes === null ? '-' : formatBytes(allocatedBytes * 3)}`,
        `IBD 物理占用 = ${formatBytes(physicalSize)}`,
        ...capacityErrors.map((item) => `${item.manager}: ${item.error}`),
    ].join('\n');

    segmentPhysicalSize.textContent = formatBytes(physicalSize);
    segmentPhysicalSize.title = title;
    ibdActualUsageRate.textContent = hasCapacityErrors ? '异常' : formatPercent(actualUsageRate);
    ibdActualUsageRate.title = rateTitle;
    ibdActualUsageRate.classList.toggle('metric-error', hasCapacityErrors);
    appendDbSize.textContent = formatBytes(appendSize);
    appendDbSize.title = title;
}

async function loadDisableNodeDiff(cluster) {
    try {
        const response = await fetch(`/api/instance-count?cluster=${encodeURIComponent(cluster)}`);
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(payload.stderr || payload.error || 'disable 数量加载失败');
        }

        const nodeTotal = getNodeCount(currentRows);
        const instanceCount = toNumber(payload.count);
        const diff = instanceCount === null ? 0 : instanceCount - nodeTotal;
        disableNodeDiffCount.hidden = false;
        disableNodeDiffCount.textContent = `disable ${diff}`;
        disableNodeDiffCount.title = [
            `get_instance_by_service ${cluster} -a | awk '{print $2}'`,
            `数量 = ${instanceCount ?? '-'}`,
            `节点数量 = ${nodeTotal}`,
        ].join('\n');
        disableNodeDiffCount.classList.toggle('active', diff !== 0);
    } catch (_) {
        disableNodeDiffCount.hidden = true;
        disableNodeDiffCount.classList.remove('active');
    }
}

function renderSegments() {
    const keyword = segmentSearch.value.trim().toLowerCase();
    const rows = sortSegmentRows(currentSegmentRows.filter((row) => row.clusterId.toLowerCase().includes(keyword)));
    const statusColumns = getSegmentStatusColumns(rows);

    if (!rows.length) {
        segmentContent.innerHTML = '<div class="empty-state">没有匹配的分片信息</div>';
        return;
    }

    segmentContent.innerHTML = `
        <table class="segment-table">
            <thead>
                <tr>
                    <th>${renderSegmentSortButton('clusterId', '集群名')}</th>
                    <th>${renderSegmentSortButton('uniqueSegmentCount', '分片ID个数')}</th>
                    <th>${renderSegmentSortButton('segmentCount', '分片数量')}</th>
                    <th>${renderSegmentSortButton('usedExtentNum', '逻辑容量')}</th>
                    <th>${renderSegmentSortButton('recyclingExtentNum', '待回收容量')}</th>
                    <th>${renderSegmentSortButton('recoveringCount', '恢复中数量')}</th>
                    <th>${renderSegmentSortButton('abnormalCount', '异常数量')}</th>
                    <th>${renderSegmentSortButton('singleReplicaCount', '1副本个数')}</th>
                    ${statusColumns.map((status) => `
                        <th class="segment-status-col">
                            ${renderSegmentSortButton(`status:${status}`, status, 'segment-status-sort-button')}
                        </th>
                    `).join('')}
                    <th class="segment-distribution-col">
                        分布信息
                        <span class="column-note">ip:port:磁盘ID:副本个数</span>
                    </th>
                </tr>
            </thead>
            <tbody>
                ${rows.map((row) => {
                    const statusCountMap = new Map(row.statusEntries || []);
                    return `
                    <tr>
                        <td>${escapeHtml(row.clusterId)}</td>
                        <td>${row.uniqueSegmentCount}</td>
                        <td>${row.segmentCount}</td>
                        <td>${escapeHtml(formatMegabytes(row.usedExtentNum))}</td>
                        <td>${escapeHtml(formatMegabytes(row.recyclingExtentNum))}</td>
                        <td>${row.recoveringCount}</td>
                        <td>${row.abnormalCount}</td>
                        <td>
                            <details class="segment-replica-details">
                                <summary>${row.singleReplicaCount}</summary>
                                <div>${(row.singleReplicaSegmentIds || []).length
                                    ? row.singleReplicaSegmentIds.map((segmentId) => escapeHtml(segmentId)).join('；')
                                    : '-'}</div>
                            </details>
                        </td>
                        ${statusColumns.map((status) => `
                            <td class="segment-status-col">${statusCountMap.get(status) || 0}</td>
                        `).join('')}
                        <td class="segment-distribution-col">
                            <details class="distribution-details">
                                <summary>${row.distribution.size} 项分布</summary>
                                <div>${row.distributionEntries
                                    .map(([key, count]) => `${renderDistributionKey(key)}: ${count}`)
                                    .join('；')}</div>
                            </details>
                        </td>
                    </tr>
                `;
                }).join('')}
            </tbody>
        </table>
    `;
}

function filterRowsByZone(rows) {
    if (['all', 'version', 'capacity'].includes(selectedZone)) {
        return rows;
    }
    if (selectedZone === 'offline') {
        return rows.filter((row) => isOfflineMachine(row.toOffline));
    }
    return rows.filter((row) => row.zone === selectedZone);
}

function filterRowsByNode(rows) {
    const keyword = nodeFilterText.trim().toLowerCase();
    if (!keyword) {
        return rows;
    }
    return rows.filter((row) => isNodePrefixMatched(row.node, keyword));
}

function isNodePrefixMatched(node, keyword) {
    return !keyword || String(node).toLowerCase().startsWith(keyword);
}

function filterDiskRows(rows) {
    return filterRowsByNode(filterRowsByZone(rows));
}

function getDiskSortColumn(key) {
    const diskColumns = [zoneColumn, ...columns];
    for (const column of diskColumns) {
        if (column.key === key) {
            return column;
        }
        const sortKey = (column.sortKeys || []).find((item) => item.key === key);
        if (sortKey) {
            return { ...sortKey, type: 'number' };
        }
    }
    return columns[0];
}

function getSortValue(row, column) {
    if (column.key === 'zone') {
        return zoneSortValue(row.zone);
    }

    const value = row[column.key];
    if (column.type === 'number' || column.type === 'boolean') {
        const number = toNumber(value);
        return number === null ? Number.NEGATIVE_INFINITY : number;
    }
    return String(value ?? '').toLowerCase();
}

function sortRows(rows) {
    const column = getDiskSortColumn(sortState.key);
    const direction = sortState.direction === 'asc' ? 1 : -1;
    return [...rows].sort((a, b) => {
        const aValue = getSortValue(a, column);
        const bValue = getSortValue(b, column);
        if (typeof aValue === 'number' && typeof bValue === 'number') {
            return (aValue - bValue) * direction;
        }
        return String(aValue).localeCompare(String(bValue), 'zh-CN', { numeric: true }) * direction;
    });
}

function getNodeEndpoint(node) {
    const match = String(node || '').match(/(?:\d{1,3}\.){3}\d{1,3}:\d+/);
    return match ? match[0] : String(node || '');
}

function getNodeEndpointFromDistributionKey(key) {
    const match = String(key || '').match(/^((?:\d{1,3}\.){3}\d{1,3}:\d+):/);
    return match ? match[1] : '';
}

function getNodeIp(node) {
    const endpoint = getNodeEndpoint(node);
    return endpoint.replace(/:\d+$/, '');
}

function renderNodeProxyLink(node, label = '') {
    const endpoint = getNodeEndpoint(node);
    const proxy = proxyMap.get(endpoint);
    const text = label || endpoint || '-';
    if (!proxy) {
        return escapeHtml(text);
    }
    return `
        <a
            class="proxy-link"
            href="${escapeHtml(proxy.url)}"
            target="_blank"
            rel="noreferrer"
            title="${escapeHtml(endpoint)} -> ${escapeHtml(proxy.url)}"
        >${escapeHtml(text)}</a>
    `;
}

function renderDiskNodeCell(row) {
    const ip = getNodeIp(row.node);
    const canCopy = ip && ip !== '-';
    return `
        <div class="node-cell">
            <span>${renderNodeProxyLink(row.node)}</span>
            <button
                class="copy-button node-copy-button"
                type="button"
                data-copy-ip="${escapeHtml(ip)}"
                aria-label="复制节点 IP ${escapeHtml(ip)}"
                title="复制节点 IP"
                ${canCopy ? '' : 'disabled'}
            >复制</button>
        </div>
    `;
}

function renderDistributionKey(key) {
    const endpoint = getNodeEndpointFromDistributionKey(key);
    if (!endpoint) {
        return escapeHtml(key);
    }
    return `${renderNodeProxyLink(endpoint)}${escapeHtml(String(key).slice(endpoint.length))}`;
}

function compareNodesByZoneAndIp(a, b) {
    const zoneCompare = zoneSortValue(a.zone) - zoneSortValue(b.zone)
        || String(a.zone).localeCompare(String(b.zone), 'zh-CN', { numeric: true });
    if (zoneCompare) {
        return zoneCompare;
    }
    return getNodeIp(a.node).localeCompare(getNodeIp(b.node), 'zh-CN', { numeric: true });
}

function getTopologySortValue(row, key) {
    if (key === 'zone') {
        return zoneSortValue(row.zone);
    }
    if (key === 'ip') {
        return getNodeIp(row.node);
    }
    if (key === 'toOffline') {
        return row.toOffline === true ? 1 : row.toOffline === false ? 0 : -1;
    }
    if (key === 'pkgVersion') {
        return displayValue(row.pkgVersion);
    }
    if (key === 'gitCommit') {
        return formatCommit(row.gitCommit);
    }
    if (key === 'diskCount') {
        return row.diskCount;
    }
    if (key === 'shardCount') {
        return row.shardCount;
    }
    return '';
}

function sortTopologyRows(rows) {
    const direction = topologySortState.direction === 'asc' ? 1 : -1;
    return [...rows].sort((a, b) => {
        if (topologySortState.key === 'zone') {
            const baseCompare = compareNodesByZoneAndIp(a, b);
            return baseCompare * direction;
        }

        const aValue = getTopologySortValue(a, topologySortState.key);
        const bValue = getTopologySortValue(b, topologySortState.key);
        if (typeof aValue === 'number' && typeof bValue === 'number') {
            return (aValue - bValue) * direction;
        }
        return String(aValue).localeCompare(String(bValue), 'zh-CN', { numeric: true }) * direction;
    });
}

function renderTopologySortButton(key, label) {
    const active = topologySortState.key === key ? 'active' : '';
    return `
        <button
            class="sort-button ${active}"
            type="button"
            data-topology-sort-key="${escapeHtml(key)}"
        >
            <span>${escapeHtml(label)}</span>
            <span class="sort-mark">${getSortMark(topologySortState, key)}</span>
        </button>
    `;
}

function comparePhysicalUsage(a, b) {
    const aValue = toNumber(a.physicalUsage);
    const bValue = toNumber(b.physicalUsage);
    if (aValue === null && bValue === null) {
        return 0;
    }
    if (aValue === null) {
        return 1;
    }
    if (bValue === null) {
        return -1;
    }
    return aValue - bValue;
}

function getDiskIdentity(row) {
    return `${displayValue(row.node)} + ${displayValue(row.storeId)}`;
}

function formatDiskWithUsage(row) {
    return row ? `${getDiskIdentity(row)} (${formatPercent(row.physicalUsage)})` : '-';
}

function formatCapacityDiskCell(row) {
    return formatDiskWithUsage(row);
}

function renderCapacityDiskCell(row) {
    if (!row) {
        return '-';
    }
    return [
        renderNodeProxyLink(row.node),
        `+ ${escapeHtml(displayValue(row.storeId))}`,
        `(${escapeHtml(formatPercent(row.physicalUsage))})`,
    ].join(' ');
}

function getZoneCapacityRows(rows) {
    const zoneMap = new Map();
    rows.forEach((row) => {
        const zone = row.zone || 'unknown';
        if (!zoneMap.has(zone)) {
            zoneMap.set(zone, {
                zone,
                capacity: { total: 0, used: 0 },
                highestDisk: null,
                lowestDisk: null,
            });
        }

        const zoneRow = zoneMap.get(zone);
        zoneRow.capacity.total += toNumber(row.physicalStoreSize) || 0;
        zoneRow.capacity.used += toNumber(row.physicalUsedSize) || 0;
        if (!zoneRow.highestDisk || comparePhysicalUsage(row, zoneRow.highestDisk) > 0) {
            zoneRow.highestDisk = row;
        }
        if (!zoneRow.lowestDisk || comparePhysicalUsage(row, zoneRow.lowestDisk) < 0) {
            zoneRow.lowestDisk = row;
        }
    });

    return [...zoneMap.values()].sort((a, b) => zoneSortValue(a.zone) - zoneSortValue(b.zone)
        || String(a.zone).localeCompare(String(b.zone), 'zh-CN', { numeric: true }));
}

function getNodesForZone(rows) {
    const filtered = filterRowsByZone(rows);
    const nodeMap = new Map();
    filtered.forEach((row) => {
        const key = row.node || '-';
        if (!nodeMap.has(key)) {
            nodeMap.set(key, {
                node: key,
                zone: row.zone,
                toOffline: row.toOffline,
                pkgVersion: row.pkgVersion,
                gitCommit: row.gitCommit,
                diskCount: 0,
                shardCount: 0,
            });
        }
        const nodeRow = nodeMap.get(key);
        nodeRow.diskCount += 1;
        nodeRow.shardCount += toNumber(row.usedCapacity) || 0;
    });
    return sortTopologyRows([...nodeMap.values()]);
}

function getNodeCount(rows) {
    return new Set(rows.map((row) => row.node).filter((node) => node && node !== '-')).size;
}

function getZoneTabLabel(zone) {
    if (zone === 'all') {
        return '全部';
    }
    if (zone === 'version') {
        return '版本信息';
    }
    if (zone === 'capacity') {
        return '容量';
    }
    if (zone === 'offline') {
        return '下线';
    }
    return displayZone(zone);
}

function renderZoneTabs(rows) {
    const zones = [...new Set(rows.map((row) => row.zone || 'unknown'))]
        .sort((a, b) => {
            const order = zoneSortValue(a) - zoneSortValue(b);
            if (order) {
                return order;
            }
            return String(a).localeCompare(String(b), 'zh-CN', { numeric: true });
        });
    const tabs = ['all', ...zones, 'offline', 'version', 'capacity'];

    if (!tabs.includes(selectedZone)) {
        selectedZone = 'all';
    }

    zoneTabs.innerHTML = tabs.map((zone) => {
        const zoneRows = zone === 'all'
            ? rows
            : zone === 'offline'
                ? rows.filter((row) => isOfflineMachine(row.toOffline))
                : rows.filter((row) => row.zone === zone);
        let count = zoneRows.length;
        if (zone === 'version') {
            count = getNodeCount(rows);
        } else if (zone === 'capacity') {
            count = zones.length;
        } else if (zone === 'offline') {
            count = getNodeCount(zoneRows);
        } else if (zone === 'all') {
            count = rows.length;
        }
        const label = getZoneTabLabel(zone);
        const active = zone === selectedZone ? 'active' : '';
        return `
            <button
                class="zone-tab ${active}"
                type="button"
                data-zone="${escapeHtml(zone)}"
            >
                <span>${escapeHtml(label)}</span>
                <span class="tab-count">${count}</span>
            </button>
        `;
    }).join('');
}

function renderCapacityInfo(rows) {
    const zoneCapacityRows = getZoneCapacityRows(rows);

    if (!zoneCapacityRows.length) {
        topologyInfo.innerHTML = '<div class="topology-empty">当前集群没有容量信息</div>';
        return;
    }

    topologyInfo.innerHTML = `
        <table class="capacity-table">
            <thead>
                <tr>
                    <th>zone</th>
                    <th>磁盘上限 / 使用 / 剩余</th>
                    <th>最高磁盘</th>
                    <th>最低磁盘</th>
                </tr>
            </thead>
            <tbody>
                ${zoneCapacityRows.map((row) => `
                    <tr>
                        <td>${escapeHtml(displayZone(row.zone))}</td>
                        <td>${escapeHtml(formatCapacitySummary(row.capacity))}</td>
                        <td title="${escapeHtml(formatCapacityDiskCell(row.highestDisk))}">
                            ${renderCapacityDiskCell(row.highestDisk)}
                        </td>
                        <td title="${escapeHtml(formatCapacityDiskCell(row.lowestDisk))}">
                            ${renderCapacityDiskCell(row.lowestDisk)}
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

function renderTopologyInfo(rows) {
    const nodeRows = getNodesForZone(rows);

    if (!nodeRows.length) {
        topologyInfo.innerHTML = '<div class="topology-empty">当前分区没有版本信息</div>';
        return;
    }

    topologyInfo.innerHTML = `
        <table class="topology-table">
            <thead>
                <tr>
                    <th>${renderTopologySortButton('zone', 'Zone')}</th>
                    <th>${renderTopologySortButton('ip', 'IP')}</th>
                    <th>${renderTopologySortButton('toOffline', '预下线')}</th>
                    <th>${renderTopologySortButton('pkgVersion', '版本')}</th>
                    <th>${renderTopologySortButton('gitCommit', 'Commit')}</th>
                    <th>${renderTopologySortButton('diskCount', '磁盘')}</th>
                    <th>${renderTopologySortButton('shardCount', '分片数量')}</th>
                </tr>
            </thead>
            <tbody>
                ${nodeRows.map((row) => `
                    <tr>
                        <td>${escapeHtml(displayZone(row.zone))}</td>
                        <td title="${escapeHtml(row.node)}">${renderNodeProxyLink(row.node)}</td>
                        <td>${escapeHtml(formatBool(row.toOffline))}</td>
                        <td title="${escapeHtml(displayValue(row.pkgVersion))}">
                            ${escapeHtml(displayValue(row.pkgVersion))}
                        </td>
                        <td title="${escapeHtml(formatCommit(row.gitCommit))}">
                            ${escapeHtml(formatCommit(row.gitCommit))}
                        </td>
                        <td>${row.diskCount}</td>
                        <td>${row.shardCount}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

function getDiskColumns() {
    if (['all', 'offline'].includes(selectedZone)) {
        return [zoneColumn, ...columns];
    }
    return columns;
}

function getMultiSortPrefix(label) {
    return String(label).split('/')[0].trim().replace(/上限$/, '');
}

function renderMultiSortHeader(column) {
    const prefix = getMultiSortPrefix(column.label);
    return `
        <div class="multi-sort-header">
            <span class="multi-sort-prefix">${escapeHtml(prefix)}</span>
            <div class="multi-sort-parts">
                ${column.sortKeys.map((item) => {
                    const active = sortState.key === item.key ? 'active' : '';
                    return `
                        <button
                            class="sort-button multi-sort-button ${active}"
                            type="button"
                            data-sort-key="${escapeHtml(item.key)}"
                            title="按${escapeHtml(prefix)}${escapeHtml(item.label)}排序"
                        >
                            <span>${escapeHtml(item.label)}</span>
                            <span class="sort-mark">${getSortMark(sortState, item.key)}</span>
                        </button>
                    `;
                }).join('<span class="multi-sort-separator">/</span>')}
            </div>
        </div>
    `;
}

function renderTable(rows) {
    if (selectedZone === 'version' || selectedZone === 'capacity') {
        tableView.innerHTML = '';
        return;
    }

    const diskColumns = getDiskColumns();
    const filtered = sortRows(filterDiskRows(rows));

    if (!filtered.length) {
        tableView.innerHTML = '<div class="empty-state">当前没有匹配的磁盘信息</div>';
        return;
    }

    tableView.innerHTML = `
        <table>
            <thead>
                <tr>
                        ${diskColumns.map((column) => {

                        const headerTitle = column.headerTitle || '';
                        const titleAttr = headerTitle
                            ? ` title="${escapeHtml(headerTitle)}"`
                            : '';
                        if (column.sortKeys) {
                            return `
                                <th${titleAttr}>
                                    ${renderMultiSortHeader(column)}
                                </th>
                            `;
                        }

                        const active = sortState.key === column.key ? 'active' : '';
                        return `
                            <th${titleAttr}>
                                <button
                                    class="sort-button ${active}"
                                    type="button"
                                    data-sort-key="${escapeHtml(column.key)}"
                                >
                                    <span>${escapeHtml(column.label)}</span>
                                    <span class="sort-mark">${getSortMark(sortState, column.key)}</span>
                                </button>
                            </th>
                        `;
                    }).join('')}
                </tr>
            </thead>
            <tbody>
                ${filtered.map((row) => `
                    <tr class="${[
                        isOfflineMachine(row.toOffline) ? 'disk-offline-row' : '',
                        isActiveDisk(row) ? '' : 'disk-disabled-row',
                    ].filter(Boolean).join(' ')}">
                    ${diskColumns.map((column) => {

                            const title = column.title ? column.title(row) : '';
                            const titleAttr = title ? ` title="${escapeHtml(title)}"` : '';
                            const content = column.html
                                ? column.html(row)
                                : escapeHtml(column.render(row));
                            return `<td${titleAttr}>${content}</td>`;
                        }).join('')}
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

function getModeFromUrl() {
    return new URLSearchParams(window.location.search).get('mode') === 'test' ? 'test' : 'online';
}

function getClusterFromUrl() {
    return new URLSearchParams(window.location.search).get('cluster') || '';
}

function updateModeInUrl(mode) {
    const url = new URL(window.location.href);
    if (mode) {
        url.searchParams.set('mode', mode);
    } else {
        url.searchParams.delete('mode');
    }
    window.history.replaceState({}, '', url);
}

function updateClusterInUrl(cluster) {
    const url = new URL(window.location.href);
    if (cluster) {
        url.searchParams.set('cluster', cluster);
    } else {
        url.searchParams.delete('cluster');
    }
    window.history.replaceState({}, '', url);
}

function setModeTabs(mode) {
    modeButtons.forEach((button) => {
        const active = button.dataset.mode === mode;
        button.classList.toggle('active', active);
        button.setAttribute('aria-pressed', String(active));
    });
}

function getPreferredClusterForModeSwitch() {
    const cluster = currentCluster.textContent.trim();
    return cluster && cluster !== '未选择' ? cluster : clusterSelect.value;
}

function updateBnsLink(cluster) {
    if (!cluster) {
        bnsLink.href = '#';
        bnsLink.title = '未选择集群';
        return;
    }

    bnsLink.href = [
        'http://bns.noah.baidu.com/webfoot/fe/app/serviceDetail.html?serviceName=',
        encodeURIComponent(cluster),
    ].join('');
    bnsLink.title = `查看 ${cluster} 的 BNS 信息`;
}

function setActiveView(view) {
    activeView = view;
    tableViewButton.classList.toggle('active', view === 'disk');
    segmentViewButton.classList.toggle('active', view === 'segment');
    recoveryViewButton.classList.toggle('active', view === 'recovery');
    jsonViewButton.classList.toggle('active', view === 'json');
    const infoTabSelected = selectedZone === 'version' || selectedZone === 'capacity';
    zoneTabs.classList.toggle('hidden', view !== 'disk');
    diskFilter.classList.toggle('hidden', view !== 'disk' || infoTabSelected);
    tableView.classList.toggle('hidden', view !== 'disk' || infoTabSelected);
    topologyInfo.classList.toggle('hidden', view !== 'disk' || !infoTabSelected);
    segmentView.classList.toggle('hidden', view !== 'segment');
    recoveryView.classList.toggle('hidden', view !== 'recovery');
    jsonView.classList.toggle('hidden', view !== 'json');
}

async function registerProxyTargets(targets, reset = false) {
    const uniqueTargets = [...new Set(targets)].filter((endpoint) => /:\d+$/.test(endpoint));
    if (reset) {
        proxyMap = new Map();
    }
    if (!uniqueTargets.length) {
        return;
    }

    try {
        const response = await fetch('/api/proxies', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ targets: uniqueTargets }),
        });
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(payload.error || '代理端口注册失败');
        }
        (payload.proxies || []).forEach((proxy) => proxyMap.set(proxy.target, proxy));
    } catch (error) {
        setNotice(error.message, 'error');
    }
}

async function registerNodeProxies(rows) {
    await registerProxyTargets(rows.map((row) => getNodeEndpoint(row.node)), true);
}

async function registerSegmentDistributionProxies(rows) {
    const targets = rows.flatMap((row) => [...row.distribution.keys()].map(getNodeEndpointFromDistributionKey));
    await registerProxyTargets(targets);
}

function compareClusterName(left, right) {
    const [leftA = '', leftB = '', leftC = ''] = String(left).split('.');
    const [rightA = '', rightB = '', rightC = ''] = String(right).split('.');
    const options = { numeric: true };
    return leftC.localeCompare(rightC, 'zh-CN', options)
        || leftA.localeCompare(rightA, 'zh-CN', options)
        || leftB.localeCompare(rightB, 'zh-CN', options);
}

async function renderData(payload) {
    currentData = payload.data;
    currentSegmentRaw = '';
    currentSegmentRows = [];
    resetPoolCapacity();
    selectedZone = 'all';
    nodeFilterText = '';
    nodeFilterInput.value = '';
    currentRows = flattenStores(currentData);
    await registerNodeProxies(currentRows);
    summarizeRows(currentRows);
    await loadDisableNodeDiff(payload.cluster || clusterSelect.value || currentCluster.textContent.trim());
    renderZoneTabs(currentRows);
    renderTopologyInfo(currentRows);
    renderTable(currentRows);
    jsonView.textContent = JSON.stringify(currentData, null, 2);
    dataStatus.textContent = '已加载';
    refreshDataButton.disabled = false;
    const nodeErrors = Array.isArray(payload.nodeErrors) ? payload.nodeErrors : [];
    if (nodeErrors.length) {
        const details = nodeErrors
            .map((item) => `${item.addr || '未知节点'}(${item.code || '状态码缺失'})`)
            .join('、');
        setNotice(`部分节点返回异常：${details}`, 'error');
    }
    setActiveView(activeView === 'json' ? 'json' : 'disk');
}

async function loadClusters(mode = currentMode, preferredCluster = '') {
    currentMode = mode === 'test' ? 'test' : 'online';
    setModeTabs(currentMode);
    updateModeInUrl(currentMode);
    clusterSelect.disabled = true;
    refreshButton.disabled = true;
    refreshDataButton.disabled = true;
    clusterSelect.innerHTML = '<option>加载中...</option>';
    setNotice('');

    try {
        const response = await fetch(`/api/clusters?mode=${encodeURIComponent(currentMode)}`);
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(payload.error || '集群列表加载失败');
        }

        const clusters = [...payload.clusters].sort(compareClusterName);
        servicePath.textContent = payload.servicePath || '-';
        clusterSource.textContent = payload.source === 'command' ? '实时列表' : '示例列表';
        clusterSelect.innerHTML = clusters
            .map((cluster) => [
                `<option value="${escapeHtml(cluster)}">`,
                escapeHtml(cluster),
                '</option>',
            ].join(''))
            .join('');
        clusterSelect.disabled = clusters.length === 0;

        if (payload.warning) {
            setNotice(payload.warning);
        }
        if (clusters.length) {
            const urlCluster = getClusterFromUrl();
            const selectedCluster = clusters.includes(preferredCluster)
                ? preferredCluster
                : clusters.includes(urlCluster)
                    ? urlCluster
                    : clusters[0];
            clusterSelect.value = selectedCluster;
            updateClusterInUrl(selectedCluster);
            await loadStores(selectedCluster);
        }
    } catch (error) {
        clusterSelect.innerHTML = '<option>加载失败</option>';
        setNotice(error.message, 'error');
    } finally {
        refreshButton.disabled = false;
    }
}

async function loadStores(cluster) {
    updateClusterInUrl(cluster);
    updateBnsLink(cluster);
    currentCluster.textContent = cluster;
    copyClusterButton.disabled = !cluster;
    nodeCount.textContent = '-';
    offlineNodeCount.textContent = '预下线 -';
    offlineNodeCount.classList.remove('active');
    disableNodeDiffCount.textContent = 'disable -';
    disableNodeDiffCount.title = '';
    disableNodeDiffCount.classList.remove('active');
    disableNodeDiffCount.hidden = true;
    diskCount.textContent = '-';
    disableDiskCount.textContent = 'disable -';
    disableDiskCount.classList.remove('active');
    riskDiskCount.textContent = '风险 -';
    riskDiskCount.classList.remove('active');
    clusterCapacity.textContent = '-';
    zoneSummary.textContent = '-';
    nodeFilterText = '';
    nodeFilterInput.value = '';
    dataStatus.textContent = '查询中';
    tableView.innerHTML = '';
    jsonView.textContent = '';
    zoneTabs.innerHTML = '';
    topologyInfo.innerHTML = '';
    setLoading(true);
    setNotice(notice.classList.contains('error') ? '' : notice.textContent);

    try {
        const response = await fetch(`/api/stores?cluster=${encodeURIComponent(cluster)}`);
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(payload.stderr || payload.error || '磁盘信息加载失败');
        }
        await renderData(payload);
    } catch (error) {
        dataStatus.textContent = '失败';
        tableView.innerHTML = '<div class="empty-state">无法获取该集群的磁盘信息</div>';
        setNotice(error.message, 'error');
    } finally {
        setLoading(false);
    }
}

async function loadSegments(cluster) {
    segmentContent.innerHTML = '<div class="loading">正在查询 gaia list-ps-status...</div>';
    resetPoolCapacity('查询中');
    refreshSegmentButton.disabled = true;

    try {
        const response = await fetch(`/api/segments?cluster=${encodeURIComponent(cluster)}`);
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(payload.stderr || payload.error || '分片信息加载失败');
        }
        currentSegmentRaw = payload.data || '';
        currentSegmentRows = summarizeSegments(currentSegmentRaw);
        enrichSegmentRowsWithExtentStats(currentSegmentRows, payload.poolCapacity || {});
        await registerSegmentDistributionProxies(currentSegmentRows);
        renderPoolCapacity(payload.poolCapacity || {});
        renderSegmentPhysicalSizes(currentSegmentRaw, payload.poolCapacity || {});
        const capacityErrors = Array.isArray(payload.poolCapacity && payload.poolCapacity.errors)
            ? payload.poolCapacity.errors
            : [];
        if (capacityErrors.length) {
            setNotice(
                `容量统计异常：${capacityErrors.map((item) => item.manager).join('、')}`,
                'error',
            );
        } else if (notice.classList.contains('error') && notice.textContent.startsWith('容量统计异常：')) {
            setNotice('');
        }
        renderSegments();
    } catch (error) {
        resetPoolCapacity();
        segmentContent.innerHTML = '<div class="empty-state">无法获取该集群的分片信息</div>';
        setNotice(error.message, 'error');
    } finally {
        refreshSegmentButton.disabled = false;
    }
}

async function loadRecovery(cluster) {
    recoverySummary.innerHTML = '';
    recoveryContent.innerHTML = '<div class="loading">正在查询 gaia list-ps-recovery...</div>';
    setRecoveryRefreshDisabled(true);

    try {
        const response = await fetch(`/api/recovery?cluster=${encodeURIComponent(cluster)}`);
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(payload.stderr || payload.error || '恢复信息加载失败');
        }
        currentRecoveryRaw = payload.data;
        currentRecoveryRows = normalizeRecoveryRows(currentRecoveryRaw);
        enrichRecoveryRowsWithDiskInfo(currentRecoveryRows, currentRows);
        await loadRecoveryVars(currentRecoveryRows);
        renderRecovery();

        const nodeErrors = Array.isArray(payload.nodeErrors) ? payload.nodeErrors : [];
        if (nodeErrors.length) {
            const details = nodeErrors
                .map((item) => `${item.addr || '未知节点'}(${item.code || '状态码缺失'})`)
                .join('、');
            setNotice(`部分节点返回异常：${details}`, 'error');
        }

    } catch (error) {
        recoverySummary.innerHTML = '';
        recoveryContent.innerHTML = '<div class="empty-state">无法获取该集群的恢复信息</div>';
        setNotice(error.message, 'error');
    } finally {
        setRecoveryRefreshDisabled(false);
    }
}

clusterSelect.addEventListener('change', () => {
    currentSegmentRaw = '';
    currentSegmentRows = [];
    currentRecoveryRaw = '';
    currentRecoveryRows = [];
    recoveryNodeFilterText = '';
    recoveryClusterFilterText = '';
    recoveryNodeSearch.value = '';
    recoveryClusterSearch.value = '';
    segmentContent.innerHTML = '';
    recoverySummary.innerHTML = '';
    recoveryContent.innerHTML = '';
    loadStores(clusterSelect.value);
});
refreshButton.addEventListener('click', () => {
    loadClusters(currentMode, getPreferredClusterForModeSwitch());
});
refreshDataButton.addEventListener('click', () => {
    if (clusterSelect.value) {
        loadStores(clusterSelect.value);
    }
});

modeButtons.forEach((button) => {
    button.addEventListener('click', () => {
        const mode = button.dataset.mode || 'online';
        loadClusters(mode, getPreferredClusterForModeSwitch());
    });
});

copyClusterButton.addEventListener('click', async () => {
    const cluster = currentCluster.textContent.trim();
    if (!cluster || cluster === '未选择') {
        return;
    }

    await copyText(cluster);
    copyClusterButton.textContent = '已复制';
    window.setTimeout(() => {
        copyClusterButton.textContent = '复制';
    }, 1200);
});

zoneTabs.addEventListener('click', (event) => {
    const button = event.target.closest('.zone-tab');
    if (!button) {
        return;
    }
    selectedZone = button.dataset.zone;
    renderZoneTabs(currentRows);
    if (selectedZone === 'capacity') {
        renderCapacityInfo(currentRows);
    } else {
        renderTopologyInfo(currentRows);
    }
    renderTable(currentRows);
    setActiveView('disk');
});

tableView.addEventListener('click', (event) => {
    const copyButton = event.target.closest('.node-copy-button');
    if (copyButton) {
        copyText(copyButton.dataset.copyIp || '').then(() => {
            copyButton.textContent = '已复制';
            window.setTimeout(() => {
                copyButton.textContent = '复制';
            }, 1200);
        });
        return;
    }

    const button = event.target.closest('.sort-button');
    if (!button) {
        return;
    }
    const key = button.dataset.sortKey;
    sortState = {
        key,
        direction: sortState.key === key && sortState.direction === 'asc' ? 'desc' : 'asc',
    };
    renderTable(currentRows);
});

nodeFilterInput.addEventListener('input', () => {
    nodeFilterText = nodeFilterInput.value;
    renderTable(currentRows);
});

topologyInfo.addEventListener('click', (event) => {
    const button = event.target.closest('.sort-button');
    if (!button || selectedZone !== 'version') {
        return;
    }
    const key = button.dataset.topologySortKey;
    topologySortState = {
        key,
        direction: topologySortState.key === key && topologySortState.direction === 'asc' ? 'desc' : 'asc',
    };
    renderTopologyInfo(currentRows);
});

tableViewButton.addEventListener('click', () => setActiveView('disk'));

segmentViewButton.addEventListener('click', () => {
    setActiveView('segment');
    if (!currentSegmentRaw && clusterSelect.value) {
        loadSegments(clusterSelect.value);
    }
});

recoveryViewButton.addEventListener('click', () => {
    setActiveView('recovery');
    if (!currentRecoveryRaw && clusterSelect.value) {
        loadRecovery(clusterSelect.value);
    }
});

refreshSegmentButton.addEventListener('click', () => {
    if (clusterSelect.value) {
        loadSegments(clusterSelect.value);
    }
});

recoverySummary.addEventListener('click', (event) => {
    const button = event.target.closest('#refreshRecoveryButton');
    if (!button || !clusterSelect.value) {
        return;
    }
    loadRecovery(clusterSelect.value);
});

segmentSearch.addEventListener('input', renderSegments);

recoveryNodeSearch.addEventListener('input', () => {
    recoveryNodeFilterText = recoveryNodeSearch.value;
    renderRecovery();
});

recoveryClusterSearch.addEventListener('input', () => {
    recoveryClusterFilterText = recoveryClusterSearch.value;
    renderRecovery();
});

segmentContent.addEventListener('click', (event) => {
    const button = event.target.closest('.sort-button');
    if (!button) {
        return;
    }
    const key = button.dataset.segmentSortKey;
    if (!key) {
        return;
    }
    segmentSortState = {
        key,
        direction: segmentSortState.key === key && segmentSortState.direction === 'asc' ? 'desc' : 'asc',
    };
    renderSegments();
});

recoveryContent.addEventListener('click', (event) => {
    const button = event.target.closest('.sort-button');
    if (!button) {
        return;
    }
    const key = button.dataset.recoverySortKey;
    if (!key) {
        return;
    }
    recoverySortState = {
        key,
        direction: recoverySortState.key === key && recoverySortState.direction === 'asc' ? 'desc' : 'asc',
    };
    renderRecovery();
});

jsonViewButton.addEventListener('click', () => setActiveView('json'));

setModeTabs(currentMode);
loadClusters(currentMode);
