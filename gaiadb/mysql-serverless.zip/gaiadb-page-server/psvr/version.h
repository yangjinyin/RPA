/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/version.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <base/string_printf.h>
#include <gaiadb/utils/utils.h>
#include <psvr0meta.h>

namespace psvr {

// Version and time message
#if defined(__DATE__) && defined(__TIME__)
static const char __PSVR_BUILD_DATE__[] = __DATE__ " " __TIME__;
#else
static const char __PSVR_BUILD_DATE__[] = "unknown";
#endif

#ifndef __PSVR_MODULE_NAME__
#ifdef WITH_GAIA_APPLY_BAN_ASSERT
#define __PSVR_MODULE_NAME__ "GAIADB-PAGE SERVER (WITHOUT ASSERT)"
#else
#define __PSVR_MODULE_NAME__ "GAIADB-PAGE SERVER"
#endif
#endif /* __PSVR_MODULE_NAME__ */

#ifndef __PSVR_COMMIT__
#define __PSVR_COMMIT__ "unknown commit"
#endif

#ifndef __PSVR_VERSION__
#define __PSVR_VERSION__ "unknown version"
#endif

#ifndef __PSVR_PLATFORM__
#define __PSVR_PLATFORM__ "unknown platform"
#endif

inline std::string get_version() {
    std::string psvr_version;
    base::string_printf(&psvr_version,
            "MODULE: %s\n"
            "COMMIT: %s\n"
            "VERSION: %s\n"
            "BUILD: %s\n"
            "COMMON_CI: %s\n"
            "APPLY_CI: %s\n"
            "PLATFORM: %s\n",
            __PSVR_MODULE_NAME__,
            __PSVR_COMMIT__,
            __PSVR_VERSION__,
            __PSVR_BUILD_DATE__,
            gaiadb::common::get_commit(),
            gaia_apply::get_commit(),
            __PSVR_PLATFORM__);
    return psvr_version;
}

}

