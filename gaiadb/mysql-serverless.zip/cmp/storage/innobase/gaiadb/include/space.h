/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/include/space.h
 The interface to gaiadb storage

 Created 10/28/2022 Hongyu Qiao
 *******************************************************/

#ifndef gaiadb_space_h
#define gaiadb_space_h

#include "univ.i"
#include "db0err.h"
#include "os0file.h"
#include "fil0fil.h"

/** Extent space size to psm
@param[in]      space_id        id of the space
@param[in]      start           extent start offset
@param[in]      len             extent length
@return DB_SUCCESS if all OK */
dberr_t gaiadb_space_extent(space_id_t space_id,
                            os_offset_t start,
                            os_offset_t len);


/** This function returns size about the specified space
@param[in]      space_id        id of the space
@return space size in bytes */
os_offset_t gaiadb_space_get_size(space_id_t space_id);

/** Create a space to psm
@param[in]      space_id        Tablespace ID
@param[in]      extent_size     Initial size of the tablespace in extents,
@param[in]      is_tde          Use TDE to encrypt space
@param[in]      tde_from_space  Source space id to copy TDE encryption info,
                                SPACE_UNKNOWN if not needed
@return DB_SUCCESS or error code */
dberr_t gaiadb_create_space(space_id_t space_id, uint32_t extent_size,
    bool is_tde = false, uint32_t tde_from_space = SPACE_UNKNOWN);

/** Drop a space from psm
@param[in]      space_id        Tablespace ID
@return DB_SUCCESS or error code */
dberr_t gaiadb_drop_space(space_id_t space_id);

/** This function check exist space
@param[in]      space_id        id of the space
@return true if all OK */
bool gaiadb_space_exist(space_id_t space_id);

#endif /* gaiadb_space_h */
