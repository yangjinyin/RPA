/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/segment_manager.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/segment_manager.h"
#include "psvr/fetch.h"

namespace psvr {

static bvar::Adder<int64_t> l_stat_psminfo_count("psvr_psminfo_total_count");
static bvar::Adder<int64_t> l_stat_cluster_count("psvr_cluster_total_count");

#define SLICE_CLUSTER_SIZE 128u
SegmentManager::SegmentManager() :
    _segment_size(0),
    _segment_version(0),
    _use_batch_fetch_clusters_size(0) {
    for (uint32_t i = 0; i < SLICE_CLUSTER_SIZE; ++i) {
        _psm_infos.emplace_back(std::make_shared<PsmInfoResManager>(l_stat_psminfo_count));
        _clusters.emplace_back(std::make_shared<ClusterResManager>(l_stat_cluster_count));
    }
}

int64_t SegmentManager::GetClusterSize() {
    return l_stat_cluster_count.get_value();
}

int64_t SegmentManager::GetPsmInfoSize() {
    return l_stat_psminfo_count.get_value();
}

void SegmentManager::Start(uint32_t store_count) {
    std::unique_lock lk(_shared_mutex);
    for (uint32_t i = 0; i < store_count; ++i) {
        _store_segments.emplace_back(i);
    }
}

void SegmentManager::Stop() {
    LOG(NOTICE) << "segment manager will stop ..., size:" << _segment_size;
    std::unique_lock lk(_shared_mutex);
    size_t n = 0;
    for (auto& store : _store_segments) {
        for (auto& seg : store.segments) {
            seg->Stop();
            ++n;
            LOG_EVERY_SECOND(NOTICE) <<  "stop segment num:" << n;
        }
    }
    LOG(NOTICE) << "all segment stop ok, start clear cluster segments ...";
    _cluster_segments.clear();
    LOG(NOTICE) << "start clear store segment ...";
    _store_segments.clear();
    LOG(NOTICE) << "start clear psm info ...";
    _psm_infos.clear();
    LOG(NOTICE) << "start clear clusters ...";
    _clusters.clear();
    LOG(NOTICE) << "segment manager stop ok";
}

void SegmentManager::SetBatchFetchClusters(const std::vector<std::string>& clusters) {
    std::unique_lock lk(_shared_mutex);
    for (auto& id : clusters) {
        if (_use_batch_fetch_clusters.emplace(id).second) {
            ++_use_batch_fetch_clusters_size;
        }
    }
}

ClusterPtr SegmentManager::GetOrCreateCluster(const std::string& cluster_id) {
    auto cluster = _clusters[Get32bitHash(cluster_id) % SLICE_CLUSTER_SIZE]->GetOrCreate(cluster_id, cluster_id);
    if (!FetcherType::IsSingleSegment()
            && !cluster->use_batch_fetch()) {
        if (FetcherType::IsBatchByAll()) {
            cluster->set_use_batch_fetch();
        } else if (_use_batch_fetch_clusters_size) {
            if (_use_batch_fetch_clusters.find(cluster_id) != _use_batch_fetch_clusters.end()) {
                cluster->set_use_batch_fetch();
            }
        }
    }
    return cluster;
}

ClusterPtr SegmentManager::GetCluster(const std::string& cluster_id) {
    return _clusters[Get32bitHash(cluster_id) % SLICE_CLUSTER_SIZE]->Get(cluster_id);
}

PsmInfoPtr SegmentManager::GetPsmInfo(const std::string& address) {
    return _psm_infos[Get32bitHash(address) % SLICE_CLUSTER_SIZE]->Get(address);
}

PsmInfoPtr SegmentManager::GetOrCreatePsmInfo(const std::string& address) {
    return _psm_infos[Get32bitHash(address) % SLICE_CLUSTER_SIZE]->GetOrCreate(address, address);
}

void SegmentManager::GetPsmInfos(pspb::ListPsmInfoResponse* response) {
    auto fn = [&response](const std::string& addr, std::shared_ptr<PsmInfo> psm_info) {
        if (psm_info) {
            auto pb = response->add_psm_infos();
            pb->set_addr(addr);
            std::vector<base::EndPoint> nodes;
            if (psm_info->GetOrRefreshBNSNodes(&nodes)) {
                for (auto& n : nodes) {
                    pb->add_nodes(base::endpoint2str(n).c_str());
                }
            }
        }
    };
    for (auto& psm : _psm_infos) {
        psm->Iterator(fn);
    }
}

SegmentManager::SegmentCluster& SegmentManager::GetOrCreateSegmentClusterNoLock(const std::string& cluster_id) {
    auto it = _cluster_segments.find(cluster_id);
    if (it != _cluster_segments.end()) {
        return it->second;
    } else {
        return _cluster_segments.emplace(cluster_id, cluster_id).first->second;
    }
}

bool SegmentManager::AddSegment(SegmentPtr segment) {
    std::unique_lock lk(_shared_mutex);
    PSVR_ASSERT(segment->store_id() >= 0);
    auto& cluster = GetOrCreateSegmentClusterNoLock(segment->cluster_id());
    if (cluster.Add(segment)) {
        auto& store = _store_segments[segment->store_id()];
        const bool ret = store.Add(segment, cluster);
        PSVR_ASSERT(ret);
        ++_segment_size;
        ++_segment_version;
        return ret;
    }
    return false;
}

bool SegmentManager::ReplaceSegment(SegmentPtr segment, SegmentPtr new_segment) {
    std::unique_lock lk(_shared_mutex);
    PSVR_ASSERT(segment->store_id() >= 0);
    auto& cluster = GetOrCreateSegmentClusterNoLock(segment->cluster_id());
    if (cluster.Replace(segment, new_segment)) {
        auto& store = _store_segments[segment->store_id()];
        const bool ret = store.Replace(segment, new_segment, cluster);
        PSVR_ASSERT(ret);
        ++_segment_version;
        return ret;
    }
    return false;
}

bool SegmentManager::DropSegment(SegmentPtr segment) {
    std::unique_lock lk(_shared_mutex);
    PSVR_ASSERT(segment->store_id() >= 0);
    auto it = _cluster_segments.find(segment->cluster_id());
    if (it != _cluster_segments.end()) {
        auto& cluster = it->second;
        if (cluster.Del(segment)) {
            auto& store = _store_segments[segment->store_id()];
            const bool ret = store.Del(segment, cluster);
            PSVR_ASSERT(ret);
            --_segment_size;
            ++_segment_version;
            return ret;
        }
    }
    return false;
}

bool SegmentManager::ExistSegment(SegmentPtr segment) {
    return GetSegment(segment->cluster_id(), segment->segment_id()) != nullptr;
}

SegmentPtr SegmentManager::GetSegment(const std::string& cluster_id, uint32_t segment_id) {
    std::shared_lock slk(_shared_mutex);
    auto it = _cluster_segments.find(cluster_id);
    if (it != _cluster_segments.end()) {
        return it->second.Get(segment_id);
    }
    return nullptr;
}

void SegmentManager::GetAllSegments(std::vector<SegmentPtr>* segments) {
    std::shared_lock slk(_shared_mutex);
    segments->reserve(_segment_size);
    for (auto& store : _store_segments) {
        segments->insert(segments->end(), store.segments.begin(), store.segments.end());
    }
}

uint32_t SegmentManager::GetAllSegments(const SegmentIteratorFn& fn) {
    std::vector<SegmentPtr> segments;
    GetAllSegments(&segments);
    uint32_t n = 0;
    std::for_each(segments.begin(), segments.end(),
        [&n, &fn](const SegmentPtr& segment) {
            ++n;
            fn (segment);
        });
    return n;
}

void SegmentManager::GetAllClusters(std::vector<std::string>* clusters) {
    std::shared_lock slk(_shared_mutex);
    clusters->reserve(_cluster_segments.size());
    for (auto& it : _cluster_segments) {
        clusters->emplace_back(it.first);
    }
}

void SegmentManager::GetClusterSegments(const std::string& cluster_id,
        std::vector<SegmentPtr>* segments) {
    std::shared_lock slk(_shared_mutex);
    auto it = _cluster_segments.find(cluster_id);
    if (it != _cluster_segments.end()) {
        segments->reserve(it->second.segments.size());
        for (auto& it2 : it->second.segments) {
            segments->emplace_back(it2.second);
        }
    }
}

uint32_t SegmentManager::GetClusterSegments(const std::string& cluster_id,
        const SegmentIteratorFn& fn) {
    std::vector<SegmentPtr> segments;
    GetClusterSegments(cluster_id, &segments);
    uint32_t n = 0;
    for (auto& segment : segments) {
        ++n;
        fn (segment);
    }
    return n;
}

uint32_t SegmentManager::DropClusterSegments(const std::string& cluster_id,
        const SegmentIteratorFn& fn) {
    uint32_t n = 0;
    std::vector<SegmentPtr> segments;
    {
        std::unique_lock lk(_shared_mutex);
        auto it = _cluster_segments.find(cluster_id);
        if (it != _cluster_segments.end()) {
            for (auto& it2 : it->second.segments) {
                auto& segment = it2.second;
                ++n;
                segments.emplace_back(segment);
                // remove from store
                auto& store = _store_segments[segment->store_id()];
                const bool ret = store.Del(segment, it->second);
                PSVR_ASSERT(ret);
            }
            _segment_size -= n;
            _cluster_segments.erase(cluster_id);
            ++_segment_version;
        }
    }
    for (auto& segment : segments) {
        fn (segment);
    }
    return n;
}

uint32_t SegmentManager::GetStoreSegments(int32_t store_id,
        std::vector<SegmentPtr>* segments) {
    std::shared_lock slk(_shared_mutex);
    uint32_t n = 0;
    auto& store = _store_segments[store_id];
    segments->reserve(store.segments.size());
    for (auto& segment : store.segments) {
        ++n;
        segments->emplace_back(segment);
    }
    return n;
}

uint32_t SegmentManager::DropStoreSegments(int32_t store_id,
        const SegmentIteratorFn& fn) {
    uint32_t n = 0;
    std::vector<SegmentPtr> segments;
    {
        std::unique_lock lk(_shared_mutex);
        auto& store = _store_segments[store_id];
        auto it = store.segments.begin();
        while (it != store.segments.end()) {
            auto segment = *it;
            ++n;
            segments.emplace_back(segment);

            auto& cluster = GetOrCreateSegmentClusterNoLock(segment->cluster_id());
            bool ret = cluster.Clear(segment);
            PSVR_ASSERT(ret);

            if (cluster.segments.empty()) {
                PSVR_ASSERT(cluster.slots.empty());
                _cluster_segments.erase(cluster.id);
            }

            ++it;
        }

        store.segments.clear();

        _segment_size -= n;
        ++_segment_version;
    }

    for (auto& segment : segments) {
        fn (segment);
    }
    return n;
}

void SegmentManager::ListAllClusterSegmentSize(pspb::ListClusterStatusResponse* rsp) {
    std::vector<std::pair<std::string, uint32_t>> _cluster_segment_num;
    {
        std::shared_lock slk(_shared_mutex);
        _cluster_segment_num.reserve(_cluster_segments.size());
        for (auto& it : _cluster_segments) {
            _cluster_segment_num.emplace_back(std::make_pair(it.first, it.second.segments.size()));
        }
    }

    std::sort(_cluster_segment_num.begin(), _cluster_segment_num.end(),
            [](const std::pair<std::string, uint32_t>& lhs, const std::pair<std::string, uint32_t>& rhs){
                return lhs.second > rhs.second;
            });

    for (auto& it : _cluster_segment_num) {
        auto pb = rsp->add_clusters();
        pb->set_cluster_id(it.first);
        pb->set_segment_num(it.second);
    }
}

}
