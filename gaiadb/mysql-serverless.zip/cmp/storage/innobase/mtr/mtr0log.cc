/*****************************************************************************

Copyright (c) 1995, 2022, Oracle and/or its affiliates.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file mtr/mtr0log.cc
 Mini-transaction log routines

 Created 12/7/1995 Heikki Tuuri
 *******************************************************/

#include "mtr0log.h"

#ifndef UNIV_HOTBACKUP
#include "buf0buf.h"
#include "buf0dblwr.h"
#include "dict0dict.h"
#include "log0recv.h"
#endif /* !UNIV_HOTBACKUP */
#include "page0page.h"

#ifndef UNIV_HOTBACKUP
#include "dict0boot.h"
#endif /* !UNIV_HOTBACKUP */
#include "col0col.h"
#include "dict0dd.h"
#include "sql_string.h"

/** Parses a log record written by mlog_open_and_write_index.
@param[in]  ptr      buffer
@param[in]  end_ptr  buffer end
@param[out] index    own: dummy index
@return parsed record end, NULL if not a complete record */
static byte *mlog_parse_index_8029(byte *ptr, const byte *end_ptr,
                                   dict_index_t **index);

/** Catenates n bytes to the mtr log.
@param[in] mtr Mini-transaction
@param[in] str String to write
@param[in] len String length */
void mlog_catenate_string(mtr_t *mtr, const byte *str, ulint len) {
  if (mtr_get_log_mode(mtr) == MTR_LOG_NONE) {
    return;
  }

  mtr->get_log()->push(str, uint32_t(len));
}

#ifndef UNIV_HOTBACKUP
/** Writes the initial part of a log record consisting of one-byte item
 type and four-byte space and page numbers. Also pushes info
 to the mtr memo that a buffer page has been modified. */
void mlog_write_initial_log_record(
    const byte *ptr, /*!< in: pointer to (inside) a buffer
                     frame holding the file page where
                     modification is made */
    mlog_id_t type,  /*!< in: log item type: MLOG_1BYTE, ... */
    mtr_t *mtr)      /*!< in: mini-transaction handle */
{
  byte *log_ptr = nullptr;

  ut_ad(type <= MLOG_BIGGEST_TYPE);
  ut_ad(type > MLOG_8BYTES);
  mlog_add_last_record_check_bits(mtr);
  /* If no logging is requested, we may return now */
  if (!mlog_open(mtr, REDO_LOG_INITIAL_INFO_SIZE, log_ptr)) {
    return;
  }

  log_ptr = mlog_write_initial_log_record_fast(ptr, type, log_ptr, mtr);

  mlog_close(mtr, log_ptr);
}
#endif /* !UNIV_HOTBACKUP */

/** Parses an initial log record written by mlog_write_initial_dict_log_record.
@param[in]      ptr             buffer
@param[in]      end_ptr         buffer end
@param[out]     type            log record type, should be
                                MLOG_TABLE_DYNAMIC_META
@param[out]     id              table id
@param[out]     version         table dynamic metadata version
@return parsed record end, NULL if not a complete record */
byte *mlog_parse_initial_dict_log_record(const byte *ptr, const byte *end_ptr,
                                         mlog_id_t *type, table_id_t *id,
                                         uint64_t *version, ulint *body_len, uint32_t *check_bits_len) {
  if (end_ptr < ptr + 1) {
    return (nullptr);
  }

  *type = (mlog_id_t)((ulint)*ptr & ~MLOG_SINGLE_REC_FLAG);
  ut_ad(*type == MLOG_TABLE_DYNAMIC_META);

  ptr++;

  if (end_ptr < ptr + 1) {
    return (nullptr);
  }

  *id = mach_parse_u64_much_compressed(&ptr, end_ptr);

  if (ptr == nullptr || end_ptr < ptr + 1) {
    return (nullptr);
  }

  *version = mach_parse_u64_much_compressed(&ptr, end_ptr);

  if (ptr == nullptr || end_ptr < ptr + 3) {
      return (nullptr);
  }

  *body_len = mach_read_from_3(ptr);
  ptr += 3;

  *check_bits_len = 0;
  parse_check_bits(body_len, check_bits_len);

  return (const_cast<byte *>(ptr));
}

byte *mlog_parse_initial_binlog_log_record(
    const byte *ptr, const byte *end_ptr, mlog_id_t *type,
    innodb::binlog_redo_op_t *binlog_redo_op_type, uint32_t *index_num,
    uint64_t *pos, ulint *body_len, uint32_t *check_bits_len) {
  if (end_ptr < ptr + 1) {
    return (nullptr);
  }

  *type = (mlog_id_t)((ulint)*ptr & ~MLOG_SINGLE_REC_FLAG);
  ut_ad(*type == MLOG_GAIA_BINLOG_DATA);

  ptr++;

  if (end_ptr < ptr + 1) {
    return (nullptr);
  }

  *binlog_redo_op_type = (innodb::binlog_redo_op_t)((ulint)*ptr);
  ut_a(*binlog_redo_op_type <= innodb::binlog_redo_op_t::BINLOG_REDO_OP_MAX);

  ptr++;

  if (end_ptr < ptr + 1) {
    return (nullptr);
  }

  *index_num = mach_parse_compressed(&ptr, end_ptr);

  if (ptr == nullptr || end_ptr < ptr + 1) {
    return (nullptr);
  }

  *pos = mach_parse_u64_much_compressed(&ptr, end_ptr);

  if (ptr != NULL) {
    if (end_ptr < ptr + 3) {
      return (NULL);
    }

    *body_len = mach_read_from_3(ptr);
    ptr += 3;

    *check_bits_len = 0;
    parse_check_bits(body_len, check_bits_len);
  }

  return (const_cast<byte *>(ptr));
}

static void mlog_write_columnar_log_low(mtr_t *mtr, columnar_op_t op,
                                        trx_id_t trx_id, uint32_t space_id,
                                        uint64_t index_id, const byte *buf,
                                        uint32_t len) {
  byte *log_ptr;

  mlog_add_last_record_check_bits(mtr);

  /* | type(1) | trx_id(8) | op(1) | space_id(4) | index_id(8) | body_len(3) |*/
  log_ptr = mlog_open_columnar_log(mtr, 1 + 8 + 1 + 4 + 8 + 3);
  ut_ad(log_ptr != NULL);

  // init record head
  log_ptr = mlog_write_initial_columnar_log_record(MLOG_GAIA_COLUMNAR_OPERATOR,
                                                   trx_id, op, space_id,
                                                   index_id, log_ptr, mtr);

  ut_a(len <= UNIV_PAGE_SIZE);
  mlog_close(mtr, log_ptr);

  // fill body
  mlog_catenate_string(mtr, buf, len);
}

constexpr size_t DATA_LEN_FIELD_LENS = 8;
constexpr uint8_t FIELD_IS_UNSIGNED = 0x01;
constexpr uint8_t FIELD_IS_UNIQUE_KEY = 0x02;

static void mlog_write_create_columnar_log(mtr_t *mtr, columnar_op_t op,
                                           trx_id_t trx_id,
                                           const dict_index_t *index,
                                           Field **mysql_fields, byte *buf_ptr,
                                           size_t buf_len) {
  dict_table_t *table = index->table;
  bool close_table = false;
  if (!table) {
    table = dd_table_open_on_name_in_mem(index->table_name, false);
    close_table = true;
  }
  auto *clust_index = UT_LIST_GET_FIRST(table->indexes);
  ut_a(clust_index->is_clustered());
  // rollptr, trx_id
  uint32_t n_t_cols = table->n_def - table->get_n_sys_cols();
  std::unique_ptr<bool[]> indexed(new bool[table->n_cols]());
  if (close_table) {
    dd_table_close(table, nullptr, nullptr, false);
  }
  table = nullptr;

  for (ulint i = 0; i < clust_index->n_uniq; ++i) {
    auto *field = clust_index->get_field(i);
    indexed[field->col->ind] = true;
  }

  std::vector<Field *> no_v_fields;
  no_v_fields.reserve(n_t_cols);
  for (ulint i = 0; i < n_t_cols; ++i) {
    auto* mysql_field = mysql_fields[i];
    if (!innobase_is_v_fld(mysql_field)) {
      no_v_fields.push_back(mysql_field);
    }
  }

  // write number of index field size, see REC_MAX_N_FIELDS
  mach_write_to_2(buf_ptr + buf_len, index->n_fields);
  buf_len += 2;

  for (ulint i = 0; i < index->n_fields; ++i) {
    auto *ind_field = index->get_field(i);

    auto* mysql_field = no_v_fields[ind_field->col->ind];

    std::string field_name(mysql_field->field_name);
    auto name_len = field_name.length();
    if (buf_len + name_len + 1 /*name_lens*/ + 1 /*field_type*/ + 1 /*flags*/ +
            1 /*precision*/ + 1 /*scale*/
        > UNIV_PAGE_SIZE) {
      mlog_write_columnar_log_low(mtr, op, trx_id, index->space, index->id,
                                  buf_ptr, buf_len);
      memset(buf_ptr, 0, UNIV_PAGE_SIZE);
      buf_len = 0;
    }

    // field name
    mach_write_to_1(buf_ptr + buf_len, name_len);
    buf_len += 1;
    memcpy(buf_ptr + buf_len, field_name.c_str(), name_len);
    buf_len += name_len;

    // field type, for 1B, see enum_field_types
    auto field_type = mysql_field->real_type();
    mach_write_to_1(buf_ptr + buf_len, field_type);
    buf_len += 1;

    // write flags
    uint8_t flags = 0;
    if (indexed[index->fields[i].col->ind]) {
      flags |= FIELD_IS_UNIQUE_KEY;
    }

    if (mysql_field->is_unsigned()) {
      flags |= FIELD_IS_UNSIGNED;
    }
    mach_write_to_1(buf_ptr + buf_len, flags);
    buf_len += 1;

    // MYSQL_TYPE_NEWDECIMAL must write precision and scale
    switch (field_type) {
      case MYSQL_TYPE_NEWDECIMAL: {
        auto decimal_field =
            dynamic_cast<const Field_new_decimal *>(mysql_field);
        mach_write_to_1(buf_ptr + buf_len, decimal_field->precision);
        buf_len += 1;
        mach_write_to_1(buf_ptr + buf_len, decimal_field->dec);
        buf_len += 1;
        break;
      }
      case MYSQL_TYPE_TIMESTAMP2: {
        auto date_field =
            dynamic_cast<const Field_temporal_with_date_and_timef *>(
                mysql_field);
        mach_write_to_1(buf_ptr + buf_len, date_field->decimals());
        buf_len += 1;
        break;
      }
      default:
        break;
    }
  }
  mlog_write_columnar_log_low(mtr, op, trx_id, index->space, index->id, buf_ptr,
                              buf_len);
}

static void mlog_write_delete_columnar_log(mtr_t *mtr, columnar_op_t op,
                                           trx_id_t trx_id, dict_index_t *index,

                                           const dtuple_t *entry, byte *buf_ptr,
                                           size_t buf_len) {
  ut_a(op == columnar_op_t::COLUMNAR_INDEX_DELETE);
  auto *clust_index = UT_LIST_GET_FIRST(index->table->indexes);
  ut_a(clust_index->is_clustered());

  std::unique_ptr<bool[]> indexed(new bool[index->table->n_cols]());
  for (ulint i = 0; i < clust_index->n_uniq; ++i) {
    auto *field = clust_index->get_field(i);
    indexed[field->col->ind] = true;
  }

  ut_a(clust_index->n_uniq > 0);
  mach_write_to_2(buf_ptr + buf_len, clust_index->n_uniq);
  buf_len += 2;

  // write primary key value
  for (ulint i = 0; i < index->n_fields; ++i) {
    if (!indexed[index->fields[i].col->ind]) {
      continue;
    }
    const auto *field = entry->fields + i;
    ut_a(!dfield_is_ext(field));
    ut_a(!dfield_is_null(field));

    // write data of field
    const byte *data = static_cast<const byte *>(dfield_get_data(field));
    ulint data_len = dfield_get_len(field);
    auto real_data_len = data_len;
    const auto *data_ptr = data;

    // for string type, we should convert type to utf8
    char tmp_buf[8192];
    if (dtype_is_non_binary_string_type(field->type.mtype,
                                        field->type.prtype) &&
        !dtype_is_utf8(field->type.prtype)) {
      data_ptr = reinterpret_cast<const byte *>(tmp_buf);
      ulint charset_coll = dtype_get_charset_coll(field->type.prtype);
      CHARSET_INFO *data_cs = all_charsets[charset_coll];
      uint num_errors;

      real_data_len = copy_and_convert(
          tmp_buf, sizeof(tmp_buf), &my_charset_utf8mb3_general_ci,
          reinterpret_cast<const char *>(data), data_len, data_cs, &num_errors);
    }

    if (buf_len + real_data_len + DATA_LEN_FIELD_LENS + 2 > UNIV_PAGE_SIZE) {
      mlog_write_columnar_log_low(mtr, op, trx_id, index->space, index->id,
                                  buf_ptr, buf_len);
      memset(buf_ptr, 0, UNIV_PAGE_SIZE);
      buf_len = 0;
    }
    // write index of field
    mach_write_to_2(buf_ptr + buf_len, i);
    buf_len += 2;

    // write data of field
    buf_len += mach_u64_write_much_compressed(buf_ptr + buf_len, real_data_len);
    memcpy(buf_ptr + buf_len, data_ptr, real_data_len);
    buf_len += real_data_len;
  }

  mlog_write_columnar_log_low(mtr, op, trx_id, index->space, index->id, buf_ptr,
                              buf_len);
}

static void mlog_write_insert_columnar_log(mtr_t *mtr, columnar_op_t op,
                                           trx_id_t trx_id, dict_index_t *index,
                                           const dtuple_t *entry, byte *buf_ptr,
                                           size_t buf_len) {
  ut_a(op == columnar_op_t::COLUMNAR_INDEX_INSERT);
  // write number of index field size, see REC_MAX_N_FIELDS
  mach_write_to_2(buf_ptr + buf_len, dtuple_get_n_fields(entry));
  buf_len += 2;

  MY_BITMAP null_fileds_bitmap;
  // use bitmap to record null fields
  ut_a(!bitmap_init(&null_fileds_bitmap, nullptr, dtuple_get_n_fields(entry)));
  // first we fill null fileds bitmap
  for (ulint i = 0; i < dtuple_get_n_fields(entry); ++i) {
    const auto *field = entry->fields + i;
    if (dfield_is_null(field)) {
      bitmap_set_bit(&null_fileds_bitmap, i);
    }
  }

  memcpy(buf_ptr + buf_len, null_fileds_bitmap.bitmap,
         bitmap_buffer_size(null_fileds_bitmap.n_bits));
  buf_len += bitmap_buffer_size(null_fileds_bitmap.n_bits);
  ut_a(buf_len < UNIV_PAGE_SIZE);
  bitmap_free(&null_fileds_bitmap);

  for (ulint i = 0; i < dtuple_get_n_fields(entry); ++i) {
    const auto *field = entry->fields + i;
    ut_a(!dfield_is_ext(field));
    if (!dfield_is_null(field)) {
      const byte *data = static_cast<const byte *>(dfield_get_data(field));
      ulint data_len = dfield_get_len(field);
      auto real_data_len = data_len;
      const auto *data_ptr = data;

      // for string type, we should convert type to utf8
      char tmp_buf[8192];
      if (dtype_is_non_binary_string_type(field->type.mtype,
                                          field->type.prtype) &&
          !dtype_is_utf8(field->type.prtype)) {
        data_ptr = reinterpret_cast<const byte *>(tmp_buf);
        //auto *dict_field = index->get_field(i);
        ulint charset_coll = dtype_get_charset_coll(field->type.prtype);
        CHARSET_INFO *data_cs = all_charsets[charset_coll];
        uint num_errors;

        real_data_len = copy_and_convert(tmp_buf, sizeof(tmp_buf),
                                         &my_charset_utf8mb3_general_ci,
                                         reinterpret_cast<const char *>(data),
                                         data_len, data_cs, &num_errors);
      }

      if (buf_len + real_data_len + DATA_LEN_FIELD_LENS > UNIV_PAGE_SIZE) {
        mlog_write_columnar_log_low(mtr, op, trx_id, index->space, index->id,
                                    buf_ptr, buf_len);
        memset(buf_ptr, 0, UNIV_PAGE_SIZE);
        buf_len = 0;
      }

      buf_len +=
          mach_u64_write_much_compressed(buf_ptr + buf_len, real_data_len);
      memcpy(buf_ptr + buf_len, data_ptr, real_data_len);
      buf_len += real_data_len;
    }
  }

  mlog_write_columnar_log_low(mtr, op, trx_id, index->space, index->id, buf_ptr,
                              buf_len);
}

void mlog_write_columnar_log(mtr_t *mtr, columnar_op_t op, trx_id_t trx_id,
                             dict_index_t *index, Field **mysql_fields) {
  ut_a(op == columnar_op_t::COLUMNAR_INDEX_CREATE);

  byte *buf = new byte[UNIV_PAGE_SIZE];
  std::shared_ptr<void> buf_guard(nullptr, [&buf](...) { delete[] buf; });

  size_t buf_len = 0;
  memset(buf, 0, UNIV_PAGE_SIZE);

  std::string columnar_table;
  std::string database;
  formula::get_duckdb_table_name(index, database, columnar_table,
                                 !index->is_committed());

  // write database name
  // see MAX_DATABASE_NAME_LEN
  mach_write_to_2(buf + buf_len, database.length());
  buf_len += 2;
  memcpy(buf + buf_len, database.c_str(), database.length());
  buf_len += database.length();

  // write table name
  // see MAX_TABLE_NAME_LEN
  mach_write_to_2(buf + buf_len, columnar_table.length());
  buf_len += 2;
  memcpy(buf + buf_len, columnar_table.c_str(), columnar_table.length());
  buf_len += columnar_table.length();

  mlog_write_create_columnar_log(mtr, op, trx_id, index, mysql_fields, buf,
                                 buf_len);
}

void mlog_write_columnar_log(mtr_t *mtr, columnar_op_t op, trx_id_t trx_id,
                             uint32_t space_id, uint64_t index_id,
                             const std::string &database,
                             const std::string &new_table_name,
                             const std::string &old_table_name) {
  ut_a(op == columnar_op_t::COLUMNAR_INDEX_RENAME);

  byte *buf = new byte[UNIV_PAGE_SIZE];
  std::shared_ptr<void> buf_guard(nullptr, [&buf](...) { delete[] buf; });

  size_t buf_len = 0;
  memset(buf, 0, UNIV_PAGE_SIZE);

  // write database name
  // see MAX_DATABASE_NAME_LEN
  mach_write_to_2(buf + buf_len, database.length());
  buf_len += 2;
  memcpy(buf + buf_len, database.c_str(), database.length());
  buf_len += database.length();

  // write new table name
  // see MAX_TABLE_NAME_LEN
  mach_write_to_2(buf + buf_len, new_table_name.length());
  buf_len += 2;
  memcpy(buf + buf_len, new_table_name.c_str(), new_table_name.length());
  buf_len += new_table_name.length();

  // write old table name
  mach_write_to_2(buf + buf_len, old_table_name.length());
  buf_len += 2;
  memcpy(buf + buf_len, old_table_name.c_str(), old_table_name.length());
  buf_len += old_table_name.length();

  ut_a(buf_len < UNIV_PAGE_SIZE);
  mlog_write_columnar_log_low(mtr, op, trx_id, space_id, index_id, buf,
                              buf_len);
}

void mlog_write_columnar_log(mtr_t *mtr, columnar_op_t op, trx_id_t trx_id,
                             uint32_t space_id, uint64_t index_id,
                             std::string database, std::string columnar_table) {
  ut_a(op == columnar_op_t::COLUMNAR_INDEX_DROP);

  byte *buf = new byte[UNIV_PAGE_SIZE];
  std::shared_ptr<void> buf_guard(nullptr, [&buf](...) { delete[] buf; });

  size_t buf_len = 0;
  memset(buf, 0, UNIV_PAGE_SIZE);

  // write database name
  // see MAX_DATABASE_NAME_LEN
  mach_write_to_2(buf + buf_len, database.length());
  buf_len += 2;
  memcpy(buf + buf_len, database.c_str(), database.length());
  buf_len += database.length();

  // write new table name
  // see MAX_TABLE_NAME_LEN
  mach_write_to_2(buf + buf_len, columnar_table.length());
  buf_len += 2;
  memcpy(buf + buf_len, columnar_table.c_str(), columnar_table.length());
  buf_len += columnar_table.length();

  ut_a(buf_len < UNIV_PAGE_SIZE);

  mlog_write_columnar_log_low(mtr, op, trx_id, space_id, index_id, buf,
                              buf_len);
}

void mlog_write_columnar_log(mtr_t *mtr, columnar_op_t op, trx_id_t trx_id,
                             dict_index_t *index, const dtuple_t *entry) {
  byte *buf = new byte[UNIV_PAGE_SIZE];
  std::shared_ptr<void> buf_guard(nullptr, [&buf](...) { delete[] buf; });

  size_t buf_len = 0;
  memset(buf, 0, UNIV_PAGE_SIZE);

  std::string columnar_table;
  std::string database;
  formula::get_duckdb_table_name(index, database, columnar_table,
                                 !index->is_committed());

  // write database name
  // see MAX_DATABASE_NAME_LEN
  mach_write_to_2(buf + buf_len, database.length());
  buf_len += 2;
  memcpy(buf + buf_len, database.c_str(), database.length());
  buf_len += database.length();

  // write table name
  // see MAX_TABLE_NAME_LEN
  mach_write_to_2(buf + buf_len, columnar_table.length());
  buf_len += 2;
  memcpy(buf + buf_len, columnar_table.c_str(), columnar_table.length());
  buf_len += columnar_table.length();

  switch (op) {
    case columnar_op_t::COLUMNAR_INDEX_DELETE:
      mlog_write_delete_columnar_log(mtr, op, trx_id, index, entry, buf,
                                     buf_len);
      return;
    case columnar_op_t::COLUMNAR_INDEX_INSERT:
      mlog_write_insert_columnar_log(mtr, op, trx_id, index, entry, buf,
                                     buf_len);
      return;
    default:
      LOG(ERROR) << "Unknown columnar op: " << static_cast<int>(op);
      assert(false);
  }
}

/** Logs a write of a string to a file page buffered in the buffer pool.
 Writes the corresponding log record to the mini-transaction log. */
void mlog_write_binlog(const byte *ptr, /*!< in: pointer written to */
                       uint32_t index_num, uint64_t pos,
                       ulint len,  /*!< in: string length */
                       mtr_t *mtr) /*!< in: mini-transaction handle */
{
  byte *log_ptr;

  ut_ad(ptr && mtr);
  ut_ad(len <= UNIV_PAGE_SIZE);
  mtr->set_binlog_in_redo(true);

  mlog_add_last_record_check_bits(mtr);
  log_ptr = mlog_open_binlog(mtr, 21);

  ut_ad(log_ptr != NULL);

  log_ptr = mlog_write_initial_binlog_log_record(MLOG_GAIA_BINLOG_DATA,
                                                 innodb::BINLOG_REDO_OP_NORMAL,
                                                 index_num, pos, log_ptr, mtr);

  mlog_close(mtr, log_ptr);

  mlog_catenate_string(mtr, ptr, len);
}

void mlog_write_binlog_truncate(uint32_t index_num,
                                uint64_t valid_pos,
                                mtr_t *mtr) /*!< in: mini-transaction handle */
{
  byte *log_ptr;

  ut_ad(mtr);
  mtr->set_binlog_in_redo(true);

  mlog_add_last_record_check_bits(mtr);
  log_ptr = mlog_open_binlog(mtr, 21);

  ut_ad(log_ptr != NULL);

  log_ptr = mlog_write_initial_binlog_log_record(
      MLOG_GAIA_BINLOG_DATA, innodb::BINLOG_REDO_OP_TRUNCATE, index_num,
      valid_pos, log_ptr, mtr);

  mlog_close(mtr, log_ptr);
}

void parse_check_bits(ulint *body_len, uint32_t *check_bits_len) {
  *check_bits_len = 0;
  bool has_check_bits =
      (*body_len & innodb::RECORD_CHECK_FLAGS) == innodb::RECORD_CHECK_FLAGS;

  if (has_check_bits) {
  bool has_page_check_bits =
      (*body_len & innodb::PAGE_CHECK_FLAGS) == innodb::PAGE_CHECK_FLAGS;

  // body_len = real_body_len + check_bits_len
  *body_len ^= (has_page_check_bits ? innodb::PAGE_CHECK_FLAGS
                                    : innodb::RECORD_CHECK_FLAGS);
  *check_bits_len = has_page_check_bits ? innodb::PAGE_CHECK_BITS_LEN +
                                              innodb::RECORD_CHECK_BITS_LEN
                                        : innodb::RECORD_CHECK_BITS_LEN;
  }
}

/** Parses an initial log record written by mlog_write_initial_log_record.
 @return parsed record end, NULL if not a complete record */
byte *mlog_parse_initial_log_record(
    const byte *ptr,     /*!< in: buffer */
    const byte *end_ptr, /*!< in: buffer end */
    mlog_id_t *type,     /*!< out: log record type: MLOG_1BYTE, ... */
    space_id_t *space,   /*!< out: space id */
    page_no_t *page_no,  /*!< out: page number */
    ulint *body_len,     /*!< out: body length */
    uint32_t *check_bits_len)     
{
  if (end_ptr < ptr + 1) {
    return (nullptr);
  }

  *type = (mlog_id_t)((ulint)*ptr & ~MLOG_SINGLE_REC_FLAG);
  ut_ad(*type <= MLOG_BIGGEST_TYPE);

  ptr++;

  if (end_ptr < ptr + 2) {
    return (nullptr);
  }

  *space = mach_parse_compressed(&ptr, end_ptr);

  if (ptr != nullptr) {
    *page_no = mach_parse_compressed(&ptr, end_ptr);
  }

  if (ptr != NULL) {
    if (end_ptr < ptr + 3) {
      return (nullptr);
    }
    *body_len = mach_read_from_3(ptr);
    ptr += 3;

    *check_bits_len = 0;
    parse_check_bits(body_len, check_bits_len);
  }

  return (const_cast<byte *>(ptr));
}

/** Parses a log record written by mlog_write_ulint or mlog_write_ull.
 @return parsed record end, NULL if not a complete record or a corrupt record */
byte *mlog_parse_nbytes(
    mlog_id_t type,      /*!< in: log record type: MLOG_1BYTE, ... */
    const byte *ptr,     /*!< in: buffer */
    const byte *end_ptr, /*!< in: buffer end */
    byte *page,          /*!< in: page where to apply the log
                         record, or NULL */
    void *page_zip)      /*!< in/out: compressed page, or NULL */
{
  ulint offset;
  ulint val;
  uint64_t dval;

  ut_a(type <= MLOG_8BYTES);
  ut_a(!page || !page_zip || !fil_page_index_page_check(page));

  if (end_ptr < ptr + 2) {
    return (nullptr);
  }

  offset = mach_read_from_2(ptr);
  ptr += 2;

  if (offset >= UNIV_PAGE_SIZE) {
    recv_sys->found_corrupt_log = true;

    return (nullptr);
  }

  if (type == MLOG_8BYTES) {
    dval = mach_u64_parse_compressed(&ptr, end_ptr);

    if (ptr == nullptr) {
      return (nullptr);
    }

    if (page) {
      if (page_zip) {
        mach_write_to_8(((page_zip_des_t *)page_zip)->data + offset, dval);
      }
      mach_write_to_8(page + offset, dval);
    }

    return (const_cast<byte *>(ptr));
  }

  val = mach_parse_compressed(&ptr, end_ptr);

  if (ptr == nullptr) {
    return (nullptr);
  }

  switch (type) {
    case MLOG_1BYTE:
      if (val > 0xFFUL) {
        goto corrupt;
      }
      if (page) {
        if (page_zip) {
          mach_write_to_1(((page_zip_des_t *)page_zip)->data + offset, val);
        }
        mach_write_to_1(page + offset, val);
      }
      break;
    case MLOG_2BYTES:
      if (val > 0xFFFFUL) {
        goto corrupt;
      }
      if (page) {
        if (page_zip) {
          mach_write_to_2(((page_zip_des_t *)page_zip)->data + offset, val);
        }
        mach_write_to_2(page + offset, val);
      }
      break;
    case MLOG_4BYTES:
      if (page) {
        if (page_zip) {
          mach_write_to_4(((page_zip_des_t *)page_zip)->data + offset, val);
        }
        mach_write_to_4(page + offset, val);
      }
      break;
    default:
    corrupt:
      recv_sys->found_corrupt_log = true;
      ptr = nullptr;
  }

  return (const_cast<byte *>(ptr));
}

/** Writes 1, 2 or 4 bytes to a file page. Writes the corresponding log
 record to the mini-transaction log if mtr is not NULL. */
void mlog_write_ulint(
    byte *ptr,      /*!< in: pointer where to write */
    ulint val,      /*!< in: value to write */
    mlog_id_t type, /*!< in: MLOG_1BYTE, MLOG_2BYTES, MLOG_4BYTES */
    mtr_t *mtr)     /*!< in: mini-transaction handle */
{
  switch (type) {
    case MLOG_1BYTE:
      mach_write_to_1(ptr, val);
      break;
    case MLOG_2BYTES:
      mach_write_to_2(ptr, val);
      break;
    case MLOG_4BYTES:
      mach_write_to_4(ptr, val);
      break;
    default:
      ut_error;
  }

  if (mtr == nullptr) {
    return;
  }

  /* If no logging is requested, we may return now */
  byte *log_ptr = nullptr;
  mlog_add_last_record_check_bits(mtr);
  if (!mlog_open(mtr, REDO_LOG_INITIAL_INFO_SIZE + 2 + 5, log_ptr)) {
    return;
  }

  log_ptr = mlog_write_initial_log_record_fast(ptr, type, log_ptr, mtr);

  mach_write_to_2(log_ptr, page_offset(ptr));
  log_ptr += 2;

  log_ptr += mach_write_compressed(log_ptr, val);

  mlog_close(mtr, log_ptr);
}

/** Writes 8 bytes to a file page. Writes the corresponding log
 record to the mini-transaction log, only if mtr is not NULL */
void mlog_write_ull(byte *ptr,    /*!< in: pointer where to write */
                    uint64_t val, /*!< in: value to write */
                    mtr_t *mtr)   /*!< in: mini-transaction handle */
{
  mach_write_to_8(ptr, val);

  if (mtr == nullptr) {
    return;
  }

  /* If no logging is requested, we may return now */
  mlog_add_last_record_check_bits(mtr);
  byte *log_ptr = nullptr;
  if (!mlog_open(mtr, REDO_LOG_INITIAL_INFO_SIZE + 2 + 9, log_ptr)) {
    return;
  }

  log_ptr = mlog_write_initial_log_record_fast(ptr, MLOG_8BYTES, log_ptr, mtr);

  mach_write_to_2(log_ptr, page_offset(ptr));
  log_ptr += 2;

  log_ptr += mach_u64_write_compressed(log_ptr, val);

  mlog_close(mtr, log_ptr);
}

#ifndef UNIV_HOTBACKUP
/** Writes a string to a file page buffered in the buffer pool. Writes the
 corresponding log record to the mini-transaction log. */
void mlog_write_string(byte *ptr,       /*!< in: pointer where to write */
                       const byte *str, /*!< in: string to write */
                       ulint len,       /*!< in: string length */
                       mtr_t *mtr)      /*!< in: mini-transaction handle */
{
  ut_ad(ptr && mtr);
  ut_a(len < UNIV_PAGE_SIZE);

  memcpy(ptr, str, len);

  mlog_log_string(ptr, len, mtr);
}

/** Logs a write of a string to a file page buffered in the buffer pool.
 Writes the corresponding log record to the mini-transaction log. */
void mlog_log_string(byte *ptr,  /*!< in: pointer written to */
                     ulint len,  /*!< in: string length */
                     mtr_t *mtr) /*!< in: mini-transaction handle */
{
  byte *log_ptr = nullptr;

  ut_ad(ptr && mtr);
  ut_ad(len <= UNIV_PAGE_SIZE);

  mlog_add_last_record_check_bits(mtr);
  /* If no logging is requested, we may return now */
  if (!mlog_open(mtr, 33, log_ptr)) {
    return;
  }

  log_ptr =
      mlog_write_initial_log_record_fast(ptr, MLOG_WRITE_STRING, log_ptr, mtr);
  mach_write_to_2(log_ptr, page_offset(ptr));
  log_ptr += 2;

  mach_write_to_2(log_ptr, len);
  log_ptr += 2;

  mlog_close(mtr, log_ptr);

  mlog_catenate_string(mtr, ptr, len);
}
#endif /* !UNIV_HOTBACKUP */

/** Parses a log record written by mlog_write_string.
 @return parsed record end, NULL if not a complete record */
byte *mlog_parse_string(
    byte *ptr,      /*!< in: buffer */
    byte *end_ptr,  /*!< in: buffer end */
    byte *page,     /*!< in: page where to apply the log record, or NULL */
    void *page_zip) /*!< in/out: compressed page, or NULL */
{
  ulint offset;
  ulint len;

  ut_a(!page || !page_zip ||
       (fil_page_get_type(page) != FIL_PAGE_INDEX &&
        fil_page_get_type(page) != FIL_PAGE_RTREE));

  if (end_ptr < ptr + 4) {
    return (nullptr);
  }

  offset = mach_read_from_2(ptr);
  ptr += 2;
  len = mach_read_from_2(ptr);
  ptr += 2;

  if (offset >= UNIV_PAGE_SIZE || len + offset > UNIV_PAGE_SIZE) {
    recv_sys->found_corrupt_log = true;

    return (nullptr);
  }

  if (end_ptr < ptr + len) {
    return (nullptr);
  }

  if (page) {
    if (page_zip) {
      memcpy(((page_zip_des_t *)page_zip)->data + offset, ptr, len);
    }
    memcpy(page + offset, ptr, len);
  }

  return (ptr + len);
}

byte *mlog_parse_index_8027(byte *ptr, const byte *end_ptr, bool comp,
                            dict_index_t **index) {
  ulint i;
  dict_table_t *table;
  dict_index_t *ind;
  bool instant = false;
  uint16_t n, n_uniq;
  uint16_t n_inst_cols = 0;

  if (comp) {
    if (end_ptr < ptr + 4) {
      return (nullptr);
    }
    n = mach_read_from_2(ptr);
    ptr += 2;
    if ((n & 0x8000) != 0) {
      /* This is instant fields,
      see also mlog_open_and_write_index() */
      instant = true;
      n_inst_cols = n & ~0x8000;
      n = mach_read_from_2(ptr);
      ptr += 2;
      ut_ad((n & 0x8000) == 0);
      ut_ad(n_inst_cols <= n);

      if (end_ptr < ptr + 2) {
        return (nullptr);
      }
    }
    n_uniq = mach_read_from_2(ptr);
    ptr += 2;
    ut_ad(n_uniq <= n);
    if (end_ptr < ptr + n * 2) {
      return (nullptr);
    }
  } else {
    n = n_uniq = 1;
  }
  table = dict_mem_table_create("LOG_DUMMY", DICT_HDR_SPACE, n, 0, 0,
                                comp ? DICT_TF_COMPACT : 0, 0);
  if (instant) {
    table->set_instant_cols(n_inst_cols);
  }

  ind = dict_mem_index_create("LOG_DUMMY", "LOG_DUMMY", DICT_HDR_SPACE, 0, n);
  ind->table = table;
  ind->n_uniq = (unsigned int)n_uniq;
  if (n_uniq != n) {
    ut_a(n_uniq + DATA_ROLL_PTR <= n);
    ind->type = DICT_CLUSTERED;
  }
  if (comp) {
    for (i = 0; i < n; i++) {
      ulint len = mach_read_from_2(ptr);
      ptr += 2;
      /* The high-order bit of len is the NOT NULL flag;
      the rest is 0 or 0x7fff for variable-length fields,
      and 1..0x7ffe for fixed-length fields. */
      dict_mem_table_add_col(
          table, nullptr, nullptr,
          ((len + 1) & 0x7fff) <= 1 ? DATA_BINARY : DATA_FIXBINARY,
          len & 0x8000 ? DATA_NOT_NULL : 0, len & 0x7fff, true);

      /* The is_ascending flag does not matter during
      redo log apply, because we do not compare for
      "less than" or "greater than". */
      dict_index_add_col(ind, table, table->get_col(i), 0, true);
    }
    dict_table_add_system_columns(table, table->heap);
    if (n_uniq != n) {
      /* Identify DB_TRX_ID and DB_ROLL_PTR in the index. */
      ut_a(DATA_TRX_ID_LEN == ind->get_col(DATA_TRX_ID - 1 + n_uniq)->len);
      ut_a(DATA_ROLL_PTR_LEN == ind->get_col(DATA_ROLL_PTR - 1 + n_uniq)->len);
      ind->fields[DATA_TRX_ID - 1 + n_uniq].col = &table->cols[n + DATA_TRX_ID];
      ind->fields[DATA_ROLL_PTR - 1 + n_uniq].col =
          &table->cols[n + DATA_ROLL_PTR];
    }

    if (ind->is_clustered() && ind->table->has_instant_cols()) {
      ind->instant_cols = true;
      ind->n_instant_nullable =
          ind->get_n_nullable_before(ind->get_instant_fields());
    } else {
      ind->instant_cols = false;
      ind->n_instant_nullable = ind->n_nullable;
    }
  }
  /* avoid ut_ad(index->cached) in dict_index_get_n_unique_in_tree */
  ind->cached = true;
  *index = ind;
  return (ptr);
}

#ifndef UNIV_HOTBACKUP
/* logical_pos 2 bytes, phy_pos 2 bytes, v_added 1 byte, v_dropped 1 byte */
constexpr size_t inst_col_info_size = 6;

/** Calculate total size needed to log index information.
@param[in]   index         index
@param[in]   size          size passed from caller
@param[in]   n             number of fields in index
@param[in]   is_comp       true if COMP
@param[in]   is_versioned  if table has row versions
@param[in]   is_instant    true if table has INSTANT cols
@param[out]  size_needed   total size needed on REDO LOG */
static void log_index_get_size_needed(const dict_index_t *index, size_t size,
                                      uint16_t n, bool is_comp,
                                      bool is_versioned, bool is_instant,
                                      size_t &size_needed) {
  auto size_for_versioned_fields = [](const dict_index_t *ind) {
    size_t _size = 0;
    /* 2 bytes for number of columns with version */
    _size += 2;

    size_t n_versioned_fields = ind->table->get_n_instant_add_cols() +
                                ind->table->get_n_instant_drop_cols();
    ut_ad(n_versioned_fields != 0);

    _size += n_versioned_fields * inst_col_info_size;
    return (_size);
  };

  ut_ad(size_needed == 0);

  size_needed += REDO_LOG_INITIAL_INFO_SIZE + size;

  /* 1 byte to log INDEX_LOG_VERSION */
  size_needed += 1;

  /* 1 byte to log flag */
  size_needed += 1;

  if (!is_versioned && !is_comp) {
    return;
  }

  /* 2 bytes to log n */
  size_needed += 2;

  if (!is_comp) {
    ut_ad(is_versioned);
    size_needed += size_for_versioned_fields(index);
    return;
  }

  if (is_instant) {
    /* 2 bytes to log n_instant_cols */
    size_needed += 2;
  }

  /* 2 bytes to log n_uniq */
  size_needed += 2;

  /* 2 bytes needed for each (n) field to store it's len */
  size_needed += n * 2;

  if (is_versioned) {
    size_needed += size_for_versioned_fields(index);
  }
}

/** Log the index log version.
@param[in]     version  1 byte index log version
@param[in,out] log_ptr  REDO LOG buffer pointer */
static void log_index_log_version(uint8_t version, byte *&log_ptr) {
  mach_write_to_1(log_ptr, version);
  log_ptr += 1;
}

/** Log the flag.
@param[in]     flag     1 byte flag to be logged
@param[in,out] log_ptr  REDO LOG buffer pointer */
static void log_index_flag(uint8_t flag, byte *&log_ptr) {
  mach_write_to_1(log_ptr, flag);
  log_ptr += 1;
}

/** Log the number of fields in index.
@param[in]      index         index
@param[in]      n             number of fields
@param[in]      rec           index record
@param[in]      is_comp       true if COMP
@param[in]      is_versioned  true if table has row versions
@param[in]      is_instant    true if table has INSTANT cols
@param[in,out]  log_ptr       REDO LOG buffer pointer */
static void log_index_column_counts(const dict_index_t *index, uint16_t n,
                                    const byte *rec, bool is_comp,
                                    bool is_versioned, bool is_instant,
                                    byte *&log_ptr) {
  /* Only clustered index can have versions */
  ut_ad(!is_versioned || index->is_clustered());

  if (!is_versioned && !is_comp) {
    return;
  }

  /* log n */
  mach_write_to_2(log_ptr, n);
  log_ptr += 2;

  if (!is_comp) {
    ut_ad(is_versioned);
    return;
  }

  if (is_instant) {
    mach_write_to_2(log_ptr, index->get_instant_fields());
    log_ptr += 2;
  }

  /* log n_uniq */
  uint16_t n_uniq;
  if (page_is_leaf(page_align(rec))) {
    n_uniq = dict_index_get_n_unique_in_tree(index);
  } else {
    n_uniq = dict_index_get_n_unique_in_tree_nonleaf(index);
  }
  ut_ad(n_uniq <= n);
  mach_write_to_2(log_ptr, n_uniq);
  log_ptr += 2;
}

/** Close, allocate and reopen LOG pointer buffer.
@param[in]      log_ptr   pointer to log buffer
@param[in,out]  log_start start of currently allocated buffer
@param[in,out]  log_end   end of currently allocated buffer
@param[in]      mtr       mini transaction
@param[in,out]  alloc     size allocated as of now on log
@param[in,out]  total     total size needed on log */
static bool close_and_reopen_log(byte *&log_ptr, const byte *&log_start,
                                 const byte *&log_end, mtr_t *&mtr,
                                 size_t &alloc, size_t &total) {
  mlog_close(mtr, log_ptr);
  ut_a(total > (ulint)(log_ptr - log_start));
  total -= log_ptr - log_start;
  alloc = total;

  if (alloc > mtr_buf_t::MAX_DATA_SIZE) {
    alloc = mtr_buf_t::MAX_DATA_SIZE;
  }

  if (!mlog_open(mtr, alloc, log_ptr)) {
    /* logging is disabled */
    return false;
  }
  log_start = log_ptr;
  log_end = log_ptr + alloc;

  return true;
}

template <typename F>
/** Log index field len info.
@param[in]  index         index
@param[in]  n             number of fields
@param[in]  is_versioned  true if table has row versions
@param[in,out]  f         vector of fields with versions
@param[in]  log_ptr       log buffer pointer
@param[in]  func          callback to check size reopen log buffer */
static bool log_index_fields(const dict_index_t *index, uint16_t n,
                             bool is_versioned, std::vector<dict_field_t *> &f,
                             byte *&log_ptr, F &func) {
  /* Write metadata for each field. Log the fields in their logical order. */
  for (size_t i = 0; i < n; i++) {
    dict_field_t *field = index->get_field(i);
    const dict_col_t *col = field->col;
    ulint len = field->fixed_len;
    ut_ad(len < 0x7fff);

    if (len == 0 && (DATA_BIG_COL(col))) {
      /* variable-length field with maximum length > 255 */
      len = 0x7fff;
    }

    if (col->prtype & DATA_NOT_NULL) {
      len |= 0x8000;
    }

    if (!func(2)) {
      return false;
    }

    mach_write_to_2(log_ptr, len);
    log_ptr += 2;

    if (is_versioned) {
      if (col->is_instant_added() || col->is_instant_dropped()) {
        f.push_back(field);
      }
    }
  }

  return true;
}

template <typename F>
/** Log fields with version.
@param[in]  f             vector of fields with versions
@param[in]  log_ptr       log buffer pointer
@param[in]  func          callback to check size reopen log buffer
@param[in]  index         index to fetch field's logical position */
static bool log_index_versioned_fields(const std::vector<dict_field_t *> &f,
                                       byte *&log_ptr, F &func,
                                       const dict_index_t *index) {
  uint16_t n_inst = f.size();
  ut_ad(n_inst > 0);

  if (!func(2)) {
    return false;
  }
  mach_write_to_2(log_ptr, n_inst);
  log_ptr += 2;

  for (auto field : f) {
    uint16_t logical_pos = index->get_logical_pos(field->get_phy_pos());
    ut_a(logical_pos != UINT16_UNDEFINED);

    /* Maximum columns could be 1017. Which needs maximum 10 bits. So we can
    use MSB to indicate if version info follows.
           - - - - - -[----------]
           ^ ^           ^
           | |           |
           | |           | 10 bits phy pos
           | |
           | | 15th bit indicates drop version info follows.
           | 16th bit indicates add version info follows. */
    uint16_t phy_pos = field->get_phy_pos();

    ut_ad(field->col->is_instant_added() || field->col->is_instant_dropped());

    if (field->col->is_instant_added()) {
      /* Set 16th bit in phy_pos to indicate presence of version added */
      phy_pos |= 0x8000;
    }

    if (field->col->is_instant_dropped()) {
      /* Set 15th bit in phy_pos to indicate presence of version added */
      phy_pos |= 0x4000;
    }

    if (!func(6)) {
      return false;
    }

    mach_write_to_2(log_ptr, logical_pos);
    log_ptr += 2;

    mach_write_to_2(log_ptr, phy_pos);
    log_ptr += 2;

    if (field->col->is_instant_added()) {
      uint8_t v = field->col->get_version_added();
      mach_write_to_1(log_ptr, v);
      log_ptr += 1;
    }

    if (field->col->is_instant_dropped()) {
      uint8_t v = field->col->get_version_dropped();
      mach_write_to_1(log_ptr, v);
      log_ptr += 1;
    }
  }
  return true;
}
#endif

bool mlog_open_and_write_index(mtr_t *mtr, const byte *rec,
                               const dict_index_t *index, mlog_id_t type,
                               size_t size, byte *&log_ptr) {
#ifndef UNIV_HOTBACKUP
  ut_ad(page_rec_is_comp(rec) == dict_table_is_comp(index->table));
  const bool is_instant = index->has_instant_cols();
  const bool is_versioned = index->has_row_versions();
  const bool is_comp = dict_table_is_comp(index->table);

  const byte *log_start;
  const byte *log_end;

  uint16_t n = is_versioned ? index->get_n_total_fields()
                            : dict_index_get_n_fields(index);
  /* For spatial index, on non-leaf page, we just keep
  2 fields, MBR and page no. */
  if (dict_index_is_spatial(index) && !page_is_leaf(page_align(rec))) {
    n = DICT_INDEX_SPATIAL_NODEPTR_SIZE;
  }

  size_t size_needed = 0;
  log_index_get_size_needed(index, size, n, is_comp, is_versioned, is_instant,
                            size_needed);
  size_t total = size_needed;
  size_t alloc = total;
  if (alloc > mtr_buf_t::MAX_DATA_SIZE) {
    alloc = mtr_buf_t::MAX_DATA_SIZE;
  }

  mlog_add_last_record_check_bits(mtr);
  if (!mlog_open(mtr, alloc, log_ptr)) {
    /* logging is disabled */
    return (false);
  }

  log_start = log_ptr;
  log_end = log_ptr + alloc;

  log_ptr = mlog_write_initial_log_record_fast(rec, type, log_ptr, mtr);

  uint8_t index_log_version = INDEX_LOG_VERSION;
  log_index_log_version(index_log_version, log_ptr);

  uint8_t flag = 0;
  if (is_instant) SET_INSTANT(flag);
  if (is_versioned) SET_VERSIONED(flag);
  if (is_comp) SET_COMPACT(flag);
  log_index_flag(flag, log_ptr);

  log_index_column_counts(index, n, rec, is_comp, is_versioned, is_instant,
                          log_ptr);

  /* List of INSTANT fields to be logged */
  std::vector<dict_field_t *> instant_fields_to_log;

  /* To check _size is available on buffer. If not, close and reopen buffer */
  auto f = [&](const size_t _size) {
    if (log_ptr + _size > log_end) {
      if (!close_and_reopen_log(log_ptr, log_start, log_end, mtr, alloc,
                                total)) {
        return false;
      }
    }
    return true;
  };

  if (is_comp) {
    /* Write fields info. */
    if (!log_index_fields(index, n, is_versioned, instant_fields_to_log,
                          log_ptr, f)) {
      return false;
    }
  } else if (is_versioned) {
    for (size_t i = 0; i < n; i++) {
      dict_field_t *field = index->get_field(i);
      const dict_col_t *col = field->col;
      if (col->is_instant_added() || col->is_instant_dropped()) {
        instant_fields_to_log.push_back(field);
      }
    }
  }

  if (!instant_fields_to_log.empty()) {
    ut_ad(is_versioned);
    /* Log INSTANT ADD/DROP fields */
    if (!log_index_versioned_fields(instant_fields_to_log, log_ptr, f, index)) {
      return false;
    }
  }

  if (size == 0) {
    mlog_close(mtr, log_ptr);
    log_ptr = nullptr;
  } else if (log_ptr + size > log_end) {
    mlog_close(mtr, log_ptr);
    bool success = mlog_open(mtr, size, log_ptr);
    ut_a(success);
  }

  return (log_ptr != nullptr);
#else  /* !UNIV_HOTBACKUP */
  return (false);
#endif /* !UNIV_HOTBACKUP */
}

/** Read 2 bytes from log buffer.
@param[in]   ptr      pointer to buffer
@param[in]   end_ptr  pointer to end of buffer
@param[out]  val      read 2 bytes value */
static byte *read_2_bytes(byte *ptr, const byte *end_ptr, uint16_t &val) {
  if (end_ptr < ptr + 2) {
    return (nullptr);
  }
  val = mach_read_from_2(ptr);
  ptr += 2;
  return ptr;
}

/** Read 1 bytes from log buffer.
@param[in]   ptr      pointer to buffer
@param[in]   end_ptr  pointer to end of buffer
@param[out]  val      read 2 bytes value */
static byte *read_1_bytes(byte *ptr, const byte *end_ptr, uint8_t &val) {
  if (end_ptr < ptr + 1) {
    return (nullptr);
  }
  val = mach_read_from_1(ptr);
  ptr += 1;
  return ptr;
}

/** Read number of columns for index.
@param[in]   ptr           pointer to buffer
@param[in]   end_ptr       pointer to end of buffer
@param[in]   is_comp       true if COMP
@param[in]   is_versioned  true if table has row versions
@param[in]   is_instant    true if table has INSTANT cols
@param[out]  n             number of index fields
@param[out]  n_uniq        n_uniq for index
@param[out]  inst_cols     number of column before first instant add was done.
@return pointer to buffer. */
static byte *parse_index_column_counts(byte *ptr, const byte *end_ptr,
                                       bool is_comp, bool is_versioned,
                                       bool is_instant, uint16_t &n,
                                       uint16_t &n_uniq, uint16_t &inst_cols) {
  if (!is_versioned && !is_comp) {
    n = n_uniq = 1;
    inst_cols = 0;
    return ptr;
  }

  /* Parse n */
  ptr = read_2_bytes(ptr, end_ptr, n);
  if (ptr == nullptr) {
    return ptr;
  }

  if (!is_comp) {
    ut_ad(is_versioned);
    return ptr;
  }

  if (is_instant) {
    ptr = read_2_bytes(ptr, end_ptr, inst_cols);
    if (ptr == nullptr) {
      return ptr;
    }
  }

  ptr = read_2_bytes(ptr, end_ptr, n_uniq);
  if (ptr == nullptr) {
    return ptr;
  }
  ut_ad(n_uniq <= n);

  return ptr;
}

/** Parse index fields.
@param[in]       ptr      pointer to buffer
@param[in]       end_ptr  pointer to end of buffer
@param[in]       n        number of fields
@param[in]       n_uniq   n_uniq
@param[in]       is_versioned  true if table has row versions
@param[in,out]   ind      dummy index
@param[in,out]   table    dummy table
@return pointer to log buffer */
static byte *parse_index_fields(byte *ptr, const byte *end_ptr, uint16_t n,
                                uint16_t n_uniq, bool is_versioned,
                                dict_index_t *&ind, dict_table_t *&table) {
  for (size_t i = 0; i < n; i++) {
    /* For redundant, col len metadata isn't needed for recovery as it is
    part of record itself. */
    uint16_t len = 0;
    ptr = read_2_bytes(ptr, end_ptr, len);
    if (ptr == nullptr) {
      return (nullptr);
    }

    uint32_t phy_pos = UINT32_UNDEFINED;
    uint8_t v_added = UINT8_UNDEFINED;
    uint8_t v_dropped = UINT8_UNDEFINED;

    /* The high-order bit of len is the NOT NULL flag;
    the rest is 0 or 0x7fff for variable-length fields,
    and 1..0x7ffe for fixed-length fields. */
    dict_mem_table_add_col(
        table, nullptr, nullptr,
        ((len + 1) & 0x7fff) <= 1 ? DATA_BINARY : DATA_FIXBINARY,
        len & 0x8000 ? DATA_NOT_NULL : 0, len & 0x7fff, true, phy_pos, v_added,
        v_dropped);

    /* The is_ascending flag does not matter during
    redo log apply, because we do not compare for
    "less than" or "greater than". */
    dict_index_add_col(ind, table, table->get_col(i), 0, true);
  }

  dict_table_add_system_columns(table, table->heap);

  /* Identify DB_TRX_ID and DB_ROLL_PTR in the index. */
  if (is_versioned || (n_uniq != n)) {
    size_t i = 0;
    i = DATA_TRX_ID - 1 + n_uniq;
    ut_a(DATA_TRX_ID_LEN == ind->get_col(i)->len);
    ind->fields[i].col = &table->cols[n + DATA_TRX_ID];
    ind->fields[i].col->set_phy_pos(table->cols[i].get_phy_pos());

    i = DATA_ROLL_PTR - 1 + n_uniq;
    ut_a(DATA_ROLL_PTR_LEN == ind->get_col(i)->len);
    ind->fields[i].col = &table->cols[n + DATA_ROLL_PTR];
    ind->fields[i].col->set_phy_pos(table->cols[i].get_phy_pos());
  }

  table->initial_col_count = table->current_col_count = table->total_col_count =
      n;
  return ptr;
}

struct Field_instant_info {
  uint16_t logical_pos{UINT16_UNDEFINED};
  uint16_t phy_pos{UINT16_UNDEFINED};
  uint8_t v_added{UINT8_UNDEFINED};
  uint8_t v_dropped{UINT8_UNDEFINED};
};

using instant_fields_list_t = std::vector<Field_instant_info>;

/** Parse the fields with versions.
@param[in]   ptr       pointer to buffer
@param[in]   end_ptr   pointer to end of buffer
@param[out]  f         vector of fields with versions
@param[out]  crv       current row version
@param[out]  n_dropped number of dropped columns */
static byte *parse_index_versioned_fields(byte *ptr, const byte *end_ptr,
                                          instant_fields_list_t &f,
                                          uint16_t &crv, size_t &n_dropped) {
  uint16_t n_inst = 0;
  ptr = read_2_bytes(ptr, end_ptr, n_inst);
  if (ptr == nullptr) return (nullptr);
  ut_ad(n_inst > 0);

  for (auto i = n_inst; i > 0; --i) {
    Field_instant_info info;

    ptr = read_2_bytes(ptr, end_ptr, info.logical_pos);
    if (ptr == nullptr) return (nullptr);

    ptr = read_2_bytes(ptr, end_ptr, info.phy_pos);
    if (ptr == nullptr) return (nullptr);

    if ((info.phy_pos & 0x8000) != 0) {
      info.phy_pos &= ~0x8000;

      /* Read v_added */
      ptr = read_1_bytes(ptr, end_ptr, info.v_added);
      if (ptr == nullptr) return (nullptr);
      ut_ad(info.v_added != UINT8_UNDEFINED);
      crv = std::max(crv, (uint16_t)info.v_added);
    }

    if ((info.phy_pos & 0x4000) != 0) {
      info.phy_pos &= ~0x4000;

      /* Read v_dropped */
      ptr = read_1_bytes(ptr, end_ptr, info.v_dropped);
      if (ptr == nullptr) return (nullptr);
      ut_ad(info.v_dropped != UINT8_UNDEFINED);
      crv = std::max(crv, (uint16_t)info.v_dropped);
      n_dropped++;
    }

    ut_ad((info.phy_pos & 0xC000) == 0);

    f.push_back(info);
  }

  return (ptr);
}

/** Update the version info for the columns.
NOTE : fields are logged in their physical order so with the help of phy_pos,
it's easy to locate them.
@param[in]      f      fields with versions
@param[in,out]  index  dummy index */
static void update_instant_info(instant_fields_list_t f, dict_index_t *index) {
  if (f.empty()) {
    return;
  }

  size_t n_added = 0;
  size_t n_dropped = 0;

  for (auto field : f) {
    bool is_added = field.v_added != UINT8_UNDEFINED;
    bool is_dropped = field.v_dropped != UINT8_UNDEFINED;
    ut_ad(is_added || is_dropped);

    dict_col_t *col = index->fields[field.logical_pos].col;

    if (is_dropped) {
      col->set_version_dropped(field.v_dropped);
      n_dropped++;
    }

    if (is_added) {
      col->set_version_added(field.v_added);
      n_added++;
    }

    col->set_phy_pos(field.phy_pos);
  }

  index->table->initial_col_count -= n_added;
  index->table->current_col_count -= n_dropped;
  index->table->n_cols -= n_dropped;
}

/** To populate dummy fields. Used only in case of REDUNDANT row format.
@param[in,out]  index    dummy index
@param[in,out]  table    dummy table
@param[in]      n        number of fields
@param[in]     is_comp  true if COMP
*/
static void populate_dummy_fields(dict_index_t *index, dict_table_t *table,
                                  size_t n IF_DEBUG(, bool is_comp)) {
  ut_ad(!is_comp);

  uint32_t phy_pos = UINT32_UNDEFINED;
  uint8_t v_added = UINT8_UNDEFINED;
  uint8_t v_dropped = UINT8_UNDEFINED;
  size_t dummy_len = 10;

  for (size_t i = 0; i < n; i++) {
    dict_mem_table_add_col(table, nullptr, nullptr, DATA_BINARY, DATA_NOT_NULL,
                           dummy_len, true, phy_pos, v_added, v_dropped);

    dict_index_add_col(index, table, table->get_col(i), 0, true);
  }
  table->initial_col_count = table->current_col_count = table->total_col_count =
      n;
}

static byte *parse_index_log_version(byte *ptr, const byte *end_ptr,
                                     uint8_t &version) {
  ptr = read_1_bytes(ptr, end_ptr, version);
  if (ptr == nullptr) return nullptr;

  return ptr;
}
static byte *parse_index_flag(byte *ptr, const byte *end_ptr, uint8_t &flag) {
  ptr = read_1_bytes(ptr, end_ptr, flag);
  if (ptr == nullptr) return nullptr;

  return ptr;
}

byte *mlog_parse_index(byte *ptr, const byte *end_ptr, dict_index_t **index) {
  /* Read the 1 byte for index log version */
  uint8_t index_log_version = 0;
  ptr = parse_index_log_version(ptr, end_ptr, index_log_version);
  if (ptr == nullptr) {
    return nullptr;
  }

  ut_a(index_log_version <= INDEX_LOG_VERSION);
  if (index_log_version == 0) {
    return mlog_parse_index_8029(ptr, end_ptr, index);
  }

  ut_ad(index_log_version == INDEX_LOG_VERSION);

  /* Read the 1 byte flag */
  uint8_t flag = 0;
  ptr = parse_index_flag(ptr, end_ptr, flag);
  if (ptr == nullptr) {
    return nullptr;
  }

  const bool is_comp = IS_COMPACT(flag);
  const bool is_versioned = IS_VERSIONED(flag);
  const bool is_instant = IS_INSTANT(flag);

  /* Read n and n_uniq */
  uint16_t n = 0;
  uint16_t n_uniq = 0;
  uint16_t inst_cols = 0;
  ptr = parse_index_column_counts(ptr, end_ptr, is_comp, is_versioned,
                                  is_instant, n, n_uniq, inst_cols);
  if (ptr == nullptr) {
    return ptr;
  }
  ut_ad(inst_cols == 0 || is_instant);

  /* Create a dummy dict_table_t */
  dict_table_t *table =
      dict_mem_table_create(RECOVERY_INDEX_TABLE_NAME, DICT_HDR_SPACE, n, 0, 0,
                            is_comp ? DICT_TF_COMPACT : 0, 0);

  if (inst_cols > 0) {
    table->set_instant_cols(inst_cols);
  }

  /* Create a dummy dict_index_t */
  dict_index_t *ind =
      dict_mem_index_create(RECOVERY_INDEX_TABLE_NAME,
                            RECOVERY_INDEX_TABLE_NAME, DICT_HDR_SPACE, 0, n);
  ind->table = table;
  ind->n_uniq = (unsigned int)n_uniq;
  if (n_uniq != n) {
    ut_a(n_uniq + DATA_ROLL_PTR <= n);
    ind->type = DICT_CLUSTERED;
  }

  if (is_comp) {
    /* Read each index field info */
    ptr = parse_index_fields(ptr, end_ptr, n, n_uniq, is_versioned, ind, table);
    if (ptr == nullptr) {
      *index = ind;
      return ptr;
    }
  } else if (is_versioned) {
    /* Populate dummy cols/fields and link them */
    populate_dummy_fields(ind, table, n IF_DEBUG(, is_comp));
  }

  size_t n_dropped = 0;
  if (is_versioned) {
    /* Read the fields with version added/dropped */
    instant_fields_list_t f;
    uint16_t current_row_version = 0;
    ptr = parse_index_versioned_fields(ptr, end_ptr, f, current_row_version,
                                       n_dropped);
    if (ptr == nullptr) {
      *index = ind;
      return (ptr);
    }
    ind->table->current_row_version = current_row_version;

    /* Update fields INSTANT info */
    update_instant_info(f, ind);

    bool *phy_pos_bitmap = new bool[ind->n_def];
    memset(phy_pos_bitmap, false, (sizeof(bool) * ind->n_def));
    for (auto field : f) {
      phy_pos_bitmap[field.phy_pos] = true;
    }
    f.clear();

    /* For the remaining columns, update physical pos */
    int shift_count = 0;
    for (size_t i = 0; i < ind->n_def; i++) {
      dict_field_t *field = ind->get_field(i);
      if (field->col->get_phy_pos() == UINT32_UNDEFINED) {
        uint16_t phy_pos = i + shift_count;
        ut_ad(phy_pos < ind->n_def);
        while (phy_pos_bitmap[phy_pos]) {
          phy_pos++;
        }
        field->col->set_phy_pos(phy_pos);
        phy_pos_bitmap[phy_pos] = true;
      } else {
        ut_ad(field->col->is_instant_added() ||
              field->col->is_instant_dropped());

        if (field->col->is_instant_added() &&
            !field->col->is_instant_dropped()) {
          shift_count--;
        }
      }
    }

    delete[] phy_pos_bitmap;
    ind->row_versions = true;
  }

  /* For upgraded table from v1, set following */
  if (inst_cols > 0) {
    ind->instant_cols = true;
    const size_t n_instant_fields = ind->get_instant_fields();
    size_t new_n_nullable = ind->calculate_n_instant_nullable(n_instant_fields);
    ind->set_instant_nullable(new_n_nullable);
  }

  ind->n_fields = n - n_dropped;
  ind->n_total_fields = n;
  table->is_system_table = false;

  if (is_instant || is_versioned) {
    if (is_versioned) {
      ut_ad(ind->has_row_versions());
      ind->create_fields_array();
    }
    if (is_instant) {
      ind->table->set_upgraded_instant();
    }
    ind->type = DICT_CLUSTERED;
    ind->create_nullables(table->current_row_version);
  }

  /* avoid ut_ad(index->cached) in dict_index_get_n_unique_in_tree */
  ind->cached = true;
  *index = ind;
  return (ptr);
}

/** Parse the fields with versions.
@param[in]   ptr       pointer to buffer
@param[in]   end_ptr   pointer to end of buffer
@param[out]  f         vector of fields with versions
@param[out]  crv       current row version
@param[out]  n_dropped number of dropped columns */
static byte *parse_index_versioned_fields_8029(byte *ptr, const byte *end_ptr,
                                               instant_fields_list_t &f,
                                               uint16_t &crv,
                                               size_t &n_dropped) {
  uint16_t n_inst = 0;
  ptr = read_2_bytes(ptr, end_ptr, n_inst);
  if (ptr == nullptr) return (nullptr);
  ut_ad(n_inst > 0);

  for (auto i = n_inst; i > 0; --i) {
    Field_instant_info info;

    ptr = read_2_bytes(ptr, end_ptr, info.phy_pos);
    if (ptr == nullptr) return (nullptr);

    if ((info.phy_pos & 0x8000) != 0) {
      info.phy_pos &= ~0x8000;

      /* Read v_added */
      ptr = read_1_bytes(ptr, end_ptr, info.v_added);
      if (ptr == nullptr) return (nullptr);
      ut_ad(info.v_added != UINT8_UNDEFINED);
      crv = std::max(crv, (uint16_t)info.v_added);
    }

    if ((info.phy_pos & 0x4000) != 0) {
      info.phy_pos &= ~0x4000;

      /* Read v_dropped */
      ptr = read_1_bytes(ptr, end_ptr, info.v_dropped);
      if (ptr == nullptr) return (nullptr);
      ut_ad(info.v_dropped != UINT8_UNDEFINED);
      crv = std::max(crv, (uint16_t)info.v_dropped);
      n_dropped++;
    }

    ut_ad((info.phy_pos & 0xC000) == 0);

    f.push_back(info);
  }

  return (ptr);
}

/** Update the version info for the columns.
NOTE : fields are logged in their physical order so with the help of phy_pos,
it's easy to locate them.
@param[in]      f      fields with versions
@param[in,out]  index  dummy index */
static void update_instant_info_8029(instant_fields_list_t f,
                                     dict_index_t *index) {
  if (f.empty()) {
    return;
  }

  size_t n_added = 0;
  size_t n_dropped = 0;

  for (auto field : f) {
    dict_col_t *col = index->fields[field.phy_pos].col;
    bool is_added = field.v_added != UINT8_UNDEFINED;
    bool is_dropped = field.v_dropped != UINT8_UNDEFINED;
    ut_ad(is_added || is_dropped);

    if (is_added) {
      col->set_version_added(field.v_added);
      n_added++;
    }

    if (is_dropped) {
      col->set_version_dropped(field.v_dropped);
      n_dropped++;
    }

    col->set_phy_pos(field.phy_pos);
  }

  index->table->initial_col_count -= n_added;
  index->table->current_col_count -= n_dropped;
}

/** Parse index fields.
@param[in]       ptr      pointer to buffer
@param[in]       end_ptr  pointer to end of buffer
@param[in]       n        number of fields
@param[in]       n_uniq   n_uniq
@param[in]       is_versioned  true if table has row versions
@param[in,out]   ind      dummy index
@param[in,out]   table    dummy table
@return pointer to log buffer */
static byte *parse_index_fields_8029(byte *ptr, const byte *end_ptr, uint16_t n,
                                     uint16_t n_uniq, bool is_versioned,
                                     dict_index_t *&ind, dict_table_t *&table) {
  for (size_t i = 0; i < n; i++) {
    /* For redundant, col len metadata isn't needed for recovery as it is
    part of record itself. */
    uint16_t len = 0;
    ptr = read_2_bytes(ptr, end_ptr, len);
    if (ptr == nullptr) {
      return (nullptr);
    }

    uint32_t phy_pos = UINT32_UNDEFINED;
    uint8_t v_added = UINT8_UNDEFINED;
    uint8_t v_dropped = UINT8_UNDEFINED;

    /* The high-order bit of len is the NOT NULL flag;
    the rest is 0 or 0x7fff for variable-length fields,
    and 1..0x7ffe for fixed-length fields. */
    dict_mem_table_add_col(
        table, nullptr, nullptr,
        ((len + 1) & 0x7fff) <= 1 ? DATA_BINARY : DATA_FIXBINARY,
        len & 0x8000 ? DATA_NOT_NULL : 0, len & 0x7fff, true, phy_pos, v_added,
        v_dropped);

    /* The is_ascending flag does not matter during
    redo log apply, because we do not compare for
    "less than" or "greater than". */
    dict_index_add_col(ind, table, table->get_col(i), 0, true);
  }

  dict_table_add_system_columns(table, table->heap);

  /* Identify DB_TRX_ID and DB_ROLL_PTR in the index. */
  if (is_versioned || (n_uniq != n)) {
    size_t i = 0;
    i = DATA_TRX_ID - 1 + n_uniq;
    ut_a(DATA_TRX_ID_LEN == ind->get_col(i)->len);
    ind->fields[i].col = &table->cols[n + DATA_TRX_ID];
    ind->fields[i].col->set_phy_pos(table->cols[i].get_phy_pos());

    i = DATA_ROLL_PTR - 1 + n_uniq;
    ut_a(DATA_ROLL_PTR_LEN == ind->get_col(i)->len);
    ind->fields[i].col = &table->cols[n + DATA_ROLL_PTR];
    ind->fields[i].col->set_phy_pos(table->cols[i].get_phy_pos());
  }

  table->initial_col_count = table->current_col_count = table->total_col_count =
      n;
  return ptr;
}

static byte *mlog_parse_index_8029(byte *ptr, const byte *end_ptr,
                                   dict_index_t **index) {
  /* Read the 1 byte flag */
  uint8_t flag = 0;
  ptr = parse_index_flag(ptr, end_ptr, flag);
  if (ptr == nullptr) {
    return nullptr;
  }

  const bool is_comp = IS_COMPACT(flag);
  const bool is_versioned = IS_VERSIONED(flag);
  const bool is_instant = IS_INSTANT(flag);

  if (is_versioned) {
    ib_info(ER_IB_MSG_PARSE_OLD_REDO_INDEX_VERSION);
  }

  /* Read n and n_uniq */
  uint16_t n = 0;
  uint16_t n_uniq = 0;
  uint16_t inst_cols = 0;
  ptr = parse_index_column_counts(ptr, end_ptr, is_comp, is_versioned,
                                  is_instant, n, n_uniq, inst_cols);
  if (ptr == nullptr) {
    return ptr;
  }
  ut_ad(inst_cols == 0 || is_instant);

  /* Create a dummy dict_table_t */
  dict_table_t *table =
      dict_mem_table_create(RECOVERY_INDEX_TABLE_NAME, DICT_HDR_SPACE, n, 0, 0,
                            is_comp ? DICT_TF_COMPACT : 0, 0);

  if (inst_cols > 0) {
    table->set_instant_cols(inst_cols);
  }

  /* Create a dummy dict_index_t */
  dict_index_t *ind =
      dict_mem_index_create(RECOVERY_INDEX_TABLE_NAME,
                            RECOVERY_INDEX_TABLE_NAME, DICT_HDR_SPACE, 0, n);
  ind->table = table;
  ind->n_uniq = (unsigned int)n_uniq;
  if (n_uniq != n) {
    ut_a(n_uniq + DATA_ROLL_PTR <= n);
    ind->type = DICT_CLUSTERED;
  }

  if (is_comp) {
    /* Read each index field info */
    ptr = parse_index_fields_8029(ptr, end_ptr, n, n_uniq, is_versioned, ind,
                                  table);
    if (ptr == nullptr) {
      *index = ind;
      return ptr;
    }
  } else if (is_versioned) {
    /* Populate dummy cols/fields and link them */
    populate_dummy_fields(ind, table, n IF_DEBUG(, is_comp));
  }

  size_t n_dropped = 0;
  if (is_versioned) {
    /* Read the fields with version added/dropped */
    instant_fields_list_t f;
    uint16_t current_row_version = 0;
    ptr = parse_index_versioned_fields_8029(ptr, end_ptr, f,
                                            current_row_version, n_dropped);
    if (ptr == nullptr) {
      *index = ind;
      return (ptr);
    }
    ind->table->current_row_version = current_row_version;

    /* Update fields INSTANT info */
    update_instant_info_8029(f, ind);
    f.clear();

    /* For the remaining columns, update physical pos */
    for (size_t i = 0; i < ind->n_def; i++) {
      dict_field_t *field = ind->get_field(i);
      if (field->col->get_phy_pos() == UINT32_UNDEFINED) {
        field->col->set_phy_pos(i);
      }
    }

    ind->row_versions = true;
  }

  /* For upgraded table from v1, set following */
  if (inst_cols > 0) {
    ind->instant_cols = true;
    ind->n_instant_nullable =
        ind->get_n_nullable_before(ind->get_instant_fields());
  }

  ind->n_fields = n - n_dropped;
  ind->n_total_fields = n;
  table->is_system_table = false;

  if (is_instant || is_versioned) {
    if (is_versioned) {
      ut_ad(ind->has_row_versions());
      ind->create_fields_array();
    }
    if (is_instant) {
      ind->table->set_upgraded_instant();
    }
    ind->type = DICT_CLUSTERED;
    ind->create_nullables(table->current_row_version);
  }

  /* avoid ut_ad(index->cached) in dict_index_get_n_unique_in_tree */
  ind->cached = true;
  *index = ind;
  return (ptr);
}
