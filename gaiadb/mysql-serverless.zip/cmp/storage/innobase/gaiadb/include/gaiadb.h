/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/include/gaiadb.h
 Components of gaiadb

 Created 11/1/2022 Hongyu Qiao
 *******************************************************/

#ifndef gaiadb_gaiadb_h
#define gaiadb_gaiadb_h

#include <chrono>
#include <pthread.h>
#include <baidu/rpc/channel.h>
#include <baidu/rpc/server.h>
#include "gaiadb/psm_client/client.h"
#include "univ.i"
#include "sql/binlog.h"
#include "bos0conductor.h"

#define DELAY_SEND_REQUEST 500000
static const auto srv_delay_send_request = std::chrono::microseconds(DELAY_SEND_REQUEST);
#define SPACE_REQUEST_INTERVAL 1000
static const auto srv_space_request_interval = std::chrono::microseconds(SPACE_REQUEST_INTERVAL);
#define SEGMENT_REQUEST_INTERVAL 1000
static const auto srv_segment_request_interval = std::chrono::microseconds(SEGMENT_REQUEST_INTERVAL);

DECLARE_bool(enable_explicit_undo_space);
DECLARE_bool(enable_purge_time_monitor);
DECLARE_bool(enable_columnar_client_warning);

bool init_com_log();

inline void sleep_for_gaiadb(uint64_t us = 500000) {
  std::this_thread::sleep_for(std::chrono::microseconds(us));
}

int get_cpus_info_for_gaiadb(cpu_set_t *cpuset = nullptr,
                             bool no_cached = false);

class rpc_t {
 public:
  rpc_t();

  bool init_server();
  bool start_server();
  bool stop_server(bool wait=false);
  bool is_innodb_ready() { return innodb_ready_; }
  void set_innodb_ready(bool ready) { innodb_ready_ = ready; }
 private:
  bool started;
  std::shared_ptr<baidu::rpc::Server> cmp_server_;
  bool innodb_ready_{false};
}; // class rpc_t

extern rpc_t rpc_sys;
extern gaiadb::psm_client::ComputeNodeInfo* compute_node_info;
extern std::shared_ptr<gaiadb::psm_client::Heartbeat_data> gaiadb_data;

class Gaiadb_heartbeat : public gaiadb::psm_client::Heartbeat_data {
 public:
  Gaiadb_heartbeat(bool binlog_in_redo_status): Heartbeat_data(binlog_in_redo_status) {}
  gaiadb::psm_client::ServiceType get_type() override { return gaiadb::psm_client::COMPUTE_NODE; }
  uint64_t get_apply_lsn() override;
  uint64_t get_trx_id() override;
  bool get_binlog_in_redo_meta(gaiadb::psm_client::BinlogInRedoMeta& meta) override;
};

extern gaiadb::psm_client::BinlogInRedoMeta binlog_in_redo_meta;
extern std::shared_ptr<gaiadb::psm_client::Psmgr_client> psmcli;
extern std::vector<bos::BosInfo> bos_infos;
extern uint64_t psm_features;
extern bool psm_binlog_in_redo;

bool gaiadb_rpl_init();
bool gaiadb_init();
bool gaiadb_shutdown();
void set_secondary_initial_vars();
BinlogInRedoInfo gaiadb_get_binlog_in_redo_info();
bool gaiadb_update_binlog_in_redo_info(const BinlogInRedoInfo* binlog_in_redo_info);
std::pair<bool, BinlogInRedoInfo> gaiadb_get_primary_binlog_in_redo_info();

bool gaiadb_async_binlog_init();
extern const std::string& get_cluster_id();
bool gaiadb_update_binlog_in_redo_info_v2(const BinlogInRedoInfoMeta* binlog_in_redo_info, int64_t end_time);
bool gaiadb_get_binlog_in_redo_info_v2_index_infos(std::vector<uint32_t> &index_infos);
bool gaiadb_get_binlog_in_redo_info_v2_start_info(BinlogInRedoInfo *binlog_info, uint32_t &last_index_id, BinlogInRedoInfoV2 *binlog_info_v2);
void gaiadb_binlog_meta_to_binlog_info(BinlogInRedoInfo *binlog_info, gaiadb::psm_client::BinlogInRedoMeta *psm_binlog_info);
void gaiadb_binlog_meta_v2_to_binlog_info_v2(BinlogInRedoInfoV2 *binlog_info, gaiadb::psm_client::BinlogInRedoMetaV2 *psm_binlog_info);
bool gaiadb_get_binlog_in_redo_info_v2_start_lsn(uint32_t index_id, uint64_t &start_lsn,  BinlogInRedoInfo *binlog_info, uint64_t &async_start_lsn);
bool gaiadb_get_binlog_in_redo_info_v2_start_indexes(std::vector<uint32_t> &index_infos);
void gaiadb_set_async_binlog_start_lsn();

template<typename Func, typename... Args>
bool retry_operation(uint64_t max_retries, Func&& func, Args&&... args) {
  for (uint64_t attempt = 0; attempt <= max_retries; attempt++) {
    if (!std::forward<Func>(func)(std::forward<Args>(args)...)) {
      return true;
    }

    if (attempt < max_retries) {
      std::this_thread::sleep_for(std::chrono::milliseconds(50 * (attempt + 1)));
    }
  }
  return false;
}

bool gaiadb_update_purge_index(int32_t purge_time);
void gaiadb_bir_flusher();
bool gaiadb_update_psm_binlog_switch_v2(bool switch_info);
bool gaiadb_get_psm_binlog_switch_v2(bool *switch_info);
bool gaiadb_update_block_write_switch(bool switch_info);
bool gaiadb_get_block_write_switch(bool *switch_info);
uint64_t get_gaia_apply_lsn();
uint32_t gaiadb_get_new_index_id();
bool gaiadb_update_bos_infos(const std::vector<bos::BosInfo> &bos_infos);
bool gaiadb_get_bos_infos(std::vector<bos::BosInfo> &bos_infos);
bool gaiadb_build_all_bos_infos(bool update_psm, std::vector<bos::BosInfo> &out_infos);

#endif /* gaiadb_space_h */
