/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_fetch.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/fetch_context.h"
#include "test/test_util.h"

namespace psvr {
namespace test {

class MockFetcher : public Fetcher {
public:
    MockFetcher(ClientPtr client, ControlWeakPtr control) : Fetcher(client, control) {}
    virtual ~MockFetcher() {}

    MOCK_METHOD1(Start, bool(uint32_t));
    TRACE_MOCK_METHOD2(Dispatch, void(SegmentPtr TRACE_FILE_LINE_DTC, bool));
    MOCK_METHOD1(Wakeup, void(SegmentPtr));
    MOCK_METHOD1(Execute, bool(Fetcher::Context*));
    TRACE_MOCK_METHOD3(DoReopenSegment, void(SegmentPtr TRACE_FILE_LINE_DTC, bool, bool));
    TRACE_MOCK_METHOD4(DoReopenSegment, void(SegmentPtr TRACE_FILE_LINE_DTC, const pspb::ReopenSegmentRequest*, pspb::ReopenSegmentResponse*, ggpb::Closure*));

};

class MockBatchFetchManager : public Fetcher::BatchManager {
public:
    MockBatchFetchManager() : Fetcher::BatchManager() {}
    virtual ~MockBatchFetchManager() {}

    MOCK_METHOD5(Exist, bool(ClusterPtr, int32_t, uint64_t*, rwlock_t**, rwlock_t**));
    MOCK_METHOD4(Get, int32_t(ClusterPtr, int32_t, std::list<SegmentWeakPtr>*, uint64_t*));
    MOCK_METHOD2(RemoveNoLock, bool(ClusterPtr, SegmentPtr));

};

}
}
