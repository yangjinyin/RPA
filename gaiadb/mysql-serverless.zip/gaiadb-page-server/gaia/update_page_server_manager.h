/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_page_server_manager.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class UpdatePageServerManager : public Command {
public:
    UpdatePageServerManager() {
        SetName("update-ps-manager");
        SetDesc("reset manager address of segment replica on page server");
        SetDescCn("重置存储服务器上分片副本的管理地址");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c',
                "update segments that matches the cluster id",
                kstring, kGroup2Scope);
        AddRequiredArgOption("segment-id", NULL, 's',
                "and match the segment id, if specified",
                kuint32_t, kGroup2Scope);
        AddRequiredArgOption("manager-address", NULL, 'M',
                "set new manager address to segment", kstring);
        AddRequiredArgOption("multi-segment", &_long_opt_val, kOptMax + 2,
                "in multi type. update segments you want",
                kjson, kGroup3Scope | kOnlyMultiPSScope);

        AddExample("-a <ip> -p <port> --manager-address bns://xxx -c gaia-test-perf -s 1");
        AddExample("-m -a <ip> -p <port> --manager-address bns://xxx -c gaia-test-perf");
        AddExample("-m -a <ip> -p <port> --manager-address bns://xxx -c gaia-test-perf -s 1");
        AddExample("-m -a <ip> -p <port> --multi-segment json_data");
    }
    virtual ~UpdatePageServerManager() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtol(opt, NULL, 10));
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 2:
                _segments = opt;
                break;
            default:
                return 1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::ModifyManagerResponse& rsp);
    int Format(const pspb::MultiModifyManagerResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
    std::string _manager_address {};
    std::string _segments {};
};

}
}
