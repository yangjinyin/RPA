/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/repair_page_server_page.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"
#include "psvr/buf.h"
#include "psvr/record_op.h"

namespace psvr {
namespace gaia {

class RepairPageServerPage : public Command {
public:
    RepairPageServerPage() : Command(true) {
        SetName("repair-ps-page");
        SetDesc("repair page server physical page");
        SetDescCn("修复存储服务器上的物理页数据");

        AddPsmClusterOption();
        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "the cluster id", kstring);
        AddRequiredArgOption("segment-id", NULL, 's', "the segment id", kuint32_t);
        AddRequiredArgOption("space-id", &_long_opt_val, kOptMax + 1, "page of the space id", kuint32_t);
        AddRequiredArgOption("page-no", &_long_opt_val, kOptMax + 2, "the page no", kuint32_t);
        AddRequiredArgOption("page-lsn", &_long_opt_val, kOptMax + 3, "page lsn", kstring);
        AddRequiredArgOption("start-lsn", &_long_opt_val, kOptMax + 4,
                "page start to apply records lsn, default is page lsn",
                kuint64_t);

        AddRequiredArgOption("ls-addr", &_long_opt_val, kOptMax + 5,
                "fetch records from it, default by random",
                kip_port, kGroup2Scope);
        AddRequiredArgOption("physical-offset", &_long_opt_val, kOptMax + 6,
                "page physical offset, default from manager extent",
                kuint64_t, kGroup2Scope);

        AddRequiredArgOption("max-apply-num", &_long_opt_val, kOptMax + 7,
                "max of apply records number, default is unlimited",
                kuint32_t);

        AddExample("--manager-address <bns://x> -a ip -p port -c cluster_id"
                " -s segment_id --space-id space --page-no page --page-lsn lsn");
        AddExample("--manager-address <bns://x> -a ip -p port -c cluster_id"
                " -s segment_id --space-id space --page-no page"
                " --page-lsn lsn --start-lsn lsn2");
    }
    virtual ~RepairPageServerPage() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _ps_addr = opt;
            break;
        case 'p':
            _ps_port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtoul(opt, NULL, 10));
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _space_id.Set(std::strtoul(opt, NULL, 10));
                break;
            case kOptMax + 2:
                _page_no.Set(std::strtoul(opt, NULL, 10));
                break;
            case kOptMax + 3:
                _page_base_lsn = std::strtoull(opt, NULL, 10);
                break;
            case kOptMax + 4:
                _start_apply_lsn = std::strtoull(opt, NULL, 10);
                break;
            case kOptMax + 5:
                _ls_addr = opt;
                break;
            case kOptMax + 6:
                _physical_offset.Set(std::strtoull(opt, NULL, 10));
                break;
            case kOptMax + 7:
                _max_apply_num = std::strtoul(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

    bool GetPagePhysicalOffset(std::vector<base::EndPoint>& nodes,
            uint32_t* physical_extent_id,
            uint64_t* physical_offset);
    bool GetLogServiceNodes(std::vector<base::EndPoint>& nodes,
            std::vector<base::EndPoint>* ls_nodes);
    bool ReadBasePage(const base::EndPoint& node,
            BufBlockPtr buf_block);
    bool FetchRecords(std::vector<base::EndPoint>& nodes,
            std::string* records_buf);
    bool BackupOldPage(const base::EndPoint& node,
            BufBlockPtr buf_block,
            uint64_t physical_extent_id);
    bool WriteNewPage(const base::EndPoint& node,
            BufBlockPtr buf_block,
            uint64_t physical_extent_id);

private:
    std::string _manager_address {};
    std::string _ps_addr {};
    int32_t _ps_port {0};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
    VarOptional<uint32_t> _space_id;
    VarOptional<uint32_t> _page_no;
    uint64_t _page_base_lsn {0};
    uint64_t _start_apply_lsn {0};
    std::string _ls_addr {};
    VarOptional<uint64_t> _physical_offset;
    uint32_t _max_apply_num {0};
};

}
}
