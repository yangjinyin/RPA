/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_statistic.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class GetStatistic : public Command {
public:
    GetStatistic() {
        SetName("get-statistic");
        SetDesc("get cluster statistic information");
        SetDescCn("获取集群统计信息");

        AddPsmClusterOption();
        
        AddExample("--manager-address \"bns://xxx\"");
    }
    virtual ~GetStatistic() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::GetStatisticResponse& rsp);

private:
    std::string _manager_address {};
};

}
}
