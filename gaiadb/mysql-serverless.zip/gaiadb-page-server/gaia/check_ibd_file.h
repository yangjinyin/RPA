/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/check_ibd_file.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class CheckIbdFile : public Command {
public:
    CheckIbdFile() {
        SetName("check-ibd-file");
        SetDesc("check ibd file pages data, hiding empty page information by default");
        SetDescCn("检查 ibd 文件存储引擎的页面数据, 默认隐藏空页信息");

        AddRequiredArgOption("ibd-file", &_long_opt_val, kOptMax + 1, "ibd file path name", kstring);

        AddRequiredArgOption("offset", &_long_opt_val, kOptMax + 2,
                "ibd file check start offset", kuint64_t, kGroup2Scope);
        AddRequiredArgOption("page-num", &_long_opt_val, kOptMax + 3,
                "ibd file check length, NUM * PAGE_SIZE",
                kuint64_t, kGroup2Scope);

        AddNoArgOption("show-empty-page", &_long_opt_val, kOptMax + 4, "disable hiding empty page", kGroup3Scope);
        AddNoArgOption("show-process", &_long_opt_val, kOptMax + 5, "show progress information", kGroup3Scope);
        AddNoArgOption("silent", &_long_opt_val, kOptMax + 6,
                "disable printing page information to log file",
                kGroup3Scope);

        AddNoArgOption("stat", &_long_opt_val, kOptMax + 7, "show stat file info", kGroup4Scope);

        AddNoArgOption("detail", &_long_opt_val, kOptMax + 8, "show page data detai", kGroup4Scope);

        AddExample("--ibd-file xx.ibd");
        AddExample("--ibd-file xx.ibd --show-process");
        AddExample("--ibd-file xx.ibd --stat");
        AddExample("--ibd-file xx.ibd --offset <off> --page-num <num>");
    }
    virtual ~CheckIbdFile() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _ibd_file = opt;
                break;
            case kOptMax + 2:
                _offset = std::strtoull(opt, nullptr, 10);
                break;
            case kOptMax + 3:
                _page_num = std::strtoull(opt, nullptr, 10);
                break;
            case kOptMax + 4:
                _show_empty_page = true;
                break;
            case kOptMax + 5:
                _show_process = true;
                break;
            case kOptMax + 6:
                _silent = true;
                break;
            case kOptMax + 7:
                _stat = true;
                break;
            case kOptMax + 8:
                _show_page_detail = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    void ShowProgress(int64_t done, int64_t total);
private:
    std::string _ibd_file {};
    uint64_t _offset {0};
    uint64_t _page_num {0};
    bool _show_empty_page {false};
    bool _show_process {false};
    bool _silent {false};
    bool _stat {false};
    int _fd {-1};
    uint64_t _file_size {0};
    bool _show_page_detail {false};
    std::chrono::steady_clock::time_point _start_time {};
};

}
}
