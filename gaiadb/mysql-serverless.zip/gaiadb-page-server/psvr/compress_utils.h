/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/compress_utils.h
* @author yukeyong@baidu.com
* @brief
*/


#pragma once

#include <zstd.h>
#include <zdict.h>
#include <psvr0page.h>
#include "psvr/common.h"

namespace psvr {

#define PSVR_COMPRESS_TYPE_NONE 0

// Compress type value has benn used by bakcup tool and old data,
//  please donot change it
#define PSVR_COMPRESS_TYPE_SNAPPY 8
#define PSVR_COMPRESS_TYPE_ZSTD 9
#define PSVR_COMPRESS_TYPE_LZ4 10

bool get_compress_type(const std::string& name, int32_t* type);
void get_compress_name(int32_t type, std::string* name);

bool decompress_data(uint32_t compress_type,
        gaia_apply::byte* compress_buf, gaia_apply::ulint compress_buf_size,
        gaia_apply::ulint original_size, gaia_apply::byte* decompressed_buf);

bool compress_data(int32_t compress_type, int32_t compress_level,
        gaia_apply::byte* buf, gaia_apply::ulint buf_size,
        gaia_apply::byte* compressed_buf, gaia_apply::ulint compressed_buf_size,
        gaia_apply::ulint* compressed_size);

bool page_is_compressed(const gaia_apply::byte* page);
int64_t page_compress_data_size(const gaia_apply::byte* page, 
        gaia_apply::ulint block_size);

bool decompress_page(gaia_apply::byte* src,
        gaia_apply::byte* decompress_buf, gaia_apply::ulint decompress_buf_size);

bool compress_page(gaia_apply::space_id_t logical_space_id, gaia_apply::page_no_t logical_page_no,
        gaia_apply::ulint block_size, int32_t compress_type, int32_t compress_level,
        gaia_apply::byte* src, gaia_apply::ulint src_size,
        gaia_apply::byte* dst, gaia_apply::ulint dst_size, gaia_apply::ulint* compressed_size);

namespace dict {

class TrainDict {
public:
    TrainDict(size_t max_buf_size) : _dict_max_buf_size(max_buf_size) {}
    ~TrainDict() {}

    const std::string& dict_buf() { return _dict_buf; }
    const std::string& samples_buf() { return _samples_buf; }
    size_t samples_size() const { return _sample_size_vec.size(); }

    void AddSample(const std::string& sample) {
        _sample_size_vec.emplace_back(sample.size());
        _samples_buf.append(sample);
    }

    void AddSample(std::string&& sample) {
        _sample_size_vec.emplace_back(sample.size());
        _samples_buf.append(sample);
    }

    bool Train(std::string* dict_buf);
    bool SaveToFile(const std::string& dict_file, const std::string& dict_buf);

    bool Train() { return Train(&_dict_buf); }
    bool SaveToFile(const std::string& dict_file) { return SaveToFile(dict_file, _dict_buf); }

private:
    const size_t _dict_max_buf_size;
    std::string _dict_buf;
    std::string _samples_buf;
    std::vector<size_t> _sample_size_vec;
};

namespace detail {

class Base {
public:
    Base() : _buf(nullptr), _buf_size(0) {}
    virtual ~Base() {}

    bool LoadAndCreateDict(const std::string& dict_file);
    int64_t GetFileSize(const std::string& filename);
protected:
    virtual bool CreateDict(const void* buf, size_t buf_size) = 0;
protected:
    void* _buf;
    size_t _buf_size;
};

} // end of ns detail

class Compress : public detail::Base {
public:
    Compress(int32_t compress_level)
        : Base(), _compress_level(compress_level), _dict(nullptr) {}
    virtual ~Compress() {
        ZSTD_freeCDict(_dict);
    }

    ZSTD_CCtx* NewCtx() { return ZSTD_createCCtx(); }
    void DestroyCtx(ZSTD_CCtx* cctx) { ZSTD_freeCCtx(cctx); }

    bool CreateDict(const std::string& dict_buf) {
        return CreateDict(&dict_buf[0], dict_buf.size());
    }

    bool Execute(ZSTD_CCtx* const cctx, const void* buf, size_t buf_size,
            void* compressed_buf, size_t compressed_buf_size, size_t* compressed_size);

protected:
    virtual bool CreateDict(const void* buf, size_t buf_size) override {
        _dict = ZSTD_createCDict(buf, buf_size, _compress_level);
        return _dict;
    }

private:
    int32_t _compress_level;
    ZSTD_CDict* _dict;
};

class Decompress : public detail::Base {
public:
    Decompress() : Base(), _dict(nullptr) {}
    virtual ~Decompress() {
        ZSTD_freeDDict(_dict);
    }

    ZSTD_DCtx* NewCtx() { return ZSTD_createDCtx(); }
    void DestroyCtx(ZSTD_DCtx* dctx) { ZSTD_freeDCtx(dctx); }

    bool CreateDict(const std::string& dict_buf) {
        return CreateDict(&dict_buf[0], dict_buf.size());
    }

    bool Execute(ZSTD_DCtx* const dctx, const void* compressed_buf, size_t compressed_buf_size,
            void* buf, size_t buf_size, size_t* original_size);
protected:
    virtual bool CreateDict(const void* buf, size_t buf_size) override {
        _dict = ZSTD_createDDict(buf, buf_size);
        return _dict;
    }

private:
    ZSTD_DDict* _dict;
};

} // end of ns dict
}
