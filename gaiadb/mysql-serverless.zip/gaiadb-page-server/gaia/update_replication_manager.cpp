/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_replication_manager.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/update_replication_manager.h"

namespace psvr {
namespace gaia {

int UpdateReplicationManager::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    if (_cluster_id.empty()) {
        print_error("miss --cluster-id");
        return 1;
    }

    if (_primary_manager_address.empty() && _standby_manager_address.empty()) {
        print_error("miss --primary-manager-address, --standby-manager-address");
        return 1;
    }

    RpcStatus status;
    replicate::pb::ModifyManagerRequest request;
    replicate::pb::ModifyManagerResponse response;

    request.set_standby_cluster_id(_cluster_id);
    if (_primary_manager_address.size()) {
        request.set_primary_manager_address(_primary_manager_address);
    }
    if (_standby_manager_address.size()) {
        request.set_standby_manager_address(_standby_manager_address);
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Update replication server[%s:%d] manager?", _address.c_str(), _port);
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    _client.Call(_log_id++, node, &replicate::pb::ReplicationService_Stub::ModifyManagerAddr, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(replicate::pb::RPC_ERROR);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int UpdateReplicationManager::Format(const replicate::pb::ModifyManagerResponse& rsp) {
    SHOW_RPL_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
