/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_compute_node_manager.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"
#include <gaiadb/proto/compute_node/compute_node.pb.h>

namespace psvr {
namespace gaia {

class UpdateComputeNodeManager : public Command {
public:
    UpdateComputeNodeManager() {
        SetName("update-cmp-manager");
        SetDesc("reset manager address of compute node");
        SetDescCn("重置计算节点的管理地址");

        AddNodeOption();
        AddRequiredArgOption("manager-address", NULL, 'M',
                "set new manager address to compute node", kstring);
        
        AddExample("-a <ip> -p <port> --manager-address bns://xxx");
    }
    virtual ~UpdateComputeNodeManager() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            default:
                return 1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const computenode::modify_manager_response& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _manager_address {};
};

}
}
