/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/clear_zone.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ClearZone : public Command {
public:
    ClearZone() {
        SetName("clear-zone");
        SetDesc("clear gaia server memory zone");
        SetDescCn("清除 Gaia 服务的内存可用区配置信息");

        AddRequiredArgOption("address", NULL, 'a', "service listening address of the server", kip_port);
        AddRequiredArgOption("port", NULL, 'p', "service listening port of the server", kint32_t);
        AddRequiredArgOption("cluster-id", NULL, 'c', "manager cluster id", kstring);
        AddRequiredArgOption("type", &_long_opt_val, kOptMax + 2, "gaia server type:(ls/cmp/rpl/ps)", kenum);

        AddExample("-a <ip> -p <port> --type <type> --cluster-id <id>");
    }
    virtual ~ClearZone() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 2:
                _type = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const lspb::lsrv_clear_zone_response& rsp);
    int Format(const computenode::clear_zone_response& rsp);
    int Format(const replicate::pb::ClearZoneResponse& rsp);
    int Format(const pspb::ClearZoneResponse& rsp);

private:
    std::string _type {};
    std::string _address {};
    uint32_t _port {0};
    std::string _cluster_id {};
};

}
}
