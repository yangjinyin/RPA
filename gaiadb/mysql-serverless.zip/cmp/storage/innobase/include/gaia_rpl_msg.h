/*
  Copyright (c) 2026, Baidu and/or its affiliates.
*/

#ifndef STORAGE_INNOBASE_INCLUDE_GAIA_RPL_MSG_H_
#define STORAGE_INNOBASE_INCLUDE_GAIA_RPL_MSG_H_

#include <cstdint>

enum gaia_rpl_msg_type_t : uint8_t {
  GAIA_RPL_MSG_OUTLINE_RELOAD = 0,
};

static constexpr uint8_t GAIA_RPL_MSG_F_OUTLINE_RETAIN_COUNTERS = 0x01;

#endif  // STORAGE_INNOBASE_INCLUDE_GAIA_RPL_MSG_H_
