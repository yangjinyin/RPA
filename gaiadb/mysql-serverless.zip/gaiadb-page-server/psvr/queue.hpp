/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/queue.h
* @author yukeyong@baidu.com
* @brief See dpdk ring
*/

#pragma once

#include "psvr/thread_pool.hpp"

namespace psvr {

class Segment;
using SegmentPtr = std::shared_ptr<Segment>;

template<typename CTX>
struct LsnConditionTask {
    CTX* ctx;
    SegmentPtr segment;
    gaia_apply::lsn_t lsn;
    int32_t retry_nr;

    LsnConditionTask(CTX* _ctx,
            SegmentPtr _segment, gaia_apply::lsn_t _lsn)
        : ctx(_ctx),
        segment(_segment),
        lsn (_lsn),
        retry_nr(0) {}
    LsnConditionTask(const LsnConditionTask& lhs)
        : ctx(lhs.ctx),
        segment(lhs.segment),
        lsn(lhs.lsn),
        retry_nr(lhs.retry_nr) {}

    operator bool();
};

template<typename CTX>
struct ClusterConditionQueue : public ConditionQueue<LsnConditionTask<CTX>,
                                                     ClusterConditionQueue<CTX>> {
    using TaskType = LsnConditionTask<CTX>;
    using FnType = typename ConditionQueue<TaskType, ClusterConditionQueue<CTX>>::Fn;

    ClusterConditionQueue() {}
    ~ClusterConditionQueue() {}

    void Push(const TaskType& task) {
        std::unique_lock lk(_push_mutex);
        _push_tasks.emplace_back(task);
    }

    void PopIf(FnType& fn) {
        MoveTask();
        {
            std::unique_lock lk(_pop_mutex);
            auto it = _cluster_tasks.begin();
            while (it != _cluster_tasks.end()) {
                ClusterTaskManager& tasks = *it;
                bool no_task = true;
                for (auto it2 = tasks.wait_reqs.begin(); it2 != tasks.wait_reqs.end(); ) {
                    TaskType& task = it2->second;
                    if (task) {
                        fn(task);
                        it2 = tasks.wait_reqs.erase(it2);
                    } else {
                        no_task = false;
                        break;
                    }
                }
                if (no_task) {
                    _cluster_tasks_idx.erase(tasks.cluster_id);
                    it = _cluster_tasks.erase(it);
                } else {
                    ++it;
                }
            }
        }
    }

    void Clear(FnType& fn) {
        MoveTask();
        {
            std::unique_lock lk(_pop_mutex);
            auto it = _cluster_tasks.begin();
            while (it != _cluster_tasks.end()) {
                ClusterTaskManager& tasks = *it;
                for (auto it2 = tasks.wait_reqs.begin(); it2 != tasks.wait_reqs.end(); ) {
                    TaskType& task = it2->second;
                    fn(task);
                    it2 = tasks.wait_reqs.erase(it2);
                }
                _cluster_tasks_idx.erase(tasks.cluster_id);
                it = _cluster_tasks.erase(it);
            }
        }
    }

private:
    void MoveTask() {
        std::list<TaskType> push_tasks;
        {
            std::unique_lock lk(_push_mutex);
            push_tasks = std::move(_push_tasks);
        }
        if (!push_tasks.empty()) {
            std::unique_lock lk(_pop_mutex);
            for (auto& task : push_tasks) {
                const std::string& key = task.segment->cluster_id();
                if (auto it = _cluster_tasks_idx.find(key); it != _cluster_tasks_idx.end()) {
                    it->second->wait_reqs.emplace(task.lsn, task);
                } else {
                    _cluster_tasks.emplace_front(ClusterTaskManager{key});
                    auto insert_it = _cluster_tasks_idx.emplace(key, _cluster_tasks.begin());
                    if (insert_it.second) {
                        insert_it.first->second->wait_reqs.emplace(task.lsn, task);
                    } else {
                        PSVR_ASSERT(false);
                    }
                }
            }
        }
    }

private:
    struct ClusterTaskManager {
        std::string cluster_id;
        std::multimap<uint64_t, TaskType, std::less<uint64_t>> wait_reqs;

        ClusterTaskManager(const std::string& _cluster_id) : cluster_id(_cluster_id) {}
    };

    char pad0 BAIDU_CACHELINE_ALIGNMENT;
    std::list<ClusterTaskManager> _cluster_tasks;
    std::map<std::string, typename std::list<ClusterTaskManager>::iterator> _cluster_tasks_idx;
    std::mutex _pop_mutex;
    char pad1 BAIDU_CACHELINE_ALIGNMENT;
    std::list<TaskType> _push_tasks;
    std::mutex _push_mutex;
    char pad2 BAIDU_CACHELINE_ALIGNMENT;
};

}
