/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/read_buf_pool_page.cpp
* @author guolingjie@baidu.com
* @brief
*/

#include <sstream>
#include <base/file_util.h>
#include "psvr/record_op.h"
#include "gaia/read_buf_pool_page.h"

namespace psvr {
namespace gaia {

int ReadBufPoolPage::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    if (_space_id == std::numeric_limits<uint32_t>::max() ||
            _page_no == std::numeric_limits<uint32_t>::max()) {
        print_error("miss --space-id or --page-no");
        return 1;
    }

    cmppb::ReadPageFromBPRequest request;
    cmppb::ReadPageFromBPResponse response;
    request.set_space_id(_space_id);
    request.set_page_no(_page_no);

    RpcStatus status;
    _client.Call(_log_id++, node, &cmppb::StatusQueryService_Stub::read_page_from_bp, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        print_error("rpc request failed. %s", status.msg.c_str());
        return 1;
    }
    return Output(response);
}

int ReadBufPoolPage::Format(const cmppb::ReadPageFromBPResponse& rsp) {
    SHOW_CMP_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    const gaia_apply::page_t* page =
        reinterpret_cast<const gaia_apply::page_t*>(rsp.page_content().c_str());
    auto page_size = rsp.page_content().size();
    printf("%s %u\n", "space_id:", gaia_apply::page_get_space_id(page));
    printf("%s %u\n", "page_no:", gaia_apply::page_get_page_no(page));
    printf("%s %lu\n", "lsn:", gaia_apply::mach_read_from_8(page + gaia_apply::FIL_PAGE_LSN));
    printf("%s %u\n", "first 4 byte of page:", gaia_apply::mach_read_from_4(page));
    printf("%s %u_%u\n", "last 4+4 byte of page:", gaia_apply::mach_read_from_4(page + page_size - 8)
            , gaia_apply::mach_read_from_4(page + page_size - 4));

    if (_dump_page) {
        std::stringstream ss;
        ss << "bp_page_" << _space_id << "_" << _page_no
            << "_" << _address << ":" << _port;
        std::string file_path_str(ss.str());
        base::FilePath file_path(file_path_str);
        // file already exists, double check
        if (base::PathExists(file_path) && !_force) {
            bool cf_ret = execute_confirm("file[%s] already exists, do you want to overwrite it?", file_path_str.c_str());
            if (!cf_ret) {
                printf("quit!\n");
                return 1;
            }
        }
        base::File file(file_path, base::File::FLAG_OPEN_ALWAYS | base::File::FLAG_WRITE);

        file.Write(0, rsp.page_content().c_str(), page_size);
        file.Close();

        printf("%s %s %s\n", "page_file:", file_path_str.c_str(), "(try to read use [hexdump])");
    }
    return 0;
}

}
}
