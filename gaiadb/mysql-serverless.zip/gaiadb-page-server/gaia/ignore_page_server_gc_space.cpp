/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/ignore_page_server_gc_space.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/ignore_page_server_gc_space.h"

namespace psvr {
namespace gaia {

int IgnorePageServerGcSpace::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    if (_cluster_id.empty()) {
        print_error("miss --cluster-id or -c");
        return 1;
    }

    if (_segment_id.has_val && _segment_id.val < 1) {
        print_error("fail, error --segment-id or -s");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    auto op = pspb::IgnoreSpaceRecordsRequest::SELECT;
    if (_op == "select") {
        //
    } else if (_op == "add") {
        op = pspb::IgnoreSpaceRecordsRequest::ADD;
    } else if (_op == "remove") {
        op = pspb::IgnoreSpaceRecordsRequest::REMOVE;
    } else if (_op == "clear") {
        op = pspb::IgnoreSpaceRecordsRequest::CLEAR;
    } else {
        print_error("-op is invalid");
        return 1;
    }

    if (_space_ids.empty() && (_op == "add" || _op == "remove")) {
        print_error("--space-id is empty");
        return 1;
    }

    if (!_force && _op != "select") {
        bool cf_ret = _segment_id.has_val ? execute_confirm("%s segment:[cluster=%s, id=%u]?", _op.c_str(), _cluster_id.c_str(), _segment_id.val)
            : execute_confirm("%s all segments:[cluster=%s]?", _op.c_str(), _cluster_id.c_str());
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    pspb::IgnoreSpaceRecordsRequest request;
    request.set_cluster_id(_cluster_id);
    if (_segment_id.has_val) {
        request.set_segment_id(_segment_id.val);
    }
    request.set_op(op);
    for (auto& id : _space_ids) {
        request.add_space_ids(id);
    }

    pspb::IgnoreSpaceRecordsResponse response;

    _cntl.set_log_id(_log_id);
    _cntl.set_timeout_ms(_timeout_ms);

    _client.Call(&_cntl, node, &pspb::ManagerService_Stub::IgnoreSpaceRecords, &request, &response, nullptr);
    if (_cntl.Failed()) {
        response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response.mutable_status()->set_msg(_cntl.ErrorText());
    }

    return Output(response);
}

int IgnorePageServerGcSpace::Format(const pspb::IgnoreSpaceRecordsResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (_op == "select") {
        auto buf = _cntl.response_attachment().to_string();
        auto ids = reinterpret_cast<gaia_apply::space_id_t*>(&buf[0]);
        auto size = buf.size() / sizeof(gaia_apply::space_id_t);
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({"space_id"}, true);
        for (size_t i = 0; i < size; ++i) {
            table.AddRowsValue({ids[i]});
        }
        table.Display();
    }
    return 0;
}

}
}
