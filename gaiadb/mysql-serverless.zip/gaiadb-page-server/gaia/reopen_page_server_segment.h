/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/reopen_page_server_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ReopenPageServerSegment : public Command {
public:
    ReopenPageServerSegment() {
        SetName("reopen-ps-segment");
        SetDesc("reopen segment in page server");
        SetDescCn("在存储服务器上重新打开分片");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "cluster id", kstring);
        AddRequiredArgOption("segment-id", NULL, 's', "segment id", kint32_t);
        AddNoArgOption("no-check", &_long_opt_val, kOptMax + 1,
                "skip checking if segment fetch lsn is invalid",
                kGroup2Scope);
        AddNoArgOption("no-recover", &_long_opt_val, kOptMax + 2, "don't update data file", kGroup2Scope);

        AddExample("-a <ip> -p <port> --cluster-id <cluster_id> --segment-id <segment_id>");
        AddExample("-a <ip> -p <port> --cluster-id <cluster_id> --segment-id <segment_id> --no-recover");
        AddExample("-a <ip> -p <port> --cluster-id <cluster_id> --segment-id <segment_id> --no-check");
        AddExample("-a <ip> -p <port> --cluster-id <cluster_id> --segment-id <segment_id> --no-check --no-recover");
    }
    virtual ~ReopenPageServerSegment() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.has_val = true;
            _segment_id.val = std::strtol(opt, NULL, 10);
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _no_check = true;
                break;
            case kOptMax + 2:
                _no_recover = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::ReopenSegmentResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
    bool _no_check {false};
    bool _no_recover {false};
};

}
}
