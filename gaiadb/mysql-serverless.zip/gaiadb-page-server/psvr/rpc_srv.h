/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/rpc_srv.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <baidu/rpc/channel.h>
#include <baidu/rpc/controller.h>
#include <baidu/rpc/errno.pb.h>
#include <baidu/rpc/server.h>
#include "psvr/common.h"
#include "psvr/namespace.h"
#include "psvr/client.h"

namespace psvr {

class RPCServer;
using RPCServerPtr = std::shared_ptr<RPCServer>;
using RPCServerWeakPtr = std::weak_ptr<RPCServer>;

class HealthImpl : public brpc::HealthReporter {
public:
    HealthImpl(RPCServerWeakPtr server) : _server(server) {}
    virtual ~HealthImpl() {}

    virtual void GenerateReport(baidu::rpc::Controller* cntl,
            google::protobuf::Closure* done) override;

private:
    RPCServerWeakPtr _server;
};

/* GaiaDB Rbio Service, handle rbio request send from compute node. */
class RbioServiceImpl : public pspb::RbioService {
public:
    RbioServiceImpl(RPCServerWeakPtr server) : _server(server) {}
    virtual ~RbioServiceImpl() {}

    virtual void Rbio(ggpb::RpcController *cntl_base,
            const pspb::RbioRequest *request,
            pspb::RbioResponse *response,
            ggpb::Closure *done) override;
    virtual void WritePhysicalPages(ggpb::RpcController *controller,
            const pspb::WritePageRequest *request,
            pspb::WritePageResponse *response,
            ggpb::Closure *done) override;

private:
    RPCServerWeakPtr _server;
};

class QueryServiceImpl : public pspb::QueryService {
public:
    QueryServiceImpl(RPCServerWeakPtr server) : _server(server) {}

    virtual ~QueryServiceImpl() {}

    virtual void GetServerStatus(ggpb::RpcController* controller,
            const pspb::GetStatusRequest* request,
            pspb::GetStatusResponse* response,
            ggpb::Closure* done) override;

    virtual void MultiGetServerStatus(ggpb::RpcController* controller,
            const pspb::MultiGetStatusRequest* request,
            pspb::MultiGetStatusResponse* response,
            ggpb::Closure* done) override;

    virtual void ReadPhysicalPage(ggpb::RpcController* controller,
            const pspb::ReadPageRequest* request,
            pspb::ReadPageResponse* response,
            ggpb::Closure* done) override;

    virtual void Read(ggpb::RpcController* controller,
            const pspb::ReadRequest* request,
            pspb::ReadResponse* response,
            ggpb::Closure* done) override;

    virtual void GetRecoverInfo(ggpb::RpcController* controller,
            const pspb::GetRecoverInfoRequest* request,
            pspb::GetRecoverInfoResponse* response,
            ggpb::Closure* done) override;

    virtual void MultiGetRecoverInfo(ggpb::RpcController* controller,
            const pspb::MultiGetRecoverInfoRequest* request,
            pspb::MultiGetRecoverInfoResponse* response,
            ggpb::Closure* done) override;

    virtual void ListRecoveryInfo(ggpb::RpcController* controller,
            const pspb::ListRecoveryInfoRequest* request,
            pspb::ListRecoveryInfoResponse* response,
            ggpb::Closure* done) override;

    virtual void ListPsmInfo(ggpb::RpcController* controller,
            const pspb::ListPsmInfoRequest* request,
            pspb::ListPsmInfoResponse* response,
            ggpb::Closure* done) override;

    virtual void GetZone(ggpb::RpcController* controller,
            const pspb::GetZoneRequest* request,
            pspb::GetZoneResponse* response,
            ggpb::Closure* done) override;

    virtual void GetCompressConfig(ggpb::RpcController* controller,
            const pspb::GetCompressConfigRequest* request,
            pspb::GetCompressConfigResponse* response,
            ggpb::Closure* done) override;

    virtual void ListCompressSegment(ggpb::RpcController* controller,
            const pspb::ListCompressSegmentRequest* request,
            pspb::ListCompressSegmentResponse* response,
            ggpb::Closure* done) override;

    virtual void ListClusterStatus(ggpb::RpcController* controller,
            const pspb::ListClusterStatusRequest* request,
            pspb::ListClusterStatusResponse* response,
            ggpb::Closure* done) override;

    virtual void GetRedoRecLog(ggpb::RpcController* controller,
            const pspb::GetRedoRecLogRequest* request,
            pspb::GetRedoRecLogResponse* response,
            ggpb::Closure* done) override;

    // legacy api
    virtual void get_status(ggpb::RpcController *controller,
            const pspb::GetStatusRequest *request,
            pspb::GetStatusResponse *response,
            ggpb::Closure *done) override {
        return GetServerStatus(controller, request, response, done);
    }
    // legacy api
    virtual void read_page(ggpb::RpcController *controller,
            const pspb::ReadPageRequest *request,
            pspb::ReadPageResponse *response,
            ggpb::Closure *done) override {
        return ReadPhysicalPage(controller, request, response, done);
    }

private:
    RPCServerWeakPtr _server;
};

class ManagerServiceImpl : public pspb::ManagerService {
public:
    ManagerServiceImpl(RPCServerWeakPtr server) : _server(server) {}
    virtual ~ManagerServiceImpl() {}

    virtual void SetRecoverInfo(ggpb::RpcController* controller,
            const pspb::SetRecoverInfoRequest* request,
            pspb::SetRecoverInfoResponse* response,
            ggpb::Closure* done) override;

    virtual void SetRecoverPrior(ggpb::RpcController* controller,
            const pspb::SetRecoverPriorRequest* request,
            pspb::SetRecoverPriorResponse* response,
            ggpb::Closure* done) override;

    virtual void MultiSetRecoverInfo(ggpb::RpcController* controller,
            const pspb::MultiSetRecoverInfoRequest* request,
            pspb::MultiSetRecoverInfoResponse* response,
            ggpb::Closure* done) override;

    virtual void ModifyManagerAddr(ggpb::RpcController* controller,
            const pspb::ModifyManagerRequest* request,
            pspb::ModifyManagerResponse* response,
            ggpb::Closure* done) override;

    virtual void MultiModifyManager(ggpb::RpcController* controller,
            const pspb::MultiModifyManagerRequest* request,
            pspb::MultiModifyManagerResponse* response,
            ggpb::Closure* done) override;

    virtual void PreLoadSegment(ggpb::RpcController* controller,
            const pspb::PreLoadSegmentRequest* request,
            pspb::PreLoadSegmentResponse* response,
            ggpb::Closure* done) override;

    virtual void LoadSegment(ggpb::RpcController* controller,
            const pspb::LoadSegmentRequest* request,
            pspb::LoadSegmentResponse* response,
            ggpb::Closure* done) override;

    virtual void CreateSegment(ggpb::RpcController* controller,
            const pspb::CreateSegmentRequest* request,
            pspb::CreateSegmentResponse* response,
            ggpb::Closure* done) override;

    virtual void DropSegment(ggpb::RpcController* controller,
            const pspb::DropSegmentRequest* request,
            pspb::DropSegmentResponse* response,
            ggpb::Closure* done) override;

    virtual void DisableStore(ggpb::RpcController* controller,
            const pspb::DisableStoreRequest* request,
            pspb::DisableStoreResponse* response,
            ggpb::Closure* done) override;

    virtual void UpdateStore(ggpb::RpcController* controller,
            const pspb::UpdateStoreRequest* request,
            pspb::UpdateStoreResponse* response,
            ggpb::Closure* done) override;

    virtual void UpdateAllStore(ggpb::RpcController* controller,
            const pspb::UpdateAllStoreRequest* request,
            pspb::UpdateAllStoreResponse* response,
            ggpb::Closure* done) override;

    virtual void SetZone(ggpb::RpcController* controller,
            const pspb::SetZoneRequest* request,
            pspb::SetZoneResponse* response,
            ggpb::Closure* done) override;

    virtual void ClearZone(ggpb::RpcController* controller,
            const pspb::ClearZoneRequest* request,
            pspb::ClearZoneResponse* response,
            ggpb::Closure* done) override;

   virtual void ReopenSegment(ggpb::RpcController* controller,
            const pspb::ReopenSegmentRequest* request,
            pspb::ReopenSegmentResponse* response,
            ggpb::Closure* done) override;

    virtual void SetCompressConfig(ggpb::RpcController* controller,
            const pspb::SetCompressConfigRequest* request,
            pspb::SetCompressConfigResponse* response,
            ggpb::Closure* done) override;

    virtual void AddCompressSegment(ggpb::RpcController* controller,
            const pspb::AddCompressSegmentRequest* request,
            pspb::AddCompressSegmentResponse* response,
            ggpb::Closure* done) override;

    virtual void DropCompressSegment(ggpb::RpcController* controller,
            const pspb::DropCompressSegmentRequest* request,
            pspb::DropCompressSegmentResponse* response,
            ggpb::Closure* done) override;

    virtual void EnableClusterStat(ggpb::RpcController* controller,
            const pspb::EnableClusterStatRequest* request,
            pspb::EnableClusterStatResponse* response,
            ggpb::Closure* done) override;

    virtual void DisableClusterStat(ggpb::RpcController* controller,
            const pspb::DisableClusterStatRequest* request,
            pspb::DisableClusterStatResponse* response,
            ggpb::Closure* done) override;

    virtual void IgnoreSpaceRecords(ggpb::RpcController* controller,
            const pspb::IgnoreSpaceRecordsRequest* request,
            pspb::IgnoreSpaceRecordsResponse* response,
            ggpb::Closure* done) override;

    virtual void WritePage(ggpb::RpcController* controller,
            const pspb::WritePhysicalPageRequest* request,
            pspb::WritePhysicalPageResponse* response,
            ggpb::Closure* done) override;

    // legacy api
    virtual void modify_manager(ggpb::RpcController* controller,
            const pspb::ModifyManagerRequest* request,
            pspb::ModifyManagerResponse* response,
            ggpb::Closure* done) override {
        return ModifyManagerAddr(controller, request, response, done);
    }
private:
    RPCServerWeakPtr _server;
};

class RPCServer : public std::enable_shared_from_this<RPCServer> {
public:
    RPCServer(ControlWeakPtr control,
        bool multi_type)
        : _control(control),
        _multi_type(multi_type),
        _health_impl(nullptr),
        _rbio_impl(nullptr),
        _query_impl(nullptr),
        _manager_impl(nullptr),
        _rpc_server(nullptr) {}

    virtual ~RPCServer() {}

    bool multi_type() const { return _multi_type; }
    ControlPtr control() { return _control.lock(); }

    FUNC_MOCK bool Init();
    FUNC_MOCK bool Start();
    void Stop(bool join = true);
    void Join();

private:
    RPCServerWeakPtr weak_this() { return std::enable_shared_from_this<RPCServer>::weak_from_this(); }

private:
    ControlWeakPtr _control;
    bool _multi_type;
    std::shared_ptr<HealthImpl> _health_impl;
    std::shared_ptr<RbioServiceImpl> _rbio_impl;
    std::shared_ptr<QueryServiceImpl> _query_impl;
    std::shared_ptr<ManagerServiceImpl> _manager_impl;
    std::shared_ptr<baidu::rpc::Server> _rpc_server;
};

}
