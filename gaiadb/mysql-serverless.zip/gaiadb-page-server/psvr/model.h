/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/model.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <memory>

#include "psvr/utils.h"

namespace psvr {

class Client;
using ClientPtr = std::shared_ptr<Client>;

class Control;
using ControlPtr = std::shared_ptr<Control>;
using ControlWeakPtr = std::weak_ptr<Control>;

template<typename T>
class Model : public std::enable_shared_from_this<T> {
public:
    Model(ClientPtr client,
        ControlWeakPtr control)
        : _stopped(true),
        _client(client),
        _control(control),
        _store_count(0) {}
    virtual ~Model() {}

    FUNC_MOCK bool Start(uint32_t store_count) {
        _store_count = store_count;
        if (SetUp()) {
            _stopped = false;
            return PrepareTask();
        }
        return false;
    }

    void Stop() {
        _stopped = true;
        TearDown();
    }

    virtual bool SetUp() { return true; }
    virtual bool PrepareTask() { return true; }
    virtual void TearDown() {}

    virtual void Join() = 0;

    std::shared_ptr<T> shared_this() {
        return std::enable_shared_from_this<T>::shared_from_this();
    }
    std::weak_ptr<T> weak_this() {
        return std::enable_shared_from_this<T>::weak_from_this();
    }

protected:
    template<typename ThreadPool, typename RecycleTaskFn>
    uint32_t IncOrDecSingleThreadNum(uint32_t& old_n, uint32_t new_n,
            ThreadPool thread_pool, RecycleTaskFn fn) {
        uint32_t cur_n = old_n;
        if (new_n == cur_n || new_n < 1 || _stopped) {
            return new_n;
        }
        if (new_n > cur_n) {
            thread_pool->IncThread(new_n - cur_n);
            old_n = new_n;
        } else if (new_n < cur_n) {
            old_n = new_n;
            auto threads = thread_pool->DecThread(cur_n - new_n);
            for (auto& t : threads) {
                t->Join();
            }
            for (auto& t : threads) {
                t->RecycleTask(fn);
            }
        }
        return cur_n;
    }

    template<typename ThreadPool, typename RecycleTaskFn>
    uint32_t IncOrDecGroupThreadNum(uint32_t& old_n, uint32_t new_n,
            ThreadPool thread_pool, size_t thread_pool_size, RecycleTaskFn fn) {
        uint32_t cur_n = old_n;
        if (new_n == cur_n || new_n < 1 || _stopped) {
            return new_n;
        }
        if (new_n > cur_n) {
            for (size_t i = 0; i < thread_pool_size; ++i) {
                thread_pool->IncThread(i, new_n - cur_n);
            }
            old_n = new_n;
        } else if (new_n < cur_n) {
            old_n = new_n;
            for (size_t i = 0; i < thread_pool_size; ++i) {
                auto threads = thread_pool->DecThread(i, cur_n - new_n);
                for (auto& t : threads) {
                    t->Join();
                }
                for (auto& t : threads) {
                    t->RecycleTask(fn);
                }
            }
        }
        return cur_n;
    }

protected:
    volatile bool _stopped;
    ClientPtr _client;
    ControlWeakPtr _control;
    uint32_t _store_count;
};

}
