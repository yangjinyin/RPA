set -x
rm -f core*

make -j16
