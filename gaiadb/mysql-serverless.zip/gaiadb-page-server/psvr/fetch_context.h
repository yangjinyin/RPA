/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/fetch_contex.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/context_types.h"
#include "psvr/client.h"
#include "psvr/namespace.h"
#include "psvr/fetch.h"

namespace psvr {

struct Fetcher::Context : public thread::TaskContext {
    Action action;

    int32_t fix_client_id {-1};
    int32_t shift_client_id {0};

    brpc::Controller cntl;
    SegmentWeakPtr segment {};
    RpcGetLogCtx get_log_ctx {};
    // for batch
    ClusterWeakPtr cluster {};
    std::string cluster_id {};
    int32_t batch_idx {-1};
    uint64_t batch_version {0};
    PsmInfoPtr psm_info {nullptr};
    std::unique_ptr<RpcBatchGetLogCtx> batch_get_log_ctx {nullptr};
    std::map<uint32_t, SegmentWeakPtr> batch_segments {};

    std::unique_ptr<RpcBatchGetLogServiceCtx> rpc_get_log_service_ctx {nullptr};
    std::unique_ptr<RpcSetReplicaRecovery> rpc_set_replica_recovery_ctx {nullptr};
    std::unique_ptr<RpcGetPageServerCtx> rpc_segment_replica_ctx {nullptr};
    std::unique_ptr<RpcGetRedoRecLog> rpc_get_redo_rec_log_ctx {nullptr};

    pspb::Status st;

    uint64_t log_service_nodes_version {0};
    uint32_t last_zone_version {0};
    bool has_zone {false};      // segment has zone meta
    size_t zone_count {0};    // the number of LS zone meta consistent with the segment
    BitFlag ls_nodes_status {0};

    bool enable_server_push {false};
    uint32_t retry_times {0};       // number of failed retries
    int32_t continuous_empty_fetch_count {0};
    int64_t node_fetch_count {0};
    int64_t node_fetch_begin_time {0};
    int64_t abnormal_fetch_begin_time {0};

    bool reopen_force {false};
    bool reopen_not_recover {false};
    pspb::ReopenSegmentResponse* reopen_response {nullptr};
    ggpb::Closure* reopen_done {nullptr};

    int64_t fetch_redo_rec_begin_time {0};
    uint32_t last_data_len {0};
    int32_t fetch_redo_rec_err_num {0};

    Timer stat_timer;           // for stat
    int64_t callback_time {0};

    Context(Action _action)
        : Context(_action, nullptr) {}
    Context(Action _action, SegmentPtr _segment)
        : thread::TaskContext(CtxType::kFetch),
        action(_action), segment(_segment) {}
    virtual ~Context() {
        baidu::rpc::ClosureGuard done_guard(reopen_done);
    }

    bool fetch_from_backup_zone(size_t idx) const {
        return has_zone && zone_count > 0 && idx >= zone_count;
    }
};

}
