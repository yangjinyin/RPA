/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/segment.h"
#include "psvr/segment_manager.h"

namespace psvr {
namespace test {

class MockSegment : public Segment {
public:
    MockSegment(ControlWeakPtr control, const std::string& cluster_id,
        gaiadb::common::segment_t segment_id, uint64_t segment_size,
        Segment::Status s, ClusterPtr cluster, const std::string& db_path = "./data")
        : Segment(control, cluster_id, segment_id,
        Segment::kUnknownReplicaID, Segment::kUnknownVersion,
        segment_size, true, s, db_path, Segment::kUnknownStoreID, cluster) {
        _db_engine->_page_size = (16<<10);
    }

    virtual ~MockSegment() {}

    MOCK_METHOD1(AddFetchLogBlock, bool(LogBlockPtr));

    MOCK_METHOD2(ParseLogBlockToLogRecords, bool(int64_t log_id, LogBlockPtr log_block));
    //MOCK_METHOD2(GetSpace, void(GetSpaceContext* ctx, ggpb::Closure* closure));
    MOCK_METHOD4(GetSpacePagePhysicalOffset, bool(gaia_apply::page_no_t, gaia_apply::page_no_t, uint64_t*, bool*));
    //MOCK_METHOD2(GetSpacePagePhysicalOffset, void(GetSpacePagePhysicalOffsetContext* ctx, ggpb::Closure* closure));
    MOCK_METHOD2(GetPeerNodes, bool(std::vector<gaiadb::common::PeerZone>*, bool));
    //MOCK_METHOD2(GetPeerNodes, void(GetPeerNodesContext* ctx, ggpb::Closure* closure));

    MOCK_METHOD2(ReadPeerPage, void(ReadPeerPageContext* ctx, ggpb::Closure* closure));

    MOCK_METHOD9(ReadPageData, db::Status(int64_t, TimePoint*, gaia_apply::page_no_t, gaia_apply::page_no_t,
                uint64_t, gaia_apply::lsn_t, BufBlockPtr, bool*, uint64_t*));

    MOCK_METHOD8(WritePageData, db::Status(int64_t, TimePoint*, gaia_apply::page_no_t, gaia_apply::page_no_t, uint64_t, gaia_apply::lsn_t, gaia_apply::lsn_t, bool));

    MOCK_METHOD6(WritePhysicalPageData, db::Status(int64_t, gaia_apply::space_id_t, gaia_apply::page_no_t, uint64_t, uint64_t, void* buf));
    MOCK_METHOD8(WritePhysicalPageData, db::Status(int64_t, gaia_apply::space_id_t, gaia_apply::page_no_t, uint64_t, uint64_t, void* buf, bool, uint64_t*));
    MOCK_METHOD4(ReadPhysicalPageData, db::Status(int64_t, uint64_t, uint64_t, void* buf));
    MOCK_METHOD6(ReadPhysicalPageData, db::Status(int64_t, uint64_t, uint64_t, void* buf, bool*, uint64_t*));

    MOCK_METHOD4(ReadPhysicalPageDataWithDblwr, db::Status(int64_t, uint64_t, uint64_t, void* buf));
    MOCK_METHOD6(ReadPhysicalPageDataWithDblwr, db::Status(int64_t, uint64_t, uint64_t, void* buf, bool*, uint64_t*));

    MOCK_CONST_METHOD0(DblwrHasBufs, bool());
    MOCK_METHOD1(DumpDblwrBuf, db::Status(int64_t));
    MOCK_METHOD1(SealDblwrTimeout, db::Status(int64_t));

    MOCK_METHOD6(TrimPhysicalPageData,
            db::Status(int64_t, gaia_apply::space_id_t, gaia_apply::page_no_t, uint64_t, uint64_t, bool));

    MOCK_METHOD6(ApplyPageLogRecordsNoLock, db::Status(int64_t, uint64_t,
                gaia_apply::lsn_t, BufBlockPtr, LogRecordIteratorInterface&, uint32_t*));
    MOCK_CONST_METHOD0(GetAppendDBCheckPointLsn, gaia_apply::lsn_t());

    MOCK_METHOD1(LoadEngineWithMeta, bool(const gaiapb::PageServerInfo&));
    MOCK_METHOD1(InitLsn, bool(const gaiapb::PageServerInfo&));
    MOCK_METHOD2(InitConfig, bool(const gaiapb::PageServerInfo&, bool));
    MOCK_METHOD1(CreateMeta, bool(const gaiapb::PageServerInfo&));
    MOCK_METHOD2(CreateEngine, bool(const std::string&, int32_t));
    MOCK_METHOD1(OpenEngine, bool(bool));
    MOCK_METHOD0(Delete, bool());
    MOCK_METHOD1(ResetPsmInfo, bool(PsmInfoPtr));

    MOCK_METHOD2(ExistSpacePagePhysicalOffset, bool(gaia_apply::space_id_t, gaia_apply::page_no_t));

    MOCK_METHOD2(UpdateStatCompress, void(int64_t&, int64_t&));
    MOCK_METHOD0(CheckRecovery, bool());
    //MOCK_METHOD0(StartRecovery, bool());
    MOCK_METHOD3(CheckGcPageInRecovery, bool(db::PageLockPtr, gaia_apply::lsn_t*, gaia_apply::lsn_t*));
    //MOCK_METHOD2(DropGcPageInRecovery, bool(db::PageLockPtr, gaia_apply::lsn_t));

    MOCK_METHOD1(GetRecoveryNextBlockTask, bool(RecoverBlockTask*));
    MOCK_METHOD1(FinishRecoveryBlockTask, void(const RecoverBlockTask&));

    MOCK_METHOD1(GcDelayForRecovery, bool(gaia_apply::lsn_t));

    MOCK_METHOD1(GetSpaceReqLock, bool(gaia_apply::space_id_t));
    MOCK_METHOD2(GetSpaceExtentReqLock, bool(gaia_apply::space_id_t, uint32_t));

    MOCK_CONST_METHOD1(GetSpaceStatus, uint32_t(gaia_apply::space_id_t));
    MOCK_CONST_METHOD0(GetSpaceStatusCount, size_t());

    MOCK_CONST_METHOD1(GetSpaceEncryptStatus, uint32_t(gaia_apply::space_id_t));
    MOCK_CONST_METHOD0(GetSpaceEncryptStatusCount, size_t());

    MOCK_METHOD0(GetPreDisable, bool());
    MOCK_METHOD0(PreDisable, bool());
    MOCK_METHOD0(Disable, bool());

    MOCK_METHOD1(AppendLog, db::Status(LogBlockPtr));
    MOCK_METHOD6(AppendRecover, db::Status(gaia_apply::lsn_t, db::LogHeader*, AppendInfo*, base::Slice*, base::Slice*, char**));
    MOCK_METHOD0(FinishAppendRecover, db::Status());
    MOCK_METHOD0(AppendRecoverFetchFinish, bool());
    MOCK_METHOD0(AppendRecoverParseFinish, bool());
    MOCK_METHOD0(AppendRecoverGcFinish, bool());

    MOCK_METHOD1(GetLogBlockOffCache, db::Status(LogBlockPtr));
    MOCK_METHOD2(UpdateAppendDBCheckPoint, db::Status(gaia_apply::lsn_t, bool));
    MOCK_METHOD0(ClearAppendDB, db::Status());
};

class MockSegmentManager : public SegmentManager {
public:
    MockSegmentManager() : SegmentManager() {}
    virtual ~MockSegmentManager() {}

    MOCK_METHOD0(Stop, void());
    MOCK_METHOD2(GetSegment, SegmentPtr(const std::string&, uint32_t));
    MOCK_METHOD2(GetClusterSegments, uint32_t(const std::string&, const SegmentIteratorFn&));
    MOCK_METHOD2(GetClusterSegments, void(const std::string&, std::vector<SegmentPtr>*));

    MOCK_METHOD1(AddSegment, bool(SegmentPtr));
    MOCK_METHOD1(DropSegment, bool(SegmentPtr));

    MOCK_METHOD1(ExistSegment, bool(SegmentPtr));

    MOCK_METHOD2(GetStoreSegments, uint32_t(int32_t, std::vector<SegmentPtr>*));
    MOCK_METHOD2(DropStoreSegments, uint32_t(int32_t, const SegmentIteratorFn&));

    MOCK_METHOD1(GetAllSegments, uint32_t(const SegmentIteratorFn&));
    MOCK_METHOD1(GetAllSegments, void(std::vector<SegmentPtr>*));

    MOCK_METHOD1(GetOrCreateCluster, ClusterPtr(const std::string&));
    MOCK_METHOD1(GetCluster, ClusterPtr(const std::string&));

    MOCK_METHOD1(GetAllClusters, void(std::vector<std::string>*));

    MOCK_METHOD1(GetOrCreatePsmInfo, PsmInfoPtr(const std::string&));
    MOCK_METHOD1(GetPsmInfos, void(pspb::ListPsmInfoResponse*));
    MOCK_METHOD1(GetPsmInfo, PsmInfoPtr(const std::string&));
    MOCK_METHOD2(ReplaceSegment, bool(SegmentPtr, SegmentPtr));
};

class MockRpcQuota : public RpcQuota {
public:
    MockRpcQuota() : RpcQuota("test") {}
    virtual ~MockRpcQuota() {}

    MOCK_METHOD0(GetQuota, uint64_t());

    MOCK_METHOD4(CreateSpaceMetaEvent, std::shared_ptr<SpaceMetaEventType>(SegmentPtr, gaia_apply::space_id_t, ggpb::Closure*, pspb::Status*));
    MOCK_METHOD7(CreateSpaceExtentEvent, std::shared_ptr<SpaceExtentEventType>(SegmentPtr, gaia_apply::space_id_t,
                uint32_t, uint32_t, gaia_apply::page_no_t page_no, ggpb::Closure*, pspb::Status*));
    MOCK_METHOD3(CreatePeerEvent, std::shared_ptr<PeerEventType>(SegmentPtr, ggpb::Closure*, pspb::Status*));

};


}
}
