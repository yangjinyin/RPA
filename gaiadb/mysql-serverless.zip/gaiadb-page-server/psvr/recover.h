/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/recover.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <bthread_types.h>

#include "psvr/common.h"
#include "psvr/model.h"
#include "psvr/utils.h"
#include "psvr/segment.h"
#include "psvr/queue.hpp"

namespace psvr {

class Recoverer;
using RecovererPtr = std::shared_ptr<Recoverer>;

class Recoverer : public Model<Recoverer> {
private:
struct Task;

public:
struct Context;

enum class Action {
    kDispatchRecovery = 1,
    kStartRecovery,
    kRecoverBlock,
    kRecoverBlockFromPeer,
    kDisposeRecoveryBlock,
    kUpdateMetaStatus,
    kOnRecoverBlock,
    kCheck,
    kUpdateRecoveryStats,
    kOnRead,
    kGetLog,
    kOnWrite,
};

private:
using ConditionTask = LsnConditionTask<Context>;
using QuotaThreadType = QuotaThread<Context*, std::shared_ptr<FlowQuota>>;
using QuotaThreadTypePtr = std::shared_ptr<QuotaThreadType>;
using ThreadPoolType = ThreadPoolExecutor<Context, thread::TaskContext>;
using ThreadPoolTypePtr = std::shared_ptr<ThreadPoolType>;
using ConditionQueue = ClusterConditionQueue<Context>;
using ConditionThreadType = GroupConditionThread<ConditionTask, ConditionQueue>;
using ConditionThreadTypePtr = std::shared_ptr<ConditionThreadType>;

struct BthreadTimerContext {
    timespec retry_tm;
    bthread_timer_t timer_id {0};
    Recoverer* recoverer {};
    Context* recovery_ctx {nullptr};
    std::unique_ptr<RpcReadPageCtx> rpc_ctx {nullptr};
};

enum EventType {
    kEventPeer = 0,
    kEventSpace,
    kEventPage,
};

class FlowControl {
public:
    FlowControl(const std::string& name, uint32_t store_count,
            const int64_t* total_limit, const int64_t* store_limit);
    ~FlowControl() {}

    FUNC_MOCK uint64_t GetQuota(int64_t quota, int32_t store_id);
    FUNC_MOCK bool GetQuota(QuotaThreadTypePtr quota_thread,
            Context* ctx, int32_t store_id);

    void StatStoreBw(int64_t size, int32_t store_id);

private:
    std::shared_ptr<FlowQuota> _total_flow;
    std::vector<std::shared_ptr<FlowQuota>> _stores_flow;
    std::vector<std::shared_ptr<StatBw>> _stores_bw;
};

public:
    Recoverer(ClientPtr client, ControlWeakPtr control);
    FUNC_MOCK ~Recoverer() {
        if (!_stopped) {
            Stop();
        }
    }

    static const char* action2str(Recoverer::Action action);

    virtual bool SetUp() override;
    virtual bool PrepareTask() override;
    virtual void TearDown() override;
    virtual void Join() override;

    bool IncOrDecThreadNum();

    FUNC_MOCK bool Dispatch(SegmentPtr segment, bool is_force, bool is_reset TRACE_FILE_LINE_DC);

    FUNC_MOCK void Dispatch(SegmentPtr segment, brpc::Controller* cntl,
            const pspb::ReadPageRequest* request,
            pspb::ReadPageResponse* response, ggpb::Closure* closure);

    FUNC_MOCK void Dispatch(SegmentPtr segment, brpc::Controller* cntl,
            const pspb::ReadRequest* request,
            pspb::ReadResponse* response, ggpb::Closure* closure);

    FUNC_MOCK void Dispatch(SegmentPtr segment, brpc::Controller* cntl,
            const pspb::WritePhysicalPageRequest* request,
            pspb::WritePhysicalPageResponse* response, ggpb::Closure* closure);

    FUNC_MOCK void Dispatch(SegmentPtr segment, brpc::Controller* cntl,
            const pspb::GetRedoRecLogRequest* request,
            pspb::GetRedoRecLogResponse* response, ggpb::Closure* closure);

    FUNC_MOCK bool Execute(Context* ctx);

    FUNC_MOCK void GetRecoveryInfo(pspb::ListRecoveryInfoResponse* response);

    void SetPriorNum(SegmentPtr segment, uint32_t prior_num);

    void GetRecoveryTaskSize(int32_t* total, int32_t* running) {
        *total = _recover_task_num.load(std::memory_order_relaxed);
        *running = _recover_task_running_num.load(std::memory_order_relaxed);
    }

    void AddSegmentToCheckList(SegmentPtr segment);
    void DelayRecoverBlockFromPeer(BthreadTimerContext* bthread_ctx);

    int32_t on_recover_in_wait_size() const { return _on_recover_in_wait_size.load(std::memory_order_relaxed); }
    int64_t on_recover_inflight_req_size() const {
        return _on_recover_inflight_req_size.load(std::memory_order_relaxed);
    }
    uint64_t inflight_read_for_recovery_req_num() const {
        return _inflight_read_for_recovery_req_num.load(std::memory_order_relaxed);
    }
    uint64_t inflight_read_for_backup_req_num() const {
        return _inflight_read_for_backup_req_num.load(std::memory_order_relaxed);
    }
    uint64_t inflight_write_for_backup_req_num() const {
        return _inflight_write_for_backup_req_num.load(std::memory_order_relaxed);
    }
    uint64_t inflight_read_redo_log_req_num() const {
        return _inflight_read_redo_log_req_num.load(std::memory_order_relaxed);
    }
    int64_t recover_expect_finish_time_s() const {
        return _recover_expect_finish_time_s.load(std::memory_order_relaxed);
    }
private:
    void Expose();
    void SetCtxClientId(Context* ctx);
    const ThreadPoolTypePtr& GetThreadPool(Context* ctx) const;
    void Schedule(Context* ctx TRACE_FILE_LINE_DC, uint64_t delay_us = 0, bool is_retry = false);
    void OnCompletion(Context* ctx);

    void DispatchRecovery(Context* ctx);
    void Check(Context* ctx);
    void UpdateRecoveryStats(Context* ctx);

    void StartRecovery(Context* ctx);
    void FinishRecovery(std::shared_ptr<Task> recover_task);

    void RecoverBlock(Context* ctx);
    void RecoverNextBlock(Context* ctx);
    void RecoverBlockError(std::shared_ptr<Task> recover_task);

    bool CheckQuota(Context* ctx, int32_t store_id);
    void OnGetQuota(Context* ctx);
    void OnEvent(Context* ctx, EventType ev_type);

    void RecoverBlockFromPeer(Context* ctx);
    void OnReadPhysicalPage(Context* ctx, RpcReadPageCtx* rpc_ctx);
    void DisposeRecoveryBlock(Context* ctx);

    void UpdateMetaStatus(Context* ctx);
    void OnUpdateReplicaRecoveryStatus(Context* ctx, RpcUpdateReplicaRecoveryStatusCtx* rpc_ctx);

    void ConditionSchedule(Context* ctx, SegmentPtr segment, gaia_apply::lsn_t lsn);
    void ConditionFn(const ConditionTask& task);

    void OnRecoverBlock(Context* ctx);
    void OnRead(Context* ctx);
    void OnWrite(Context* ctx);

    void OnGetLog(Context* ctx);

private:
    uint32_t _dst_thread_num;
    uint32_t _src_thread_num;
    uint32_t _condi_thread_num;
    ThreadPoolTypePtr _thread_pool;
    ThreadPoolTypePtr _dst_thread_pool;
    ThreadPoolTypePtr _src_thread_pool;
    QuotaThreadTypePtr  _quota_thread;
    ConditionThreadTypePtr _condition_thread_pool;
    std::atomic<int32_t> _recover_task_num;
    std::atomic<int32_t> _recover_task_running_num;
    std::atomic<int64_t> _on_recover_inflight_req_size;
    std::atomic<int32_t> _on_recover_in_wait_size;
    std::atomic<int64_t> _recover_expect_finish_time_s;
    std::map<int32_t, std::list<std::shared_ptr<Task>>> _recover_store_tasks;
    std::list<std::shared_ptr<Task>> _segment_check_task_list;
    std::list<std::shared_ptr<Task>>::iterator _segment_check_iter;
    rwlock_t _shared_mutex;
    std::shared_ptr<FlowControl> _src_flow_cntl {nullptr};
    std::shared_ptr<FlowControl> _dst_flow_cntl {nullptr};
    std::shared_ptr<FlowQuota> _check_flow_cntl {nullptr};
    std::shared_ptr<FlowControl> _read_flow_cntl {nullptr};
    std::shared_ptr<FlowControl> _get_redo_log_flow_cntl {nullptr};
    std::shared_ptr<FlowControl> _write_flow_cntl {nullptr};
    std::atomic<uint64_t> _inflight_read_for_recovery_req_num {0};
    std::atomic<uint64_t> _inflight_read_for_backup_req_num {0};
    std::atomic<uint64_t> _inflight_write_for_backup_req_num {0};
    std::atomic<uint64_t> _inflight_read_redo_log_req_num {0};
    // statistics
    StatLatency _stat_on_recover_block_lat;
    StatLatency _stat_on_read_block_lat;
    StatLatency _stat_on_get_log_lat;
    StatCount _stat_on_recover_block_err_count;
    StatLatency _stat_recover_block_total_lat;
    StatLatency _stat_recover_peer_block_lat;
    StatCount _stat_recover_interrupt_by_quota_count;
    StatCount _stat_recover_block_err_count;
    StatCount _stat_recover_block_ok_count;
    StatCount _stat_recover_block_invalid_lsn_count;
    StatCount _stat_recover_block_apply_append_log_count;
    StatLatency _stat_recover_block_apply_append_log_lat;
    bvar::PassiveStatus<int32_t> _stat_on_recover_in_wait_count;
    bvar::PassiveStatus<bvar::Vector<int64_t, 5>> _stat_recover_inflight_req_size;
    bvar::PassiveStatus<bvar::Vector<int32_t, 2>> _stat_recover_running_task_num;
    bvar::Adder<int64_t> _stat_recover_left_size;
    StatBw _stat_recover_bw;
    bvar::PassiveStatus<int64_t> _stat_recover_expect_finish_time_s;
};

/* for check quota is ok */
bool operator>=(std::shared_ptr<FlowQuota> quota, Recoverer::Context* ctx);

/* for check condiation is ok */
template<>
inline LsnConditionTask<Recoverer::Context>::operator bool() {
    if (segment->append_lsn() >= lsn
            || !segment_is_valid(segment)) {
        return true;
    } else if (++retry_nr > FLAGS_psvr_recover_wait_lsn_max_times) {
        return true;
    } else {
        return false;
    }
}

} // end of ns psvr
