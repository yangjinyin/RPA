/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_compute_node.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_compute_node.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ListComputeNode::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (_addr.empty()) {
        gaiapb::ComputeNodeBatchGetRequest request;
        gaiapb::ComputeNodeBatchGetResponse response;

        request.set_log_id(_log_id);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_compute_node, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                return Output(response);
            } else {
                LOG(WARNING) << node << " list compute node failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("list failed, all nodes failed");
        return Output(response);
    } else {
        gaiapb::ComputeNodeRequest request;
        gaiapb::ComputeNodeResponse response;

        request.set_addr(_addr);
        request.set_log_id(_log_id);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_compute_node, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                return Output(response);
            } else {
                LOG(WARNING) << node << " list compute node failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("list failed, all nodes failed");
        return Output(response);
    }
}

int ListComputeNode::Format(const gaiapb::ComputeNodeResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"server_id", rsp.server_id()});
    table.AddRowsValue({"addr", rsp.addr()});
    table.AddRowsValue({"is_primary", rsp.is_primary()});
    table.AddRowsValue({"lowest_trx_id", rsp.lowest_trx_id()});
    table.AddRowsValue({"apply_lsn", rsp.apply_lsn()});
    table.AddRowsValue({"start_apply_lsn", rsp.start_apply_lsn()});
    table.AddRowsValue({"cn_lowest_gc_lsn", rsp.cn_lowest_gc_lsn()});
    table.AddRowsValue({"primary_lsn", rsp.primary_lsn()});
    table.AddRowsValue({"binlog_in_redo_lowest_sync_lsn", rsp.binlog_in_redo_lowest_sync_lsn()});
    table.AddRowsValue({"state", gaiadb::NodeState_Name(rsp.state())});
    table.AddRowsValue({"zone", GetZoneStr(rsp)});
    table.AddRowsValue({"binlog_in_redo_info", GetBinLogInfo(rsp)});
    table.Display();
    return 0;
}

int ListComputeNode::Format(const gaiapb::ComputeNodeBatchGetResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.compute_nodes_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({
                "node", "id", "lowest_trx_id",
                "apply_lsn", "start_apply_lsn", "state",
                "primary", "zone", "binlog_in_redo_info"}, true);
        for (auto& cp : rsp.compute_nodes()) {
            table.AddRowsValue({
                    cp.addr(),
                    cp.server_id(),
                    cp.lowest_trx_id(),
                    cp.apply_lsn(),
                    cp.start_apply_lsn(),
                    gaiadb::NodeState_Name(cp.state()),
                    cp.is_primary() ? "yes" : "no",
                    GetZoneStr(cp),
                    GetBinLogInfo(cp),
                    });
        }
        table.Display();
    }
    return 0;
}

}
}
