/* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/recover.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <bthread_unstable.h>
#include "psvr/config.h"
#include "psvr/control.h"
#include "psvr/page_op.h"
#include "psvr/recover_context.h"

namespace psvr {

#define recover_define_control_or_return_invalid(_ctx, cond) \
    ControlPtr control = _control.lock();   \
    while (_stopped || !control) {    \
        std::unique_ptr<Context> ctx_guard(_ctx);    \
        if (cond) { \
            LOG(TRACE) << "server maybe stopped";   \
            RecoverBlockError(_ctx->recover_task);    \
        } \
        return; \
    }

#define recover_define_segment_or_return_invalid(_ctx, cond) \
    SegmentPtr segment = _ctx->segment.lock();   \
    while (!segment_is_valid(segment)) { \
        std::unique_ptr<Context> ctx_guard(_ctx);    \
        if (cond) { \
            LOG(TRACE) << "segment is invalid";   \
            RecoverBlockError(_ctx->recover_task);    \
        } \
        return; \
    }

#define recover_check_interrupt_segment_recovery(_ctx, cond) \
do { \
    if (segment->RecoveryStoped()) { \
        std::unique_ptr<Context> ctx_guard(_ctx);    \
        if (cond) { \
            LOG(TRACE) << "recovery stopped";   \
            RecoverBlockError(_ctx->recover_task);    \
        } \
        return; \
    }   \
    if (_ctx->recover_task->is_check && !FLAGS_psvr_recover_enable_check) { \
        std::unique_ptr<Context> ctx_guard(_ctx);    \
        if (cond) { \
            LOG(TRACE) << "disable check";   \
            RecoverBlockError(_ctx->recover_task);    \
        } \
        return; \
    } \
} while(0)

#define dec_inflight_ref_if_on_recover(_ctx) \
do {    \
    if (_ctx->action == Action::kOnRecoverBlock     \
            || _ctx->action == Action::kOnRead      \
            || _ctx->action == Action::kGetLog) {   \
        _on_recover_inflight_req_size.fetch_sub(1, std::memory_order_relaxed);  \
    }   \
} while(0)

#define dec_inflight_req_num(_ctx) \
do {    \
    if (_ctx->counted_inflight) {   \
        switch (_ctx->action) { \
        case Action::kOnRecoverBlock:   \
            _inflight_read_for_recovery_req_num.fetch_sub(1, std::memory_order_relaxed);  \
            break;  \
        case Action::kOnRead:   \
            _inflight_read_for_backup_req_num.fetch_sub(1, std::memory_order_relaxed);  \
            break;  \
        case Action::kOnWrite:  \
            _inflight_write_for_backup_req_num.fetch_sub(1, std::memory_order_relaxed);  \
            break;  \
        case Action::kGetLog:   \
            _inflight_read_redo_log_req_num.fetch_sub(1, std::memory_order_relaxed);  \
            break;  \
        default:    \
            break;  \
        }   \
    }   \
} while(0)

constexpr static uint64_t kDelayRunCheckTask = second2microseconds(2ul);   // 2s
constexpr static uint64_t kDelayUpdateRecoveryStats = second2microseconds(1ul);   // 1s
constexpr static uint32_t kScheduleTaskThreadNum = 1;

static uint64_t recovery_get_delay_us(uint32_t retry_times,
        uint64_t retry_interval_us = FLAGS_psvr_recover_delay_min_us,
        uint64_t max_delay_us = FLAGS_psvr_recover_delay_max_us) {
    return get_delay_us(retry_times, retry_interval_us, max_delay_us);
}

static int32_t get_on_recover_in_wait_count(void* arg) {
    return static_cast<Recoverer*>(arg)->on_recover_in_wait_size();
}

static bvar::Vector<int64_t, 5> get_recover_inflight_req_size(void* arg) {
    Recoverer* recoverer = static_cast<Recoverer*>(arg);
    bvar::Vector<int64_t, 5> result;
    result[0] = recoverer->on_recover_inflight_req_size();
    result[1] = static_cast<int64_t>(recoverer->inflight_read_for_recovery_req_num());
    result[2] = static_cast<int64_t>(recoverer->inflight_read_for_backup_req_num());
    result[3] = static_cast<int64_t>(recoverer->inflight_write_for_backup_req_num());
    result[4] = static_cast<int64_t>(recoverer->inflight_read_redo_log_req_num());
    return result;
}

static bvar::Vector<int32_t, 2> get_recover_running_task_num(void* arg) {
    Recoverer* recoverer = static_cast<Recoverer*>(arg);
    bvar::Vector<int32_t, 2> result;
    recoverer->GetRecoveryTaskSize(&result[0], &result[1]);
    return result;
}

static int64_t get_recover_expect_finish_time_s(void* arg) {
    return static_cast<Recoverer*>(arg)->recover_expect_finish_time_s();
}

static bool try_add_inflight_req_num(std::atomic<uint64_t>& quota,
        uint64_t max_size, bool* counted) {
    *counted = false;
    if (max_size == 0) {
        return true;
    }
    auto inflight_count = quota.load(std::memory_order_acquire);
    do {
        if (inflight_count + 1 > max_size) {
            return false;
        }
    } while (!quota.compare_exchange_strong(inflight_count, inflight_count + 1, std::memory_order_release));
    *counted = true;
    return true;
}

Recoverer::FlowControl::FlowControl(const std::string& name,
    uint32_t store_count,
    const int64_t* total_limit,
    const int64_t* store_limit) {
    _total_flow.reset(new FlowQuota(name, "total_used", total_limit, true));
    for (uint32_t i = 0; i < store_count; ++i) {
        _stores_flow.emplace_back(new FlowQuota(name, std::to_string(i) + "_total_used", store_limit, true));
        _stores_bw.emplace_back(new StatBw(name, std::to_string(i) + "_bw", kSlaWindowSize));
    }
}

uint64_t Recoverer::FlowControl::GetQuota(int64_t quota, int32_t store_id) {
    uint64_t delay_us = 0;
    delay_us = _total_flow->GetQuota(quota);
    if (delay_us > 0) {
        return delay_us;
    }
    return _stores_flow[store_id]->GetQuota(quota);
}

bool Recoverer::FlowControl::GetQuota(QuotaThreadTypePtr quota_thread,
            Context* ctx, int32_t store_id) {
    if (!quota_thread->GetQuota(ctx, _total_flow)) {
        return false;
    }
    return quota_thread->GetQuota(ctx, _stores_flow[store_id]);
}

void Recoverer::FlowControl::StatStoreBw(int64_t size, int32_t store_id) {
    *(_stores_bw[store_id]) << size;
}

bool operator>=(std::shared_ptr<FlowQuota> quota, Recoverer::Context* ctx) {
    return quota->GetQuota(ctx->task.size) == 0;
}

static const char* action2str(Recoverer::Action action) {
    switch (action) {
    case Recoverer::Action::kDispatchRecovery:
        return "kDispatchRecovery";
    case Recoverer::Action::kStartRecovery:
        return "kStartRecovery";
    case Recoverer::Action::kRecoverBlock:
        return "kRecoverBlock";
    case Recoverer::Action::kRecoverBlockFromPeer:
        return "kRecoverBlockFromPeer";
    case Recoverer::Action::kDisposeRecoveryBlock:
        return "kDisposeRecoveryBlock";
    case Recoverer::Action::kUpdateMetaStatus:
        return "kUpdateMetaStatus";
    case Recoverer::Action::kOnRecoverBlock:
        return "kOnRecoverBlock";
    case Recoverer::Action::kCheck:
        return "kCheck";
    case Recoverer::Action::kUpdateRecoveryStats:
        return "kUpdateRecoveryStats";
    case Recoverer::Action::kOnRead:
        return "kOnRead";
    case Recoverer::Action::kGetLog:
        return "kGetLog";
    case Recoverer::Action::kOnWrite:
        return "kOnWrite";
    default:
        return "unknown";
    }
}

const char* Recoverer::action2str(Recoverer::Action action) {
    return psvr::action2str(action);
}

Recoverer::Recoverer(ClientPtr client, ControlWeakPtr control)
    : Model<Recoverer>(client, control),
    _dst_thread_num(1),
    _src_thread_num(1),
    _condi_thread_num(1),
    _stat_on_recover_block_lat(kSlaWindowSize),
    _stat_on_read_block_lat(kSlaWindowSize),
    _stat_on_get_log_lat(kSlaWindowSize),
    _stat_on_recover_block_err_count(kSlaWindowSize),
    _stat_recover_block_total_lat(kSlaWindowSize),
    _stat_recover_peer_block_lat(kSlaWindowSize),
    _stat_recover_interrupt_by_quota_count(kSlaWindowSize),
    _stat_recover_block_err_count(kSlaWindowSize),
    _stat_recover_block_ok_count(kSlaWindowSize),
    _stat_recover_block_invalid_lsn_count(kSlaWindowSize),
    _stat_recover_block_apply_append_log_count(kSlaWindowSize),
    _stat_recover_block_apply_append_log_lat(kSlaWindowSize),
    _stat_on_recover_in_wait_count(&get_on_recover_in_wait_count, this),
    _stat_recover_inflight_req_size(&get_recover_inflight_req_size, this),
    _stat_recover_running_task_num(&get_recover_running_task_num, this),
    _stat_recover_bw(kSlaWindowSize),
    _stat_recover_expect_finish_time_s(&get_recover_expect_finish_time_s, this) {
    _thread_pool.reset(new ThreadPoolType);
    _dst_thread_pool.reset(new ThreadPoolType);
    _src_thread_pool.reset(new ThreadPoolType);
    _quota_thread.reset(new QuotaThreadType);
    _condition_thread_pool.reset(new ConditionThreadType);
    _recover_task_num.store(0);
    _recover_task_running_num.store(0);
    _on_recover_inflight_req_size.store(0);
    _on_recover_in_wait_size.store(0);
    _recover_expect_finish_time_s.store(0);
    Expose();
}

void Recoverer::Expose() {
#ifndef GTEST
    _stat_on_recover_block_lat.expose("psvr_on_recover_block");
    _stat_on_read_block_lat.expose("psvr_on_read_block");
    _stat_on_get_log_lat.expose("psvr_on_get_log");
    _stat_on_recover_block_err_count.expose("psvr_on_recover_block_err_count");
    _stat_recover_block_total_lat.expose("psvr_recover_block_total");
    _stat_recover_peer_block_lat.expose("psvr_recover_peer_block");
    _stat_recover_interrupt_by_quota_count.expose("psvr_recover_interrupt_by_quota_count");
    _stat_recover_block_err_count.expose("psvr_recover_block_err_count");
    _stat_recover_block_ok_count.expose("psvr_recover_block_ok_count");
    _stat_recover_block_invalid_lsn_count.expose("psvr_recover_block_invalid_lsn_count");
    _stat_recover_block_apply_append_log_count.expose("psvr_recover_block_apply_append_log_count");
    _stat_recover_block_apply_append_log_lat.expose("psvr_recover_block_apply_append_log_lat");
    _stat_on_recover_in_wait_count.expose("psvr_on_recover_in_wait_count");
    _stat_recover_inflight_req_size.expose("psvr_recover_inflight_req_size");
    _stat_recover_inflight_req_size.set_vector_names("total,read_for_recovery,read_for_backup,write_for_backup,read_redo_log");
    _stat_recover_running_task_num.expose("psvr_recover_running_task_num");
    _stat_recover_running_task_num.set_vector_names("total,running");
    _stat_recover_left_size.expose("psvr_recover_left_size");
    _stat_recover_bw.expose("psvr_recover_bw");
    _stat_recover_expect_finish_time_s.expose("psvr_recover_expect_finish_time_s");
#endif
}

bool Recoverer::SetUp() {
    ControlPtr control = _control.lock();
    if (!control) {
        LOG(ERROR) << "failed, control is release";
        return false;
    }
    if (FLAGS_psvr_stop_recovery_work) {
        LOG(WARNING) << "--psvr_stop_recovery_work is set true!!!";
    }
    // a normal thread pool, recovery tasks for each store run disjointly
    // create double count of store threads and one data check extra thread
    // | schedule thread | src and dst recover thread |
    _condi_thread_num = FLAGS_multi_psvr_recover_condition_thread_num;

    if (FLAGS_multi_psvr_dst_recover_thread_num > 0) {
        _dst_thread_num = FLAGS_multi_psvr_dst_recover_thread_num;
    } else if (FLAGS_multi_psvr_recover_thread_num > 0) {
        _dst_thread_num = FLAGS_multi_psvr_recover_thread_num;
    } else {
        _dst_thread_num = _store_count;
    }

    if (FLAGS_multi_psvr_src_recover_thread_num > 0) {
        _src_thread_num = FLAGS_multi_psvr_src_recover_thread_num;
    } else if (FLAGS_multi_psvr_recover_thread_num > 0) {
        _src_thread_num = FLAGS_multi_psvr_recover_thread_num;
    } else {
        _src_thread_num = _store_count;
    }

    // set store flowcontrol
    _src_flow_cntl.reset(new FlowControl("psvr_on_recover_quota_store", _store_count,
                &FLAGS_psvr_recover_src_max_speed, &FLAGS_psvr_recover_src_store_max_speed));
    _dst_flow_cntl.reset(new FlowControl("psvr_recover_quota_store", _store_count,
                &FLAGS_psvr_recover_dst_max_speed, &FLAGS_psvr_recover_dst_store_max_speed));
    _check_flow_cntl.reset(new FlowQuota("psvr", "recover_check_quota_total_used",
                &FLAGS_psvr_recover_check_max_speed));
    _read_flow_cntl.reset(new FlowControl("psvr_recover_read_quota_store", _store_count,
                &FLAGS_psvr_recover_read_max_speed, &FLAGS_psvr_recover_read_store_max_speed));
    _get_redo_log_flow_cntl.reset(new FlowControl("psvr_get_redo_log_quota_store", _store_count,
                &FLAGS_psvr_get_redo_log_max_speed, &FLAGS_psvr_get_redo_log_store_max_speed));
    _write_flow_cntl.reset(new FlowControl("psvr_write_page_quota_store", _store_count,
                &FLAGS_psvr_recover_write_max_speed, &FLAGS_psvr_recover_write_store_max_speed));

    typename ConditionThreadType::Fn cond_fn
        = std::bind(&Recoverer::ConditionFn, this, std::placeholders::_1);
    _condition_thread_pool->Start(_condi_thread_num, "recover_cond", cond_fn,
            &FLAGS_psvr_recover_wait_lsn_sleep_interval_us);

    typename QuotaThreadType::Fn quota_fn
        = std::bind(&Recoverer::OnGetQuota, this, std::placeholders::_1);
    _quota_thread->Start("recover_quota", quota_fn, &FLAGS_psvr_recover_wait_quota_sleep_interval_us);

    typename ThreadPoolType::TaskFn fn
        = std::bind(&Recoverer::OnCompletion, this, std::placeholders::_1);

    if (!_thread_pool->Start("r_sched", control->timer(), kScheduleTaskThreadNum, fn)) {
        LOG(ERROR) << "recovery thread pool start failed";
        return false;
    }
    if (!_dst_thread_pool->Start("r_dst", control->timer(), _dst_thread_num, true, fn)) {
        LOG(ERROR) << "dst recovery thread pool start failed";
        return false;
    }
    if (!_src_thread_pool->Start("r_src", control->timer(), _src_thread_num, true, fn)) {
        LOG(ERROR) << "src recovery thread pool start failed";
        return false;
    }
    return true;
}

bool Recoverer::PrepareTask() {
    // start kDispatchRecovery
    {
        auto* run_ctx = new Context(Action::kDispatchRecovery);
        run_ctx->log_id = get_log_id();
        run_ctx->fix_client_id = 0;
        Schedule(run_ctx TRACE_FILE_LINE_CC, second2microseconds(1ul));
    }
    // start kCheck
    {
        auto* check_ctx = new Context(Action::kCheck);
        check_ctx->log_id = get_log_id();
        check_ctx->fix_client_id = 0;
        Schedule(check_ctx TRACE_FILE_LINE_CC, kDelayRunCheckTask);
    }
    // start kUpdateRecoveryStats
    {
        auto* stat_ctx = new Context(Action::kUpdateRecoveryStats);
        stat_ctx->log_id = get_log_id();
        stat_ctx->fix_client_id = 0;
        Schedule(stat_ctx TRACE_FILE_LINE_CC, kDelayUpdateRecoveryStats);
    }
    return true;
}

void Recoverer::TearDown() {
    LOG(NOTICE) << "recoverer will stop ...";
    _quota_thread->Stop(false);
    _condition_thread_pool->Stop(false);
    _thread_pool->Stop(false);
    _dst_thread_pool->Stop(false);
    _src_thread_pool->Stop(false);
    _stat_on_recover_block_lat.hide();
    _stat_on_read_block_lat.hide();
    _stat_on_get_log_lat.hide();
    _stat_on_recover_block_err_count.hide();
    _stat_recover_block_total_lat.hide();
    _stat_recover_peer_block_lat.hide();
    _stat_recover_interrupt_by_quota_count.hide();
    _stat_recover_block_err_count.hide();
    _stat_recover_block_ok_count.hide();
    _stat_recover_block_invalid_lsn_count.hide();
    _stat_recover_block_apply_append_log_count.hide();
    _stat_recover_block_apply_append_log_lat.hide();
    _stat_on_recover_in_wait_count.hide();
    _stat_recover_inflight_req_size.hide();
    _stat_recover_running_task_num.hide();
    _stat_recover_left_size.hide();
    _stat_recover_bw.hide();
    _stat_recover_expect_finish_time_s.hide();
}

void Recoverer::Join() {
    LOG(NOTICE) << "recoverer will join ...";
    _quota_thread->Stop(true);
    _condition_thread_pool->Stop(true);
    _thread_pool->RecycleTask([this](Context* ctx) {
            // call all received rpc requests done, otherwise block brpc quit
            dec_inflight_ref_if_on_recover(ctx);
            dec_inflight_req_num(ctx);
            delete ctx;
        });
    _dst_thread_pool->RecycleTask([this](Context* ctx) {
            // call all received rpc requests done, otherwise block brpc quit
            dec_inflight_ref_if_on_recover(ctx);
            dec_inflight_req_num(ctx);
            delete ctx;
        });
    _src_thread_pool->RecycleTask([this](Context* ctx) {
            // call all received rpc requests done, otherwise block brpc quit
            dec_inflight_ref_if_on_recover(ctx);
            dec_inflight_req_num(ctx);
            delete ctx;
        });
    while (_on_recover_inflight_req_size.load() > 0) {
        _condition_thread_pool->Clear();
    }
    LOG(NOTICE) << "recoverer will join ok";
}

bool Recoverer::IncOrDecThreadNum() {
    uint32_t dst_cfg_n = 0;
    if (FLAGS_multi_psvr_dst_recover_thread_num > 0) {
        dst_cfg_n = FLAGS_multi_psvr_dst_recover_thread_num;
    } else if (FLAGS_multi_psvr_recover_thread_num > 0) {
        dst_cfg_n = FLAGS_multi_psvr_recover_thread_num;
    } else {
        dst_cfg_n = _store_count;
    }

    uint32_t src_cfg_n = 0;
    if (FLAGS_multi_psvr_src_recover_thread_num > 0) {
        src_cfg_n = FLAGS_multi_psvr_src_recover_thread_num;
    } else if (FLAGS_multi_psvr_recover_thread_num > 0) {
        src_cfg_n = FLAGS_multi_psvr_recover_thread_num;
    } else {
        src_cfg_n = _store_count;
    }

    uint32_t dst_cur_n = IncOrDecSingleThreadNum(_dst_thread_num, dst_cfg_n, _dst_thread_pool,
            [this](Context* ctx){
                Schedule(ctx TRACE_FILE_LINE_CC);
            });

    LOG_IF(NOTICE, dst_cfg_n != dst_cur_n) << "dst recoverer thread num changed,"
        << " old:[" << dst_cur_n
        << "] new:[" << dst_cfg_n
        << "]";

    uint32_t src_cur_n = IncOrDecSingleThreadNum(_src_thread_num, src_cfg_n, _src_thread_pool,
            [this](Context* ctx){
                Schedule(ctx TRACE_FILE_LINE_CC);
            });

    LOG_IF(NOTICE, src_cfg_n != src_cur_n) << "dst recoverer thread num changed,"
        << " old:[" << src_cur_n
        << "] new:[" << src_cfg_n
        << "]";

    return (dst_cfg_n != dst_cur_n) || (src_cfg_n != src_cur_n);
}

// thread layout (useless if thread pool enable shard mode):
// [0,1): check data thread
// [1, store_count) src thread
// [store_count, 2 * store_count) dst thread
void Recoverer::SetCtxClientId(Context* ctx) {
    static std::atomic<uint32_t> round_robin_id = 0;
    if (ctx->fix_client_id > -1) {
        ctx->client_id = ctx->fix_client_id;
        return;
    }
    if (ctx->action == Action::kOnRecoverBlock ||
            ctx->action == Action::kOnRead ||
            ctx->action == Action::kGetLog) {
        auto idx = round_robin_id.fetch_add(1, std::memory_order_relaxed);
        ctx->client_id = (idx % _src_thread_num) + ctx->shift_client_id;
        return;
    } else {
        if (auto segment = ctx->segment.lock(); segment) {
            auto idx = segment->store_id();
            if (ctx->recover_task) {
                idx += ctx->task.offset;
            }
            ctx->client_id = (idx % _dst_thread_num) + ctx->shift_client_id;
            return;
        }
    }
    auto idx = round_robin_id.fetch_add(1, std::memory_order_relaxed);
    ctx->client_id = idx % _dst_thread_num;
}

const Recoverer::ThreadPoolTypePtr& Recoverer::GetThreadPool(Context* ctx) const {
    switch(ctx->action) {
    case Action::kDispatchRecovery:
    case Action::kCheck:
    case Action::kUpdateRecoveryStats:
        return _thread_pool;
    case Action::kOnRecoverBlock:
    case Action::kOnRead:
    case Action::kGetLog:
        return _src_thread_pool;
    default:
        return _dst_thread_pool;
    }
}

bool Recoverer::Execute(Context* ctx) {
    SegmentPtr segment = ctx->segment.lock();
    if (segment && (ctx->action == Action::kStartRecovery ||
                ctx->action == Action::kRecoverBlock ||
                ctx->action == Action::kRecoverBlockFromPeer ||
                ctx->action == Action::kDisposeRecoveryBlock ||
                ctx->action == Action::kUpdateMetaStatus)) {
        segment_set_stage_info_with_action(segment, pspb::RecoverStageSchedule, ctx->action);
    }
    if (!GetThreadPool(ctx)->EmergentExecute(ctx)) {
        if (_stopped) {
            std::unique_ptr<Context> ctx_guard(ctx);
            dec_inflight_ref_if_on_recover(ctx);
            dec_inflight_req_num(ctx);
        } else {
            psvr_terminate();
        }
        return false;
    }
    return true;
}

bool Recoverer::Dispatch(SegmentPtr segment,
        bool is_force, bool /*is_reset*/ TRACE_FILE_LINE_DC) {
    if (segment->TurnOnRecovery(is_force)) {
        {
            std::unique_lock lm(_shared_mutex);
            std::shared_ptr<Task> recover_task(new Task(segment, false));
            recover_task->recover_total_size = segment->segment_size();
            _recover_store_tasks[segment->store_id()].emplace_back(recover_task);
            _stat_recover_left_size << recover_task->recover_total_size;
        }
        _recover_task_num.fetch_add(1, std::memory_order_relaxed);
        LOG(NOTICE) << segment << " add to recovery list!" << TRACE_FILE_LINE_LOG_STR;
        return true;
    } else {
        LOG(NOTICE) << segment << " in recovering!" << TRACE_FILE_LINE_LOG_STR;
        return false;
    }
}

void Recoverer::SetPriorNum(SegmentPtr segment, uint32_t prior_num) {
    std::unique_lock lm(_shared_mutex);
    auto& tasks = _recover_store_tasks[segment->store_id()];
    for (auto& task : tasks) {
        if (task->segment.lock() == segment) {
            if (task->prior_num != prior_num) {
                task->prior_num = prior_num;
                // order by prior_num DESC
                tasks.sort([](const auto& lhs, const auto& rhs){
                        return lhs->prior_num > rhs->prior_num;
                        });
            }
            return;
        }
    }
}

void Recoverer::AddSegmentToCheckList(SegmentPtr segment) {
    std::unique_lock lk(_shared_mutex);
    _segment_check_task_list.emplace_back(std::make_shared<Task>(segment, true));
    if (_segment_check_task_list.size() == 1lu) {
        _segment_check_iter = _segment_check_task_list.begin();
    }
}

void Recoverer::GetRecoveryInfo(pspb::ListRecoveryInfoResponse* response) {
    std::shared_lock slk(_shared_mutex);
    for (auto& it : _recover_store_tasks) {
        for (auto& ctx : it.second) {
            auto segment = ctx->segment.lock();
            if (segment) {
                auto seg_pb = response->add_segments();
                segment->GetRecoveryInfo(seg_pb);
                seg_pb->set_is_running(ctx->start_status);
                seg_pb->set_prior_num(ctx->prior_num);
            }
        }
    }
    response->set_disk_quota(FLAGS_psvr_recover_src_max_speed);
    response->set_total_quota(FLAGS_psvr_recover_src_store_max_speed);
}

void Recoverer::Schedule(Context* ctx TRACE_FILE_LINE_DC, uint64_t delay_us, bool is_retry) {
    PSVR_LOG_CTX(TRACE, ctx) << "ctx action:[" << static_cast<uint32_t>(ctx->action) << "," << action2str(ctx->action)
        << "] retry_times:[" << ctx->retry_times
        << "] ctx:[" << ctx
        << "]" << TRACE_FILE_LINE_LOG_STR;
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        dec_inflight_ref_if_on_recover(ctx);
        dec_inflight_req_num(ctx);
        return;
    }
    SetCtxClientId(ctx);
    if (is_retry) {
        ++ctx->retry_times;
    }
    SegmentPtr segment = ctx->segment.lock();
    if (segment && (ctx->action == Action::kStartRecovery ||
                ctx->action == Action::kRecoverBlock ||
                ctx->action == Action::kRecoverBlockFromPeer ||
                ctx->action == Action::kDisposeRecoveryBlock ||
                ctx->action == Action::kUpdateMetaStatus)) {
        segment_set_stage_info_with_action(segment, pspb::RecoverStageSchedule, ctx->action);
    }
    if (delay_us == 0) {
        if (GetThreadPool(ctx)->Execute(ctx)) {
            return;
        }
    } else {
        if (GetThreadPool(ctx)->Schedule(ctx, delay_us)) {
            return;
        }
    }

    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        dec_inflight_ref_if_on_recover(ctx);
        dec_inflight_req_num(ctx);
        return;
    }

    PSVR_LOG_CTX(ERROR, ctx) << "dispatch segment to recovery pool failed,"
        << TRACE_FILE_LINE_LOG_STR;
    psvr_terminate();
}

void Recoverer::OnCompletion(Context* ctx) {
    PSVR_LOG_CTX(TRACE, ctx) << "ctx action:[" << static_cast<uint32_t>(ctx->action) << "," << action2str(ctx->action)
        << "] retry_times:[" << ctx->retry_times
        << "] ctx:[" << ctx
        << "]";
    if (BAIDU_UNLIKELY(_stopped)) {
        std::unique_ptr<Context> ctx_guard(ctx);
        dec_inflight_ref_if_on_recover(ctx);
        dec_inflight_req_num(ctx);
        return;
    }
    SegmentPtr segment = ctx->segment.lock();
    if (segment && (ctx->action == Action::kStartRecovery ||
                ctx->action == Action::kRecoverBlock ||
                ctx->action == Action::kRecoverBlockFromPeer ||
                ctx->action == Action::kDisposeRecoveryBlock ||
                ctx->action == Action::kUpdateMetaStatus)) {
        segment_set_stage_info_with_action(segment, pspb::RecoverStageDo, ctx->action);
    }
    switch (ctx->action) {
    case Action::kDispatchRecovery:
        return DispatchRecovery(ctx);
    case Action::kStartRecovery:
        return StartRecovery(ctx);
    case Action::kRecoverBlock:
        return RecoverBlock(ctx);
    case Action::kRecoverBlockFromPeer:
        return RecoverBlockFromPeer(ctx);
    case Action::kDisposeRecoveryBlock:
        return DisposeRecoveryBlock(ctx);
    case Action::kUpdateMetaStatus:
        return UpdateMetaStatus(ctx);
    case Action::kOnRecoverBlock:
        return OnRecoverBlock(ctx);
    case Action::kCheck:
        return Check(ctx);
    case Action::kUpdateRecoveryStats:
        return UpdateRecoveryStats(ctx);
    case Action::kOnRead:
        return OnRead(ctx);
    case Action::kGetLog:
        return OnGetLog(ctx);
    case Action::kOnWrite:
        return OnWrite(ctx);
    default:
        PSVR_ASSERT(false);
    }
}

// Get task in list, and dispatch it to threads
void Recoverer::DispatchRecovery(Context* ctx) {
    const int32_t store_max_num = FLAGS_psvr_recover_task_parallel_num_per_store;
    std::unique_lock lm(_shared_mutex);
    for (auto it = _recover_store_tasks.begin();
            it != _recover_store_tasks.end() && !_stopped; ++it) {
        if (it->second.empty()) {
            continue;
        }

        int32_t store_num = 0;
        auto& store_task_list = it->second;
        for (auto store_it = store_task_list.begin();
                store_it != store_task_list.end(); ++store_it) {
            std::shared_ptr<Task> recover_task = *store_it;
            if (recover_task->start_status) {
                ++store_num;
                continue;
            }

            if (store_num + 1 > store_max_num) {
                break;
            }

            SegmentPtr segment = recover_task->segment.lock();
            if (!segment) {
                store_task_list.erase(store_it);
                _recover_task_num.fetch_sub(1, std::memory_order_relaxed);
                _stat_recover_left_size << -recover_task->recover_total_size.load();
            } else {
                if (!segment->is_start_lsn_ok()) {
                    continue;
                }

                recover_task->start_status = true;
                _recover_task_running_num.fetch_add(1, std::memory_order_release);

                auto* task_ctx = new Context(Action::kStartRecovery, segment);
                task_ctx->log_id = get_log_id();
                task_ctx->recover_task = recover_task;
                Schedule(task_ctx TRACE_FILE_LINE_CC);
            }
            break;  // do next store
        }
    }
    // schedule again
    Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(FLAGS_psvr_recover_check_task_interval_second));
}

void Recoverer::UpdateRecoveryStats(Context* ctx) {
    const int64_t recover_left_size = _stat_recover_left_size.get_value();
    const int64_t recover_bw = _stat_recover_bw.get_value();
    if (recover_left_size == 0) {
        _recover_expect_finish_time_s.store(0, std::memory_order_relaxed);
    } else if (recover_bw > 0) {
        _recover_expect_finish_time_s.store(recover_left_size / recover_bw, std::memory_order_relaxed);
    } else {
        _recover_expect_finish_time_s.store(-1, std::memory_order_relaxed);
    }
    Schedule(ctx TRACE_FILE_LINE_CC, kDelayUpdateRecoveryStats);
}

void Recoverer::Check(Context* ctx) {
    if (!ctx->recover_task) {
        std::unique_lock lk(_shared_mutex);
        if (_segment_check_task_list.empty()) {
            Schedule(ctx TRACE_FILE_LINE_CC, kDelayRunCheckTask);
            return;
        }
        if (_segment_check_iter == _segment_check_task_list.end()) {
            _segment_check_iter = _segment_check_task_list.begin();
        }
        ctx->recover_task = *_segment_check_iter;
    }

    do {
        SegmentPtr segment = ctx->recover_task->segment.lock();
        if (!segment_is_valid(segment)) {
            {
                std::unique_lock lk(_shared_mutex);
                _segment_check_iter = _segment_check_task_list.erase(_segment_check_iter);
            }
            LOG(TRACE) << "segment is invalid or is delete";
            break;
        }

        {
            std::unique_lock lk(_shared_mutex);
            ++_segment_check_iter;
        }

        if (!FLAGS_psvr_recover_enable_check) {
            LOG(TRACE) << "psvr disable check";
            break;
        }
        if (!segment->recovery_status_is_finish() || !segment->is_active()) {
            LOG(TRACE) << segment << " recovery status is invalid or is inactive";
            break;
        }
        if (!segment->EnableCheckAgain(second2microseconds(FLAGS_psvr_recover_check_interval))) {
            LOG(TRACE) << segment << " last check time is very new";
            break;
        }
        if (!segment->TurnOnRecovery(false)) {
            LOG(WARNING) << segment << " start recovery again?";
            break;
        }
        // ok, dispatch check task
        ctx->segment = segment;
        ctx->action = Action::kStartRecovery;
        ctx->log_id = get_log_id();
        Schedule(ctx TRACE_FILE_LINE_CC);
        return;

    } while (0);
    // retry to get next
    ctx->recover_task = nullptr;
    Schedule(ctx TRACE_FILE_LINE_CC, kDelayRunCheckTask);
}

void Recoverer::RecoverBlockError(std::shared_ptr<Task> recover_task) {
    if (recover_task->DecInflightReqSize() == 1) {
        FinishRecovery(recover_task);
    }
}

void Recoverer::FinishRecovery(std::shared_ptr<Task> recover_task) {
    PSVR_ASSERT(recover_task->InflightReqSize() == 0);
    SegmentPtr segment = recover_task->segment.lock();
    if (segment) {
        segment->FinishRecovery();
        segment->TurnOffRecovery();
        LOG(NOTICE) << segment << " end recovery,"
            << " is_check:[" << recover_task->is_check
            << "]";
    }
    if (!recover_task->is_check) {
        uint64_t remain_recover_size = recover_task->recover_total_size.load();
        _stat_recover_left_size << -remain_recover_size;
        {
            std::unique_lock lm(_shared_mutex);
            auto& store_list = _recover_store_tasks[recover_task->store_id];
            auto it = store_list.begin();
            for (; it != store_list.end(); ++it) {
                if (*it == recover_task) {
                    store_list.erase(it);
                    _recover_task_num.fetch_sub(1, std::memory_order_relaxed);
                    _recover_task_running_num.fetch_sub(1, std::memory_order_release);
                    return;
                }
            }
        }
        LOG(WARNING) << "not found a recovery task in list, store_id:[" << recover_task->store_id << "]";
    } else {
        // run next check task
        auto* ctx = new Context(Action::kCheck);
        ctx->log_id = get_log_id();
        Schedule(ctx TRACE_FILE_LINE_CC, kDelayRunCheckTask);
    }
}

void Recoverer::StartRecovery(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    auto segment = ctx->segment.lock();
    if (!segment_is_valid(segment)) {
        FinishRecovery(ctx->recover_task);
        return;
    }

    if (!segment->StartRecovery()) {
        Schedule(ctx_guard.release() TRACE_FILE_LINE_CC, second2microseconds(1));
        return;
    }
    PSVR_LOG_CTX(NOTICE, ctx) << segment << " start recovery,"
        << " is_check:[" << ctx->recover_task->is_check
        << "]";

    const int32_t task_size = std::max(1, FLAGS_psvr_recover_max_inflight_task_size);
    ctx->recover_task->task_size = task_size;
    int32_t i = 0;
    for (/*nothing*/; i < task_size && !_stopped; ++i) {
        //1) get block task
        RecoverBlockTask task;
        if (!segment->GetRecoveryNextBlockTask(&task)) {
            // not more block task
            break;
        }
        //2) add inflight_req_size
        ctx->recover_task->IncInflightReqSize();
        //3) dispatch block task
        auto recover_ctx = new Context(Action::kRecoverBlock, segment);
        recover_ctx->log_id = get_log_id();
        recover_ctx->task = task;
        recover_ctx->shift_client_id = kScheduleTaskThreadNum;
        recover_ctx->stat_timer.reset();
        recover_ctx->recover_task = ctx->recover_task;
        TP_INIT_IF(recover_ctx->tp, FLAGS_psvr_enable_recover_annotate);
        if (CheckQuota(recover_ctx, segment->store_id())) {
            OnGetQuota(recover_ctx);
        }
    }

    if (_stopped) {
        return;
    }

    // if segment recovery task interrupted at the beginning,
    // the first get block task will return failure.
    if (i == 0) {
        FinishRecovery(ctx->recover_task);
    }
}

void Recoverer::RecoverNextBlock(Context* ctx) {
    recover_define_control_or_return_invalid(ctx, true);
    recover_define_segment_or_return_invalid(ctx, true);
    recover_check_interrupt_segment_recovery(ctx, true);

    if (FLAGS_psvr_recover_long_query_time_us > 0
            && TP_ELAPSED(ctx->tp, FLAGS_psvr_recover_long_query_time_us)) {
        LOG(NOTICE) << segment << " slow recover request," << ctx->tp;
    }
    if (ctx->wait_gc) {
        segment->SetGcDelayForRecovery(false);
    }
    TP_DESTROY(ctx->tp);

    // stat lat
    _stat_recover_block_total_lat << ctx->stat_timer.u_elapsed();
    _stat_recover_block_ok_count << 1;
    if (!ctx->recover_task->is_check) {
        ctx->recover_task->recover_total_size.fetch_sub(ctx->task.size, std::memory_order_relaxed);
        _stat_recover_bw << ctx->task.size;
        _stat_recover_left_size << -ctx->task.size;
        _dst_flow_cntl->StatStoreBw(ctx->task.size, segment->store_id());
    }

    segment->FinishRecoveryBlockTask(ctx->task);

    auto recover_task = ctx->recover_task;
    int32_t task_size = std::max(1, FLAGS_psvr_recover_max_inflight_task_size);
    int32_t old_task_size = recover_task->task_size.load();

    // when inflight task size decreases
    if (task_size < old_task_size) {
        if (recover_task->TryDecInflightReqSize(task_size)) {
            recover_task->task_size.fetch_sub(1);
            std::unique_ptr<Context> ctx_guard(ctx);
            return;
        }
    }

    if (segment->GetRecoveryNextBlockTask(&ctx->task)) {
        ctx->Reset(Action::kRecoverBlock);
        TP_INIT_IF(ctx->tp, FLAGS_psvr_enable_recover_annotate);
        if (CheckQuota(ctx, segment->store_id())) {
            OnGetQuota(ctx);
        }

        // when inflight task size increases
        if (task_size > old_task_size) {
            int32_t diff = task_size - old_task_size;
            if (recover_task->task_size.compare_exchange_strong(old_task_size, task_size)) {
                for (int32_t i = 0; i < diff; ++i) {
                    //1) get block task
                    RecoverBlockTask task;
                    if (!segment->GetRecoveryNextBlockTask(&task)) {
                        // not more block task
                        break;
                    }
                    //2) add inflight_req_size
                    recover_task->IncInflightReqSize();
                    //3) dispatch block task
                    auto recover_ctx = new Context(Action::kRecoverBlock, segment);
                    recover_ctx->log_id = get_log_id();
                    recover_ctx->task = task;
                    recover_ctx->shift_client_id = kScheduleTaskThreadNum;
                    recover_ctx->stat_timer.reset();
                    recover_ctx->recover_task = recover_task;
                    TP_INIT_IF(recover_ctx->tp, FLAGS_psvr_enable_recover_annotate);
                    if (CheckQuota(recover_ctx, segment->store_id())) {
                        OnGetQuota(recover_ctx);
                    }
                }
            }
        }
    } else {
        std::unique_ptr<Context> ctx_guard(ctx);
        if (ctx->recover_task->DecInflightReqSize() == 1) {
            if (!ctx->recover_task->is_check) {
                ctx->Reset(Action::kUpdateMetaStatus);
                Schedule(ctx_guard.release() TRACE_FILE_LINE_CC);
            } else {
                FinishRecovery(ctx->recover_task);
            }
        }
    }
}

bool Recoverer::CheckQuota(Context* ctx, int32_t store_id) {
    if (ctx->recover_task->is_check) {
        if (!_quota_thread->GetQuota(ctx, _check_flow_cntl)) {
            return false;
        }
    } else {
        if (!_dst_flow_cntl->GetQuota(_quota_thread, ctx, store_id)) {
            return false;
        }
    }
    return true;
}

void Recoverer::OnGetQuota(Context* ctx) {
    ctx->has_quota = true;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Recoverer::OnEvent(Context* ctx, EventType ev_type) {
    recover_define_control_or_return_invalid(ctx, true);
    recover_define_segment_or_return_invalid(ctx, true);
    if (ctx->st.code() != pspb::Status_ReturnCode_SUCCESS) {
        if (ev_type == kEventSpace) {
            LOG_EVERY_N(WARNING, 64) << "recover get space meta failed,"
                << " space_id:[" << ctx->local_space_id
                << "] " << ctx->st;
        } else if (ev_type == kEventPage) {
            LOG_EVERY_N(WARNING, 64) << "recover get space page meta failed,"
                << " space_id:[" << ctx->local_space_id
                << "], page_no:[" << ctx->local_page_no
                << "], offset:[" << ctx->task.offset
                << "] " << ctx->st;
        } else if (ev_type == kEventPeer) {
            ctx->recover_from_peer_fail_num = 0;
            LOG_EVERY_N(WARNING, 64) << "recover get peer meta failed,"
                << " segment_id:[" << segment->segment_id()
                << "] " << ctx->st;
        }
        Schedule(ctx TRACE_FILE_LINE_CC, recovery_get_delay_us(ctx->retry_times), true);
    } else {
        ctx->retry_times = 0;
        Schedule(ctx TRACE_FILE_LINE_CC);
    }
}

void Recoverer::RecoverBlock(Context* ctx) {
    recover_define_control_or_return_invalid(ctx, true);
    recover_define_segment_or_return_invalid(ctx, true);
    recover_check_interrupt_segment_recovery(ctx, true);

    if (FLAGS_psvr_stop_recovery_work) {
        LOG_EVERY_SECOND(NOTICE) << "--psvr_stop_recovery_work is set true!!!";
        uint64_t delay_us = second2microseconds(base::fast_rand() % 60 + 30);
        Schedule(ctx TRACE_FILE_LINE_CC, delay_us, false);
        return;
    }

    // check quota
    if (!ctx->has_quota) {
        if (!CheckQuota(ctx, segment->store_id())) {
            _stat_recover_interrupt_by_quota_count << 1;
            return;
        }
    }

    ADD_TRACE_TP(ctx->tp, "start");
    thread_local BufBlockPtr tl_buf_block = nullptr;
    if (!tl_buf_block) {
        tl_buf_block = control->buf_pool()->AllocBufBlock(gaia_apply::FLAGS_univ_page_size);
    }
    if (!tl_buf_block) {
        PSVR_LOG_CTX(WARNING, ctx) << segment << " alloc buf failed,"
            << " size:[" << ctx->task.size
            << "]";
        _stat_recover_block_err_count << 1;
        Schedule(ctx TRACE_FILE_LINE_CC, recovery_get_delay_us(ctx->retry_times), true);
        return;
    }

    // before recovery, if local page:
    // 1) empty: If I am in a recovery status, recover page from peer. Otherwise recover next page.
    // 2) not empty: If page exist and match offset, recover next page. Otherwise recover page from peer.
    //
    // finish recovery:
    // 1) if local page is courrpt or empty, write peer data to file.
    // 2) if local page changed, reset recovery. Otherwise write peer data to file.

    bool local_block_data_success = false;
    do {
        db::Status s;
        const uint64_t physical_page_no = ctx->task.offset / ctx->task.size;
        db::PageLockPtr page_lock = segment->GetPageLock(physical_page_no);
        db::PageSharedLock lm(page_lock);
        s = segment->ReadPhysicalPageData(ctx->log_id,
                ctx->task.offset, ctx->task.size, tl_buf_block->frame);
        if (!s.IsOk()) {
            PSVR_LOG_CTX(ERROR, ctx) << segment << " read physical data failed,"
                << " offset:[" << ctx->task.offset
                << "] size:[" << ctx->task.size
                << "] is_check:[" << ctx->recover_task->is_check
                << "] " << s;
            _stat_recover_block_err_count << 1;
            Schedule(ctx TRACE_FILE_LINE_CC, recovery_get_delay_us(ctx->retry_times), true);
            return;
        }
        ADD_TRACE_TP(ctx->tp, "read_local");

        bool local_is_empty = false;
        bool local_is_corrupted = page_is_corrupted(tl_buf_block->frame, ctx->task.size, &local_is_empty);
        if (local_is_corrupted) {
            PSVR_LOG_CTX(WARNING, ctx) << segment << " physical data corrupted,"
                << " offset:[" << ctx->task.offset
                << "] size:[" << ctx->task.size
                << "] is_corrupted:[" << local_is_corrupted
                << "] is_empty:[" << local_is_empty
                << "] is_check:[" << ctx->recover_task->is_check
                << "]";
            break;
        }

        ctx->local_space_id = buf_block_get_space_id(tl_buf_block);
        ctx->local_page_no = buf_block_get_page_no(tl_buf_block);
        ctx->local_page_lsn = buf_block_get_page_lsn(tl_buf_block);

        PSVR_LOG_CTX(TRACE, ctx) << segment << " read local physical data,"
            << " offset:[" << ctx->task.offset
            << "] size:[" << ctx->task.size
            << "] space:[" << ctx->local_space_id
            << "] page:[" << ctx->local_page_no
            << "] lsn:[" << ctx->local_page_lsn
            << "] is_check:[" << ctx->recover_task->is_check
            << "]";

        if (local_is_empty) {
            local_block_data_success = segment->recovery_status_is_finish();
            if (local_block_data_success) {
                local_block_data_success = segment->DropGcPageInRecovery(page_lock, ctx->local_page_lsn);
            }
            break;
        }

        const uint32_t space_status = segment->GetSpaceStatus(ctx->local_space_id);
        if (space_status_is_unknown(space_status)) {
            auto closure = brpc::NewCallback(this, &Recoverer::OnEvent, ctx, kEventSpace);
            control->parser()->AddGetSpaceMetaEvent(segment TRACE_FILE_LINE_CC,
                    ctx->local_space_id, closure, &ctx->st);
            return;
        }

        if (!space_status_is_work(space_status)) {
            // space is deleted, get page from peer.
            PSVR_ASSERT(space_status_is_deleted(space_status));
            if (ctx->recover_task->is_check) {
                local_block_data_success = segment->DropGcPageInRecovery(page_lock, ctx->local_page_lsn);
            }
            break;
        }

        bool data_invalid = false;
        uint64_t page_physical_offset = ctx->task.offset;
        bool ret = segment->GetSpacePagePhysicalOffset(ctx->local_space_id,
                ctx->local_page_no, &page_physical_offset, &data_invalid);
        if (ret) {
            local_block_data_success = (page_physical_offset == ctx->task.offset);
            if (!local_block_data_success) {
                LOG(NOTICE) << segment << " found a reuse page and space exists,"
                    << " offset:[" << ctx->task.offset
                    << "] space:[" << ctx->local_space_id
                    << "] page_no:[" << ctx->local_page_no
                    << "]";
            } else {
                local_block_data_success = segment->DropGcPageInRecovery(page_lock, ctx->local_page_lsn);
            }
            break;
        } else {
            if (!data_invalid) {
                auto closure = brpc::NewCallback(this, &Recoverer::OnEvent, ctx, kEventPage);
                control->parser()->AddGetSpaceExtentEvent(segment TRACE_FILE_LINE_CC,
                        ctx->local_space_id, ctx->local_page_no, ctx->task.offset, closure, &ctx->st);
                return;
            } else {
                local_block_data_success = segment->DropGcPageInRecovery(page_lock, ctx->local_page_lsn);
                LOG(WARNING) << segment << " found a garbage page and space exists,"
                    << " offset:[" << ctx->task.offset
                    << "] space:[" << ctx->local_space_id
                    << "] page_no:[" << ctx->local_page_no
                    << "] local_success:[" << local_block_data_success
                    << "]";
            }
        }
        ADD_TRACE_TP(ctx->tp, "read_check");
    } while (false);

    if (local_block_data_success) {
        RecoverNextBlock(ctx);
    } else {
        if (ctx->recover_task->is_check) {
            if (!FLAGS_psvr_recover_block_if_check_fail) {
                LOG(ERROR) << segment << " check local block failed,"
                    << " offset:[" << ctx->task.offset
                    << "] size:[" << ctx->task.size
                    << "] space:[" << ctx->local_space_id
                    << "] page:[" << ctx->local_page_no
                    << "] lsn:[" << ctx->local_page_lsn
                    << "]";
                RecoverNextBlock(ctx);
                return;
            }

            LOG(WARNING) << segment << " check local block failed and try recover it,"
                << " offset:[" << ctx->task.offset
                << "] size:[" << ctx->task.size
                << "] space:[" << ctx->local_space_id
                << "] page:[" << ctx->local_page_no
                << "] lsn:[" << ctx->local_page_lsn
                << "]";
        }
        ctx->retry_times = 0;
        ctx->action = Action::kRecoverBlockFromPeer;
        Schedule(ctx TRACE_FILE_LINE_CC);
    }
}

void Recoverer::RecoverBlockFromPeer(Context* ctx) {
    recover_define_control_or_return_invalid(ctx, true);
    recover_define_segment_or_return_invalid(ctx, true);
    recover_check_interrupt_segment_recovery(ctx, true);

    ADD_TRACE_TP(ctx->tp, "read_peer");
    ctx->replicas.clear();
    ctx->empty_replicas.clear();
    bool ret = segment->GetPeerNodes(&ctx->replicas, ctx->recover_from_peer_fail_num == 0);
    if (!ret || ctx->recover_from_peer_fail_num > FLAGS_psvr_refresh_peers_err_times) {
        if (ctx->replicas.empty()) {
            auto closure = brpc::NewCallback(this, &Recoverer::OnEvent, ctx, kEventPeer);
            control->parser()->AddGetPeerEvent(segment TRACE_FILE_LINE_CC, closure, &ctx->st);
            return;
        } else {
            ctx->recover_from_peer_fail_num = 0;
            control->parser()->AddGetPeerEvent(segment TRACE_FILE_LINE_CC, nullptr, nullptr);
        }
    }

    PSVR_ASSERT(!ctx->replicas.empty());

    {   // for page lock
        const uint64_t physical_page_no = ctx->task.offset / ctx->task.size;
        auto page_lock = segment->GetPageLock(physical_page_no);
        db::PageSharedLock slk(page_lock);
        ctx->lsn = std::max(segment->recovery_lsn(), segment->gc_lsn());
    }

    auto* rpc_ctx = new RpcReadPageCtx;
    rpc_ctx->log_id = ctx->log_id;
    rpc_ctx->timeout_ms = FLAGS_psvr_recover_call_timeout_ms;
    rpc_ctx->servers = std::move(ctx->replicas);
    rpc_ctx->request.set_physical_offset(ctx->task.offset);
    rpc_ctx->request.set_size(ctx->task.size);
    rpc_ctx->request.set_request_lsn(ctx->lsn);
    if (FLAGS_psvr_recover_enable_incremental_completion
            && FLAGS_psvr_enable_append_file) {
        // The peer page must reach this append redo boundary before it can
        // be used as the base page for incremental completion.
        const auto append_checkpoint_lsn = segment->GetAppendDBCheckPointLsn();
        if (append_checkpoint_lsn > 0) {
            rpc_ctx->request.set_append_min_lsn(append_checkpoint_lsn);
        }
    }
    rpc_ctx->request.set_segment_id(segment->segment_id());
    rpc_ctx->request.set_cluster_id(segment->cluster_id());
    if (ctx->peer_wait_gc_lsn) {
        rpc_ctx->request.set_wait_gc_lsn(true);
    }
    if (FLAGS_psvr_recover_use_attachment) {
        rpc_ctx->request.set_enable_attachment(true);
        ctx->rpc_ctx_cntl.Reset();
        rpc_ctx->controller = &ctx->rpc_ctx_cntl;
    }

    if (rpc_ctx->current_server().has_zone()) {
        rpc_ctx->request.mutable_zone()->set_region(rpc_ctx->current_server().region);
        rpc_ctx->request.mutable_zone()->set_available_zone(rpc_ctx->current_server().available_zone);
    } else {
        rpc_ctx->request.clear_zone();
    }

    auto closure = brpc::NewCallback(this, &Recoverer::OnReadPhysicalPage, ctx, rpc_ctx);
    _client->ReadPhysicalPage(rpc_ctx, closure);
}

void Recoverer::OnReadPhysicalPage(Context* ctx, RpcReadPageCtx* rpc_ctx) {
    _stat_recover_peer_block_lat << rpc_ctx->latency_us;
    ADD_TRACE_TP(ctx->tp, "peer_rpc");
    ctx->rpc_ctx.reset(rpc_ctx);
    ctx->action = Action::kDisposeRecoveryBlock;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Recoverer::DisposeRecoveryBlock(Context* ctx) {
    auto rpc_ctx = ctx->rpc_ctx.release();
    std::unique_ptr<RpcReadPageCtx> rpc_ctx_guard(rpc_ctx);

    recover_define_control_or_return_invalid(ctx, true);
    recover_define_segment_or_return_invalid(ctx, true);
    recover_check_interrupt_segment_recovery(ctx, true);

#define RECOVERY_TASK_COMMON_LOG_STR    \
    << " log_id:[" << rpc_ctx->log_id   \
    << "] idx:[" << rpc_ctx->idx        \
    << "] server:[" << rpc_ctx->current_server()        \
    << "] empty_num:[" << ctx->empty_replicas.size()    \
    << "] replicas_num:[" << rpc_ctx->servers.size()    \
    << "] offset:[" << ctx->task.offset \
    << "] size:[" << ctx->task.size     \
    << "] lsn:[" << ctx->lsn

    thread_local BufBlockPtr tl_buf_block_rsp = nullptr;
    if (!tl_buf_block_rsp) {
        tl_buf_block_rsp = control->buf_pool()->AllocBufBlock(gaia_apply::FLAGS_univ_page_size);
    }

    bool response_ok = false;
    bool peer_is_empty = false;
    do {
        if (!tl_buf_block_rsp) {
            PSVR_LOG_CTX(WARNING, ctx) << segment << " alloc buf failed";
            break;
        }
        PSVR_ASSERT(tl_buf_block_rsp->frame);
        if (!rpc_ctx->status.IsOk()) {
            PSVR_LOG_CTX(WARNING, ctx) << segment << " recover page rpc failed,"
                RECOVERY_TASK_COMMON_LOG_STR
                << "] " << rpc_ctx->status;
            ++ctx->recover_from_peer_fail_num;
            segment->SetPeerNodeFailed(rpc_ctx->idx, rpc_ctx->current_server());
            break;
        }

        const pspb::ReadPageResponse& response = rpc_ctx->response;
        if (response.has_refresh_zone() && response.refresh_zone()) {
            PSVR_LOG_EVERY_SECOND(TRACE, ctx) << segment << " mismatch zone,"
                RECOVERY_TASK_COMMON_LOG_STR
                << "]";
        }

        // peer parse lsn < request lsn, so let gc sleep a few moment
        if (response.has_checkpoint_lsn()) {
            segment->set_peer_gc_lsn(response.checkpoint_lsn());
        }

        if (response.status().code() != pspb::Status::SUCCESS) {
            if (FLAGS_psvr_enable_append_file
                    && !ctx->wait_gc
                    && response.status().code() == pspb::Status::LIMIT) {
                ctx->wait_gc = true;
                segment->SetGcDelayForRecovery(true);
            }
            if (response.status().code() != pspb::Status::NOT_EXISTS) {
                ++ctx->recover_from_peer_fail_num;
            }
            LOG(TRACE) << segment << " recover page rpc rsp failed,"
                RECOVERY_TASK_COMMON_LOG_STR
                << "] " << response.status()
                << "]";
            PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx)
                << segment << " recover page rpc rsp failed,"
                RECOVERY_TASK_COMMON_LOG_STR
                << "] wait_gc:[" << ctx->wait_gc
                << "] retry_times:[" << ctx->retry_times
                << "] peer_lsn:[" << response.checkpoint_lsn()
                << "] peer_gc_lsn:[" << response.gc_lsn()
                << "] append_min_lsn:[" << (rpc_ctx->request.has_append_min_lsn() ? rpc_ctx->request.append_min_lsn() : 0)
                << "] " << response.status()
                << "]";
            break;
        }

        // check peer parse lsn
        bool need_to_replay_append_file_log = false;
        if (rpc_ctx->request.has_append_min_lsn() && response.has_gc_lsn()) {
            // The peer guarantees that the returned page contains all redo
            // before gc_lsn. Local append redo completes [gc_lsn, ctx->lsn].
            if (response.gc_lsn() < rpc_ctx->request.append_min_lsn()) {
                PSVR_LOG_CTX(WARNING, ctx) << segment << " peer gc lsn is older on recovery,"
                    RECOVERY_TASK_COMMON_LOG_STR
                    << "] request_append_min_lsn:[" << rpc_ctx->request.append_min_lsn()
                    << "] response_gc_lsn:[" << response.gc_lsn()
                    << "]";
                break;
            } else {
                need_to_replay_append_file_log = true;
            }
        } else if ((response.has_max_lsn() && response.max_lsn() < ctx->lsn)
                || (!response.has_max_lsn() && response.checkpoint_lsn() < ctx->lsn)) {
            PSVR_LOG_CTX(WARNING, ctx) << segment << " peer parse lsn is older on recovery,"
                RECOVERY_TASK_COMMON_LOG_STR
                << "] response_max_lsn:[" << response.max_lsn()
                << "] response_checkpoint_lsn:[" << response.checkpoint_lsn()
                << "]";
            break;
        }

        if (response.size() != ctx->task.size
                || ctx->task.size != gaia_apply::FLAGS_univ_page_size) {
            PSVR_LOG_CTX(WARNING, ctx) << segment << " peer rsp size invalid on recovery,"
                RECOVERY_TASK_COMMON_LOG_STR
                << "] response_size:[" << response.size()
                << "] buf_size:[" << gaia_apply::FLAGS_univ_page_size
                << "]";
            break;
        }

        if (response.has_attachment_data()) {
            const auto rsp_n = ctx->rpc_ctx_cntl.response_attachment().copy_to(
                    reinterpret_cast<char*>(tl_buf_block_rsp->frame), ctx->task.size);
            if (rsp_n != ctx->task.size) {
                PSVR_LOG_CTX(ERROR, ctx) << segment << " attachment size invalid,"
                    RECOVERY_TASK_COMMON_LOG_STR
                    << "] attachment_size:[" << rsp_n
                    << "]";
                break;
            }
        } else {
            // response data length must be equal ctx->task.size
            if (response.data().size() != ctx->task.size) {
                PSVR_LOG_CTX(ERROR, ctx) << segment << " response data size invalid,"
                    RECOVERY_TASK_COMMON_LOG_STR
                    << "] response:[" << response.data().size()
                    << "]";
                break;
            }
            std::memcpy(tl_buf_block_rsp->frame, response.data().c_str(), ctx->task.size);
        }

        if (response.has_data_crc()
                && response.data_crc() != gaiadb::common::ut_crc32(tl_buf_block_rsp->frame, ctx->task.size)) {
            PSVR_LOG_CTX(ERROR, ctx) << segment << " peer page data crc mismatch on recovery,"
                RECOVERY_TASK_COMMON_LOG_STR
                << "] response_crc:[" << response.data_crc()
                << "]";
            break;
        }

        if (page_is_corrupted(tl_buf_block_rsp->frame, ctx->task.size, &peer_is_empty)) {
            PSVR_LOG_CTX(ERROR, ctx) << segment << " peer page data is corrupted on recovery,"
                RECOVERY_TASK_COMMON_LOG_STR
                << "]";
            break;
        }

        if (need_to_replay_append_file_log) {
            const auto space_id = buf_block_get_space_id(tl_buf_block_rsp);
            const auto page_no = buf_block_get_page_no(tl_buf_block_rsp);
            init_buf_block(tl_buf_block_rsp, space_id, page_no, gaia_page_size());
            // Per-thread read-ahead buffer for the append redo reads below.
            thread_local AppendReadBuf tl_append_read_buf(FLAGS_psvr_append_recover_read_buf_size);
            tl_append_read_buf.Reset();
            Timer timer(base::Timer::STARTED);
            db::Status st = segment->ApplyAppendRedoToPageNoLock(ctx->log_id,
                    ctx->task.offset, response.gc_lsn(), ctx->lsn,
                    tl_buf_block_rsp, &tl_append_read_buf);
            _stat_recover_block_apply_append_log_lat << timer.u_elapsed();
            if (!st.IsOk() && !st.IsAhead()) {
                PSVR_LOG_CTX(WARNING, ctx) << segment << " replay append file log failed,"
                    RECOVERY_TASK_COMMON_LOG_STR
                    << "] space_id:[" << space_id
                    << "] page_no:[" << page_no
                    << "] response_gc_lsn:[" << response.gc_lsn()
                    << "] " << st;
                break;
            }

            if (page_is_corrupted(tl_buf_block_rsp->frame, ctx->task.size, &peer_is_empty)) {
                PSVR_LOG_CTX(ERROR, ctx) << segment << " peer page data is corrupted on recovery,"
                    RECOVERY_TASK_COMMON_LOG_STR
                    << "]";
                break;
            }

            if (peer_is_empty) {
                rpc_ctx->response.set_valid_empty(true);
            }

            _stat_recover_block_apply_append_log_count << 1;
        }

        segment->MovePeerNodeToFirst(rpc_ctx->idx, rpc_ctx->current_server());
        if (peer_is_empty) {
            const bool valid_empty = (response.has_valid_empty() && response.valid_empty());
            PSVR_LOG_CTX(TRACE, ctx) << segment << " peer page data is empty on recovery,"
                RECOVERY_TASK_COMMON_LOG_STR
                << "] valid_empty:[" << valid_empty
                << "]";
            ctx->empty_replicas.emplace(rpc_ctx->current_server().addr);
            if (!valid_empty && ctx->empty_replicas.size() < calc_peer_majority_num(rpc_ctx->servers.size() + 1)) {
                break;
            }
            // else: remote peer majority empty or believable empty
        }

        response_ok = true;
    } while (false);

    bool retry_quick = false;
    do {
        if (!response_ok) {
            break;
        }

        ADD_TRACE_TP(ctx->tp, "rpc_check");
        // Only for OnRecovery threads
        // 4 threads * 16KB = 64KB
        thread_local BufBlockPtr tl_buf_block = nullptr;
        if (!tl_buf_block) {
            tl_buf_block = control->buf_pool()->AllocBufBlock(gaia_apply::FLAGS_univ_page_size);
        }
        if (!tl_buf_block) {
            LOG(WARNING) << segment << " alloc buf failed";
            break;
        }

        const gaia_apply::space_id_t space_id = buf_block_get_space_id(tl_buf_block_rsp);
        const gaia_apply::page_no_t page_no = buf_block_get_page_no(tl_buf_block_rsp);
        const gaia_apply::lsn_t page_lsn = buf_block_get_page_lsn(tl_buf_block_rsp);

        db::Status s;
        const uint64_t physical_page_no = ctx->task.offset / ctx->task.size;
        auto page_lock = segment->GetPageLock(physical_page_no);
        // lock page
        db::PageUniqueLock lk(page_lock);
        gaia_apply::lsn_t min_apply_lsn = 0;
        gaia_apply::lsn_t page_min_apply_lsn = 0;
        const bool gc_page_in_recovery = segment->CheckGcPageInRecovery(page_lock,
                &page_min_apply_lsn, &min_apply_lsn);
        bool check_page_lsn_ok = false;
        if (gc_page_in_recovery) {
            check_page_lsn_ok = page_min_apply_lsn <= page_lsn;
        } else {
            check_page_lsn_ok = min_apply_lsn <= ctx->lsn;
        }

        if (!check_page_lsn_ok) {
            retry_quick = true;
            if (!ctx->wait_gc) {
                ctx->wait_gc = true;
                segment->SetGcDelayForRecovery(true);
            }
            _stat_recover_block_invalid_lsn_count << 1;
            LOG(TRACE) << segment << " recover data lsn lower than page gc,"
                RECOVERY_TASK_COMMON_LOG_STR
                << "] space_id:[" << space_id
                << "] page_no:[" << page_no
                << "] page_lsn:[" << page_lsn
                << "] page_min_apply_lsn:[" << page_min_apply_lsn
                << "] min_apply_lsn:[" << min_apply_lsn
                << "]";
            LOG_EVERY_N(NOTICE, 128) << segment << " recover data lsn lower than page gc,"
                RECOVERY_TASK_COMMON_LOG_STR
                << "] space_id:[" << space_id
                << "] page_no:[" << page_no
                << "] page_lsn:[" << page_lsn
                << "] page_min_apply_lsn:[" << page_min_apply_lsn
                << "] min_apply_lsn:[" << min_apply_lsn
                << "]";
            break;
        }

        uint64_t real_write_size = ctx->task.size;
        s = segment->ReadPhysicalPageData(ctx->log_id,
                ctx->task.offset, ctx->task.size, tl_buf_block->frame, nullptr, &real_write_size);
        if (!s.IsOk()) {
            LOG(WARNING) << segment << " read block failed,"
                << " offset:[" << ctx->task.offset
                << "] size:[" << ctx->task.size
                << "]";
            break;
        }

        bool write_local_page = false;
        bool local_is_empty = false;
        if (page_is_corrupted(tl_buf_block->frame, ctx->task.size, &local_is_empty)) {
            write_local_page = true;
        } else if (local_is_empty) {
            write_local_page = true;
        } else {
            // check local has data and remote data
            const auto local_space_id = buf_block_get_space_id(tl_buf_block);
            const auto local_page_no = buf_block_get_page_no(tl_buf_block);
            const auto local_page_lsn = buf_block_get_page_lsn(tl_buf_block);

            const bool local_updated = ctx->local_space_id != local_space_id
                || ctx->local_page_no != local_page_no
                || ctx->local_page_lsn != local_page_lsn;
            if (local_updated) {
                LOG(WARNING) << segment << " local block updated,"
                    << " offset:[" << ctx->task.offset
                    << "] size:[" << ctx->task.size
                    << "] space:[" << local_space_id << "," << ctx->local_space_id
                    << "] page:[" << local_page_no << "," << ctx->local_page_no
                    << "] page_lsn:[" << local_page_lsn << "," << ctx->local_page_lsn
                    << "]";
                break;
            } else {
                write_local_page = true;
            }
        }

        if (write_local_page) {
            if (peer_is_empty) {     // remote is empty
                if (!local_is_empty || real_write_size > 0) {
                    s = segment->TrimPhysicalPageData(ctx->log_id, space_id, page_no,
                            ctx->task.offset, ctx->task.size, true);
                } // else: local and peer are empty
            } else {
                s = segment->WritePhysicalPageData(ctx->log_id, space_id, page_no,
                        ctx->task.offset, ctx->task.size, tl_buf_block_rsp->frame);
            }
        }

        if (s.IsOk()) {
            if (!segment->DropGcPageInRecovery(page_lock, page_lsn)) {
                break;
            }
        }

        ADD_TRACE_TP(ctx->tp, "rw");
        if (!s.IsOk()) {
            PSVR_LOG_CTX(ERROR, ctx) << segment << " recovery failed,"
                RECOVERY_TASK_COMMON_LOG_STR
                << "] space:[" << space_id
                << "] page:[" << page_no
                << "] " << s;
            break;
        }

        PSVR_LOG_CTX(TRACE, ctx) << segment << " recover ok,"
            RECOVERY_TASK_COMMON_LOG_STR
            << "] space:[" << space_id
            << "] page:[" << page_no
            << "] page_lsn:[" << page_lsn
            << "] " << s;
        RecoverNextBlock(ctx);
        return;
    } while(false);

    LOG(TRACE) << segment << " retry recover block,"
        << " response_ok:[" << response_ok
        << "] retry_quick:[" << retry_quick
        << "]";
    _stat_recover_block_err_count << 1;
    ctx->peer_wait_gc_lsn = peer_is_empty;
    if (rpc_ctx->RetryNext()) {
        if (response_ok) {
            ctx->rpc_ctx_cntl.Reset();
            auto closure = brpc::NewCallback(this, &Recoverer::OnReadPhysicalPage, ctx, rpc_ctx_guard.release());
            _client->ReadPhysicalPage(rpc_ctx, closure);
        } else {
            auto bthread_ctx = new BthreadTimerContext;
            bthread_ctx->recoverer = this;
            bthread_ctx->recovery_ctx = ctx;
#define DELAY_BETWEEN_READ_PEER_MS (std::max(FLAGS_psvr_recover_delay_min_us/1000, 1lu))
            bthread_ctx->rpc_ctx.reset(rpc_ctx_guard.release());
            bthread_ctx->retry_tm = base::milliseconds_to_timespec(base::gettimeofday_ms() + DELAY_BETWEEN_READ_PEER_MS);
            int ret = bthread_timer_add(&bthread_ctx->timer_id, bthread_ctx->retry_tm, [](void* arg) {
                        auto _bthread_ctx = static_cast<BthreadTimerContext*>(arg);
                        _bthread_ctx->recoverer->DelayRecoverBlockFromPeer(_bthread_ctx);
                    }, bthread_ctx);
            if (ret != 0) {
                DelayRecoverBlockFromPeer(bthread_ctx);
            }
        }
    } else {
        ctx->action = Action::kRecoverBlock;
        if (!retry_quick) {
            ctx->has_quota = false;
            Schedule(ctx TRACE_FILE_LINE_CC, recovery_get_delay_us(ctx->retry_times), true);
        } else {
            Schedule(ctx TRACE_FILE_LINE_CC);
        }
    }
}

void Recoverer::DelayRecoverBlockFromPeer(BthreadTimerContext* bthread_ctx) {
    std::unique_ptr<BthreadTimerContext> bthread_ctx_guard(bthread_ctx);
    recover_define_control_or_return_invalid(bthread_ctx->recovery_ctx, true);
    bthread_ctx->recovery_ctx->rpc_ctx_cntl.Reset();
    auto closure = brpc::NewCallback(this, &Recoverer::OnReadPhysicalPage,
            bthread_ctx->recovery_ctx, bthread_ctx->rpc_ctx.get());
    _client->ReadPhysicalPage(bthread_ctx->rpc_ctx.release(), closure);
}

void Recoverer::UpdateMetaStatus(Context* ctx) {
    recover_define_control_or_return_invalid(ctx, false);
    recover_define_segment_or_return_invalid(ctx, false);

    PsmInfoPtr psm_info = segment->GetPsmInfo();
    std::vector<base::EndPoint> nodes;
    if (!psm_info->GetOrRefreshNodes(&nodes)) {
        control->RefreshPsmInfo(psm_info);
        Schedule(ctx TRACE_FILE_LINE_CC, recovery_get_delay_us(ctx->retry_times), true);
        return;
    }

    if (!segment->CheckRecovery()) {
        Schedule(ctx TRACE_FILE_LINE_CC, recovery_get_delay_us(ctx->retry_times), true);
        return;
    }

    std::string addr = gaiadb::common::endpoint2str(control->myself());
    auto* rpc_ctx = new RpcUpdateReplicaRecoveryStatusCtx;
    rpc_ctx->servers = std::move(nodes);
    rpc_ctx->request.set_cluster_id(segment->cluster_id());
    rpc_ctx->request.set_segment_id(segment->segment_id());
    rpc_ctx->request.set_replica_id(segment->replica_id());
    rpc_ctx->request.set_addr(addr);
    rpc_ctx->request.set_status(segment->recovery_status());
    if (segment->version() > 0) {
        rpc_ctx->request.set_version(segment->version());
    }

    auto closure = brpc::NewCallback(this, &Recoverer::OnUpdateReplicaRecoveryStatus, ctx, rpc_ctx);
    _client->UpdateReplicaRecoveryStatus(rpc_ctx, closure);
}

void Recoverer::OnUpdateReplicaRecoveryStatus(Context* ctx,
        RpcUpdateReplicaRecoveryStatusCtx* rpc_ctx) {
    std::unique_ptr<RpcUpdateReplicaRecoveryStatusCtx> rpc_ctx_guard(rpc_ctx);

    recover_define_control_or_return_invalid(ctx, false);
    recover_define_segment_or_return_invalid(ctx, false);

    std::unique_ptr<Context> ctx_guard(ctx);
    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        if (!not_exists) {
            if (rpc_ctx->RetryNext()) {
                auto closure = brpc::NewCallback(this, &Recoverer::OnUpdateReplicaRecoveryStatus,
                        ctx_guard.release(), rpc_ctx_guard.release());
                _client->UpdateReplicaRecoveryStatus(rpc_ctx, closure);
            } else {
                control->RefreshPsmInfo(segment->GetPsmInfo());
                ctx_guard.release();
                Schedule(ctx TRACE_FILE_LINE_CC, recovery_get_delay_us(ctx->retry_times), true);
            }
            return;
        }
    }

    segment->GetPsmInfo()->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());
    PSVR_LOG_CTX(NOTICE, ctx) << segment << " recovery ok, not_exists:[" << not_exists << "]";
    FinishRecovery(ctx->recover_task);
}

void Recoverer::ConditionSchedule(Context* ctx,
        SegmentPtr segment, gaia_apply::lsn_t lsn) {
    LOG(TRACE) << segment << " add to recover wait queue, lsn:[" << lsn << "]";
    _on_recover_in_wait_size.fetch_add(1, std::memory_order_relaxed);
    _condition_thread_pool->Schedule(segment->GetClusterHashVal(),
            ConditionTask(ctx, segment, lsn));
}

void Recoverer::ConditionFn(const ConditionTask& task) {
    LOG(TRACE) << task.segment << " get out of the recover wait queue";
    _on_recover_in_wait_size.fetch_sub(1, std::memory_order_relaxed);
    Execute(task.ctx);
}

// for src
void Recoverer::Dispatch(SegmentPtr segment, brpc::Controller* cntl,
        const pspb::ReadPageRequest* request,
        pspb::ReadPageResponse* response, ggpb::Closure* closure) {
    // set default response
    set_rpc_status(response->mutable_status(), pspb::Status::INVALID, "wait");

    if (FLAGS_psvr_recover_disabled_as_data_source) {
        baidu::rpc::ClosureGuard guard(closure);
        set_rpc_status(response->mutable_status(), pspb::Status::LIMIT, "disable as data source");
        return;
    }

    bool counted = false;
    if (!try_add_inflight_req_num(_inflight_read_for_recovery_req_num,
                FLAGS_psvr_recover_max_read_for_recovery_num, &counted)) {
        baidu::rpc::ClosureGuard guard(closure);
        set_rpc_status(response->mutable_status(), pspb::Status::LIMIT, "inflight num overflow");
        return;
    }

    _on_recover_inflight_req_size.fetch_add(1, std::memory_order_relaxed);

    auto* ctx = new Context(Action::kOnRecoverBlock, segment, request, response, closure);
    ctx->counted_inflight = counted;
    ctx->log_id = response->log_id();
    ctx->shift_client_id = kScheduleTaskThreadNum + _src_thread_num;
    ctx->cntl = cntl;
    ctx->task.offset = request->physical_offset();
    ctx->task.size = request->size();
    ctx->lsn = request->request_lsn();
    ctx->stat_timer.reset();
    Schedule(ctx TRACE_FILE_LINE_CC);
}

// my peer read myself page data
void Recoverer::OnRecoverBlock(Context* ctx) {
    std::unique_ptr<Context, std::function<void(Context*)>> ctx_guard(ctx,
            [this](Context* ctx_ptr) {
                _stat_on_recover_block_lat << ctx_ptr->stat_timer.u_elapsed();
                if (ctx_ptr->response->status().code() != pspb::Status::SUCCESS) {
                    _stat_on_recover_block_err_count << 1;
                }
                dec_inflight_ref_if_on_recover(ctx_ptr);
                dec_inflight_req_num(ctx_ptr);
                delete ctx_ptr;
            });

    auto* status = ctx->response->mutable_status();

    ControlPtr control = _control.lock();
    if (_stopped || !control) {
        set_rpc_status(status, pspb::Status::ERROR, "server not work");
        return;
    }

    SegmentPtr segment = ctx->segment.lock();
    if (!segment) {
        set_rpc_status(status, pspb::Status::NOT_EXISTS, "not found segment");
        return;
    }

    if (ctx->task.offset % gaia_apply::FLAGS_univ_page_size != 0
            || ctx->task.size % gaia_apply::FLAGS_univ_page_size != 0
            || ctx->task.offset >= segment->segment_size()
            || ctx->task.offset + ctx->task.size > segment->segment_size()
            || ctx->task.size != gaia_apply::FLAGS_univ_page_size) {
        set_rpc_status(status, pspb::Status::INVALID, "offset:%lu or size:%lu invalid",
                ctx->task.offset, ctx->task.size);
        return;
    }

    segment->UpdatePeerLastRecoverTime();

    const bool check_gc_lsn = ctx->request->has_wait_gc_lsn() ? ctx->request->wait_gc_lsn() : false;
    const auto max_lsn = segment->parse_lsn();
    ctx->response->set_max_lsn(max_lsn);
    gaia_apply::lsn_t wait_lsn_value = ctx->lsn;
    const gaia_apply::lsn_t gc_lsn = segment->gc_lsn();
    bool wait_lsn = check_gc_lsn ? (gc_lsn < ctx->lsn) : (max_lsn < ctx->lsn);
    bool in_recovery = segment->in_recovery();
    // For incremental completion, wait until the peer page contains all redo
    // before append_min_lsn, then return the actual gc_lsn as the replay start.
    if (ctx->request->has_append_min_lsn() && ctx->request->append_min_lsn() > 0 && !in_recovery) {
        wait_lsn_value = ctx->request->append_min_lsn();
        wait_lsn = gc_lsn < wait_lsn_value;
    }
    if (wait_lsn) {
        if (ctx->in_condition
                || _on_recover_in_wait_size.load() > FLAGS_psvr_recover_max_wait_lsn_size) {
            set_rpc_status(status, pspb::Status::LIMIT, "expect lsn:%lu more than gc_lsn:%lu",
                    wait_lsn_value, gc_lsn);
        } else {
            ctx->in_condition = true;
            ConditionSchedule(ctx_guard.release(), segment, wait_lsn_value);
        }
        return;
    }

    ctx->response->set_checkpoint_lsn(gc_lsn);
    ctx->response->set_valid_empty(segment->recovery_status_is_finish());
    ctx->response->clear_data();

    auto delay_us = _src_flow_cntl->GetQuota(ctx->task.size, segment->store_id());
    if (delay_us) {
        set_rpc_status(status, pspb::Status::LIMIT, "get store quota failed, id:%d",
                segment->store_id());
        return;
    }

    // Only for OnRecovery threads
    // 4 threads * 16KB = 64KB
    thread_local BufBlockPtr tl_buf_block = nullptr;
    if (!tl_buf_block) {
        tl_buf_block = control->buf_pool()->AllocBufBlock(gaia_apply::FLAGS_univ_page_size);
    }
    if (!tl_buf_block || ctx->task.size != gaia_apply::FLAGS_univ_page_size) {
        set_rpc_status(status, pspb::Status::LIMIT, "alloc buf failed, size:%lu",
                ctx->task.size);
        return;
    }

    const uint64_t physical_page_no = ctx->task.offset / ctx->task.size;
    db::PageLockPtr page_lock = segment->GetPageLock(physical_page_no);
    do {
        db::PageSharedLock lk(page_lock, std::try_to_lock);
        if (!lk) {
            set_rpc_status(status, pspb::Status::LIMIT, "get physical page:%lu lock failed",
                    physical_page_no);
            break;
        }

        gaia_apply::lsn_t ckp_lsn = 0;
        segment->dblwr()->ReadCkpLsn(&ckp_lsn);

        db::Status s = segment->ReadPhysicalPageDataWithDblwr(ctx->log_id, ctx->task.offset,
                ctx->task.size, tl_buf_block->frame);
        if (!s.IsOk()) {
            set_rpc_status(status, pspb::Status::ERROR,
                    "read page data failed, offset:%lu, size:%lu, error:%s",
                    ctx->task.offset, ctx->task.size, s.ToStr().c_str());
            break;
        }

        _src_flow_cntl->StatStoreBw(ctx->task.size, segment->store_id());
        bool is_empty = false;
        if (page_is_corrupted(tl_buf_block->frame, ctx->task.size, &is_empty)) {
            PSVR_LOG_CTX(ERROR, ctx) << "page data is corrupted,"
                << " offset:[" << ctx->task.offset
                << "] size:[" << ctx->task.size
                << "]";
            set_rpc_status(status, pspb::Status::ERROR,
                    "read page data is corrupted, offset:%lu size:%lu",
                    ctx->task.offset, ctx->task.size);
            break;
        }

        if (ctx->request->has_append_min_lsn() && ctx->request->append_min_lsn() > 0 && !in_recovery) {
            ctx->response->set_gc_lsn(gc_lsn);
            set_rpc_status(status, pspb::Status::SUCCESS, "read ok");
            break;
        }

        if (is_empty) {
            if (ctx->lsn <= gc_lsn) {
                set_rpc_status(status, pspb::Status::SUCCESS, "read page data is empty");
            } else {
                set_rpc_status(status, pspb::Status::LIMIT,
                        "read a doubt empty data, lsn:%lu gc_lsn:%lu",
                        ctx->lsn, gc_lsn);
            }
            break;
        }

        ctx->local_space_id = gaia_apply::page_get_space_id(tl_buf_block->frame);
        ctx->local_page_no = gaia_apply::page_get_page_no(tl_buf_block->frame);

        const uint32_t space_status = segment->GetSpaceStatus(ctx->local_space_id);
        if (space_status_is_unknown(space_status)) {
            set_rpc_status(status, pspb::Status::ERROR,
                    "wait to get space meta with unknown, space:%u page:%u",
                    ctx->local_space_id, ctx->local_page_no);
            control->parser()->AddGetSpaceMetaEvent(segment TRACE_FILE_LINE_CC, ctx->local_space_id, nullptr, nullptr);
            break;
        }

        if (!space_status_is_work(space_status)) {
            PSVR_ASSERT(space_status_is_deleted(space_status));
            if (ctx->lsn <= std::max(gc_lsn, ckp_lsn)) {
                set_rpc_status(status, pspb::Status::SUCCESS, "space is delete");
            } else {
                set_rpc_status(status, pspb::Status::LIMIT,
                        "wait space to delete, lsn:%lu gc_lsn:%lu",
                        ctx->lsn, gc_lsn);
            }
            break;
        }

        bool data_invalid = false;
        uint64_t page_physical_offset = ctx->task.offset;
        bool ret = segment->GetSpacePagePhysicalOffset(ctx->local_space_id,
                ctx->local_page_no, &page_physical_offset, &data_invalid);
        if (!ret) {
            if (!data_invalid) {
                set_rpc_status(status, pspb::Status::ERROR,
                        "get offset failed, space:%u page:%u",
                        ctx->local_space_id, ctx->local_page_no);

                control->parser()->AddGetSpaceExtentEvent(segment TRACE_FILE_LINE_CC,
                        ctx->local_space_id, ctx->local_page_no, ctx->task.offset, nullptr, nullptr);
            } else {
                LOG(WARNING) << segment << " found a garbage page and space exists,"
                    << " offset:[" << ctx->task.offset
                    << "] space:[" << ctx->local_space_id
                    << "] page_no:[" << ctx->local_page_no
                    << "]";
                memset(tl_buf_block->frame, 0x0, ctx->task.size);
                set_rpc_status(status, pspb::Status::SUCCESS, "read a garbage page");
            }
            break;
        }

        if (page_physical_offset != ctx->task.offset) {
            LOG(NOTICE) << segment << " found a reuse page and space exists,"
                << " offset:[" << ctx->task.offset
                << "] space:[" << ctx->local_space_id
                << "] page_no:[" << ctx->local_page_no
                << "]";
            memset(tl_buf_block->frame, 0x0, ctx->task.size);
            set_rpc_status(status, pspb::Status::SUCCESS, "read a reuse page");
            break;
        }

        if (std::max(gc_lsn, ckp_lsn) >= ctx->lsn) {
            set_rpc_status(status, pspb::Status::SUCCESS, "read a page ok");
            break;
        }

        // init buf meta to apply
        init_buf_block(tl_buf_block, ctx->local_space_id, ctx->local_page_no, gaia_page_size());

        // space, page, offset are matched, apply it
        PagePtr page = segment->GetPage(ctx->local_space_id, ctx->local_page_no);
        if (!page) {
            set_rpc_status(status, pspb::Status::SUCCESS, "no apply page");
            break;
        }

        std::shared_lock lm(page->shared_mutex());
        gaia_apply::lsn_t log_record_min_lsn = 0;
        if (page->LogRecordIsEmptyNoLock(ctx->lsn, &log_record_min_lsn)) {
            set_rpc_status(status, pspb::Status::SUCCESS, "no apply page");
            break;
        }

        PageLogRecordIterator iter(page);
        uint32_t apply_size = 0;
        s = segment->ApplyPageLogRecordsNoLock(ctx->log_id,
                page_physical_offset, ctx->lsn, tl_buf_block, iter, &apply_size);
        if (s.IsOk() || s.IsAhead()) {
            set_rpc_status(status, pspb::Status::SUCCESS, "apply page");
        } else {
            set_rpc_status(status, pspb::Status::ERROR, s.msg);
        }
    } while (0);

    if (status->code() == pspb::Status::SUCCESS) {
        if (ctx->request->enable_attachment()
                && FLAGS_psvr_recover_use_attachment && ctx->cntl) {
            ctx->cntl->response_attachment().append(tl_buf_block->frame, ctx->task.size);
            ctx->response->set_attachment_data(true);
        } else {
            ctx->response->set_data(tl_buf_block->frame, ctx->task.size);
        }
        ctx->response->set_size(ctx->task.size);
        ctx->response->set_data_crc(gaiadb::common::ut_crc32(tl_buf_block->frame, ctx->task.size));
    }
}

// for read
void Recoverer::Dispatch(SegmentPtr segment, brpc::Controller* cntl,
        const pspb::ReadRequest* request,
        pspb::ReadResponse* response, ggpb::Closure* closure) {
    // set default response
    set_rpc_status(response->mutable_status(), pspb::Status::INVALID, "wait");

    if (FLAGS_psvr_recover_disabled_as_data_source) {
        baidu::rpc::ClosureGuard guard(closure);
        set_rpc_status(response->mutable_status(), pspb::Status::LIMIT, "disable as data source");
        return;
    }

    bool counted = false;
    if (!try_add_inflight_req_num(_inflight_read_for_backup_req_num,
                FLAGS_psvr_recover_max_read_for_backup_num, &counted)) {
        baidu::rpc::ClosureGuard guard(closure);
        set_rpc_status(response->mutable_status(), pspb::Status::LIMIT, "inflight num overflow");
        return;
    }

    _on_recover_inflight_req_size.fetch_add(1, std::memory_order_relaxed);

    auto* ctx = new Context(Action::kOnRead, segment, request, response, closure);
    ctx->counted_inflight = counted;
    ctx->log_id = response->log_id();
    ctx->shift_client_id = kScheduleTaskThreadNum + _src_thread_num;
    ctx->cntl = cntl;
    ctx->task.offset = request->offset();
    ctx->task.size = request->size();
    ctx->stat_timer.reset();
    Schedule(ctx TRACE_FILE_LINE_CC);
}

// read physical offset page
void Recoverer::OnRead(Context* ctx) {
    std::unique_ptr<Context, std::function<void(Context*)>> ctx_guard(ctx,
            [this](Context* ctx_ptr) {
                _stat_on_read_block_lat << ctx_ptr->stat_timer.u_elapsed();
                dec_inflight_ref_if_on_recover(ctx_ptr);
                dec_inflight_req_num(ctx_ptr);
                delete ctx_ptr;
            });
    auto* status = ctx->read_rsp->mutable_status();
    ControlPtr control = _control.lock();
    if (_stopped || !control) {
        set_rpc_status(status, pspb::Status::ERROR, "server not work");
        return;
    }

    SegmentPtr segment = ctx->segment.lock();
    if (!segment) {
        set_rpc_status(status, pspb::Status::NOT_EXISTS, "not found");
        return;
    }

    if (segment->in_recovery()) {
        set_rpc_status(status, pspb::Status::IN_RECOVERY,
                "segment in recovery, segment_id:%u", segment->segment_id());
        return;
    }

    auto offset = ctx->task.offset;
    const auto end_offset = ctx->task.offset + ctx->task.size;
    constexpr uint64_t kMaxReadSize = 4lu << 20;
    if (ctx->task.size > kMaxReadSize
            || offset == end_offset
            || offset % gaia_apply::FLAGS_univ_page_size != 0
            || end_offset % gaia_apply::FLAGS_univ_page_size != 0
            || offset >= segment->segment_size()
            || end_offset > segment->segment_size()) {
        set_rpc_status(status, pspb::Status::INVALID,
                "size must align page and lower than 4MB or offset invalid, offset:%lu size:%lu",
                offset, ctx->task.size);
        return;
    }

    auto delay_us = _read_flow_cntl->GetQuota(ctx->task.size, segment->store_id());
    if (delay_us) {
        set_rpc_status(status, pspb::Status::LIMIT,
                "get quota failed, size:%lu store_id:%d",
                ctx->task.size, segment->store_id());
        return;
    }

    // Only for OnRead threads
    // 4 threads * 16KB = 64KB
    thread_local BufBlockPtr tl_buf_block = nullptr;
    if (!tl_buf_block) {
        tl_buf_block = control->buf_pool()->AllocBufBlock(gaia_apply::FLAGS_univ_page_size);
    }
    if (BAIDU_UNLIKELY(!tl_buf_block)) {
        set_rpc_status(status, pspb::Status::LIMIT, "get block failed, size:%lu",
                ctx->task.size);
        return;
    }

    ctx->read_rsp->set_gc_lsn(segment->gc_lsn());

    gaia_apply::lsn_t ckp_lsn = 0;
    auto st = segment->dblwr()->ReadCkpLsn(&ckp_lsn);
    if (st.IsOk()) {
        if (ckp_lsn > ctx->read_rsp->gc_lsn()) {
            ctx->read_rsp->set_gc_lsn(ckp_lsn);
        }
    }

    while (offset < end_offset) {
        const uint64_t physical_page_no = offset / gaia_apply::FLAGS_univ_page_size;
        db::PageLockPtr page_lock = segment->GetPageLock(physical_page_no);
        db::PageSharedLock slk(page_lock);

        db::Status s = segment->ReadPhysicalPageDataWithDblwr(ctx->log_id, offset,
                gaia_apply::FLAGS_univ_page_size, tl_buf_block->frame);
        if (!s.IsOk()) {
            set_rpc_status(status, pspb::Status::ERROR,
                    "read page data failed, offset:%lu error:%s",
                    offset, s.ToStr().c_str());
            return;
        }

        bool is_empty = false;
        if (page_is_corrupted(tl_buf_block->frame, gaia_apply::FLAGS_univ_page_size, &is_empty)) {
            PSVR_LOG_CTX(ERROR, ctx) << "page data is corrupted,"
                << " offset:[" << offset
                << "] size:[" << gaia_apply::FLAGS_univ_page_size
                << "]";
            set_rpc_status(status, pspb::Status::ERROR,
                    "read page data is corrupted, offset:%lu", offset);
            return;
        }

        ctx->read_rsp->mutable_data()->append(
                reinterpret_cast<const char*>(tl_buf_block->frame), gaia_apply::FLAGS_univ_page_size);
        if (ctx->task.size == gaia_apply::FLAGS_univ_page_size) {
            ctx->read_rsp->set_data_is_empty(is_empty);
        }

        offset += gaia_apply::FLAGS_univ_page_size;
    }

    set_rpc_status(status, pspb::Status::SUCCESS, "ok");
    ctx->read_rsp->set_size(offset - ctx->task.offset);
    ctx->read_rsp->set_data_crc(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(ctx->read_rsp->data().c_str()), ctx->read_rsp->size()));
}

// for write
void Recoverer::Dispatch(SegmentPtr segment, brpc::Controller* cntl,
        const pspb::WritePhysicalPageRequest* request,
        pspb::WritePhysicalPageResponse* response, ggpb::Closure* closure) {
    // set default response
    set_rpc_status(response->mutable_status(), pspb::Status::INVALID, "wait");

    if (!request->has_ignore_segment_prepare() || !request->ignore_segment_prepare()) {
        if (!segment->is_prepare()) {
            baidu::rpc::ClosureGuard done_guard(closure);
            set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                    "segment is not valid");
            return;
        }
    }

    bool counted = false;
    if (!try_add_inflight_req_num(_inflight_write_for_backup_req_num,
                FLAGS_psvr_recover_max_write_for_backup_num, &counted)) {
        baidu::rpc::ClosureGuard guard(closure);
        set_rpc_status(response->mutable_status(), pspb::Status::LIMIT, "inflight num overflow");
        return;
    }

    auto* ctx = new Context(Action::kOnWrite, segment, request, response, closure);
    ctx->counted_inflight = counted;
    ctx->log_id = request->has_log_id() ? request->log_id() : get_log_id();
    ctx->shift_client_id = kScheduleTaskThreadNum + _src_thread_num;
    ctx->cntl = cntl;
    ctx->task.offset = request->physical_offset();
    ctx->task.size = request->size();
    ctx->stat_timer.reset();
    Schedule(ctx TRACE_FILE_LINE_CC);
}

// directly write physical page data, used to fix a broken ibd page.
void Recoverer::OnWrite(Context* ctx) {
    std::unique_ptr<Context, std::function<void(Context*)>> ctx_guard(ctx,
            [this](Context* ctx_ptr) {
                dec_inflight_req_num(ctx_ptr);
                delete ctx_ptr;
            });
    auto* status = ctx->write_rsp->mutable_status();
    ControlPtr control = _control.lock();
    if (_stopped || !control) {
        set_rpc_status(status, pspb::Status::ERROR, "server not work");
        return;
    }

    SegmentPtr segment = ctx->segment.lock();
    if (!segment) {
        set_rpc_status(status, pspb::Status::NOT_EXISTS, "not found segment");
        return;
    }

    auto offset = ctx->task.offset;
    const auto end_offset = ctx->task.offset + ctx->task.size;
    constexpr uint64_t kMaxWriteSize = 4lu << 20;
    if (ctx->task.size > kMaxWriteSize
            || offset == end_offset
            || offset % gaia_apply::FLAGS_univ_page_size != 0
            || end_offset % gaia_apply::FLAGS_univ_page_size != 0
            || offset >= segment->segment_size()
            || end_offset > segment->segment_size()) {
        set_rpc_status(status, pspb::Status::INVALID,
                "size must align page and lower than max size or offset invalid, offset:%lu size:%lu",
                offset, ctx->task.size);
        return;
    }

    auto req = ctx->write_req;
    if (req->use_attachment()) {
        if (ctx->cntl->request_attachment().size() != req->size()) {
            set_rpc_status(status, pspb::Status::INVALID,
                    "attachment size mismatch, attachment:%lu expect:%lu",
                    ctx->cntl->request_attachment().size(), req->size());
            return;
        }
    } else {
        if (req->data().size() != req->size()) {
            set_rpc_status(status, pspb::Status::INVALID,
                    "data size mismatch, data:%lu expect:%lu",
                    req->data().size(), req->size());
            return;
        }

        if (gaiadb::common::ut_crc32(reinterpret_cast<const gaia_apply::byte*>(req->data().c_str()),
                        req->size()) != req->data_checksum()) {
            set_rpc_status(status, pspb::Status::INVALID,
                    "data checksum mismatch, expect:%u size:%lu",
                    req->data_checksum(), req->size());
            return;
        }
    }

    auto delay_us = _write_flow_cntl->GetQuota(ctx->task.size, segment->store_id());
    if (delay_us) {
        set_rpc_status(status, pspb::Status::LIMIT,
                "get quota failed, size:%lu store_id:%d",
                ctx->task.size, segment->store_id());
        return;
    }

    thread_local BufBlockPtr tl_buf_block = nullptr;
    if (!tl_buf_block) {
        tl_buf_block = control->buf_pool()->AllocBufBlock(gaia_apply::FLAGS_univ_page_size);
    }
    if (BAIDU_UNLIKELY(!tl_buf_block)) {
        set_rpc_status(status, pspb::Status::LIMIT, "get block failed, size:%lu",
                ctx->task.size);
        return;
    }

    uint64_t succ_size = 0;
    while (offset < end_offset) {
        const uint64_t physical_page_no = offset / gaia_apply::FLAGS_univ_page_size;
        db::PageLockPtr page_lock = segment->GetPageLock(physical_page_no);
        db::PageUniqueLock lk(page_lock, std::try_to_lock);
        if (!lk) {
            ctx->write_rsp->set_succ_size(succ_size);
            set_rpc_status(status, pspb::Status::LIMIT,
                    "get physical page:%lu lock failed", physical_page_no);
            return;
        }

        const uint64_t pos = offset - ctx->task.offset;
        if (req->use_attachment()) {
            ctx->cntl->request_attachment().copy_to(tl_buf_block->frame, gaia_apply::FLAGS_univ_page_size, pos);
        } else {
            memcpy(tl_buf_block->frame, req->data().data() + pos, gaia_apply::FLAGS_univ_page_size);
        }

        bool is_empty = false;
        if (page_is_corrupted(tl_buf_block->frame, gaia_apply::FLAGS_univ_page_size, &is_empty)) {
            ctx->write_rsp->set_succ_size(succ_size);
            set_rpc_status(status, pspb::Status::INVALID,
                    "page data is corrupted, offset:%lu", offset);
            return;
        }

        if (!is_empty || !segment->is_prepare()) {
            const gaia_apply::space_id_t local_space_id = gaia_apply::page_get_space_id(tl_buf_block->frame);
            const gaia_apply::page_no_t local_page_no = gaia_apply::page_get_page_no(tl_buf_block->frame);

            db::Status s = segment->WritePhysicalPageData(
                    ctx->log_id,
                    local_space_id,
                    local_page_no,
                    offset,
                    gaia_apply::FLAGS_univ_page_size,
                    tl_buf_block->frame);
            if (!s.IsOk()) {
                ctx->write_rsp->set_succ_size(succ_size);
                set_rpc_status(status, pspb::Status::ERROR,
                        "write page data failed, offset:%lu error:%s",
                        offset, s.ToStr().c_str());
                return;
            }
        }

        offset += gaia_apply::FLAGS_univ_page_size;
        succ_size += gaia_apply::FLAGS_univ_page_size;
    }

    set_rpc_status(status, pspb::Status::SUCCESS, "ok");
}


// for get log
void Recoverer::Dispatch(SegmentPtr segment, brpc::Controller* cntl,
        const pspb::GetRedoRecLogRequest* request,
        pspb::GetRedoRecLogResponse* response, ggpb::Closure* closure) {
    // set default response
    set_rpc_status(response->mutable_status(), pspb::Status::INVALID, "wait");

    if (FLAGS_psvr_recover_disabled_as_data_source) {
        baidu::rpc::ClosureGuard guard(closure);
        set_rpc_status(response->mutable_status(), pspb::Status::LIMIT, "disable as data source");
        return;
    }

    bool counted = false;
    if (!try_add_inflight_req_num(_inflight_read_redo_log_req_num,
                FLAGS_psvr_recover_max_read_redo_log_num, &counted)) {
        baidu::rpc::ClosureGuard guard(closure);
        set_rpc_status(response->mutable_status(), pspb::Status::LIMIT, "inflight num overflow");
        return;
    }

    _on_recover_inflight_req_size.fetch_add(1, std::memory_order_relaxed);

    auto* ctx = new Context(Action::kGetLog, segment, request, response, closure);
    ctx->counted_inflight = counted;
    ctx->log_id = request->has_log_id() ? request->log_id() : get_log_id();
    ctx->shift_client_id = kScheduleTaskThreadNum + _src_thread_num;
    ctx->cntl = cntl;
    ctx->stat_timer.reset();
    Schedule(ctx TRACE_FILE_LINE_CC);
}

// read append rec log
void Recoverer::OnGetLog(Context* ctx) {
    std::unique_ptr<Context, std::function<void(Context*)>> ctx_guard(ctx,
            [this](Context* ctx_ptr) {
                _stat_on_get_log_lat << ctx_ptr->stat_timer.u_elapsed();
                dec_inflight_ref_if_on_recover(ctx_ptr);
                dec_inflight_req_num(ctx_ptr);
                delete ctx_ptr;
            });
    auto* status = ctx->get_log_rsp->mutable_status();
    ControlPtr control = _control.lock();
    if (_stopped || !control) {
        set_rpc_status(status, pspb::Status::ERROR, "server not work");
        return;
    }

    SegmentPtr segment = ctx->segment.lock();
    if (!segment) {
        set_rpc_status(status, pspb::Status::NOT_EXISTS, "not found");
        return;
    }

    if (segment->in_recovery()) {
        set_rpc_status(status, pspb::Status::IN_RECOVERY,
                "segment in recovery, segment_id:%u", segment->segment_id());
        return;
    }

    auto req = ctx->get_log_req;

    if (req->fetch_lsn() >= segment->append_lsn()) {
        set_rpc_status(status, pspb::Status::RECOVERY_FINISH,
                "not more redo log, fetch_lsn:%lu append_lsn:%lu",
                req->fetch_lsn(), segment->append_lsn());
        return;
    }

    auto delay_us = _get_redo_log_flow_cntl->GetQuota(req->last_data_len(), segment->store_id());
    if (delay_us) {
        set_rpc_status(status, pspb::Status::LIMIT,
                "get quota failed, len:%u store_id:%d",
                req->last_data_len(), segment->store_id());
        return;
    }

    db::Status st;
    uint64_t block_no = 0;
    uint64_t block_offset = 0;
    if (req->has_append_db_block_no()) {
        block_no = req->append_db_block_no();
        block_offset = req->append_db_block_offset();
    }
    base::Slice key;
    base::Slice value;
    char *buf = nullptr;
    gaia_apply::lsn_t next_fetch_lsn = 0;
    uint32_t key_crc = 0;
    uint32_t value_crc = 0;
    uint32_t records_count = 0;
    uint32_t fold_size = 0;

    thread_local AppendReadBuf tl_append_read_buf(FLAGS_psvr_append_recover_read_buf_size);
    tl_append_read_buf.Reset();
    st = segment->FetchRedoLog(req->fetch_lsn(), &key, &value, &buf,
            &key_crc, &value_crc, &records_count, &fold_size,
            &next_fetch_lsn, block_no, block_offset, &tl_append_read_buf);

    if (st.IsOk()) {
        auto rsp = ctx->get_log_rsp;
        rsp->set_record_num(records_count);
        rsp->set_data_len(value.size());
        rsp->set_data(value.data(), value.size());
        rsp->set_last_lsn(next_fetch_lsn);
        rsp->set_data_checksum(value_crc);
        rsp->set_key_len(key.size());
        rsp->set_key(key.data(), key.size());
        rsp->set_key_checksum(key_crc);
        rsp->set_fold_size(fold_size);
        rsp->set_next_append_db_block_no(block_no);
        rsp->set_next_append_db_block_offset(block_offset);
        set_rpc_status(status, pspb::Status::SUCCESS, "ok");
    } else {
        set_rpc_status(status, pspb::Status::ERROR, st.ToStr());
    }

    if (buf) {
        std::free(buf);
    }
}

}
