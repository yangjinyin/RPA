/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_page.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/parse.h"
#include "psvr/segment_server.h"

namespace psvr {
namespace test {

class PageTests : public PsvrTest {
 public:
    PageTests() : _page(nullptr) {
        //init_logger();
    }
    virtual ~PageTests() {
        //LogSink::GetInstance()->Stop();
    }

    void SetUp() {
        _page.reset(new Page(1, 2));
    }

    void TearDown() {
    }

private:
    PagePtr _page;
};

std::atomic<gaia_apply::lsn_t> rlsn = 8192;
int32_t thread_num = 2;

void run_t(int32_t i, SegmentPtr seg, uint32_t space_id, bool* stopped) {
    while (!*stopped) {
        if (i == 0) {
            for (int32_t j = 1; j < thread_num; ++j) {
                LogRecord rec (gaia_apply::MLOG_FILE_DELETE, nullptr, 4, rlsn, rlsn + 4, space_id, j, false, 0);
                PagePtr page = seg->GetPage(space_id, j, true);
                ASSERT_TRUE(page->AppendLogRecord(&rec));
                rlsn += 4;
            }
            sleep_for(10);
            //LOG_EVERY_SECOND(NOTICE) << "lsn:" << rlsn.load();
        } else {
            auto lsn = rlsn.load();
            {
                PagePtr page = seg->GetPage(space_id, i, false);
                if (page) {
                    if (!page->LogRecordIsEmpty(lsn)) {
                        page->set_purge_record_lsn(lsn);
                        page->PurgeLogRecords(lsn);
                    }
                }
                sleep_for(20);
            }
        }
    }
}

TEST_F(PageTests, test_multi_thread) {
    auto seg = create_segment();
    gaia_apply::page_size_t page_size(0, 0, false);
    bool stopped = false;
    std::vector<std::shared_ptr<std::thread>> threads;
    for (int32_t i = 0; i < thread_num; ++i) {
        threads.emplace_back(new std::thread(run_t, i, seg, 1, &stopped));
    }
    LOG(TRACE) << " test multi thread in 3s ...";
    sleep_for(SLEEP_SECOND * 3);
    stopped = true;
    for (int32_t i = 0; i < thread_num; ++i) {
        if (threads[i]->joinable()) {
            threads[i]->join();
        }
    }
}

TEST_F(PageTests, test_ALL) {
    ASSERT_EQ(1, _page->_page_no);
    ASSERT_EQ(2, _page->_space_id);

    ASSERT_TRUE(_page->LogRecordEmpty());
    ASSERT_TRUE(_page->LogRecordIsEmpty(4096));

    LogRecord rec(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0, 512, 1024, 2, 1, false, 0);
    ASSERT_TRUE(_page->AppendLogRecord(&rec));
    LogRecord rec2(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0, 512, 1022, 2, 1, false, 0);
    ASSERT_FALSE(_page->AppendLogRecord(&rec2));

    ASSERT_EQ(_page->GetFirstLogRecordType(2048), gaia_apply::MLOG_INIT_FILE_PAGE2);
    ASSERT_TRUE(_page->FirstLogRecordTypeIsInit(2048));

    ASSERT_EQ(1, _page->_log_records.size());
    ASSERT_FALSE(_page->LogRecordEmpty());

    std::list<const LogRecord*> list_rec;
    ASSERT_EQ(0, list_rec.size());
    LogRecord rec3(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0, 1025, 4096, 2, 1, false, 0);
    list_rec.emplace_back(&rec3);
    LogRecord rec4(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0, 10240, 40960, 2, 1, false, 0);
    list_rec.emplace_back(&rec4);
    ASSERT_EQ(2, list_rec.size());
    std::list<const LogRecord*> list_rec2 = list_rec;

    ASSERT_TRUE(_page->AppendLogRecords(std::move(list_rec)));
    ASSERT_FALSE(_page->AppendLogRecords(std::move(list_rec2)));

    ASSERT_EQ(3, _page->_log_records.size());
    ASSERT_EQ(0, list_rec.size());

    ASSERT_FALSE(_page->LogRecordEmpty());

    ASSERT_TRUE(_page->LogRecordIsEmpty(128));
    ASSERT_FALSE(_page->LogRecordIsEmpty(1025));

    ASSERT_FALSE(_page->FirstLogRecordTypeIsInitNoLock(128));
    ASSERT_TRUE(_page->FirstLogRecordTypeIsInitNoLock(1025));

    _page->PurgeLogRecords(40960);
    ASSERT_TRUE(_page->LogRecordEmpty());
}

TEST_F(PageTests, test_PageLogRecordIterator) {
    LogRecord rec1(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0, 512, 1024, 2, 1, false, 0);
    ASSERT_TRUE(_page->AppendLogRecord(&rec1));

    LogRecord rec2(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0, 1024, 2048, 2, 1, false, 0);
    ASSERT_TRUE(_page->AppendLogRecord(&rec2));

    LogRecord rec3(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0, 2048, 2049, 2, 1, false, 0);
    ASSERT_TRUE(_page->AppendLogRecord(&rec3));

    LogRecord rec4(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0, 2049, 2050, 2, 1, false, 0);
    ASSERT_TRUE(_page->AppendLogRecord(&rec4));

    PageLogRecordIterator iter(_page);
    for (;iter.Valid();) {
        iter.Next();
    }

    LogRecord rec5(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0, 2050, 2051, 2, 1, false, 0);
    ASSERT_TRUE(_page->AppendLogRecord(&rec5));
    _page->PurgeLogRecordsNoLock(iter, 2050);

    ASSERT_EQ(1, _page->_log_records.size());
    ASSERT_EQ(2050, _page->_log_records.front()->start_lsn);
}


}
}
