/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_parse.cpp
* @author yukeyong@baidu.com
* @brief
*/


#include "test/test_common.h"
#include "psvr/parse_context.h"
#include "test/mock_thread_pool.h"
#include "bmock.h"

namespace psvr {
namespace test {

class ParserTests : public PsvrTest {
 public:
    ParserTests() : _parser(nullptr) {
        _mock_control->parser()->Stop();
    }
    virtual ~ParserTests() {}

    void SetUp() {
        _parser.reset(new Parser(_mock_client, _control));
        _mock_thread_pool = new MockExecutor<Parser::Context, thread::TaskContext>;
        _parser->_thread_pool.reset(_mock_thread_pool);
        _parser->_rpc_quota_thread_pool = _parser->_thread_pool;

        _mock_quota_thread = new MockQuotaThread<Parser::Context*, std::shared_ptr<FlowQuota>>;
        _parser->_quota_thread.reset(_mock_quota_thread);

        gaia_apply::page_size_t page_size(16<<10, 16<<10, false);

        // The mock objects created by BMOCK_NS_METHOD attach their hooks at static-init
        // time, so they would stay in effect for the whole binary. Stop them all here and
        // let each test enable only the ones it injects with BMOCK_NS_RESUME.
        BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
    }

    void TearDown() {
    }

    bool OnCompletion(Parser::Context* ctx) {
        _parser->OnCompletion(ctx);
        return true;
    }

private:
    ParserPtr _parser;
    MockExecutor<Parser::Context, thread::TaskContext>* _mock_thread_pool;
    MockQuotaThread<Parser::Context*, std::shared_ptr<FlowQuota>>* _mock_quota_thread;
};

bool MockExecuteOk(Parser::Context* ctx) {
    delete ctx;
    return true;
}

bool MockScheduleOk(thread::TaskContext* ctx, uint64_t) {
    delete ctx;
    return true;
}

bool MockGetQuotaFail(Parser::Context* ctx, std::shared_ptr<FlowQuota>) {
    delete ctx;
    return false;
}

TEST_F(ParserTests, test_Start_Stop) {
    {
        // invalid thread num
        ASSERT_FALSE(_parser->Start(0));
    }

    {
        // start fail
        EXPECT_CALL(*_mock_quota_thread, Start(_, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, FLAGS_multi_psvr_parser_thread_enable_shared, _)).WillOnce(Return(false));
        ASSERT_FALSE(_parser->Start(1));
    }

    {
        // ok & fail
        EXPECT_CALL(*_mock_quota_thread, Start(_, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, FLAGS_multi_psvr_parser_thread_enable_shared, _))
            .WillOnce(Return(true))
            .WillOnce(Return(false));
        EXPECT_CALL(*_mock_thread_pool, Stop(_))
            .WillOnce(Return());
        ASSERT_FALSE(_parser->Start(1));
    }
    {
        // ok & ok
        EXPECT_CALL(*_mock_quota_thread, Start(_, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, FLAGS_multi_psvr_parser_thread_enable_shared, _))
            .WillOnce(Return(true))
            .WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Stop(_))
            .WillOnce(Return())
            .WillOnce(Return());
        ASSERT_TRUE(_parser->Start(1));
        _parser->Stop();
    }
    {
        // fail
        _parser->_control.reset();
        ASSERT_FALSE(_parser->Start(1));
    }
}

TEST_F(ParserTests, test_IncOrDecThreadNum) {
    _parser->_store_count = 2;
    _parser->_thread_num = FLAGS_multi_psvr_parser_thread_num_per_store * _parser->_store_count;
    _parser->_metadata_thread_num = FLAGS_multi_psvr_get_metadata_thread_num;
    {
        _parser->IncOrDecThreadNum();
        _parser->_stopped = false;
        _parser->IncOrDecThreadNum();
    }
    {
        // inc
        FLAGS_multi_psvr_parser_thread_num_per_store = FLAGS_multi_psvr_parser_thread_num_per_store + 1;
        EXPECT_CALL(*_mock_thread_pool, IncThread(_)).WillOnce(Return(true));
        _parser->IncOrDecThreadNum();
    }
    {
        // dec
        std::vector<MockExecutor<Parser::Context, thread::TaskContext>::ThreadType> vec;
        FLAGS_multi_psvr_parser_thread_num_per_store = FLAGS_multi_psvr_parser_thread_num_per_store - 1;
        EXPECT_CALL(*_mock_thread_pool, DecThread(_)).WillOnce(Return(vec));
        _parser->IncOrDecThreadNum();
    }
    _parser->_stopped = true;
}

static void OnCompletion2(Parser::Context*) {
}

TEST_F(ParserTests, test_IncOrDecThreadNum2) {
    _parser->_store_count = 2;
    _parser->_thread_num = FLAGS_multi_psvr_parser_thread_num_per_store * _parser->_store_count;
    _parser->_metadata_thread_num = FLAGS_multi_psvr_get_metadata_thread_num;
    {
        _parser->IncOrDecThreadNum();
        _parser->_stopped = false;
        _parser->IncOrDecThreadNum();
    }
    {
        // inc
        FLAGS_multi_psvr_get_metadata_thread_num = FLAGS_multi_psvr_get_metadata_thread_num + 1;
        EXPECT_CALL(*_mock_thread_pool, IncThread(_)).WillOnce(Return(true));
        _parser->IncOrDecThreadNum();
    }
    {
        // dec
        typename thread::Executor<Parser::Context, thread::TaskContext>::TaskFn fn
            = std::bind(OnCompletion2, std::placeholders::_1);

        std::vector<thread::Executor<Parser::Context, thread::TaskContext>::ThreadType> vec;
        vec.push_back(std::make_shared<thread::Thread<Parser::Context, thread::TaskContext>>("test", 0, fn));
        vec.back()->Stop();

        FLAGS_multi_psvr_get_metadata_thread_num = FLAGS_multi_psvr_get_metadata_thread_num - 1;
        EXPECT_CALL(*_mock_thread_pool, DecThread(_)).WillOnce(Return(vec));
        _parser->IncOrDecThreadNum();
        FLAGS_multi_psvr_get_metadata_thread_num = 0;
        _parser->IncOrDecThreadNum();
    }
    _parser->_stopped = true;
}


TEST_F(ParserTests, test_Dispatch) {
    _parser->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());
    {
        SegmentPtr segment = create_segment();
        auto lb = create_empty_log_block(1024);
        segment->_fetch_log_block_queue.SetlastLsn(lb->start_lsn);
        segment->AddFetchLogBlock(lb);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _parser->Dispatch(segment TRACE_FILE_LINE_CC, 1024);

        _parser->Dispatch(segment TRACE_FILE_LINE_CC, 102 + 10);
    }
}

BMOCK_NS_METHOD1(gaiadb::common, terminate, void(int));
TEST_F(ParserTests, test_Schedule) {
    {
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kParse, segment, nullptr);
        _parser->Schedule(ctx TRACE_FILE_LINE_CC, 10, false);
    }

    _parser->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());
    {
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kParse, segment, nullptr);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _parser->Schedule(ctx TRACE_FILE_LINE_CC, 0, true);
    }

    {
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kParse, segment, nullptr);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _parser->Schedule(ctx TRACE_FILE_LINE_CC, 10, true);
    }
    {
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, segment, nullptr);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _parser->Schedule(ctx TRACE_FILE_LINE_CC, 0, true);
    }

    {
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, segment, nullptr);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _parser->Schedule(ctx TRACE_FILE_LINE_CC, 10, true);
    }
    {
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kDisposeRpcQuota, segment, nullptr);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _parser->Schedule(ctx TRACE_FILE_LINE_CC, 0, true);
    }

    {
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kDisposeRpcQuota, segment, nullptr);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _parser->Schedule(ctx TRACE_FILE_LINE_CC, 10, true);
    }

    {
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kParse, segment, nullptr);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Invoke(MockExecuteOk));
        _parser->Execute(ctx);
    }
    {
        _parser->_stopped = true;
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kParse, segment, nullptr);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Return(false));
        _parser->Execute(ctx);
    }
    {
        _parser->_stopped = false;
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kParse, segment, nullptr);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Return(false));
        BMOCK_NS_RESUME(gaiadb::common, terminate, void(int));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaiadb::common, terminate), terminate(_)).WillOnce(Return());
        _parser->Execute(ctx);
    }
    {
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kDisposeRpcQuota, segment, nullptr);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Invoke(MockExecuteOk));
        _parser->Execute(ctx);
    }
    {
        _parser->_stopped = true;
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kDisposeRpcQuota, segment, nullptr);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Return(false));
        _parser->Execute(ctx);
    }

    {
        _parser->_stopped = false;
        auto segment = create_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kDisposeRpcQuota, segment, nullptr);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Return(false));
        BMOCK_NS_RESUME(gaiadb::common, terminate, void(int));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaiadb::common, terminate), terminate(_)).WillOnce(Return());
        _parser->Execute(ctx);
    }

    BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
}

TEST_F(ParserTests, test_OnCompletion) {
    {
        _parser->_stopped = true;
        auto segment = create_mock_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kParse, segment, create_empty_log_block(1024, true));
        _parser->OnCompletion(ctx);
    }
}

TEST_F(ParserTests, test_ParseLogBlock) {
    _parser->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        // parse failed
        auto segment = create_mock_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kParse, segment, create_empty_log_block(1024, true));
        MockSegment* mock_segment = static_cast<MockSegment*>(segment.get());
        EXPECT_CALL(*mock_segment, ParseLogBlockToLogRecords(_,_)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _parser->OnCompletion(ctx);
    }

    {
        // parse failed 2
        auto segment = create_mock_segment();
        Parser::Context* ctx = new Parser::Context(Parser::Action::kParse, segment, create_empty_log_block(1024, false));
        MockSegment* mock_segment = static_cast<MockSegment*>(segment.get());
        EXPECT_CALL(*mock_segment, ParseLogBlockToLogRecords(_,_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _parser->OnCompletion(ctx);
    }

    {
        // parse failed 3
        auto segment = create_mock_segment();
        segment->fetch_log_block_queue()._plug_count = 1;
        Parser::Context* ctx = new Parser::Context(Parser::Action::kParse, segment, create_empty_log_block(1024, false));
        ctx->log_block->event = EventOp::kGetAllSapceId;
        MockSegment* mock_segment = static_cast<MockSegment*>(segment.get());
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _parser->OnCompletion(ctx);
    }

    {
        // parse ok
        auto segment = create_mock_segment();
        segment->fetch_log_block_queue()._plug_count = 1;
        Parser::Context* ctx = new Parser::Context(Parser::Action::kParse, segment, create_empty_log_block(1024, true));
        MockSegment* mock_segment = static_cast<MockSegment*>(segment.get());
        EXPECT_CALL(*mock_segment, ParseLogBlockToLogRecords(_,_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_gc_manager, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());
        _parser->OnCompletion(ctx);
    }

    {
        // parse ok
        auto segment = create_mock_segment();
        segment->fetch_log_block_queue()._plug_count = 2;
        Parser::Context* ctx = new Parser::Context(Parser::Action::kParse, segment, create_empty_log_block(1024, true));
        MockSegment* mock_segment = static_cast<MockSegment*>(segment.get());
        EXPECT_CALL(*mock_segment, ParseLogBlockToLogRecords(_,_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_gc_manager, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        auto lb = create_empty_log_block(1024);
        segment->_fetch_log_block_queue.SetlastLsn(lb->start_lsn);
        segment->_fetch_log_block_queue.PushBack(lb);
        _parser->OnCompletion(ctx);
    }
}

TEST_F(ParserTests, test_AddGetSpaceMetaEvent) {
    _parser->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        auto segment = create_segment();
        EXPECT_CALL(*_mock_rpc_quota, CreateSpaceMetaEvent(_, _, _, _)).WillOnce(Return(nullptr));
        _parser->AddGetSpaceMetaEvent(segment TRACE_FILE_LINE_CC, 1, nullptr, nullptr);

    }
    {
        auto segment = create_segment();
        std::shared_ptr<SpaceMetaEventType> tmp(new SpaceMetaEventType(1));
        EXPECT_CALL(*_mock_rpc_quota, CreateSpaceMetaEvent(_, _, _, _)).WillOnce(Return(tmp));
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _parser->AddGetSpaceMetaEvent(segment TRACE_FILE_LINE_CC, 1, nullptr, nullptr);

        pspb::Status status;
        _parser->AddGetSpaceMetaEvent(segment TRACE_FILE_LINE_CC, 1, nullptr, &status);
        ASSERT_EQ(pspb::Status::LIMIT, status.code());
    }
}

TEST_F(ParserTests, test_AddGetSpaceExtentEvent) {
    _parser->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        auto segment = create_mock_segment();
        EXPECT_CALL(*segment.get(), GetSpaceExtentReqLock(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_rpc_quota, CreateSpaceExtentEvent(_, _, _, _, _, _, _)).WillOnce(Return(nullptr));
        _parser->AddGetSpaceExtentEvent(segment TRACE_FILE_LINE_CC, 1, 1, nullptr, nullptr);
    }
    {
        auto segment = create_mock_segment();
        const event_space_extent_t fold(1, 1);
        std::shared_ptr<SpaceExtentEventType> tmp(new SpaceExtentEventType(fold));
        EXPECT_CALL(*segment.get(), GetSpaceExtentReqLock(_, _))
            .WillOnce(Return(true))
            .WillOnce(Return(false))
            .WillOnce(Return(false));

        EXPECT_CALL(*_mock_rpc_quota, CreateSpaceExtentEvent(_, _, _, _, _, _, _)).WillOnce(Return(tmp));
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _parser->AddGetSpaceExtentEvent(segment TRACE_FILE_LINE_CC, 1, 1, nullptr, nullptr);

        pspb::Status status;
        _parser->AddGetSpaceExtentEvent(segment TRACE_FILE_LINE_CC, 1, 1, nullptr, &status);
        ASSERT_EQ(pspb::Status::LIMIT, status.code());

        _parser->AddGetSpaceExtentEvent(segment TRACE_FILE_LINE_CC, 1, 1, nullptr, nullptr);
    }
}

TEST_F(ParserTests, test_AddGetPeerEvent) {
    _parser->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        auto segment = create_segment();
        EXPECT_CALL(*_mock_rpc_quota, CreatePeerEvent(_, _, _)).WillOnce(Return(nullptr));
        _parser->AddGetPeerEvent(segment TRACE_FILE_LINE_CC, nullptr, nullptr);

    }
    {
        auto segment = create_segment();
        std::shared_ptr<PeerEventType> tmp(new PeerEventType(1));
        EXPECT_CALL(*_mock_rpc_quota, CreatePeerEvent(_, _, _)).WillOnce(Return(tmp));
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _parser->AddGetPeerEvent(segment TRACE_FILE_LINE_CC, nullptr, nullptr);

        pspb::Status status;
        _parser->AddGetPeerEvent(segment TRACE_FILE_LINE_CC, nullptr, &status);
        ASSERT_EQ(pspb::Status::LIMIT, status.code());
    }
}

TEST_F(ParserTests, test_AddClearSapceStatusEvent) {
    _parser->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        // parse ok
        auto segment = create_mock_segment();
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(this, &ParserTests::OnCompletion));
        _parser->AddClearSapceStatusEvent(segment TRACE_FILE_LINE_CC);
    }
}

TEST_F(ParserTests, test_AddGetAllSpaceIdEvent) {
    _parser->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        // parse ok
        auto segment = create_mock_segment();
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _parser->AddGetAllSpaceIdEvent(segment TRACE_FILE_LINE_CC);
    }
}


TEST_F(ParserTests, test_GetSpaceMeta) {
    _parser->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        // GetQuota fail
        std::shared_ptr<SpaceMetaEventType> event(new SpaceMetaEventType(1));
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceMeta);
        ctx->space_meta_event = event;

        LOG(NOTICE) << "_mock_rpc_quota:" << _mock_rpc_quota;
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Invoke(MockGetQuotaFail));
        _parser->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // not have segment
        auto segment = create_segment();
        auto event = segment->cluster()->rpc_quota()->_space_event_ops.Add(1, nullptr, nullptr, nullptr);
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceMeta);
        ctx->space_meta_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        //EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Return(MockScheduleOk));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_space_event_ops.Erase(event, [](SegmentPtr seg,
                    gaia_apply::space_id_t space_id, pspb::Status* st, const EventClosureArgType&) {});
    } END_OF_CASE;

    {
        // GetOrRefreshNodes fail
        auto segment = create_segment();
        auto event = segment->cluster()->rpc_quota()->_space_event_ops.Add(1, segment, nullptr, nullptr);
        ASSERT_TRUE(!!event);
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceMeta);
        ctx->space_meta_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Return(MockScheduleOk));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_space_event_ops.Erase(event, [](SegmentPtr seg,
                    gaia_apply::space_id_t space_id, pspb::Status* st, const EventClosureArgType&) {});
    } END_OF_CASE;

    {
        // rpc fail
        auto segment = create_segment();
        auto event = segment->cluster()->rpc_quota()->_space_event_ops.Add(1, segment, nullptr, nullptr);
        ASSERT_TRUE(!!event);
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceMeta);
        ctx->space_meta_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSpaceMetaCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kCntlFailed, "fail");
            closure->Run();
        };

        auto fun2 = [](RpcGetSpaceMetaCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_TIMEOUT);
            closure->Run();
        };

        auto fun3 = [](RpcGetSpaceMetaCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_INVALID);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSpaceMeta(_, _))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun2))
            .WillOnce(Invoke(fun3))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun2))
            .WillOnce(Invoke(fun3));

        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_space_event_ops.Erase(event, [](SegmentPtr seg,
                    gaia_apply::space_id_t space_id, pspb::Status* st, const EventClosureArgType&) {});
    } END_OF_CASE;

    {
        // not exists
        auto segment = create_segment();
        pspb::Status st;
        auto event = segment->cluster()->rpc_quota()->_space_event_ops.Add(1, segment, nullptr, &st);
        ASSERT_TRUE(!!event);
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceMeta);
        ctx->space_meta_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSpaceMetaCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_NOT_EXIST);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSpaceMeta(_, _))
            .WillOnce(Invoke(fun1));

        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Return(MockExecuteOk));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_space_event_ops.Erase(event, [](SegmentPtr seg,
                    gaia_apply::space_id_t space_id, pspb::Status* st, const EventClosureArgType&) {});
    } END_OF_CASE;

    {
        // mismatch size
        auto segment = create_segment();
        auto event = segment->cluster()->rpc_quota()->_space_event_ops.Add(1, segment, nullptr, nullptr);
        ASSERT_TRUE(!!event);
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceMeta);
        ctx->space_meta_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSpaceMetaCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
            auto rsp = rpc_ctx->response.mutable_space_meta();
            rsp->set_is_compressed(false);
            rsp->set_is_encrypted(false);
            rsp->set_logical_page_size(1);
            rsp->set_physical_page_size(16<<10);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSpaceMeta(_, _))
            .WillOnce(Invoke(fun1));

        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_space_event_ops.Erase(event, [](SegmentPtr seg,
                    gaia_apply::space_id_t space_id, pspb::Status* st, const EventClosureArgType&) {});
    } END_OF_CASE;

    {
        // mismatch size
        auto segment = create_segment();
        auto event = segment->cluster()->rpc_quota()->_space_event_ops.Add(1, segment, nullptr, nullptr);
        ASSERT_TRUE(!!event);
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceMeta);
        ctx->space_meta_event = event;
        ctx->has_quota = true;

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSpaceMetaCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
            auto rsp = rpc_ctx->response.mutable_space_meta();
            rsp->set_is_compressed(false);
            rsp->set_is_encrypted(false);
            rsp->set_logical_page_size(16<<10);
            rsp->set_physical_page_size(1);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSpaceMeta(_, _))
            .WillOnce(Invoke(fun1));

        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_space_event_ops.Erase(event, [](SegmentPtr seg,
                    gaia_apply::space_id_t space_id, pspb::Status* st, const EventClosureArgType&) {});
    } END_OF_CASE;

    {
        // get ok
        auto segment = create_segment();
        auto event = segment->cluster()->rpc_quota()->_space_event_ops.Add(1, segment, nullptr, nullptr);
        ASSERT_TRUE(!!event);
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceMeta);
        ctx->space_meta_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSpaceMetaCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
            auto rsp = rpc_ctx->response.mutable_space_meta();
            rsp->set_is_compressed(false);
            rsp->set_is_encrypted(false);
            rsp->set_logical_page_size(16<<10);
            rsp->set_physical_page_size(16<<10);
            auto encryption_info_pb = rsp->mutable_encryption_info();
            encryption_info_pb->set_version(1);
            encryption_info_pb->set_encryption_key("0123456789abcdef0123456789abcdef");
            encryption_info_pb->set_encryption_iv("0123456789abcdef");
            encryption_info_pb->set_encryption_alg("aes_ctr");
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSpaceMeta(_, _))
            .WillOnce(Invoke(fun1));

        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Return(MockExecuteOk));
        _parser->OnCompletion(ctx);
    }
}


TEST_F(ParserTests, test_GetSpaceExtent) {
    _parser->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        // GetQuota fail
        const event_space_extent_t fold(1, 1);
        std::shared_ptr<SpaceExtentEventType> event(new SpaceExtentEventType(fold));
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceExtent);
        ctx->space_extent_event = event;

        LOG(NOTICE) << "_mock_rpc_quota:" << _mock_rpc_quota;
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Invoke(MockGetQuotaFail));
        _parser->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // not have segment
        const event_space_extent_t fold(1, 1);
        auto segment = create_segment();
        auto event = segment->cluster()->rpc_quota()->_offset_event_ops.Add(fold, nullptr, nullptr, nullptr, ExtentArg{0, 0});
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceExtent);
        ctx->space_extent_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        //EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Return(MockScheduleOk));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_offset_event_ops.Erase(event, [](SegmentPtr seg,
                    const event_space_extent_t& fold2, pspb::Status* st, const EventClosureArgType&){});
    } END_OF_CASE;

    {
        // GetOrRefreshNodes fail
        auto segment = create_segment();
        const event_space_extent_t fold(1, 1);
        auto event = segment->cluster()->rpc_quota()->_offset_event_ops.Add(fold, segment, nullptr, nullptr, ExtentArg{0, 0});

        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceExtent);
        ctx->space_extent_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Return(MockScheduleOk));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_offset_event_ops.Erase(event, [](SegmentPtr seg,
                    const event_space_extent_t& fold2, pspb::Status* st, const EventClosureArgType&){});
    } END_OF_CASE;

    {
        // rpc fail
        auto segment = create_segment();
        const event_space_extent_t fold(1, 1);
        auto event = segment->cluster()->rpc_quota()->_offset_event_ops.Add(fold, segment, nullptr, nullptr, ExtentArg{0, 0});
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceExtent);
        ctx->space_extent_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSpaceExtentMapCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kCntlFailed, "fail");
            closure->Run();
        };

        auto fun2 = [](RpcGetSpaceExtentMapCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_TIMEOUT);
            closure->Run();
        };

        auto fun3 = [](RpcGetSpaceExtentMapCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_INVALID);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSpaceExtentMap(_, _))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun2))
            .WillOnce(Invoke(fun3))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun2))
            .WillOnce(Invoke(fun3));

        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_offset_event_ops.Erase(event, [](SegmentPtr seg,
                    const event_space_extent_t& fold2, pspb::Status* st, const EventClosureArgType&){});
    } END_OF_CASE;

    {
        // rpc fail not_exists
        auto segment = create_segment();
        const event_space_extent_t fold(1, 1);
        pspb::Status st;
        auto event = segment->cluster()->rpc_quota()->_offset_event_ops.Add(fold, segment, nullptr, &st, ExtentArg{0, 0});
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceExtent);
        ctx->space_extent_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSpaceExtentMapCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_NOT_EXIST);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSpaceExtentMap(_, _))
            .WillOnce(Invoke(fun1));

        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Return(MockExecuteOk));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_offset_event_ops.Erase(event, [](SegmentPtr seg,
                    const event_space_extent_t& fold2, pspb::Status* st, const EventClosureArgType&){});
    } END_OF_CASE;

    {
        // rpc ok
        auto segment = create_segment();
        const event_space_extent_t fold(1, 1);
        auto event = segment->cluster()->rpc_quota()->_offset_event_ops.Add(fold, segment, nullptr, nullptr, ExtentArg{0, 0});
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetSpaceExtent);
        ctx->space_extent_event = event;
        ctx->has_quota = true;

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSpaceExtentMapCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSpaceExtentMap(_, _))
            .WillOnce(Invoke(fun1));

        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_offset_event_ops.Erase(event, [](SegmentPtr seg,
                    const event_space_extent_t& fold2, pspb::Status* st, const EventClosureArgType&){});
    } END_OF_CASE;
}

TEST_F(ParserTests, test_GetPeer) {
    _parser->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        // GetQuota fail
        std::shared_ptr<PeerEventType> event(new PeerEventType(1));
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetPeer);
        ctx->peer_event = event;

        LOG(NOTICE) << "_mock_rpc_quota:" << _mock_rpc_quota;
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Invoke(MockGetQuotaFail));
        _parser->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // not have segment
        auto segment = create_segment();
        auto event = segment->cluster()->rpc_quota()->_peer_event_ops.Add(segment->segment_id(), nullptr, nullptr, nullptr);
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetPeer);
        ctx->peer_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        //EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Return(MockScheduleOk));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_peer_event_ops.Erase(event, [](SegmentPtr seg,
                    gaiadb::common::segment_t, pspb::Status* st, const EventClosureArgType&) {});
    } END_OF_CASE;

    {
        // GetOrRefreshNodes fail
        auto segment = create_segment();
        auto event = segment->cluster()->rpc_quota()->_peer_event_ops.Add(segment->segment_id(), segment, nullptr, nullptr);
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetPeer);
        ctx->peer_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Return(MockScheduleOk));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_peer_event_ops.Erase(event, [](SegmentPtr seg,
                    gaiadb::common::segment_t, pspb::Status* st, const EventClosureArgType&) {});
    } END_OF_CASE;

    {
        // rpc fail
        auto segment = create_segment();
        auto event = segment->cluster()->rpc_quota()->_peer_event_ops.Add(segment->segment_id(), segment, nullptr, nullptr);
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetPeer);
        ctx->peer_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSegmentCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kCntlFailed, "fail");
            closure->Run();
        };

        auto fun2 = [](RpcGetSegmentCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_TIMEOUT);
            closure->Run();
        };

        auto fun3 = [](RpcGetSegmentCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_INVALID);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, ListSegmentReplica(_, _))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun2))
            .WillOnce(Invoke(fun3))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun2))
            .WillOnce(Invoke(fun3));

        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_peer_event_ops.Erase(event, [](SegmentPtr seg,
                    gaiadb::common::segment_t, pspb::Status* st, const EventClosureArgType&) {});
    } END_OF_CASE;

    {
        // rpc fail not_exists
        auto segment = create_segment();
        pspb::Status st;
        auto event = segment->cluster()->rpc_quota()->_peer_event_ops.Add(segment->segment_id(), segment, nullptr, &st);
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetPeer);
        ctx->peer_event = event;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSegmentCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_NOT_EXIST);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, ListSegmentReplica(_, _))
            .WillOnce(Invoke(fun1));

        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_peer_event_ops.Erase(event, [](SegmentPtr seg,
                    gaiadb::common::segment_t, pspb::Status* st, const EventClosureArgType&) {});
    } END_OF_CASE;

    {
        // rpc ok
        auto segment = create_segment();
        auto event = segment->cluster()->rpc_quota()->_peer_event_ops.Add(segment->segment_id(), segment, nullptr, nullptr);
        auto* ctx = new Parser::Context(Parser::Action::kDoRpcQuota, _cluster, EventOp::kGetPeer);
        ctx->peer_event = event;
        ctx->has_quota = true;

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [](RpcGetSegmentCtx* rpc_ctx, ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, ListSegmentReplica(_, _))
            .WillOnce(Invoke(fun1));

        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &ParserTests::OnCompletion));
        _parser->OnCompletion(ctx);
        segment->cluster()->rpc_quota()->_peer_event_ops.Erase(event, [](SegmentPtr seg,
                    gaiadb::common::segment_t, pspb::Status* st, const EventClosureArgType&) {});
    } END_OF_CASE;
}

}
}
