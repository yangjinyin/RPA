/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/drop_replicator.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class DropReplicator : public Command {
public:
    DropReplicator() {
        SetName("drop-replicator");
        SetDesc("drop an existing replicator from manager");
        SetDescCn("从管理服务中删除热活服务的复制节点");
        
        AddPsmClusterOption();
        AddRequiredArgOption("addr", &_long_opt_val, kOptMax + 1, "the replicator node", kip_port);

        AddExample("--manager-address \"bns://xxx\" --addr 127.0.0.0:1111");
    }
    virtual ~DropReplicator() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _addr = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::DropReplicatorResponse& rsp);

private:
    std::string _manager_address {};
    std::string _addr {};
};

}
}
