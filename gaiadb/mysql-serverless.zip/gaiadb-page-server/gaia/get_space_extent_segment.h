/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_space_extent_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class GetSpaceExtentSegment : public Command {
public:
    GetSpaceExtentSegment() {
        SetName("get-space-extent-segment");
        SetDesc("get space extent segment id");
        SetDescCn("获取表空间区数据所在的分片 ID");

        AddPsmClusterOption();
        AddRequiredArgOption("space-id", &_long_opt_val, kOptMax + 1, "the space id to be queried", kuint32_t);
        AddRequiredArgOption("page-no", &_long_opt_val, kOptMax + 2, "the logical page no to be queried", kuint32_t);

        AddNoArgOption("use-bytes", &_long_opt_val, kOptMax + 3, "set use_bytes type to get meta data", kGroup2Scope);
        AddNoArgOption("check", &_long_opt_val, kOptMax + 4, "read replica data to check", kGroup3Scope);
        AddRequiredArgOption("cluster-id", NULL, 'c',
                "cluster id for check page data", kstring, kGroup3Scope);

        AddExample("--manager-address \"bns://xxx\" --space-id 1 --page-no 1");
        AddExample("--manager-address \"bns://xxx\" --space-id 1 --page-no 1 --check --cluster-id id");
    }
    virtual ~GetSpaceExtentSegment() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'c':
            _cluster_id = opt;
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _specify_space_id = true;
                _space_id = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 2:
                _specify_page_no = true;
                _page_no = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 3:
                _use_bytes = true;
                break;
            case kOptMax + 4:
                _check_page_data = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::GetSpaceExtentMapResponse& rsp);

private:
    std::string _manager_address {};
    uint32_t _space_id {0};
    bool _specify_space_id {false};
    uint32_t _page_no {0};
    bool _specify_page_no {false};
    bool _use_bytes {false};
    gaiapb::GetSegmentResponse _response;
    bool _segment_info_ok {false};
    bool _check_page_data {false};
    std::string _cluster_id {};
};

}
}
