/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/append_file_utils.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <gaiadb/utils/ut.h>
#include "psvr/common.h"
#include "psvr/config.h"
#include "gaia/append_file_utils.h"
#include "psvr/append_block.h"
#include "psvr/dblwr.h"
#include "gaia/parse_apply_rec.h"

namespace psvr {
namespace gaia {

int AppendFileUtils::Run() {
    gaiadb::common::ut_crc32_init();

    if (_file.empty()) {
        print_error("miss --file");
        return 1;
    }

    if (_type.empty()) {
        print_error("miss --type");
        return 1;
    }

    if (_type != "checkpoint" && _type != "db" && _type != "dblwr" && _type != "slots") {
        print_error("invalid --type");
        return 1;
    }

    if (_parse) {
        if (_space_id == std::numeric_limits<uint32_t>::max() || _page_no == std::numeric_limits<uint32_t>::max()) {
            if (!_force) {
                if (!execute_confirm("parse all page ?")) {
                    std::cout << "quit!" << std::endl;
                    return -1;
                }
            }
        }
    }

    int fd = open(_file.c_str(), O_RDONLY, 0644);
    if (fd < 0) {
        print_error("open file failed, %m");
        return 1;
    }

    GuardFd guard_fd(fd);

    if (_type == "checkpoint") {
        db::CheckPointBlock::Dump(fd, std::cout);
    } else if (_type == "db") {
        if (_parse) {
            db::RandomAccessBlock::DumpAndParse(fd, std::cout,
                [this](gaia_apply::byte* start, gaia_apply::byte* end, gaia_apply::lsn_t start_lsn) {
                    if (_space_id != std::numeric_limits<uint32_t>::max() && _page_no != std::numeric_limits<uint32_t>::max()) {
                        return parse_records(start, end, &start_lsn, nullptr, nullptr, &_space_id, &_page_no);
                    } else {
                        return parse_records(start, end, &start_lsn);
                    }
                }, true);
        } else {
            db::RandomAccessBlock::Dump(fd, std::cout);
        }
    } else if (_type == "dblwr") {
        Dblwr::Dump(fd, std::cout, _parse);
    } else if (_type == "slots") {
        db::BlockSlotsBlock::Dump(fd, std::cout);
    }

    return 0;
}

}
}
