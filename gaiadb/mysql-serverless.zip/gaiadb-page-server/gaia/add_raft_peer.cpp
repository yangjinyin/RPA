/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/add_raft_peer.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <raft/configuration.h>
#include "gaia/add_raft_peer.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int AddRaftPeer::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_group_id.empty()) {
        print_error("miss --group-id");
        return 1;
    }

    if (_add_peer_id.empty()) {
        print_error("miss --peer-id");
        return 1;
    }

    raft::PeerId add_peer_id;
    int ret = add_peer_id.parse(_add_peer_id);
    if (ret != 0) {
        print_error("error --peer-id, like, ip:port:idx");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Add this raft peer: %s?", _add_peer_id.c_str());
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    raft::GetLeaderRequest request;
    raft::GetLeaderResponse response;
    request.set_group_id(_group_id);
    raft::PeerId leader_id;
    for (auto& node : nodes) {
        //request.set_peer_id();
        _client.Call(_log_id, node, &raft::CliService_Stub::get_leader, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            ret = leader_id.parse(response.leader_id());
            if (ret != 0) {
                LOG(WARNING) << node << " leader parse failed, " << response.leader_id();
                print_error("leader parse failed, %s", response.leader_id().c_str());
                return 1;
            }
            break;
        } else {
            LOG(WARNING) << node << " get leader failed, " << status;
        }
    }

    if (leader_id.is_empty()) {
        print_error("get leader failed");
        return 1;
    }

    raft::AddPeerRequest request2;
    raft::AddPeerResponse response2;

    request2.set_group_id(_group_id);
    request2.set_leader_id(leader_id.to_string());
    request2.set_peer_id(_add_peer_id);

    _client.Call(_log_id, leader_id.addr, &raft::CliService_Stub::add_peer, &request2, &response2,
            nullptr, &status, _timeout_ms);
    if (status.IsOk()) {
        return Output(response2);
    } else {
        LOG(WARNING) << leader_id.addr << " add peer failed, " << status;
        print_error("add peer failed");
        return 1;
    }
}

int AddRaftPeer::Format(const raft::AddPeerResponse& rsp) {
    Table header(_raw_with_table, 2);
    header.AddRowsValue({"log_id:", _log_id});
    header.AddRowsValue({"code:", "ok"});
    header.Display();
    raft::Configuration old_conf;
    Table old_table(_raw_with_table, 0);
    old_table.AddRowsWithName({"before_list"});
    for (int i = 0; i < rsp.old_peers_size(); ++i) {
        old_conf.add_peer(rsp.old_peers(i));
        old_table.AddRowsValue({rsp.old_peers(i)});
    }
    old_table.Display();
    raft::Configuration new_conf;
    Table new_table(_raw_with_table, 0);
    new_table.AddRowsWithName({"after_list"});
    for (int i = 0; i < rsp.new_peers_size(); ++i) {
        new_conf.add_peer(rsp.new_peers(i));
        new_table.AddRowsValue({rsp.new_peers(i)});
    }
    new_table.Display();
    LOG(INFO) << "configuration of replication group `" << _group_id
              << "' changed from " << old_conf
              << " to " << new_conf;
    return 0;
}

}
}
