/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/utils.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <base/third_party/murmurhash3/murmurhash3.h>

#include <gaiadb/utils/signal.h>    // gaiadb::common::terminate

#include "psvr/utils.h"

namespace psvr {

void terminate() {
    base::debug::StackTrace trace;
    LOG(ERROR) << trace.ToString();
    gaiadb::common::terminate();
}

size_t calc_peer_majority_num(size_t active_num) {
    if (active_num <= 2lu) {
        return 1lu;
    } else {
        return (active_num / 2 + 1lu);
    }
}

uint32_t Get32bitHash(const std::string& name) {
    uint32_t hash = 0;
    base::MurmurHash3_x86_32(name.c_str(), name.size(), 0, &hash);
    return hash;
}

}
