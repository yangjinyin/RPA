/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file ddl/ddl0column.cc
 DDL cluster index scan implementation.
 Created 2023-08-02 by guolingjie. */

#include "btr0load.h"
#include "ddl0impl-column.h"
#include "ddl0impl-cursor.h"
#include "log0chkp.h"
#include "row0vers.h"
#include <sstream>
#include "col0col.h"

namespace ddl {

Columnar_inserter::Columnar_inserter(Context &ctx, dict_index_t *index) noexcept
    : RTree_inserter(ctx, index) {}

dberr_t Columnar_inserter::batch_insert(trx_id_t trx_id,
                                      Latch_release &&latch_release) noexcept {
  // TODO
  ut_a(dict_index_is_columnar(m_index));

  if (m_dtuples->empty()) {
    return DB_SUCCESS;
  }

  mtr_t mtr;
  mtr.set_create_column_index(true); 
  mtr_start(&mtr);
  for (auto it = m_dtuples->begin(); it != m_dtuples->end(); ++it) {
    auto dtuple = *it;
    ut_ad(dtuple != nullptr);
    mlog_write_columnar_log(&mtr, COLUMNAR_INDEX_INSERT, trx_id, m_index, dtuple);
  }
  mtr_commit(&mtr);

  m_dtuples->clear();

  mem_heap_empty(m_dml_heap);
  mem_heap_empty(m_dtuple_heap);
  return DB_SUCCESS;
}

}  // namespace ddl
