/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/drop_space.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class DropSpace : public Command {
public:
    DropSpace() {
        SetName("drop-space");
        SetDesc("drop space from manager");
        SetDescCn("从管理服务中删除表空间");

        AddPsmClusterOption();
        AddRequiredArgOption("space-id", &_long_opt_val, kOptMax + 1, "drop space id", kuint32_t);
        
        AddExample("--manager-address \"bns://xxx\" --space-id 1");
    }
    virtual ~DropSpace() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _space_id.Set(std::strtoul(opt, NULL, 10));
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::AckResponse& rsp);

private:
    std::string _manager_address {};
    VarOptional<uint32_t> _space_id;
};

}
}
