/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file mock_client.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "psvr/client.h"

namespace psvr {
namespace test {

class MockClient : public Client {
    MockClient() : Client() {}
    virtual ~MockClient() {}

    MOCK_METHOD2(GetSegmentInfo, void(ClientContext<gaiapb::GetPageServerRequest, gaiapb::GetPageServerResponse>*, ggpb::Closure*));
    MOCK_METHOD2(ListLogService, void(ClientContext<gaiapb::LogServiceBatchGetRequest, gaiapb::LogServiceBatchGetResponse>*, ggpb::Closure*));
    MOCK_METHOD2(GetSpaceMeta, void(ClientContext<gaiapb::GetSpaceMetaRequest, gaiapb::GetSpaceMetaResponse>*, ggpb::Closure*));
    MOCK_METHOD2(GetSpaceExtentMap, void(ClientContext<gaiapb::GetSpaceExtentMapRequest, gaiapb::GetSpaceExtentMapResponse>*, ggpb::Closure*));
    MOCK_METHOD2(ListSegmentReplica, void(ClientContext<gaiapb::GetSegmentRequest, gaiapb::GetSegmentResponse>*, ggpb::Closure*));
    MOCK_METHOD2(UpdateReplicaRecoveryStatus, void(ClientContext<gaiapb::UpdateReplicaRecoveryStatusRequest, gaiapb::AckResponse>*, ggpb::Closure*));
    MOCK_METHOD2(ReadPhysicalPage, void(ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>*, ggpb::Closure*));
    MOCK_METHOD2(Rbio, void(ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>*, ggpb::Closure*));
    MOCK_METHOD2(Heartbeat, void(ClientContext<gaiapb::PageServerHeartbeatRequest, gaiapb::HeartbeatResponse>*, ggpb::Closure*));
    MOCK_METHOD2(BatchHeartbeat, void(ClientContext<gaiapb::BatchPageServerHeartbeatRequest, gaiapb::BatchPageServerHeartbeatResponse>*, ggpb::Closure*));
    MOCK_METHOD2(WritePhysicalPages, void(ClientContext<pspb::WritePageRequest, pspb::WritePageResponse>*, ggpb::Closure*));
    MOCK_METHOD2(GetLog, void(ClientContext<lspb::psrv_get_log_request, lspb::psrv_get_log_response, gaiadb::common::PeerZone>*, ggpb::Closure*));
    MOCK_METHOD2(BatchGetLog, void(ClientContext<lspb::batch_psrv_get_log_request, lspb::batch_psrv_get_log_response, gaiadb::common::PeerZone>*, ggpb::Closure*));
    MOCK_METHOD2(SetReplicaRecovery, void(RpcSetReplicaRecovery*, ggpb::Closure*));
    MOCK_METHOD2(GetRedoRecLog, void(RpcGetRedoRecLog*, ggpb::Closure*));
    MOCK_METHOD2(GetLowestLsn, void(RpcGetLowestCtx*, ggpb::Closure*));
    MOCK_METHOD2(ListSegment, void(RpcListSegmentCtx*, ggpb::Closure*));
};

}
}
