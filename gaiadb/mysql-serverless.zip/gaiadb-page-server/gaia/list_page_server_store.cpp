/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server_store.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_page_server_store.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ListPageServerStore::Run() {
    RpcStatus status;

    if (!_cluster_addr.empty()) {
        return Run2();
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    pspb::MultiGetStatusRequest request;
    pspb::MultiGetStatusResponse response;

    request.set_log_id(_log_id);
    request.set_only_get_store_info(true);

    _client.Call(_log_id, node, &pspb::QueryService_Stub::MultiGetServerStatus, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);

}

int ListPageServerStore::Format(const pspb::MultiGetStatusResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table2(_raw_with_table, 0);
    table2.AddRowsWithName({
            "store_id", "status",
            "size_type", "store_size", "physical_store_size",
            "logic_used_size", "physical_used_size", "free_size",
            "capacity_status", "capacity", "used_capacity",
            "store_path", "io_error_count", "compress_rate"});
    for (int32_t i = 0; i < rsp.stores_size(); ++i) {
        const auto& store_pb = rsp.stores(i);
        table2.AddRowsValue({
                store_pb.store_id(),
                store_pb.active() ? "active" : "inactive",
                store_pb.specify_store_size() ? "manual" : "auto",
                RowSize(store_pb.store_size(), _human_readable),
                RowSize(store_pb.physical_store_size(), _human_readable),
                RowSize(store_pb.logic_used_size(), _human_readable),
                RowSize(store_pb.physical_used_size(), _human_readable),
                RowSize(store_pb.free_size(), _human_readable),
                store_pb.capacity() > -1 ? "on" : "off",
                store_pb.capacity(), store_pb.used_capacity(),
                store_pb.store_path(),
                store_pb.io_error_count(),
                get_unknown_type(store_pb.has_compress_rate(), store_pb.compress_rate(), -1)});
    }
    table2.Display();
    return 0;
}

int ListPageServerStore::Run2() {
    // get all
    PsmInfo psm_info(_cluster_addr, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--cluster-addr parse failed, cant get server list");
        return 1;
    }

    auto wait_finish_fn = [this] () {
        while (!_stopped) {
            if (_task_count.load(std::memory_order_acquire) == 0) {
                break;
            } else {
                gaiadb::common::pause();    // x86
            }
        }
        if (_stopped) {
            print_error("quit by signal");
            return 1;
        }
        return 0;
    };

    _task_count.store(nodes.size());
    pspb::BatchMultiGetStatusResponse  response;
    response.set_log_id(_log_id);

    pspb::MultiGetStatusRequest req;
    req.set_log_id(_log_id);
    req.set_only_get_store_info(true);

    for (auto& node : nodes) {
        auto server_status = response.add_server_status();
        server_status->set_addr(gaiadb::common::endpoint2str(node));

        pspb::MultiGetStatusResponse* rsp = server_status->mutable_status();
        RpcStatus* status = new RpcStatus;
        auto closure = brpc::NewCallback(this, &ListPageServerStore::Done2, rsp, status);

        _client.Call(_log_id, node, &pspb::QueryService_Stub::MultiGetServerStatus, &req, rsp,
                closure, status, _timeout_ms);
    }
    if (wait_finish_fn()) {
        return 1;
    }

    std::sort(response.mutable_server_status()->begin(),
            response.mutable_server_status()->end(),
            [](const pspb::BatchMultiGetStatusResponse::ServerStatus& lhs,
                const pspb::BatchMultiGetStatusResponse::ServerStatus& rhs){
                if (lhs.status().status().code() == pspb::Status_ReturnCode_SUCCESS
                        && rhs.status().status().code() == pspb::Status_ReturnCode_SUCCESS) {
                    return lhs.status().topology_zone() < rhs.status().topology_zone();
                } else {
                    return lhs.addr() < rhs.addr();
                }
            });

    return Output(response);
}

void ListPageServerStore::Done2(pspb::MultiGetStatusResponse* response, RpcStatus* status) {
    if (!status->IsOk()) {
        LOG(WARNING) << "rpc failed:" << status;
        response->mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response->mutable_status()->set_msg(status->msg);
    }
    _task_count.fetch_sub(1, std::memory_order_release);
    delete status;
}

struct ZoneStatus {
    std::string max_use_size_addr {};
    int64_t max_use_size {0};
    std::string max_store_path {};
    std::string min_use_size_addr {};
    int64_t min_use_size {0};
    std::string min_store_path {};
    int64_t physical_total_size {0};
    int64_t physical_total_used_size {0};
};

int ListPageServerStore::Format(const pspb::BatchMultiGetStatusResponse& rsp) {
    Table __table(_raw_with_table, 2);
    __table.AddRowsValue({"log_id:", _log_id});
    __table.Display();

    std::vector<std::string> error_servers;
    std::vector<std::pair<std::string, std::string>> error_server_stores;
    std::map<int32_t, ZoneStatus> zone_status;
    int64_t sum_physical_store_size = 0;
    int64_t sum_physical_total_used_size = 0;
    int64_t sum_physical_total_free_size = 0;

    for (int32_t j = 0; j < rsp.server_status_size(); ++j) {
        const auto& server_status = rsp.server_status(j);
        const auto& rsp2 = server_status.status();

        Table table(_raw_with_table, 0);
        if (rsp2.status().code() != pspb::Status_ReturnCode_SUCCESS) {
            error_servers.emplace_back(server_status.addr());
            table.AddRowsWithName({"no", "node", ""});
            table.AddRowsValue({
                        j + 1, server_status.addr(),
                        RowStr(pspb::Status_ReturnCode_Name(rsp2.status().code()), rsp2.status().msg())
                    });
        } else {
            table.AddRowsWithName({"no", "node", "zone", "offline", "git_commit", "pkg_version"});
            table.AddRowsValue({j + 1, server_status.addr(), rsp2.topology_zone(), rsp2.topology_to_offline(),
                    get_unknown_type(rsp2.has_git_commit(), rsp2.git_commit()),
                    get_unknown_type(rsp2.has_pkg_version(), rsp2.pkg_version())});
        }
        table.Display();

        Table table2(_raw_with_table, 0);
        table2.AddRowsWithName({
                "store_id", "status",
                "size_type", "store_size", "physical_store_size",
                "logic_used_size", "physical_used_size", "physical_used_rate", "free_size",
                "capacity_status", "capacity", "used_capacity",
                "store_path", "io_error_count", "compress_rate"});

        int32_t zone = rsp2.topology_zone();
        for (int32_t i = 0; i < rsp2.stores_size(); ++i) {
            const auto& store_pb = rsp2.stores(i);
            table2.AddRowsValue({
                    store_pb.store_id(),
                    store_pb.active() ? "active" : "inactive",
                    store_pb.specify_store_size() ? "manual" : "auto",
                    RowSize(store_pb.store_size(), _human_readable),
                    RowSize(store_pb.physical_store_size(), _human_readable),
                    RowSize(store_pb.logic_used_size(), _human_readable),
                    RowSize(store_pb.physical_used_size(), _human_readable),
                    RowPercent(store_pb.physical_used_size(), store_pb.physical_store_size()),
                    RowSize(store_pb.free_size(), _human_readable),
                    store_pb.capacity() > -1 ? "on" : "off",
                    store_pb.capacity(), store_pb.used_capacity(),
                    store_pb.store_path(),
                    store_pb.io_error_count(),
                    get_unknown_type(store_pb.has_compress_rate(), store_pb.compress_rate(), -1)});

            if (!store_pb.active()
                    || store_pb.io_error_count() > 0) {
                error_server_stores.emplace_back(server_status.addr(), store_pb.store_path());
                continue;
            }

            sum_physical_store_size += store_pb.physical_store_size();
            sum_physical_total_used_size += store_pb.physical_used_size();

            auto it = zone_status.find(zone);
            if (it == zone_status.end()) {
                zone_status[zone] = {server_status.addr(),
                    store_pb.physical_used_size(),
                    store_pb.store_path(),
                    server_status.addr(),
                    store_pb.physical_used_size(),
                    store_pb.store_path(),
                    store_pb.physical_store_size(),
                    store_pb.physical_used_size()
                };
            } else {
                if (store_pb.physical_used_size() > zone_status[zone].max_use_size) {
                    zone_status[zone].max_use_size_addr = server_status.addr();
                    zone_status[zone].max_use_size = store_pb.physical_used_size();
                    zone_status[zone].max_store_path = store_pb.store_path();
                }
                if (store_pb.physical_used_size() < zone_status[zone].min_use_size) {
                    zone_status[zone].min_use_size_addr = server_status.addr();
                    zone_status[zone].min_use_size = store_pb.physical_used_size();
                    zone_status[zone].min_store_path = store_pb.store_path();
                }
                zone_status[zone].physical_total_size += store_pb.physical_store_size();
                zone_status[zone].physical_total_used_size += store_pb.physical_used_size();
            }
        }
        table2.Display();
    }

    if (_show_total) {
        Table table3(_raw_with_table, 0);
        table3.AddRowsWithName({"zone", "max_use_size_addr", "max_use_store", "max_use_size",
                "min_use_size_addr", "min_use_store", "min_use_size",
                "physical_store_size", "physical_total_used_size", "physical_total_free_size"});
        for (auto& it : zone_status) {
            table3.AddRowsValue({it.first,
                    it.second.max_use_size_addr,
                    it.second.max_store_path,
                    RowSize(it.second.max_use_size, _human_readable),
                    it.second.min_use_size_addr,
                    it.second.min_store_path,
                    RowSize(it.second.min_use_size, _human_readable),
                    RowSize(it.second.physical_total_size, _human_readable),
                    RowSize(it.second.physical_total_used_size, _human_readable),
                    RowSize(it.second.physical_total_size - it.second.physical_total_used_size, _human_readable),
                });
        }

        sum_physical_total_free_size = sum_physical_store_size - sum_physical_total_used_size;
        table3.AddRowsValue({"",
                "", "", "", "", "", "SUM",
                RowSize(sum_physical_store_size, _human_readable),
                RowSize(sum_physical_total_used_size, _human_readable),
                RowSize(sum_physical_total_free_size, _human_readable),
            });

        table3.Display();

        if (error_servers.size() || error_server_stores.size()) {
            Table table4(_raw_with_table, 0);
            table4.AddRowsWithName({"error_addr", "error_store_path"}, true);
            for (auto& it : error_servers) {
                table4.AddRowsValue({it, "-"});
            }
            for (auto& it : error_server_stores) {
                table4.AddRowsValue({it.first, it.second});
            }
            table4.Display();
        }
    }

    return 0;
}

}
}
