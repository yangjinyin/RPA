/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/namespace.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <cstdarg>
#include <functional>

#include <base/string_printf.h>
#include <gaiadb/utils/namespace.h>

namespace psvr {

namespace ARG = std::placeholders;

inline void set_rpc_status(pspb::Status* st, pspb::Status::ReturnCode c, const std::string& m) {
    st->set_code(c);
    st->set_msg(m);
}

inline void set_rpc_status(pspb::Status* st, pspb::Status::ReturnCode c, std::string&& m) {
    st->set_code(c);
    st->set_msg(m);
}

__attribute__((format(printf, 3, 4)))
inline void set_rpc_status(pspb::Status* st, pspb::Status::ReturnCode c, const char* fmt, ...) {
    std::string m;
    va_list ap;
    va_start(ap, fmt);
    base::string_vprintf(&m, fmt, ap);
    va_end(ap);
    set_rpc_status(st, c, std::move(m));
}

}

