#!/usr/bin/env bash
set -euo pipefail

LOG_PATH="/home/work/page_server/log/page_server.log.wf"
TAIL_LINES="50"
SSH_OPTS="-o ConnectTimeout=5 -o StrictHostKeyChecking=no"

usage() {
    cat <<'EOF'
Usage:
  ./tail_page_server_wf_log_by_bns.sh <bns> [tail_lines]

Examples:
  ./tail_page_server_wf_log_by_bns.sh group.example.all
  ./tail_page_server_wf_log_by_bns.sh group.example.all 100

Notes:
  - Requires get_instance_by_service in PATH.
  - Requires SSH access to each BNS node.
  - Fetches the last N lines of /home/work/page_server/log/page_server.log.wf from each node.
EOF
}

if [[ $# -lt 1 || $# -gt 2 ]]; then
    usage
    exit 1
fi

BNS="$1"
if [[ $# -eq 2 ]]; then
    TAIL_LINES="$2"
fi

if ! [[ "$TAIL_LINES" =~ ^[1-9][0-9]*$ ]]; then
    echo "ERROR: tail_lines must be a positive integer: $TAIL_LINES" >&2
    exit 1
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

NODE_LIST="$TMP_DIR/nodes.txt"
FAILED_LOG="$TMP_DIR/failed.log"

extract_nodes() {
    awk '
        /^[[:space:]]*$/ { next }
        /^#/ { next }
        {
            for (i = 1; i <= NF; i++) {
                field = $i
                gsub(/^\[/, "", field)
                gsub(/\]$/, "", field)

                if (field ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+(:[0-9]+)?$/) {
                    sub(/:[0-9]+$/, "", field)
                    print field
                    next
                }

                if (field ~ /^[A-Za-z0-9._-]+(:[0-9]+)?$/ && field !~ /^[0-9]+$/) {
                    sub(/:[0-9]+$/, "", field)
                    print field
                    next
                }
            }
        }
    ' | sort -u
}

if ! command -v get_instance_by_service >/dev/null 2>&1; then
    echo "ERROR: get_instance_by_service not found in PATH" >&2
    exit 2
fi

echo "Fetching BNS instances: $BNS" >&2
if ! get_instance_by_service "$BNS" 2>"$TMP_DIR/bns.err" | extract_nodes >"$NODE_LIST"; then
    echo "ERROR: failed to fetch BNS instances" >&2
    cat "$TMP_DIR/bns.err" >&2 || true
    exit 3
fi

if [[ ! -s "$NODE_LIST" ]]; then
    echo "ERROR: no nodes parsed from BNS: $BNS" >&2
    echo "Raw error output:" >&2
    cat "$TMP_DIR/bns.err" >&2 || true
    exit 3
fi

NODE_COUNT="$(wc -l <"$NODE_LIST")"
echo "Found $NODE_COUNT node(s)" >&2
: >"$FAILED_LOG"

success_count=0
failed_count=0

while IFS= read -r node; do
    safe_node="${node//[^A-Za-z0-9_.-]/_}"
    out_file="$TMP_DIR/${safe_node}.log"

    if ssh -n $SSH_OPTS "$node" "test -r '$LOG_PATH' && tail -n '$TAIL_LINES' '$LOG_PATH'" >"$out_file" 2>"$TMP_DIR/${safe_node}.err"; then
        success_count=$((success_count + 1))
        echo
        echo "===== $node: $LOG_PATH (last $TAIL_LINES lines) ====="
        cat "$out_file"
    else
        failed_count=$((failed_count + 1))
        echo "FAILED $node" >&2
        {
            echo "===== $node ====="
            cat "$TMP_DIR/${safe_node}.err"
            echo
        } >>"$FAILED_LOG"
    fi
done <"$NODE_LIST"

echo
echo "Summary"
echo "  BNS:           $BNS"
echo "  Log path:      $LOG_PATH"
echo "  Tail lines:    $TAIL_LINES"
echo "  Total nodes:   $NODE_COUNT"
echo "  Success nodes: $success_count"
echo "  Failed nodes:  $failed_count"

if [[ -s "$FAILED_LOG" ]]; then
    echo
    echo "Failures:"
    cat "$FAILED_LOG"
fi

if [[ "$success_count" -eq 0 ]]; then
    exit 4
fi

if [[ "$failed_count" -gt 0 ]]; then
    exit 5
fi

exit 0
