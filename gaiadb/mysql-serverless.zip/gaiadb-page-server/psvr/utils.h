/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/utils.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <chrono>
#include <vector>

#include <base/debug/stack_trace.h>
#include <base/iobuf.h>
#include <json_to_pb.h>
#include <pb_to_json.h>
#include <psvr0meta.h>

#include <gaiadb/utils/ut.h>
#include <gaiadb/utils/utils.h>

#include "psvr/log.h"

namespace psvr {

#define PSVR_FUNC_CTOR __attribute__((constructor))
#define PSVR_FUNC_DTOR __attribute__((destructor))

#define NO_OPTIMIZE __attribute__((optimize("O0")))

#ifdef GTEST
#define FUNC_MOCK virtual
#define CONST_MOCK
#define NO_OPTIMIZE_MOCK NO_OPTIMIZE
#else
#define FUNC_MOCK
#define CONST_MOCK const
#define NO_OPTIMIZE_MOCK
#endif

// not include self
#define MIN_RECOVER_DATA_RELICAS_SIZE 1

#define PTR_P(ptr) reinterpret_cast<std::uintptr_t>(ptr)

#define PSVR_LOG_CTX(level, ctx)  \
    LOG(level) << "logid:[" << (ctx)->log_id << "#" << reinterpret_cast<std::uintptr_t>(ctx) << "] "
#ifndef GTEST
#define PSVR_LOG_EVERY_SECOND_CTX(level, ctx) \
    LOG_EVERY_SECOND(level) << "logid:[" << (ctx)->log_id << "#" << reinterpret_cast<std::uintptr_t>(ctx) << "] "
#define PSVR_LOG_IF_EVERY_SECOND_CTX(level, cond, ctx) \
    LOG_IF_EVERY_SECOND(level, cond) << "[" << (ctx)->log_id << "#" << reinterpret_cast<std::uintptr_t>(ctx) << "] "
#else
#define PSVR_LOG_EVERY_SECOND_CTX(level, ctx) \
    LOG(level) << "logid:[" << (ctx)->log_id << "#" << reinterpret_cast<std::uintptr_t>(ctx) << "] "
#define PSVR_LOG_IF_EVERY_SECOND_CTX(level, cond, ctx) \
    LOG_IF(level, cond) << "[" << (ctx)->log_id << "#" << reinterpret_cast<std::uintptr_t>(ctx) << "] "
#endif // GTEST
#define PSVR_LOG_IF_CTX(level, cond, ctx) \
    LOG_IF(level, cond) << "logid:[" << (ctx)->log_id << "#" << reinterpret_cast<std::uintptr_t>(ctx) << "] "

#define PSVR_LOG(level, log_id) \
    LOG(level) << "logid:[" << log_id << "] "
#ifndef GTEST
#define PSVR_LOG_EVERY_SECOND(level, log_id) \
    LOG_EVERY_SECOND(level) << "logid:[" << log_id << "] "
#define PSVR_LOG_IF_EVERY_SECOND(level, cond, log_id) \
    LOG_IF_EVERY_SECOND(level, cond) << "logid:[" << log_id << "] "
#else
#define PSVR_LOG_EVERY_SECOND(level, log_id) \
    LOG(level) << "logid:[" << log_id << "] "
#define PSVR_LOG_IF_EVERY_SECOND(level, cond, log_id) \
    LOG_IF(level, cond) << "logid:[" << log_id << "] "
#endif // GTEST
#define PSVR_LOG_IF(level, cond, log_id) \
    LOG_IF(level, cond) << "logid:[" << log_id << "] "

#define ToKB(b) ((b) >> 10)
#define ToMB(b) ((b) >> 20)
#define ToGB(b) ((b) >> 30)

#define KBToByte(b) ((b) << 10)
#define MBToByte(b) ((b) << 20)
#define GBToByte(b) ((b) << 30)

#define u32tou64(_u1, _u2) ((static_cast<uint64_t>(_u1) << 32) + (_u2))
#define u64tou32first(_u64) (static_cast<uint32_t>(_u64 >> 32u))
#define u64tou32second(_u64) (static_cast<uint32_t>(_u64 & 0xfffffffful))

inline void unfold_u64(uint64_t value, uint32_t* first, uint32_t* second) {
    *first = u64tou32first(value);
    *second = u64tou32second(value);
}

#define PSVR_ASSERT_U(cond) \
while (FLAGS_psvr_in_chaos) {   \
    PSVR_ASSERT((cond));        \
    break;                      \
}

#define PSVR_ASSERT(cond)   \
do {    \
if (BAIDU_UNLIKELY(!(cond))) {     \
    LOG(ERROR) << "check failed:" #cond ".";    \
    base::debug::StackTrace trace;  \
    LOG(ERROR) << trace.ToString(); \
    assert(cond);      \
}   \
} while(0)

#define psvr_terminate() \
do {    \
    LOG(ERROR) << "terminate here"; \
    terminate();   \
} while(0)

#define ENABLE_TRACE_POINIT

#ifdef ENABLE_TRACE_POINIT

#define TRACE_FILE_LINE_DT    const char*, const char*, int
#define TRACE_FILE_LINE_DTC   , TRACE_FILE_LINE_DT
#define TRACE_FILE_LINE_D     const char* __psvr_file_name, const char* __psvr_func_name, int __psvr_line
#define TRACE_FILE_LINE_DC    , TRACE_FILE_LINE_D
#define TRACE_FILE_LINE_C     (strrchr(__FILE__, '/') ? (strrchr(__FILE__, '/') + 1) : __FILE__), __FUNCTION__, __LINE__
#define TRACE_FILE_LINE_CC    , TRACE_FILE_LINE_C
#define TRACE_FILE_LINE_ARG_C        __psvr_file_name, __psvr_func_name, __psvr_line
#define TRACE_FILE_LINE_ARG_CC       , TRACE_FILE_LINE_ARG_C
#define TRACE_FILE_LINE_LOG_STR   " trace:[file#" << __psvr_file_name << ", line#" << __psvr_line << ", func#" << __psvr_func_name << "]"

#else

#define TRACE_FILE_LINE_DT
#define TRACE_FILE_LINE_DTC
#define TRACE_FILE_LINE_D
#define TRACE_FILE_LINE_DC
#define TRACE_FILE_LINE_C
#define TRACE_FILE_LINE_CC
#define TRACE_FILE_LINE_ARG_C
#define TRACE_FILE_LINE_ARG_CC
#define TRACE_FILE_LINE_LOG_STR ""

#endif

constexpr int64_t SLEEP_INTERVAL = 500000;
constexpr int64_t SLEEP_SECOND = 1000000;

template<typename UIntType> UIntType ut_uintx_align_down(UIntType n, UIntType align_no) {
    assert(align_no > 0);
    assert(gaiadb::common::ut_is_2pow(align_no));
    return (n & ~(align_no - 1));
}

template<typename UIntType> UIntType ut_uintx_align_up(UIntType n, UIntType align_no) {
    assert(align_no > 0);
    assert(gaiadb::common::ut_is_2pow(align_no));
    return ((n + align_no - 1) & ~(align_no - 1));
}

template<typename T>
inline constexpr T second2microseconds(T s) { return s * 1000 * 1000; }

template<typename T>
inline constexpr T millisecond2microseconds(T ms) { return ms * 1000; }

constexpr uint32_t GAIADB_EXTENT_SIZE_SHIFT = 20u;
constexpr uint32_t GAIADB_EXTENT_SIZE = (1u << GAIADB_EXTENT_SIZE_SHIFT);  // 1MB
constexpr uint32_t GAIADB_EXTENT_SIZE_MASK = (GAIADB_EXTENT_SIZE - 1);
constexpr uint32_t GAIADB_EXTENT_PAGE_NUM_SHIFT = 6u;
constexpr uint32_t GAIADB_EXTENT_PAGE_NUM = (1u << GAIADB_EXTENT_PAGE_NUM_SHIFT);
constexpr uint32_t GAIADB_EXTENT_PAGE_NUM_MASK = (GAIADB_EXTENT_PAGE_NUM -1);

constexpr uint32_t kInvalidExtentId = std::numeric_limits<uint32_t>::max();
constexpr uint64_t kInvalidOffset = gaia_apply::ULINT_UNDEFINED;

inline uint64_t extent_num_to_size(uint32_t extent_num) {
    return static_cast<uint64_t>(extent_num) << GAIADB_EXTENT_SIZE_SHIFT;
}

inline void sleep_for(uint64_t microseconds) {
    gaiadb::common::sleep_for(microseconds);
}

template<class Rep, class Period> void sleep_for(const std::chrono::duration<Rep, Period>& sleep_duration) {
    Rep us = std::chrono::duration_cast<std::chrono::microseconds>(sleep_duration).count();
    sleep_for(static_cast<uint64_t>(us));
}

inline std::string pb2jsonstr(const google::protobuf::Message& pb_msg) {
    std::string json;
    std::string error;
    if (ProtoMessageToJson(pb_msg, &json, &error)) {
        return json;
    }
    return error;
}

inline bool jsonstr2pb(const std::string& json,
        google::protobuf::Message* message, std::string* error = nullptr) {
    return JsonToProtoMessage(json, message, error);
}

inline bool parse_message_from_iobuf(google::protobuf::Message* message,
        const base::IOBuf& in, std::string* error = nullptr) {
    base::IOBufAsZeroCopyInputStream wrapper(in);
    if (!message->ParseFromZeroCopyStream(&wrapper)) {
        if (error) {
            *error = base::string_printf("fail to parse message=%s",
                    message->GetDescriptor()->full_name().c_str());
        }
        return false;
    }
    return true;
}

inline int64_t get_log_id() { return gaiadb::common::get_log_id(); }
inline int64_t get_current_micros() { return gaiadb::common::get_current_micros(); }

inline uint64_t get_delay_us(uint32_t retry_times,
        uint64_t retry_interval_us = 10000, uint64_t max_delay_us = 3000000) {
    return std::min(((retry_times + 1) * retry_interval_us), max_delay_us);
}

inline bool NO_OPTIMIZE_MOCK atomic_write_file(const std::string& file,
        const std::string& data, bool sync = true) {
    return gaiadb::common::atomic_write_file(file, data, sync);
}

template<typename T>
std::string JoinVec(std::vector<T>& vec, const char* link_str) {
    size_t n = vec.size();
    std::string str;
    for (size_t i = 0; i < n; ++i) {
        str.append(base::string_printf(link_str + !i, vec[i]));
    }
    str.append(base::string_printf(", size:%lu", n));
    return str;
}

template<typename T>
std::string JoinVec(T vec[], size_t n, const char* link_str) {
    std::string str;
    for (size_t i = 0; i < n; ++i) {
        str.append(base::string_printf(link_str + !i, vec[i]));
    }
    str.append(base::string_printf(", size:%lu", n));
    return str;
}


void terminate();

size_t calc_peer_majority_num(size_t active_num);

uint32_t Get32bitHash(const std::string& name);

}
