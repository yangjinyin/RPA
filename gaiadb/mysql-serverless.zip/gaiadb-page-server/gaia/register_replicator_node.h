/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/register_replicator_node.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class RegisterReplicatorNode : public Command {
public:
    RegisterReplicatorNode() {
        SetName("register-replicator-node");
        SetDesc("register a replicator node to manager");
        SetDescCn("在管理服务上注册复制服务的节点");
        
        AddPsmClusterOption();
        AddRequiredArgOption("addr", &_long_opt_val, kOptMax + 1, "an existing replicator endpoint", kip_port);
        AddRequiredArgOption("token", &_long_opt_val, kOptMax + 2, "node token", kint64_t);

        AddExample("--manager-address \"bns://xxx\" --addr 127.0.0.1:1999 --token 1999");
    }
    virtual ~RegisterReplicatorNode() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _addr = opt;
                break;
            case kOptMax + 2:
                _token = std::strtoll(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::RegisterReplicatorNodeResponse& rsp);

private:
    std::string _manager_address {};
    std::string _addr {};
    int64_t _token {-1};
};

}
}
