/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_lowest_replica.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/get_lowest_replica.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int GetLowestReplica::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    gaiapb::ListPageServerRequest request;
    gaiapb::ListPageServerResponse response;
    request.set_log_id(_log_id);

    pspb::LowestNode rsp;

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_page_server, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            FindLowestNode(response, &rsp);
            return Output(rsp);
        } else {
            LOG(WARNING) << node << " list page server failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("list failed, all nodes failed");
    FindLowestNode(response, &rsp);
    return Output(rsp);
}

struct Node {
    uint32_t segment_id;
    uint32_t replica_id;
    std::string addr;
    uint64_t fetch_lsn;
    uint64_t parse_lsn;
    uint64_t checkpoint_lsn;

    Node(const gaiapb::PageServerInfo& ps)
        : segment_id(ps.segment_id()),
        replica_id(ps.replica_id()),
        addr(ps.addr()),
        fetch_lsn(ps.fetch_lsn()),
        parse_lsn(ps.apply_lsn()),
        checkpoint_lsn(ps.checkpoint_lsn()) {}
};

bool operator> (const Node& lhs, const Node& rhs) {
    return lhs.checkpoint_lsn > rhs.checkpoint_lsn;
}

bool operator== (const Node& lhs, const Node& rhs) {
    return lhs.checkpoint_lsn == rhs.checkpoint_lsn
        && lhs.parse_lsn == rhs.parse_lsn
        && lhs.fetch_lsn == rhs.fetch_lsn;
}

void GetLowestReplica::FindLowestNode(const gaiapb::ListPageServerResponse& rsp,
        pspb::LowestNode* rsp2) {
    if (rsp.status().code()) {
        rsp2->set_log_id(_log_id);
        rsp2->mutable_status()->set_code(pspb::Status::ERROR);
        rsp2->mutable_status()->set_msg(rsp.status().msg());
        return;
    }
    rsp2->mutable_status()->set_code(pspb::Status::SUCCESS);
    rsp2->mutable_status()->set_msg("ok");
    if (rsp.page_servers_size()) {
        uint64_t cn_lowest_lsn = rsp.cn_lowest_lsn();
        uint64_t ps_lowest_lsn = std::numeric_limits<uint64_t>::max();
        uint64_t max_fetch_lsn = 0;
        uint64_t max_parse_lsn = 0;
        uint64_t max_checkpoint_lsn = 0;

        std::vector<Node> nodes;
        nodes.reserve(rsp.page_servers_size());
        for (auto& ps : rsp.page_servers()) {
            nodes.emplace_back(ps);
            if (ps.checkpoint_lsn() < ps_lowest_lsn) {
                ps_lowest_lsn = ps.checkpoint_lsn();
            }
            if (ps.fetch_lsn() > max_fetch_lsn) {
                max_fetch_lsn = ps.fetch_lsn();
            }
            if (ps.apply_lsn() > max_parse_lsn) {
                max_parse_lsn = ps.apply_lsn();
            }
            if (ps.checkpoint_lsn() > max_checkpoint_lsn) {
                max_checkpoint_lsn = ps.checkpoint_lsn();
            }
        }

        std::vector<Node> lowest_nodes;
        lowest_nodes.reserve(12);

        std::make_heap(nodes.begin(), nodes.end(), std::greater<>{});
        std::pop_heap(nodes.begin(), nodes.end(), std::greater<>{});
        auto lowest_node = nodes.back();
        nodes.pop_back();
        lowest_nodes.emplace_back(lowest_node);

        bool find_it = false;
        while (!nodes.empty()) {
            std::make_heap(nodes.begin(), nodes.end(), std::greater<>{});
            std::pop_heap(nodes.begin(), nodes.end(), std::greater<>{});
            auto second_lowest_node = nodes.back();
            nodes.pop_back();

            if (lowest_node == second_lowest_node) {
                lowest_nodes.emplace_back(lowest_node);
            } else {
                if (second_lowest_node.checkpoint_lsn - lowest_node.checkpoint_lsn >= _min_distance) {
                    find_it = true;
                }
                break;
            }
        }

        rsp2->set_max_fetch_lsn(max_fetch_lsn);
        rsp2->set_max_parse_lsn(max_parse_lsn);
        rsp2->set_max_checkpoint_lsn(max_checkpoint_lsn);
        rsp2->set_ps_lowest_lsn(ps_lowest_lsn);
        rsp2->set_cn_lowest_lsn(cn_lowest_lsn);

        if (find_it) {
            for (auto& n : lowest_nodes) {
                auto n_pb = rsp2->add_lowest_nodes();
                n_pb->set_addr(n.addr);
                n_pb->set_segment_id(n.segment_id);
                n_pb->set_replica_id(n.replica_id);
                n_pb->set_fetch_lsn(n.fetch_lsn);
                n_pb->set_parse_lsn(n.parse_lsn);
                n_pb->set_checkpoint_lsn(n.checkpoint_lsn);
            }
        }
    }
}

int GetLowestReplica::Format(const pspb::LowestNode& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 0);
    table.AddRowsWithName({
            "segment_id", "replica_id", "addr",
            "fetch_lsn", "parse_lsn", "checkpoint_lsn"}, true);
    for (auto& ps : rsp.lowest_nodes()) {
        table.AddRowsValue({
                ps.segment_id(),
                ps.replica_id(),
                ps.addr(),
                ps.fetch_lsn(),
                ps.parse_lsn(),
                ps.checkpoint_lsn()});
    }

    table.AddRowsValue({"max_fetch_lsn:", rsp.max_fetch_lsn()});
    table.AddRowsValue({"max_parse_lsn:", rsp.max_parse_lsn()});
    table.AddRowsValue({"max_checkpoint_lsn:", rsp.max_checkpoint_lsn()});
    table.AddRowsValue({"ps_lowest_lsn:", rsp.ps_lowest_lsn()});
    table.AddRowsValue({"cn_lowest_lsn:", rsp.cn_lowest_lsn()});

    table.Display();
    return 0;
}

}
}
