/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_segment_compress_config.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class SetSegmentCompressConfig : public Command {
public:
    SetSegmentCompressConfig() {
        SetName("set-segment-compress-config");
        SetDesc("set segment compress config to cluster");
        SetDescCn("设置集群中分片的压缩配置");

        AddPsmClusterOption();
        AddRequiredArgOption("cfg-enable", &_long_opt_val, kOptMax + 1, "enable or disable compression", kenum);
        AddRequiredArgOption("cfg-type", &_long_opt_val, kOptMax + 2, "name of compression algorithm", kenum);
        AddRequiredArgOption("cfg-level", &_long_opt_val, kOptMax + 3, "level of compression algorithm", kint32_t);
        
        AddExample("--manager-address \"bns://xxx\" --cfg-enable 0");
        AddExample("--manager-address \"bns://xxx\" --cfg-enable 1 --cfg-type \"<type>\" --cfg-level <level>");
    }
    virtual ~SetSegmentCompressConfig() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _enable.Set(!!std::strtoull(opt, NULL, 10));
                break;
            case kOptMax + 2:
                _type.Set(opt);
                break;
            case kOptMax + 3:
                _level = std::strtol(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::SetSegmentCompressConfigResponse& rsp);

private:
    std::string _manager_address {};
    VarOptional<bool> _enable;
    VarOptional<std::string> _type;
    int32_t _level {-1};
};

}
}
