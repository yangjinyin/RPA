/***************************************************************************
 * Copyright (c) Baidu.com, Inc. All Rights Reserved
 **************************************************************************/
/**
 * @file gaia/compress_page_server_segment.cpp
 * @author yukeyong@baidu.com
 * @brief
 */

#include "gaia/compress_page_server_segment.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int CompressPageServerSegment::Run() {
    RpcStatus status;

    if (_address.empty() || _port < 1) {
        print_error("miss --cluster-addr or (--address and --port)");
        return 1;
    }

    if (_cluster_id.empty() || !_segment_id.has_val) {
        print_error("miss --cluster-id or --segmnet-id");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    if (!_remove) {
        pspb::AddCompressSegmentRequest request;
        pspb::AddCompressSegmentResponse response;

        request.set_log_id(_log_id);
        request.set_cluster_id(_cluster_id);
        request.set_segment_id(_segment_id.val);
        request.set_is_prior(_is_prior);

        if (!_force) {
            bool cf_ret = execute_confirm("Add segment to compression list?");
            if (!cf_ret) {
                printf("quit!\n");
                return 1;
            }
        }

        _client.Call(
                _log_id,
                node,
                &pspb::ManagerService_Stub::AddCompressSegment,
                &request,
                &response,
                nullptr,
                &status,
                _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }
        return Output(response);
    } else {
        pspb::DropCompressSegmentRequest request;
        pspb::DropCompressSegmentResponse response;

        request.set_log_id(_log_id);
        request.set_cluster_id(_cluster_id);
        request.set_segment_id(_segment_id.val);

        if (!_force) {
            bool cf_ret = execute_confirm("Remove segment from compression list?");
            if (!cf_ret) {
                printf("quit!\n");
                return 1;
            }
        }

        _client.Call(
                _log_id,
                node,
                &pspb::ManagerService_Stub::DropCompressSegment,
                &request,
                &response,
                nullptr,
                &status,
                _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }
        return Output(response);
    }
}

int CompressPageServerSegment::Format(const pspb::AddCompressSegmentResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

int CompressPageServerSegment::Format(const pspb::DropCompressSegmentResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}  // namespace gaia
}  // namespace psvr
