/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/parse.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/common.h"
#include "psvr/model.h"
#include "psvr/quota.h"
#include "psvr/segment.h"
#include "psvr/thread_pool.hpp"

namespace psvr {

class Parser;
using ParserPtr = std::shared_ptr<Parser>;

class Parser : public Model<Parser> {
public:
struct Context;

enum class Action {
    kParse = 1,
    kDispath,
    kDoRpcQuota,
    kDisposeRpcQuota,
    kDisposeGetAllSpaceId,
};

private:
using QuotaThreadType = QuotaThread<Context*, std::shared_ptr<FlowQuota>>;
using QuotaThreadTypePtr = std::shared_ptr<QuotaThreadType>;
using ThreadPoolType = ThreadPoolExecutor<Context, thread::TaskContext>;
using ThreadPoolTypePtr = std::shared_ptr<ThreadPoolType>;

public:
    Parser(ClientPtr client, ControlWeakPtr control);
    FUNC_MOCK ~Parser() {
        if (!_stopped) {
            Stop();
        }
    }

    static const char* action2str(Parser::Action action);

    virtual bool SetUp() override;
    virtual void TearDown() override;
    virtual void Join() override;

    bool IncOrDecThreadNum();

    FUNC_MOCK void Dispatch(SegmentPtr segment TRACE_FILE_LINE_DC, gaia_apply::lsn_t lsn);
    FUNC_MOCK bool Execute(Context* ctx);

    FUNC_MOCK void AddGetAllSpaceIdEvent(SegmentPtr segment TRACE_FILE_LINE_DC);
    FUNC_MOCK void AddGetSpaceMetaEvent(SegmentPtr segment TRACE_FILE_LINE_DC,
            gaia_apply::space_id_t id, ggpb::Closure* closure, pspb::Status* status);
    FUNC_MOCK void AddGetSpaceExtentEvent(SegmentPtr segment TRACE_FILE_LINE_DC,
            gaia_apply::space_id_t id, gaia_apply::page_no_t logical_page_no,
            ggpb::Closure* closure, pspb::Status* status);
    FUNC_MOCK void AddGetSpaceExtentEvent(SegmentPtr segment TRACE_FILE_LINE_DC,
            gaia_apply::space_id_t id, gaia_apply::page_no_t logical_page_no,
            uint64_t search_offset, ggpb::Closure* closure, pspb::Status* status);
    FUNC_MOCK void AddGetPeerEvent(SegmentPtr segment TRACE_FILE_LINE_DC,
            ggpb::Closure* closure, pspb::Status* status);
    FUNC_MOCK void AddClearSapceStatusEvent(SegmentPtr segment TRACE_FILE_LINE_DC);

private:
    void Expose();

    void SetCtxClientId(Context* ctx);
    const ThreadPoolTypePtr& GetThreadPool(Context* ctx) const;
    void Schedule(Context* ctx TRACE_FILE_LINE_DC,
            uint64_t delay_us = 0, bool is_retry = false);
    void OnCompletion(Context* ctx);

    void CheckQuota(RpcQuotaPtr rpc_quota, Context* ctx TRACE_FILE_LINE_DC);
    bool GetQuota(RpcQuotaPtr rpc_quota, Context* ctx);
    void OnGetQuota(Context* ctx);

    void GetSpaceMeta(Context* ctx);
    void OnGetSpaceMeta(Context* ctx, RpcGetSpaceMetaCtx* rpc_ctx);
    void DisposeGetSpaceMeta(Context* ctx);

    void GetSpaceExtent(Context* ctx);
    void OnGetSpaceExtent(Context* ctx, RpcGetSpaceExtentMapCtx* rpc_ctx);
    void DisposeGetSpaceExtent(Context* ctx);

    void GetPeer(Context* ctx);
    void OnGetPeer(Context* ctx, RpcGetSegmentCtx* rpc_ctx);
    void DisposeGetPeer(Context* ctx);

    void OnGetAllSpaceId(Context* ctx, RpcGetAllSpaceCtx* rpc_ctx);
    void DisposeGetAllSpaceId(Context* ctx);

    void DoNextLogBlock(Context* ctx);
    void ParseLogBlock(Context* ctx);

private:
    uint32_t _thread_num;
    uint32_t _metadata_thread_num;
    ThreadPoolTypePtr _thread_pool;
    ThreadPoolTypePtr _rpc_quota_thread_pool;
    QuotaThreadTypePtr _quota_thread;
    // statistic
    StatQps _stat_get_meta_qps;
    StatCount _stat_get_meta_fail_count;
    StatCount _stat_get_meta_limit_quota_count;
    StatQps _stat_parse_empty_qps;
    StatLatency _stat_parse_log_block_lat;
    StatSize _stat_parse_log_block_size;
    StatSize _stat_parse_log_block_include_record_size;
    StatCount _stat_parse_error_count;
};

bool operator>=(std::shared_ptr<FlowQuota> quota, Parser::Context* ctx);

}
