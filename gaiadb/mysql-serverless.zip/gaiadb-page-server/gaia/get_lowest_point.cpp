/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_lowest_point.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/get_lowest_point.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int GetLowestPoint::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_show_total) {
lowst_info:
        gaiapb::EmptyMessage request;
        gaiapb::GetLowestPointResponse response;
        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_lowest_point, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                return Output(response);
            } else {
                LOG(WARNING) << node << " get lowest point failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("get failed, all nodes failed");
        return Output(response);
    }

    {
        // show replicator
        gaiapb::ListReplicatorRequest request;
        gaiapb::ListReplicatorResponse response;

        request.set_log_id(_log_id);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_replicator, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                if (Output(response)) {
                    return 1;
                }
                break;
            } else {
                LOG(WARNING) << node << " list replicator failed, " << status << " " << response.status();
            }
        }
    }

    {
        // show compute
        gaiapb::ComputeNodeBatchGetRequest request;
        gaiapb::ComputeNodeBatchGetResponse response;

        request.set_log_id(_log_id);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_compute_node, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                if (Output(response)) {
                    return 1;
                }
                break;
            } else {
                LOG(WARNING) << node << " list compute node failed, " << status << " " << response.status();
            }
        }
    }

    {
        // show log_service
        gaiapb::LogServiceBatchGetRequest request;
        gaiapb::LogServiceBatchGetResponse response;

        request.set_log_id(_log_id);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_log_service, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                log_service::batch_lsrv_status_response batch_ls_response;
                log_service::lsrv_empty_message ls_request;
                log_service::lsrv_status_response ls_response;
                for (auto& ls : response.log_services()) {
                    base::EndPoint ls_node;
                    base::str2endpoint(ls.addr().c_str(), &ls_node);
                    _client.Call(_log_id, ls_node, &log_service::LogServiceService_Stub::query_status, &ls_request, &ls_response,
                            nullptr, &status, _timeout_ms);
                    if (!status.IsOk()) {
                        ls_response.mutable_status()->set_code(2);
                        ls_response.mutable_status()->set_msg("query fail");
                    }

                    auto rsp_node = batch_ls_response.add_nodes();
                    rsp_node->set_addr(ls.addr());
                    rsp_node->mutable_info()->CopyFrom(ls_response);
                }
                if (Output(batch_ls_response)) {
                    return 1;
                }
                break;
            } else {
                LOG(WARNING) << node << " list log service failed, " << status << " " << response.status();
            }
        }
    }

    {
        // show page server
        gaiapb::ListPageServerRequest request;
        gaiapb::ListPageServerResponse response;

        request.set_log_id(_log_id);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_page_server, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                if (Output(response)) {
                    return 1;
                }
                break;
            } else {
                LOG(WARNING) << node << " list page server failed, " << status << " " << response.status();
            }
        }
    }

    goto lowst_info;
}

int GetLowestPoint::Format(const gaiapb::ListReplicatorResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    {
        Table table(_raw_with_table, 2);
        table.AddRowsValue({"replication_apply_lsn", rsp.replication_apply_lsn()});
        table.AddRowsValue({"replication_write_lsn", rsp.replication_write_lsn()});
        table.AddRowsValue({"replication_trx_id", rsp.replication_trx_id()});
        table.AddRowsValue({"replication_recovery_is_finish", rsp.recovery_is_finish() ? "yes" : "no"});
        table.AddRowsValue({"replication_latest_pit", rsp.latest_pit()});
        table.Display();
    }
    if (rsp.replicators_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({"node", "epoch", "token", "apply_lsn", "write_lsn", "trx_id", "state", "zone"}, true);
        for (auto& pb : rsp.replicators()) {
            table.AddRowsValue({
                    pb.addr(),
                    pb.epoch(),
                    pb.token(),
                    pb.apply_lsn(),
                    pb.write_lsn(),
                    pb.trx_id(),
                    gaiadb::NodeState_Name(pb.state()),
                    GetZoneStr(pb)
                    });
        }
        table.Display();
    }
    return 0;
}

int GetLowestPoint::Format(const gaiapb::ComputeNodeBatchGetResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.compute_nodes_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({
                "node", "id", "lowest_trx_id",
                "apply_lsn", "start_apply_lsn", "state",
                "primary", "zone", "binlog_in_redo_info"}, true);
        for (auto& cp : rsp.compute_nodes()) {
            table.AddRowsValue({
                    cp.addr(),
                    cp.server_id(),
                    cp.lowest_trx_id(),
                    cp.apply_lsn(),
                    cp.start_apply_lsn(),
                    gaiadb::NodeState_Name(cp.state()),
                    cp.is_primary() ? "yes" : "no",
                    GetZoneStr(cp),
                    GetBinLogInfo(cp),
                    });
        }
        table.Display();
    }
    return 0;
}

int GetLowestPoint::Format(const log_service::batch_lsrv_status_response& rsp) {
    Table table(_raw_with_table, 0);
    table.AddRowsWithName({"addr", "write_lsn", "vdl", "parse_lsn", "dispatch_lsn",
            "archive_lsn", "gc_lsn", "lowest_lz_lsn", "cn_lowest_lsn", "ps_lowest_lsn", "cn_lowest_gc_lsn", "ps_lowest_gc_lsn",
            "link_buf_tail", "epoch", "quorum_enabled", "in_gossip", "zone", "lz_num", "lz_max_num"}, true);
    for (auto& ls : rsp.nodes()) {
        if (static_cast<log_service::GaiaErrno>(ls.info().status().code()) == log_service::GIE_OK) {
            table.AddRowsValue({
                    ls.addr(),
                    ls.info().write_lsn(),
                    ls.info().vdl(),
                    ls.info().parse_lsn(),
                    ls.info().dispatch_lsn(),
                    ls.info().archive_lsn(),
                    ls.info().gc_lsn(),
                    ls.info().lowest_lz_lsn(),
                    ls.info().cn_lowest_lsn(),
                    ls.info().ps_lowest_lsn(),
                    get_unknown_type(ls.info().has_cn_lowest_gc_lsn(), ls.info().cn_lowest_gc_lsn()),
                    get_unknown_type(ls.info().has_ps_lowest_gc_lsn(), ls.info().ps_lowest_gc_lsn()),
                    ls.info().link_buf_tail(),
                    ls.info().epoch(),
                    ls.info().quorum_enabled(),
                    ls.info().in_gossip(),
                    GetZoneStr(ls.info()),
                    ls.info().used_lz_file_num(),
                    ls.info().max_lz_file_num(),
                    });
        } else {
            table.AddRowsValue({ls.addr(), RowStr(ls.info().status().msg())});
        }
    }
    table.Display();
    return 0;
}

int GetLowestPoint::Format(const gaiapb::ListPageServerResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.page_servers_size()) {
        uint32_t lowest_segment_id = rsp.page_servers(0).segment_id();
        if (!_more) {
            uint64_t lowest_lsn = rsp.page_servers(0).checkpoint_lsn();
            for (auto& ps : rsp.page_servers()) {
                if (ps.checkpoint_lsn() < lowest_lsn) {
                    lowest_lsn = ps.checkpoint_lsn();
                    lowest_segment_id = ps.segment_id();
                }
            }
        }
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({
                "segment_id", "replica_id", "addr",
                "fetch_lsn", "apply_lsn", "checkpoint_lsn",
                "state", "recovery_status", "slow", "version", "zone"}, true);
        for (auto& ps : rsp.page_servers()) {
            if (!_more && ps.segment_id() != lowest_segment_id) {
                continue;
            }
            table.AddRowsValue({
                    ps.segment_id(),
                    ps.replica_id(),
                    ps.addr(),
                    ps.fetch_lsn(),
                    ps.apply_lsn(),
                    ps.checkpoint_lsn(),
                    gaiadb::NodeState_Name(ps.state()),
                    gaiadb::RecoveryStatus_Name(ps.recovery_status()),
                    ps.is_slow(),
                    ps.version(),
                    GetZoneStr(ps)
                });
        }
        table.Display();
    }
    return 0;
}

int GetLowestPoint::Format(const gaiapb::GetLowestPointResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, _show_total ? 4 : 2);
    table.AddRowsValue({"cluster_role", gaiadb::ClusterRole_Name(rsp.cluster_role())});
    table.AddRowsValue({"lowest_trx_id", rsp.lowest_trx_id()});
    table.AddRowsValue({"lowest_gc_lsn_status", rsp.lowest_gc_lsn_status()});
    table.AddRowsValue({"cn_lowest_lsn", rsp.cn_lowest_lsn()});
    table.AddRowsValue({"cn_lowest_gc_lsn", rsp.cn_lowest_gc_lsn()});
    table.AddRowsValue({"ps_lowest_lsn", rsp.ps_lowest_lsn()});
    if (_show_total) {
        table.AddRowsValue({"ps_lowest_gc_lsn", rsp.ps_lowest_gc_lsn(),
                "diff ps_lowest_lsn",
                RowSize(diff_val(rsp.ps_lowest_gc_lsn(), rsp.ps_lowest_lsn()), _human_readable)});
        table.AddRowsValue({"rbio_lowest_gc_lsn", rsp.rbio_lowest_gc_lsn(),
                "diff ps_lowest_gc_lsn",
                RowSize(diff_val(rsp.rbio_lowest_gc_lsn(), rsp.ps_lowest_gc_lsn()), _human_readable)});
    } else {
        table.AddRowsValue({"ps_lowest_gc_lsn", rsp.ps_lowest_gc_lsn()});
        table.AddRowsValue({"rbio_lowest_gc_lsn", rsp.rbio_lowest_gc_lsn()});
    }
    table.AddRowsValue({"replication_apply_lsn", rsp.replication_apply_lsn()});
    table.AddRowsValue({"replication_write_lsn", rsp.replication_write_lsn()});
    table.AddRowsValue({"replication_trx_id", rsp.replication_trx_id()});
    table.AddRowsValue({"standby_cluster_lowest_lsn", rsp.standby_cluster_lowest_lsn()});
    table.AddRowsValue({"standby_cluster_lowest_trx_id", rsp.standby_cluster_lowest_trx_id()});
    table.AddRowsValue({"ls_lowest_gc_lsn", rsp.ls_lowest_gc_lsn()});
    table.AddRowsValue({"ls_max_write_lsn", rsp.ls_max_write_lsn()});
    if (_show_total) {
        table.AddRowsValue({"ls_max_vdl", rsp.ls_max_vdl(),
                "diff ls_lowest_gc_lsn",
                RowSize(diff_val(rsp.ps_lowest_gc_lsn(), rsp.ps_lowest_lsn()), _human_readable)});
    } else {
        table.AddRowsValue({"ls_max_vdl", rsp.ls_max_vdl()});
    }
    table.AddRowsValue({"binlog_in_redo_lowest_sync_lsn", rsp.binlog_in_redo_lowest_sync_lsn()});
    table.Display();
    return 0;
}

}
}
