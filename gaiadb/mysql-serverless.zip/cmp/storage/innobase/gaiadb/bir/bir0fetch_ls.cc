#include "bir0async_binlog.h"
#include <ctype.h>
#include <base/base64.h>
#include <openssl/hmac.h>
#include <baidu/rpc/uri.h>
#include <baidu/rpc/details/http_message.h>
#include <openssl/aes.h>
#include "gaiadb/common/global_flags.h"
#include "rpl0rpl.h"
#include "rpl0parse.h"
#include "gaiadb/redo_fetch/fetch_mdc_object.h"
#include "gaiadb/redo_fetch/fetch_mdc_utils.h"

namespace bir {

int32_t BirAsyncBinlog::refresh_replicas(rpl::LogServerInfo &ls_info) {
  if (ls_info.need_refresh_replicas()) {
    if (!ls_info.refresh_replicas()) {
      if (req_count_ % 128 == 0) {
        ib_error(ER_IB_GAIA_MSG_RPL)
          << "Gaia binlog recover fetch log failed: "
          "rpc failed on get log serice addr";
      }
      std::this_thread::sleep_for(
        std::chrono::microseconds(1000 * 100));  // sleep 100ms if psm do not work
      ls_info.reuse_maybe_error_replicas();
    }
  } else if (ls_info.refresh_zone()) {
    ls_info.resort_replicas();
  }
  if (ls_info.replicas.empty()) {
    return FETCH_ERROR::ERROR; // empty nodes list
  }
  return FETCH_ERROR::SUCCESS;
}
// fetch log-service
int32_t BirAsyncBinlog::fetch_ls_log(
    rpl::LogServerInfo &ls_info, int wait_for_more_data_count, lsn_t end_lsn) {
  baidu::rpc::Controller cntl;
  log_service::sec_get_log_request request;
  log_service::sec_get_log_response response;
  lsn_t start_lsn = fetch_lsn_;
  lsn_t request_lsn = ut_uint64_align_down(start_lsn, OS_FILE_LOG_BLOCK_SIZE);
  uint32_t req_blocks_n = end_lsn == 0 ?
        rpl::RplConst::RPL_FETCH_BLOCK_NUMS :
        (end_lsn - request_lsn) / OS_FILE_LOG_BLOCK_SIZE + 1;
  if (req_blocks_n > rpl::RplConst::RPL_FETCH_BLOCK_NUMS) {
    req_blocks_n = rpl::RplConst::RPL_FETCH_BLOCK_NUMS;
  }
  if (refresh_replicas(ls_info)) {
    LOG(WARNING) << "refresh replicas failed";
    return FETCH_ERROR::ERROR;
  }

  auto &ls_replica = ls_info.get_replica();

  request.set_start_lsn(request_lsn);
  request.set_expect_blocks(req_blocks_n);
  request.set_block_no(log_block_convert_lsn_to_hdr_no(request_lsn));
  request.set_server_id(1);
  if (ls_info.has_zone && ls_replica.has_zone()) {
    request.mutable_zone()->set_region(ls_replica.region);
    request.mutable_zone()->set_available_zone(ls_replica.available_zone);
  }

  bir_client_.Call(&cntl, ls_replica.addr, &ls_stub::get_log, &request,
      &response, nullptr);

  if (cntl.Failed()) {
    LOG(WARNING) << "Gaia bir binlog recover fetch ls log failed: rpc "
      "failed on requesting logs at start_lsn = "
      << start_lsn << " from: " << ls_replica.addr << ", " <<  cntl.ErrorText() ;
    ++ls_info.fetch_invalid_count;
    return FETCH_ERROR::ERROR;
  }

  if (response.has_refresh_zone() && response.refresh_zone() &&
      ls_info.has_zone && response.has_zone()) {
    ++ls_info.fetch_invalid_count;
  }

  lsn_t ls_vdl = response.master_vdl();
  uint32_t valid_block_num = response.block_num();

  // The lsn is not found in ls.
  if (ls_vdl < start_lsn || valid_block_num == 0) {
    LOG(TRACE) << "Gaia bir binlog recover fetch ls log failed: no valid data.";
    if (ls_vdl - start_lsn >
          rpl::RplConst::RPL_FETCH_BLOCK_NUMS * OS_FILE_LOG_BLOCK_SIZE) {
      LOG(TRACE) << "Gaia bir binlog recover fetch ls log failed, not found lsn data.";
      return FETCH_ERROR::NOT_FOUND_LSN;
    } else if (end_lsn == 0 && valid_block_num == 0) {
      LOG(TRACE) << "Gaia bir binlog recover fetch ls log empty";
      return FETCH_ERROR::DATA_NOT_ENOUGH;
    } else {
      return FETCH_ERROR::SUCCESS;
    }
  }

  return copy_to_fetch_log_buf(
    response.blocks().c_str(), valid_block_num, ls_vdl, end_lsn);
}
}
