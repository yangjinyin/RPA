/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file tools/src/check_replicas_rbio.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <sstream>
#include "psvr/page_op.h"
#include "gaia/check_replicas_rbio.h"

namespace psvr {
namespace gaia {

void ProgressBar::Display(bool force) {
    if (_silent) {
        return;
    }
    float space_progress = 0.0;
    uint32_t space_pos = 0;
    float extent_progress = 0.0;
    uint32_t extent_pos = 0;

    if (!force && base::cpuwide_time_s() - _last_show_time < 3) {
        return;
    }
    _last_show_time = base::cpuwide_time_s();

    if (_space_total > 0) {
        space_progress = static_cast<float>(_space_complete * 1.0) / _space_total;
        space_pos = static_cast<uint32_t>(_space_width * space_progress);
    }
    if (_extent_total > 0) {
        extent_progress = static_cast<float>(_extent_complete * 1.0) / _extent_total;
        extent_pos = static_cast<uint32_t>(_extent_width * extent_progress);
    }

    const auto default_precision{std::cout.precision()};
    if (_space_total) {
        std::cout << "Space [";
        for (uint32_t i = 0; i < _space_width; ++i) {
            if (i < space_pos) {
                std::cout << "=";
            } else if (i == space_pos) {
                std::cout << ">";
            } else {
                std::cout << " ";
            }
        }
        std::cout << "| size:" << _space_total <<  ", ";
        std::cout << std::fixed << std::setprecision(2) << (space_progress * 100.0) << "%] ";
        std::cout << std::setprecision(default_precision);
        std::cout << " Extent [";
        auto prepare_extent_num = _prepare_extent.load();
        if (prepare_extent_num) {
            extent_pos = prepare_extent_num % _extent_width;
        }
        for (uint32_t i = 0; i < _extent_width; ++i) {
            if (i < extent_pos) {
                std::cout << (prepare_extent_num ? "-" : "=");
            } else if (i == extent_pos) {
                std::cout << (prepare_extent_num ? "-" : ">");
            } else {
                std::cout << " ";
            }
        }
        std::cout << "| size:" << _extent_total << ", ";
        std::cout << std::fixed << std::setprecision(1) << (extent_progress * 100.0) << "%] ";
        std::cout << std::setprecision(default_precision);
    }
    if (_retry_io) {
        std::cout << "[retry: " << _retry_io.load() << "] ";
    }
    if (_error_page_count) {
        std::cout << "[error: " << _error_page_count.load() << "] ";
    }
    std::cout << "[io_depth: " << _iodepth.load() << "] ";
    auto time_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - _start_time).count();
    std::cout << "cost:" << std::fixed << std::setprecision(2) << static_cast<float>(time_elapsed / 1000.0) << "s\033[K\r";
    std::cout.flush();
}

void CheckReplicasRbio::OnCompletion(CheckSpacePageContext* ctx) {
    if (_stopped) {
        delete ctx;
        return;
    }
    switch(ctx->action) {
    case kSend:
        return CheckSpacePage(ctx);
    case kCheck:
        return OnCheck(ctx);
    default:
        assert(false);
    }
}

bool CheckReplicasRbio::GetSpaces(std::vector<uint32_t>* ids) {
    std::vector<base::EndPoint> nodes;
    if (!_psm_info->GetOrRefreshNodes(&nodes)) {
        return false;
    }
    psvr::RpcStatus status;
    gaiapb::EmptyMessage request;
    gaiapb::GetAllSpaceIdsResponse response;
    for (size_t i = 0; i < nodes.size(); ++i) {
        _client.Call(get_log_id(), nodes[i], &gaiapb::QueryService_Stub::get_all_space_ids, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && response.status().code() == gaiadb::GIE_OK) {
            for (auto& id : response.space_ids()) {
                ids->push_back(id);
            }
            _psm_info->MoveLeaderToFirst(i, nodes[i]);
            return true;
        } else {
            LOG(WARNING) << nodes[i] << " get space failed, " << status << " " << response.status();
        }
    }
    _psm_info->SetFailed();
    LOG(ERROR) << "get space failed, all node failed";
    return false;
}

int CheckReplicasRbio::Run() {
    gaiadb::common::ut_crc32_init();

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_cluster_id.empty()) {
        print_error("miss --cluster-id");
        return 1;
    }

    _thread_pool.reset(new ThreadPoolExecutor<CheckSpacePageContext>);
    _psm_info.reset(new PsmInfo(_manager_address, _both));
    _buf_pool.reset(new BufPool);

    typename thread::Executor<CheckSpacePageContext>::TaskFn fn
        = std::bind(&CheckReplicasRbio::OnCompletion, this, std::placeholders::_1);
    if (!_thread_pool->Start("check", 100000, _thread_num, false, fn)) {
        LOG(ERROR) << "check thread pool start failed";
        return 1;
    }

    if (!GetSpaces(&_space_ids)) {
        return 1;
    }
    for (auto& space_id : _space_ids) {
        _space_ids_set.emplace(space_id);
    }

    if (_specify_space) {
        for (auto& id : _space_id_vec) {
            if (auto it = _space_ids_set.find(id); it == _space_ids_set.end()) {
                std::cout << "ERROR: space id not in manager, id:" << id << std::endl;
                return 1;
            }
        }
        _space_ids.clear();
        _space_ids = _space_id_vec;
    }

    LOG(NOTICE) << "get space ok,"
        << " cluster_id:[" << _cluster_id
        << "] size:[" << _space_ids.size()
        << "] silent:[" << _silent
        << "] debug:[" << _debug
        << "]";

    _show_bar.set_silent(_silent);
    _show_bar.set_space_total(_space_ids.size());
    _show_bar.Display(true);

    for (auto& space_id : _space_ids) {
        if (!CheckSpace(space_id)) {
            printf("\nerror\n");
            return 1;
        }
        _show_bar.inc_space_complete();
        _show_bar.Display();
        if (_stopped) {
            return 1;
        }
    }
    _show_bar.Done();
    if (_fail_num.load() > 0) {
        printf("done, fail!\n");
        LOG(NOTICE) << "done, fail";
    } else {
        printf("done, success!\n");
        LOG(NOTICE) << "done, success";
    }
    return 0;
}

bool CheckReplicasRbio::ExistSpaceId(uint32_t id) {
    std::vector<base::EndPoint> nodes;
    if (!_psm_info->GetOrRefreshNodes(&nodes)) {
        // unknown, let it exists
        return true;
    }
    while (!_stopped) {
        psvr::RpcStatus status;
        gaiapb::GetSpaceMetaRequest request;
        gaiapb::GetSpaceMetaResponse response;

        request.set_space_id(id);
        request.set_need_encryption_info(false);
        request.set_cluster_id(_cluster_id);

        for (size_t i = 0; i < nodes.size(); ++i) {
            _client.Call(get_log_id(), nodes[i], &gaiapb::QueryService_Stub::get_space_meta, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && (response.status().code() == gaiadb::GIE_OK || response.status().code() == gaiadb::GIE_NOT_EXIST)) {
                return response.status().code() == gaiadb::GIE_NOT_EXIST ? false : true;
            } else {
                LOG(WARNING) << nodes[i] << " get space meta failed, " << status << " " << response.status();
            }
        }
    }
    _psm_info->SetFailed();
    return true;
}

bool CheckReplicasRbio::GetSpaceExtents(uint32_t space_id, std::list<uint32_t>* extent_segments) {
    std::vector<base::EndPoint> nodes;
    if (!_psm_info->GetOrRefreshNodes(&nodes)) {
        return false;
    }
    uint32_t begin_extent_id = 0;
    uint32_t num = 1024;
    uint32_t n = 0;
    while (!_stopped) {
        psvr::RpcStatus status;
        gaiapb::GetSpaceExtentMapRequest request;
        gaiapb::GetSpaceExtentMapResponse response;

        request.set_space_id(space_id);
        request.set_begin_extent_id(begin_extent_id);
        request.set_num(num);
        request.set_need_physical_extent_id(false);

        _show_bar.set_prepare_extent(++n);
        _show_bar.Display();

        uint32_t rsp_num = 0;
        for (size_t i = 0; i < nodes.size(); ++i) {
            _client.Call(get_log_id(), nodes[i], &gaiapb::QueryService_Stub::get_space_extent_map, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && response.status().code() == gaiadb::GIE_OK) {
                for (auto& extent : response.extent_map().entries()) {
                    extent_segments->push_back(extent.segment_id());
                    ++rsp_num;
                }
                _psm_info->MoveLeaderToFirst(i, nodes[i]);
                break;
            } else {
                LOG(WARNING) << nodes[i] << " get space extent failed, " << status << " " << response.status();
            }
        }

        begin_extent_id += rsp_num;
        if (begin_extent_id >= response.total_extent_num()) {
            break;
        }

        if (rsp_num == 0) {
            LOG(ERROR) << "get space extent failed, all node failed";
            _psm_info->SetFailed();
            return false;
        }
    }
    return true;
}

bool CheckReplicasRbio::CheckSpace(uint32_t space_id) {
    std::list<uint32_t> extent_segments;
    if (!GetSpaceExtents(space_id, &extent_segments)) {
        return ExistSpaceId(space_id) ? false : true;
    }
    _show_bar.set_prepare_extent(0);
    _show_bar.set_extent_total(extent_segments.size() * 64);
    _show_bar.Display(true);

    LOG(NOTICE) << "start check space,"
        << " id:[" << space_id
        << "] extent_num:[" << extent_segments.size()
        << "]";

    _io_inflight.store(0);

    auto check_segment_fn = [this](uint32_t s) {
        return _segment_id_set.count(s) > 0;
    };

    uint32_t sleep_nr = 0;
    auto it = extent_segments.begin();
    uint32_t extent_id = 0;
    uint32_t extent_pos = 0;
    uint64_t show_n = 0;
    while (it != extent_segments.end()) {
        if (_stopped) {
            return false;
        }

        if (_io_inflight.load() >= _io_depth) {
            sleep_for(1000);
            if (++sleep_nr % 3 == 0) {
                _show_bar.Display();
            }
            continue;
        }
        sleep_nr = 0;

        if (!_specify_segment_id || check_segment_fn(*it)) {
            CheckSpacePageContext* ctx = new CheckSpacePageContext;
            ctx->action = kSend;
            ctx->space_id = space_id;
            ctx->extent_id = extent_id;
            ctx->extent_pos = extent_pos;
            ctx->logical_page_no = extent_pos + extent_id * 64;
            ctx->segment_id = *it;
            ctx->client_id = extent_pos;
            _thread_pool->Execute(ctx);

            _io_inflight.fetch_add(1);
        }

        ++extent_pos;
        if (extent_pos == 64) {
            extent_pos = 0;
            ++extent_id;
            ++it;
            _show_bar.inc_extent_complete();
        }
        if (++show_n % 100 == 0) {
            _show_bar.Display();
        }
        _show_bar.set_iodepth(_io_inflight.load());
    }

    // wait finish
    while (_io_inflight.load() > 0) {
        sleep_for(1000000);
        _show_bar.set_iodepth(_io_inflight.load());
        _show_bar.Display();
    }

    LOG(NOTICE) << "end check space,"
        << " id:[" << space_id
        << "] extent_num:[" << extent_segments.size()
        << "] io_num:[" << show_n
        << "]";

    return true;
}

bool CheckReplicasRbio::GetSegmentNodes(uint32_t segment_id, std::vector<base::EndPoint>* seg_nodes) {
    {
        std::shared_lock slm(_shared_mutex);
        auto it = _cache_segments.find(segment_id);
        if (it != _cache_segments.end()) {
            *seg_nodes = it->second;
            if (seg_nodes->size()) {
                return true;
            }
        }
    }
    std::unique_lock lm(_shared_mutex);
    std::vector<base::EndPoint> nodes;
    if (!_psm_info->GetOrRefreshNodes(&nodes)) {
        return false;
    }
    psvr::RpcStatus status;
    gaiapb::GetSegmentRequest request;
    gaiapb::GetSegmentResponse response;
    request.set_segment_id(segment_id);
    for (size_t i = 0; i < nodes.size(); ++i) {
        _client.Call(get_log_id(), nodes[i], &gaiapb::QueryService_Stub::get_segment, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && response.status().code() == gaiadb::GIE_OK) {
            for (auto& ps : response.page_servers()) {
                base::EndPoint ep;
                base::str2endpoint(ps.addr().c_str(), &ep);
                seg_nodes->push_back(ep);
            }
            _cache_segments[segment_id] = *seg_nodes;
            _psm_info->MoveLeaderToFirst(i, nodes[i]);
            return true;
        } else {
            LOG(WARNING) << nodes[i] << " get space failed, " << status << " " << response.status();
        }
    }
    LOG(ERROR) << "get space failed, all node failed";
    _psm_info->SetFailed();
    return false;
}

void CheckReplicasRbio::CheckSpacePage(CheckSpacePageContext* ctx) {
    if (ctx->retry_num > 10) {
        std::stringstream ss;
        for (size_t i = 0; i < ctx->rbio_ctxs.size(); ++i) {
            ss << "\n" << i << ":" << *ctx->rbio_ctxs[i];
        }
        LOG(ERROR) << "check failed, cluster:" << _cluster_id
            << ", segment_id:" << ctx->segment_id
            << ", space_id:" << ctx->space_id
            << ", page_no:" << ctx->logical_page_no
            << ", extent_id:" << ctx->extent_id
            << ", extent_pos:" << ctx->extent_pos
            << ", segment_offset:" << (ctx->extent_id * 1048576 + ctx->extent_pos * 16384)
            << ss.str();
        _show_bar.inc_error_page_count();
        _io_inflight.fetch_sub(1);
        _fail_num.fetch_add(1);
        delete ctx;
        return;
    }

    std::vector<base::EndPoint> nodes;
    if (!GetSegmentNodes(ctx->segment_id, &nodes)) {
        LOG(NOTICE) << "get segment failed";
        _thread_pool->Schedule(ctx, 100000ul);
        return;
    }

    ctx->rbio_ctxs.clear();
    ctx->task_count.store(nodes.size());

    pspb::RbioRequest request;
    request.set_requestid(get_log_id());
    request.set_n(1);
    request.set_readtype(pspb::RbioRequest::READ_SYNC);
    request.set_peerread(true);
    request.set_segment_id(ctx->segment_id);
    request.set_cluster_id(_cluster_id);
    auto vec = request.add_reqvec();
    vec->set_tablespaceid(ctx->space_id);
    vec->set_logicalpageno(ctx->logical_page_no);
    vec->set_vlsn(ctx->vlsn);
    vec->set_ziplen(gaia_apply::FLAGS_univ_page_size);

    //LOG(TRACE) << "rpc count:" << nodes.size() << " pos:" << extent_pos;
    for (auto& node : nodes) {
        std::shared_ptr<RbioCtx> rbio_ctx(new RbioCtx);
        rbio_ctx->node = node;

        //LOG(TRACE) << "rpc send:" << node << " pos:" << extent_pos;
        auto closure = brpc::NewCallback(this, &CheckReplicasRbio::OnCheckSpacePage, ctx, rbio_ctx);
        _client.Call(get_log_id(), node, &pspb::RbioService_Stub::Rbio,
                &request, &rbio_ctx->response, closure, &rbio_ctx->status, _timeout_ms);
    }
}

void CheckReplicasRbio::OnCheckSpacePage(CheckSpacePageContext* check_ctx, std::shared_ptr<RbioCtx> rbio_ctx) {
    //LOG(TRACE) << "rbio done, " << rbio_ctx->node << " pos:" << batch_rpc_ctx->extent_pos;
    {
        std::unique_lock<std::mutex> lm(check_ctx->mutex);
        check_ctx->rbio_ctxs.push_back(rbio_ctx);
    }
    uint32_t nr = check_ctx->task_count.fetch_sub(1);
    if (nr - 1 != 0) {
        return;
    }
    check_ctx->action = kCheck;
    _thread_pool->Execute(check_ctx);
}

void CheckReplicasRbio::OnCheck(CheckSpacePageContext* check_ctx) {
    bool replicas_changed = false;
    for (auto& ctx : check_ctx->rbio_ctxs) {
        ResetRbioCtxRsp(ctx);
        if (!ctx->status.IsOk()) {
            LOG(NOTICE) << ctx->node << " " << ctx->status
                << " space_id:[" << check_ctx->space_id
                << "] page_no:[" << check_ctx->logical_page_no
                << "] extent_id:[" << check_ctx->extent_id
                << "] extent_pos:[" << check_ctx->extent_pos
                << "] vlsn:[" << check_ctx->vlsn
                << "]";
            replicas_changed = true;
            continue;
        }

        ctx->rpc_ok = true;
        if (ctx->response.errcode() != pspb::RbioResponse_Error_RBIO_SUCCESS){
            LOG(NOTICE) << ctx->node << " " << pspb::RbioResponse_Error_Name(ctx->response.errcode())
                << " space_id:[" << check_ctx->space_id
                << "] page_no:[" << check_ctx->logical_page_no
                << "] extent_id:[" << check_ctx->extent_id
                << "] extent_pos:[" << check_ctx->extent_pos
                << "]";
            replicas_changed = ctx->response.errcode() == pspb::RbioResponse_Error_RBIO_SEGMENT_NOT_EXIST;
            continue;
        }
        ctx->rsp_ok = true;
    }

    if (replicas_changed) {
        std::unique_lock lm(_shared_mutex);
        _cache_segments.erase(check_ctx->segment_id);
    }

    static gaia_apply::page_size_t page_size(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size, false);
    BufBlockPtr buf_block = _buf_pool->AllocBufBlock(gaia_apply::FLAGS_univ_page_size, nullptr);
    init_buf_block(buf_block, check_ctx->space_id, check_ctx->logical_page_no, page_size);

    bool has_rpc_fail = false;
    for (auto& ctx : check_ctx->rbio_ctxs) {
        if (!ctx->rpc_ok) {
            has_rpc_fail = true;
            continue;
        }

        if (!ctx->rsp_ok) {
            continue;
        }

        const auto& rsp_vec = ctx->response.resvec(0);
        memcpy(buf_block->frame, rsp_vec.pageframe().c_str(), gaia_apply::FLAGS_univ_page_size);

        ctx->corrupted = buf_block_is_corrupted(buf_block, &ctx->is_empty);
        if (ctx->corrupted) {
            continue;
        }
        if (ctx->is_empty) {
            ctx->crc = 0;
            ctx->space_id = 0;
            ctx->page_no = 0;
            ctx->page_lsn = 0;
        } else {
            ctx->crc = gaia_apply::mach_read_from_4(buf_block->frame + gaia_apply::FIL_PAGE_SPACE_OR_CHKSUM);
            ctx->space_id = gaia_apply::page_get_space_id(buf_block->frame);
            ctx->page_no = gaia_apply::page_get_page_no(buf_block->frame);
            ctx->page_lsn = buf_block_get_page_lsn(buf_block);
        }
    }

    bool check_fail = false;
    auto first = check_ctx->rbio_ctxs[0];
    for (size_t i = 1; i < check_ctx->rbio_ctxs.size(); ++i) {
        auto next = check_ctx->rbio_ctxs[i];
        if (!first->rpc_ok || !next->rpc_ok
                || !first->rsp_ok || !next->rsp_ok
                || first->corrupted || next->corrupted
                || first->is_empty != next->is_empty
                || first->crc != next->crc
                || first->space_id != next->space_id
                || first->page_no != next->page_no
                || first->page_lsn != next->page_lsn
                || (_max_page_lsn > 0 && first->page_lsn > _max_page_lsn)) {
            check_fail = true;
            break;
        }
    }
    if (check_fail) {
        size_t has_lsn_num = 0;
        for (size_t i = 0; i < check_ctx->rbio_ctxs.size(); ++i) {
            auto next = check_ctx->rbio_ctxs[i];
            if (next->page_lsn > 0) {
                ++has_lsn_num;
            }
        }
        check_ctx->vlsn = LOG_START_LSN;
        if (has_lsn_num == check_ctx->rbio_ctxs.size()) {
            check_ctx->vlsn = first->page_lsn;
        }
        _show_bar.inc_retry_io();
        check_ctx->action = kSend;
        if (!has_rpc_fail) {
            ++check_ctx->retry_num;
        }
        _thread_pool->Schedule(check_ctx, 100000ul);
        return;
    }

    if (check_ctx->rbio_ctxs.size() != _replica_num) {
        LOG(WARNING) << "replicas size is not 3,"
            << " space_id:[" << check_ctx->space_id
            << "] page_no:[" << check_ctx->logical_page_no
            << "] extent_id:[" << check_ctx->extent_id
            << "] extent_pos:[" << check_ctx->extent_pos
            << "] last_lsn:[" << first->page_lsn
            << "] last_space:[" << first->space_id
            << "] last_page_no:[" << first->page_no
            << "] replica_num:[" << check_ctx->rbio_ctxs.size()
            << "]";
    }

    LOG_IF(NOTICE, _debug) << "check ok,"
        << " space_id:[" << check_ctx->space_id
        << "] page_no:[" << check_ctx->logical_page_no
        << "] extent_id:[" << check_ctx->extent_id
        << "] extent_pos:[" << check_ctx->extent_pos
        << "] empty:[" << first->is_empty
        << "] page_lsn:[" << first->page_lsn
        << "] space_id:[" << first->space_id
        << "] page_no:[" << first->page_no
        << "] page_crc:[" << first->crc
        << "] replica_num:[" << check_ctx->rbio_ctxs.size()
        << "]";

    _io_inflight.fetch_sub(1);
    delete check_ctx;
}

}
}
