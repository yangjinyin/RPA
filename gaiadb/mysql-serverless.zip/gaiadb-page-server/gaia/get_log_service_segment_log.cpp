/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_log_service_segment_log.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <algorithm>
#include <sstream>
#include <cstdlib>
#include <cstring>
#include <cerrno>
#include "gaia/get_log_service_segment_log.h"
#include "gaia/parse_apply_rec.h"

namespace psvr {
namespace gaia {

bool GetLogServiceSegmentLog::CheckSegments() {
    if (_segment_ids.empty()) {
        print_error("miss --segment-id");
        return false;
    }
    if (_segment_ids.size() != _fetch_lsns.size()) {
        print_error("mismatch --segment-id and --fetch-lsn size");
        return false;
    }
    return true;
}

int GetLogServiceSegmentLog::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }
    if (!CheckSegments()) {
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    // multiple segment groups switch to batch_get_log automatically
    if (_segment_ids.size() > 1) {
        return RunBatch(node);
    }
    return RunSingle(node);
}

int GetLogServiceSegmentLog::RunSingle(const base::EndPoint& node) {
    lspb::psrv_get_log_request request;
    request.set_segment_id(_segment_ids[0]);
    request.set_fetch_lsn(_fetch_lsns[0]);
    request.set_log_id(_log_id);
    if (!_cluster_id.empty()) {
        request.set_cluster_id(_cluster_id);
    }

    lspb::psrv_get_log_response response;
    RpcStatus status;
    _client.Call(_log_id, node, &lspb::PageServerService_Stub::get_log, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        print_error("rpc get_log failed. %s", status.msg.c_str());
        return 1;
    }
    return Output(response);
}

int GetLogServiceSegmentLog::RunBatch(const base::EndPoint& node) {
    if (_cluster_id.empty()) {
        print_error("miss --cluster-id in batch mode");
        return 1;
    }

    lspb::batch_psrv_get_log_request request;
    request.set_cluster_id(_cluster_id);
    request.set_log_id(_log_id);
    uint64_t max_fetch_lsn = _fetch_lsns[0];
    uint64_t min_fetch_lsn = _fetch_lsns[0];
    for (size_t i = 0; i < _segment_ids.size(); ++i) {
        auto* segment = request.add_segments();
        segment->set_segment_id(_segment_ids[i]);
        segment->set_fetch_lsn(_fetch_lsns[i]);
        max_fetch_lsn = std::max(max_fetch_lsn, _fetch_lsns[i]);
        min_fetch_lsn = std::min(min_fetch_lsn, _fetch_lsns[i]);
    }
    request.set_max_fetch_lsn(max_fetch_lsn);
    request.set_min_fetch_lsn(min_fetch_lsn);

    lspb::batch_psrv_get_log_response response;
    RpcStatus status;
    _client.Call(_log_id, node, &lspb::PageServerService_Stub::batch_get_log, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        print_error("rpc batch_get_log failed. %s", status.msg.c_str());
        return 1;
    }
    return Output(response);
}

bool GetLogServiceSegmentLog::PrintRecords(const std::string& data,
        uint32_t total_len, uint32_t checksum) {
    if (data.empty()) {
        return true;
    }
    if (total_len != data.size()) {
        print_error("response data size mismatch, total_len:%u, data_len:%zu",
                total_len, data.size());
        return false;
    }

    const auto* log_block_data = reinterpret_cast<const gaia_apply::byte*>(data.data());
    uint32_t actual_checksum = gaiadb::common::ut_crc32(log_block_data, total_len);
    if (actual_checksum != checksum) {
        print_error("response data checksum mismatch, expect:%u, actual:%u",
                checksum, actual_checksum);
        return false;
    }

    auto* buf = static_cast<gaia_apply::byte*>(std::malloc(total_len));
    if (!buf) {
        print_error("malloc records buf failed, size:%u, %s", total_len, strerror(errno));
        return false;
    }
    std::memcpy(buf, log_block_data, total_len);

    Table table(_raw_with_table, 0);
    table.AddRowsWithName({"rec_start_lsn", "rec_end_lsn", "type", "type_str",
            "space", "page", "body_len", "real_page_last_lsn"}, true);

    uint64_t record_num = 0;
    GaiaLogRecordIterator iter(buf, buf + total_len, 0);
    for (; iter.Valid(); iter.Next()) {
        const auto& record = iter.Get();
        table.AddRowsValue({record.start_lsn, record.end_lsn,
                static_cast<int32_t>(record.type),
                gaia_apply::rec_type_name(record.type),
                record.space_id, record.page_no,
                static_cast<uint64_t>(record.body_len),
                record.last_page_lsn});
        ++record_num;
    }
    table.Display();

    bool ok = iter.Status().IsOk();
    if (!ok) {
        std::ostringstream oss;
        oss << iter.Status();
        print_error("parse redo record failed: %s", oss.str().c_str());
    } else {
        std::cout << "parse records ok, record_num:[" << record_num << "]" << std::endl;
    }

    std::free(buf);
    return ok;
}

int GetLogServiceSegmentLog::Format(const lspb::psrv_get_log_response& rsp) {
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"log_id:", _log_id});
    table.AddRowsValue({"record_num:", rsp.record_num()});
    table.AddRowsValue({"total_len:", rsp.total_len()});
    table.AddRowsValue({"data_len:", static_cast<uint64_t>(rsp.data_returned().size())});
    table.AddRowsValue({"last_lsn:", rsp.last_lsn()});
    table.AddRowsValue({"data_checksum:", rsp.data_checksum()});
    table.AddRowsValue({"cn_lowest_lsn:", rsp.cn_lowest_lsn()});
    table.AddRowsValue({"write_lsn:", get_unknown_type(rsp.has_write_lsn(), rsp.write_lsn())});
    table.AddRowsValue({"parse_lsn:", get_unknown_type(rsp.has_parse_lsn(), rsp.parse_lsn())});
    table.AddRowsValue({"dispatch_lsn:",
            get_unknown_type(rsp.has_dispatch_lsn(), rsp.dispatch_lsn())});
    table.Display();

    PrintRecords(rsp.data_returned(), rsp.total_len(), rsp.data_checksum());
    return 0;
}

int GetLogServiceSegmentLog::Format(const lspb::batch_psrv_get_log_response& rsp) {
    Table head(_raw_with_table, 2);
    head.AddRowsValue({"log_id:", _log_id});
    head.AddRowsValue({"segment_num:", rsp.segments_size()});
    head.AddRowsValue({"cn_lowest_lsn:",
            get_unknown_type(rsp.has_cn_lowest_lsn(), rsp.cn_lowest_lsn())});
    head.Display();

    for (int32_t i = 0; i < rsp.segments_size(); ++i) {
        const auto& seg = rsp.segments(i);
        std::string error_code = "unknown";
        if (seg.has_error_code()) {
            error_code = lspb::LSRVErrno_Name(seg.error_code());
        }

        Table table(_raw_with_table, 2);
        table.AddRowsValue({"segment_id:", seg.segment_id()});
        table.AddRowsValue({"is_ok:", seg.is_ok()});
        table.AddRowsValue({"error_code:", error_code});
        table.AddRowsValue({"record_num:",
                get_unknown_type(seg.has_record_num(), seg.record_num())});
        table.AddRowsValue({"total_len:", get_unknown_type(seg.has_total_len(), seg.total_len())});
        table.AddRowsValue({"data_len:", static_cast<uint64_t>(seg.data_returned().size())});
        table.AddRowsValue({"last_lsn:", get_unknown_type(seg.has_last_lsn(), seg.last_lsn())});
        table.AddRowsValue({"data_checksum:",
                get_unknown_type(seg.has_data_checksum(), seg.data_checksum())});
        table.Display();

        if (seg.has_data_returned() && seg.has_total_len() && seg.has_data_checksum()) {
            PrintRecords(seg.data_returned(), seg.total_len(), seg.data_checksum());
        }
    }
    return 0;
}

}
}
