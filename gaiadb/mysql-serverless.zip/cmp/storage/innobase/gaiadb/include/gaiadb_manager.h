/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/include/gaiadb_manager.h
 The general function for gaiadb manager

 Created 11/9/2022 Hongyu Qiao
 *******************************************************/

#ifndef gaiadb_gaiadb_manager_h
#define gaiadb_gaiadb_manager_h

#include "univ.i"
#include "db0err.h"
#include <base/endpoint.h>
#include "gaiadb/common/types.h"
#include  "trx0types.h"
#include "sql/binlog.h"

/** Create undo truncate log file to psm
@param[in]      log_file_name       undo truncate log file name
@return DB_SUCCESS if all OK */
dberr_t gaiadb_create_undo_truncate_log_file(const char *log_file_name);

/** Delete undo truncate log file from psm
@param[in]      log_file_name       undo truncate log file name
@return DB_SUCCESS if all OK */
dberr_t gaiadb_delete_undo_truncate_log_file(const char *log_file_name);

/** check undo truncate log file in psm
@param[in]      log_file_name       undo truncate log file name
@return DB_SUCCESS if all OK */
bool gaiadb_undo_truncate_log_file_exist(const char *log_file_name);

/** get lowest trx_id from psm
@return lowest trx_id */
trx_id_t get_lowest_trx_id();

/** get lowest lsn from psm
@return true if success */
bool gaiadb_get_lowest_lsn(uint64_t &lowest_lsn);

/** wait lowest lsn from psm */
void gaiadb_wait_lowest_lsn(uint64_t expect_lsn);

/** delete space from psm
@return true if success */
bool gaiadb_delete_space(uint32_t space_id);

/** get all space ids from psm
@param[out]     ids: will be filled after function returned
@return         PSMGR_CLIENT_SUCCESS
                PSMGR_CLIENT_ERROR
*/
bool gaiadb_get_all_space_ids(std::vector<uint32_t>& ids);

/** get tde space ids from psm
@param[out]     ids: will be filled after function returned
@return         PSMGR_CLIENT_SUCCESS
                PSMGR_CLIENT_ERROR
*/
bool gaiadb_get_tde_space_ids(std::vector<uint32_t>& ids);

bool gaiadb_update_binlog_in_redo_info(const std::string &addr, const BinlogInRedoInfo* binlog_in_redo_info);

BinlogInRedoInfo gaiadb_get_binlog_in_redo_info(const std::string &addr);

#endif /* gaiadb_gaiadb_manager_h */
