/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file include/rpl0fetch.h
 Gaiadb redo log replication

 Created 10/12/2021 Hongyu Qiao
 *******************************************************/

#include "base/endpoint.h"
#include "gaiadb/common/types.h"
#include "gaiadb/proto/log_service/sec_message_servcie.pb.h"
#include "gaiadb/utils/rpc_client.hpp"
#include "rpl0assemble.h"
#include "gaiadb.h"
#include "landing_zone_client.h"

DECLARE_bool(secondary_exit_if_slow_node);

namespace rpl {

DECLARE_uint64(rpl_get_log_consecutive_time);
DECLARE_uint64(rpl_get_log_consecutive_time_from_backup_zone);

class RplFetcher;
extern RplFetcher *g_rpl_fetcher;

extern void rpl_fetcher();

bool rpl_get_log_service_peers(std::vector<gaiadb::common::PeerZone> &peers);

lsn_t copy_to_log_buffer_for_block(lsn_t start_lsn, lsn_t end_lsn,
    const byte *source, uint64_t nblocks,
    byte *dest, uint64_t dest_size,
    bool need_check = true);

struct LogServerInfo {
  std::vector<gaiadb::common::PeerZone> replicas;
  size_t replicas_idx;
  uint64_t fetch_count;
  uint32_t last_zone_version;
  bool has_zone;
  std::string region;
  std::string available_zone;
  size_t zone_replica_count;
  uint32_t fetch_invalid_count;
  uint32_t round_count;

  LogServerInfo() { init(); }
  ~LogServerInfo() {}

  void init() {
    replicas.clear();
    replicas_idx = 0;
    fetch_count = 0;
    last_zone_version = 0;
    has_zone = false;
    region.clear();
    available_zone.clear();
    zone_replica_count = 0;
    fetch_invalid_count = 0;
    // get zone
    init_zone();
  }

  void init_zone() {
    last_zone_version = psmcli->zone_version();
    has_zone = psmcli->has_zone();
    if (has_zone) {
      psmcli->get_zone(&region, &available_zone);
    } else {
      region.clear();
      available_zone.clear();
    }
  }

  bool refresh_zone() {
    const uint32_t zone_version = psmcli->zone_version();
    if (zone_version == last_zone_version) {
      return false;
    }
    init_zone();
    return true;
  }

  void resort_replicas() {
    replicas_idx = 0;
    fetch_count = 0;
    zone_replica_count = 0;
    if (has_zone) {
      gaiadb::common::sort_peer_zone_vector(replicas, region, available_zone);
      for (auto &replica : replicas) {
        if (!replica.match_zone(region, available_zone)) {
          break;
        }
        ++zone_replica_count;
      }
    } else {
      std::random_shuffle(replicas.begin(), replicas.end());
    }
  }

  bool refresh_replicas() {
    std::vector<gaiadb::common::PeerZone> next_replicas;
    if (!rpl_get_log_service_peers(next_replicas)) {
      return false;
    }
    fetch_invalid_count = 0;
    round_count = 0;
    refresh_zone();
    replicas = std::move(next_replicas);
    resort_replicas();
    return true;
  }

  void reuse_maybe_error_replicas() { resort_replicas(); }

  bool fetch_from_backup_zone() const {
    return has_zone && zone_replica_count > 0 &&
           replicas_idx >= zone_replica_count;
  }

  bool need_refresh_replicas() const {
    return fetch_invalid_count >= 16 ||
           replicas.empty() ||
           (replicas.size() !=
                (size_t)landing_zone::FLAGS_gaia_redo_store_replicas &&
            round_count > 3);
  }

  const gaiadb::common::PeerZone &get_replica() {
    ut_a(replicas.size() > replicas_idx);
    return replicas[replicas_idx];
  }

  const gaiadb::common::PeerZone &next_replica(size_t n) {
    size_t idx = (replicas_idx + n) % replicas.size();
    if (has_zone && zone_replica_count > 0) {
      idx = (replicas_idx + n) % zone_replica_count;
    }
    return replicas[idx];
  }

  void fetch_error() {
    ++replicas_idx;
    fetch_count = 0;
    if (replicas_idx >= replicas.size()) {
      replicas_idx = 0;
      ++round_count;
    }
  }

  void fetch_success() {
    ++fetch_count;
    if (fetch_from_backup_zone() &&
        fetch_count >= FLAGS_rpl_get_log_consecutive_time_from_backup_zone) {
      ++replicas_idx;
      fetch_count = 0;
    } else if (fetch_count >= FLAGS_rpl_get_log_consecutive_time) {
      ++replicas_idx;
      fetch_count = 0;
      if (fetch_from_backup_zone() && fetch_invalid_count == 0) {
        replicas_idx = 0;
        ++round_count;
      }
    }
    if (replicas_idx >= replicas.size()) {
      replicas_idx = 0;
      ++round_count;
    }
  }
};

class RplFetcher {
  RplFetcher();

 public:
  ~RplFetcher();

  static RplFetcher &get_instance();

  bool init();

  bool cleanup();

  void routine();

 private:
  DISALLOW_COPY_AND_ASSIGN(RplFetcher);
};

}  // namespace rpl
