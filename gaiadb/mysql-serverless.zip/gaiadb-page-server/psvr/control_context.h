/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/control_context.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/context_types.h"
#include "psvr/cluster.h"
#include "psvr/namespace.h"
#include "psvr/psminfo.h"
#include "psvr/control.h"

namespace psvr {

struct Control::BatchHeartbeatGroup {
    size_t idx;
    uint64_t min_gc_lsn;
    uint64_t max_gc_lsn;
    int32_t segment_size;
    SegmentWeakPtr slow_segment;
    RpcBatchPageServerHeartbeatCtx rpc_ctx;

    BatchHeartbeatGroup(size_t i)
        : idx(i),
        min_gc_lsn(std::numeric_limits<uint64_t>::max()),
        max_gc_lsn(0), segment_size(0) {}
    ~BatchHeartbeatGroup() {}

    bool EnableLog() const;
};

struct Control::BatchHeartbeatTask {
    ClusterWeakPtr cluster;
    std::string cluster_id;
    uint64_t epoch;
    uint64_t max_gc_lsn;
    std::atomic<size_t> inflight_count;
    std::list<std::shared_ptr<BatchHeartbeatGroup>> group_list;

    BatchHeartbeatTask(ClusterPtr cls, uint64_t e)
        : cluster(cls), cluster_id(cls->name()), epoch(e), max_gc_lsn(0), inflight_count(0) {}
    ~BatchHeartbeatTask() {}

    RpcBatchPageServerHeartbeatCtx* Add(SegmentPtr segment);
};

struct Control::Context : public thread::TaskContext {
    Action action;
    SegmentPtr segment;
    PsmInfoPtr psm_info;
    // for rpc
    const ggpb::Message* request;
    ggpb::Message* response;
    ggpb::Closure* closure;
    // for iterator
    uint32_t idx;
    uint32_t count;
    // for retry count
    uint32_t retry_times;
    Timer timer;

    std::variant<nullptr_t,
        RpcGetPageServerCtx*> rpc_ctx {nullptr};

    Context(Action _action)
        : thread::TaskContext(CtxType::kControl),
        action(_action), segment(nullptr), psm_info(nullptr),
        request(nullptr), response(nullptr), closure(nullptr),
        idx(0), count(0), retry_times(0), timer(base::Timer::STARTED) {}

    Context(Action _action, PsmInfoPtr _psm_info)
        : thread::TaskContext(CtxType::kControl),
        action(_action), segment(nullptr), psm_info(_psm_info),
        request(nullptr), response(nullptr), closure(nullptr),
        idx(0), count(0), retry_times(0), timer(base::Timer::STARTED) {}

    Context(Action _action, SegmentPtr _segment)
        : thread::TaskContext(CtxType::kControl),
        action(_action), segment(_segment), psm_info(nullptr),
        request(nullptr), response(nullptr), closure(nullptr),
        idx(0), count(0), retry_times(0), timer(base::Timer::STARTED) {}

    Context(Action _action, SegmentPtr _segment,
        const ggpb::Message* _request,
        ggpb::Message* _response,
        ggpb::Closure* _closure)
        : thread::TaskContext(CtxType::kControl),
        action(_action), segment(_segment), psm_info(nullptr),
        request(_request), response(_response), closure(_closure),
        idx(0), count(0), retry_times(0), timer(base::Timer::STARTED) {}

    ~Context();

    template<typename T> T get_rpc_ctx() {
        auto tmp = std::get<T>(rpc_ctx);
        rpc_ctx = nullptr;
        return tmp;
    }
};

}
