/**************************************************************************
 * Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
 * File Name:     log_queue.h
 **************************************************************************/

#pragma once

#include <list>
#include <psvr0meta.h>
#include "psvr/common.h"
#include "psvr/record_op.h"
#include "psvr/utils.h"

namespace psvr {

struct LogRecord;
using LogRecordPtr = std::unique_ptr<LogRecord>;
class Page;
using PagePtr = std::shared_ptr<Page>;
class Space;
class PageLogRecordIterator;
/* Redo log record */
struct BAIDU_CACHELINE_ALIGNMENT LogRecord {
    const gaia_apply::mlog_id_t type;
    const bool has_page_check_bits;
    const gaia_apply::lsn_t last_page_lsn;
    /* record body */
    const gaia_apply::byte* body;     // data shared LogBlock
    const gaia_apply::ulint body_len;
    /* record start lsn */
    const gaia_apply::lsn_t start_lsn;
    // record's end lsn, could be rewrite as page's last modified record lsn
    const gaia_apply::lsn_t end_lsn;
    const gaia_apply::space_id_t space_id;
    const gaia_apply::page_no_t page_no;

    LogRecord(gaia_apply::mlog_id_t _type,
        gaia_apply::byte* _body,
        gaia_apply::ulint _body_len,
        gaia_apply::lsn_t _start_lsn,
        gaia_apply::lsn_t _end_lsn,
        gaia_apply::space_id_t _space_id,
        gaia_apply::page_no_t _page_no,
        bool _has_page_check_bits,
        gaia_apply::lsn_t _last_page_lsn)
        : type(_type),
        has_page_check_bits(_has_page_check_bits),
        last_page_lsn(_last_page_lsn),
        body(_body), body_len(_body_len),
        start_lsn(_start_lsn), end_lsn(_end_lsn),
        space_id(_space_id), page_no(_page_no) {}
    LogRecord(const LogRecord& rec)
        : type(rec.type),
        has_page_check_bits(rec.has_page_check_bits),
        last_page_lsn(rec.last_page_lsn),
        body(rec.body), body_len(rec.body_len),
        start_lsn(rec.start_lsn), end_lsn(rec.end_lsn),
        space_id(rec.space_id), page_no(rec.page_no) {}
    ~LogRecord() {}
};

inline std::ostream& operator<<(std::ostream& os, const LogRecord& rec) {
    return os << "rec:[" << rec.start_lsn << "," << rec.end_lsn
        << ", type=" << static_cast<uint32_t>(rec.type)
        << ", space=" << rec.space_id
        << ", page=" << rec.page_no
        << "]";
}

static_assert(sizeof(LogRecord) <= 64);

inline bool is_file_delete_record(gaia_apply::mlog_id_t type) {
    return gaia_apply::MLOG_FILE_DELETE == type;
}

class Page {
friend class Space;
friend class PageLogRecordIterator;
public:
    Page(gaia_apply::page_no_t page_no, gaia_apply::space_id_t space_id)
            : _page_no(page_no), _space_id(space_id),
            _last_gc_lsn(0), _last_record_lsn(0), _purge_record_lsn(0), _log_records_size(0) {}
    FUNC_MOCK ~Page() {}

    gaia_apply::space_id_t space_id() const { return _space_id; }
    gaia_apply::page_no_t page_no() const { return _page_no; }
    rwlock_t& shared_mutex(){ return _shared_mutex; }

    gaia_apply::lsn_t last_gc_lsn() const { return _last_gc_lsn.load(std::memory_order_acquire); }
    gaia_apply::lsn_t last_record_lsn() const { return _last_record_lsn.load(std::memory_order_acquire); }

    gaia_apply::lsn_t purge_record_lsn() const { return _purge_record_lsn.load(std::memory_order_acquire); }
    void set_purge_record_lsn(gaia_apply::lsn_t lsn) { _purge_record_lsn.store(lsn); }

#ifdef GTEST
    int64_t log_records_size() const { return _log_records_size; }
#endif

    bool LogRecordEmpty();

    bool AppendLogRecord(const LogRecord* rec);
    bool AppendLogRecords(std::list<const LogRecord*>&& list_rec);

    bool LogRecordIsEmptyNoLock(gaia_apply::lsn_t max_lsn, gaia_apply::lsn_t* lsn = nullptr);
    bool LogRecordIsEmpty(gaia_apply::lsn_t max_lsn, gaia_apply::lsn_t* lsn = nullptr);

    gaia_apply::mlog_id_t GetFirstLogRecordTypeNoLock(gaia_apply::lsn_t max_lsn);
    gaia_apply::mlog_id_t GetFirstLogRecordType(gaia_apply::lsn_t max_lsn);

    bool FirstLogRecordTypeIsInitNoLock(gaia_apply::lsn_t max_lsn);
    bool FirstLogRecordTypeIsInit(gaia_apply::lsn_t max_lsn);

    void PurgeLogRecords(gaia_apply::lsn_t max_record_lsn);
    void PurgeLogRecordsNoLock(gaia_apply::lsn_t max_record_lsn);
    void PurgeLogRecordsNoLock(const PageLogRecordIterator& iter, gaia_apply::lsn_t max_record_lsn);

private:
    const gaia_apply::page_no_t _page_no;  // typedef uint32 page_no_t;
    const gaia_apply::space_id_t _space_id;
    std::atomic<gaia_apply::lsn_t> _last_gc_lsn;
    std::atomic<gaia_apply::lsn_t> _last_record_lsn;
    std::atomic<gaia_apply::lsn_t> _purge_record_lsn;
    int64_t _log_records_size;
    std::list<const LogRecord*> _log_records;
    rwlock_t _shared_mutex;
};

inline std::ostream& operator<<(std::ostream& os, const Page* page) {
    return page ?
        (os << "space:[" << page->space_id()
         << "] page:[" << page->page_no()
         << "] last_gc_lsn:[" << page->last_gc_lsn()
         << "] last_record_lsn:[" << page->last_record_lsn()
         << "] purge_record_lsn:[" << page->purge_record_lsn()
#ifdef GTEST
         << "] log_records_size:[" << page->log_records_size()
#endif
         << "]")
        : os;
}

inline std::ostream& operator<<(std::ostream& os, const PagePtr& page) {
    return os << (page.get());
}

class PageLogRecordIterator : public LogRecordIteratorInterface {
public:
    PageLogRecordIterator(PagePtr page) : _page(page), _size(0) {
        SeekToFirst();
    }
    FUNC_MOCK ~PageLogRecordIterator() {}

    int64_t size() const { return _size; }

    void SeekToFirst() {
        _iter = _page->_log_records.begin();
        _size = 0;
    }

    void Next() override {
        ++_iter;
        ++_size;
    }

    bool Valid() const override {
        return _iter != _page->_log_records.end();
    }

    const LogRecord& Get() const override {
        return **_iter;
    }

    const db::Status& Status() const override {
        return _status;
    }

    std::list<const LogRecord*>::iterator end() const {
        auto end = _page->_log_records.begin();
        std::advance(end, _size);
        return end;
    }

private:
    PagePtr _page;
    std::list<const LogRecord*>::iterator _iter;
    int64_t _size;
    db::Status _status;
};

}
