/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_log_block.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/log_block.h"

namespace psvr {
namespace test {

class LogBlockTests : public PsvrTest {
 public:
    LogBlockTests() {
    }
    virtual ~LogBlockTests() {}

    void SetUp() {
    }

    void TearDown() {
    }

private:
};

TEST_F(LogBlockTests, test_All) {
    ASSERT_EQ(log_translate_lsn_to_sn(1021), 0);

    LogBlockPtr log = create_log_block(11);
    LOG(NOTICE) << log;
    log->latency_us();

    {
        auto p1 = fold_space_page_to_index(fold_space_page_t{1, 1});
        auto p2 = fold_space_page_to_index(fold_space_page_t{1, 2});
        ASSERT_EQ(p1, p2);
    }
    END_OF_CASE;
}

// Test FROM_NONE, FROM_LOCAL, FROM_PEER constants
TEST_F(LogBlockTests, test_from_append_file_constants) {
    ASSERT_EQ(FROM_NONE, 0);
    ASSERT_EQ(FROM_LOCAL, 1);
    ASSERT_EQ(FROM_PEER, 2);

    // LogBlock default from_append_file should be FROM_NONE
    LogBlockPtr log = create_log_block(11);
    ASSERT_EQ(log->from_append_file, FROM_NONE);

    // Test setting different values
    log->from_append_file = FROM_LOCAL;
    ASSERT_EQ(log->from_append_file, FROM_LOCAL);

    log->from_append_file = FROM_PEER;
    ASSERT_EQ(log->from_append_file, FROM_PEER);
    END_OF_CASE;
}

// Test LogBlock::set_key() method
TEST_F(LogBlockTests, test_set_key) {
    LogBlockPtr log = create_log_block(11);

    // Initial append_info.buf should be nullptr
    ASSERT_EQ(log->append_info.buf, nullptr);

    // Test set_key with valid data
    std::string key_data = "test_key_123";
    base::Slice key(key_data);
    bool result = log->set_key(key);
    ASSERT_TRUE(result);
    ASSERT_NE(log->append_info.buf, nullptr);
    ASSERT_EQ(std::memcmp(log->append_info.buf, key_data.data(), key_data.size()), 0);
    END_OF_CASE;
}

// Test KeyValueCache::Init() with buf parameter
TEST_F(LogBlockTests, test_KeyValueCache_Init_with_buf) {
    gaiadb::common::MemArena arena;
    KeyValueCache<uint64_t, uint32_t> cache(&arena);

    // Prepare buffer with 2 entries
    size_t entry_size = sizeof(uint64_t) + sizeof(uint32_t);
    size_t buf_size = entry_size * 2;
    char* buf = static_cast<char*>(arena.Alloc(buf_size));

    // Write entry 1: key=100, value=200
    char* ptr = buf;
    *reinterpret_cast<uint64_t*>(ptr) = 100;
    ptr += sizeof(uint64_t);
    *reinterpret_cast<uint32_t*>(ptr) = 200;
    ptr += sizeof(uint32_t);

    // Write entry 2: key=101, value=201
    *reinterpret_cast<uint64_t*>(ptr) = 101;
    ptr += sizeof(uint64_t);
    *reinterpret_cast<uint32_t*>(ptr) = 201;

    // Init with buf - should parse and populate map
    cache.Init(2, buf);

    // Verify cache state
    ASSERT_EQ(cache.size(), 2);
    ASSERT_EQ(cache.pos(), 2);
    ASSERT_EQ(cache.buf_size(), buf_size);
    ASSERT_TRUE(cache.is_init());

    // Verify values can be retrieved
    uint32_t value;
    ASSERT_TRUE(cache.Get(100, &value));
    ASSERT_EQ(value, 200);
    ASSERT_TRUE(cache.Get(101, &value));
    ASSERT_EQ(value, 201);
    END_OF_CASE;
}

// Test KeyValueCache::Init() without buf parameter
TEST_F(LogBlockTests, test_KeyValueCache_Init_without_buf) {
    gaiadb::common::MemArena arena;
    KeyValueCache<uint64_t, uint32_t> cache(&arena);

    cache.Init(3);

    ASSERT_EQ(cache.size(), 3);
    ASSERT_EQ(cache.pos(), 0);
    ASSERT_FALSE(cache.is_init());

    // Add entries manually
    cache.Add(10, 20);
    cache.Add(11, 21);

    ASSERT_EQ(cache.pos(), 2);

    uint32_t value;
    ASSERT_TRUE(cache.Get(10, &value));
    ASSERT_EQ(value, 20);
    END_OF_CASE;
}

// Test KeyValueCache::Decode() with size mismatch
TEST_F(LogBlockTests, test_KeyValueCache_Decode_size_mismatch) {
    gaiadb::common::MemArena arena;
    KeyValueCache<uint64_t, uint32_t> cache(&arena);

    cache.Init(2);

    size_t entry_size = sizeof(uint64_t) + sizeof(uint32_t);
    char dummy_buf[100] = {0};

    // buf_size mismatch - should return false
    bool result = cache.Decode(dummy_buf, entry_size * 3, 2);  // wrong buf_size
    ASSERT_FALSE(result);

    // size mismatch - should return false
    result = cache.Decode(dummy_buf, entry_size * 2, 3);  // wrong size
    ASSERT_FALSE(result);
    END_OF_CASE;
}

// Test KeyValueCache::Decode() early return when already initialized
TEST_F(LogBlockTests, test_KeyValueCache_Decode_already_init) {
    gaiadb::common::MemArena arena;
    KeyValueCache<uint64_t, uint32_t> cache(&arena);

    size_t entry_size = sizeof(uint64_t) + sizeof(uint32_t);
    size_t buf_size = entry_size * 2;
    char* buf = static_cast<char*>(arena.Alloc(buf_size));

    // Prepare valid buffer
    char* ptr = buf;
    *reinterpret_cast<uint64_t*>(ptr) = 100;
    ptr += sizeof(uint64_t);
    *reinterpret_cast<uint32_t*>(ptr) = 200;
    ptr += sizeof(uint32_t);
    *reinterpret_cast<uint64_t*>(ptr) = 101;
    ptr += sizeof(uint64_t);
    *reinterpret_cast<uint32_t*>(ptr) = 201;

    // Init with buf - becomes initialized
    cache.Init(2, buf);
    ASSERT_TRUE(cache.is_init());
    ASSERT_EQ(cache.pos(), 2);

    // Decode again - should early return with true (pos == size)
    bool result = cache.Decode(buf, buf_size, 2);
    ASSERT_TRUE(result);
    END_OF_CASE;
}

// Test KeyValueCache::Decode() success case
TEST_F(LogBlockTests, test_KeyValueCache_Decode_success) {
    gaiadb::common::MemArena arena;
    KeyValueCache<uint64_t, uint32_t> cache(&arena);

    cache.Init(2);

    size_t entry_size = sizeof(uint64_t) + sizeof(uint32_t);
    size_t buf_size = entry_size * 2;
    char decode_buf[100];

    // Prepare decode buffer
    char* ptr = decode_buf;
    *reinterpret_cast<uint64_t*>(ptr) = 50;
    ptr += sizeof(uint64_t);
    *reinterpret_cast<uint32_t*>(ptr) = 500;
    ptr += sizeof(uint32_t);
    *reinterpret_cast<uint64_t*>(ptr) = 51;
    ptr += sizeof(uint64_t);
    *reinterpret_cast<uint32_t*>(ptr) = 501;

    // Decode should succeed
    bool result = cache.Decode(decode_buf, buf_size, 2);
    ASSERT_TRUE(result);
    ASSERT_EQ(cache.pos(), 2);

    // Verify values
    uint32_t value;
    ASSERT_TRUE(cache.Get(50, &value));
    ASSERT_EQ(value, 500);
    ASSERT_TRUE(cache.Get(51, &value));
    ASSERT_EQ(value, 501);
    END_OF_CASE;
}

// Test KeyValueCache::Add() duplicate key handling
TEST_F(LogBlockTests, test_KeyValueCache_Add_duplicate) {
    gaiadb::common::MemArena arena;
    KeyValueCache<uint64_t, uint32_t> cache(&arena);

    cache.Init(3);

    cache.Add(10, 100);
    ASSERT_EQ(cache.pos(), 1);

    // Adding duplicate key should not increment pos
    cache.Add(10, 200);
    ASSERT_EQ(cache.pos(), 1);

    // Original value should be preserved
    uint32_t value;
    ASSERT_TRUE(cache.Get(10, &value));
    ASSERT_EQ(value, 100);
    END_OF_CASE;
}

// Test records_start_lsn vector (GTEST conditional)
TEST_F(LogBlockTests, test_records_start_lsn) {
    LogBlockPtr log = create_log_block(11);

    // records_start_lsn is only available under GTEST
    ASSERT_TRUE(log->records_start_lsn.empty());

    log->records_start_lsn.push_back(1000);
    log->records_start_lsn.push_back(2000);
    log->records_start_lsn.push_back(3000);

    ASSERT_EQ(log->records_start_lsn.size(), 3);
    ASSERT_EQ(log->records_start_lsn[0], 1000);
    ASSERT_EQ(log->records_start_lsn[1], 2000);
    ASSERT_EQ(log->records_start_lsn[2], 3000);
    END_OF_CASE;
}

// Test KeyValueCache::Free()
TEST_F(LogBlockTests, test_KeyValueCache_Free) {
    gaiadb::common::MemArena arena;
    KeyValueCache<uint64_t, uint32_t> cache(&arena);

    cache.Init(2);
    cache.Add(10, 100);
    cache.Add(11, 110);
    cache.set_init();

    ASSERT_EQ(cache.pos(), 2);
    ASSERT_TRUE(cache.is_init());
    ASSERT_NE(cache.buf_size(), 0);

    cache.Free();

    ASSERT_EQ(cache.size(), 0);
    ASSERT_EQ(cache.pos(), 0);
    ASSERT_EQ(cache.buf(), nullptr);
    ASSERT_EQ(cache.buf_size(), 0);
    ASSERT_FALSE(cache.is_init());
    END_OF_CASE;
}

// The log block quota accounting covers the payload plus the per-record overhead
// (see calc_log_block_quota_size), and the counter starts at zero.
TEST_F(LogBlockTests, test_quota_size) {
    const size_t buf_size = 4096;
    const uint32_t rec_cnt = 7;
    const size_t expected = buf_size + sizeof(LogBlock)
            + (sizeof(LogRecord) + sizeof(PagePtr)) * rec_cnt;
    ASSERT_EQ(calc_log_block_quota_size(buf_size, rec_cnt), expected);

    // a block without payload only carries its own footprint
    ASSERT_EQ(calc_log_block_quota_size(0, 0), sizeof(LogBlock));

    LogBlockPtr log = create_log_block(11);
    ASSERT_EQ(log->quota_size, 0);
    log->quota_size = calc_log_block_quota_size(buf_size, rec_cnt);
    ASSERT_EQ(log->quota_size, expected);
    END_OF_CASE;
}

}
}
