/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_compute_node.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class UpdateComputeNode : public Command {
public:
    UpdateComputeNode() {
        SetName("update-compute-node");
        SetDesc("update an existing compute node meta");
        SetDescCn("更新计算节点的元数据信息");

        AddPsmClusterOption();
        AddRequiredArgOption("addr", &_long_opt_val, kOptMax + 1, "the compute node endpoint", kip_port);
        AddRequiredArgOption("is-primary", &_long_opt_val, kOptMax + 2,
                "set or cancel the primary attribute:(1/0)", kenum);

        AddExample("--manager-address \"bns://xxx\" --addr 127.0.0.1:1999 --is-primary 0");
    }
    virtual ~UpdateComputeNode() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _addr = opt;
                break;
            case kOptMax + 2:
                _is_primary.Set(!!std::strtol(opt, NULL, 10));
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::AckResponse& rsp);

private:
    std::string _manager_address {};
    std::string _addr {};
    VarOptional<bool> _is_primary;
};

}
}
