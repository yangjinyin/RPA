/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/table_format.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/table_format.h"

namespace psvr {
namespace gaia {

int Table::FindSortColumn(const std::string& col_name) const {
    for (size_t i = 0; i < _rows.size(); ++i) {
        if (_rows[i].line_cnt() > 0 &&
                row_type_to_string(_rows[i].GetLine(0)) == col_name) {
            return static_cast<int>(i);
        }
    }
    return -1;
}

void Table::Display() {
    if (_rows.empty()) {
        return;
    }

    const auto& sort_cfg = GetTableSortConfig();
    size_t line_cnt = _rows[0].line_cnt();

    // Capture _has_title before the display loop modifies it.
    // It indicates that _rows[i].GetLine(0) holds the column header names.
    bool has_named_cols = _has_title;

    // Build sorted index array for data rows (line 0 = header, skip it).
    std::vector<size_t> data_indices;
    if (sort_cfg.enabled && has_named_cols && line_cnt > 1) {
        int sort_col = FindSortColumn(sort_cfg.col_name);
        if (sort_col >= 0) {
            data_indices.resize(line_cnt - 1);
            std::iota(data_indices.begin(), data_indices.end(), 1);
            const auto& sort_row = _rows[sort_col];
            std::stable_sort(data_indices.begin(), data_indices.end(),
                [&](size_t idx_a, size_t idx_b) {
                    int cmp = compare_row_values(
                        sort_row.GetLine(idx_a), sort_row.GetLine(idx_b));
                    return sort_cfg.ascending ? cmp < 0 : cmp > 0;
                });
        }
    }

    DrawHeaderOrFooter(std::cout);
    for (size_t i = 0; i < line_cnt; ++i) {
        // Line 0 is always the header; data lines use sorted indices when available.
        size_t line_idx = (i == 0 || data_indices.empty()) ? i : data_indices[i - 1];
        for (auto& row : _rows) {
            DrawSplit(std::cout);
            std::cout << " ";
            std::cout << std::left << std::setw(row.width());
            row.Display(std::cout, line_idx);
            std::cout << " ";
        }
        DrawSplit(std::cout);
        std::cout << std::endl;
        if (_has_title) {
            DrawHeaderOrFooter(std::cout);
            _has_title = false;
        }
    }
    DrawHeaderOrFooter(std::cout);
}

}  // namespace gaia
}  // namespace psvr
