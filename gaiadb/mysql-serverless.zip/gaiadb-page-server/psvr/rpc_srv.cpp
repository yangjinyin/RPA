/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/rpc_srv.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/config.h"
#include "psvr/control_context.h"
#include "psvr/rpc_srv.h"
#include "psvr/version.h"

namespace psvr {

#define CHECK_ZONE()        \
do {    \
    if (request->has_zone() != control->dbd_zone()->has_zone()) {   \
        response->set_refresh_zone(true);   \
    } else if (request->has_zone() && control->dbd_zone()->has_zone()) {    \
        std::string region; \
        std::string available_zone; \
        if (control->dbd_zone()->Get(&region, &available_zone)) { \
            if (region != request->zone().region() \
                    || available_zone != request->zone().available_zone()) { \
                response->set_refresh_zone(true); \
                response->mutable_zone()->set_region(region); \
                response->mutable_zone()->set_available_zone(available_zone); \
            } \
        } else { \
            LOG_EVERY_SECOND(WARNING) << "get node zone fail"; \
        } \
    } \
} while(0)

#define rpc_define_control_or_return_invalid()  \
    bool is_multi_type = false; \
    ControlPtr control = check_rpc_work(_server, &is_multi_type);   \
    while (!control || control->stopped()) { \
        brpc::ClosureGuard closure_guard(done); \
        cntl->SetFailed("server will stopped");  \
        return; \
    }

static ControlPtr check_rpc_work(RPCServerWeakPtr server, bool* is_multi_type) {
    RPCServerPtr owner = server.lock();
    if (owner) {
        *is_multi_type = owner->multi_type();
        return owner->control();
    }
    return nullptr;
}

bool RPCServer::Init() {
    _rpc_server.reset(new baidu::rpc::Server());
    _health_impl.reset(new HealthImpl(weak_this()));
    _rbio_impl.reset(new RbioServiceImpl(weak_this()));
    _query_impl.reset(new QueryServiceImpl(weak_this()));
    _manager_impl.reset(new ManagerServiceImpl(weak_this()));

    if (_rpc_server->AddService(_rbio_impl.get(), baidu::rpc::SERVER_DOESNT_OWN_SERVICE)) {
        LOG(ERROR) << "fail to add rbio service to rpc server, exit!";
        return false;
    }

    if (_rpc_server->AddService(_query_impl.get(), baidu::rpc::SERVER_DOESNT_OWN_SERVICE)) {
        LOG(ERROR) << "fail to add query service to rpc server, exit!";
        return false;
    }

    if (_rpc_server->AddService(_manager_impl.get(), baidu::rpc::SERVER_DOESNT_OWN_SERVICE)) {
        LOG(ERROR) << "fail to add manager service to rpc server, exit!";
        return false;
    }

    _rpc_server->set_version(get_version());
    LOG(NOTICE) << "success to init page server rpc server.";
    return true;
}

bool RPCServer::Start() {
    baidu::rpc::ServerOptions options;
    options.use_rdma = FLAGS_enable_server_rdma;
    options.num_threads = FLAGS_psvr_bthread_num;
    options.idle_timeout_sec = -1;
    options.health_reporter = _health_impl.get();

    uint32_t retry_n = 0;
    while (true) {
        if (_rpc_server->Start(FLAGS_psvr_rbio_server_port, &options) == 0) {
            break;
        }
        if (++retry_n >= 20) {  // 4s
            LOG(ERROR) << "fail to start page server rpc server,"
                << " addr:[" << control()->myself()
                << "] use_rdma:[" << FLAGS_enable_server_rdma
                << "]";
            return false;
        }
        sleep_for(millisecond2microseconds(200ul));
    }

    LOG(NOTICE) << "success to start page server rpc server,"
        << " addr:[" << control()->myself()
        << "] use_rdma:[" << FLAGS_enable_server_rdma
        << "]";
    return true;
}

void RPCServer::Stop(bool join) {
    if (_rpc_server) {
        _rpc_server->Stop(0);
        if (join) {
            Join();
        }
    }
    LOG(NOTICE) << "stop page server rpc server done,"
        << " use_rdma:[" << FLAGS_enable_server_rdma
        << "]";
}

void RPCServer::Join() {
    if (_rpc_server) {
        _rpc_server->Join();
    }
}

void HealthImpl::GenerateReport(baidu::rpc::Controller* cntl,
        google::protobuf::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    cntl->http_response().set_content_type("text/plain");
    std::string body = std::string("OK") +
        "\nSegment count:" + std::to_string(control->segment_manager()->segment_size()) +
        "\nCluster count:" + std::to_string(control->segment_manager()->GetClusterSize()) +
        "\nPsminfo count:" + std::to_string(control->segment_manager()->GetPsmInfoSize()) +
        "\n";

    cntl->response_attachment().append(body);
}

void RbioServiceImpl::WritePhysicalPages(ggpb::RpcController* cntl,
        const pspb::WritePageRequest *request, pspb::WritePageResponse *response,
        ggpb::Closure *done) {
    const int64_t begin_time = base::cpuwide_time_us();
    rpc_define_control_or_return_invalid();
    response->set_request_id(request->request_id());
    pspb::WritePageResponse_Error code = pspb::WritePageResponse::INVALID;
    if (is_multi_type) {
        if (!request->has_cluster_id() || !request->has_segment_id()) {
            code = pspb::WritePageResponse::INVALID;
        } else {
            SegmentPtr segment = control->segment_manager()->GetSegment(
                    request->cluster_id(), request->segment_id());
            if (segment && segment->is_active() && segment->is_init()) {
                control->rbio_manager()->Dispatch(segment, request, response, done, begin_time);
                return;
            } else {
                code = pspb::WritePageResponse::INVALID;
            }
        }
    } else {
        SegmentPtr segment = control->one_segment();
        if (segment && segment->is_active() && segment->is_init()) {
            if (request->has_segment_id()) {
                if (segment->segment_id() == request->segment_id()) {
                    control->rbio_manager()->Dispatch(segment, request, response, done, begin_time);
                    return;
                }
                code = pspb::WritePageResponse::INVALID;
            } else {
                control->rbio_manager()->Dispatch(segment, request, response, done, begin_time);
                return;
            }
        } else {
            code = pspb::WritePageResponse::INVALID;
        }
    }

    PSVR_LOG(WARNING, request->request_id()) << "write page failed, "
            << pspb::WritePageResponse::Error_Name(code)
            << " request_id:[" << request->request_id()
            << "] request:[" << pb2jsonstr(*request)
            << "]";
    baidu::rpc::ClosureGuard done_guard(done);
    response->mutable_status()->set_code(code);
    response->mutable_status()->set_msg("write failed, please check and try again");
}

void RbioServiceImpl::Rbio(ggpb::RpcController* cntl,
        const pspb::RbioRequest* request,
        pspb::RbioResponse* response,
        ggpb::Closure* done) {
    const int64_t begin_time = base::cpuwide_time_us();
    rpc_define_control_or_return_invalid();
    pspb::RbioResponse_Error s = pspb::RbioResponse::RBIO_TIMEOUT;

    if (FLAGS_psvr_mock_rbio_timeout && base::RandInt(0, 100) < 10) {
        bthread_usleep(FLAGS_psvr_mock_rbio_sleep_us);
        baidu::rpc::ClosureGuard done_guard(done);
        response->set_requestid(request->requestid());
        response->set_errcode(handle_rbio_error_code(s, pspb::RbioResponse::RBIO_TIMEOUT));
        return;
    }

    CHECK_ZONE();
    if (is_multi_type) {
        if (!request->has_cluster_id() || !request->has_segment_id()) {
            s = pspb::RbioResponse::RBIO_INVALID;
        } else {
            SegmentPtr segment = control->segment_manager()->GetSegment(request->cluster_id(),
                    request->segment_id());
            if (segment) {
                if (segment->is_active() && segment->is_init()) {
                    control->rbio_manager()->Dispatch(segment, cntl, request, response, done, begin_time);
                    return;
                } else {
                    s = pspb::RbioResponse::RBIO_SEGMENT_INACTIVE;
                }
            } else {
                s = pspb::RbioResponse::RBIO_SEGMENT_NOT_EXIST;
            }
        }
    } else {
        SegmentPtr segment = control->one_segment();
        if (segment && segment->is_active() && segment->is_init()) {
            if (request->has_segment_id()) {
                if (segment->segment_id() == request->segment_id()) {
                    control->rbio_manager()->Dispatch(segment, cntl, request, response, done, begin_time);
                    return;
                }
                s = pspb::RbioResponse::RBIO_SEGMENT_NOT_EXIST;
            } else {
                control->rbio_manager()->Dispatch(segment, cntl, request, response, done, begin_time);
                return;
            }
        } else {
            s = pspb::RbioResponse::RBIO_SEGMENT_INACTIVE;
        }
    }

    auto brpc_cntl = static_cast<brpc::Controller*>(cntl);
    PSVR_LOG_EVERY_SECOND(WARNING, request->requestid()) << "rbio failed,"
        <<" error:[" << pspb::RbioResponse::Error_Name(s)
        << "] request_id:[" << request->requestid()
        << "] remote:[" << brpc_cntl->remote_side()
        << "] request:[" << pb2jsonstr(*request)
        << "]";
    baidu::rpc::ClosureGuard done_guard(done);
    auto max_error_code = !request->has_max_error_code()
        ? kRbioMaxErrorCodeOld : static_cast<pspb::RbioResponse_Error>(request->max_error_code());
    response->set_requestid(request->requestid());
    response->set_errcode(handle_rbio_error_code(s, max_error_code));
}

void QueryServiceImpl::GetServerStatus(ggpb::RpcController* cntl,
        const pspb::GetStatusRequest* request,
        pspb::GetStatusResponse* response,
        ggpb::Closure *done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    SegmentPtr segment = nullptr;
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS, "not found segment");

    if (is_multi_type) {
        if (request->has_cluster_id() && request->has_segment_id()) {
            segment = control->segment_manager()->GetSegment(request->cluster_id(),
                    request->segment_id());
        } else {
            PSVR_LOG(WARNING, log_id) << "invalid request, miss argmuents,"
                << " request:[" << pb2jsonstr(*request)
                << "]";
            set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                    "invalid request, miss argmuents");
        }
    } else {
        segment = control->one_segment();
        if (request->has_cluster_id() || request->has_segment_id()) {
            if (segment && segment->cluster_id() != request->cluster_id()) {
                segment = nullptr;
                PSVR_LOG(WARNING, log_id) << "invalid request, mismatch cluster,"
                    << " request:[" << pb2jsonstr(*request)
                    << "]";
            }
            if (segment && segment->segment_id() != request->segment_id()) {
                segment = nullptr;
                PSVR_LOG(WARNING, log_id) << "invalid request, mismatch segment id,"
                    << " request:[" << pb2jsonstr(*request)
                    << "]";
            }
        }
    }

    if (!segment) {
        response->set_fetch_lsn(0);
        response->set_shred_lsn(0);
        response->set_apply_lsn(0);
        response->set_cn_lowest_lsn(0);
        response->set_checkpoint_lsn(0);
        return;
    }

    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "success");

    response->set_fetch_lsn(segment->fetch_lsn());
    response->set_shred_lsn(0);
    response->set_apply_lsn(segment->parse_lsn());
    response->set_append_lsn(segment->append_lsn());
    response->set_seg_lowest_gc_ls(segment->seg_lowest_gc_lsn());
    response->set_checkpoint_lsn(segment->gc_lsn());
    response->set_append_db_size(segment->append_db_size());
    response->set_append_checkpoint_lsn(segment->append_gc_lsn());
    response->set_cn_lowest_lsn(segment->GetClusterCnLowestLsn());
    response->set_db_checkpoint_lsn(segment->GetAppendDBCheckPointLsn());
}

void QueryServiceImpl::MultiGetServerStatus(ggpb::RpcController* cntl,
        const pspb::MultiGetStatusRequest* request,
        pspb::MultiGetStatusResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!is_multi_type) {
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "page server not running in multi mode");
        return;
    }

    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");
    response->set_topology_zone(FLAGS_psvr_topology_zone);
    response->set_topology_to_offline(FLAGS_psvr_topology_to_offline);

#ifdef __PSVR_COMMIT__
    response->set_git_commit(__PSVR_COMMIT__);
#endif
#ifdef __PSVR_VERSION__
    response->set_pkg_version(__PSVR_VERSION__);
#endif

    const bool show_stages = request->has_show_stages() && request->show_stages();

    SegmentIteratorFn fn = [this, response, &show_stages] (SegmentPtr seg) -> void {
        auto* rsp = response->add_segments();
        rsp->set_cluster_id(seg->cluster_id());
        rsp->set_segment_id(seg->segment_id());
        set_rpc_status(rsp->mutable_status(), pspb::Status::SUCCESS, "ok");
        rsp->set_fetch_lsn(seg->fetch_lsn());
        rsp->set_apply_lsn(seg->parse_lsn());
        rsp->set_checkpoint_lsn(seg->gc_lsn());
        rsp->set_cn_lowest_lsn(seg->GetClusterCnLowestLsn());
        rsp->set_store_id(seg->store_id());
        rsp->set_segment_size(seg->segment_size());
        rsp->set_segment_physical_size(seg->segment_physical_size());
        rsp->set_segment_status(seg->status2str());
        rsp->set_manager_address(seg->GetPsmInfo()->address());
        rsp->set_init_flag(seg->initflag2str());
        rsp->set_in_recovery(!seg->recovery_status_is_finish());
        rsp->set_version(seg->version());
        rsp->set_replica_id(seg->replica_id());
        // get rebalance from
        std::string rebalance_from {};
        uint64_t rebalance_version = 0;
        if (seg->GetRebalanceNode(&rebalance_from, &rebalance_version)) {
            rsp->set_rebalance_from(rebalance_from);
            rsp->set_rebalance_version(rebalance_version);
        }
        rsp->set_init_lsn_ok(!seg->is_invalid_start_lsn());
        rsp->set_compress_num(seg->stat_compress().compress_times.load(std::memory_order_relaxed));
        rsp->set_append_lsn(seg->append_lsn());
        rsp->set_append_db_size(seg->append_db_size());
        rsp->set_append_checkpoint_lsn(seg->append_gc_lsn());
        rsp->set_seg_lowest_gc_ls(seg->seg_lowest_gc_lsn());
        if (show_stages) {
            seg->get_stage_infos(rsp->mutable_stage_infos());
        }
        rsp->set_db_checkpoint_lsn(seg->GetAppendDBCheckPointLsn());
    };

    auto segment_manager = control->segment_manager();
    if (request->segments_size()) {
        for (int32_t i = 0; i < request->segments_size(); ++i) {
            const auto& req = request->segments(i);
            if (req.has_segment_id()) {
                SegmentPtr segment = segment_manager->GetSegment(req.cluster_id(),
                        req.segment_id());
                if (!segment) {
                    auto* rsp = response->add_segments();
                    set_rpc_status(rsp->mutable_status(), pspb::Status::NOT_EXISTS,
                            "segment:%s/%u not found",
                            req.cluster_id().c_str(), req.segment_id());
                    rsp->set_cluster_id(req.cluster_id());
                    rsp->set_segment_id(req.segment_id());
                } else {
                    fn (segment);
                }
            } else {
                uint32_t n = segment_manager->GetClusterSegments(req.cluster_id(), fn);
                if (n == 0) {
                    auto* rsp = response->add_segments();
                    set_rpc_status(rsp->mutable_status(), pspb::Status::NOT_EXISTS,
                            "cluster:%s not found segments",
                            req.cluster_id().c_str());
                    rsp->set_cluster_id(req.cluster_id());
                }
            }
        }
    } else {
        if (!request->has_only_get_store_info()
                || !request->only_get_store_info()) {
            segment_manager->GetAllSegments(fn);
        }
    }

    if ((request->has_get_store_info() && request->get_store_info())
            || (request->has_only_get_store_info() && request->only_get_store_info())) {
        StoreIteratorFn store_fn = [&response, control](StorePtr store) {
            auto* rsp = response->add_stores();
            store->GetStoreInfo(rsp);
            rsp->set_compress_rate(control->compressor()->GetStoreCompressRate(store->id()));
            return true;
        };
        control->store_manager()->GetStores(store_fn);
    }
}

void QueryServiceImpl::ReadPhysicalPage(ggpb::RpcController* cntl,
        const pspb::ReadPageRequest* request,
        pspb::ReadPageResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    SegmentPtr segment = control->one_segment();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    CHECK_ZONE();
    if (is_multi_type) {
        if (!request->has_cluster_id() || !request->has_segment_id()) {
            baidu::rpc::ClosureGuard done_guard(done);
            set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                    "invalid request in multi mode");
            return;
        }
        segment = control->segment_manager()->GetSegment(request->cluster_id(),
                request->segment_id());
    }

    if (!segment) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }
    if (segment->is_active() && segment->is_init()) {
        control->recoverer()->Dispatch(segment,
                dynamic_cast<brpc::Controller*>(cntl), request, response, done);
    } else {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "segment:%s/%u status invalid",
                segment->cluster_id().c_str(), segment->segment_id());
    }
}

void QueryServiceImpl::Read(ggpb::RpcController* cntl,
        const pspb::ReadRequest* request,
        pspb::ReadResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    SegmentPtr segment = control->one_segment();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (is_multi_type) {
        segment = control->segment_manager()->GetSegment(request->cluster_id(),
                request->segment_id());
    }

    if (!segment) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    if (segment->is_active() && segment->is_init()) {
        control->recoverer()->Dispatch(segment,
                dynamic_cast<brpc::Controller*>(cntl), request, response, done);
    } else {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "segment:%s/%u status invalid",
                segment->cluster_id().c_str(), segment->segment_id());
    }
}

void QueryServiceImpl::GetRedoRecLog(ggpb::RpcController* cntl,
        const pspb::GetRedoRecLogRequest* request,
        pspb::GetRedoRecLogResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    SegmentPtr segment = control->one_segment();

    if (is_multi_type) {
        segment = control->segment_manager()->GetSegment(request->cluster_id(),
                request->segment_id());
    }

    if (!segment) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    if (segment->is_active() && segment->is_init()) {
        control->recoverer()->Dispatch(segment,
                dynamic_cast<brpc::Controller*>(cntl), request, response, done);
    } else {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "segment:%s/%u status invalid",
                segment->cluster_id().c_str(), segment->segment_id());
    }
}

void QueryServiceImpl::GetRecoverInfo(ggpb::RpcController* cntl,
        const pspb::GetRecoverInfoRequest* request,
        pspb::GetRecoverInfoResponse* response,
        ggpb::Closure *done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    SegmentPtr segment = control->one_segment();
    if (is_multi_type) {
        if (!request->has_cluster_id() || !request->has_segment_id()) {
            set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                    "invalid request in multi mode");
            return;
        }
        segment = control->segment_manager()->GetSegment(request->cluster_id(),
                request->segment_id());
    } else {
        if (request->has_cluster_id() || request->has_segment_id()) {
            if (segment && segment->cluster_id() != request->cluster_id()) {
                segment = nullptr;
            }
            if (segment && segment->segment_id() != request->segment_id()) {
                segment = nullptr;
            }
        }
    }

    if (!segment) {
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    if (!segment->is_active() || !segment->is_init()) {
        set_rpc_status(response->mutable_status(), pspb::Status::ERROR,
                "segment:%s/%u not active, wait it",
                segment->cluster_id().c_str(), segment->segment_id());
        return;
    }

    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "success");

    segment->GetRecoveryInfo(response);
}

void QueryServiceImpl::MultiGetRecoverInfo(ggpb::RpcController* cntl,
        const pspb::MultiGetRecoverInfoRequest* request,
        pspb::MultiGetRecoverInfoResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!is_multi_type) {
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "page server not running in multi mode");
        return;
    }

    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");

    SegmentIteratorFn fn = [this, response] (SegmentPtr seg) -> void {
        auto* rsp = response->add_segments();
        if (seg->is_active()
              && seg->is_init()) {
            set_rpc_status(rsp->mutable_status(), pspb::Status::SUCCESS, "ok");
            seg->GetRecoveryInfo(rsp);
        } else {
            set_rpc_status(rsp->mutable_status(), pspb::Status::INVALID,
                    "segment:%s/%u status invalid",
                    seg->cluster_id().c_str(), seg->segment_id());
            rsp->set_cluster_id(seg->cluster_id());
            rsp->set_segment_id(seg->segment_id());
        }
    };

    auto segment_manager = control->segment_manager();
    if (request->segments_size()) {
        for (int32_t i = 0; i < request->segments_size(); ++i) {
            const auto& req = request->segments(i);
            if (req.has_segment_id()) {
                SegmentPtr segment = segment_manager->GetSegment(req.cluster_id(),
                        req.segment_id());
                if (!segment) {
                    auto* rsp = response->add_segments();
                    set_rpc_status(rsp->mutable_status(), pspb::Status::NOT_EXISTS,
                            "segment:%s/%u not found",
                            req.cluster_id().c_str(), req.segment_id());
                    rsp->set_cluster_id(req.cluster_id());
                    rsp->set_segment_id(req.segment_id());
                } else {
                    fn (segment);
                }
            } else {
                uint32_t n = segment_manager->GetClusterSegments(req.cluster_id(), fn);
                if (n == 0) {
                    auto* rsp = response->add_segments();
                    set_rpc_status(rsp->mutable_status(), pspb::Status::NOT_EXISTS,
                            "cluster:%s not found segments",
                            req.cluster_id().c_str());
                    rsp->set_cluster_id(req.cluster_id());
                }
            }
        }
    } else {
        uint32_t n = segment_manager->GetAllSegments(fn);
        if (n == 0) {
            response->mutable_status()->set_msg("not found segments");
        }
    }
}

void QueryServiceImpl::ListRecoveryInfo(ggpb::RpcController* cntl,
        const pspb::ListRecoveryInfoRequest* request,
        pspb::ListRecoveryInfoResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");
    control->recoverer()->GetRecoveryInfo(response);
}

void QueryServiceImpl::ListPsmInfo(ggpb::RpcController* cntl,
        const pspb::ListPsmInfoRequest* request,
        pspb::ListPsmInfoResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");

    if (!request->has_addr()) {
        control->segment_manager()->GetPsmInfos(response);
    } else {
        PsmInfoPtr psm_info = control->segment_manager()->GetPsmInfo(request->addr());
        if (!psm_info) {
            set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                    "psm addr:%s not found", request->addr().c_str());
            return;
        }
        auto pb = response->add_psm_infos();
        pb->set_addr(request->addr());
        std::vector<base::EndPoint> nodes;
        if (psm_info->GetOrRefreshNodes(&nodes)) {
            for (auto& n : nodes) {
                pb->add_nodes(base::endpoint2str(n).c_str());
            }
        }
    }
}

void QueryServiceImpl::GetZone(ggpb::RpcController* cntl,
        const pspb::GetZoneRequest* request,
        pspb::GetZoneResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);
    if (control->dbd_zone()->has_zone()) {
        std::string region;
        std::string available_zone;
        if (control->dbd_zone()->Get(&region, &available_zone)) {
            response->mutable_zone()->set_region(region);
            response->mutable_zone()->set_available_zone(available_zone);
            set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");
        } else {
            set_rpc_status(response->mutable_status(), pspb::Status::ERROR, "get zone fail");
        }
    } else {
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS, "not set zone");
    }
}

void QueryServiceImpl::GetCompressConfig(ggpb::RpcController* cntl,
        const pspb::GetCompressConfigRequest* request,
        pspb::GetCompressConfigResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    uint32_t n = 0;
    if (!request->has_segment_id()) {
        n = control->segment_manager()->GetClusterSegments(request->cluster_id(),
                [response](SegmentPtr seg) {
                    auto pb = response->add_segments();
                    pb->set_cluster_id(seg->cluster_id());
                    pb->set_segment_id(seg->segment_id());
                    seg->GetCompressConfig(pb->mutable_compress_cfg());
                });
    } else {
        SegmentPtr seg = control->segment_manager()->GetSegment(request->cluster_id(), request->segment_id());
        if (seg) {
            auto pb = response->add_segments();
            pb->set_cluster_id(seg->cluster_id());
            pb->set_segment_id(seg->segment_id());
            seg->GetCompressConfig(pb->mutable_compress_cfg());
            ++n;
        }
    }
    if (!n) {
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
    } else {
        set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");
    }
}

void QueryServiceImpl::ListCompressSegment(ggpb::RpcController* cntl,
        const pspb::ListCompressSegmentRequest* request,
        pspb::ListCompressSegmentResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");

    control->compressor()->GetTasks(response);
}

void QueryServiceImpl::ListClusterStatus(ggpb::RpcController* cntl,
        const pspb::ListClusterStatusRequest* request,
        pspb::ListClusterStatusResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    //int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();

    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");

#define SortClusterBy(name, pb_name)                                 \
    std::vector<std::string> clusters;                      \
    control->segment_manager()->GetAllClusters(&clusters);  \
    std::vector<std::pair<std::string, uint64_t>> _cluster_item_size; \
    auto n = clusters.size();                               \
    _cluster_item_size.reserve(n);                          \
    for (auto& it : clusters) {                             \
        auto cluster = control->segment_manager()->GetCluster(it);    \
        if (cluster) {                                      \
            _cluster_item_size.emplace_back(std::make_pair(it, cluster->statistic()->name.get_value()));  \
        }                                                   \
    }                                                       \
    std::sort(_cluster_item_size.begin(), _cluster_item_size.end(),   \
            [](const std::pair<std::string, uint32_t>& lhs, const std::pair<std::string, uint32_t>& rhs){ \
                return lhs.second > rhs.second;             \
            });                                             \
    for (auto& it : _cluster_item_size) {                   \
        auto pb = response->add_clusters();                 \
        pb->set_cluster_id(it.first);                       \
        pb->set_##pb_name(static_cast<uint32_t>(it.second));        \
    }

    if (request->has_sort_segment_num()) {
        control->segment_manager()->ListAllClusterSegmentSize(response);
    } else if (request->has_sort_redo_size()) {
        SortClusterBy(stat_redo_size_count, redo_size);
    } else if (request->has_sort_rbio_size()) {
        SortClusterBy(stat_rbio_size_count, rbio_size);
    } else if (request->has_sort_write_size()) {
        SortClusterBy(stat_write_size_count, write_size);
    } else {
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID, "not found sort key");
    }
}

void ManagerServiceImpl::SetRecoverInfo(ggpb::RpcController* cntl,
        const pspb::SetRecoverInfoRequest* request,
        pspb::SetRecoverInfoResponse* response,
        ggpb::Closure *done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    SegmentPtr segment = control->one_segment();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (is_multi_type) {
        if (!request->has_cluster_id() || !request->has_segment_id()) {
            set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                    "invalid request in multi mode");
            return;
        }
        segment = control->segment_manager()->GetSegment(request->cluster_id(),
                request->segment_id());
    } else {
        if (request->has_cluster_id() || request->has_segment_id()) {
            if (segment && segment->cluster_id() != request->cluster_id()) {
                segment = nullptr;
            }
            if (segment && segment->segment_id() != request->segment_id()) {
                segment = nullptr;
            }
        }
    }

    if (!segment) {
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    if (!segment->is_active() || !segment->is_init()) {
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "segment:%s/%u status invalid",
                segment->cluster_id().c_str(), segment->segment_id());
        return;
    }

    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");
    if (request->recover_enable()) {
        bool ret = control->recoverer()->Dispatch(segment,
                request->has_recover_force() ? request->recover_force() : false, true TRACE_FILE_LINE_CC);
        if (ret) {
            response->mutable_status()->set_msg("start ok");
        } else {
            response->mutable_status()->set_msg("last is running");
        }
    } else {
        segment->TurnOffRecovery();
        response->mutable_status()->set_msg("stop ok");
    }
    bool status = false, is_force = false;
    segment->GetRecoveryStatus(&status, &is_force);
    response->set_recover_enable(status);
    response->set_recover_force(is_force);
}

void ManagerServiceImpl::SetRecoverPrior(ggpb::RpcController* cntl,
        const pspb::SetRecoverPriorRequest* request,
        pspb::SetRecoverPriorResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    SegmentPtr segment = control->one_segment();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!is_multi_type) {
        set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "not need to set prior");
        return;
    }

    if (!request->has_cluster_id() || !request->has_segment_id()) {
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "invalid request in multi mode");
        return;
    }

    segment = control->segment_manager()->GetSegment(request->cluster_id(),
            request->segment_id());

    if (!segment) {
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    if (!segment->is_active() || !segment->is_init()) {
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "segment:%s/%u status invalid",
                segment->cluster_id().c_str(), segment->segment_id());
        return;
    }

    control->recoverer()->SetPriorNum(segment, request->prior_num());
    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");
}

void ManagerServiceImpl::MultiSetRecoverInfo(ggpb::RpcController* cntl,
        const pspb::MultiSetRecoverInfoRequest* request,
        pspb::MultiSetRecoverInfoResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!is_multi_type) {
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "page server not running in multi mode");
        return;
    }

    if (!request->segments_size()) {
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "not specify segments recovery info");
        return;
    }

    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");

    auto fn = [this, control, response] (SegmentPtr seg,
            const pspb::MultiSetRecoverInfoRequest::Segment& req) -> void {
        auto* rsp = response->add_segments();
        rsp->set_cluster_id(req.cluster_id());
        rsp->set_segment_id(req.segment_id());
        if (!seg->is_active() || !seg->is_init()) {
            set_rpc_status(rsp->mutable_status(), pspb::Status::INVALID,
                    "segment:%s/%u status invalid",
                    seg->cluster_id().c_str(), seg->segment_id());
            return;
        }
        set_rpc_status(rsp->mutable_status(), pspb::Status::SUCCESS, "ok");
        if (req.recover_enable()) {
            bool ret = control->recoverer()->Dispatch(seg,
                    req.has_recover_force() ? req.recover_force() : false, true TRACE_FILE_LINE_CC);
            if (ret) {
                rsp->mutable_status()->set_msg("start ok");
            } else {
                rsp->mutable_status()->set_msg("last is running");
            }
        } else {
            seg->TurnOffRecovery();
            rsp->mutable_status()->set_msg("stop ok");
        }
        bool status = false, is_force = false;
        seg->GetRecoveryStatus(&status, &is_force);
        rsp->set_recover_enable(status);
        rsp->set_recover_force(is_force);
    };

    auto segment_manager = control->segment_manager();
    for (int32_t i = 0; i < request->segments_size(); ++i) {
        const auto& req = request->segments(i);
        if (req.has_segment_id()) {
            SegmentPtr segment = segment_manager->GetSegment(req.cluster_id(),
                    req.segment_id());
            if (!segment) {
                auto* rsp = response->add_segments();
                set_rpc_status(rsp->mutable_status(), pspb::Status::NOT_EXISTS,
                        "segment:%s/%u not found",
                        req.cluster_id().c_str(), req.segment_id());
                rsp->set_cluster_id(req.cluster_id());
                rsp->set_segment_id(req.segment_id());
            } else {
                fn (segment, req);
            }
        } else {
            SegmentIteratorFn cluster_fn = [&req, &fn] (SegmentPtr seg) {
                fn (seg, req);
            };
            uint32_t n = segment_manager->GetClusterSegments(req.cluster_id(), cluster_fn);
            if (n == 0) {
                auto* rsp = response->add_segments();
                set_rpc_status(rsp->mutable_status(), pspb::Status::NOT_EXISTS,
                        "cluster:%s not found segments",
                        req.cluster_id().c_str());
                rsp->set_cluster_id(req.cluster_id());
            }
        }
    }
}

void ManagerServiceImpl::ModifyManagerAddr(ggpb::RpcController* cntl,
        const pspb::ModifyManagerRequest* request,
        pspb::ModifyManagerResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    SegmentPtr segment = control->one_segment();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (is_multi_type) {
        if (!request->has_cluster_id() || !request->has_segment_id()) {
            baidu::rpc::ClosureGuard done_guard(done);
            set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                    "invalid request in multi mode");
            return;
        }
        segment = control->segment_manager()->GetSegment(request->cluster_id(),
                request->segment_id());
    } else {
        if (request->has_cluster_id() || request->has_segment_id()) {
            if (segment && segment->cluster_id() != request->cluster_id()) {
                segment = nullptr;
            }
            if (segment && segment->segment_id() != request->segment_id()) {
                segment = nullptr;
            }
        }
    }

    if (!segment) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    auto* ctx = new Control::Context(Control::Action::kModifySegmentManagerInfo,
            segment, request, response, done);
    ctx->log_id = log_id;
    control->Dispatch(ctx);
}

void ManagerServiceImpl::MultiModifyManager(ggpb::RpcController* cntl,
        const pspb::MultiModifyManagerRequest* request,
        pspb::MultiModifyManagerResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!is_multi_type) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "page server not running in multi mode");
        return;
    }
    if (request->segments_size() < 1) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "not specify segments info");
        return;
    }

    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");

    auto* ctx = new Control::Context(Control::Action::kMultiModifySegmentManagerInfo,
            nullptr, request, response, done);
    ctx->log_id = log_id;
    ctx->idx = 0;
    ctx->count = request->segments_size();
    control->Dispatch(ctx);
}

void ManagerServiceImpl::PreLoadSegment(ggpb::RpcController* cntl,
        const pspb::PreLoadSegmentRequest* request,
        pspb::PreLoadSegmentResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!is_multi_type) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "page server not running in multi mode");
        return;
    }
    auto* ctx = new Control::Context(Control::Action::kPreLoadSegment,
            nullptr, request, response, done);
    ctx->log_id = log_id;
    control->Dispatch(ctx);
}

void ManagerServiceImpl::LoadSegment(ggpb::RpcController* cntl,
        const pspb::LoadSegmentRequest* request,
        pspb::LoadSegmentResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!is_multi_type) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "page server not running in multi mode");
        return;
    }
    auto* ctx = new Control::Context(Control::Action::kLoadSegment,
            nullptr, request, response, done);
    ctx->log_id = log_id;
    control->Dispatch(ctx);
}

void ManagerServiceImpl::CreateSegment(ggpb::RpcController* cntl,
        const pspb::CreateSegmentRequest* request,
        pspb::CreateSegmentResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!is_multi_type) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "page server not running in multi mode");
        return;
    }
    auto* ctx = new Control::Context(Control::Action::kCreateSegment,
            nullptr, request, response, done);
    ctx->log_id = log_id;
    control->Dispatch(ctx);
}

void ManagerServiceImpl::DropSegment(ggpb::RpcController* cntl,
        const pspb::DropSegmentRequest* request,
        pspb::DropSegmentResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!is_multi_type) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "page server not running in multi mode");
        return;
    }
    auto* ctx = new Control::Context(Control::Action::kDropSegment,
            nullptr, request, response, done);
    ctx->log_id = log_id;
    control->Dispatch(ctx);
}

void ManagerServiceImpl::DisableStore(ggpb::RpcController* cntl,
        const pspb::DisableStoreRequest* request,
        pspb::DisableStoreResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!is_multi_type) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "page server not running in multi mode");
        return;
    }
    auto* ctx = new Control::Context(Control::Action::kDisableStore,
            nullptr, request, response, done);
    ctx->log_id = log_id;
    control->Dispatch(ctx);
}

void ManagerServiceImpl::UpdateStore(ggpb::RpcController* cntl,
        const pspb::UpdateStoreRequest* request,
        pspb::UpdateStoreResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!is_multi_type) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "page server not running in multi mode");
        return;
    }
    auto* ctx = new Control::Context(Control::Action::kUpdateStore,
            nullptr, request, response, done);
    ctx->log_id = log_id;
    control->Dispatch(ctx);
}

void ManagerServiceImpl::UpdateAllStore(ggpb::RpcController* cntl,
        const pspb::UpdateAllStoreRequest* request,
        pspb::UpdateAllStoreResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!is_multi_type) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "page server not running in multi mode");
        return;
    }
    auto* ctx = new Control::Context(Control::Action::kUpdateAllStore,
            nullptr, request, response, done);
    ctx->log_id = log_id;
    control->Dispatch(ctx);
}

void ManagerServiceImpl::SetZone(ggpb::RpcController* cntl,
        const pspb::SetZoneRequest* request,
        pspb::SetZoneResponse* response,
        ggpb::Closure* done){
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (request->zone().region().empty()
            || request->zone().available_zone().empty()) {
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "invalid zone, region:%s available_zone:%s",
                request->zone().region().c_str(), request->zone().available_zone().c_str());
        return;
    }

    std::string region;
    std::string available_zone;
    if (control->dbd_zone()->has_zone()
            && control->dbd_zone()->Get(&region, &available_zone)
            && region == request->zone().region()
            && available_zone == request->zone().available_zone()) {
        set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "set again");
        return;
    }

    if (control->dbd_zone()->Set(request->zone().region(),
                request->zone().available_zone())) {
        set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "set ok");
    } else {
        set_rpc_status(response->mutable_status(), pspb::Status::ERROR,
                "set zone fail, region:%s available_zone:%s",
                request->zone().region().c_str(), request->zone().available_zone().c_str());
    }
    LOG(NOTICE) << "set zone, log_id:[" << request->log_id()
        << "] region:["  << request->zone().region()
        << "] available_zone:["  << request->zone().available_zone()
        << "] " << response->status();
}

void ManagerServiceImpl::ClearZone(ggpb::RpcController* cntl,
        const pspb::ClearZoneRequest* request,
        pspb::ClearZoneResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    if (!control->dbd_zone()->has_zone()) {
        set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "not zone");
        return;
    }

    if (control->dbd_zone()->Clear()) {
        set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "clear ok");
    } else {
        set_rpc_status(response->mutable_status(), pspb::Status::ERROR, "clear zone fail");
    }
    LOG(NOTICE) << "clear zone, log_id:[" << request->log_id()
        << "] " << response->status();
}

void ManagerServiceImpl::ReopenSegment(ggpb::RpcController* cntl,
        const pspb::ReopenSegmentRequest* request,
        pspb::ReopenSegmentResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);
    SegmentPtr seg = control->segment_manager()->GetSegment(request->cluster_id(), request->segment_id());
    if (!seg) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    if (!seg->is_active()) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::INVALID,
                "segment:%s/%u is not active",
                seg->cluster_id().c_str(), seg->segment_id());
        return;
    }

    control->fetcher()->DoReopenSegment(seg TRACE_FILE_LINE_CC, request, response, done);
}

void ManagerServiceImpl::SetCompressConfig(ggpb::RpcController* cntl,
        const pspb::SetCompressConfigRequest* request,
        pspb::SetCompressConfigResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    uint32_t n = 0;
    if (!request->has_segment_id()) {
        n = control->segment_manager()->GetClusterSegments(request->cluster_id(),
                [request](SegmentPtr seg) {
                    seg->SetCompressConfig(request->compress_cfg());
                });
    } else {
        SegmentPtr seg = control->segment_manager()->GetSegment(request->cluster_id(), request->segment_id());
        if (seg) {
            seg->SetCompressConfig(request->compress_cfg());
            ++n;
        }
    }
    if (!n) {
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
    } else {
        set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");
        response->set_succ_cnt(n);
    }
}

void ManagerServiceImpl::AddCompressSegment(ggpb::RpcController* cntl,
        const pspb::AddCompressSegmentRequest* request,
        pspb::AddCompressSegmentResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    SegmentPtr segment = control->segment_manager()->GetSegment(request->cluster_id(), request->segment_id());
    if (!segment) {
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    const bool is_prior = request->has_is_prior() ? request->is_prior() : false;
    bool ret = control->compressor()->AddSegmentToCompressList(segment, is_prior);
    if (ret) {
        set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");
    } else {
        set_rpc_status(response->mutable_status(), pspb::Status::EXISTS,
                "segment:%s/%u exists", request->cluster_id().c_str(), request->segment_id());
    }
}

void ManagerServiceImpl::DropCompressSegment(ggpb::RpcController* cntl,
        const pspb::DropCompressSegmentRequest* request,
        pspb::DropCompressSegmentResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    SegmentPtr segment = control->segment_manager()->GetSegment(request->cluster_id(), request->segment_id());
    if (!segment) {
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    bool ret = control->compressor()->DropSegmentFromCompressList(segment);
    if (ret) {
        set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");
    } else {
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not exists in compress list",
                request->cluster_id().c_str(), request->segment_id());
    }
}

void ManagerServiceImpl::EnableClusterStat(ggpb::RpcController* cntl,
        const pspb::EnableClusterStatRequest* request,
        pspb::EnableClusterStatResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);
    ClusterPtr cluster = control->segment_manager()->GetCluster(request->cluster_id());
    if (!cluster) {
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "cluster:%s not exists", request->cluster_id().c_str());
        return;
    }

    bool ret = false;
    if (!request->prefix().empty()) {
        ret = cluster->EnableClusterStatistic(request->prefix());
    } else {
        ret = cluster->EnableClusterStatistic(request->cluster_id());
    }

    if (ret) {
        set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "enable ok");
    } else {
        set_rpc_status(response->mutable_status(), pspb::Status::EXISTS,
                "cluster:%s enable again", request->cluster_id().c_str());
    }
}

void ManagerServiceImpl::DisableClusterStat(ggpb::RpcController* cntl,
        const pspb::DisableClusterStatRequest* request,
        pspb::DisableClusterStatResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);
    ClusterPtr cluster = control->segment_manager()->GetCluster(request->cluster_id());
    if (!cluster) {
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "cluster:%s not exists", request->cluster_id().c_str());
        return;
    }

    if (cluster->DisableClusterStatistic()) {
        set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "disable ok");
    } else {
        set_rpc_status(response->mutable_status(), pspb::Status::EXISTS,
                "cluster:%s disable again", request->cluster_id().c_str());
    }
}

void ManagerServiceImpl::IgnoreSpaceRecords(ggpb::RpcController* cntl,
        const pspb::IgnoreSpaceRecordsRequest* request,
        pspb::IgnoreSpaceRecordsResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    baidu::rpc::ClosureGuard done_guard(done);
    ClusterPtr cluster = control->segment_manager()->GetCluster(request->cluster_id());
    if (!cluster) {
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "cluster:%s not exists", request->cluster_id().c_str());
        return;
    }

    set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");
    switch(request->op()) {
    case pspb::IgnoreSpaceRecordsRequest::ADD: {
        if (!request->has_segment_id()) {
            for (auto& id : request->space_ids()) {
                cluster->ignore_corrupt_info()->AddSpace(id);
            }
        } else {
            for (auto& id : request->space_ids()) {
                cluster->ignore_corrupt_info()->AddSegmentSpace(request->segment_id(), id);
            }
        }
    } break;
    case pspb::IgnoreSpaceRecordsRequest::REMOVE: {
        if (!request->has_segment_id()) {
            for (auto& id : request->space_ids()) {
                cluster->ignore_corrupt_info()->RemoveSpace(id);
            }
        } else {
            for (auto& id : request->space_ids()) {
                cluster->ignore_corrupt_info()->RemoveSegmentSpace(request->segment_id(), id);
            }
        }
    } break;
    case pspb::IgnoreSpaceRecordsRequest::CLEAR: {
        if (!request->has_segment_id()) {
            cluster->ignore_corrupt_info()->Clear();
        } else {
            cluster->ignore_corrupt_info()->ClearSegment(request->segment_id());
        }
    } break;
    case pspb::IgnoreSpaceRecordsRequest::SELECT: {
        std::set<gaia_apply::space_id_t> ids;
        if (!request->has_segment_id()) {
            cluster->ignore_corrupt_info()->List(&ids);
        } else {
            cluster->ignore_corrupt_info()->ListSegment(request->segment_id(), &ids);
        }
        gaia_apply::space_id_t* buf = new gaia_apply::space_id_t[ids.size()]();
        size_t idx = 0;
        for (auto& id : ids) {
            buf[idx++] = id;
        }
        auto bcntl = static_cast<brpc::Controller*>(cntl);
        bcntl->response_attachment().append(static_cast<void*>(buf), sizeof(gaia_apply::space_id_t) * idx);
    } break;
    default:
        break;
    }
    LOG(NOTICE) << "IgnoreSpaceRecords:" << pb2jsonstr(*request);
}

void ManagerServiceImpl::WritePage(ggpb::RpcController* cntl,
        const pspb::WritePhysicalPageRequest* request,
        pspb::WritePhysicalPageResponse* response,
        ggpb::Closure* done) {
    rpc_define_control_or_return_invalid();
    int64_t log_id = request->has_log_id() ? request->log_id() : get_log_id();
    response->set_log_id(log_id);

    SegmentPtr segment = control->segment_manager()->GetSegment(request->cluster_id(),
            request->segment_id());
    if (!segment) {
        baidu::rpc::ClosureGuard done_guard(done);
        set_rpc_status(response->mutable_status(), pspb::Status::NOT_EXISTS,
                "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    control->recoverer()->Dispatch(segment,
            dynamic_cast<brpc::Controller*>(cntl), request, response, done);
}

}
