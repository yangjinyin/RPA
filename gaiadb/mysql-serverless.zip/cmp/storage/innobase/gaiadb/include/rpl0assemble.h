/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file include/rpl0assemble.h
 Gaiadb redo log replication

 Created 10/12/2021 Hongyu Qiao
 *******************************************************/

#pragma once

#include "log0recv.h"
#include "log0types.h"
#include "trx0types.h"
#include "ut0lst.h"
#include "trx0purge.h"
#include "srv0start.h"

#include <gaiadb/utils/arena.h>
#include <gaiadb_utility.h>
#include <cstdint>
#include <shared_mutex>
#include <string>
#include <unordered_map>
#include <vector>
#include "sql/dd/cache/dictionary_client.h"

#define RPL_DATA_BLOCK_SIZE (MEM_MAX_ALLOC_IN_BUF - sizeof(record_data_t))

namespace rpl {

static constexpr uint64_t RPL_ASMB_BUCKETS = 2048;

using page_hash_t = uint64_t;

inline page_hash_t page_id_hash(page_id_t id) {
  uint64_t hash = (uint64_t)id.space();
  hash = hash << 32;
  hash += (uint64_t)id.page_no();
  return hash;
}

struct log_record_t {
 public:
  void copy_to_buffer(byte *buffer);

  using Node = UT_LIST_NODE_T(log_record_t);

  /** Log record type */
  mlog_id_t type;

  /** Log record body length in bytes */
  uint64_t len = 0;

  /** Start lsn of the log segment written by the mtr which generated
    this log record: NOTE that this is not necessarily the start lsn of
    this log record */
  lsn_t start_lsn = 0;

  /** End lsn of the log segment written by the mtr which generated
    this log record: NOTE that this is not necessarily the end LSN of
    this log record */
  lsn_t end_lsn = 0;

  lsn_t last_page_lsn = 0;
  ulint ibuf_entry_counter = 0;

  /** List node, list anchored in recv_addr_t */
  Node list_entry;

  /** log record body content */
  byte data[0];
};

struct page_records_t {
  using List = UT_LIST_BASE_NODE_T(log_record_t, list_entry);

  /** Space ID */
  space_id_t space;

  /** Page number */
  page_no_t page_no;

  uint64_t n_record = 0;

  /** List of log records for this page */
  List rec_list_head;
};

using Pages = std::unordered_map<page_hash_t, page_records_t *>;

enum class AssemblyState {
  ASSEMBLY_STATE_UNINITED = 0,
  ASSEMBLY_STATE_INITED,
  ASSEMBLY_STATE_PARSED,
  ASSEMBLY_STATE_PREPARED,
  ASSEMBLY_STATE_APPLIED,
};

std::ostream &operator<<(std::ostream &os, const AssemblyState &asmb_state);

enum class PagehashState {
  PAGE_HASH_STATE_UNAPPLIED,
  PAGE_HASH_STATE_APPLIED,
};

struct PageHash {
  Pages m_pages{};
  PagehashState state = PagehashState::PAGE_HASH_STATE_UNAPPLIED;
  gaiadb::common::Arena arena;
};

struct space_ddl_t {
  mlog_id_t type;
  space_id_t space_id;
  std::string name;
  std::string new_name;
  std::string new_path;

  space_ddl_t(mlog_id_t _type, space_id_t _space_id, std::string&& _name)
    : type(_type), space_id(_space_id),
    name(_name), new_name() {}
  space_ddl_t(mlog_id_t _type, space_id_t _space_id,
    std::string&& _name, std::string&& _new_name, std::string&& _new_path)
    : type(_type), space_id(_space_id),
    name(_name), new_name(_new_name), new_path(_new_path) {}
};

struct rpl_msg_t {
  uint8_t type{0};
  uint8_t flags{0};
  std::string payload;
};

struct RplAssembly {
  RplAssembly();
  ~RplAssembly();

 public:
  using TrxIds = std::vector<trx_id_t>;
  bool init(uint64_t epoch, uint64_t index);
  bool cleanup();

  LSNRange lsn_range();
  uint64_t lsn_range_size() { return end_lsn > 0 ? (end_lsn - start_lsn) : 0; }

  void add_begin_trx_id(trx_id_t trx_id);
  void add_commit_trx_id(trx_id_t trx_id);
  void set_max_trx_id(trx_id_t trx_id);
  void set_max_trx_no(trx_id_t trx_no);
  void set_max_primary_recv_trx_id(trx_id_t trx_id);
  void update_last_rpl_time(uint64_t ts);
  void add_smo_index(space_id_t space_id, table_id_t table_id,
                     space_index_t index_id);
  void add_deleting_space(space_id_t space_id);
  void add_creating_undo_space(space_id_t space_id);

  void add_space_ddls(mlog_id_t type, space_id_t space_id,
      byte *body, lsn_t mtr_start_lsn);
  void push_space_ddls(mlog_id_t type, space_id_t space_id,
      std::string&& name, bool is_new_name);

  bool add_mdl_key(MDL_key *mdl_key, lsn_t lsn, bool log = true);
  void add_stats_tablename(std::string &table_name);
  void add_rpl_msg(uint8_t type, uint8_t flags, const byte *payload,
                   uint64_t len);
  void acquire_mdls();
  void release_mdls();

  void add_invalid_qc_table(const std::string& table_name);

  void tablespace_mdl_clean_up();
  void update_fil_system();
  void delay_table_free_if_needed(const space_ddl_t &ddl);
  void update_table_stats();
  void apply_rpl_msgs();
  void reload_meta();

  void do_invalid_qc_tables();

  void commit_transaction(TrxIds &trx_commit_ids_to_erase);

  void rpl_add_trx_start_id_to_rw_list();
  void rpl_prepare_transaction_ids(TrxIds &trx_commit_ids_to_erase);

  void update_trx_sys_max_trx_id(trx_id_t trx_id);
  void clear_space_cache();
  void create_new_undo_spaces();
  void apply_metadata();
  PageHash *get_page_hash(page_id_t page_id);
  page_records_t *get_page_records(page_id_t page_id);

  void add_record(mlog_id_t type, space_id_t space_id, page_no_t page_no,
                  byte *body, byte *rec_end, lsn_t start_lsn, lsn_t end_lsn,
                  const bool &ibuf_sec_index_page_modificiaton,
                  const ulint &ibuf_counter);

  void update_record_range(lsn_t start_lsn, lsn_t end_lsn);
  void finish_parse();
  void finish_apply();
  void finish_apply_low();

  void apply_prepare();
  uint64_t apply_materialize(buf_block_t *block);
  void apply_commit();
  void wait_for_all_slot_materialized();

  void apply_slot(uint64_t slot_id);

  void ref();
  void deref();

 public:
  using MDLKeys = std::vector<MDL_key *>;
  using SpaceIds = std::vector<space_id_t>;
  using SpaceDDLs = std::vector<space_ddl_t>;
  using NameVec = std::vector<std::pair<std::string, space_id_t>>;
  using StatsTableNames = std::vector<std::string>;
  using RplMsgs = std::vector<rpl_msg_t>;
  using MetaDatas = MetadataRecover;
  using TableIndexes = std::vector<std::pair<table_id_t, index_id_t>>;
  using AlteringKeyMap =
      std::unordered_map<std::string,
                         dd::cache::Dictionary_client::Table_altering_keys>;

  std::atomic<AssemblyState> state{AssemblyState::ASSEMBLY_STATE_UNINITED};
  TrxIds commit_trx_ids;
  TrxIds begin_trx_ids;
  MDLKeys mdl_keys;
  NameVec tablespace_mdl_vec;
  TableIndexes indexes;

  trx_id_t max_trx_id = 0;
  trx_id_t max_trx_no = 0;
  trx_id_t max_primary_recv_trx_id = 0;

  SpaceIds deleteing_spaces;
  SpaceIds new_undo_spaces;
  StatsTableNames stats_table_names;
  RplMsgs rpl_msgs;
  MetaDatas metadatas;
  SpaceDDLs space_ddls;
  AlteringKeyMap altering_keys;
  std::vector<std::string> invalid_qc_tables;

  std::atomic<uint64_t> record_count{0};
  PageHash *slots = nullptr;
  uint64_t n_slots;
  lsn_t start_lsn = 0;
  lsn_t end_lsn = 0;

  std::atomic<uint32_t> rbio_refer_num{0};
  std::atomic<uint32_t> bp_refer_num{0};
  std::atomic<uint32_t> apply_refer_num{0};

  std::atomic<uint64_t> epoch{0};
  uint64_t rpl_last_time = 0;

  std::shared_mutex mutex;
  int64_t snapshot_index = -1;
};

}  // namespace rpl
