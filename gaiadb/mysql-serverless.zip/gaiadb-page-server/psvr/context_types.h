/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/types.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <cstdint>

namespace psvr {

enum CtxType : uint32_t {
    kControl = 1,
    kFetch,
    kParse,
    kGc,
    kRecovery,
    kCompress,
    kRbio,
};

}
