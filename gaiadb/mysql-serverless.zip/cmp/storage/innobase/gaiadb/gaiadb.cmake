# Copyright (c) 2022, Baidu and/or its affiliates.
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License, version 2.0,
# as published by the Free Software Foundation.
#
# This program is also distributed with certain software (including
# but not limited to OpenSSL) that is licensed under separate terms,
# as designated in a particular file or component or in included license
# documentation.  The authors of MySQL hereby grant you an additional
# permission to link the program and your derivative works with the
# separately licensed software that they have included with MySQL.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License, version 2.0, for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

# Invoke with -DWITH_GAIADB=<directory>.
# If WITH_GAIADB is *not* set, builing will be failed

INCLUDE_DIRECTORIES(SYSTEM ${BOOST_PATCHES_DIR} ${BOOST_INCLUDE_DIR})
INCLUDE_DIRECTORIES(SYSTEM ../../extra/icu/icu-release-69-1/source/i18n)
INCLUDE_DIRECTORIES(SYSTEM ../../extra/icu/icu-release-69-1/source/common)

MACRO(RESET_GAIADB_VARIABLES)
  UNSET(BAIDURPC_DIR)
  #  UNSET(BAIDURPC_DIR CACHE)
  UNSET(BTHREAD_DIR)
  # UNSET(BTHREAD_DIR CACHE)
  UNSET(BASE_COMMON_DIR)
  # UNSET(BASE_COMMON_DIR CACHE)
  UNSET(BASE_ULLIB_DIR)
  #UNSET(BASE_ULLIB_DIR CACHE)
  UNSET(GFLAGS_DIR)
  #UNSET(GFLAGS_DIR CACHE)
  UNSET(BASE_IOBUF_DIR)
  #UNSET(BASE_IOBUF_DIR CACHE)
  UNSET(PB_DIR)
  #UNSET(PB_DIR CACHE)
  UNSET(BVAR_DIR)
  #UNSET(BVAR_DIR CACHE)
  UNSET(BRAFT_DIR)
  #UNSET(BRAFT_DIR CACHE)
  UNSET(PBTOJSON_DIR)
  #UNSET(PBTOJSON_DIR CACHE)
ENDMACRO()

MACRO(ECHO_GAIADB_VARIABLES)
  MESSAGE(STATUS "BAIDURPC_DIR ${BAIDURPC_DIR}")
  MESSAGE(STATUS "BTHREAD_DIR ${BTHREAD_DIR}")
  MESSAGE(STATUS "BASE_COMMON_DIR ${BASE_COMMON_DIR}")
  MESSAGE(STATUS "BASE_ULLIB_DIR ${BASE_ULLIB_DIR}")
  MESSAGE(STATUS "GFLAGS_DIR ${GFLAGS_DIR}")
  MESSAGE(STATUS "BASE_IOBUF_DIR ${BASE_IOBUF_DIR}")
  MESSAGE(STATUS "PB_DIR ${PB_DIR}")
  MESSAGE(STATUS "BVAR_DIR ${BVAR_DIR}")
  MESSAGE(STATUS "BRAFT_DIR ${BRAFT_DIR}")
  MESSAGE(STATUS "PBTOJSON_DIR ${PBTOJSON_DIR}")
ENDMACRO()

MACRO(COULD_NOT_FIND_GAIADB)
  ECHO_GAIADB_VARIABLES()
  #  RESET_GAIADB_VARIABLES()
  MESSAGE(STATUS "Could not find gaiadb dependent library.")
  MESSAGE(FATAL_ERROR
    "You can use it with -DWITH_GAIADB=<directory>\n"
    "This CMake script will look for gaiadb in <directory>. "
    )
ENDMACRO()

IF(NOT DEFINED WITH_GAIADB)
  COULD_NOT_FIND_GAIADB()
ENDIF()

SET(WITH_GAIADB ${WITH_GAIADB} CACHE PATH
  "Path to gaiadb sources: a directory.")

IF (WITH_GAIADB)
  FIND_PATH(BAIDURPC_DIR
            NAMES "include/baidu/rpc/server.h"
            PATHS ${WITH_GAIADB}/baidu/base/baidu-rpc/output
            NO_DEFAULT_PATH
           )

  FIND_PATH(BTHREAD_DIR
            NAMES "include/bthread_errno.h"
            PATHS ${WITH_GAIADB}/baidu/base/bthread/output
            NO_DEFAULT_PATH
           )

  FIND_PATH(BASE_COMMON_DIR
            NAMES "include/base/errno.h"
            PATHS ${WITH_GAIADB}/baidu/base/common/output
            NO_DEFAULT_PATH
           )

  FIND_PATH(BASE_ULLIB_DIR
            NAMES "include/com_log.h"
            PATHS ${WITH_GAIADB}/baidu/base/ullib/output
            NO_DEFAULT_PATH
           )

  FIND_PATH(GFLAGS_DIR
            NAMES "include/gflags/gflags.h"
            PATHS ${WITH_GAIADB}/third-64/gflags/output
            NO_DEFAULT_PATH
           )

  FIND_PATH(BASE_IOBUF_DIR
            NAMES "include/base/iobuf.h"
            PATHS ${WITH_GAIADB}/baidu/base/iobuf/output
            NO_DEFAULT_PATH
           )

  FIND_PATH(PB_DIR
            NAMES "include/google/protobuf/service.h"
            PATHS ${WITH_GAIADB}/baidu/third-party/protobuf/output
            NO_DEFAULT_PATH
           )

  FIND_PATH(BVAR_DIR
            NAMES "include/bvar/utils/lock_timer.h"
            PATHS ${WITH_GAIADB}/baidu/base/bvar/output
            NO_DEFAULT_PATH
           )

  FIND_PATH(BRAFT_DIR
            NAMES "include/raft/repeated_timer_task.h"
            PATHS ${WITH_GAIADB}/baidu/base/raft/output
            NO_DEFAULT_PATH
           )

  FIND_PATH(PBTOJSON_DIR
            NAMES "include/pb_to_json.h"
            PATHS ${WITH_GAIADB}/baidu/base/protobuf-json/output
            NO_DEFAULT_PATH
           )

  IF (CMAKE_SYSTEM_PROCESSOR MATCHES "aarch64")
    FIND_PATH(SSE2NEON_DIR
              NAMES "include/sse2neon.h"
              PATHS ${WITH_GAIADB}/baidu/third-party/sse2neon/output
              NO_DEFAULT_PATH
              )
    IF(SSE2NEON_DIR)
      INCLUDE_DIRECTORIES(SYSTEM ${SSE2NEON_DIR}/include)
      FIND_LIBRARY(SSE2NEON_LIBRARY sse2neon HINTS ${SSE2NEON_DIR}/lib/)
    ENDIF()
  ENDIF()
  
  IF(BAIDURPC_DIR)
    INCLUDE_DIRECTORIES(SYSTEM ${BAIDURPC_DIR}/include)
    FIND_LIBRARY(BDRPC_LIBRARY bdrpc HINTS ${BAIDURPC_DIR}/lib/)
  ENDIF()

  IF(BTHREAD_DIR)
    INCLUDE_DIRECTORIES(SYSTEM ${BTHREAD_DIR}/include)
    FIND_LIBRARY(BTHREAD_LIBRARY bthread HINTS ${BTHREAD_DIR}/lib/)
  ENDIF()

  IF(BASE_COMMON_DIR)
    INCLUDE_DIRECTORIES(SYSTEM ${BASE_COMMON_DIR}/include)
    FIND_LIBRARY(BASE_COMMON_LIBRARY base HINTS ${BASE_COMMON_DIR}/lib/)
  ENDIF()

  IF(BASE_ULLIB_DIR)
    INCLUDE_DIRECTORIES(SYSTEM ${BASE_ULLIB_DIR}/include)
    FIND_LIBRARY(BASE_ULLIB_LIBRARY ullib HINTS ${BASE_ULLIB_DIR}/lib/)
  ENDIF()

  IF(GFLAGS_DIR)
    INCLUDE_DIRECTORIES(SYSTEM ${GFLAGS_DIR}/include)
    FIND_LIBRARY(GFLAGS_LIBRARY gflags HINTS ${GFLAGS_DIR}/lib/)
  ENDIF()

  IF(BASE_IOBUF_DIR)
    INCLUDE_DIRECTORIES(SYSTEM ${BASE_IOBUF_DIR}/include)
    FIND_LIBRARY(BASE_IOBUF_LIBRARY iobuf HINTS ${BASE_IOBUF_DIR}/lib/)
  ENDIF()

  IF(PB_DIR)
    INCLUDE_DIRECTORIES(SYSTEM ${PB_DIR}/include)
    FIND_LIBRARY(PB_LIBRARY protobuf HINTS ${PB_DIR}/lib/)
  ENDIF()

  IF(BVAR_DIR)
    INCLUDE_DIRECTORIES(SYSTEM ${BVAR_DIR}/include)
    FIND_LIBRARY(BVAR_LIBRARY bvar HINTS ${BVAR_DIR}/lib/)
  ENDIF()

  IF(BRAFT_DIR)
    INCLUDE_DIRECTORIES(SYSTEM ${BRAFT_DIR}/include)
    FIND_LIBRARY(BRAFT_LIBRARY raft HINTS ${BRAFT_DIR}/lib/)
  ENDIF()

  IF(PBTOJSON_DIR)
    INCLUDE_DIRECTORIES(SYSTEM ${PBTOJSON_DIR}/include)
    FIND_LIBRARY(PBTOJSON_LIBRARY json-pb HINTS ${PBTOJSON_DIR}/lib/)
  ENDIF()

  INCLUDE_DIRECTORIES(SYSTEM ${WITH_GAIADB}/baidu/dba/gaiadb-common/output/include)
  FIND_LIBRARY(GAIADB_PB_LIBRARY gaiadb_pb HINTS ${WITH_GAIADB}/baidu/dba/gaiadb-common/output/lib)
  FIND_LIBRARY(GAIADB_COMMON_LIBRARY gaiadb_common HINTS ${WITH_GAIADB}/baidu/dba/gaiadb-common/output/lib)

  INCLUDE_DIRECTORIES(SYSTEM ${WITH_GAIADB}/baidu/dba/gaiadb-agent/output/include)
  FIND_LIBRARY(GAIADB_AGENT_LIBRARY gaiadb_polar HINTS ${WITH_GAIADB}/baidu/dba/gaiadb-agent/output/lib)

  INCLUDE_DIRECTORIES(SYSTEM ${WITH_GAIADB}/baidu/bos/cppsdk/output/include)
  FIND_LIBRARY(BOSSDK_LIBRARY bossdk HINTS ${WITH_GAIADB}/baidu/bos/cppsdk/output/lib)

  INCLUDE_DIRECTORIES(SYSTEM ${WITH_GAIADB}/third-64/json-cpp/output/include)
  FIND_LIBRARY(JSON_LIBMT_LIBRARY json_libmt HINTS ${WITH_GAIADB}/third-64/json-cpp/output/lib)

  FIND_LIBRARY(UUID_LIBRARY uuid HINTS ${WITH_GAIADB}/baidu/third-party/uuid/output/lib)
  INCLUDE_DIRECTORIES(SYSTEM ${WITH_GAIADB}/baidu/third-party/uuid/output/include)

  IF(WITH_POLAR_DPDK)
    INCLUDE_DIRECTORIES(SYSTEM ${WITH_GAIADB}/baidu/hpn/polar/output/include)
    FIND_LIBRARY(POLAR_DPDK_LIBRARY polar_dpdk HINTS ${WITH_GAIADB}/baidu/hpn/polar/output/lib)
    FIND_LIBRARY(DPDK_RTE_PMD_MLX5_LIBRARY rte_pmd_mlx5 HINTS ${WITH_GAIADB}/baidu/hpn/dpdk-19-11-snb/output/lib)
    FIND_LIBRARY(DPDK_RTE_MEMPOOL_LIBRARY rte_mempool HINTS ${WITH_GAIADB}/baidu/hpn/dpdk-19-11-snb/output/lib)
    FIND_LIBRARY(DPDK_RTE_MEMPOOL_RING_LIBRARY rte_mempool_ring HINTS ${WITH_GAIADB}/baidu/hpn/dpdk-19-11-snb/output/lib)

    FIND_LIBRARY(POLAR_NUMA_LIBRARYS numa HINTS ${WITH_GAIADB}/baidu/hpn/dpdk-19-11-snb/output/so)
    FIND_LIBRARY(POLAR_IBVERBS_LIBRARYS ibverbs HINTS ${WITH_GAIADB}/baidu/hpn/dpdk-19-11-snb/output/so)
    FIND_LIBRARY(POLAR_MLX5_LIBRARYS mlx5 HINTS ${WITH_GAIADB}/baidu/hpn/dpdk-19-11-snb/output/so)
    FIND_LIBRARY(POLAR_NL_LIBRARYS nl HINTS ${WITH_GAIADB}/baidu/hpn/dpdk-19-11-snb/output/so)

    INCLUDE_DIRECTORIES(SYSTEM ${WITH_GAIADB}/third-64/libevent/output/include)
    FIND_LIBRARY(EVENT_LIBRARY event HINTS ${WITH_GAIADB}/third-64/libevent/output/lib/)
    FIND_LIBRARY(EVENT_CORE_LIBRARY event_core HINTS ${WITH_GAIADB}/third-64/libevent/output/lib/)
    FIND_LIBRARY(EVENT_EXTRA_LIBRARY event_extra HINTS ${WITH_GAIADB}/third-64/libevent/output/lib/)
    FIND_LIBRARY(EVENT_OPENSSL_LIBRARY event_openssl HINTS ${WITH_GAIADB}/third-64/libevent/output/lib/)
    FIND_LIBRARY(EVENT_PTHREADS_LIBRARY event_pthreads HINTS ${WITH_GAIADB}/third-64/libevent/output/lib/)

    SET(DPDK_LIBS acl bbdev bitratestats bpf bus_dpaa bus_fslmc bus_ifpga bus_pci bus_vdev bus_vmbus
      cfgfile cmdline common_cpt common_dpaax common_octeontx2 common_octeontx compressdev cryptodev
      distributor eal efd ethdev eventdev fib flow_classify gro gso hash ip_frag ipsec jobstats kni kvargs
      latencystats lpm mbuf member mempool_bucket mempool_dpaa2 mempool_dpaa mempool_octeontx2
      mempool_octeontx mempool_stack meter metrics net pci pipeline pmd_af_packet pmd_ark
      pmd_atlantic pmd_avp pmd_axgbe pmd_bbdev_fpga_lte_fec pmd_bbdev_null pmd_bbdev_turbo_sw pmd_bnxt
      pmd_bond pmd_caam_jr pmd_crypto_scheduler pmd_cxgbe pmd_dpaa2 pmd_dpaa2_event pmd_dpaa2_sec pmd_dpaa
      pmd_dpaa_event pmd_dpaa_sec pmd_dsw_event pmd_e1000 pmd_ena pmd_enetc pmd_enic pmd_failsafe pmd_fm10k
      pmd_hinic pmd_hns3 pmd_i40e pmd_iavf pmd_ice pmd_ifc pmd_ixgbe pmd_kni pmd_memif pmd_netvsc
      pmd_nfp pmd_nitrox pmd_null pmd_null_crypto pmd_octeontx2 pmd_octeontx2_crypto pmd_octeontx2_event
      pmd_octeontx pmd_octeontx_crypto pmd_opdl_event pmd_qat pmd_qede pmd_ring pmd_skeleton_event pmd_softnic
      pmd_sw_event pmd_tap pmd_vdev_netvsc pmd_vhost pmd_virtio pmd_virtio_crypto port power rawdev
      rawdev_dpaa2_cmdif rawdev_dpaa2_qdma rawdev_ioat rawdev_ntb rawdev_octeontx2_dma rawdev_skeleton
      rcu reorder rib ring sched security stack table timer vhost)

    SET(DPDK_LIBRARIES "")
    FOREACH (dlib ${DPDK_LIBS})
      FIND_LIBRARY(DPDK_RET_${dlib}_LIBRARY rte_${dlib} HINTS ${WITH_GAIADB}/baidu/hpn/dpdk-19-11-snb/output/lib/)
      LIST(APPEND DPDK_LIBRARIES "${DPDK_RET_${dlib}_LIBRARY}")
    ENDFOREACH(dlib)
  ENDIF()

  IF (BUILD_WITH_PROFILER)
    INCLUDE_DIRECTORIES(SYSTEM ${WITH_GAIADB}/third-64/tcmalloc/output/include)
    FIND_LIBRARY(TCMALLOC_LIBRARY tcmalloc_and_profiler HINTS ${WITH_GAIADB}/third-64/tcmalloc/output/lib/)
  ELSE()
    SET(TCMALLOC_LIBRARY "")
  ENDIF()

  FIND_LIBRARY(WEBFOOT_NAMING_LIBRARY webfoot_naming HINTS ${WITH_GAIADB}/baidu/bns/naming-lib/output/lib/)
  FIND_LIBRARY(CARES_LIBRARY cares HINTS ${WITH_GAIADB}/baidu/third-party/c-ares/output/lib)
  FIND_LIBRARY(MCPACK2PB_LIBRARY mcpack2pb HINTS ${WITH_GAIADB}/baidu/base/mcpack2pb/output/lib/)
  FIND_LIBRARY(BSL_EXCEPTION_LIBRARY bsl_exception HINTS ${WITH_GAIADB}/lib2-64/bsl/output/lib/)
  FIND_LIBRARY(BSL_BUFFER_LIBRARY bsl_buffer HINTS ${WITH_GAIADB}/lib2-64/bsl/output/lib/)
  FIND_LIBRARY(BSL_UTILS_LIBRARY bsl_utils HINTS ${WITH_GAIADB}/lib2-64/bsl/output/lib/)
  FIND_LIBRARY(MESH_LIB_LIBRARY mesh HINTS ${WITH_GAIADB}/baidu/base/mesh-lib/output/lib/)
  FIND_LIBRARY(SFL_LIBRARY sfl HINTS ${WITH_GAIADB}/baidu/inf/sfl/output/lib/)

  IF (CMAKE_SYSTEM_PROCESSOR MATCHES "aarch64")
    FIND_LIBRARY(BAAS_INTERFACE_LIBRARY baas_interface HINTS ${WITH_GAIADB}/baidu/giano/giano-sdk/output/lib/)
    FIND_LIBRARY(LEVELDB_LIBRARY leveldb HINTS ${WITH_GAIADB}/baidu/third-party/leveldb/output/lib/)
  ELSE()
    FIND_LIBRARY(BAAS_INTERFACE_LIBRARY baas_interface HINTS ${WITH_GAIADB}/public/noah/giano-lib/release/baas-lib-c/output/lib/)
    FIND_LIBRARY(LEVELDB_LIBRARY leveldb HINTS ${WITH_GAIADB}/third-64/leveldb/output/lib/)
  ENDIF()

  MESSAGE(STATUS "baidu-rpc dir ${BAIDURPC_DIR}")
  MESSAGE(STATUS "bthread dir ${BTHREAD_DIR}")
  MESSAGE(STATUS "base-common dir ${BASE_COMMON_DIR}")
  MESSAGE(STATUS "comlog dir ${BASE_ULLIB_DIR}")
  MESSAGE(STATUS "gflags dir ${GFLAGS_DIR}")
  MESSAGE(STATUS "base-iobuf dir ${BASE_IOBUF_DIR}")
  MESSAGE(STATUS "protobuf dir ${PB_DIR}")
  MESSAGE(STATUS "bvar dir ${BVAR_DIR}")
  MESSAGE(STATUS "braft dir ${BRAFT_DIR}")
  MESSAGE(STATUS "protobuf-json dir ${PBTOJSON_DIR}")
ENDIF()
