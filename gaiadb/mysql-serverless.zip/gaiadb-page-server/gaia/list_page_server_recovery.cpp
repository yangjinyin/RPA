/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server_recovery.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_page_server_recovery.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

void ListPageServerRecovery::Done(pspb::BatchListRecoveryInfoResponse_ServerStatus* server_status,
        pspb::ListRecoveryInfoResponse* response, RpcStatus* status) {
    if (!status->IsOk()) {
        LOG(WARNING) << "rpc failed:" << status;
        response->mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
    }
    server_status->mutable_status()->CopyFrom(*response);
    _task_count.fetch_sub(1, std::memory_order_release);
    delete response;
    delete status;
}

int ListPageServerRecovery::Execute(const base::EndPoint& node,
        pspb::ListRecoveryInfoResponse* response, RpcStatus* status, ggpb::Closure* closure) {
    pspb::ListRecoveryInfoRequest request;
    request.set_log_id(_log_id);
    _client.Call(_log_id++, node, &pspb::QueryService_Stub::ListRecoveryInfo, &request, response,
            closure, status, _timeout_ms);
    if (closure) {
        return 0;
    } else {
        return status->IsOk() ? 0 : -1;
    }
}

void ListPageServerRecovery::DoneMulti(pspb::BatchMultiGetRecoverInfoResponse_ServerStatus* server_status,
        pspb::MultiGetRecoverInfoResponse* response, RpcStatus* status) {
    if (!status->IsOk()) {
        LOG(WARNING) << "rpc failed:" << status;
        response->mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
    }
    server_status->mutable_status()->CopyFrom(*response);
    _task_count.fetch_sub(1, std::memory_order_release);
    delete response;
    delete status;
}

int ListPageServerRecovery::Execute(const base::EndPoint& node,
        pspb::MultiGetRecoverInfoResponse* response, RpcStatus* status, ggpb::Closure* closure) {
    pspb::MultiGetRecoverInfoRequest request;
    request.set_log_id(_log_id);

    if (_segments.size()) {
        std::string error;
        int ret = JsonToProtoMessage(_segments, &request, &error);
        if (!ret) {
            print_error("--multi-segment convert to json error, %s", error.c_str());
            return 1;
        }
    } else if (_cluster_id.size()) {
        auto segment_pb = request.add_segments();
        segment_pb->set_cluster_id(_cluster_id);
        if (_segment_id.has_val) {
            if (_segment_id.val < 1) {
                print_error("error --segment-id:%u", _segment_id.val);
                return 1;
            }
            segment_pb->set_segment_id(_segment_id.val);
        }
    }

    _client.Call(_log_id++, node, &pspb::QueryService_Stub::MultiGetRecoverInfo, &request, response,
            closure, status, _timeout_ms);
    if (closure) {
        return 0;
    } else {
        return status->IsOk() ? 0 : -1;
    }
}


int ListPageServerRecovery::RunSpecific() {
    if (_cluster_id.size() && _segments.size()) {
        print_error("choice one between --multi-segment and --cluster-id");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    RpcStatus status;
    if (!_multi_type) {
        if (_segments.size()) {
            print_error("--multi-segment is disable in single type");
            return 1;
        }
        if ((_cluster_id.size() && !_segment_id.has_val)
                || (_cluster_id.empty() && _segment_id.has_val)) {
            print_error("--cluster-id and --segment-id should always appear in pairs in single type");
            return 1;
        }
        if (_segment_id.has_val && _segment_id.val < 1) {
            print_error("error --segment-id:%u", _segment_id.val);
            return 1;
        }

        pspb::GetRecoverInfoRequest request;
        pspb::GetRecoverInfoResponse response;
        request.set_log_id(_log_id);
        if (_segment_id.has_val) {
            request.set_cluster_id(_cluster_id);
            request.set_segment_id(_segment_id.val);
        }
        _client.Call(_log_id++, node, &pspb::QueryService_Stub::GetRecoverInfo, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }
        return Output(response);
    } else {
        pspb::MultiGetRecoverInfoRequest request;
        pspb::MultiGetRecoverInfoResponse response;

        request.set_log_id(_log_id);
        if (_segments.size()) {
            std::string error;
            ret = JsonToProtoMessage(_segments, &request, &error);
            if (!ret) {
                print_error("--multi-segment convert to json error, %s", error.c_str());
                return 1;
            }
        } else if (_cluster_id.size()) {
            auto segment_pb = request.add_segments();
            segment_pb->set_cluster_id(_cluster_id);
            if (_segment_id.has_val) {
                if (_segment_id.val < 1) {
                    print_error("error --segment-id:%u", _segment_id.val);
                    return 1;
                }
                segment_pb->set_segment_id(_segment_id.val);
            }
        }

        _client.Call(_log_id++, node, &pspb::QueryService_Stub::MultiGetRecoverInfo, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }
        return Output(response);
    }
}

int ListPageServerRecovery::Run() {
    if (_cluster_addr.empty() && (_address.empty() || _port < 1)) {
        print_error("miss --cluster-addr or (--address and --port)");
        return 1;
    }

    // to get specify info on a single page server
    if ((_segments.size() || _cluster_id.size()) && _cluster_addr.empty()) {
        return RunSpecific();
    }

    // get one server
    if (_cluster_addr.empty()) {
        base::EndPoint node;
        int ret = base::str2endpoint(_address.c_str(), _port, &node);
        if (ret != 0) {
            print_error("--address and --port convert to endpoint error");
            return 1;
        }
        RpcStatus status;
        pspb::ListRecoveryInfoResponse response;
        ret = Execute(node, &response, &status, nullptr);
        if (ret) {
            LOG(WARNING) << "rpc failed:" << status;
            return ret;
        }
        return Output(response);
    }

    // to get all servers
    PsmInfo psm_info(_cluster_addr, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--cluster-addr parse failed, cant get server list");
        return 1;
    }

    _task_count.store(nodes.size());

    if (!_multi_type) {
        pspb::BatchListRecoveryInfoResponse response;
        response.set_log_id(_log_id);
        for (auto& node : nodes) {
            auto server_status = response.add_server_status();
            server_status->set_addr(gaiadb::common::endpoint2str(node));
            pspb::ListRecoveryInfoResponse* rsp = new pspb::ListRecoveryInfoResponse;
            RpcStatus* status = new RpcStatus;
            auto closure = brpc::NewCallback(this, &ListPageServerRecovery::Done, server_status, rsp, status);
            int ret = Execute(node, rsp, status, closure);
            if (ret) {
                status->Reset(RpcCode::kInvalidArgs, "invalid");
                closure->Run();
            }
        }

        while (!_stopped) {
            if (_task_count.load(std::memory_order_acquire) == 0) {
                break;
            } else {
                gaiadb::common::pause();    // x86
            }
        }
        if (_stopped) {
            print_error("quit by signal");
            return 1;
        }

        return Output(response);
    } else {
        pspb::BatchMultiGetRecoverInfoResponse response;
        response.set_log_id(_log_id);
        for (auto& node : nodes) {
            auto server_status = response.add_server_status();
            server_status->set_addr(gaiadb::common::endpoint2str(node));
            pspb::MultiGetRecoverInfoResponse* rsp = new pspb::MultiGetRecoverInfoResponse;
            RpcStatus* status = new RpcStatus;
            auto closure = brpc::NewCallback(this, &ListPageServerRecovery::DoneMulti, server_status, rsp, status);
            int ret = Execute(node, rsp, status, closure);
            if (ret) {
                status->Reset(RpcCode::kInvalidArgs, "invalid");
                closure->Run();
            }
        }

        while (!_stopped) {
            if (_task_count.load(std::memory_order_acquire) == 0) {
                break;
            } else {
                gaiadb::common::pause();    // x86
            }
        }
        if (_stopped) {
            print_error("quit by signal");
            return 1;
        }

        return Output(response);
    }
}

int ListPageServerRecovery::Format(const pspb::GetRecoverInfoResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"recover_enable:", rsp.recover_enable()});
    table.AddRowsValue({"total_size:", RowSize(rsp.total_size(), _human_readable)});
    table.AddRowsValue({"recover_size:", RowSize(rsp.recover_size(), _human_readable)});
    table.AddRowsValue({"recover_times:", rsp.recover_times()});
    table.AddRowsValue({"recover_force:", rsp.recover_force()});
    table.AddRowsValue({"recover_finish_rate:", rsp.recover_finish_rate()});
    table.Display();
    return 0;
}

int ListPageServerRecovery::Format(const pspb::MultiGetRecoverInfoResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 0);
    table.AddRowsWithName({
            "cluster_id", "segment_id", "recover_status",
            "force_status", "recovery_times",
            "total_size", "finish_size", "finish_rate"}, true);
    for (int32_t i = 0; i < rsp.segments_size(); ++i) {
        const auto& seg_pb = rsp.segments(i);
        if (seg_pb.status().code() == pspb::Status_ReturnCode_SUCCESS) {
            table.AddRowsValue({
                    seg_pb.cluster_id(),
                    seg_pb.segment_id(),
                    seg_pb.recover_enable(),
                    seg_pb.recover_force(),
                    seg_pb.recover_times(),
                    RowSize(seg_pb.total_size(), _human_readable),
                    RowSize(seg_pb.recover_size(), _human_readable),
                    seg_pb.recover_finish_rate()
                    });
        } else {
            table.AddRowsValue({
                    seg_pb.cluster_id(),
                    seg_pb.segment_id(),
                    pspb::Status_ReturnCode_Name(seg_pb.status().code()),
                    seg_pb.status().msg()
                    });
        }
    }
    table.Display();
    return 0;
}

int ListPageServerRecovery::Format(const pspb::BatchMultiGetRecoverInfoResponse& rsp) {
    Table __table(_raw_with_table, 2);
    __table.AddRowsValue({"log_id:", _log_id});
    __table.Display();
    for (int32_t j = 0; j < rsp.server_status_size(); ++j) {
        const auto& server_status = rsp.server_status(j);
        const auto& rsp2 = server_status.status();
        if (rsp2.status().code() != pspb::Status_ReturnCode_SUCCESS) {
            Table table_err(_raw_with_table, 2);
            table_err.AddRowsValue({server_status.addr(),
                    RowStr(pspb::Status_ReturnCode_Name(rsp2.status().code()), rsp2.status().msg())});
            table_err.Display();
            continue;
        }

        Table table(_raw_with_table, 0);
        table.AddRowsWithName({
                "addr", "cluster_id", "segment_id", "recover_status",
                "force_status", "recovery_times",
                "total_size", "finish_size", "finish_rate"}, true);
        for (int32_t i = 0; i < rsp2.segments_size(); ++i) {
            const auto& seg_pb = rsp2.segments(i);
            if (seg_pb.status().code() == pspb::Status_ReturnCode_SUCCESS) {
                table.AddRowsValue({
                        server_status.addr(),
                        seg_pb.cluster_id(),
                        seg_pb.segment_id(),
                        seg_pb.recover_enable(),
                        seg_pb.recover_force(),
                        seg_pb.recover_times(),
                        RowSize(seg_pb.total_size(), _human_readable),
                        RowSize(seg_pb.recover_size(), _human_readable),
                        seg_pb.recover_finish_rate()
                        });
            } else {
                table.AddRowsValue({
                        server_status.addr(),
                        seg_pb.cluster_id(),
                        seg_pb.segment_id(),
                        pspb::Status_ReturnCode_Name(seg_pb.status().code()),
                        seg_pb.status().msg()
                        });
            }
        }
        table.Display();
    }
    return 0;
}

int ListPageServerRecovery::Format(const pspb::ListRecoveryInfoResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 0);
    table.AddRowsWithName({"status", "cluster_id", "segment_id",
            "total_size", "finish_size", "finish_rate",
            "store_id", "paiallel_count", "prior_num"
            }, true);
    for (int32_t i = 0; i < rsp.segments_size(); ++i) {
        const auto& seg_pb = rsp.segments(i);
        if (_only_running && !seg_pb.is_running()) {
            continue;
        }
        if (!_cluster_id.empty() && seg_pb.cluster_id() != _cluster_id) {
            continue;
        }
        if (_segment_id.has_val && seg_pb.segment_id() != _segment_id.val) {
            continue;
        }
        table.AddRowsValue({
                seg_pb.is_running() ? "=>" : "==",
                seg_pb.cluster_id(),
                seg_pb.segment_id(),
                RowSize(seg_pb.segment_size(), _human_readable),
                RowSize(seg_pb.recovery_size(), _human_readable),
                RowPercent(seg_pb.recovery_size(), seg_pb.segment_size()),
                seg_pb.store_id(),
                seg_pb.paiallel_task_count(),
                seg_pb.prior_num(),
                });
    }
    table.Display();
    return 0;
}

int ListPageServerRecovery::Format(const pspb::BatchListRecoveryInfoResponse& rsp) {
    Table __table(_raw_with_table, 2);
    __table.AddRowsValue({"log_id:", _log_id});
    __table.Display();
    for (int32_t j = 0; j < rsp.server_status_size(); ++j) {
        const auto& server_status = rsp.server_status(j);
        const auto& rsp2 = server_status.status();
        if (rsp2.status().code() != pspb::Status_ReturnCode_SUCCESS) {
            Table table_err(_raw_with_table, 2);
            table_err.AddRowsValue({server_status.addr(),
                    RowStr(pspb::Status_ReturnCode_Name(rsp2.status().code()), rsp2.status().msg())});
            table_err.Display();
            continue;
        }

        Table table_h(_raw_with_table, 4);
        table_h.AddRowsValue({"server", server_status.addr(), "total", rsp2.segments_size()});
        table_h.Display();

        Table table(_raw_with_table, 0);
        table.AddRowsWithName({"status", "cluster_id", "segment_id",
                "total_size", "finish_size", "finish_rate",
                "store_id", "paiallel_count", "prior_num"
                }, true);
        for (int32_t i = 0; i < rsp2.segments_size(); ++i) {
            const auto& seg_pb = rsp2.segments(i);
            if (_only_running && !seg_pb.is_running()) {
                continue;
            }
            table.AddRowsValue({
                    seg_pb.is_running() ? "=>" : "==",
                    seg_pb.cluster_id(),
                    seg_pb.segment_id(),
                    RowSize(seg_pb.segment_size(), _human_readable),
                    RowSize(seg_pb.recovery_size(), _human_readable),
                    RowPercent(seg_pb.recovery_size(), seg_pb.segment_size()),
                    seg_pb.store_id(),
                    seg_pb.paiallel_task_count(),
                    seg_pb.prior_num(),
                    });
        }

        table.Display();
    }
    return 0;
}

}
}
