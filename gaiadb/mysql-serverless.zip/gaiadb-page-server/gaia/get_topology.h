/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_topology.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class GetTopology : public Command {
public:
    GetTopology() {
        SetName("get-topology");
        SetDesc("get cluster topology information");
        SetDescCn("获取集群拓扑信息");
        
        AddPsmClusterOption();
        
        AddExample("--manager-address \"bns://xxx\"");
    }
    virtual ~GetTopology() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::TopologyResponse& rsp);

private:
    std::string _manager_address {};
};

}
}
