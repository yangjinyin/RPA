/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/client.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/client.h"

namespace psvr {

Client::Client() : _stopped(false), _inflight_req_count(0) {
    _log_id = get_current_micros();
    _rpc_client.reset(new RpcClient);
}

void Client::GetSegmentInfo(RpcGetPageServerCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &gaiapb::QueryService_Stub::get_page_server, ctx, closure);
}

void Client::GetLowestLsn(RpcGetLowestCtx* ctx, ggpb::Closure* closure) {
    Call(_rpc_client, &gaiapb::QueryService_Stub::get_lowest_point, ctx, closure);
}

void Client::ListLogService(RpcBatchGetLogServiceCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &gaiapb::QueryService_Stub::list_log_service, ctx, closure);
}

void Client::GetAllSpace(RpcGetAllSpaceCtx* ctx, ggpb::Closure* closure) {
    Call(_rpc_client, &gaiapb::QueryService_Stub::get_all_space_ids, ctx, closure);
}

void Client::GetSpaceMeta(RpcGetSpaceMetaCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &gaiapb::QueryService_Stub::get_space_meta, ctx, closure);
}

void Client::GetSpaceExtentMap(RpcGetSpaceExtentMapCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &gaiapb::QueryService_Stub::get_space_extent_map, ctx, closure);
}

void Client::ListSegmentReplica(RpcGetSegmentCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &gaiapb::QueryService_Stub::get_segment, ctx, closure);
}

void Client::ListSegment(RpcListSegmentCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &gaiapb::QueryService_Stub::list_segment, ctx, closure);
}

void Client::UpdateReplicaRecoveryStatus(RpcUpdateReplicaRecoveryStatusCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &gaiapb::ManageService_Stub::update_replica_recovery_status, ctx, closure);
}

void Client::ReadPhysicalPage(RpcReadPageCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &pspb::QueryService_Stub::ReadPhysicalPage, ctx, closure);
}

void Client::Read(RpcReadCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &pspb::QueryService_Stub::Read, ctx, closure);
}

void Client::Rbio(RpcRbioCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &pspb::RbioService_Stub::Rbio, ctx, closure);
}

void Client::Heartbeat(RpcPageServerHeartbeatCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &gaiapb::HeartbeatService_Stub::page_server_heartbeat, ctx, closure);
}

void Client::BatchHeartbeat(RpcBatchPageServerHeartbeatCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &gaiapb::HeartbeatService_Stub::batch_page_server_heartbeat, ctx, closure);
}

void Client::WritePhysicalPages(RpcWritePageCtx* ctx,
        ggpb::Closure* closure) {
    Call(_rpc_client, &pspb::RbioService_Stub::WritePhysicalPages, ctx, closure);
}

void Client::GetLog(RpcGetLogCtx* ctx, ggpb::Closure* closure) {
    Call(_rpc_client, &lspb::PageServerService_Stub::get_log, ctx, closure);
}

void Client::BatchGetLog(RpcBatchGetLogCtx* ctx, ggpb::Closure* closure) {
    Call(_rpc_client, &lspb::PageServerService_Stub::batch_get_log, ctx, closure);
}

void Client::SetReplicaRecovery(RpcSetReplicaRecovery* ctx, ggpb::Closure* closure) {
    Call(_rpc_client, &gaiapb::ManageService_Stub::set_replica_recovery, ctx, closure);
}

void Client::GetRedoRecLog(RpcGetRedoRecLog* ctx, ggpb::Closure* closure) {
    Call(_rpc_client, &pspb::QueryService_Stub::GetRedoRecLog, ctx, closure);
}

}
