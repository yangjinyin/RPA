/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file rpl/rpl0assemble.cc
 Gaiadb redo log replication

 Created 10/12/2021 Hongyu Qiao
 *******************************************************/

#include "rpl0assemble.h"
#include <unordered_set>
#include <vector>
#include "btr0sea.h"
#include "dict0dict.h"
#include "dict0priv.h"
#include "dict0stats_bg.h"
#include "gaiadb.h"
#include "handler/ha_innodb.h"
#include "ibuf0ibuf.h"
#include "log0ddl.h"
#include "rpl0apply.h"
#include "rpl0conductor.h"
#include "rpl0rpl.h"
#include "sql/current_thd.h"
#include "sql/dd/cache/dictionary_client.h"
#include "sql/dd/types/table.h"
#include "sql/mysqld.h"  // partition_level_mdl_enabled
#include "sql/sql_class.h"
#include "srv0srv.h"
#include "trx0sys.h"
#ifdef ENABLED_GAIADB_PAGE_VALIDATION
#include "rbio.h"
#include "rpl0pv.h"
#endif
#include "gaiadb_table.h"
#include "log0recv.h"

#include <gaiadb/utils/arena.h>
#include <cstring>

#ifdef UNIV_DEBUG
#include "sql/debug_sync.h"
#endif

extern byte *recv_parse_or_apply_log_rec_body(
    mlog_id_t type, byte *ptr, byte *end_ptr, space_id_t space_id,
    page_no_t page_no, buf_block_t *block, mtr_t *mtr, ulint parsed_bytes, lsn_t start_lsn);

namespace rpl {

#ifndef UNIV_HOTBACKUP
PSI_memory_key mem_rpl_page_hash_key;
#endif /* !UNIV_HOTBACKUP */

bvar::LatencyRecorder secondary_max_trx_id_rw_trx_ids_front_distance(
    "cmp_rpl_secondary_max_trx_id_rw_trx_ids_front_distance");

bvar::Adder<uint64_t> secondary_commit_trx_id_not_in_rw_trx_ids(
    "cmp_rpl_secondary_commit_trx_id_not_in_rw_trx_ids");

void log_record_t::copy_to_buffer(byte *buffer) { memcpy(buffer, data, len); }

std::ostream &operator<<(std::ostream &os, const AssemblyState &asmb_state) {
  switch (asmb_state) {
    case AssemblyState::ASSEMBLY_STATE_UNINITED:
      os << "ASSEMBLY_STATE_UNINITED";
      break;
    case AssemblyState::ASSEMBLY_STATE_INITED:
      os << "ASSEMBLY_STATE_INITED";
      break;
    case AssemblyState::ASSEMBLY_STATE_PARSED:
      os << "ASSEMBLY_STATE_PARSED";
      break;
    case AssemblyState::ASSEMBLY_STATE_PREPARED:
      os << "ASSEMBLY_STATE_PREPARED";
      break;
    case AssemblyState::ASSEMBLY_STATE_APPLIED:
      os << "ASSEMBLY_STATE_APPLIED";
      break;
    default:
      os << "unknow_assembly_state";
  }
  return os;
}

RplAssembly::RplAssembly() { n_slots = RplConst::RPL_SLOTS_PARALLEL; }

RplAssembly::~RplAssembly() {
  if (slots) {
    for (uint64_t i = 0; i < n_slots; ++i) {
      slots[i].m_pages.clear();
    }
    ut::delete_(slots);
  }
}

bool RplAssembly::init(uint64_t _epoch, uint64_t index) {
  std::unique_lock _(mutex);
  epoch = _epoch;
  if (!slots) {
    auto slots_p = ut::zalloc_withkey(UT_NEW_THIS_FILE_PSI_KEY,
                                      n_slots * sizeof(PageHash));
    slots = static_cast<PageHash *>(slots_p);
    for (uint64_t i = 0; i < n_slots; ++i) {
      PageHash *slot = new (&slots[i]) PageHash();
      slot->state = PagehashState::PAGE_HASH_STATE_UNAPPLIED;
      new (&(slot->arena)) gaiadb::common::Arena();
    }
  }
  ut_a(index != (uint64_t)-1);
  state = AssemblyState::ASSEMBLY_STATE_INITED;
  snapshot_index = (int64_t)index;
  ut_a(rbio_refer_num == 0);
  ut_a(bp_refer_num == 0);
  ut_a(apply_refer_num == 0);
  return true;
}

bool RplAssembly::cleanup() {
  LOG(TRACE) << "assembly " << lsn_range() << " cleanup";
  commit_trx_ids.clear();
  begin_trx_ids.clear();
  for (auto key : mdl_keys) {
    delete key;
  }
  mdl_keys.clear();
  if (!altering_keys.empty()) {
    if (current_thd != nullptr && current_thd->dd_client() != nullptr) {
      for (const auto &entry : altering_keys) {
        current_thd->dd_client()->unmark_table_altering(entry.second);
      }
    } else {
      ib_warn(ER_IB_GAIA_MSG_RPL)
          << "apply threads: cleanup found pending altering keys but no THD "
             "context for unmark";
    }
  }
  altering_keys.clear();
  tablespace_mdl_vec.clear();
  indexes.clear();
  deleteing_spaces.clear();
  stats_table_names.clear();
  rpl_msgs.clear();
  metadatas.clear();
  space_ddls.clear();
  invalid_qc_tables.clear();
  record_count = 0;
  if (slots) {
    for (uint32_t i = 0; i < n_slots; ++i) {
      PageHash *slot = &slots[i];
      slot->m_pages.clear();
      slot->arena.~Arena();
      slot->state = PagehashState::PAGE_HASH_STATE_UNAPPLIED;
    }
  }

  max_trx_id = 0;
  max_trx_no = 0;
  max_primary_recv_trx_id = 0;

  start_lsn = 0;
  end_lsn = 0;
  epoch.store(0);
  rpl_last_time = 0;
  state = AssemblyState::ASSEMBLY_STATE_UNINITED;
  snapshot_index = -1;
  return true;
}

LSNRange RplAssembly::lsn_range() { return LSNRange(start_lsn, end_lsn); }

void RplAssembly::add_begin_trx_id(trx_id_t trx_id) {
  begin_trx_ids.push_back(trx_id);
  set_max_trx_id(trx_id);
}

void RplAssembly::add_commit_trx_id(trx_id_t trx_id) {
  commit_trx_ids.push_back(trx_id);
  set_max_trx_id(trx_id);
}

void RplAssembly::set_max_trx_id(trx_id_t trx_id) {
  if (trx_id == TRX_ID_MAX) {
    return;
  }
  if (max_trx_id < trx_id) {
    max_trx_id = trx_id;
  }
}

void RplAssembly::set_max_trx_no(trx_id_t trx_no) {
  if (trx_no == TRX_ID_MAX) {
    return;
  }
  if (max_trx_no < trx_no) {
    max_trx_no = trx_no;
  }
}

void RplAssembly::set_max_primary_recv_trx_id(trx_id_t trx_id) {
  if (max_primary_recv_trx_id < trx_id) {
    max_primary_recv_trx_id = trx_id;
  }
}

void RplAssembly::update_last_rpl_time(uint64_t ts) {
  if (ts > rpl_last_time) {
    rpl_last_time = ts;
    auto now = my_micro_time();
    if (now > ts) {
      g_rpl_metric->parse_behind_master << (now - ts) / 1000;
    }
  }
}

void RplAssembly::add_smo_index(space_id_t space_id, table_id_t table_id,
                                space_index_t index_id) {
  indexes.push_back(std::make_pair(table_id, index_id_t(space_id, index_id)));
}

void RplAssembly::add_deleting_space(space_id_t space_id) {
  deleteing_spaces.push_back(space_id);
}

void RplAssembly::add_creating_undo_space(space_id_t space_id) {
  new_undo_spaces.push_back(space_id);
}

bool RplAssembly::add_mdl_key(MDL_key *key, lsn_t lsn, bool log) {
  for (auto& k : mdl_keys) {
    if (k->is_equal(key)) {
      const char *part_name = "-";
      if (key->mdl_namespace() == MDL_key::PARTITION) {
        part_name = key->partition_name();
      }
      ib_warn() << "mdl exists,"
        << " db_name=" << key->db_name()
        << " name=" << key->name()
        << " namespace=" << key->mdl_namespace_str()
        << " lenght=" << key->length()
        << " partition_name=" << (part_name ? part_name : "(null)")
        << " mtr_start_lsn=" << lsn;
      return false;
    }
  }
  mdl_keys.push_back(key);
  if (log) {
    const char *part_name = "-";
    if (key->mdl_namespace() == MDL_key::PARTITION) {
      part_name = key->partition_name();
    }
    ib_system() << "add mdl key,"
      << " db_name=" << key->db_name()
      << " name=" << key->name()
      << " namespace=" << key->mdl_namespace_str()
      << " lenght=" << key->length()
      << " partition_name=" << (part_name ? part_name : "(null)")
      << " mtr_start_lsn=" << lsn;
  }
  return true;
}

void RplAssembly::add_invalid_qc_table(const std::string& table_name) {
  invalid_qc_tables.push_back(table_name);
}

void RplAssembly::add_stats_tablename(std::string &table_name) {
  stats_table_names.emplace_back(table_name);
}

void RplAssembly::add_rpl_msg(uint8_t type, uint8_t flags, const byte *payload,
                              uint64_t len) {
  auto &msg = rpl_msgs.emplace_back();
  msg.type = type;
  msg.flags = flags;
  if (len > 0) {
    msg.payload.assign(reinterpret_cast<const char *>(payload), len);
  }
}

void RplAssembly::push_space_ddls(mlog_id_t type, space_id_t space_id,
    std::string&& name, bool is_new_name) {
  if (space_id == 0 || fsp_is_system_temporary(space_id)) {
    ib_system() << "ignore to add space ddl, space_id:" << space_id;
    return;
  }
  if (type != MLOG_FILE_RENAME) {
    space_ddls.emplace_back(type, space_id, std::move(name));
    return;
  }

  for (auto& ddl : space_ddls) {
    if (ddl.type != MLOG_FILE_RENAME || ddl.space_id != space_id) {
      continue;
    }

    if (is_new_name && ddl.new_name.empty()) {
      ddl.new_name = std::move(name);
      ddl.new_path = Fil_path::make_ibd_from_table_name(ddl.new_name);
      return;
    }

    if (!is_new_name && ddl.name.empty()) {
      ddl.name = std::move(name);
      return;
    }
  }

  if (is_new_name) {
    space_ddls.emplace_back(type, space_id, std::string());
    space_ddls.back().new_name = std::move(name);
    space_ddls.back().new_path = Fil_path::make_ibd_from_table_name(
        space_ddls.back().new_name);
  } else {
    space_ddls.emplace_back(type, space_id, std::move(name));
  }
}

void RplAssembly::add_space_ddls(mlog_id_t type, space_id_t space_id,
    byte *body, lsn_t mtr_start_lsn) {
  if (space_id == 0 || fsp_is_system_temporary(space_id)) {
    ib_info() << "ignore to add space ddl, space_id:" << space_id;
    return;
  }

  auto add_tablespace_mdl = [&](const std::string& name) {
    std::string key;
    uint32_t key_len = name.size();
    if (key_len == 0) {
      ib_warn() << "not get name on create tablespace mdl" << space_id;
      return;
    }
    // MDL_key::TABLESPACE format
    // | namespace_type | db_name | '\0' | object_name| '\0' |
    // |<-  1B        ->|<- 0B  ->|<-1B->|            |<-1B->|
    // if name overflows, truncate. see validate_tspnamelen function.
    if (key_len > NAME_LEN) {
      key_len = NAME_LEN;
    }

    key.resize(1 + 1 + key_len + 1, '\0');
    key[0] = (char)MDL_key::TABLESPACE;
    memcpy(&key[2], name.c_str(), key_len);
    key_len += 3;

    MDL_key *mdl_key = new MDL_key();
    mdl_key->mdl_key_init(key.c_str(), key_len);
    if (!add_mdl_key(mdl_key, mtr_start_lsn)) {
      delete mdl_key;
      mdl_key = nullptr;
    }
  };

  auto add_table_mdl = [&](const std::string& name) {
    // table key
    // MDL_key::TABLE format
    // | namespace_type | db_name | '\0' | table_name | '\0' |
    // |<-  1B        ->|         |<-1B->|            |<-1B->|
    if (auto pos = name.find('/');
        pos != name.npos) {
      std::string db_name = name.substr(0, pos);
      std::string table_name = name.substr(pos + 1);
      if (auto part_pos = table_name.find('#');
          part_pos != table_name.npos) {
        table_name = table_name.substr(0, part_pos);
      }
      if (db_name.empty() || table_name.empty()) {
        ib_warn() << "not get db or table_name on create table mdl" << space_id;
        return;
      }
      std::string table_key;
      table_key.resize(1 + db_name.size() + 1 + table_name.size() + 1, '\0');
      table_key[0] = (char)MDL_key::TABLE;
      memcpy(&table_key[1], db_name.c_str(), db_name.size());
      memcpy(&table_key[1 + db_name.size() + 1], table_name.c_str(), table_name.size());
      MDL_key *table_mdl_key = new MDL_key();
      table_mdl_key->mdl_key_init(table_key.c_str(), table_key.size());
      if (!add_mdl_key(table_mdl_key, mtr_start_lsn)) {
        delete table_mdl_key;
        table_mdl_key = nullptr;
      }
    } else {
      ib_warn() << "not found / on name when create table mdl:" << name;
    }
  };

  switch(type) {
  case MLOG_FILE_DELETE: {
    ulint path_len = mach_read_from_2(body);
    std::string path = std::string((const char*)body + 2, path_len - 1);
    ib_info() << "get delete rec, space_id=" << space_id
      << " path_len=" << path_len
      << " path=" << path;
    /** disable use redo to update fil system */
    return;
    std::string space_name;
    if (Fil_path::has_suffix(IBD, path)) {
      if (!Fil_path::parse_file_path(path, IBD, space_name)) {
        space_name = path;
        Fil_path::truncate_suffix(IBD, space_name);
      }
    } else {
      /* 8018 not include IBD suffix */
      space_name = path;
    }
    //std::string space_name = fil_convert_filename_to_tablename(path);
    ib_system() << "get delete rec, space_id=" << space_id
      << " path_len=" << path_len
      << " path=" << path
      << " space_name=" << space_name
      << " mtr_start_lsn=" << mtr_start_lsn;
    space_ddls.emplace_back(type, space_id, std::move(space_name));
    add_tablespace_mdl(space_ddls.back().name);
    add_table_mdl(space_ddls.back().name);
    break;
  }
  case MLOG_FILE_CREATE: {
    /*  |size|flags|path_len|path| */
    ulint path_len = mach_read_from_2(body + 4 + 4);
    std::string path = std::string((const char*)body + 4 + 4 + 2, path_len - 1);
    ib_info() << "get create rec, space_id=" << space_id
      << " path_len=" << path_len
      << " path=" << path;
    /** disable use redo to update fil system */
    return;
    std::string space_name;
    if (Fil_path::has_suffix(IBD, path)) {
      if (!Fil_path::parse_file_path(path, IBD, space_name)) {
        space_name = path;
        Fil_path::truncate_suffix(IBD, space_name);
      }
    } else {
      /* 8018 not include IBD suffix */
      space_name = path;
    }
    //std::string space_name = fil_convert_filename_to_tablename(path);
    ib_system() << "get create rec, space_id=" << space_id
      << " path_len=" << path_len
      << " path=" << path
      << " space_name=" << space_name
      << " mtr_start_lsn=" << mtr_start_lsn;
    space_ddls.emplace_back(type, space_id, std::move(space_name));
    add_tablespace_mdl(space_ddls.back().name);
    add_table_mdl(space_ddls.back().name);
    break;
  }
  case MLOG_FILE_RENAME: {
    ulint old_path_len = mach_read_from_2(body);
    std::string old_path = std::string((const char*)body + 2, old_path_len - 1);
    ulint new_path_len = mach_read_from_2(body + 2 + old_path_len);
    std::string new_path = std::string((const char*)body + 2 + old_path_len + 2, new_path_len - 1);
    ib_info() << "get rename rec, space_id=" << space_id
      << " old_path_len=" << old_path_len
      << " old_path=" << old_path
      << " new_path_len=" << new_path_len
      << " new_path=" << new_path;
    /** disable use redo to update fil system */
    return;
    std::string old_space_name;
    if (Fil_path::has_suffix(IBD, old_path)) {
      if (!Fil_path::parse_file_path(old_path, IBD, old_space_name)) {
        old_space_name = old_path;
        Fil_path::truncate_suffix(IBD, old_space_name);
      }
    } else {
      /* 8018 not include IBD suffix */
      old_space_name = old_path;
    }
    std::string new_space_name;
    if (Fil_path::has_suffix(IBD, new_path)) {
      if (!Fil_path::parse_file_path(new_path, IBD, new_space_name)) {
        new_space_name = new_path;
        Fil_path::truncate_suffix(IBD, new_space_name);
      }
    } else {
      new_space_name = new_path;
    }
    //std::string old_space_name = fil_convert_filename_to_tablename(old_path);
    //std::string new_space_name = fil_convert_filename_to_tablename(new_path);
    ib_system() << "get rename rec, space_id=" << space_id
      << " old_path_len=" << old_path_len
      << " old_path=" << old_path
      << " old_space_name=" << old_space_name
      << " new_path_len=" << new_path_len
      << " new_path=" << new_path
      << " new_space_name=" << new_space_name
      << " mtr_start_lsn=" << mtr_start_lsn;
    space_ddls.emplace_back(type, space_id, std::move(old_space_name),
        std::move(new_space_name), std::move(new_path));
    add_tablespace_mdl(space_ddls.back().name);
    add_table_mdl(space_ddls.back().name);
    add_tablespace_mdl(space_ddls.back().new_name);
    add_table_mdl(space_ddls.back().new_name);
    break;
  }
  default:
    break;
  }
}

bool ingnore_mdl_key_for_mysql_tables(MDL_key *mdl_key) {
  //the below tables are permanent handle which means their tables' reference count are always 1(in innodb table cache). see innobase_dict_recover()
  //since the table definition are compatiable between 8018 and 8031, so we can skip the table cache invalidation. otherwise will hit the table refcount == 0 assertion.
  if (mdl_key->mdl_namespace() == MDL_key::TABLE &&
      !strcmp(mdl_key->db_name(), "mysql")) {
    auto table_name = mdl_key->name();
    if (!strcmp(table_name, "innodb_dynamic_metadata") ||
        !strcmp(table_name, "innodb_table_stats") ||
        !strcmp(table_name, "innodb_index_stats") ||
        !strcmp(table_name, "innodb_ddl_log")) {
      return true;
    }
  }

  return false;
}

static std::string make_table_key(const MDL_key *mdl_key) {
  const char *schema_name = mdl_key->db_name();
  const char *table_name = mdl_key->name();
  std::string key;
  key.reserve(strlen(schema_name) + 1 + strlen(table_name));
  key.append(schema_name);
  key.push_back('\0');
  key.append(table_name);
  return key;
}

void RplAssembly::acquire_mdls() {
  altering_keys.clear();
  std::unordered_set<std::string> fallback_table_x;
  for (auto mdl_key : mdl_keys) {
    if (ingnore_mdl_key_for_mysql_tables(mdl_key)) {
      continue;
    }
    if (mdl_key->mdl_namespace() != MDL_key::SCHEMA &&
        mdl_key->mdl_namespace() != MDL_key::TABLESPACE) {
      MDL_request pre_mdl_request;
      MDL_REQUEST_INIT(&pre_mdl_request, MDL_key::SCHEMA, mdl_key->db_name(),
                       "", MDL_INTENTION_EXCLUSIVE, MDL_TRANSACTION);
      if (current_thd->mdl_context.acquire_lock(
              &pre_mdl_request, srv_gaia_apply_mdl_lock_wait_timeout, true)) {
        ib_error(ER_IB_GAIA_MSG_RPL)
            << "apply threads: acquire db mdl failed:" << mdl_key->db_name();
        continue;
      }
    }
    if (mdl_key->mdl_namespace() == MDL_key::PARTITION) {
      // If secondary disables partition-level MDL, fall back to TABLE X so
      // replay preserves traditional DDL/DML blocking semantics.
      if (!partition_level_mdl_enabled) {
        const std::string table_key = make_table_key(mdl_key);
        if (fallback_table_x.insert(table_key).second) {
          MDL_request table_x_request;
          MDL_REQUEST_INIT(&table_x_request, MDL_key::TABLE, mdl_key->db_name(),
                           mdl_key->name(), MDL_EXCLUSIVE, MDL_TRANSACTION);
          if (current_thd->mdl_context.acquire_lock(
                  &table_x_request, srv_gaia_apply_mdl_lock_wait_timeout,
                  true)) {
            ib_error(ER_IB_GAIA_MSG_RPL)
                << "apply threads: fallback acquire table x mdl failed, db "
                   "name:"
                << mdl_key->db_name() << ", table name:" << mdl_key->name();
          } else {
            ib_info(ER_IB_GAIA_MSG_RPL)
                << "apply threads: partition mdl fallback to table x, db name:"
                << mdl_key->db_name() << ", table name:" << mdl_key->name();
          }
        }
        continue;
      }
      // TODO: sync TABLE SPW lock info via redo; currently inferred from
      // PARTITION keys to restore primary-side semantics.
      MDL_request table_spw_request;
      MDL_REQUEST_INIT(&table_spw_request, MDL_key::TABLE, mdl_key->db_name(),
                       mdl_key->name(), MDL_SHARED_PARTITION_WRITE,
                       MDL_TRANSACTION);
      if (current_thd->mdl_context.acquire_lock(
              &table_spw_request, srv_gaia_apply_mdl_lock_wait_timeout, true)) {
        ib_error(ER_IB_GAIA_MSG_RPL)
            << "apply threads: acquire table spw mdl failed, db name:"
            << mdl_key->db_name() << ", table name:" << mdl_key->name()
            << ", partition:" << mdl_key->partition_name();
        continue;
      }
    }
    if (mdl_key->mdl_namespace() == MDL_key::COLUMN_STATISTICS ||
        mdl_key->mdl_namespace() == MDL_key::FOREIGN_KEY ||
        mdl_key->mdl_namespace() == MDL_key::CHECK_CONSTRAINT) {
      MDL_request table_mdl_request;
      auto mdl_type = MDL_INTENTION_EXCLUSIVE;
      if (mdl_key->mdl_namespace() == MDL_key::COLUMN_STATISTICS) {
        // for COLUMN_STATISTICS, we need to clean the tdc cache,
        // should have the MDL_key::TABLE, MDL_EXCLUSIVE lock
        mdl_type = MDL_EXCLUSIVE;
      }
      MDL_REQUEST_INIT(&table_mdl_request, MDL_key::TABLE, mdl_key->name(), "",
                       mdl_type, MDL_TRANSACTION);
      if (current_thd->mdl_context.acquire_lock(
              &table_mdl_request, srv_gaia_apply_mdl_lock_wait_timeout, true)) {
        ib_error(ER_IB_GAIA_MSG_RPL)
            << "apply threads: acquire table mdl failed:" << mdl_key->name();
        continue;
      }
    }
    MDL_request mdl_request;
    MDL_REQUEST_INIT_BY_KEY(&mdl_request, mdl_key, MDL_EXCLUSIVE,
                            MDL_TRANSACTION);
    if (current_thd->mdl_context.acquire_lock(
            &mdl_request, srv_gaia_apply_mdl_lock_wait_timeout, true)) {
      ib_error(ER_IB_GAIA_MSG_RPL)
          << "apply threads: acquire mdl failed, db name:"
          << mdl_key->db_name() << ", table name:" << mdl_key->name()
          << ", namespace:" << mdl_key->mdl_namespace_str();
      continue;
    }
    ib_info(ER_IB_GAIA_MSG_RPL)
        << "apply threads: acquire mdl success, db name:" << mdl_key->db_name()
        << ", table name:" << mdl_key->name()
        << ", namespace:" << mdl_key->mdl_namespace_str();
    if (mdl_key->mdl_namespace() == MDL_key::PARTITION) {
      const std::string table_key = make_table_key(mdl_key);
      if (altering_keys.find(table_key) != altering_keys.end()) {
        continue;
      }

      dd::cache::Dictionary_client::Auto_releaser releaser(
          current_thd->dd_client());
      const dd::Table *table = nullptr;
      if (current_thd->dd_client()->acquire<dd::Table>(
              dd::String_type(mdl_key->db_name()),
              dd::String_type(mdl_key->name()), &table) ||
          table == nullptr) {
        ib_error(ER_IB_GAIA_MSG_RPL)
            << "apply threads: acquire dd::Table failed, db name:"
            << mdl_key->db_name() << ", table name:" << mdl_key->name()
            << ", partition:" << mdl_key->partition_name();
      } else {
        dd::cache::Dictionary_client::Table_altering_keys keys;
        if (current_thd->dd_client()->mark_table_altering_and_wait(*table,
                                                                   &keys)) {
          ib_error(ER_IB_GAIA_MSG_RPL)
              << "apply threads: mark table altering failed, db name:"
              << mdl_key->db_name() << ", table name:" << mdl_key->name()
              << ", partition:" << mdl_key->partition_name();
        } else {
          altering_keys.emplace(table_key, keys);
        }
      }
    }
  }
}

void RplAssembly::delay_table_free_if_needed(const space_ddl_t &ddl) {
  dict_table_t *table = nullptr;
  uint64_t ref_count = 0;
  bool needs_delay = false;
  space_id_t mismatch_space_id = dict_sys_t::s_invalid_space_id;

  dict_sys_mutex_enter();
  table = dict_table_check_if_in_cache_low(ddl.name.c_str());
  if (table != nullptr) {
    if (table->space != ddl.space_id) {
      /* Same-name partition may already be reused by another space_id. */
      mismatch_space_id = table->space;
      table = nullptr;
    } else {
      ref_count = table->get_ref_count();
      if (ref_count > 0) {
        btr_drop_ahi_for_table(table);
        dict_table_remove_from_cache(table, true);
        needs_delay = true;
      } else {
        btr_drop_ahi_for_table(table);
        dict_table_remove_from_cache(table);
      }
    }
  }
  dict_sys_mutex_exit();

  if (mismatch_space_id != dict_sys_t::s_invalid_space_id) {
    ib_warn(ER_IB_GAIA_MSG_RPL)
        << "apply threads: skip dict_table cleanup due to space_id mismatch:"
        << " expected_space_id:" << ddl.space_id
        << " cached_space_id:" << mismatch_space_id << " name:" << ddl.name;
    return;
  }

  if (!needs_delay) {
    return;
  }

  ut_ad(table != nullptr);
  DDL_Delayed_Task *task =
      ut::new_withkey<DDL_Delayed_Task>(UT_NEW_THIS_FILE_PSI_KEY);
  ut_ad(task != nullptr);
  task->thread_id =
      current_thd ? static_cast<ulint>(current_thd->thread_id()) : 0;
  task->table = table;

  ddl_delayed_queue_add(task);

  ib_info(ER_IB_GAIA_MSG_RPL)
      << "apply threads: delay free dict_table after delete, space_id:"
      << ddl.space_id << " name:" << ddl.name << " ref_count:" << ref_count;
}

void RplAssembly::update_fil_system() {
  dberr_t error_ret;

  for (auto &ddl : space_ddls) {
    dberr_t raw_error_ret = DB_SUCCESS;

    if (ddl.type == MLOG_FILE_CREATE) {
      raw_error_ret = fil_space_create_in_secondary(ddl.space_id, ddl.name);
      error_ret = raw_error_ret;
    } else if (ddl.type == MLOG_FILE_DELETE) {
      raw_error_ret = fil_space_delete_in_secondary(ddl.space_id, ddl.name);
      if (raw_error_ret == DB_SUCCESS || raw_error_ret == DB_TABLESPACE_NOT_FOUND) {
        if (raw_error_ret == DB_TABLESPACE_NOT_FOUND) {
          ib_info(ER_IB_GAIA_MSG_RPL)
              << "apply threads: treat missing tablespace delete as idempotent"
                 " success:"
              << " space_id:" << ddl.space_id << " name:" << ddl.name;
        }
        delay_table_free_if_needed(ddl);
        /* Secondary delete is idempotent: normalize not-found to success. */
        error_ret = DB_SUCCESS;
      } else {
        error_ret = raw_error_ret;
        ib_warn(ER_IB_GAIA_MSG_RPL)
            << "apply threads: skip delayed table free because delete failed:"
            << " space_id:" << ddl.space_id << " name:" << ddl.name
            << " err:" << raw_error_ret;
      }
    } else if (ddl.type == MLOG_FILE_RENAME) {
      ut_a(!ddl.name.empty());
      ut_a(!ddl.new_name.empty());
      raw_error_ret = fil_space_rename_in_secondary(ddl.space_id, ddl.name,
                                                    ddl.new_name, ddl.new_path);
      error_ret = raw_error_ret;
    } else {
      ut_error;
    }
    ib_system() << "update fil system, ret:" << error_ret
      << ", raw_ret:" << raw_error_ret
      << " type:" << get_mlog_string(ddl.type)
      << ", space_id:" << ddl.space_id
      << ", name:" << ddl.name
      << ", new_name:" << ddl.new_name
      << ", new_path:" << ddl.new_path
      << ", lsn:" << start_lsn << "," << end_lsn;
  }
}

void RplAssembly::tablespace_mdl_clean_up() {
  auto size = tablespace_mdl_vec.size();
  for (decltype(size) i = 0; i < size; ++i) {
    auto name = tablespace_mdl_vec[i].first;
    auto space_id = tablespace_mdl_vec[i].second;
    dberr_t err;
    if (space_id == dict_sys_t::s_invalid_space_id) {
      err = fil_clear_one_map_in_secondary(name.c_str());
    } else {
      err = fil_clear_both_maps_in_secondary(space_id);
    }
    if (err != DB_SUCCESS) {
      ib_warn(ER_IB_GAIA_MSG_RPL)
          << "apply threads: cleanup tablespace mdl failed:"
          << " space_id: " << space_id << ", name: " << name
          << ", err:" << err;
    } else {
      ib_info(ER_IB_GAIA_MSG_RPL)
          << "apply threads: cleanup tablespace mdl ok:"
          << " space_id: " << space_id << ", name: " << name;
    }
  }
}

void RplAssembly::do_invalid_qc_tables() {
  for (auto& name : invalid_qc_tables) {
    innobase_invalidate_query_cache(name.c_str());
  }
}

struct Table_mdl_invalidation {
  std::string db;
  std::string table;
  const MDL_key *table_mdl{nullptr};
  bool has_table{false};
  bool has_partition{false};
  std::vector<std::string> partition_names;
};

void RplAssembly::release_mdls() {
  MDL_ticket *ticket;
  MDL_ticket_store *ticket_store = current_thd->mdl_context.get_tickets();
  MDL_ticket_store::List_iterator it =
      ticket_store->list_iterator(MDL_TRANSACTION);

  /* do_invalid_qc_tables() must be called unconditionally here, even when
     there are no MDL_TRANSACTION tickets (i.e., plain DML without DDL).
     For DML on partitioned tables the redo parser collects table names into
     invalid_qc_tables during parse, but this is the only place they are
     actually flushed to the fast-query-cache layer.  Skipping the call when
     the ticket store is empty would leave stale cache entries indefinitely,
     causing the two query forms
       "SELECT ... FROM db.tbl"  vs  "USE db; SELECT ... FROM tbl"
     to return inconsistent results after a DML on the slave. */
  do_invalid_qc_tables();

  if (ticket_store->is_empty(MDL_TRANSACTION)) {
    return;
  }

  update_fil_system();
  tablespace_mdl_clean_up();

  std::unordered_map<std::string, Table_mdl_invalidation> table_invalidations;
  const MDL_key *acl_key = nullptr;
  while ((ticket = it++)) {
    if (ticket->get_type() != MDL_EXCLUSIVE) {
      continue;
    }
    if (ticket->get_key()->mdl_namespace() == MDL_key::ACL_CACHE) {
      if (!acl_key) {
        acl_key = ticket->get_key();
      }
      continue;
    }
    const MDL_key *mdl_key = ticket->get_key();
    if (mdl_key->mdl_namespace() == MDL_key::PARTITION ||
        mdl_key->mdl_namespace() == MDL_key::TABLE) {
      const std::string table_key = make_table_key(mdl_key);
      auto &info = table_invalidations[table_key];
      if (info.db.empty()) {
        info.db = mdl_key->db_name();
        info.table = mdl_key->name();
      }
      if (mdl_key->mdl_namespace() == MDL_key::TABLE) {
        info.has_table = true;
        info.table_mdl = mdl_key;
      } else {
        info.has_partition = true;
        const char *part_name = mdl_key->partition_name();
        if (part_name != nullptr && part_name[0] != '\0') {
          info.partition_names.emplace_back(part_name);
        }
      }
    } else {
      current_thd->secondary_mdl_invalid_caches(mdl_key);
    }
  }

  for (auto &entry : table_invalidations) {
    auto &info = entry.second;
    // For mixed DDL on the same table (TABLE X + PARTITION X), prefer TABLE
    // invalidation. Partition-only invalidation is only for pure partition DDL.
    if (info.has_table) {
      current_thd->secondary_mdl_invalid_caches(info.table_mdl);
    } else if (info.has_partition) {
      current_thd->secondary_mdl_invalid_partitions(
          info.db.c_str(), info.table.c_str(), info.partition_names);
    }
    if (info.has_partition) {
      auto it_keys = altering_keys.find(entry.first);
      if (it_keys != altering_keys.end()) {
        current_thd->dd_client()->unmark_table_altering(it_keys->second);
        altering_keys.erase(it_keys);
      }
    }
  }

  current_thd->mdl_context.release_transactional_locks();

  // reload acl cache after ticket iterator
  // because reload acl cache will acquire mdl lock
  if (acl_key) {
    MDL_request mdl_request;
    MDL_REQUEST_INIT_BY_KEY(&mdl_request, acl_key, MDL_EXCLUSIVE,
                            MDL_TRANSACTION);
    if (current_thd->mdl_context.acquire_lock(
            &mdl_request, srv_gaia_apply_mdl_lock_wait_timeout, true)) {
      ib_error(ER_IB_GAIA_MSG_RPL)
          << "apply threads: acquire mdl failed for acl cache, db name: "
          << acl_key->db_name() << " table name: " << acl_key->name()
          << " namespace: " << acl_key->mdl_namespace_str();
    } else {
      current_thd->secondary_mdl_invalid_caches(acl_key);
    }
    current_thd->mdl_context.release_transactional_locks();

    // to release thd trx
    ha_close_connection(g_rpl_coordinator->m_thd);
  }
}

void RplAssembly::update_table_stats() {
  if (stats_table_names.size() == 0) {
    return;
  }
  char norm_name[FN_REFLEN];
  mutex_enter(&dict_sys->mutex);
  for (auto table_name : stats_table_names) {
    normalize_table_name(norm_name, table_name.c_str());
    LOG(TRACE) << "update table stat: [" << table_name << "][" << norm_name
               << "]";
    dict_table_t *table = dict_table_check_if_in_cache_low(norm_name);
    if (table == NULL) {
      continue;
    }

    dict_stats_recalc_pool_add(table);
  }
  mutex_exit(&dict_sys->mutex);
}

void RplAssembly::apply_rpl_msgs() {
  for (const auto &msg : rpl_msgs) {
    const byte *payload = nullptr;
    if (!msg.payload.empty()) {
      payload = reinterpret_cast<const byte *>(msg.payload.data());
    }
    g_rpl_conductor->apply_rpl_msg(msg.type, msg.flags, payload,
                                   msg.payload.size());
  }
}

void RplAssembly::reload_meta() {
  auto reload_meta = rpl_sys->get_rpl_reload_meta();
  if (!reload_meta->get_need_reload_meta()){
    return;
  }

  auto duration_second = std::chrono::duration<double>(
      std::chrono::steady_clock::now() - reload_meta->get_start_time()).count();
  if (duration_second < reload_meta->get_delay()) {
    return;
  }
  LOG(NOTICE) << "RplAssembly::reload_meta, duration_second="
              << duration_second << ", delay=" <<  reload_meta->get_delay();
  current_thd->secondary_reload_meta(reload_meta->get_db_name());
  reload_meta->set_need_reload_meta(false);
}

void RplAssembly::rpl_prepare_transaction_ids(TrxIds &trx_commit_ids_to_erase) {
  trx_commit_ids_to_erase.clear();
  for (auto trx_id : commit_trx_ids) {
    TrxIds::iterator it =
        std::find(begin_trx_ids.begin(), begin_trx_ids.end(), trx_id);
    if (it != begin_trx_ids.end()) {
      begin_trx_ids.erase(it);
    } else {
      trx_commit_ids_to_erase.push_back(trx_id);
    }
  }
}

void RplAssembly::rpl_add_trx_start_id_to_rw_list() {
  if (begin_trx_ids.empty()) {
    return;
  }

  ut_a(trx_sys != nullptr);
  trx_sys_mutex_enter();
  bool skip_add = false;
#ifdef UNIV_DEBUG
  /* Simulate BEGIN records lost across a secondary restart. */
  DBUG_EXECUTE_IF("rpl_skip_add_begin_trx_id", { skip_add = true; });
#endif /* UNIV_DEBUG */
  if (!skip_add) {
    for (auto trx_id : begin_trx_ids) {
      trx_sys->rw_trx_ids.push_back(trx_id);
    }
  }
  update_trx_sys_max_trx_id(begin_trx_ids.back());
  trx_sys_mutex_exit();
}

void RplAssembly::commit_transaction(TrxIds &trx_commit_ids_to_erase) {
  ut_a(trx_sys != nullptr);
  trx_sys_mutex_enter();
  for (auto trx_id : trx_commit_ids_to_erase) {
    trx_ids_t::iterator iterator = std::lower_bound(
        trx_sys->rw_trx_ids.begin(), trx_sys->rw_trx_ids.end(), trx_id);
    if (iterator == trx_sys->rw_trx_ids.end() || *iterator != trx_id) {
      /* Erasing *iterator here would drop another active trx. */
      secondary_commit_trx_id_not_in_rw_trx_ids << 1;
      LOG(WARNING) << "RplAssembly::commit_transaction, commit trx_id="
                   << trx_id << " not in rw_trx_ids, skip erase";
      continue;
    }
    trx_sys->rw_trx_ids.erase(iterator);
  }

  size_t rw_trx_size = trx_sys->rw_trx_ids.size();
  for (size_t i = 0; i < rw_trx_size; i++) {
    if (max_primary_recv_trx_id >= trx_sys->rw_trx_ids.front()) {
      trx_sys->rw_trx_ids.erase(trx_sys->rw_trx_ids.begin());
    } else {
      break;
    }
  }
  update_trx_sys_max_trx_id(max_trx_id);
  auto next_trx_id_or_no =  trx_sys_get_next_trx_id_or_no();
  if (!trx_sys->rw_trx_ids.empty() && next_trx_id_or_no > trx_sys->rw_trx_ids.front()) {
    secondary_max_trx_id_rw_trx_ids_front_distance << (next_trx_id_or_no - trx_sys->rw_trx_ids.front());
  } else {
    secondary_max_trx_id_rw_trx_ids_front_distance << 0;
  }
  trx_sys_mutex_exit();
}

void RplAssembly::update_trx_sys_max_trx_id(trx_id_t trx_id) {
  ut_ad(trx_sys_mutex_own());
  if (max_trx_id <= 0 || trx_id == TRX_ID_MAX) {
    return;
  }

  if (!g_rpl_conductor->trx_sys_max_id_inited() ||
      trx_sys_get_next_trx_id_or_no() <= trx_id) {
    trx_sys->next_trx_id_or_no.store(trx_id + 1);
    g_rpl_conductor->set_trx_sys_max_id_inited();
  }
}

void RplAssembly::clear_space_cache() {
  if (psmcli == nullptr) {
    ib_error() << "psmgr client not found";
    return;
  }
  for (auto space_id : deleteing_spaces) {
    psmcli->drop_space_cache(space_id);
    ib_info() << "drop space psmcli cache, space_id: " << space_id;
    //[[maybe_unused]] dberr_t err = fil_clear_both_maps_in_secondary(space_id);
  }
}

void RplAssembly::create_new_undo_spaces() {
  for (auto space_id : new_undo_spaces) {
    ib_info() << "apply create undo space: " << space_id;
    ut_ad(fsp_is_undo_tablespace(space_id));
    undo::Tablespace undo_space(space_id);
    undo::rpl_use_space_id(space_id);
    srv_undo_tablespace_open(undo_space);
  }
}

void RplAssembly::apply_metadata() { metadatas.rpl_apply(); }

PageHash *RplAssembly::get_page_hash(page_id_t page_id) {
  PageHash *slots_ptr = slots;
  if (!slots_ptr) {
    return nullptr;
  }
  uint64_t hash_val = page_id_hash(page_id);
  return &slots_ptr[hash_val % n_slots];
}

page_records_t *RplAssembly::get_page_records(page_id_t page_id) {
  uint64_t hash_val = page_id_hash(page_id);
  PageHash *slots_ptr = slots;
  if (!slots_ptr) {
    return nullptr;
  }
  PageHash *page_hash = &slots_ptr[hash_val % n_slots];
  if (page_hash != nullptr) {
    auto it = page_hash->m_pages.find(page_id_hash(page_id));
    if (it != page_hash->m_pages.end()) {
      ut_a(page_id.page_no() == it->second->page_no &&
           page_id.space() == it->second->space);
      return (it->second);
    }
  }
  return (nullptr);
}

void RplAssembly::add_record(mlog_id_t type, space_id_t space_id,
                             page_no_t page_no, byte *body, byte *rec_end,
                             lsn_t start_lsn, lsn_t end_lsn, 
                             const bool &ibuf_sec_index_page_modificiaton,
                             const ulint &ibuf_counter) {
  page_id_t page_id(space_id, page_no);
  PageHash *page_hash = get_page_hash(page_id);
  log_record_t *rpl_record =
      (log_record_t *)(page_hash->arena.Allocate(sizeof(log_record_t) + rec_end - body));

  rpl_record = new (rpl_record) log_record_t();
  rpl_record->type = type;
  rpl_record->end_lsn = end_lsn;
  rpl_record->ibuf_entry_counter = ibuf_sec_index_page_modificiaton ? ibuf_counter : ULINT_UNDEFINED;
  if ((mach_read_from_3(body - 3) & innodb::PAGE_CHECK_FLAGS)) {
    rpl_record->last_page_lsn =
        mach_read_from_8(rec_end + innodb::RECORD_CHECK_BITS_LEN);
  }
  ut_a(rec_end >= body);
  ut_a(end_lsn > start_lsn);
  if (!(mach_read_from_3(body - 3) & innodb::RECORD_CHECK_FLAGS)) {
    ut_a((mach_read_from_3(body - 3)) == (rec_end - body));
  }
  rpl_record->len = rec_end - body;
  ut_a(rpl_record->len < 2 * UNIV_PAGE_SIZE);
  std::memcpy(rpl_record->data, body, rpl_record->len);
  rpl_record->start_lsn = start_lsn;

  page_records_t *page_records = nullptr;

  page_hash_t hash_val = page_id_hash(page_id);
  Pages *pages = &(page_hash->m_pages);
  Pages::const_iterator it = pages->find(hash_val);
  if (it != pages->end()) {
    ut_a(page_id.page_no() == it->second->page_no &&
         page_id.space() == it->second->space);
    page_records = it->second;
  } else {
    /** aarch64 atomic need aligned memory */
    page_records = (page_records_t *)(page_hash->arena.AllocateAligned(sizeof(page_records_t)));
    new (page_records) page_records_t();
    page_records->n_record = 0;
    page_records->space = space_id;
    page_records->page_no = page_no;
    UT_LIST_INIT(page_records->rec_list_head);

    ut_a(UT_LIST_GET_LEN(page_records->rec_list_head) == 0);
    ut_a(page_records->n_record == 0);
    using value_type = Pages::value_type;
    pages->insert(it, value_type(page_id_hash(page_id), page_records));
  }

  UT_LIST_ADD_LAST(page_records->rec_list_head, rpl_record);
  page_records->n_record++;
  ut_a(UT_LIST_GET_LEN(page_records->rec_list_head) == page_records->n_record);
  record_count.fetch_add(1);
}

void RplAssembly::finish_parse() {
  state = AssemblyState::ASSEMBLY_STATE_PARSED;
}

void RplAssembly::finish_apply_low() {
  state = AssemblyState::ASSEMBLY_STATE_APPLIED;
}

void RplAssembly::finish_apply() {
  ut_a(record_count == 0);
  for (uint64_t i = 0; i < n_slots; i++) {
    ut_a(slots[i].state == PagehashState::PAGE_HASH_STATE_UNAPPLIED);
    slots[i].state = PagehashState::PAGE_HASH_STATE_APPLIED;
  }
  finish_apply_low();
}

void RplAssembly::update_record_range(lsn_t _start_lsn, lsn_t _end_lsn) {
  if (start_lsn == 0) {
    start_lsn = _start_lsn;
  }
  if (_end_lsn > end_lsn) {
    end_lsn = _end_lsn;
  }
}

void RplAssembly::apply_prepare() {
  LOG(TRACE) << "assembly apply prepare";

  ScopedLatencyRecorder _(&g_rpl_metric->apply_prepare);

  for (uint32_t i = 0; i < n_slots; i++) {
    ut_a(slots[i].state == PagehashState::PAGE_HASH_STATE_UNAPPLIED);
  }
  ut_a(state == AssemblyState::ASSEMBLY_STATE_PARSED);

  acquire_mdls();

  std::unordered_set<dict_index_t *> cluster_index_list;
  std::unordered_set<dict_index_t *> secondary_index_list;
  std::unordered_set<dict_table_t *> dict_tables;
  dict_sys_mutex_enter();
  for (auto &ti : indexes) {
    dict_index_t *index = nullptr;
    if (ti.second.m_space_id == 0 &&
        ti.second.m_index_id == DICT_IBUF_ID_MIN + IBUF_SPACE_ID) {
      index = ibuf->index;
    } else {
      index = const_cast<dict_index_t *>(dict_index_find(ti.first, ti.second));
    }
    if (index != nullptr) {
      if (index->is_clustered()) {
        cluster_index_list.insert(index);
      } else {
        secondary_index_list.insert(index);
      }
      auto table = index->table;
      dict_tables.insert(table);
    }
  }
  for (auto table : dict_tables) {
    table->acquire_with_lock();
    ut_a(table->get_ref_count() >= 1);
  }
  dict_sys_mutex_exit();

  mtr_t mtr;
  mtr_start(&mtr);
  for (auto index : secondary_index_list) {
    mtr_x_lock(dict_index_get_lock(index), &mtr, UT_LOCATION_HERE);
    index->version.store(end_lsn);
  }
  for (auto index : cluster_index_list) {
    mtr_x_lock(dict_index_get_lock(index), &mtr, UT_LOCATION_HERE);
    index->version.store(end_lsn);

#ifdef UNIV_DEBUG
    DBUG_EXECUTE_IF("rpl_apply_index_version_set", {
      // just for user created space
      if (index->space > 0 && index->space < 100) {
        const char act[] = "now SIGNAL rpl_apply_index_version_set";
        ut_ad(!debug_sync_set_action(current_thd, STRING_WITH_LEN(act)));
      }
    };);
#endif /*UNIV_DEBUG*/
  }

  state.store(AssemblyState::ASSEMBLY_STATE_PREPARED);
  TrxIds trx_commit_ids_to_erase;
  rpl_prepare_transaction_ids(trx_commit_ids_to_erase);
  rpl_add_trx_start_id_to_rw_list();
  g_rpl_conductor->advance_apply();
#ifdef UNIV_DEBUG
  DBUG_EXECUTE_IF("rpl_apply_wait_mvcc_view_to_open", {
    if (begin_trx_ids.size() > 0) {
      const char act[] =
          "now SIGNAL view_open_go_ahead  WAIT_FOR view_open_done";
      ut_ad(!debug_sync_set_action(current_thd, STRING_WITH_LEN(act)));
    }
  };);
#endif /*UNIV_DEBUG*/

  commit_transaction(trx_commit_ids_to_erase);
  if (max_trx_no > g_rpl_conductor->max_trx_no()) {
    g_rpl_conductor->set_max_trx_no(max_trx_no);
  }

  mtr_commit(&mtr);

  for (auto table : dict_tables) {
    table->lock();
    table->release();
    table->unlock();
  }
  create_new_undo_spaces();
  clear_space_cache();
  apply_metadata();
}

uint64_t RplAssembly::apply_materialize(buf_block_t *block) {
  ScopedLatencyRecorder _(&g_rpl_metric->apply_materialize);
  lsn_t target_lsn = end_lsn;
  ut_a(state == AssemblyState::ASSEMBLY_STATE_PREPARED ||
       state == AssemblyState::ASSEMBLY_STATE_APPLIED);

  page_records_t *page_records = get_page_records(block->page.id);
  auto block_applied_lsn = block->applied_lsn.load();
  if (block_applied_lsn >= target_lsn) {
    LOG(TRACE) << "page: " << block->page.id
               << " skip already applied assembly: " << lsn_range()
               << " applied_lsn: " << block_applied_lsn;
    return 0;
  }
  if (page_records == nullptr) {
    LOG(TRACE) << "page: " << block->page.id << " skip none record "
               << lsn_range();
    block->update_applied_lsn(end_lsn);
    return 0;
  }

  LOG(TRACE) << "page: " << block->page.id << " apply epoch " << epoch
             << " records " << lsn_range();
  mtr_t mtr;
  mtr_start(&mtr);
  mtr_set_log_mode(&mtr, MTR_LOG_NONE);
  page_t *page = block->frame;
  page_zip_des_t *page_zip = buf_block_get_page_zip(block);
  /* Read the newest modification lsn from the page */
  lsn_t page_lsn = mach_read_from_8(page + FIL_PAGE_LSN);

  uint64_t apply_count = 0;
  bool modification_to_page = false;
  lsn_t modification_start_lsn = 0;
  lsn_t modification_end_lsn = 0;
  ulint max_ibuf_merged_counter = ULINT_UNDEFINED;
  lsn_t max_ibuf_applied_lsn = 0;
  for (auto rpl_record = UT_LIST_GET_FIRST(page_records->rec_list_head);
       rpl_record != nullptr;
       rpl_record = UT_LIST_GET_NEXT(list_entry, rpl_record)) {
    byte *buf = ((byte *)(rpl_record->data));
    /* Ignore applying the redo logs for tablespace that is
    truncated. Truncated tablespaces are handled explicitly
    post-recovery, where we will restore the tablespace back
    to a normal state.

    Applying redo at this stage will cause problems because the
    redo will have action recorded on page before tablespace
    was re-inited and that would lead to a problem later. */
    if (rpl_record->start_lsn >= page_lsn) {
      apply_count++;
      if (!modification_to_page) {
        modification_to_page = true;
        modification_start_lsn = rpl_record->start_lsn;
      }
      if (rpl_record->type == MLOG_INIT_FILE_PAGE ||
          rpl_record->type == MLOG_INIT_FILE_PAGE2) {
        memset(FIL_PAGE_LSN + page, 0, 8);
        memset(UNIV_PAGE_SIZE - FIL_PAGE_END_LSN_OLD_CHKSUM + page, 0, 8);
        if (page_zip) {
          memset(FIL_PAGE_LSN + page_zip->data, 0, 8);
        }
        block->page.last_page_lsn = 0;
      }

      if (rpl_record->type == MLOG_GAIA_IBUF_MERGE_ENTRY_COUNTER) {
        LOG(TRACE) << "apply_materialize, ibuf merge end reset status, page_id:"<<block->page.id
                   << ", rpl_record->ibuf_entry_counter:"<< rpl_record->ibuf_entry_counter
                   << ", block->ibuf_merged_counter:"<< block->ibuf_merged_counter
                   << ", rpl_record->start_lsn:"<< rpl_record->start_lsn
                   << ", rpl_record->end_lsn:"<< rpl_record->end_lsn
                   << ", max_trx_id:"<< page_get_max_trx_id(buf_block_get_frame(block));
        block->ibuf_merged_counter = ULINT_UNDEFINED;
        max_ibuf_merged_counter = ULINT_UNDEFINED;
        continue;
      }

      // check last page lsn
      if (rpl_record->last_page_lsn != 0 &&
          rpl_record->last_page_lsn != block->page.last_page_lsn) {
        LOG(ERROR) << "page last lsn dismatch"
                   << ", expect_page_last_lsn: " << rpl_record->last_page_lsn
                   << ", real_page_last_lsn: " << block->page.last_page_lsn;
        ut_error;
      }

      if (rpl_record->ibuf_entry_counter != ULINT_UNDEFINED &&
          block->ibuf_merged_counter != ULINT_UNDEFINED &&
          rpl_record->ibuf_entry_counter <= block->ibuf_merged_counter) {
        LOG(TRACE) << "apply_materialize, skip apply for page_id:"<< block->page.id
                   << ", rpl_record->ibuf_entry_counter:"<< rpl_record->ibuf_entry_counter
                   << ", block->ibuf_merged_counter:"<< block->ibuf_merged_counter
                   << ", rpl_record->start_lsn:"<< rpl_record->start_lsn
                   << ", rpl_record->end_lsn:"<< rpl_record->end_lsn
                   << ", max_trx_id:"<< page_get_max_trx_id(buf_block_get_frame(block));
        max_ibuf_applied_lsn = rpl_record->end_lsn;
      } else {
        recv_parse_or_apply_log_rec_body(
          rpl_record->type, buf, buf + rpl_record->len, page_records->space,
          page_records->page_no, block, &mtr, ULINT_UNDEFINED, rpl_record->start_lsn);
        if (rpl_record->ibuf_entry_counter != ULINT_UNDEFINED) {
          LOG(TRACE) << "apply_materialize, apply ibuf merge for  page_id:"<< block->page.id
                     << ", rpl_record->ibuf_entry_counter:"<< rpl_record->ibuf_entry_counter
                     << ", block->ibuf_merged_counter:"<< block->ibuf_merged_counter
                     << ", rpl_record->start_lsn:"<< rpl_record->start_lsn
                     << ", rpl_record->end_lsn:"<< rpl_record->end_lsn
                     << ", max_trx_id:"<< page_get_max_trx_id(buf_block_get_frame(block));
          //there are cases that one ibuf entry merge may produce several records for the same secondary index page in one mtr
          //which means these records share the same ibuf entry counter, once the apply start, we can not skip the apply anymore 
          //so use max_ibuf_merged_counter to track it and assign it back to  block->ibuf_merged_counter at the end of matrialize
          max_ibuf_merged_counter = rpl_record->ibuf_entry_counter;
          max_ibuf_applied_lsn = rpl_record->end_lsn;
        }
      }

      lsn_t end_lsn = rpl_record->end_lsn;
      block->page.last_page_lsn = end_lsn;
      mach_write_to_8(FIL_PAGE_LSN + page, end_lsn);
      mach_write_to_8(UNIV_PAGE_SIZE - FIL_PAGE_END_LSN_OLD_CHKSUM + page,
                      end_lsn);
      if (page_zip) {
        mach_write_to_8(FIL_PAGE_LSN + page_zip->data, end_lsn);
      }
    }
    modification_end_lsn = rpl_record->end_lsn;
  }

  if (max_ibuf_merged_counter != ULINT_UNDEFINED && 
      block->ibuf_merged_counter < max_ibuf_merged_counter) {
    block->ibuf_merged_counter = max_ibuf_merged_counter;
  }
  
  if(max_ibuf_applied_lsn != 0 && max_ibuf_applied_lsn > block->ibuf_merged_lsn.load()) {
    block->update_ibuf_merged_lsn(max_ibuf_applied_lsn);;
  }
  if (modification_to_page) {
    buf_flush_recv_note_modification(block, modification_start_lsn,
                                     modification_end_lsn);
  }
  /* Make sure that committing mtr does not change the modification
  LSN values of page */
  mtr.discard_modifications();
  mtr_commit(&mtr);
  block->update_applied_lsn(end_lsn);

#ifdef ENABLED_GAIADB_PAGE_VALIDATION
  byte buf[65536];  // maximum page size 64KB
  page_id_t page_id = block->page.id;
  page_size_t page_size = block->page.size;
  auto err = RbioClient::get_instance().get_page(
      page_server::RbioRequest_Type_READ_SYNC, page_id, page_size, buf, block,
      true, false, 0, nullptr end_lsn);
  ut_a(err == DB_SUCCESS);
  ib_uint32_t header_chksum = mach_read_from_4(buf + FIL_PAGE_SPACE_OR_CHKSUM);
  ib_uint32_t tailer_chksum =
      mach_read_from_4(buf + page_size.logical() - FIL_PAGE_END_LSN_OLD_CHKSUM);
  if (header_chksum != tailer_chksum) {
    ib_error(ER_IB_GAIA_MSG_RPL)
        << "page validation failed, got corrupted page form ps for space_id="
        << page_id.space() << ", page_no=" << page_id.page_no();
    return apply_count;
  }

  ib_uint32_t chksum = buf_calc_page_crc32_exclude_fil_page_lsn(
      buf_block_get_frame(block), page_size.logical());
  ib_uint32_t ps_chksum =
      buf_calc_page_crc32_exclude_fil_page_lsn(buf, page_size.logical());

  if (chksum != ps_chksum) {
    ib_error(ER_IB_GAIA_MSG_RPL)
        << "page validation failed for space_id=" << page_id.space()
        << ", page_no=" << page_id.page_no() << ", vlsn=" << end_lsn
        << ", cmp chksum =" << chksum << ", ps calc_chksum =" << ps_chksum
        << ", vdl=" << g_rpl_conductor->apply_lsn();

    std::string nam = "=====secondary===";
    debug_for_buf_hexdump(nam.c_str(), buf_block_get_frame(block),
                          page_size.logical());
    std::string nam1 = "=====page server====";
    debug_for_buf_hexdump(nam1.c_str(), buf, page_size.logical());
  }
#endif /* ENABLED_GAIADB_PAGE_VALIDATION */

  return apply_count;
}

void RplAssembly::apply_commit() {
  LOG(TRACE) << "assembly apply commit";
  ScopedLatencyRecorder _(&g_rpl_metric->apply_commit);
  release_mdls();
  reload_meta();
  update_table_stats();
  apply_rpl_msgs();
}

void RplAssembly::wait_for_all_slot_materialized() {
  PageHash *slots_ptr = slots;
  do {
    uint32_t finish_count = 0;
    for (uint64_t i = 0; i < n_slots; ++i) {
      if (slots_ptr[i].state != PagehashState::PAGE_HASH_STATE_APPLIED) {
        break;
      }
      finish_count++;
    }
    if (finish_count == n_slots) {
      break;
    }
    LOG_EVERY_SECOND(TRACE)
        << "apply batch: " << lsn_range()
        << " wait for all slot finish apply, finish_count: " << finish_count;
    std::this_thread::sleep_for(std::chrono::microseconds(100));
  } while (!rpl_sys->should_stop());

  //state = AssemblyState::ASSEMBLY_STATE_APPLIED;
}

void RplAssembly::apply_slot(uint64_t slot_id) {
  static bvar::LatencyRecorder slot_apply_lat("cmp_rpl_apply_slot");
  ScopedLatencyRecorder _(&slot_apply_lat);
  PageHash *slot = &(slots[slot_id]);
  if (slot->state == PagehashState::PAGE_HASH_STATE_APPLIED) {
    return;
  }
  ut_a(slot->state == PagehashState::PAGE_HASH_STATE_UNAPPLIED);

  LOG(TRACE) << "assembly epoch: " << epoch.load() << " " << lsn_range()
             << " apply_slot " << slot_id;
  for (auto pages : slot->m_pages) {
    bool found = false;
    const page_id_t page_id(pages.second->space, pages.second->page_no);
    bool is_force = srv_gaia_enable_hot_backup && page_id.page_no() == 0;
    const page_size_t page_size =
        secondary_fil_space_get_page_size(pages.second->space, is_force, &found);
    if (found) {
#ifndef ENABLED_GAIADB_PAGE_VALIDATION
      if (buf_page_peek(page_id) || is_force) {
#endif /* ENABLED_GAIADB_PAGE_VALIDATION */
        mtr_t mtr;
        mtr_start(&mtr);
        buf_block_t *block = nullptr;
        {
          static bvar::LatencyRecorder bp_get("cmp_rpl_apply_page_get");
          ScopedLatencyRecorder bp_get_lat(&bp_get);
          block = buf_page_get(page_id, page_size, RW_X_LATCH, UT_LOCATION_HERE, &mtr);
        }
        RplMaterializer::apply_page(block, this);
        mtr_commit(&mtr);
#ifndef ENABLED_GAIADB_PAGE_VALIDATION
      } else {
        LOG(TRACE) << "page: " << page_id << " skip apply " << lsn_range()
                   << ", record_count: " << record_count;
      }
#endif /* ENABLED_GAIADB_PAGE_VALIDATION */
    } else {
      // !found and is_force
      if (is_force) {
        // If current space is NOT found in secondary compute node
        // and primary compute node modified page 0 of this space,
        // we need to drop local space cache of psmcli.
        psmcli->drop_space_cache(pages.second->space);
      }
    }
  }
  slot->state = PagehashState::PAGE_HASH_STATE_APPLIED;
  LOG(TRACE) << "assembly epoch: " << epoch.load() << " " << lsn_range()
             << " apply_slot " << slot_id << " finish";
}

}  // namespace rpl
