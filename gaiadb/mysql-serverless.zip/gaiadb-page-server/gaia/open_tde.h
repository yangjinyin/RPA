/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/open_tde.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class OpenTDE : public Command {
public:
    OpenTDE() {
        SetName("open-tde");
        SetDesc("open TDE encryption in manager");
        SetDescCn("在管理服务中开启 TDE 加密");

        AddPsmClusterOption();
        AddRequiredArgOption("version", &_long_opt_val, kOptMax + 1, "encryption info version", kuint32_t);
        AddRequiredArgOption("encryption-key", &_long_opt_val, kOptMax + 2, "encryption key", kstring);
        AddRequiredArgOption("encryption-iv", &_long_opt_val, kOptMax + 3, "encryption iv", kstring);
        AddRequiredArgOption("encryption-alg", &_long_opt_val, kOptMax + 4,
                "encryption algorithm: aes_ctr or sm4_ctr", kstring);

        AddExample("--manager-address \"bns://xxx\" --version 1 --encryption-key 1234567890123456 --encryption-iv 1234567890123456");
        AddExample("--manager-address \"bns://xxx\" --version 1 --encryption-key 1234567890123456 --encryption-iv 1234567890123456 --encryption-alg aes_ctr");
    }
    virtual ~OpenTDE() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _version.Set(std::strtoul(opt, NULL, 10));
                break;
            case kOptMax + 2:
                _encryption_key = opt;
                break;
            case kOptMax + 3:
                _encryption_iv = opt;
                break;
            case kOptMax + 4:
                _encryption_alg = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::OpenTDEResponse& rsp);

private:
    std::string _manager_address {};
    VarOptional<uint32_t> _version;
    std::string _encryption_key {};
    std::string _encryption_iv {};
    std::string _encryption_alg {};
};

}
}
