/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/compress.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/compress_context.h"
#include "psvr/compress_utils.h"
#include "psvr/control.h"
#include "psvr/page_op.h"

namespace psvr {

constexpr static uint64_t kStoreCompressInterval = second2microseconds(3ul);
constexpr static uint32_t kScheduleTaskThreadNum = 1;

static double get_compress_rate_from_this(void* arg) {
    return static_cast<Compressor*>(arg)->GetCompressRate();
}

bool operator>=(std::shared_ptr<FlowQuota> quota, Compressor::Context* ctx) {
    uint64_t fragment_size = gaia_apply::FLAGS_univ_page_size;
    if (ctx->quota_size > 0) {
        fragment_size = ctx->quota_size;
    }
    return quota->GetQuota(fragment_size) == 0;
}

static const char* action2str(Compressor::Action action) {
    switch (action) {
    case Compressor::Action::kCalcPriority:
        return "kCalcPriority";
    case Compressor::Action::kStoreCompress:
        return "kStoreCompress";
    case Compressor::Action::kCompressSegment:
        return "kCompressSegment";
    case Compressor::Action::kCalcPriorityForFreeExtent:
        return "kCalcPriorityForFreeExtent";
    case Compressor::Action::kTrimFreeExtent:
        return "kTrimFreeExtent";
    default:
        return "unknown";
    }
}

Compressor::Compressor(ClientPtr client, ControlWeakPtr control)
    : Model<Compressor>(client, control),
    _thread_num(1 + kScheduleTaskThreadNum),
    _stat_compress_segment_lat(kSlaWindowSize),
    _stat_compress_segment_rate(get_compress_rate_from_this, this),
    _stat_compress_segment_size(kSlaWindowSize),
    _stat_compress_segment_valid_page_size(kSlaWindowSize),
    _stat_compress_page_lat(kSlaWindowSize),
    _stat_trim_free_extent_lat(kSlaWindowSize),
    _stat_compress_page_error_count(kSlaWindowSize),
    _stat_compress_interrupt_by_quota_count(kSlaWindowSize) {
    _thread_pool.reset(new ThreadPoolType);
    _quota_thread.reset(new QuotaThreadType);
    Expose();
}

void Compressor::Expose() {
#ifndef GTEST
    _stat_compress_segment_lat.expose_as("psvr", "compress_segment_cost");
    _stat_compress_segment_rate.expose_as("psvr", "compress_segment_rate");
    _stat_compress_segment_size.expose_as("psvr", "compress_segment_size_mb");
    _stat_compress_segment_valid_page_size.expose_as("psvr", "compress_segment_valid_page_size");
    _stat_compress_page_lat.expose_as("psvr", "compress_segment_page_cost");
    _stat_trim_free_extent_lat.expose_as("psvr", "trim_free_extent_cost");
    _stat_compress_page_error_count.expose_as("psvr", "compress_segment_page_error_count");
    _stat_compress_interrupt_by_quota_count.expose_as("psvr", "compress_interrupt_by_quota_count");
#endif
}

bool Compressor::SetUp() {
    ControlPtr control = _control.lock();
    if (!control) {
        LOG(ERROR) << "failed, control is release";
        return false;
    }
    if (FLAGS_multi_psvr_compress_thread_num > 0) {
        _thread_num = std::min(static_cast<uint32_t>(FLAGS_multi_psvr_compress_thread_num), _store_count);
    } else {
        _thread_num = _store_count;
    }

    _flow.reset(new FlowQuota("psvr_compress_flow_quota_total_used", &FLAGS_psvr_compress_max_speed, true));
    _stores.reserve(_store_count);
    for (uint32_t i = 0; i < _store_count; ++i) {
        auto store = std::make_shared<Store>(i);
        store->task_quota = std::make_shared<Quota>(
                base::string_printf("psvr_compress_store_task_%d_quota_total_remain", i),
                &FLAGS_psvr_compress_store_inflight_num);
        store->flow_quota = std::make_shared<FlowQuota>(
                base::string_printf("psvr_compress_store_%u_flow_quota_total_used", i),
                &FLAGS_psvr_compress_store_max_speed);
        _stores.emplace_back(store);
    }

    typename QuotaThreadType::Fn quota_fn
        = std::bind(&Compressor::OnGetQuota, this, std::placeholders::_1);
    _quota_thread->Start("compress_quota", quota_fn, &FLAGS_psvr_compress_wait_quota_sleep_interval_us);

    _trim_free_extent_task.reset(new TrimFreeExtentTask(_store_count));

    typename ThreadPoolType::TaskFn fn
        = std::bind(&Compressor::OnCompletion, this, std::placeholders::_1);
    if (!_thread_pool->Start("compress", control->timer(), _thread_num + kScheduleTaskThreadNum, fn)) {
        LOG(ERROR) << "compress thread pool start failed";
        return false;
    }
    return true;
}

bool Compressor::PrepareTask() {
    for (uint32_t i = 0; i < _store_count; ++i) {
        auto ctx = new Context(Action::kCalcPriority, static_cast<int32_t>(i));
        ctx->fix_client_id = 0;
        Schedule(ctx TRACE_FILE_LINE_CC,
                second2microseconds(FLAGS_psvr_compress_calc_priority_interval_second + i));

        auto ctx2 = new Context(Action::kStoreCompress, static_cast<int32_t>(i));
        ctx2->fix_client_id = 0;
        Schedule(ctx2 TRACE_FILE_LINE_CC, kStoreCompressInterval + second2microseconds(i));
    }

    {
        auto ctx = new Context(Action::kCalcPriorityForFreeExtent);
        ctx->fix_client_id = 0;
        Schedule(ctx TRACE_FILE_LINE_CC,
                second2microseconds(FLAGS_psvr_trim_free_extent_calc_priority_interval_second));
    }
    return true;
}

void Compressor::TearDown() {
    LOG(NOTICE) << "compress manager will stop ...";
    _quota_thread->Stop(false);
    _thread_pool->Stop(false);
    if (_flow) {
        _flow->hide();
    }
    for (uint32_t i = 0; i < _stores.size(); ++i) {
        _stores[i]->flow_quota->hide();
    }
    _stat_compress_segment_lat.hide();
    _stat_compress_segment_rate.hide();
    _stat_compress_segment_size.hide();
    _stat_compress_segment_valid_page_size.hide();
    _stat_compress_page_lat.hide();
    _stat_trim_free_extent_lat.hide();
    _stat_compress_page_error_count.hide();
    _stat_compress_interrupt_by_quota_count.hide();
}

void Compressor::Join() {
    LOG(NOTICE) << "compress manager will join ...";
    _quota_thread->Stop(true);
    _thread_pool->Stop(true);
    LOG(NOTICE) << "compress manager will join ok";
}

bool Compressor::IncOrDecThreadNum() {
    uint32_t cfg_n = FLAGS_multi_psvr_compress_thread_num;
    cfg_n = std::min(cfg_n, _store_count);
    uint32_t cur_n = IncOrDecSingleThreadNum(_thread_num, cfg_n, _thread_pool,
            [this](Context* ctx){
                Schedule(ctx TRACE_FILE_LINE_CC);
            });
    LOG_IF(NOTICE, cfg_n != cur_n) << "compress manager thread num changed,"
        << " old:[" << cur_n
        << "] new:[" << cfg_n
        << "]";
    return cfg_n != cur_n;
}

bool Compressor::Execute(Context* ctx) {
    if (!_thread_pool->EmergentExecute(ctx)) {
        if (_stopped) {
            std::unique_ptr<Context> ctx_guard(ctx);
        } else {
            psvr_terminate();
        }
        return false;
    }
    return true;
}

double Compressor::GetStoreCompressRate(int32_t store_id) {
    if (!_stopped && store_id >= 0 && static_cast<size_t>(store_id) < _stores.size()) {
        return _stores[store_id]->compress_rate;
    }
    return 0.0;
}

double Compressor::GetCompressRate() {
    double rate = 0.0;
    if (!_stopped) {
        for (auto& store_task : _stores) {
            rate += store_task->compress_rate;
        }
    }
    return rate;
}

void Compressor::GetTasks(pspb::ListCompressSegmentResponse* response) {
    for (auto& store : _stores) {
        std::shared_lock slk(store->shared_mutex);
        for (auto& task : store->compress_tasks) {
            SegmentPtr seg = task->segment.lock();
            if (seg) {
                auto pb = response->add_segments();
                pb->set_cluster_id(seg->cluster_id());
                pb->set_segment_id(seg->segment_id());
                pb->set_size(task->size);
                pb->set_offset(task->offset);
                pb->set_store_id(seg->store_id());
            }
        }
    }
}

bool Compressor::AddSegmentToCompressList(SegmentPtr segment, bool is_prior) {
    std::shared_ptr<Store> store = _stores[segment->store_id()];
    std::unique_lock lk(store->shared_mutex);
    auto it = std::find_if(store->compress_tasks.begin(), store->compress_tasks.end(),
            [segment](std::shared_ptr<Task> task){
                return (task->segment.lock() == segment);
            });
    if (it != store->compress_tasks.end()) {
        LOG(TRACE) << segment << " in compress list";
        return false;
    }
    if (is_prior) {
        store->compress_tasks.emplace_front(std::make_shared<Task>(segment));
    } else {
        store->compress_tasks.emplace_back(std::make_shared<Task>(segment));
    }
    LOG(TRACE) << segment << " add in compress list";
    return true;
}

bool Compressor::DropSegmentFromCompressList(SegmentPtr segment) {
    std::shared_ptr<Store> store = _stores[segment->store_id()];
    std::unique_lock lk(store->shared_mutex);
    auto it = std::find_if(store->compress_tasks.begin(), store->compress_tasks.end(),
            [segment](std::shared_ptr<Task> task){
                return (task->segment.lock() == segment);
            });
    if (it == store->compress_tasks.end()) {
        LOG(TRACE) << segment << " not in compress list";
        return false;
    }
    (*it)->segment.reset();     // only release shared_ptr
    return true;
}

void Compressor::SetCtxClientId(Context* ctx) {
    static std::atomic<uint32_t> round_robin_id = 0;
    if (ctx->fix_client_id) {
        ctx->client_id = ctx->fix_client_id;
        return;
    }
    if (ctx->compress_task) {
        if (auto segment = ctx->compress_task->segment.lock(); segment) {
            ctx->client_id = segment->store_id() % _thread_num;
            return;
        }
    }
    auto idx = round_robin_id.fetch_add(1, std::memory_order_relaxed);
    ctx->client_id = idx % _thread_num;
}

void Compressor::Schedule(Context* ctx TRACE_FILE_LINE_DC,
        uint64_t delay_us, bool is_retry) {
    PSVR_LOG_CTX(TRACE, ctx) << "ctx action:[" << static_cast<uint32_t>(ctx->action)
        << "," << action2str(ctx->action)
        << "] retry_times:[" << ctx->retry_times
        << "] ctx:[" << ctx
        << "]" << TRACE_FILE_LINE_LOG_STR;
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }
    SetCtxClientId(ctx);
    if (is_retry) {
        ++ctx->retry_times;
    }
    if (delay_us == 0) {
        if (_thread_pool->Execute(ctx)) {
            return;
        }
    } else {
        if (_thread_pool->Schedule(ctx, delay_us)) {
            return;
        }
    }

    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }

    PSVR_LOG_CTX(ERROR, ctx) << "dispatch segment to compress pool failed,"
        << TRACE_FILE_LINE_LOG_STR;
    psvr_terminate();
}

void Compressor::OnCompletion(Context* ctx) {
    PSVR_LOG_CTX(TRACE, ctx) << "ctx action:[" << static_cast<uint32_t>(ctx->action)
        << "," << action2str(ctx->action)
        << "] retry_times:[" << ctx->retry_times
        << "] ctx:[" << ctx
        << "]";
    if (BAIDU_UNLIKELY(_stopped)) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }
    switch (ctx->action) {
    case Action::kCalcPriority:
        return CalcPriority(ctx);
    case Action::kStoreCompress:
        return StoreCompress(ctx);
    case Action::kCompressSegment:
        return CompressSegment(ctx);
    case Action::kCalcPriorityForFreeExtent:
        return CalcPriorityForFreeExtent(ctx);
    case Action::kTrimFreeExtent:
        return TrimFreeExtent(ctx);
    default:
        PSVR_ASSERT(false);
    }
}

void Compressor::CalcPriority(Context* ctx) {
    define_control_or_return_invalid(ctx);
    const int32_t store_id = ctx->store_id;
    std::shared_ptr<Store> store = _stores[store_id];
    size_t remain_task_size = 0;
    if (!FLAGS_psvr_enable_compression) {
        Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(FLAGS_psvr_compress_calc_priority_interval_second));
        return;
    }
    if (FLAGS_psvr_enable_append_file && FLAGS_psvr_dblwr_max_page_num > 0) {
        Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(FLAGS_psvr_compress_calc_priority_interval_second));
        return;
    }
    if (FLAGS_psvr_compress_store_max_task_num > 0) {
        std::shared_lock slk(store->shared_mutex);
        if (store->compress_tasks.size() >= FLAGS_psvr_compress_store_max_task_num) {
            Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(FLAGS_psvr_compress_calc_priority_interval_second));
            return;
        }
        remain_task_size = FLAGS_psvr_compress_store_max_task_num - store->compress_tasks.size();
    }
    std::vector<SegmentPtr> segments;
    control->segment_manager()->GetStoreSegments(store_id, &segments);
    if (segments.empty()) {
        Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(FLAGS_psvr_compress_calc_priority_interval_second));
        return;
    }

    LOG(TRACE) << "get store segments,"
        << " store_id:[" << store_id
        << " size:[" << segments.size()
        << "]";
    int64_t store_non_empty_page_count = 0;
    int64_t store_compress_data_size = 0;
    for (auto& segment : segments) {
        segment->UpdateStatCompress(store_non_empty_page_count, store_compress_data_size);
    }

    double store_compress_rate = 0.0;
    if (store_compress_data_size > 0 && store_non_empty_page_count > 0) {
        /* rate = real_size / compress_size */
        store_compress_rate = (store_non_empty_page_count * gaia_physical_page_size() * 1.0) / store_compress_data_size;
    }
    store->compress_rate = store_compress_rate;

    std::sort(segments.begin(), segments.end(), [](SegmentPtr lhs, SegmentPtr rhs) {
            const auto& lhs_st = lhs->stat_compress();
            const auto& rhs_st = rhs->stat_compress();
            if (lhs_st.sort_last_compress_time_s != rhs_st.sort_last_compress_time_s) {
                return lhs_st.sort_last_compress_time_s < rhs_st.sort_last_compress_time_s;
            } else if (lhs_st.sort_data_size_mb != rhs_st.sort_data_size_mb) {
                return lhs_st.sort_data_size_mb > rhs_st.sort_data_size_mb;
            } else if (lhs_st.sort_update_extent_num != rhs_st.sort_update_extent_num) {
                return lhs_st.sort_update_extent_num < rhs_st.sort_update_extent_num;
            } else if (lhs_st.sort_drop_space_num != rhs_st.sort_drop_space_num) {
                return lhs_st.sort_drop_space_num > rhs_st.sort_drop_space_num;
            } else {
                return lhs_st.sort_compress_times < rhs_st.sort_compress_times;
            }
        });

    for (size_t i = 0; i < segments.size() && !_stopped && remain_task_size > 0; ++i) {
        auto segment = segments[i];
        const auto& st = segment->stat_compress();
        if (segment->in_recovery()) {
            LOG(TRACE) << segment << " in recovery, ignore compression";
            continue;
        }
        if (!segment_is_valid(segment) || !segment->is_active()) {
            LOG(TRACE) << segment << " invalid or not active, ignore compression";
            continue;
        }
        if (st.sort_data_size_mb <= 1ul) {
            LOG(TRACE) << segment << " data size small, ignore compression";
            continue;
        }
        if (!st.data_updated) {
            if (FLAGS_psvr_recover_enable_check && st.compress_times > 0) {
                LOG(TRACE) << segment << " data not changed and enable check data, ignore compression";
                continue;
            } else if (!FLAGS_psvr_recover_enable_check
                    && st.last_compress_time_s + FLAGS_psvr_recover_check_interval >= base::gettimeofday_s()) {
                LOG(TRACE) << segment << " data not changed and within in validity period of the inspection, ignore compression";
                continue;
            }
        }
        if (st.sort_update_extent_num >= static_cast<int32_t>((segment->segment_size() / MBToByte(1ul)) * 0.4)) {
            LOG(TRACE) << segment << " update page frequently, ignore compression";
            continue;
        }
        if (FLAGS_psvr_compress_segment_min_interval_second > 0
                && st.last_compress_time_s > 0
                && base::gettimeofday_s() < FLAGS_psvr_compress_segment_min_interval_second + st.last_compress_time_s) {
            LOG(TRACE) << segment << " last compress time still valid, ignore compression";
            continue;
        }
        if (AddSegmentToCompressList(segment, false)) {
            --remain_task_size;
        }
    }

    Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(FLAGS_psvr_compress_calc_priority_interval_second));
}

void Compressor::StoreCompress(Context* ctx) {
    const int32_t store_id = ctx->store_id;
    std::shared_ptr<Store> store = _stores[store_id];

    if (store->task_quota->remain() <= 0) {
        LOG(TRACE) << "no quota to compress, store:[" << store_id << "]";
        Schedule(ctx TRACE_FILE_LINE_CC, kStoreCompressInterval);
        return;
    }

    std::unique_lock lk(store->shared_mutex);
    for (auto it = store->compress_tasks.begin();
            it != store->compress_tasks.end() && !_stopped; ) {
        std::shared_ptr<Task> task = *it;
        SegmentPtr segment = task->segment.lock();
        if (!segment_is_valid(segment)) {
            it = store->compress_tasks.erase(it);
            LOG(TRACE) << "invalid a segment";
            continue;
        }
        ++it;
        if (task->running) {
            LOG(TRACE) << segment << " in running";
            continue;
        }

        if (!store->task_quota->Acquire(1)) {
            LOG(TRACE) << "no quota to compress, store:[" << store_id << "]";
            break;
        } else {
            task->running = true;
            auto compress_ctx = new Context(Action::kCompressSegment, store_id);
            compress_ctx->shift_client_id = kScheduleTaskThreadNum;
            compress_ctx->compress_task = task;
            compress_ctx->stat_timer.reset();
            LOG(NOTICE) << segment << " start to comrpess";
            Schedule(compress_ctx TRACE_FILE_LINE_CC);
            break; // only schedule one task
        }
    }

    Schedule(ctx TRACE_FILE_LINE_CC, kStoreCompressInterval);
}

bool Compressor::CheckQuota(Context* ctx, int32_t store_id) {
    if (!_quota_thread->GetQuota(ctx, _flow)) {
        return false;
    }
    return _quota_thread->GetQuota(ctx, _stores[store_id]->flow_quota);
}

void Compressor::OnGetQuota(Context* ctx) {
    ctx->has_quota = true;
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void Compressor::OnEvent(Context* ctx, uint32_t space_id) {
    if (ctx->st.code() != pspb::Status_ReturnCode_SUCCESS) {
        LOG_EVERY_N(WARNING, 64) << "compress get space meta failed,"
            << " space_id:[" << space_id
            << "] " << ctx->st;
        Schedule(ctx TRACE_FILE_LINE_CC, millisecond2microseconds(50lu), true);
    } else {
        ctx->retry_times = 0;
        Schedule(ctx TRACE_FILE_LINE_CC);
    }
}

void Compressor::FinishCompressSegment(Context* ctx, bool succ) {
    std::unique_ptr<Context> ctx_guard(ctx);
    const int32_t store_id = ctx->store_id;
    std::shared_ptr<Task> compress_task = ctx->compress_task;
    std::shared_ptr<Store> store = _stores[store_id];

    {
        std::unique_lock lk(store->shared_mutex);
        for (auto it = store->compress_tasks.begin(); it != store->compress_tasks.end(); ++it) {
            if (*it == compress_task) {
                store->compress_tasks.erase(it);
                break;
            }
            if (_stopped) {
                return;
            }
        }
    }
    // release store quota
    store->task_quota->Release(1);
    // update segment if exists
    SegmentPtr segment = compress_task->segment.lock();
    if (segment_is_valid(segment)) {
        segment->CompressFinish(succ, ctx->segment_non_empty_page_count, ctx->segment_compress_data_size);
        if (succ) {
            segment->UpdateDBSize();
            ctx->segment_compress_after_size = segment->segment_physical_size();
            LOG(NOTICE) << segment << " finish compression,"
                << " before_size:[" << ctx->segment_compress_before_size
                << "] after_size:[" << ctx->segment_compress_after_size
                << "] page_total_num:[" << ctx->segment_page_count
                << "] compress_page_num:[" << ctx->segment_valid_compress_page_count
                << "] compressed_page_num:[" << ctx->segment_compressed_page_count
                << "] trim_page_num:[" << ctx->segment_trim_page_count
                << "] empty_page_num:[" << ctx->segment_empty_page_count
                << "] non_empty_page_num:[" << ctx->segment_non_empty_page_count
                << "] compress_data_size:[" << ctx->segment_compress_data_size
                << "] compress_rate:["
                << (ctx->segment_compress_data_size > 0 ?
                        (1.0 * ctx->segment_non_empty_page_count * gaia_physical_page_size() / ctx->segment_compress_data_size) :
                        0.0)
                << "] use_time_s:[" << ctx->stat_timer.s_elapsed()
                << "] interrupt_by_quota_count:[" << ctx->interrupt_by_quota_count
                << "] interrupt_by_meta_count:[" << ctx->interrupt_by_meta_count
                << "] interrupt_by_other_count:[" << ctx->interrupt_by_other_count
                << "] interrupt_by_io_count:[" << ctx->interrupt_by_io_count
                << "]";
            _stat_compress_segment_lat << ctx->stat_timer.s_elapsed();
            _stat_compress_segment_size << ToMB(ctx->segment_compress_before_size - ctx->segment_compress_after_size);
            _stat_compress_segment_valid_page_size << ctx->segment_valid_compress_page_count;
        }
    }
}

void Compressor::CompressSegment(Context* ctx) {
    define_control_or_return_invalid(ctx);
    PSVR_ASSERT(!!ctx->compress_task);

    if (!FLAGS_psvr_enable_compression) {
        FinishCompressSegment(ctx, false);
        return;
    }
    if (FLAGS_psvr_enable_append_file && FLAGS_psvr_dblwr_max_page_num > 0) {
        FinishCompressSegment(ctx, false);
        return;
    }

    const uint64_t fragment_size = gaia_apply::FLAGS_univ_page_size;
    thread_local BufBlockPtr tl_buf_block = nullptr;
    if (!tl_buf_block) {
        tl_buf_block = control->buf_pool()->AllocBufBlock(fragment_size);
    }
    if (!tl_buf_block) {
        LOG(ERROR) << "alloc buf failed, size:[" << fragment_size << "]";
        Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(1ul));
        return;
    }

    std::shared_ptr<Task> compress_task = ctx->compress_task;
    SegmentPtr segment = compress_task->segment.lock();
    if (!segment_is_valid(segment)) {
        LOG(NOTICE) << "compression task object inactive, ignore it";
        FinishCompressSegment(ctx, false);
        return;
    }

    bool status = false;
    bool is_force = false;
    segment->GetRecoveryStatus(&status, &is_force);
    if (status) {
        LOG(NOTICE) << segment << " in recovery or checking data, ignore it";
        FinishCompressSegment(ctx, false);
        return;
    }

    if (!FLAGS_psvr_enable_compression) {
        LOG(NOTICE) << segment << " global compression is disabled, ignore it";
        FinishCompressSegment(ctx, false);
        return;
    }

    pspb::CompressConfig cfg;
    segment->GetCompressConfig(&cfg);
    if (!cfg.enable()) {
        LOG(NOTICE) << segment << " compression is disabled, ignore it";
        FinishCompressSegment(ctx, false);
        return;
    }

    if (segment->stat_compress().sort_update_extent_num
            >= static_cast<int32_t>((segment->segment_size() / MBToByte(1ul)) * 0.4)) {
        LOG(NOTICE) << segment << " update frequently, interrupt it";
        FinishCompressSegment(ctx, false);
        return;
    }

    const uint64_t offset = compress_task->offset;
    if (offset == 0) {
        LOG(NOTICE) << segment << " start to compress data";
        segment->UpdateDBSize();
        ctx->segment_compress_before_size = segment->segment_physical_size();
    } else if (offset >= compress_task->size) {
        LOG(TRACE) << segment << " finish compress";
        FinishCompressSegment(ctx, true);
        return;
    }

    PSVR_ASSERT(offset + fragment_size <= compress_task->size);
    const int32_t store_id = segment->store_id();
    if (!ctx->has_quota) {
        if (!CheckQuota(ctx, store_id)) {
            _stat_compress_interrupt_by_quota_count << 1;
            ++ctx->interrupt_by_quota_count;
            return;
        }
    }

    TimerGuard timer_compress_page(_stat_compress_page_lat);
    const uint64_t log_id = get_log_id();
    const uint64_t physical_page_no = offset / fragment_size;
    db::Status st(db::Code::kInvalid);
    do {
        db::PageLockPtr page_lock = segment->GetPageLock(physical_page_no);
        db::PageUniqueLock lk(page_lock, std::try_to_lock);
        if (!lk) {
            ++ctx->interrupt_by_other_count;
            Schedule(ctx TRACE_FILE_LINE_CC, millisecond2microseconds(50ul), false);
            return;
        }

        bool is_compressed = false;
        uint64_t real_write_size = fragment_size;
        st = segment->ReadPhysicalPageData(log_id, offset, fragment_size,
                tl_buf_block->frame, &is_compressed, &real_write_size);
        if (!st.IsOk()) {
            ++ctx->interrupt_by_io_count;
            LOG(ERROR) << segment << " read physical data failed in compression,"
                << " offset:[" << offset
                << "] size:[" << fragment_size
                << "] " << st;
            break;
        }

        bool local_is_empty = false;
        if (page_is_corrupted(tl_buf_block->frame, fragment_size, &local_is_empty)) {
            st.Reset(db::Code::kCorrupted, "page data corrupted");
        }
        if (!st.IsOk()) {
            ++ctx->interrupt_by_io_count;
            LOG(ERROR) << segment << " physical data is corrupted in compression,"
                << " offset:[" << offset
                << "] size:[" << fragment_size
                << "] is_empty:[" << local_is_empty
                << "] " << st;
            break;
        }

        const gaia_apply::space_id_t local_space_id = buf_block_get_space_id(tl_buf_block);
        const gaia_apply::page_no_t local_page_no = buf_block_get_page_no(tl_buf_block);
        if (local_is_empty) {
            ++ctx->segment_empty_page_count;
            if (real_write_size != 0) {
                st = segment->TrimPhysicalPageData(log_id, local_space_id, local_page_no, offset, fragment_size, true);
                if (!st.IsOk()) {
                    ++ctx->interrupt_by_io_count;
                    LOG(ERROR) << segment << " trim physical data failed in compression,"
                        << " offset:[" << offset
                        << "] size:[" << fragment_size
                        << "] " << st;
                }
            }
            break;
        }

        // when space encrypt is enable, do not compress page belongs to it
        const uint32_t space_encrypt_status = segment->GetSpaceEncryptStatus(local_space_id);
        LOG(TRACE) << segment << " get space_encrypt_status:[" << space_encrypt_status
                   << "] space:[" << local_space_id << "] page_no:[" << local_page_no << "]";
        if (space_encrypt_status_is_unknown(space_encrypt_status)
            && segment->cluster()->enable_encrypt()) {
            ++ctx->interrupt_by_meta_count;
            auto closure = brpc::NewCallback(this, &Compressor::OnEvent, ctx, local_space_id);
            control->parser()->AddGetSpaceMetaEvent(segment TRACE_FILE_LINE_CC,
                                                    local_space_id, closure, &ctx->st);
            return;
        }
        if (space_encrypt_status_is_enable(space_encrypt_status)) {
            LOG(TRACE) << segment
                       << " space is enable encrypt, do not compress page, local_space_id:["
                       << local_space_id << "] local_page_no:[" << local_page_no << "]";
            st.Reset(db::Code::kOk, "space is enable encrypt");
            break;
        }

        const uint32_t space_status = segment->GetSpaceStatus(local_space_id);
        LOG(TRACE) << segment << " get space_status:[" << space_status
            << "] space:[" << local_space_id
            << "] page_no:[" << local_page_no
            << "]";
        if (space_status_is_unknown(space_status)) {
            ++ctx->interrupt_by_meta_count;
            auto closure = brpc::NewCallback(this, &Compressor::OnEvent, ctx, local_space_id);
            control->parser()->AddGetSpaceMetaEvent(segment TRACE_FILE_LINE_CC,
                    local_space_id, closure, &ctx->st);
            return;
        }

        if (!space_status_is_work(space_status)) {
            PSVR_ASSERT(space_status_is_deleted(space_status));
            if (!space_status_with_psm(space_status)) {
                ++ctx->interrupt_by_meta_count;
                auto closure = brpc::NewCallback(this, &Compressor::OnEvent, ctx, local_space_id);
                control->parser()->AddGetSpaceMetaEvent(segment TRACE_FILE_LINE_CC,
                        local_space_id, closure, &ctx->st);
                return;
            }

            auto cluster = segment->cluster();
            if (cluster->in_backup()) {
                LOG(TRACE) << segment << " cluster in backup, dont trim page.";
                st.Reset(db::Code::kInterrupt, "cluster in backup");
                break;
            }

            PagePtr page = segment->GetPage(local_space_id, local_page_no, false);
            if (page && !page->LogRecordEmpty()) {
                LOG(TRACE) << segment << " page not apply over,"
                    << " local_space_id:[" << local_space_id
                    << "] local_page_no:[" << local_page_no
                    << "]";
                st.Reset(db::Code::kOk, "page not apply over");
                break;
            }

            gaia_apply::lsn_t safe_trim_lsn = segment->GetSpaceSafeTrimLsn(local_space_id);
            if (safe_trim_lsn == 0) {
                int64_t trim_space_id_time = base::cpuwide_time_us();
                if (ctx->trim_space_id == local_space_id) {
                    trim_space_id_time = ctx->trim_space_id_time;
                } else {
                    ctx->trim_space_id = local_space_id;
                    ctx->trim_space_id_time = trim_space_id_time;
                }

                if (trim_space_id_time > cluster->last_lsn_update_time()) {
                    LOG(TRACE) << segment << " wait cluster update cn lowest lsn.";
                    ++ctx->interrupt_by_meta_count;
                    Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(FLAGS_psvr_update_lowest_lsn_interval_second), false);
                    return;
                }
                segment->SetSpaceSafeTrimLsn(local_space_id, cluster->real_cn_lowest_lsn());
            }

            st = segment->TrimPhysicalPageData(log_id, local_space_id, local_page_no, offset, fragment_size, false);
            if (st.IsOk()) {
                ++ctx->segment_trim_page_count;
            } else {
                LOG(ERROR) << segment << " trim physical data failed in compression,"
                    << " offset:[" << offset
                    << "] size:[" << fragment_size
                    << "] " << st;
            }
            break;
        }

        ++ctx->segment_non_empty_page_count;
        if (is_compressed) {
            ++ctx->segment_compressed_page_count;
            ctx->segment_compress_data_size += segment->GetPhysicalPageCompressSize(tl_buf_block->frame);
            st.Reset(db::Code::kOk, "already compressed");
            break;
        }

        st = segment->WritePhysicalPageData(log_id, local_space_id, local_page_no,
                offset, fragment_size, tl_buf_block->frame, true, &real_write_size);
        if (!st.IsOk()) {
            ++ctx->interrupt_by_io_count;
            LOG(ERROR) << segment << " write physical data failed in compression,"
                << " offset:[" << offset
                << "] " << st;
            break;
        }
        ctx->segment_compress_data_size += real_write_size;

        if (FLAGS_psvr_enable_check_compress_data) {
            st = segment->ReadPhysicalPageData(log_id, offset, fragment_size,
                    tl_buf_block->frame, nullptr, nullptr);
            if (st.IsOk()) {
                if (page_is_corrupted(tl_buf_block->frame, fragment_size, &local_is_empty)) {
                    st.Reset(db::Code::kCorrupted, "compressed data check fail");
                }
            }
            if (!st.IsOk()) {
                ++ctx->interrupt_by_io_count;
                LOG(ERROR) << segment << " check compress data failed in compression,"
                    << " offset:[" << offset
                    << "] size:[" << fragment_size
                    << "] " << st;
                FLAGS_psvr_enable_compression = false;
                break;
            }
        }

        ++ctx->segment_valid_compress_page_count;
    } while (false);

    ctx->has_quota = false;
    if (!st.IsOk()) {
        _stat_compress_page_error_count << 1;
        FinishCompressSegment(ctx, false);
    } else {
        LOG(TRACE) << segment << " compress fragment data ok,"
            << " offset:[" << offset
            << "] " << st;
        // ok
        ++ctx->segment_page_count;
        compress_task->offset += fragment_size;

        uint64_t sync_size = ut_uintx_align_up(
                FLAGS_psvr_sync_size_on_recovery_or_compression, gaia_physical_page_size());
        if (FLAGS_psvr_sync_on_recovery_or_compression
                && sync_size > 0
                && compress_task->offset % sync_size == 0) {
            segment->Sync();
        }

        if (CheckQuota(ctx, store_id)) {
            OnGetQuota(ctx);
        }
    }
}

void Compressor::CalcPriorityForFreeExtent(Context* ctx) {
    define_control_or_return_invalid(ctx);
    if (!FLAGS_psvr_enable_trim_free_extent) {
        Schedule(ctx TRACE_FILE_LINE_CC,
                second2microseconds(FLAGS_psvr_trim_free_extent_calc_priority_interval_second));
        return;
    }

    std::vector<SegmentPtr> segments;
    control->segment_manager()->GetAllSegments(&segments);

    std::map<std::string, std::map<uint32_t, uint64_t>> cluster_segment_logic_size;
    std::map<std::string, std::map<uint32_t, uint64_t>> cluster_segment_physical_size;
    std::map<std::string, PsmInfoPtr> cluster_infos;
    for (auto& segment : segments) {
        auto it = cluster_infos.find(segment->cluster_id());
        if (it == cluster_infos.end()) {
            cluster_infos[segment->cluster_id()] = segment->GetPsmInfo();
        }
        cluster_segment_physical_size[segment->cluster_id()][segment->segment_id()] = segment->segment_physical_size();
        cluster_segment_logic_size[segment->cluster_id()][segment->segment_id()] = segment->segment_physical_size();
    }

    for (auto& it : cluster_infos) {
        std::vector<base::EndPoint> nodes;
        if (!it.second->GetOrRefreshNodes(&nodes)) {
            LOG(NOTICE) << "cluster get psm nodes failed,"
                << " cluster:[" << it.first
                << "]";
            control->RefreshPsmInfo(it.second);
            continue;
        }

        RpcListSegmentCtx rpc_ctx;

        rpc_ctx.servers = std::move(nodes);
        rpc_ctx.request.set_cluster_id(it.first);
        while (true) {
            control->client()->ListSegment(&rpc_ctx, nullptr);
            bool not_exists = false;
            if (rpc_failed(&rpc_ctx, &not_exists)) {
                if (rpc_ctx.RetryNext()) {
                    continue;
                }
                LOG(WARNING) << "cluster:[" << it.first << "] list segment rpc failed,"
                    << ", not_exists:[" << not_exists
                    << "]";
            } else {
                for (const auto& seg : rpc_ctx.response.segments()) {
                    uint64_t logic_size = (seg.total_extent_num() - seg.free_extent_num()) << GAIADB_EXTENT_SIZE_SHIFT;
                    cluster_segment_logic_size[it.first][seg.segment_id()] = logic_size;
                }
            }
            break;
        };
    }

    auto diff_size_fn = [](uint64_t logic, uint64_t physical) {
        return logic < physical ? (physical - logic) : 0;
    };

    std::sort(segments.begin(), segments.end(), [&](SegmentPtr lhs, SegmentPtr rhs) {
            uint64_t lhs_logic_size = cluster_segment_logic_size[lhs->cluster_id()][lhs->segment_id()];
            uint64_t rhs_logic_size = cluster_segment_logic_size[rhs->cluster_id()][rhs->segment_id()];
            uint64_t lhs_physical_size = cluster_segment_physical_size[lhs->cluster_id()][lhs->segment_id()];
            uint64_t rhs_physical_size = cluster_segment_physical_size[rhs->cluster_id()][rhs->segment_id()];
            uint64_t lhs_size = diff_size_fn(lhs_logic_size, lhs_physical_size);
            uint64_t rhs_size = diff_size_fn(rhs_logic_size, rhs_physical_size);

            if (lhs->stat_last_trim_extent_time() != rhs->stat_last_trim_extent_time()) {
                return lhs->stat_last_trim_extent_time() < rhs->stat_last_trim_extent_time();
            }
            if (lhs_size != rhs_size) {
                return lhs_size > rhs_size;
            }
            return lhs->segment_id() < rhs->segment_id();
        });

    uint32_t max_num = FLAGS_psvr_trim_free_extent_max_task_num_per_store;
    uint32_t run_num = 0;
    std::set<uint32_t> stores;
    for (size_t i = 0; i < segments.size() && !_stopped; ++i) {
        auto segment = segments[i];
        if (segment->in_recovery()) {
            LOG(TRACE) << segment << " in recovery, ignore trim free extent";
            continue;
        }
        if (!segment_is_valid(segment) || !segment->is_active()) {
            LOG(TRACE) << segment << " invalid or not active, ignore trim free extent";
            continue;
        }
        if (segment->cluster()->in_backup()) {
            LOG(TRACE) << segment << " in backup, ignore trim free extent";
            continue;
        }

        uint64_t logic_size = cluster_segment_logic_size[segment->cluster_id()][segment->segment_id()];
        uint64_t physical_size = cluster_segment_physical_size[segment->cluster_id()][segment->segment_id()];
        if (physical_size <= logic_size) {
            LOG(TRACE) << segment << " the logical size more than physical size, ignore trim free extent";
            continue;
        }

        if (FLAGS_psvr_trim_free_extent_min_interval_us > 0 &&
                segment->stat_last_trim_extent_time() + FLAGS_psvr_trim_free_extent_min_interval_us > base::cpuwide_time_us()) {
            LOG(TRACE) << segment << " last trim free extent time , ignore trim free extent";
            continue;
        }

        if (stores.count(segment->store_id())) {
            LOG(TRACE) << segment << " store running task is full, ignore trim free extent";
            continue;
        }

        if (!_trim_free_extent_task->CanRun(segment->store_id(), max_num)) {
            LOG(TRACE) << segment << " store running task is full, ignore trim free extent";
            stores.emplace(segment->store_id());
            continue;
        }

        segment->set_stat_last_trim_extent_time(base::cpuwide_time_us());

        auto trim_ctx = new Context(Action::kTrimFreeExtent, segment->store_id());
        trim_ctx->stat_timer.reset();
        trim_ctx->compress_task.reset(new Task(segment));
        trim_ctx->quota_size = GAIADB_EXTENT_SIZE;
        Schedule(trim_ctx TRACE_FILE_LINE_CC);
        if (++run_num >= _store_count * max_num) {
            break;
        }
    }

    Schedule(ctx TRACE_FILE_LINE_CC,
            second2microseconds(FLAGS_psvr_trim_free_extent_calc_priority_interval_second));
}

void Compressor::FinishTrimFreeExtent(Context* ctx, bool succ) {
    std::unique_ptr<Context> ctx_guard(ctx);
    const int32_t store_id = ctx->store_id;
    std::shared_ptr<Task> compress_task = ctx->compress_task;
    std::shared_ptr<Store> store = _stores[store_id];

    // release store quota
    _trim_free_extent_task->Finish(store_id);
    // update segment if exists
    SegmentPtr segment = compress_task->segment.lock();
    if (segment_is_valid(segment)) {
        segment->UpdateDBSize();
        ctx->segment_compress_after_size = segment->segment_physical_size();
        LOG(NOTICE) << segment << " finish trim free extents,"
            << " result:" << succ
            << "] before_size:[" << ctx->segment_compress_before_size
            << "] after_size:[" << ctx->segment_compress_after_size
            << "] trim_page_num:[" << ctx->segment_trim_page_count
            << "] use_time_s:[" << ctx->stat_timer.s_elapsed()
            << "] interrupt_by_quota_count:[" << ctx->interrupt_by_quota_count
            << "] interrupt_by_meta_count:[" << ctx->interrupt_by_meta_count
            << "] interrupt_by_other_count:[" << ctx->interrupt_by_other_count
            << "] interrupt_by_io_count:[" << ctx->interrupt_by_io_count
            << "]";
    }
}

void Compressor::TrimFreeExtent(Context* ctx) {
    define_control_or_return_invalid(ctx);

    PSVR_ASSERT(!!ctx->compress_task);

    if (!FLAGS_psvr_enable_trim_free_extent) {
        FinishTrimFreeExtent(ctx);
        return;
    }

    std::shared_ptr<Task> compress_task = ctx->compress_task;
    SegmentPtr segment = compress_task->segment.lock();
    if (!segment_is_valid(segment)) {
        LOG(NOTICE) << "trim free extent task object inactive, ignore it";
        FinishTrimFreeExtent(ctx);
        return;
    }

    bool status = false;
    bool is_force = false;
    segment->GetRecoveryStatus(&status, &is_force);
    if (status) {
        LOG(NOTICE) << segment << " in recovery or checking data, ignore it";
        FinishTrimFreeExtent(ctx);
        return;
    }

    const int32_t store_id = segment->store_id();
    auto cluster = segment->cluster();
    if (cluster->in_backup()) {
        LOG(TRACE) << segment << " in backup, ignore it";
        FinishTrimFreeExtent(ctx);
        return;
    }

    const uint64_t fragment_size = gaia_apply::FLAGS_univ_page_size;
    thread_local BufBlockPtr tl_buf_block = nullptr;
    if (!tl_buf_block) {
        tl_buf_block = control->buf_pool()->AllocBufBlock(fragment_size);
    }
    if (!tl_buf_block) {
        LOG(ERROR) << "alloc buf failed, size:[" << fragment_size << "]";
        Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(1ul));
        return;
    }

    if (!ctx->has_quota) {
        if (!CheckQuota(ctx, store_id)) {
            _stat_compress_interrupt_by_quota_count << 1;
            ++ctx->interrupt_by_quota_count;
            return;
        }
    }

    uint64_t offset = compress_task->offset;
    if (offset == 0) {
        LOG(NOTICE) << segment << " start to trim free extents";
        segment->UpdateDBSize();
        ctx->segment_compress_before_size = segment->segment_physical_size();
    } else if (offset >= compress_task->size) {
        LOG(TRACE) << segment << " finish trim free extents";
        FinishTrimFreeExtent(ctx, true);
        return;
    }

    uint32_t trim_page_num = ctx->segment_trim_page_count;
    TimerGuard timer_trim_free_extent(_stat_trim_free_extent_lat);
    const uint64_t log_id = get_log_id();
    uint64_t end_offset = ut_uintx_align_down<uint64_t>(offset, GAIADB_EXTENT_SIZE) + GAIADB_EXTENT_SIZE;
    while (offset < end_offset) {
        const uint64_t physical_page_no = offset / fragment_size;
        db::PageLockPtr page_lock = segment->GetPageLock(physical_page_no);
        db::PageUniqueLock lk(page_lock, std::try_to_lock);
        if (!lk) {
            ++ctx->interrupt_by_other_count;
            Schedule(ctx TRACE_FILE_LINE_CC, millisecond2microseconds(50ul), false);
            return;
        }

        bool is_compressed = false;
        uint64_t real_write_size = fragment_size;
        db::Status st = segment->ReadPhysicalPageData(log_id, offset, fragment_size,
                tl_buf_block->frame, &is_compressed, &real_write_size);
        if (!st.IsOk()) {
            LOG(ERROR) << segment << " read physical data failed in trim free extent,"
                << " offset:[" << offset
                << "] size:[" << fragment_size
                << "] " << st;
            ++ctx->interrupt_by_io_count;
            FinishTrimFreeExtent(ctx);
            return;
        }

        bool local_is_empty = false;
        if (page_is_corrupted(tl_buf_block->frame, fragment_size, &local_is_empty)) {
            LOG(ERROR) << segment << " page data is corrupted,"
                << " offset:[" << offset
                << "] size:[" << fragment_size
                << "] " << st;
            ++ctx->interrupt_by_io_count;
            FinishTrimFreeExtent(ctx);
            return;
        }

        const gaia_apply::space_id_t local_space_id = buf_block_get_space_id(tl_buf_block);
        const gaia_apply::page_no_t local_page_no = buf_block_get_page_no(tl_buf_block);

        if (local_is_empty) {
            if (real_write_size == 0) {
                LOG(NOTICE) << segment << " finish trim free extents,"
                    << " offset:[" << offset
                    << "]";
                FinishTrimFreeExtent(ctx, true);
                return;
            }
            st = segment->TrimPhysicalPageData(log_id, local_space_id, local_page_no, offset, fragment_size, true);
            if (st.IsOk()) {
                LOG(TRACE) << segment << " trim empty fragment data ok,"
                    << " offset:[" << offset
                    << "] " << st;
                offset += fragment_size;
                ++ctx->segment_trim_page_count;
                continue;
            } else if (st.IsRetry()) {
                ++ctx->interrupt_by_other_count;
                Schedule(ctx TRACE_FILE_LINE_CC, millisecond2microseconds(50lu), false);
                return;
            } else {
                LOG(ERROR) << segment << " trim physical data failed in trim free extent,"
                    << " offset:[" << offset
                    << "] size:[" << fragment_size
                    << "] " << st;
                ++ctx->interrupt_by_io_count;
                FinishTrimFreeExtent(ctx);
                return;
            }
        }

        const uint32_t space_status = segment->GetSpaceStatus(local_space_id);
        LOG(TRACE) << segment << " get space_status:[" << space_status
            << "] space:[" << local_space_id
            << "] page_no:[" << local_page_no
            << "]";
        if (space_status_is_unknown(space_status)) {
            ++ctx->interrupt_by_meta_count;
            auto closure = brpc::NewCallback(this, &Compressor::OnEvent, ctx, local_space_id);
            control->parser()->AddGetSpaceMetaEvent(segment TRACE_FILE_LINE_CC,
                    local_space_id, closure, &ctx->st);
            return;
        }

        if (space_status_is_work(space_status)) {
            break;
        }

        PSVR_ASSERT(space_status_is_deleted(space_status));
        if (!space_status_with_psm(space_status)) {
            ++ctx->interrupt_by_meta_count;
            auto closure = brpc::NewCallback(this, &Compressor::OnEvent, ctx, local_space_id);
            control->parser()->AddGetSpaceMetaEvent(segment TRACE_FILE_LINE_CC,
                    local_space_id, closure, &ctx->st);
            return;
        }

        PagePtr page = segment->GetPage(local_space_id, local_page_no, false);
        if (page && !page->LogRecordEmpty()) {
            LOG(TRACE) << segment << " page not apply over,"
                << " local_space_id:[" << local_space_id
                << "] local_page_no:[" << local_page_no
                << "]";
            break;
        }

        gaia_apply::lsn_t safe_trim_lsn = segment->GetSpaceSafeTrimLsn(local_space_id);
        if (safe_trim_lsn == 0) {
            int64_t trim_space_id_time = base::cpuwide_time_us();
            if (ctx->trim_space_id == local_space_id) {
                trim_space_id_time = ctx->trim_space_id_time;
            } else {
                ctx->trim_space_id = local_space_id;
                ctx->trim_space_id_time = trim_space_id_time;
            }

            if (trim_space_id_time > cluster->last_lsn_update_time()) {
                LOG(TRACE) << segment << " wait cluster update cn lowest lsn.";
                ++ctx->interrupt_by_meta_count;
                Schedule(ctx TRACE_FILE_LINE_CC, second2microseconds(FLAGS_psvr_update_lowest_lsn_interval_second), false);
                return;
            }
            segment->SetSpaceSafeTrimLsn(local_space_id, cluster->real_cn_lowest_lsn());
        }

        st = segment->TrimPhysicalPageData(log_id, local_space_id, local_page_no, offset, fragment_size, false);
        if (st.IsOk()) {
            LOG(TRACE) << segment << " trim fragment data ok,"
                << " offset:[" << offset
                << "] " << st;
            ++ctx->segment_trim_page_count;
        } else if (st.IsRetry()) {
            ++ctx->interrupt_by_other_count;
            Schedule(ctx TRACE_FILE_LINE_CC, millisecond2microseconds(50lu), false);
            return;
        } else {
            LOG(ERROR) << segment << " trim physical data failed in trim free extent,"
                << " offset:[" << offset
                << "] size:[" << fragment_size
                << "] " << st;
            ++ctx->interrupt_by_io_count;
            FinishTrimFreeExtent(ctx);
            return;
        }

        offset += fragment_size;
    }

    compress_task->offset = end_offset;

    if (FLAGS_psvr_sync_on_recovery_or_compression
            && trim_page_num < ctx->segment_trim_page_count) {
        segment->Sync();
    }

    ctx->has_quota = false;
    if (CheckQuota(ctx, store_id)) {
        OnGetQuota(ctx);
    }
}

}
