/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/drop_standby_cluster.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/drop_standby_cluster.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int DropStandbyCluster::Run() {
    RpcStatus status;
    gaiapb::DropStandbyClusterRequest request;
    gaiapb::DropStandbyClusterResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_standby_cluster_id.empty()) {
        print_error("miss --standby-cluster-id");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Drop this standby cluster: %s?", _standby_cluster_id.c_str());
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    request.set_cluster_id(_standby_cluster_id);
    request.set_log_id(_log_id);
    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::drop_standby_cluster, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " drop standby cluster failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("drop failed, all nodes failed");
    return Output(response);
}

int DropStandbyCluster::Format(const gaiapb::DropStandbyClusterResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
