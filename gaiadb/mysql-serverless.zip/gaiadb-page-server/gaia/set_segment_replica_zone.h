/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_segment_replica_zone.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class SetSegmentReplicaZone : public Command {
public:
    SetSegmentReplicaZone() {
        SetName("set-segment-replica-zone");
        SetDesc("set segment replica zone in manager");
        SetDescCn("设置管理服务中分片副本的可用区");

        AddPsmClusterOption();
        AddRequiredArgOption("addr", &_long_opt_val, kOptMax + 1, "segment replica endpoint", kip_port);
        AddZoneOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "manager cluster id", kstring);
        AddRequiredArgOption("segment-id", NULL, 's', "segment id", kuint32_t);
        
        AddExample("--manager-address \"bns://xxx\" --segment-id <id>"
                " --addr <ip:port> --region bjdd --available-zone test");
    }
    virtual ~SetSegmentReplicaZone() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'c':
            _cluster_id = opt;
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 's':
            _segment_id = std::strtoull(opt, NULL, 10);
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptRegion:
                _zone.region = opt;
                break;
            case kOptAvailableZone:
                _zone.available_zone = opt;
                break;
            case kOptMax + 1:
                _addr = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::AckResponse& rsp);

private:
    std::string _manager_address {};
    std::string _addr {};
    VarZone _zone;
    std::string _cluster_id {};
    uint32_t _segment_id {0};
};

}
}
