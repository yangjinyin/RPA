/***************************************************************************
* Copyright (c) baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/dblwr.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <shared_mutex>
#include "psvr/common.h"
#include "psvr/utils.h"
#include "psvr/dbengine.h"

namespace psvr {

static constexpr uint32_t kDBLWRBufFooterMagic = 0x4e435831;     // echo "kDBLWRBufFooter" |md5sum| cut -c 1-8
static constexpr uint32_t kpage_size = 4096;

static constexpr ssize_t kDblwrFooterSize = 4096;
static constexpr ssize_t kMaxDblwrOffsetNum = 506;

static constexpr uint32_t kDblwrFlagsNone = 0;
static constexpr uint32_t kDblwrFlagsWithCompress = 1;  // 1<<0

struct ALIGNAS(sizeof(uint32_t)) DblwrFooter {
    uint32_t magic;
    uint32_t max_page_num;
    uint64_t fno;
    uint32_t page_num;
    uint32_t crc;
    uint64_t ckp_lsn[2];    // first, last
    uint64_t offs[kMaxDblwrOffsetNum];          // 256=4M
    uint32_t flags;
    uint32_t checksum;
};

static_assert(sizeof(DblwrFooter) == kDblwrFooterSize);

struct DblwrBuf {
    gaia_apply::byte* frames;
    DblwrFooter footer;
    DblwrFooter* footer_ptr;  // points to frames tail when latest, &footer otherwise
    ssize_t frames_len;
    int fd;
    std::map<uint64_t, std::vector<uint32_t>> pages_to_slot;  // fold_space_page -> frames slot list (ordered by write)
    std::map<uint64_t, uint32_t> offs_to_slot;                // offset -> latest frames slot

    DblwrBuf() : frames(nullptr), footer_ptr(&footer), frames_len(0), fd(-1) {
        memset(&footer, '\0', kDblwrFooterSize);
    }
    ~DblwrBuf() {
        if (fd > -1) {
            close(fd);
        }
    }
};

using DblwrBufPtr = std::shared_ptr<DblwrBuf>;

inline uint32_t calc_dblwr_page_num(uint32_t size) {
    return std::min(size, static_cast<uint32_t>(kMaxDblwrOffsetNum));
}

class Dblwr {
public:
    Dblwr();
    FUNC_MOCK ~Dblwr();

    FUNC_MOCK db::Status Open(uint32_t max_page_num, const std::string& db_path,
            gaia_apply::lsn_t* max_ckp_lsn);

    FUNC_MOCK db::Status Read(uint64_t offset, gaia_apply::byte* frame);

    FUNC_MOCK db::Status Read(gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no,
            uint64_t offset, gaia_apply::byte* frame);

    FUNC_MOCK db::Status Write(gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no,
            gaia_apply::byte* buf, uint64_t offset, uint32_t flags);

    FUNC_MOCK db::Status ReadSealBuf(gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no,
            gaia_apply::byte* frame, uint64_t offset);

    FUNC_MOCK db::Status ReadCkpLsn(gaia_apply::lsn_t* ckp_lsn);
    FUNC_MOCK db::Status WriteCkpLsn(gaia_apply::lsn_t ckp_lsn);

    FUNC_MOCK db::Status SealBufByLsn(gaia_apply::lsn_t lsn);
    FUNC_MOCK db::Status SealBufByTime(int64_t timeout_us);

    FUNC_MOCK bool HasBufs() const;
    FUNC_MOCK DblwrBufPtr DumpBuf() const;
    uint64_t NextDumpFileNo() const;
    FUNC_MOCK db::Status RemoveBuf(DblwrBufPtr buf);

    static std::ostream& Dump(int fd, std::ostream& os, bool parse = false);

    size_t bufs_size() const { return _bufs_size.load(std::memory_order_relaxed); }
    bool in_dump() const { return _in_dump.test(); }
    bool acquire_in_dump() { return _in_dump.try_lock(); }
    void release_in_dump() { return _in_dump.unlock(); }

private:
    db::Status OpenFile(uint64_t fno);
    db::Status RemoveFile(uint64_t fno);
    db::Status ReadFile(int fd, gaia_apply::byte* frame, uint32_t slot);
    db::Status ReadBuf(DblwrBufPtr buf, gaia_apply::byte* frame, uint32_t slot);

    DblwrBufPtr AllocBuf();
    DblwrBufPtr AllocBufByPageNum(uint64_t fno, uint32_t max_page_num);
    DblwrBufPtr AllocBufByBufSize(uint64_t fno, ssize_t buf_size);
    db::Status SealBuf();
    db::Status AllocFramesMmap(ssize_t buf_size);

private:
    mutable rwlock_t _shared_mutex;
    uint32_t _max_page_num;
    uint64_t _file_no;
    std::string _db_path;
    gaia_apply::byte* _frames;
    ssize_t _frames_len;
    int _latest_fd;             // fd for "latest" mmap file
    DblwrBufPtr _buf;           // mutable buf
    std::list<DblwrBufPtr> _bufs;       // immutable bufs
    std::atomic<int64_t> _latest_create_time;
    Lsn _latest_lsn;
    std::atomic<size_t> _bufs_size;
    AcquireLock _in_dump;
};

using DblwrPtr = std::shared_ptr<Dblwr>;

}
