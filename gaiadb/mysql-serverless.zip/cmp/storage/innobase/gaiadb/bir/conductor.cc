#include "conductor.h"

#include "log0log.h"
#include "gflags/gflags.h"
#include "baidu/rpc/reloadable_flags.h"

#include "rpl0rpl.h"

DEFINE_uint64(
    rpl_parse_batch_interval_threshold, 4000,
    "beyond this time, force parse even not enough data for parse batch");
BAIDU_RPC_VALIDATE_GFLAG(rpl_parse_batch_interval_threshold,
                         baidu::rpc::PassValidate);

bvar::Status<uint64_t> stat_rpl_get_log_buf_size("cmp_rpl_get_log_cur_log_buf_size", 0);

static size_t adjust_fetch_log_buffer_by_bp_size() {
  if (srv_rpl_fetch_log_buffer_size > 0) {
    return srv_rpl_fetch_log_buffer_size;
  }
  static size_t last_bp_size = 0;
  static size_t last_log_size = 0;

  const size_t bp_size = srv_buf_pool_curr_size;
  if (bp_size == last_bp_size) {
    return last_log_size;
  }
  if (bp_size >= (3lu<<30)) {
    last_log_size = (256lu<<20);
  } else if (bp_size >= (2lu<<30)) {
    last_log_size = (128lu<<20);
  } else if (bp_size >= (1lu<<30)) {
    last_log_size = (64lu<<20);
  } else if (bp_size >= (600lu<<20)) {
    last_log_size = (32lu<<20);
  }

  last_bp_size = bp_size;
  return last_log_size;
}

bool Conductor::init() {
  if (init_) {
    return true;
  }

  mutex_create(LATCH_ID_RPL_BINLOG, &binlog_mutex_);

  log_buf_size_ = std::max(
    srv_log_buffer_size, adjust_fetch_log_buffer_by_bp_size());
  log_buf_size_ = ut_uint64_align_up(log_buf_size_, OS_FILE_LOG_BLOCK_SIZE);

  log_buf_.alloc_withkey(UT_NEW_THIS_FILE_PSI_KEY, ut::Count{log_buf_size_});

  binlog_recover_ = ut::new_withkey<BinlogRecover>(UT_NEW_THIS_FILE_PSI_KEY);

  LOG(NOTICE) << "bir init fetch log buf,"
              << " log_buf_size:" << log_buf_size_;
  init_ = true;
  return true;
}

bool Conductor::reinit() {
  ut::delete_(binlog_recover_);
  binlog_recover_ = ut::new_withkey<BinlogRecover>(UT_NEW_THIS_FILE_PSI_KEY);
  log_buf_size_ = std::max(
    srv_log_buffer_size, adjust_fetch_log_buffer_by_bp_size());
  log_buf_size_ = ut_uint64_align_up(log_buf_size_, OS_FILE_LOG_BLOCK_SIZE);

  log_buf_.dealloc();
  log_buf_.alloc_withkey(UT_NEW_THIS_FILE_PSI_KEY, ut::Count{log_buf_size_});
  return true;
}

bool Conductor::init(const size_t buf_size) {
  if (init_) {
    mutex_destroy(&binlog_mutex_);
    ut::delete_(binlog_recover_);
    log_buf_.dealloc();
  }
  mutex_create(LATCH_ID_RPL_BINLOG, &binlog_mutex_);
  log_buf_size_ = buf_size;
  log_buf_size_ = ut_uint64_align_up(log_buf_size_, OS_FILE_LOG_BLOCK_SIZE);

  log_buf_.alloc_withkey(UT_NEW_THIS_FILE_PSI_KEY, ut::Count{log_buf_size_});

  binlog_recover_ = ut::new_withkey<BinlogRecover>(UT_NEW_THIS_FILE_PSI_KEY);
  init_ = true;

  LOG(NOTICE) << "bir init fetch log buf,"
              << " log_buf_size:" << log_buf_size_;
  return true;
}

byte *Conductor::log_buf() { return log_buf_; }

ut::aligned_array_pointer<byte, OS_FILE_LOG_BLOCK_SIZE>& Conductor::get_log_buf() {
  return log_buf_; 
}

std::mutex& Conductor::log_buf_mutex() { return log_buf_mutex_; }

size_t& Conductor::log_buf_size() { return log_buf_size_; }

ib_mutex_t *Conductor::binlog_mutex() { return &binlog_mutex_; }

BinlogRecover *Conductor::binlog_recover() { return binlog_recover_; }

bool Conductor::cleanup() {
  mutex_destroy(&binlog_mutex_);
  ut::delete_(binlog_recover_);
  log_buf_.dealloc();
  init_ = false;
  return true;
}

void Conductor::resize_buf_if(const bool set_stat_rpl_bvar) {
  auto new_size = std::max(
    srv_log_buffer_size, adjust_fetch_log_buffer_by_bp_size());
  new_size = ut_uint64_align_up(new_size, OS_FILE_LOG_BLOCK_SIZE);
  if (new_size == log_buf_size()) {
    return;
  }

  LOG(NOTICE) << "resize fetch log buf, fetch_lsn:"
              << fetch_lsn() << ", copy_lsn:" << copy_lsn()
              << ", log_buf_size:" << log_buf_size_
              << ", new_size:" << new_size;

  lsn_t cur_fetch_lsn = fetch_lsn();
  for (int i = 0; i < 3; ++i) {
    lsn_t cur_copy_lsn = copy_lsn();
    if (cur_fetch_lsn - cur_copy_lsn > new_size) {
      std::this_thread::sleep_for(std::chrono::microseconds(100));
      continue;
    }
    std::unique_lock lk(log_buf_mutex_);
    cur_copy_lsn = copy_lsn();
    cur_copy_lsn = ut_uint64_align_down(cur_copy_lsn, OS_FILE_LOG_BLOCK_SIZE);
    cur_fetch_lsn = ut_uint64_align_up(cur_fetch_lsn, OS_FILE_LOG_BLOCK_SIZE);
    if (cur_fetch_lsn - cur_copy_lsn > new_size) {
      return;
    }

    ut::aligned_array_pointer<byte, OS_FILE_LOG_BLOCK_SIZE> tmp_buf;
    size_t tmp_buf_size = log_buf_size_;
    tmp_buf.alloc_withkey(UT_NEW_THIS_FILE_PSI_KEY, ut::Count{tmp_buf_size});
    std::memcpy(tmp_buf, log_buf_, tmp_buf_size);

    log_buf_.dealloc();
    log_buf_.alloc_withkey(UT_NEW_THIS_FILE_PSI_KEY, ut::Count{new_size});
    log_buf_size_ = new_size;

    while (cur_copy_lsn < cur_fetch_lsn) {
      sn_t sn = log_translate_lsn_to_sn(cur_copy_lsn);
      // src
      byte *src_ptr = tmp_buf + (sn % tmp_buf_size);
      byte *src_buf_end = tmp_buf + tmp_buf_size;
      ut_a(src_buf_end - src_ptr >= LOG_BLOCK_DATA_SIZE);
      // dest
      byte *ptr = log_buf_ + (sn % log_buf_size_);
      byte *buf_end = log_buf_ + log_buf_size_;
      ut_a(buf_end - ptr >= LOG_BLOCK_DATA_SIZE);

      std::memcpy(ptr, src_ptr, LOG_BLOCK_DATA_SIZE);
      cur_copy_lsn += OS_FILE_LOG_BLOCK_SIZE;
    }
    LOG(NOTICE) << "resize fetch log buf ok, new_size:" << log_buf_size_;
    if (set_stat_rpl_bvar) {
      stat_rpl_get_log_buf_size.set_value(log_buf_size_);
    }
    return;
  }
}
