/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/segment.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <limits.h>
#include <base/strings/string_number_conversions.h>

#include <gaiadb/utils/configuration.h>

#include "psvr/cluster.h"
#include "psvr/config.h"
#include "psvr/control.h"
#include "psvr/compress_utils.h"
#include "psvr/fetch.h"
#include "psvr/gc.h"
#include "psvr/page_op.h"
#include "psvr/parse.h"
#include "psvr/record_op.h"
#include "psvr/recover.h"
#include "psvr/store_cfg.h"
#include "psvr/store.h"
#include "psvr/segment.h"
#include "psvr/redo_record.h"
#include "psvr/segment_manager.h"
#include "psvr/utils.h"

namespace psvr {

std::ostream& operator<<(std::ostream& os, const SegmentPtr& segment) {
    if (segment) {
        os << segment.get();
    }
    return os;
}

std::ostream& operator<<(std::ostream& os, const Segment* segment) {
    if (segment) {
        os << "segment:[" << segment->db_path()
            << "@" << segment->replica_id()
            << "#" << segment->version()
            << "]";
    } else {
        os << "segment:[null]";
    }
    return os;
}

bool segment_is_valid(SegmentPtr segment) {
    return segment_is_valid_exclude(segment, 0);
}

bool segment_is_valid_exclude(SegmentPtr segment, uint32_t flag) {
    const uint32_t used_flag = fSegmentIsInvalied ^ flag;
    if ((!segment && (used_flag & fSegmentIsNull))
            || (segment->is_stopped() && (used_flag & fSegmentIsStop))
            || (segment->is_delete() && (used_flag & fSegmentIsDelete))
            || (segment->is_disable() && (used_flag & fSegmentIsDisable))) {
        return false;
    }
    return true;
}

struct GlobalSegmentStatictis {
    bvar::Adder<int32_t> stat_segment_count;
    bvar::Adder<int64_t> stat_record_unparse_size;
    bvar::Adder<int64_t> stat_record_ungc_size;

    GlobalSegmentStatictis()
        : stat_segment_count("psvr_segment_total_count"),
        stat_record_unparse_size("psvr", "record_unparse_total_size"),
        stat_record_ungc_size("psvr", "record_ungc_total_size") {}
};

static std::unique_ptr<GlobalSegmentStatictis> l_global_segment_stat {nullptr};

void PSVR_FUNC_CTOR init_global_segment_stat() {
    l_global_segment_stat.reset(new GlobalSegmentStatictis);
}

#define set_global_statistic(var, val)       \
    if (l_global_segment_stat) {                  \
        (l_global_segment_stat->var) << (val);   \
    }

#define set_statistic(var, val)       \
    if (_statistic) {                  \
        (_statistic->var) << (val);   \
    }

#define expose_statistic(var, name) \
    if (_statistic) {   \
        (_statistic->var).expose_as(name, _statistic->prefix);  \
    }

#define hide_statistic(var) \
    if (_statistic) {   \
        (_statistic->var).hide();  \
    }

#define PSMINFO_MAX_FAILED_COUNT 8

static bvar::Vector<gaia_apply::lsn_t, 5> get_segment_lsn_info(void* arg) {
    Segment* segment = static_cast<Segment*>(arg);
    bvar::Vector<gaia_apply::lsn_t, 5> result;
    result[0] = segment->fetch_lsn();
    result[1] = segment->parse_lsn();
    result[2] = segment->gc_lsn();
    result[3] = segment->GetClusterCnLowestLsn();
    result[4] = segment->GetClusterPsLowestLsn();
    return result;
}

static bvar::Vector<uint64_t, 2> get_segment_logblock_info(void* arg) {
    Segment* segment = static_cast<Segment*>(arg);
    bvar::Vector<uint64_t, 2> result;
    result[0] = segment->fetch_log_block_queue().Size();
    result[1] = segment->parse_log_block_queue().Size();
    return result;
}

Statistic::Statistic(Segment* _segment, const std::string& _prefix)
    : prefix(_prefix), segment(_segment),
    stat_lsn("seg_fetch_parse_gc_cmp_peer_lsn", prefix, &get_segment_lsn_info, segment),
    stat_fetch_logblock_count("seg_fetch_logblock_count", prefix),
    stat_parse_logblock_count("seg_parse_logblock_count", prefix),
    stat_append_logblock_count("seg_append_logblock_count", prefix),
    stat_gc_logblock_count("seg_gc_logblock_count", prefix),
    stat_fetch_logblock_data_bw("seg_fetch_logblock_data_bw", prefix, kSlaWindowSize),
    stat_recover_redo_rec_log_bw("seg_recover_redo_rec_log_bw", prefix, kSlaWindowSize),
    stat_parse_logblock_lat("seg_parse_logblock", prefix, kSlaWindowSize),
    stat_parse_logblock_real_lat("seg_parse_logblock_real", prefix, kSlaWindowSize),
    stat_append_logblock_lat("seg_append_logblock", prefix, kSlaWindowSize),
    stat_append_logblock_real_lat("seg_append_logblock_real", prefix, kSlaWindowSize),
    stat_gc_logblock_lat("seg_gc_logblock", prefix, kSlaWindowSize),
    stat_gc_logblock_real_lat("seg_gc_logblock_real", prefix, kSlaWindowSize),
    stat_gc_logblock_in_prior_thread_count("seg_gc_logblock_in_prior_thread_count", prefix, kSlaWindowSize),
    stat_gc_task_lat("seg_gc_task", prefix, kSlaWindowSize),
    stat_gc_page_lat("seg_gc_page", prefix, kSlaWindowSize),
    stat_gc_task_size("seg_gc_task_size", prefix, kSlaWindowSize),
    stat_gc_schedule_count("seg_gc_schedule_count", prefix, kSlaWindowSize),
    stat_parse_records_count("seg_parse_records_count", prefix, kSlaWindowSize),
    stat_apply_records_count("seg_apply_records_count", prefix, kSlaWindowSize),
    stat_logblock_unparse_ungc_count("seg_logblock_unparse_ungc_count", prefix, &get_segment_logblock_info, segment),
    stat_recover_bw(kSlaWindowSize),
    _is_hid(false) {
    stat_lsn.set_vector_names("fetch,parse,gc,cluster_cn,cluster_ps");
    stat_logblock_unparse_ungc_count.set_vector_names("fetch,parse");
}

Statistic::~Statistic() {
    if (!_is_hid) {
        HideBvar();
    }
}

void Statistic::HideBvar() {
    _is_hid = true;
    stat_lsn.hide();
    stat_fetch_logblock_count.hide();
    stat_parse_logblock_count.hide();
    stat_append_logblock_count.hide();
    stat_gc_logblock_count.hide();
    stat_fetch_logblock_data_bw.hide();
    stat_recover_redo_rec_log_bw.hide();
    stat_parse_logblock_lat.hide();
    stat_parse_logblock_real_lat.hide();
    stat_append_logblock_lat.hide();
    stat_append_logblock_real_lat.hide();
    stat_gc_logblock_lat.hide();
    stat_gc_logblock_real_lat.hide();
    stat_gc_logblock_in_prior_thread_count.hide();
    stat_gc_task_lat.hide();
    stat_gc_page_lat.hide();
    stat_gc_task_size.hide();
    stat_gc_schedule_count.hide();
    stat_parse_records_count.hide();
    stat_apply_records_count.hide();
    stat_logblock_unparse_ungc_count.hide();
    stat_recover_bw.hide();
}

StatCompress::StatCompress()
    : inited(false),
    data_updated(true),
    last_compress_time_s(0),
    compress_times(0),
    non_empty_page_count(0),
    last_compress_data_size(0),
    sort_data_size_mb(0),
    sort_last_compress_time_s(0),
    sort_compress_times(0),
    sort_drop_space_num(0),
    sort_update_extent_num(0),
    stat_drop_space_num(FLAGS_psvr_stat_update_page_interval_second),
    stat_update_page_count(FLAGS_psvr_stat_update_page_interval_second) {
}

void StageInfo::GetStageInfos(const Segment* segment,
        google::protobuf::RepeatedPtrField<pspb::SegmentStageInfo>* infos) const {
    auto add_stage_info = [infos](
            pspb::SegmentStage stage, const char* action) {
        auto* info = infos->Add();
        info->set_stage(stage);
        if (action) {
            info->set_action(action);
        }
        return info;
    };
    const auto fetch_action = _fetch_action.load(std::memory_order_acquire);
    auto fetch_info = add_stage_info(_fetch.load(std::memory_order_acquire), fetch_action > 0
            ? Fetcher::action2str(static_cast<Fetcher::Action>(fetch_action)) : nullptr);
    fetch_info->set_queue_size(segment->fetch_log_block_queue().log_block_size());
    fetch_info->set_time(segment->last_fetch_time());
    fetch_info->set_quota_state(segment->fetch_quota_state());

    const auto parse_action = _parse_action.load(std::memory_order_acquire);
    auto parse_info = add_stage_info(_parse.load(std::memory_order_acquire), parse_action > 0
            ? Parser::action2str(static_cast<Parser::Action>(parse_action)) : nullptr);
    parse_info->set_queue_size(segment->parse_log_block_queue().log_block_size());
    parse_info->set_size(segment->fetch_log_block_queue().Size());

    const auto append_action = _append_action.load(std::memory_order_acquire);
    auto append_info = add_stage_info(_append.load(std::memory_order_acquire), append_action > 0
            ? GcManager::action2str(static_cast<GcManager::Action>(append_action)) : nullptr);
    append_info->set_queue_size(segment->append_log_block_queue().log_block_size());
    append_info->set_size(segment->parse_log_block_queue().Size());

    const auto gc_action = _gc_action.load(std::memory_order_acquire);
    auto gc_info = add_stage_info(_gc.load(std::memory_order_acquire), gc_action > 0
            ? GcManager::action2str(static_cast<GcManager::Action>(gc_action)) : nullptr);
    gc_info->set_size(segment->append_log_block_queue().Size());

    const auto recovery_action = _recovery_action.load(std::memory_order_acquire);
    auto recovery_info = add_stage_info(_recovery.load(std::memory_order_acquire), recovery_action > 0
            ? Recoverer::action2str(static_cast<Recoverer::Action>(recovery_action)) : nullptr);
    recovery_info->set_size(segment->GetRecoveryMaxSize());

    const auto dblwr_action = _dblwr_action.load(std::memory_order_acquire);
    auto dblwr_info = add_stage_info(_dblwr.load(std::memory_order_acquire), dblwr_action > 0
            ? GcManager::action2str(static_cast<GcManager::Action>(dblwr_action)) : nullptr);
    const auto dblwr = segment->dblwr();
    dblwr_info->set_file_no(dblwr ? dblwr->NextDumpFileNo() : 0);
}

std::ostream& operator<<(std::ostream& os, const StageInfo& stage_info) {
    auto print_stage_info = [&os](pspb::SegmentStage stage,
            uint32_t action, const char* action_name) {
        os << pspb::SegmentStage_Name(stage);
        if (action > 0) {
            os << ":" << action_name;
        }
    };

    os << "stage_info:[";
    auto action = stage_info._fetch_action.load(std::memory_order_acquire);
    print_stage_info(stage_info._fetch.load(std::memory_order_acquire), action,
            Fetcher::action2str(static_cast<Fetcher::Action>(action)));
    //os << "/queue_size=" << segment->fetch_log_block_queue().log_block_size();

    action = stage_info._parse_action.load(std::memory_order_acquire);
    os << ",";
    print_stage_info(stage_info._parse.load(std::memory_order_acquire), action,
            Parser::action2str(static_cast<Parser::Action>(action)));
    //os << "/queue_size=" << segment->parse_log_block_queue().log_block_size();
    //os << "/size=" << segment->fetch_log_block_queue().Size();

    action = stage_info._append_action.load(std::memory_order_acquire);
    os << ",";
    print_stage_info(stage_info._append.load(std::memory_order_acquire), action,
            GcManager::action2str(static_cast<GcManager::Action>(action)));
    //os << "/queue_size=" << segment->append_log_block_queue().log_block_size();
    //os << "/size=" << segment->parse_log_block_queue().Size();

    action = stage_info._gc_action.load(std::memory_order_acquire);
    os << ",";
    print_stage_info(stage_info._gc.load(std::memory_order_acquire), action,
            GcManager::action2str(static_cast<GcManager::Action>(action)));
    //os << "/size=" << segment->append_log_block_queue().Size();

    action = stage_info._recovery_action.load(std::memory_order_acquire);
    os << ",";
    print_stage_info(stage_info._recovery.load(std::memory_order_acquire), action,
            Recoverer::action2str(static_cast<Recoverer::Action>(action)));
    //os << "/size=" << segment->GetRecoveryMaxSize();

    action = stage_info._dblwr_action.load(std::memory_order_acquire);
    os << ",";
    print_stage_info(stage_info._dblwr.load(std::memory_order_acquire), action,
            GcManager::action2str(static_cast<GcManager::Action>(action)));
    //const auto dblwr = segment->dblwr();
    //os << "/file_no=" << (dblwr ? dblwr->NextDumpFileNo() : 0);
    return os << "]";
}

Segment::Segment(ControlWeakPtr control,
    const std::string& cluster_id,
    const gaiadb::common::segment_t segment_id,
    gaiadb::common::replica_t replica_id,
    uint64_t version,
    uint64_t segment_size,
    bool enable_punch_hole,
    Status status,
    const std::string& db_path, int32_t store_id,
    ClusterPtr cluster)
    : _status(status),
    _init_flag(kUnInit),
    _stopped(false),
    _is_invalid_start_lsn(1),
    _disable(false),
    _control(control),
    _start_time(base::cpuwide_time_us()),
    _cluster_id(cluster_id),
    _segment_id(segment_id),
    _key(SEGMENT_KEY(cluster_id.c_str(), segment_id)),
    _segment_size(segment_size),
    _enable_punch_hole(enable_punch_hole),
    _compress_cfg(),
    _cluster(cluster),
    _psm_info(nullptr),
    _segment_physical_size(0),
    _append_db_size(0),
    _append_un_gc_size(0),
    _replica_id(replica_id),
    _version(version),
    _start_checkpoint_lsn(0),
    _last_apply_lsn(0),
    _start_lsn(0),
    _recovery_status(gaiadb::RECOVERY_UNKNOWN),
    _hash_val(Get32bitHash(cluster_id) + segment_id),
    _pre_disable(false),
    _wakeup_fetch_nr(0),
    _fetch_ctx(nullptr),
    _fetch_batch_idx(-1),
    _last_fetch_time(0),
    _fetch_quota_state(pspb::QuotaUninit),
    _wakeup_dblwr_nr(0),
    _dblwr_ctx(nullptr),
    _fetch_quota(nullptr),
    _ls_vdl(0),
    _ls_write_lsn(0),
    _ls_parse_lsn(0),
    _ls_dispatch_lsn(0),
    _fetch_lsn(0),
    _parse_lsn(0),
    _append_lsn(0),
    _gc_lsn(0),
    _peer_gc_lsn(0),
    _recovery_lsn(0),
    _seg_lowest_gc_lsn(0),
    _db_checkpoint_lsn(0),
    _db_append_lsn(0),
    _dblwr_checkpoint_lsn(0),
    _gc_delay_flag(0),
    _fetch_log_block_queue(),
    _parse_log_block_queue(),
    _append_log_block_queue(),
    _db_path(db_path),
    _store_id(store_id),
    _db_is_init(false),
    _rebalance_from(),
    _rebalance_version(),
    _peer_info(),
    _peer_last_recover_time_s(0),
    _recovery_info(),
    _stat_compress(),
    _stage_info(),
    _db_engine(nullptr),
    _append_db_engine(nullptr),
    _dblwr(nullptr),
    _space_page_manager(nullptr),
    _space_status_manager(nullptr),
    _extent_meta_manager(nullptr),
    _statistic(nullptr) {
    auto quota_ptr = FLAGS_psvr_enable_append_file ?
        &FLAGS_psvr_segment_fetch_max_buf_size_by_append :
        &FLAGS_psvr_segment_fetch_max_buf_size;
    _fetch_quota.reset(new Quota(quota_ptr));
    _db_engine.reset(new DBEngine());
    _append_db_engine.reset(new AppendDBEngine());
    _dblwr.reset(new Dblwr());
    _space_page_manager.reset(new SpacePageManager());
    _space_status_manager.reset(new SpaceStatusManager());
    _extent_meta_manager.reset(new ExtentMetaManager());
    set_global_statistic(stat_segment_count, 1);
}

Segment::~Segment() {
    if (!_stopped.load()) {
        Stop();
    }
    set_global_statistic(stat_segment_count, -1);
}

void Segment::CopyTo(SegmentPtr segment) {
    segment->InitPsmInfo(GetPsmInfo());
    // shared db data locks, protect the data from double writing.
    _db_engine->IncRef();
    segment->_db_engine = _db_engine;
    segment->_append_db_engine = _append_db_engine;
    segment->_dblwr = _dblwr;

    // copy other configs
    segment->_rebalance_from = _rebalance_from;
    segment->_rebalance_version = _rebalance_version;
}

void Segment::Stop() {
    if (!_stopped.exchange(true)) {
        TurnOffRecovery();
        if (_statistic) {
            _statistic->HideBvar();
        }
        if (_fetch_quota) {
            _fetch_quota->hide();
        }
        if (_db_engine && _db_engine->DecRef() == 1) {
            // in restarting segment, the db engine will be shared to the new segment.
            // destroying old segment does not close the db engine.
            _db_engine->Close();
            _append_db_engine->Close();
        }
    }
}

uint32_t Segment::GetClusterHashVal() const {
    return _cluster->hash_val();
}

gaia_apply::lsn_t Segment::GetClusterCnLowestLsn() const {
    return _cluster->real_cn_lowest_lsn();
}

void Segment::SetClusterCnLowestLsn(gaia_apply::lsn_t lsn) {
    _cluster->set_cn_lowest_lsn(lsn);
}

void Segment::SetClusterCnLowestGcLsn(gaia_apply::lsn_t lsn) {
    _cluster->set_cn_lowest_gc_lsn(lsn);
}

gaia_apply::lsn_t Segment::GetClusterPsLowestLsn() const {
    return _cluster->real_ps_lowest_lsn();
}

void Segment::SetClusterPsLowestLsn(gaia_apply::lsn_t lsn) {
    _cluster->set_ps_lowest_lsn(lsn);
}

void Segment::SetClusterPsLowestGcLsn(gaia_apply::lsn_t lsn) {
    _cluster->set_ps_lowest_gc_lsn(lsn);
}

bool Segment::InitMeta(const gaiapb::PageServerInfo& meta) {
    std::unique_lock lk(_shared_mutex);
    return InitConfigNoLock(meta);
}

bool Segment::InitLsn(const gaiapb::PageServerInfo& meta) {
    std::unique_lock lk(_shared_mutex);
    return InitLsnNoLock(meta);
}

bool Segment::InitLsnNoLock(const gaiapb::PageServerInfo& meta) {
    if (_fetch_lsn() > 0) {
        LOG(WARNING) << this << " init agian!!!";
        return false;
    }

    PSVR_ASSERT(is_init_db());

    _start_checkpoint_lsn = meta.checkpoint_lsn();
    _last_apply_lsn = meta.apply_lsn();

    if (_start_checkpoint_lsn < LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE) {
        if (_start_checkpoint_lsn != 0) {
            LOG(ERROR) << this << " invalid start lsn,"
                << " lsn:[" << _start_checkpoint_lsn
                << "]";
            return false;
        }
        _start_checkpoint_lsn = LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE;
    }

    _start_lsn = _start_checkpoint_lsn;
    if (_db_append_lsn != 0) {
        if (_db_append_lsn < _start_lsn) {
            LOG(ERROR) << this << " invalid db append lsn,"
                << " lsn:[" << _start_lsn
                << "] db_append_lsn:[" << _db_append_lsn
                << "]";
            return false;
        }
        _start_lsn = _db_append_lsn;
    }

    auto start_apply_lsn = _start_checkpoint_lsn;
    if (_db_checkpoint_lsn > 0) {
        if (_db_checkpoint_lsn < LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE) {
            LOG(ERROR) << this << " invalid db checkpoint lsn,"
                << " db_checkpoint_lsn:[" << _db_checkpoint_lsn
                << "]";
            return false;
        }
        start_apply_lsn = std::max(_db_checkpoint_lsn, _dblwr_checkpoint_lsn);
    } else {
        _append_db_engine->Init(start_apply_lsn);
    }

    _fetch_lsn.set(start_apply_lsn);
    _parse_lsn.set(start_apply_lsn);
    _append_lsn.set(start_apply_lsn);
    _gc_lsn.set(start_apply_lsn);
    _recovery_lsn.set(start_apply_lsn);
    SetClusterCnLowestLsn(start_apply_lsn);
    SetClusterPsLowestLsn(start_apply_lsn);

    _fetch_log_block_queue.SetlastLsn(start_apply_lsn);
    _parse_log_block_queue.SetlastLsn(start_apply_lsn);
    _append_log_block_queue.SetlastLsn(start_apply_lsn);

    if (AppendRecoverParseFinish()) {
        _init_flag.fetch_or(kInitAppendDB);
    }

    if (AppendRecoverFetchFinish()) {
        db::Status st = FinishAppendRecover();
        if (!st.IsOk()) {
            LOG(ERROR) << this << " close append db recovery failed,"
                << st;
            return false;
        }
    }

    LOG(NOTICE) << this << " init lsn ok,"
        << " start_checkpoint_lsn:[" << _start_checkpoint_lsn
        << "] start_lsn:[" << _start_lsn
        << "] start_apply_lsn:[" << start_apply_lsn
        << "] db_append_lsn:[" << _db_append_lsn
        << "] db_checkpoint_lsn:[" << _db_checkpoint_lsn
        << "]";
    return true;
}

void Segment::InitVersionNoLock(const gaiapb::PageServerInfo& meta) {
    if (meta.has_version()) {
        _version.store(meta.version());
    }
}

bool Segment::InitConfig(const gaiapb::PageServerInfo& meta, bool is_created) {
    std::unique_lock lk(_shared_mutex);
    if (is_created) {
        InitVersionNoLock(meta);
    } else {
        if (meta.has_version() && meta.version() != _version.load()) {
            InitVersionNoLock(meta);
            if (!StoreMetaNoLock()) {
                return false;
            }
        }
    }
    return InitConfigNoLock(meta);
}

bool Segment::InitConfigNoLock(const gaiapb::PageServerInfo& meta) {
    if (_segment_id != meta.segment_id()) {
        LOG(ERROR) << this << " segment id mismatch !"
            << " id1:[" << _segment_id
            << "] id2:[" << meta.segment_id()
            << "]";
        return false;
    }
    bool set_default_compress_cfg = true;
    if (meta.has_compress_cfg()) {
        // FIXME: PSM default config is false, but PS default is true.
        const auto& cfg = meta.compress_cfg();
        if (cfg.enable() || cfg.type() != "none" || cfg.level() != -1) {
            set_default_compress_cfg = false;
            SetCompressConfigNoLock(cfg.enable(), cfg.type(), cfg.level());
        }
    }
    if (set_default_compress_cfg) {
        std::string compress_type;
        get_compress_name(FLAGS_psvr_gc_compress_type, &compress_type);
        SetCompressConfigNoLock(true, compress_type, -1);
    }

    if (meta.has_recovery_status()) {
        _recovery_status.store(meta.recovery_status());
        _recovery_info.stopped = !(_recovery_status.load() == gaiadb::RECOVERY_IN);
    }
    _init_flag.fetch_or(kInitMeta);
    if (FLAGS_psvr_auto_enable_segment_statistic) {
        _statistic.reset(new Statistic(this, SEGMENT_KEY(_cluster_id.c_str(), _segment_id)));
        _fetch_quota->expose_as("seg_fetch_quota_total_remain", SEGMENT_KEY(_cluster_id.c_str(), _segment_id));
    }
    LOG(NOTICE) << this << " init config,"
        << " size:[" << _segment_size
        << "] recovery_status:[" << gaiadb::RecoveryStatus_Name(_recovery_status.load())
        << "] hash_val:[" << _hash_val
        << "] set_default_compress_cfg:[" << set_default_compress_cfg
        << "] enable_statistic:[" << FLAGS_psvr_auto_enable_segment_statistic
        << "]";
    return true;
}

void Segment::UpdateStatCompress(int64_t& sum_non_empty_page_count, int64_t& sum_compress_data_size) {
    // (NoLock) Only one compression thread executes at the same time
    if (!_stat_compress.inited) {
        _stat_compress.inited = true;
        LoadComperssLogNoLock();
    }
    _stat_compress.sort_data_size_mb = ToMB(_segment_physical_size.load());
    _stat_compress.sort_last_compress_time_s = _stat_compress.last_compress_time_s.load();
    _stat_compress.sort_compress_times = _stat_compress.compress_times.load();
    _stat_compress.sort_update_extent_num = _stat_compress.stat_update_page_count.get_value() / GAIADB_EXTENT_PAGE_NUM;
    _stat_compress.sort_drop_space_num = _stat_compress.stat_drop_space_num.get_value();

    sum_non_empty_page_count += _stat_compress.non_empty_page_count;
    sum_compress_data_size += _stat_compress.last_compress_data_size;
}

void Segment::LoadComperssLogNoLock() {
    std::string meta_file = base::string_printf("%s/%s", _db_path.c_str(), kCompressFileName);
    if (!std::filesystem::exists(meta_file)) {
        return;
    }
    gaiadb::common::Config config;
    if (!config.Load(meta_file)) {
        LOG(TRACE) << this << " load segment compress file failed, file:[" << meta_file << "]";
        return;
    }

    _stat_compress.last_compress_time_s = config.GetInt("compress", "last_compress_time_s", 0);
    _stat_compress.compress_times = config.GetInt("compress", "compress_times", 0);
    _stat_compress.non_empty_page_count = config.GetInt("compress", "non_empty_page_count", 0);
    _stat_compress.last_compress_data_size = config.GetInt("compress", "last_compress_data_size", 0);
}

void Segment::CompressFinish(bool succ, int64_t non_empty_page_count,
        int64_t last_compress_data_size) {
    ControlPtr control = _control.lock();
    if (!control || is_stopped() || is_delete()) {
        LOG(WARNING) << this << " server or segment stopped";
        return;
    }
    _stat_compress.last_compress_time_s = base::gettimeofday_s();
    if (!succ) {
        return;
    }

    if (FLAGS_psvr_sync_on_recovery_or_compression) {
        Sync();
    }

    _stat_compress.data_updated = false;
    ++_stat_compress.compress_times;
    _stat_compress.non_empty_page_count = non_empty_page_count;
    _stat_compress.last_compress_data_size = last_compress_data_size;

    gaiadb::common::Config config;
    config.SetInt("compress", "last_compress_time_s", _stat_compress.last_compress_time_s.load());
    config.SetInt("compress", "compress_times", _stat_compress.compress_times.load());
    config.SetInt("compress", "non_empty_page_count", _stat_compress.non_empty_page_count.load());
    config.SetInt("compress", "last_compress_data_size", _stat_compress.last_compress_data_size.load());

    std::string meta_file = base::string_printf("%s/%s", _db_path.c_str(), kCompressFileName);
    if (!atomic_write_file(meta_file, config.ToString(), true/*sync*/)) {
        StorePtr s = control->store_manager()->GetStore(_store_id);
        if (s) {
            s->IncIOErrorCount(TRACE_FILE_LINE_C);
        }
        LOG(ERROR) << this << " fail to store meta:[" << meta_file << "]";
        return;
    }
    db::Status status = db::sync_directoryx(_db_path.c_str());
    if (!status.IsOk()) {
        LOG(ERROR) << this << " fail to sync directory:[" << _db_path << "], " << status;
    }
}

void Segment::SetCompressConfig(const pspb::CompressConfig& cfg) {
    std::unique_lock lk(_light_shared_mutex);
    SetCompressConfigNoLock(cfg.enable(), cfg.type(), cfg.level());
}

void Segment::GetCompressConfig(pspb::CompressConfig* cfg) {
    std::shared_lock slk(_light_shared_mutex);
    GetCompressConfigNoLock(cfg);
}

void Segment::SetCompressConfigNoLock(bool enable, const std::string& name, int32_t level) {
    _compress_cfg.enable = enable;
    if (enable) {
        _compress_cfg.enable = get_compress_type(name, &_compress_cfg.type);
        _compress_cfg.level = level;
    }
}

void Segment::GetCompressConfigNoLock(pspb::CompressConfig* cfg) {
    cfg->set_enable(_compress_cfg.enable);
    get_compress_name(_compress_cfg.type, cfg->mutable_type());
    cfg->set_level(_compress_cfg.level);
}

void Segment::CopyMetaDataForStore(MetaData* meta_data) {
    meta_data->cluster_id = _cluster_id;
    meta_data->segment_id = _segment_id;
    meta_data->segment_size = _segment_size;
    meta_data->replica_id = _replica_id.load();
    meta_data->version = _version.load();
    meta_data->status = status2str();
    meta_data->manager_address = _psm_info->address();
    meta_data->meta_version = SegmentMetaVersion;
    meta_data->rebalance_from = _rebalance_from;
    meta_data->rebalance_version = _rebalance_version;
}

bool Segment::StoreMetaNoLock() {
    MetaData meta_data;
    CopyMetaDataForStore(&meta_data);
    return StoreMetaNoLock(meta_data);
}

bool Segment::StoreMetaNoLock(const MetaData& meta_data) {
    ControlPtr control = _control.lock();
    if (!control || is_stopped()) {
        LOG(WARNING) << this << " server or segment stopped";
        return false;
    }
    if (!control->multi_type()) {
        // without save on single mode
        return true;
    }
    gaiadb::common::Config config;
    config.SetString("segment", "cluster_id", meta_data.cluster_id);
    config.SetInt("segment", "segment_id", meta_data.segment_id);
    config.SetInt("segment", "segment_size", meta_data.segment_size);
    config.SetInt("segment", "replica_id", meta_data.replica_id);
    if (meta_data.version > 0) {
        config.SetInt("segment", "version", meta_data.version);
    }
    config.SetString("segment", "status", meta_data.status);
    config.SetString("segment", "manager_address", meta_data.manager_address);
    config.SetInt("segment", "meta_version", meta_data.meta_version);
    /* version=2 changed */
    config.SetString("segment", "brief", base::string_printf("%s/%u@%u",
                meta_data.cluster_id.c_str(), meta_data.segment_id, meta_data.replica_id));
    /* version=2 end */
    if (!_rebalance_from.empty()) {
        config.SetString("rebalance", "from", meta_data.rebalance_from);
        config.SetInt("rebalance", "version", meta_data.rebalance_version);
    }
    std::string meta_file = base::string_printf("%s/%s", _db_path.c_str(), kMetaFileName);
    if (!atomic_write_file(meta_file, config.ToString(), true/*sync*/)) {
        StorePtr s = control->store_manager()->GetStore(_store_id);
        if (s) {
            s->IncIOErrorCount(TRACE_FILE_LINE_C);
        }
        LOG(ERROR) << this << " fail to store meta:[" << meta_file << "]";
        return false;
    }
    db::Status status = db::sync_directoryx(_db_path.c_str());
    if (!status.IsOk()) {
        LOG(ERROR) << this << " fail to sync directory:[" << _db_path << "], " << status;
        return false;
    }
    _meta_version = meta_data.meta_version;
    return true;
}

PsmInfoPtr Segment::GetPsmInfo() {
    std::shared_lock slk(_light_shared_mutex);
    return _psm_info;
}

// only for create
void Segment::InitPsmInfo(PsmInfoPtr psm_info) {
    std::unique_lock lk(_light_shared_mutex);
    PSVR_ASSERT(_psm_info == nullptr);
    _psm_info = psm_info;
}

bool Segment::ResetPsmInfo(PsmInfoPtr psm_info) {
    {
        std::shared_lock slk(_light_shared_mutex);
        if (_psm_info == psm_info) {
            return true;
        }
    }
    {
        // dont block rpc
        std::unique_lock lk(_shared_mutex, std::try_to_lock);
        if (!lk) {
            return false;
        }
        MetaData meta_data;
        CopyMetaDataForStore(&meta_data);
        meta_data.manager_address = psm_info->address();
        if (!StoreMetaNoLock(meta_data)) {
            return false;
        }
    }
    {
        std::unique_lock lk(_light_shared_mutex);
        _psm_info = psm_info;
    }
    return true;
}

bool Segment::GetRebalanceNode(std::string* from, uint64_t* version) {
    std::shared_lock slk(_light_shared_mutex);
    if (_rebalance_from.empty()) {
        return false;
    }
    *from = _rebalance_from;
    *version = _rebalance_version;
    return true;
}

void Segment::SetRebalanceNode(const std::string& from, uint64_t version) {
    std::unique_lock lk(_light_shared_mutex);
    _rebalance_from = from;
    _rebalance_version = version;
}

void Segment::ClearRebalanceNode() {
    {
        std::shared_lock slk(_light_shared_mutex);
        if (_rebalance_from.empty()) {
            return;
        }
    }
    {
        std::unique_lock lk(_shared_mutex);
        MetaData meta_data;
        CopyMetaDataForStore(&meta_data);
        meta_data.rebalance_from.clear();
        meta_data.rebalance_version = 0;
        if (!StoreMetaNoLock(meta_data)) {
            return;
        }
    }
    {
        std::unique_lock llk(_light_shared_mutex);
        _rebalance_from.clear();
        _rebalance_version = 0;
    }
}

bool Segment::InitPathNoLock(const std::string& trash_path) {
    if (_db_is_init) {
        LOG(ERROR) << this << " init segment db agian?"
            << " store_id:[" << _store_id
            << "]";
        return false;
    }
    // if db path exists, move to trash
    std::error_code ec;
    if (std::filesystem::exists(_db_path, ec)) {
        if (!std::filesystem::exists(trash_path, ec)) {
            if (!std::filesystem::create_directory(trash_path, ec)) {
                LOG(ERROR) << this << " init trash dir:[" << trash_path << "] failed, " << ec.message();
                return false;
            }
            const auto trash_parent_path = std::filesystem::path(trash_path).parent_path();
            db::Status status = db::sync_directoryx(trash_parent_path.c_str());
            if (!status.IsOk()) {
                LOG(ERROR) << this << " sync trash parent directory failed, dir:["
                    << trash_parent_path << "], " << status;
                return false;
            }
        }
        std::string tmp = base::string_printf("%s/%s_%s_%u_%ld", trash_path.c_str(),
                kTrashSegmentPrefixName.c_str(), _cluster_id.c_str(), _segment_id, base::gettimeofday_s());
        uint32_t i = 0;
        while (std::filesystem::exists(tmp, ec)) {
            tmp = base::string_printf("%s/%s_%s_%u_%ld_%u", trash_path.c_str(),
                    kTrashSegmentPrefixName.c_str(), _cluster_id.c_str(), _segment_id, base::gettimeofday_s(), ++i);
        }
        std::filesystem::rename(_db_path, tmp, ec);
        if (ec) {
            LOG(ERROR) << this << " fail to rename file:[" << _db_path << "] to dst:[" << tmp << "] " << ec.message();
            return false;
        }
        db::Status source_status = db::sync_directoryx(
                std::filesystem::path(_db_path).parent_path().c_str());
        db::Status target_status = db::sync_directoryx(trash_path.c_str());
        if (!source_status.IsOk() || !target_status.IsOk()) {
            LOG(ERROR) << this << " sync segment rename directories failed, source:["
                << std::filesystem::path(_db_path).parent_path()
                << "], source_status:[" << source_status
                << "], target:[" << trash_path << "], target_status:[" << target_status << "]";
            return false;
        }
    }
    if (!std::filesystem::create_directories(_db_path, ec)) {
        LOG(ERROR) << this << " create engine:[" << _db_path << "] failed, " << ec.message();
        return false;
    }
    const auto db_parent_path = std::filesystem::path(_db_path).parent_path();
    db::Status status = db::sync_directoryx(db_parent_path.c_str());
    if (!status.IsOk()) {
        LOG(ERROR) << this << " sync segment parent directory failed, dir:["
            << db_parent_path << "], " << status;
        return false;
    }
    _db_is_init = true;
    return true;
}

bool Segment::CreateMeta(const std::string& trash_path) {
    std::unique_lock lk(_shared_mutex);
    if (!InitPathNoLock(trash_path)) {
        return false;
    }
    if (!StoreMetaNoLock()) {
        _db_is_init = false;
        return false;
    }
    return true;
}

bool Segment::LoadEngineWithMeta(const gaiapb::PageServerInfo& meta) {
    std::unique_lock lk(_shared_mutex);
    LOG(TRACE) << this << " status:[" << status2str() << "]";
    if (_status.load() != Status::kPrepare) {
        return false;
    }
    if (_segment_id != meta.segment_id()) {
        LOG(ERROR) << this << " segment id mismatch !"
            << " id1:[" << _segment_id
            << "] id2:[" << meta.segment_id()
            << "]";
        return false;
    }
    _replica_id.store(meta.replica_id());
    InitVersionNoLock(meta);
    InitConfigNoLock(meta);

    auto bf_status = _status.load();
    auto bf_init_flag = _init_flag.load();
    if (!OpenEngineNoLock(false)) {
        return false;
    }

    InitLsnNoLock(meta);

    if (!StoreMetaNoLock()) {
        CloseEngineNoLock(bf_status, bf_init_flag);
        return false;
    }
    return true;
}

bool Segment::OpenEngine(bool create_if_missing) {
    std::unique_lock lk(_shared_mutex);
    return OpenEngineNoLock(create_if_missing);
}

bool Segment::OpenEngineNoLock(bool create_if_missing) {
    ControlPtr control = _control.lock();
    if (!control) {
        LOG(WARNING) << this << " server stopped";
        return false;
    }
    if (control->multi_type()) {
        if (_store_id < 0) {
            LOG(ERROR) << this << " uninit store id,"
                << " store_id:[" << _store_id
                << "]";
            return false;
        }
    }
    db::OpenOptions options;
    options.engine_type = db::EngineType::kFile;
    options.page_size = gaia_apply::FLAGS_univ_page_size;
    options.create_if_missing = create_if_missing;
    if (control->multi_type()) {
        options.file.name = base::string_printf("%s/%s", _db_path.c_str(), kDataFileName);
        options.file.create_ckp = false;
        options.file.size = FLAGS_psvr_enable_empty_db_file_on_creating ? 0 : _segment_size;
    } else {
        PSVR_ASSERT(_store_id == 0);
        options.file.name = base::string_printf("%s/gaiadb_page_store_%u_%u.ibd",
                _db_path.c_str(), _segment_id, _replica_id.load());
        options.file.create_ckp = true;
        options.file.ckp_name = base::string_printf("%s/gaiadb_checkpoint_%u_%u.ckp",
                _db_path.c_str(), _segment_id, _replica_id.load());
        options.file.ckp_size = FLAGS_psvr_ckp_file_size;
        options.file.size = _segment_size;
    }
    options.file.block_size = gaia_apply::ULINT_UNDEFINED;
    options.file.max_size = _segment_size;
    options.file.enable_punch_hole = _enable_punch_hole;

    db::Status s = _db_engine->Open(options);
    if (!s.IsOk()) {
        LOG(ERROR) << this << " fail to open db engine,"
            << " engine_type:[" << static_cast<uint32_t>(options.engine_type)
            << "] page_size:[" << options.page_size
            << "] file.name:[" << options.file.name
            << "] file.size:[" << options.file.size
            << "] " << s;
        return false;
    }

    const auto dblwr_path = base::string_printf("%s/%s", _db_path.c_str(), kDblwrFilePath.c_str());
    s = _dblwr->Open(std::max(0, FLAGS_psvr_dblwr_max_page_num), dblwr_path, &_dblwr_checkpoint_lsn);
    if (!s.IsOk()) {
        LOG(ERROR) << this << " fail to open dblwr db engine,"
            << " db_path:[" << dblwr_path
            << "] " << s;
        return false;
    }

    const auto append_path = base::string_printf("%s/%s", _db_path.c_str(), kAppendFilePath.c_str());
    s = _append_db_engine->Open(append_path, _dblwr_checkpoint_lsn, &_db_checkpoint_lsn, &_db_append_lsn);
    if (!s.IsOk()) {
        LOG(ERROR) << this << " fail to open append db engine,"
            << " db_path:[" << append_path
            << "] " << s;
        return false;
    }

    LOG(NOTICE) << this << " open engine ok,"
        << " db_checkpoint_lsn:[" << _db_checkpoint_lsn
        << "] db_append_lsn:[" << _db_append_lsn
        << "] dblwr_checkpoint_lsn:[" << _dblwr_checkpoint_lsn
        << "]";

    _status.store(Status::kOpen);
    _init_flag.fetch_or(kInitDB);
    // update db size
    UpdateDBSizeNoLock();
    return true;
}

bool Segment::CloseEngineNoLock(Status status, uint32_t init_flag) {
    _status.store(status);
    _init_flag.store(init_flag);
    if (_db_engine) {
        db::Status s = _db_engine->Close();
        if (!s.IsOk()) {
            LOG(WARNING) << this << " fail to close db engine, " << s;
            return false;
        }
        s = _append_db_engine->Close();
        if (!s.IsOk()) {
            LOG(WARNING) << this << " fail to close append db engine, " << s;
            return false;
        }
    }
    return true;
}

bool Segment::CloseEngine() {
    std::unique_lock lk(_shared_mutex);
    return CloseEngineNoLock(_status.load(), _init_flag.load());
}

bool Segment::CreateEngine(const std::string& trash_path) {
    std::unique_lock lk(_shared_mutex);
    if (!InitPathNoLock(trash_path)) {
        return false;
    }
    auto bf_status = _status.load();
    auto bf_init_flag = _init_flag.load();
    if (!OpenEngineNoLock(true)) {
        _db_is_init = false;
        return false;
    }
    if (!StoreMetaNoLock()) {
        _db_is_init = false;
        CloseEngineNoLock(bf_status, bf_init_flag);
        return false;
    }
    LOG(NOTICE) << this << " create ok";
    return true;
}

bool Segment::Delete() {
    std::unique_lock lk(_shared_mutex);
    if (is_delete()) {
        return true;
    }
    MetaData meta_data;
    CopyMetaDataForStore(&meta_data);
    meta_data.status = status2str(Status::kDelete);
    if (!StoreMetaNoLock(meta_data)) {
        return false;
    }
    _status.store(Status::kDelete);
    TurnOffRecovery();
    if (_statistic) {
        // create again if before shared_ptr not release, bvar will print error log
        _statistic->HideBvar();
    }
    if (_fetch_quota) {
        _fetch_quota->hide();
    }
    if (_db_engine) {
        _db_engine->Close();
        _append_db_engine->Close();
    }
    return true;
}

bool Segment::ReOpen(const gaiapb::PageServerInfo& meta) {
    std::unique_lock lk(_shared_mutex);
    InitVersionNoLock(meta);
    if (!InitConfigNoLock(meta)) {
        return false;
    }
    std::error_code ec;
    if (!std::filesystem::exists(_db_path, ec)) {
        LOG(WARNING) << this << " reopen failed, db path not exists,"
            << " path:[" << _db_path << "]";
        return false;
    }
    _db_is_init = true;
    auto bf_status = _status.load();
    auto bf_init_flag = _init_flag.load();
    if (!OpenEngineNoLock(true)) {
        _db_is_init = false;
        return false;
    }
    if (!StoreMetaNoLock()) {
        _db_is_init = false;
        CloseEngineNoLock(bf_status, bf_init_flag);
        return false;
    }
    return InitLsnNoLock(meta);
}

bool Segment::GetPreDisable() {
    return _pre_disable.exchange(true) == false;
}

void Segment::PutPreDisable() {
    _pre_disable.store(false);
}

bool Segment::PreDisable() {
    std::unique_lock lk(_shared_mutex);
    ControlPtr control = _control.lock();
    if (!control || is_stopped()) {
        LOG(WARNING) << this << " server or segment stopped";
        return false;
    }
    if (!control->multi_type()) {
        LOG(WARNING) << this << " only exec in mulit type";
        return false;
    }

    if (!_disable.exchange(true)) {
        TurnOffRecovery();
        if (_statistic) {
            _statistic->HideBvar();
        }
        if (_fetch_quota) {
            _fetch_quota->hide();
        }
        if (_db_engine) {
            _db_engine->Close();
            _append_db_engine->Close();
        }
    }
    return _disable.load() == true;
}

bool Segment::Disable() {
    std::unique_lock lk(_shared_mutex);
    if (_disable.load() != true) {
        LOG(WARNING) << this << " not is disable";
        return false;
    }
    std::error_code ec;
    std::string disable_path = base::string_printf("%s/disable", _db_path.c_str());
    if (!std::filesystem::exists(disable_path, ec)) {
        if (!std::filesystem::create_directory(disable_path, ec)) {
            LOG(ERROR) << this << " init disable dir:[" << disable_path << "] failed, " << ec.message();
            return false;
        }
        db::Status status = db::sync_directoryx(_db_path.c_str());
        if (!status.IsOk()) {
            LOG(ERROR) << this << " sync segment directory after creating disable path failed, dir:["
                << _db_path << "], " << status;
            return false;
        }
    }
    // move db file
    for (auto& file_name : {kDataFileName, kMetaFileName, kCompressFileName}) {
        auto cur_file = base::string_printf("%s/%s", _db_path.c_str(), file_name);
        if (std::filesystem::exists(cur_file, ec)) {
            auto dst_file = base::string_printf("%s/%s_%lu",
                    disable_path.c_str(), file_name, _version.load());
            std::filesystem::rename(cur_file, dst_file, ec);
            if (ec) {
                LOG(ERROR) << this << " fail to rename file:[" << cur_file
                    << "] to dst:[" << dst_file << "] " << ec.message();
                return false;
            }
        }
    }
    db::Status source_status = db::sync_directoryx(_db_path.c_str());
    db::Status target_status = db::sync_directoryx(disable_path.c_str());
    if (!source_status.IsOk() || !target_status.IsOk()) {
        LOG(ERROR) << this << " sync disable directories failed, source:["
            << _db_path << "], source_status:[" << source_status
            << "], target:[" << disable_path << "], target_status:[" << target_status << "]";
        return false;
    }
    return true;
}

bool Segment::UpdateMetaVersionIf() {
    std::unique_lock lk(_shared_mutex);
    if (_meta_version != SegmentMetaVersion) {
        return StoreMetaNoLock();
    }
    return true;
}

void Segment::Sync() {
    ControlPtr control = _control.lock();
    if (!FLAGS_psvr_disable_sync) {
         Timer timer(base::Timer::STARTED);
        _db_engine->Sync(FLAGS_psvr_enable_fdatasync);
        if (control) {
            control->store_manager()->StatSyncLat(_store_id, timer.u_elapsed());
        }
    }
}

void Segment::UpdateDBSize() {
    //std::unique_lock lk(_shared_mutex);
    UpdateDBSizeNoLock();
}

void Segment::UpdateDBSizeNoLock() {
    if (is_active() && is_init_db() && !is_stopped()) {
        int64_t size = _db_engine->GetSize(true);
        if (size >= 0) {
            _segment_physical_size.store(size, std::memory_order_relaxed);
        } else {
            LOG(WARNING) << this << " fail to get engine physical size.";
        }
        UpdateAppendSize();
    }
}

bool Segment::AddFetchLogBlock(LogBlockPtr log_block) {
    // check log_block lsn is rollback
    if (log_block->data_length() > 0) {
        const gaia_apply::lsn_t first_lsn = get_record_end_lsn(log_block->data());
        if (first_lsn < _fetch_lsn()) {
            LOG(ERROR) << this << " fetch log error,"
                << " cur_fetch_lsn:[" << _fetch_lsn()
                << "] next_log_first_lsn:[" << first_lsn
                << "]";
            return false;
        }
    }

    gaia_apply::lsn_t queue_last_lsn = 0;
    if (!_fetch_log_block_queue.PushBack(log_block, &queue_last_lsn)) {
        LOG(ERROR) << this << " fetch log error,"
            << " cur_fetch_lsn:[" << _fetch_lsn()
            << "] queue_last_lsn:[" << queue_last_lsn
            << "] log_block:[" << log_block
            << "]";
        return false;
    }

    _fetch_lsn(log_block->end_lsn, true);

    set_statistic(stat_fetch_logblock_count, 1);
    set_statistic(stat_fetch_logblock_data_bw, log_block->data_length());
    if (log_block->from_append_file != FROM_NONE) {
        set_statistic(stat_recover_redo_rec_log_bw, log_block->data_length());
    }

    PSVR_LOG(TRACE, log_block->log_id) << this << " add log block to fetcher queue,"
        << " lsn:[" << log_block->start_lsn << "," << log_block->end_lsn << "]";

    set_global_statistic(stat_record_unparse_size, log_block->data_length());
    return true;
}

void Segment::AddParseLogBlock(LogBlockPtr log_block) {
    PSVR_ASSERT(log_block->is_parsed == 0);
    log_block->is_parsed = 1;

    bool ret = _parse_log_block_queue.PushBack(log_block);
    PSVR_ASSERT(ret);
    _parse_lsn(log_block->end_lsn, true);

    if (!is_init_append_db() && AppendRecoverParseFinish()) {
        _init_flag.fetch_or(kInitAppendDB);
    }

    set_statistic(stat_parse_logblock_count, 1);
    set_statistic(stat_parse_logblock_lat, log_block->latency_us());
    set_statistic(stat_parse_records_count, log_block->valid_records_count);
    set_cluster_stat(_cluster, stat_redo_size_count, log_block->valid_records_count);
    set_global_statistic(stat_record_unparse_size, -log_block->data_length());
    set_global_statistic(stat_record_ungc_size, log_block->data_length());

    PSVR_LOG(TRACE, log_block->log_id) << this << " add log block to parser queue,"
        << " lsn:[" << log_block->start_lsn << "," << log_block->end_lsn << "]";
    LOG_EVERY_SECOND(NOTICE) << this << " parse success logblock,"
        << " end_lsn:[" << log_block->end_lsn
        << "] lsn_size:[" << log_block->lsn_length()
        << "]";
}

void Segment::AddAppendLogBlock(LogBlockPtr log_block) {
    auto head = log_block;
    while (head) {
        bool ret = _append_log_block_queue.PushBack(head);
        PSVR_ASSERT(ret);

        set_statistic(stat_append_logblock_count, 1);
        _append_un_gc_size.fetch_add(head->data_length(), std::memory_order_relaxed);
        if (FLAGS_psvr_enable_append_file) {
            _append_lsn(head->end_lsn, true);
            LOG_EVERY_SECOND(NOTICE) << this << " append gc success log block,"
                << " end_lsn:[" << head->end_lsn
                << "] lsn_size:[" << head->lsn_length()
                << "]";
        }

        auto next = head->next;
        head->next = nullptr;
        head = next;
    }
}

LogBlockPtr Segment::NextParseLogBlock(bool plug) {
    LogBlockPtr log_block = nullptr;
    if (plug ? _fetch_log_block_queue.Plug() : !_fetch_log_block_queue.UnPlug()) {
        log_block = _fetch_log_block_queue.Pop();
        PSVR_ASSERT(log_block);
    }
    return log_block;
}

LogBlockPtr Segment::NextAppendLogBlock(bool plug, uint64_t unplug_size) {
    LogBlockPtr log_block = nullptr;
    if (plug ? _parse_log_block_queue.Plug(1) : !_parse_log_block_queue.UnPlug(unplug_size)) {
        log_block = _parse_log_block_queue.Pop();
        PSVR_ASSERT(log_block);

        uint64_t merge_num = 1;
        const uint64_t max_merge_num = std::min<uint64_t>(
                _parse_log_block_queue.Size(), IOV_MAX / 3);
        const uint64_t max_buf_size = FLAGS_psvr_append_merge_max_buf_size;
        uint64_t total_buf_size = log_block->buf_size;
        auto head = log_block;
        while (merge_num < max_merge_num && total_buf_size < max_buf_size) {
            if (head->from_append_file == FROM_LOCAL) {
                break;
            }
            auto next = _parse_log_block_queue.Pop(max_buf_size - total_buf_size);
            if (!next) {
                break;
            }

            total_buf_size += next->buf_size;
            ++merge_num;

            head->next = next;
            head = next;
        }
    }

    return log_block;
}

LogBlockPtr Segment::NextGcLogBlock(bool plug, uint64_t plug_size) {
    LogBlockPtr log_block = nullptr;
    if (plug ? _append_log_block_queue.Plug(plug_size) : !_append_log_block_queue.UnPlug()) {
        log_block = _append_log_block_queue.Pop();
        PSVR_ASSERT(log_block);
    }
    return log_block;
}

void Segment::DropSpace(gaia_apply::space_id_t id, gaia_apply::lsn_t lsn) {
    PSVR_ASSERT(GetClusterCnLowestLsn() >= lsn);
    bool ret = _extent_meta_manager->CleanSpaceExtent(id);
    LOG(NOTICE) << this << " gc drop space:[" << id
        << "] rec_lsn:[" << lsn
        << "] ret:[" << ret
        << "]";
    _recovery_lsn(lsn, true);
    AddGcDropSpaceInRecovery(id, lsn);
    _cluster->ignore_corrupt_info()->RemoveSegmentSpace(_segment_id, id,
            FLAGS_psvr_gc_clear_ignore_cluster_space);
    _stat_compress.stat_drop_space_num << 1;
}

void Segment::RetryPushGcLsn(LogBlockPtr log_block, const LogBlockChunk& chunk) {
    if (chunk.real_gc_page_count) {
        Sync();
        _stat_compress.stat_update_page_count << chunk.real_gc_page_count;
        if (!_stat_compress.data_updated) {
            _stat_compress.data_updated = true;
        }
    }

    gaia_apply::lsn_t lowest_lsn = chunk.incomplete_lift_start_lsn.load();
    for (auto& it : log_block->chunks) {
        const gaia_apply::lsn_t lsn = it->incomplete_lift_start_lsn.load();
        if (lsn < lowest_lsn) {
            lowest_lsn = lsn;
        }
    }
    PSVR_ASSERT(GetClusterCnLowestLsn() >= lowest_lsn);
    _gc_lsn(lowest_lsn, true);
    if (!FLAGS_psvr_enable_append_file) {
        _append_lsn(lowest_lsn, true);
    }
}

void Segment::PushGcLsn(LogBlockPtr log_block) {
    ControlPtr control = _control.lock();
    if (!control) {
        return;
    }
    PSVR_ASSERT(GetClusterCnLowestLsn() >= log_block->end_lsn);

    if (!FLAGS_psvr_enable_append_file) {
        _append_lsn(log_block->end_lsn, true);
    }

    _gc_lsn(log_block->end_lsn, true);

    _append_un_gc_size.fetch_sub(log_block->data_length(), std::memory_order_relaxed);

    set_statistic(stat_gc_logblock_count, 1);
    set_statistic(stat_gc_logblock_lat, log_block->latency_us());
    set_statistic(stat_apply_records_count, log_block->valid_records_count);
    set_global_statistic(stat_record_ungc_size, -log_block->data_length());

    control->store_manager()->StatStoreGcInfo(_store_id,
            log_block->data_length(), log_block->real_gc_page_count.load());

    PSVR_LOG(TRACE, log_block->log_id) << this << " gc log block ok,"
        << " lsn:[" << log_block->start_lsn << "," << log_block->end_lsn << "]";
    LOG_EVERY_SECOND(NOTICE) << this << " gc success log block,"
        << " end_lsn:[" << log_block->end_lsn
        << "] lsn_size:[" << log_block->lsn_length()
        << "]";
}

void Segment::SetGcDelayForRecovery(bool delay) {
    if (delay) {
        _gc_delay_flag.fetch_add(1);
    } else {
        _gc_delay_flag.fetch_sub(1);
    }
}

bool Segment::GcDelayForRecovery(gaia_apply::lsn_t lsn) {
    auto lsn2 = std::max(recovery_lsn(), gc_lsn());
    return _gc_delay_flag.load(std::memory_order_relaxed) > 0
        && recovery_status() == gaiadb::RECOVERY_IN
        && (FLAGS_psvr_enable_append_file || _peer_gc_lsn() < std::max(lsn, lsn2));
}

gaia_apply::lsn_t Segment::GetSpaceSafeTrimLsn(gaia_apply::space_id_t id) {
    return _space_status_manager->GetSafeTrimLsn(id);
}

bool Segment::SetSpaceSafeTrimLsn(gaia_apply::space_id_t id, gaia_apply::lsn_t lsn) {
    return _space_status_manager->SetSafeTrimLsn(id, lsn);
}

uint32_t Segment::GetSpaceStatus(gaia_apply::space_id_t id) const {
    return _space_status_manager->GetSpaceStatus(id);
}

bool Segment::SetSpaceStatus(gaia_apply::space_id_t id, uint32_t s) {
    bool ret = _space_status_manager->SetSpaceStatus(id, s);
    if (!ret && space_status_with_psm(s)) {
        LOG(WARNING) << this << " update space stauts failed,"
            << " space:[" << id
            << "] status:[" << s
            << "] cur_status:[" << GetSpaceStatus(id)
            << "]";
    }
    return ret;
}

void Segment::ClearUseLessSpaceStatus() {
     int32_t drop_n = _space_status_manager->ClearUseLessSpaceStatus();
     LOG(NOTICE) << this << " drop space status,"
         << " drop_num:[" << drop_n
         << "] total:[" << _space_status_manager->GetSpaceStatusCount()
         << "]";
}

size_t Segment::GetSpaceStatusCount() const  {
    return _space_status_manager->GetSpaceStatusCount();
}

uint32_t Segment::GetSpaceEncryptStatus(gaia_apply::space_id_t id) const {
    return _space_status_manager->GetEncryptSpaceStatus(id);
}

bool Segment::SetSpaceEncryptStatus(gaia_apply::space_id_t id, uint32_t s) {
    bool ret = _space_status_manager->SetSpaceEncryptStatus(id, s);
    if (!ret) {
        LOG(WARNING) << this << " update space encrypt stauts failed,"
                     << " space:[" << id << "] status:[" << s << "] cur_status:["
                     << GetSpaceEncryptStatus(id) << "]";
    }
    return ret;
}

PagePtr Segment::GetPage(gaia_apply::space_id_t id,
        gaia_apply::page_no_t page_no, bool create_if_missing) {
    return _space_page_manager->GetPage(id, page_no, create_if_missing);
}

void Segment::InitSpaceStatusWithPsm(gaia_apply::space_id_t id, bool not_exists) {
    uint32_t status = kSpaceStatusWithPSM;
    status |= not_exists ? kSpaceStatusDeleted : kSpaceStatusWork;
    LogBlockPtr log_block(new LogBlock(EventOp::kGetSpaceMeta, id, status));
    _fetch_log_block_queue.PushFront(log_block);
    PutSpaceReqLock(id);
}

void Segment::InitAllSpaceId(const gaiapb::GetAllSpaceIdsResponse& rsp) {
    for (int32_t i = 0; i < rsp.space_ids_size(); ++i) {
        const auto space_id = rsp.space_ids(i);
        uint32_t status = kSpaceStatusWork | kSpaceStatusWithPSM;
        SetSpaceStatus(space_id, status);
    }
    for (int32_t i = 0; i < rsp.encrypt_space_ids_size(); ++i) {
        const auto space_id = rsp.encrypt_space_ids(i);
        uint32_t encrypt_status = kSpaceEncryptStatusEnable | kSpaceEncryptStatusWithPSM;
        SetSpaceEncryptStatus(space_id, encrypt_status);
    }
}

bool Segment::ParseLogBlockToLogRecords(int64_t log_id, LogBlockPtr log_block) {
    if (BAIDU_UNLIKELY(_parse_lsn() > log_block->end_lsn)) {
        PSVR_LOG(ERROR, log_id) << this << " parse BUG, block_end_lsn:[" << log_block->end_lsn
            << "] < parsed_lsn:[" << _parse_lsn()
            << "] log_block:[" << log_block
            << "] abort!!!";
        return false;
    }

    PSVR_LOG(TRACE, log_id) << this << " parse log block begin,"
        << " end_lsn[" << log_block->end_lsn
        << "] data_length:[" << log_block->data_length()
        << "]";

    if (BAIDU_UNLIKELY(log_block->is_parsed)) {
        PSVR_LOG(ERROR, log_id) << this << " why we parse this block twice ???"
            << " log_block:[" << log_block
            << "]";
        return false;
    }


    if (log_block->data_length() == 0) {
        AddParseLogBlock(log_block);
        return true;
    }

    {
        Timer timer(base::Timer::STARTED);
        gaia_apply::lsn_t rec_end_lsn = _parse_lsn();
        gaia_apply::byte* start_ptr = log_block->parse_ptr;
        gaia_apply::byte* end_ptr = log_block->buf + log_block->data_length();
        /* Parse rec from ptr */
        while (start_ptr < end_ptr) {
            const auto remaining =
                    static_cast<size_t>(end_ptr - start_ptr);
            if (remaining <= sizeof(uint64_t)) {
                PSVR_LOG(ERROR, log_id) << this
                    << " parse failed, redo record is incomplete,"
                    << " remaining:[" << remaining
                    << "] ptr:[" << PTR_P(start_ptr)
                    << "] end_ptr:[" << PTR_P(end_ptr)
                    << "] log_block:[" << log_block
                    << "]";
                return false;
            }

            /* data:    | 8bytes(end_lsn) | redo | 8bytes | redo | ... |
             * end_lsn is the end of the redo record*/
            if (rec_end_lsn >= get_record_end_lsn(start_ptr)) {
                PSVR_LOG(ERROR, log_id) << this <<  " parse error, last rec lsn is bigger,"
                    << " rec_lsn:[" << get_record_end_lsn(start_ptr)
                    << "] last_rec_lsn:[" << rec_end_lsn
                    << "] head:[" << PTR_P(log_block->data())
                    << "] ptr:[" << PTR_P(start_ptr)
                    << "] end_ptr:[" << PTR_P(end_ptr)
                    << "] log_block:[" << log_block
                    << "]";
                return false;
            }

            rec_end_lsn = get_record_end_lsn(start_ptr);
            start_ptr += 8;

            LogRecord* log_record = nullptr;
            gaia_apply::ulint record_len = 0;
            void* record_storage = log_block->mb_arena.Alloc(sizeof(LogRecord));
            if (!record_storage) {
                PSVR_LOG(FATAL, log_id) << this
                    << " allocate log record storage failed,"
                    << " log_block:[" << log_block << "]";
                return false;
            }
            auto st = parse_append_redo_record(
                    start_ptr,
                    end_ptr,
                    rec_end_lsn,
                    record_storage,
                    &log_record,
                    &record_len);
            if (!st.IsOk()) {
                PSVR_LOG(FATAL, log_id) << this
                    << " parse error, status:[" << st
                    << "] log_block:[" << log_block << "]";
                return false;
            }
            if (log_record->end_lsn > log_block->end_lsn) {
                PSVR_LOG(ERROR, log_id) << this
                    << " check rec failed, record end lsn is beyond block,"
                    << " rec_end_lsn:[" << log_record->end_lsn
                    << "] block_end_lsn:[" << log_block->end_lsn
                    << "] log_block:[" << log_block << "]";
                return false;
            }

            if (gaia_apply::is_mtr_page_modification_type(log_record->type)
                    || is_file_delete_record(log_record->type)) {

                LOG_IF(TRACE, log_record->type == gaia_apply::MLOG_INIT_FILE_PAGE2)
                    << this << " parsed a record,"
                    << " type:[" << log_record->type
                    << "] space:[" << log_record->space_id
                    << "] page:[" << log_record->page_no
                    << "] lsn:[" << log_record->start_lsn << ","
                    << log_record->end_lsn
                    << "]";

                log_block->PushRecord(log_record);
                if (!is_file_delete_record(log_record->type)) {
                    ++log_block->valid_records_count;
                    PagePtr page = _space_page_manager->GetOrCreatePage(
                            log_record->space_id,
                            log_record->page_no);
                    if (!page->AppendLogRecord(log_record)) {
                        PSVR_LOG(ERROR, log_id) << this << " append rec failed!"
                            << " rec_start_lsn:[" << log_record->start_lsn
                            << "] rec_end_lsn:[" << log_record->end_lsn
                            << "] record_len:[" << record_len
                            << "] head:[" << PTR_P(log_block->data())
                            << "] ptr:[" << PTR_P(start_ptr)
                            << "] end_ptr:[" << PTR_P(end_ptr)
                            << "] log_block:[" << log_block
                            << "]";
                        return false;
                    }
                    SetSpaceStatus(log_record->space_id, kSpaceStatusWork);
                    log_block->page_refs.emplace(page);
                } else {
                    SetSpaceStatus(log_record->space_id, kSpaceStatusDeleted);
                    SetSpaceSafeTrimLsn(log_record->space_id, log_record->end_lsn);
                    PSVR_LOG(NOTICE, log_id)
                        << this << " parse log block found a delete space:["
                        << log_record->space_id
                        << "] type from record, end_lsn:["
                        << log_record->end_lsn << "]";
                }
            } else {
                if (log_record->type == gaia_apply::MLOG_FILE_CREATE) {
                    _extent_meta_manager->CleanSpaceExtent(log_record->space_id);
                    SetSpaceStatus(log_record->space_id, kSpaceStatusWork);
                    SetSpaceSafeTrimLsn(log_record->space_id, 0);
                    PSVR_LOG(NOTICE, log_id) << this << " space init,"
                        << " space_id:[" << log_record->space_id
                        << "] lsn:[" << log_record->start_lsn << ","
                        << log_record->end_lsn
                        << "]";
                }
                PSVR_LOG(TRACE, log_id) << this << " get useless record,"
                    << " type:[" << log_record->type
                    << "] rec_end_lsn:[" << log_record->end_lsn
                    << "] lb_data_hex:[" << log_block->HexEncode()
                    << "]";
            }
            _parse_lsn(log_record->end_lsn, true);
            start_ptr += record_len;
            log_block->parse_ptr = start_ptr;
            //PSVR_LOG(TRACE, log_id) << this << " parse one record end_lsn:[" << rec_end_lsn << "]";
        }
        if (log_block->parse_ptr != end_ptr) {
            PSVR_LOG(ERROR, log_id) << this << " parse faile, data is not empty!"
                << " ptr:[" << PTR_P(log_block->parse_ptr)
                << "] end_ptr:[" << PTR_P(end_ptr)
                << "] log_block:[" << log_block
                << "]";
            return false;
        }
        set_statistic(stat_parse_logblock_real_lat, timer.u_elapsed());
    }

    AddParseLogBlock(log_block);
    return true;
}

bool Segment::GetSpaceReqLock(gaia_apply::space_id_t space_id) {
    return _inflight_space_reqs.GetReqLock(space_id);
}

void Segment::PutSpaceReqLock(gaia_apply::space_id_t space_id) {
    _inflight_space_reqs.PutReqLock(space_id);
}

bool Segment::GetSpaceExtentReqLock(gaia_apply::space_id_t space_id,
        uint32_t begin_extent_id) {
    return _inflight_space_extent_reqs.GetReqLock(u32tou64(space_id, begin_extent_id));
}

void Segment::PutSpaceExtentReqLock(gaia_apply::space_id_t space_id,
        uint32_t begin_extent_id) {
    _inflight_space_extent_reqs.PutReqLock(u32tou64(space_id, begin_extent_id));
}

uint64_t calc_physical_offset_by_extent_id(uint32_t physical_extent_id, uint32_t logical_page_no) {
    const uint32_t page_size = gaia_apply::FLAGS_univ_page_size;
    const uint32_t extent_page_count = GAIADB_EXTENT_SIZE / page_size;
    return (static_cast<uint64_t>(physical_extent_id) << GAIADB_EXTENT_SIZE_SHIFT)
        + (logical_page_no % extent_page_count) * page_size;
}

static gaiadb::common::extent_t logical_page_to_extent_id(uint32_t logical_page_no) {
    const uint32_t page_size = gaia_apply::FLAGS_univ_page_size;
    const uint32_t extent_page_count = GAIADB_EXTENT_SIZE / page_size;
    return logical_page_no / extent_page_count;
}

gaiadb::common::extent_t calc_begin_extent_id(uint32_t logical_page_no) {
    const uint32_t get_extent_size = FLAGS_psvr_get_extent_size;
    gaiadb::common::extent_t logical_extent_id = logical_page_to_extent_id(logical_page_no);
    return logical_extent_id & ~(get_extent_size - 1);
}

bool Segment::ExistSpacePagePhysicalOffset(gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no) {
    return _extent_meta_manager->Get(space_id, logical_page_to_extent_id(logical_page_no));
}

bool Segment::GetSpacePagePhysicalOffset(gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no,
        uint64_t* physical_offset, bool* data_invalid) {
    /* Calculates the logical extent id.
    Note that, we need to calculate the extent size in pages,
    because the size of extent is 1MB in GaiaDB, but it can be
    2MB, 4MB or 8MB in MySQL, so we can not use FSP_EXTENT_SIZE
    as the extent_page_cnt directly. */
    PSVR_ASSERT(gaia_apply::FLAGS_univ_page_size > 0);
    const uint32_t extent_page_count = GAIADB_EXTENT_SIZE / gaia_apply::FLAGS_univ_page_size;
    gaiadb::common::extent_t logical_extent_id = logical_page_no / extent_page_count;
    gaiadb::common::extent_t physical_extent_id = kInvalidExtentId;
    const uint64_t search_offset = *physical_offset;
    *physical_offset = kInvalidOffset;
    // lock here: avoid inserting data between two get steps
    std::shared_lock slk(_extent_meta_manager->shared_mutex());
    if (_extent_meta_manager->GetNoLock(space_id, logical_extent_id, &physical_extent_id)) {
        *physical_offset = (static_cast<uint64_t>(physical_extent_id) << GAIADB_EXTENT_SIZE_SHIFT)
            + (logical_page_no % extent_page_count) * gaia_apply::FLAGS_univ_page_size;
        LOG(TRACE) << this << " get extent,"
            << " space:[" << space_id
            << "] page:[" << logical_page_no
            << "] logical_extent_id:[" << logical_extent_id
            << "] physical_extent_id:[" << physical_extent_id
            << "] offset:[" << *physical_offset
            << "]";
        return true;
    } else {
        /* the searcher physical offset is not kInvalidOffset:
         * if physical offset cache data (space_id, page_no, segment_id) mismatch the searcher,
         * set data_invalid to true.
         * */
        if (search_offset != kInvalidOffset && data_invalid) {
            *data_invalid = false;
            physical_extent_id = search_offset / GAIADB_EXTENT_SIZE;
            gaia_apply::space_id_t tmp_space_id = space_id;
            gaia_apply::page_no_t tmp_logical_extent_id = logical_extent_id;
            bool match_segment = true;
            LOG(TRACE) << this << " get extent,"
                << " search_offset:[" << search_offset
                << "]";
            if (_extent_meta_manager->GetPhysicalExtentNoLock(physical_extent_id,
                        &tmp_space_id, &tmp_logical_extent_id, &match_segment)) {
                *data_invalid = (tmp_space_id != space_id)
                    || (logical_extent_id != tmp_logical_extent_id)
                    || (!match_segment);
                LOG(NOTICE) << this << " get useless extent,"
                    << " space:[" << space_id
                    << "] tmp_space:[" << tmp_space_id
                    << "] logical_extent_id:[" << logical_extent_id
                    << "] tmp_logical_extent_id:[" << tmp_logical_extent_id
                    << "] match_segment:[" << match_segment
                    << "] page:[" << logical_page_no
                    << "] search_offset:[" << search_offset
                    << "]";
            }
        }
        return false;
    }
}

void Segment::SetSpaceExtent(const event_space_extent_t& fold, ExtentArg extent_arg,
        bool not_exists, const gaiapb::GetSpaceExtentMapResponse& response) {
    SetSpaceExtent(fold.space_id, fold.begin_extent_id, extent_arg, not_exists, response);
}

void Segment::SetSpaceExtent(gaia_apply::space_id_t space_id, uint32_t begin_extent_id,
        ExtentArg extent_arg, bool not_exists, const gaiapb::GetSpaceExtentMapResponse& response) {
    std::shared_ptr<nullptr_t> guard(nullptr, [this, space_id, begin_extent_id](nullptr_t){
                PutSpaceExtentReqLock(space_id, begin_extent_id);
            });

    if (not_exists) {
        uint32_t status = kSpaceStatusDeleted | kSpaceStatusWithPSM;
        LogBlockPtr log_block(new LogBlock(EventOp::kGetSpaceMeta, space_id, status));
        _fetch_log_block_queue.PushFront(log_block);
        return;
    }

    struct ExtentMap {
        uint32_t segment_id;
        uint32_t physical_extent_id;
    };
    static_assert(sizeof(ExtentMap) == 8);
    std::vector<ExtentMap> extends;
    const uint32_t search_logic_extent_id = logical_page_to_extent_id(extent_arg.logical_page_no);
    const auto search_physical_extent_id = extent_arg.search_extent_id;
    extends.reserve(FLAGS_psvr_get_extent_size);
    if (response.has_extent_map_bytes()) {
        const auto& extent_str = response.extent_map_bytes();
        //extent_str layout:
        // |entry1_segment_id|entry1_extent_id|entry2_segment_id|entry2_extent_id|...
        // |<-   4B          | 4B             | 4B              | 4B           ->|...
        const ExtentMap* entry = reinterpret_cast<const ExtentMap*>(extent_str.c_str());
        const uint32_t count = extent_str.length() / sizeof(*entry);
        for (uint32_t i = 0; i < count; ++i) {
            extends.emplace_back(*(entry + i));
        }
    } else {
        const auto& extent_map = response.extent_map();
        for (int32_t i = 0; i < extent_map.entries_size(); ++i) {
            const auto& entry = extent_map.entries(i);
            extends.emplace_back(ExtentMap{entry.segment_id(), entry.physical_extent_id()});
        }
    }

    std::unique_lock lk(_extent_meta_manager->shared_mutex());
    uint32_t extends_size = static_cast<uint32_t>(extends.size());
    for (uint32_t i = 0; i < extends_size; ++i) {
        const auto& entry = extends[i];
        const auto logic_extent_id = begin_extent_id + i;
        if (_segment_id == entry.segment_id) {
            _extent_meta_manager->SetNoLock(space_id, logic_extent_id, entry.physical_extent_id);
        }
    }

    if (search_physical_extent_id == kInvalidExtentId
            || search_logic_extent_id == kInvalidExtentId) {
        return;
    }

    if (_extent_meta_manager->ExistPhysicalExtentNoLock(search_physical_extent_id)) {
        return;
    }

    /* if not found physical extent id in cache, check if it is invalid data.
     *
     * check logical extent id:
     *  1) < begin_extent_id, impossibility
     *  2) in [begin_extent_id, begin_extent_id + extends_size), the segment id do not match.
     *  3) >= begin_extent_id + extends_size, the space is reuse or in backup.
     */
    if (begin_extent_id <= search_logic_extent_id
            && search_logic_extent_id < begin_extent_id + extends_size) {
        bool set_rc = _extent_meta_manager->SetPhysicalExtentNoLock(
                search_physical_extent_id, space_id, search_logic_extent_id);
        LOG(WARNING) << this << " extent size mismatch segment,"
            << " rc:[" << set_rc
            << "] space:[" << space_id
            << "] begin_extent_id:[" << begin_extent_id
            << "] num:[" << FLAGS_psvr_get_extent_size
            << "] rsp_num:[" << extends_size
            << "] logical_page_no:[" << extent_arg.logical_page_no
            << "] search_extent_id:[" << extent_arg.search_extent_id
            << "] total_extent:[" << response.total_extent_num()
            << "]";
    } else if (response.total_extent_num() > 0
            && begin_extent_id + extends_size >= response.total_extent_num()
            && search_logic_extent_id >= begin_extent_id + extends_size) {
        bool set_rc = false;
        if (FLAGS_psvr_enable_unknown_extent_to_garbage) {
            set_rc = _extent_meta_manager->SetPhysicalExtentNoLock(
                    search_physical_extent_id, space_id, kInvalidExtentId);
        }
        LOG(WARNING) << this << " extent size invalid,"
            << " rc:[" << set_rc
            << "] space:[" << space_id
            << "] begin_extent_id:[" << begin_extent_id
            << "] num:[" << FLAGS_psvr_get_extent_size
            << "] rsp_num:[" << response.actual_get_num()
            << "] search_extent_id:[" << extent_arg.search_extent_id
            << "] logical_page_no:[" << extent_arg.logical_page_no
            << "] total_extent:[" << response.total_extent_num()
            << "]";
    } // else: impossibility
}

bool Segment::GetPeerNodes(std::vector<gaiadb::common::PeerZone>* replicas, bool need_random) {
    std::shared_lock lm(_peer_info.shared_mutex);
    ControlPtr control = _control.lock();
    if (!control || _peer_info.replicas.empty()) {
        return false;
    }

    *replicas = _peer_info.replicas;
    bool need_refresh = false;
    if (!need_refresh && _peer_info.has_zone && _peer_info.zone_count > 0
            && _peer_info.replicas_status.Test(0, _peer_info.zone_count)) {
        // my az zone are failed
        need_refresh = true;
    }
    if (!need_refresh && _peer_info.replicas_status.MajorityTest()) {
        // major replicas failed
        need_refresh = true;
    }
    if (!need_refresh && _peer_info.last_zone_version != control->dbd_zone()->version()) {
        // zone meta changed
        need_refresh = true;
    }

    if (need_random) {
        if (_peer_info.has_zone && _peer_info.zone_count > 0) {
            std::random_shuffle(replicas->begin(), replicas->begin() + _peer_info.zone_count);
            std::random_shuffle(replicas->begin() + _peer_info.zone_count, replicas->end());
        } else {
            std::random_shuffle(replicas->begin(), replicas->end());
        }
    }

    return !need_refresh;
}

void Segment::UpdatePeerNodes(gaiadb::common::segment_t segment_id,
        bool not_exists, const gaiapb::GetSegmentResponse& response) {
    PSVR_ASSERT(_segment_id == segment_id);
    ControlPtr control = _control.lock();
    if (!control) {
        return;
    }

    std::shared_ptr<nullptr_t> guard(nullptr, [this](nullptr_t){
            _peer_info.lock.unlock();
        });

    if (not_exists) {
        return;
    }

    std::vector<gaiadb::common::PeerZone> peers;
    const bool has_zone = control->dbd_zone()->has_zone();
    const uint32_t zone_version = control->dbd_zone()->version();
    uint32_t zone_count = 0;
    std::string region;
    std::string available_zone;
    if (has_zone) {
        control->dbd_zone()->Get(&region, &available_zone);
    }

    bool match_rebalance_from = false;
    for (int32_t i = 0; i < response.page_servers_size(); ++i) {
        const auto& page_server = response.page_servers(i);
        base::EndPoint ep;
        base::str2endpoint(page_server.addr().c_str(), &ep);
        if (ep == control->myself()) {
            continue;
        }
        if (!match_rebalance_from
                && !_rebalance_from.empty()
                && _rebalance_from == page_server.addr()
                && _rebalance_version == page_server.version()) {
            match_rebalance_from = true;
        }
        peers.emplace_back(ep, page_server.zone().region(), page_server.zone().available_zone());
        if (has_zone && region == page_server.zone().region()
                && available_zone == page_server.zone().available_zone()) {
            ++zone_count;
        }
    }

    std::random_shuffle(peers.begin(), peers.end(), base::fast_rand_less_than);
    if (zone_count && !region.empty() && !available_zone.empty()) {
        gaiadb::common::sort_peer_zone_vector(peers, region, available_zone);
    }

    LOG_IF(WARNING, peers.empty()) << this << " get replicas failed, response is empty";
    if (!peers.empty()) {
        std::unique_lock lm(_peer_info.shared_mutex);
        _peer_info.has_zone = has_zone;
        _peer_info.last_zone_version = zone_version;
        _peer_info.zone_count = zone_count;
        _peer_info.replicas = std::move(peers);
        _peer_info.replicas_status.Reset(_peer_info.replicas.size());
        LOG_EVERY_SECOND(NOTICE) << this << " refresh replicas ok, " << _peer_info;
        if (!match_rebalance_from) {
            ClearRebalanceNode();
        }
    }
}

void Segment::MovePeerNodeToFirst(uint32_t idx, const base::EndPoint& node) {
    std::unique_lock lm(_peer_info.shared_mutex);
    uint32_t pos = idx;
    if (pos >= _peer_info.replicas.size() || _peer_info.replicas[pos].addr != node) {
        // idx refers to a shuffled copy returned by GetPeerNodes, which may not
        // align with _peer_info.replicas, so locate the node by addr instead.
        pos = 0;
        while (pos < _peer_info.replicas.size() && _peer_info.replicas[pos].addr != node) {
            ++pos;
        }
        if (pos >= _peer_info.replicas.size()) {
            return;
        }
    }

    if (pos == 0) {
        return;
    }

    std::swap(_peer_info.replicas[0], _peer_info.replicas[pos]);
    const bool failed_0 = _peer_info.replicas_status.Test(0);
    const bool failed_pos = _peer_info.replicas_status.Test(pos);
    if (failed_pos) {
        _peer_info.replicas_status.SetIdx(0);
    } else {
        _peer_info.replicas_status.ClearIdx(0);
    }
    if (failed_0) {
        _peer_info.replicas_status.SetIdx(pos);
    } else {
        _peer_info.replicas_status.ClearIdx(pos);
    }
}

void Segment::MovePeerNodeToFirst(uint32_t idx, const gaiadb::common::PeerZone& peer) {
    return MovePeerNodeToFirst(idx, peer.addr);
}

void Segment::SetPeerNodeFailed(uint32_t idx, const base::EndPoint& node) {
    std::unique_lock lm(_peer_info.shared_mutex);
    uint32_t pos = idx;
    if (pos >= _peer_info.replicas.size() || _peer_info.replicas[pos].addr != node) {
        // idx refers to a shuffled copy returned by GetPeerNodes, which may not
        // align with _peer_info.replicas, so locate the node by addr instead.
        pos = 0;
        while (pos < _peer_info.replicas.size() && _peer_info.replicas[pos].addr != node) {
            ++pos;
        }
        if (pos >= _peer_info.replicas.size()) {
            return;
        }
    }

    _peer_info.replicas_status.SetIdx(pos);
    if (pos == 0 && !_peer_info.replicas_status.IsFull()) {
        for (uint32_t i = 1; i < _peer_info.replicas.size(); ++i) {
            if (!_peer_info.replicas_status.Test(i)) {
                std::swap(_peer_info.replicas[0], _peer_info.replicas[i]);
                _peer_info.replicas_status.ClearIdx(0);
                _peer_info.replicas_status.SetIdx(i);
                break;
            }
        }
    }
}

void Segment::SetPeerNodeFailed(uint32_t idx, const gaiadb::common::PeerZone& peer) {
    return SetPeerNodeFailed(idx, peer.addr);
}

bool Segment::EnableCheckAgain(int64_t interval_us) {
    std::shared_lock slk(_recovery_info.shared_mutex);
    return _recovery_info.last_recover_time + interval_us < base::cpuwide_time_us();
}

void Segment::UpdatePeerLastRecoverTime() {
    _peer_last_recover_time_s.set(base::cpuwide_time_s(), true);
}

bool Segment::TurnOnRecovery(bool is_force) {
    if (_recovery_info.lock.try_lock()) {
        std::unique_lock lm(_recovery_info.shared_mutex);
        _recovery_info.stopped = false;
        _recovery_info.is_force = is_force;
        _recovery_info.offset = 0;
        _recovery_info.finish_size = 0;
        _recovery_info.inflight_count = 0;
        _recovery_info.tablets_idx = 0;
        _recovery_info.tablets.clear();
        _recovery_info.min_apply_lsn(0);
        uint64_t start = 0, end = 0;
        size_t idx = 0;
        constexpr uint64_t tablet_size = (4lu<<30);
        while (start < _segment_size) {
            end = start + tablet_size;
            if (end <= _segment_size) {
                _recovery_info.AddTablet(idx, start, end);
                start = end;
            } else {
                _recovery_info.AddTablet(idx, start, _segment_size);
                start = _segment_size;
            }
            ++idx;
        }
        LOG(NOTICE) << this << " turn on recovery,"
            << " segment_size:[" << _segment_size
            << "] tablet_size:[" << tablet_size
            << "] tablets_count:[" << _recovery_info.tablets.size()
            << "]";
        return true;
    }
    return false;
}

void Segment::TurnOffRecovery() {
    std::unique_lock lm(_recovery_info.shared_mutex);
    if (!_recovery_info.stopped) {
        _recovery_info.stopped = true;
        LOG(NOTICE) << this << " turn off recovery";
    }
}

uint64_t Segment::GetRecoveryMaxSize() const {
    std::shared_lock slm(_recovery_info.shared_mutex);
    return !_recovery_info.stopped ? _recovery_info.offset : 0;
}

void Segment::GetRecoveryStatus(bool* status, bool* is_force) const {
    std::shared_lock slm(_recovery_info.shared_mutex);
    *status = _recovery_info.stopped ? false : true;
    *is_force = _recovery_info.is_force;
}

bool Segment::StartRecovery() {
    // alloc pages_min_lsn buf on real start recovery
    std::unique_lock lm(_recovery_info.shared_mutex);
    if (!_recovery_info.pages_min_lsn) {
        PSVR_ASSERT(_segment_size % gaia_apply::FLAGS_univ_page_size == 0);
        auto page_count = _segment_size / gaia_apply::FLAGS_univ_page_size;
        _recovery_info.pages_min_lsn = new RecoveryInfo::PageMinLsn[page_count]();
        if (!_recovery_info.pages_min_lsn) {
            LOG(WARNING) << this << " alloc recovery buf failed,"
                << " size:[" << (sizeof(RecoveryInfo::PageMinLsn) * page_count)
                << "]";
            return false;
        }
    }
    _recovery_info.drop_spaces.clear();
    _gc_delay_flag.store(0);
    _recovery_info.append_file_cleanup_frozen.store(true, std::memory_order_relaxed);
    expose_statistic(stat_recover_bw, "recover_bw");
    return true;
}

void Segment::FinishRecovery() {
    std::unique_lock lm(_recovery_info.shared_mutex);
    _recovery_info.append_file_cleanup_frozen.store(false, std::memory_order_relaxed);
    if (_recovery_info.pages_min_lsn) {
        delete[] _recovery_info.pages_min_lsn;
        _recovery_info.pages_min_lsn = nullptr;
    }
    _recovery_info.drop_spaces.clear();
    _gc_delay_flag.store(0);
    hide_statistic(stat_recover_bw);
    _recovery_info.lock.unlock();
    LOG(NOTICE) << this << " finish recvoery";
}

bool Segment::RecoveryStoped() {
    std::shared_lock slm(_recovery_info.shared_mutex);
    return _recovery_info.stopped;
}

bool Segment::GetRecoveryNextBlockTask(RecoverBlockTask* task) {
    std::unique_lock lm(_recovery_info.shared_mutex);
    if (_recovery_info.offset >= _segment_size) {
        return false;
    }
    task->size = gaia_apply::FLAGS_univ_page_size;
    auto size = _recovery_info.tablets.size();
    auto cur_idx = _recovery_info.tablets_idx;
    for (size_t i = 0; i < size; ++i) {
        auto idx = cur_idx + i;
        auto& tablet = _recovery_info.tablets[idx % size];
        if (tablet.offset < tablet.end) {
            task->idx = idx;
            task->offset = tablet.offset;
            tablet.offset += task->size;
            _recovery_info.tablets_idx = idx;
            _recovery_info.offset += task->size;
            ++_recovery_info.inflight_count;
            return true;
        }
    }
    PSVR_ASSERT(false);
    return false;
}

void Segment::FinishRecoveryBlockTask(const RecoverBlockTask& task) {
    uint64_t finish_size = 0;
    {
        std::unique_lock lm(_recovery_info.shared_mutex);
        PSVR_ASSERT(_recovery_info.inflight_count > 0);
        --_recovery_info.inflight_count;
        _recovery_info.finish_size += task.size;
        set_statistic(stat_recover_bw, task.size);
        PSVR_ASSERT(_recovery_info.finish_size <= _segment_size);
        if (_recovery_info.finish_size == _segment_size) {
            PSVR_ASSERT(_recovery_info.inflight_count == 0);
            ++_recovery_info.data_check_round_count;
            if (_recovery_status.load() != gaiadb::RECOVERY_FINISH) {
                _recovery_status.store(gaiadb::RECOVERY_FINISH);
            }
            _recovery_info.last_recover_time = base::cpuwide_time_us();
        }
        finish_size = _recovery_info.finish_size;
    }

    if (finish_size == _segment_size) {
        if (FLAGS_psvr_sync_on_recovery_or_compression) {
            Sync();
        }

        std::unique_lock lk(_shared_mutex);
        std::error_code ec;
        std::string disable_path = base::string_printf("%s/disable", _db_path.c_str());
        if (std::filesystem::exists(disable_path, ec)) {
            std::filesystem::remove_all(disable_path, ec);
            if (!ec) {
                db::Status status = db::sync_directoryx(_db_path.c_str());
                if (!status.IsOk()) {
                    LOG(ERROR) << this << " fail to sync directory after removing disable path,"
                        << " dir:[" << _db_path << "], " << status;
                }
            }
        }
    } else {
        uint64_t sync_size = ut_uintx_align_up(
                FLAGS_psvr_sync_size_on_recovery_or_compression, gaia_physical_page_size());
        if (FLAGS_psvr_sync_on_recovery_or_compression
                && sync_size > 0
                && finish_size % sync_size == 0) {
            Sync();
        }
    }
}

/**
 * If the segment recovery status is true, but recovery is not started,
 *  the min_lsn set to min_apply_lsn.
 *  when recovery is started, min_lsn set to pages_min_lsn[x].
 *  --
 *  min_lsn: If page is recovered, the page lsn must not be less than it.
 *  --
 *  return false, need retry Gc, prohibit discarding page records.
 * */
bool Segment::AddGcPageInRecovery(db::PageLockPtr page_lock,
        gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no,
        gaia_apply::lsn_t min_lsn, bool* retry) {
    std::unique_lock lm(_recovery_info.shared_mutex);
    if (_recovery_info.stopped
            || _recovery_status.load() != gaiadb::RECOVERY_IN) {
        *retry = false;
        return false;
    }

    PSVR_ASSERT(min_lsn > LOG_START_LSN);
    const uint64_t gc_offset = page_lock->offset();
    if (!_recovery_info.pages_min_lsn) {
        // segment recovery not started
        _recovery_info.min_apply_lsn(min_lsn, true);
        return true;
    }

    _recovery_info.drop_spaces.erase(space_id);
    const uint64_t idx = gc_offset / gaia_apply::FLAGS_univ_page_size;
    if (_recovery_info.pages_min_lsn[idx].min_lsn == LOG_START_LSN) {
        // page recovery completed, retry gc
        *retry = true;
        return false;
    } else {
        _recovery_info.pages_min_lsn[idx].space_id = space_id;
        _recovery_info.pages_min_lsn[idx].page_no = page_no;
        _recovery_info.pages_min_lsn[idx].min_lsn = min_lsn;
        return true;
    }
}

/**
 * In recovery, somes pages discard records by AddGcPageInRecovery and after drop space.
 * recoverer this pages may get empty data, so the lsn check failed.
 * Add drop spaces in recovery for checking.
 */
void Segment::AddGcDropSpaceInRecovery(gaia_apply::space_id_t space_id,
        gaia_apply::lsn_t lsn) {
    std::unique_lock lm(_recovery_info.shared_mutex);
    if (_recovery_info.stopped
            || _recovery_status.load() != gaiadb::RECOVERY_IN) {
        return;
    }
    auto it = _recovery_info.drop_spaces.emplace(space_id, lsn);
    if (!it.second) {
        it.first->second = lsn;
    }
}

/**
 * Return true: this means that the page has lost records when recovery started.
 *  we need sure the page_lsn not less than pages_min_lsn[x].
 * Return false: maybe the page has lost records whtn recovery not started
 *  or never modified. just make sure page_lsn or peer_gc_lsn(page empty) is not less than min_apply_lsn.
 * */
bool Segment::CheckGcPageInRecovery(db::PageLockPtr page_lock,
        gaia_apply::lsn_t* page_min_lsn, gaia_apply::lsn_t* min_lsn) {
    std::shared_lock slm(_recovery_info.shared_mutex);
    const uint64_t gc_offset = page_lock->offset();
    const uint64_t idx = gc_offset / gaia_apply::FLAGS_univ_page_size;
    *min_lsn = _recovery_info.min_apply_lsn();
    *page_min_lsn = _recovery_info.pages_min_lsn[idx].min_lsn;
    if (*page_min_lsn > LOG_START_LSN) {
        auto space_id = _recovery_info.pages_min_lsn[idx].space_id;
        if (_recovery_info.drop_spaces.count(space_id) > 0) {
            *page_min_lsn = 0;
        }
    }
    return *page_min_lsn > LOG_START_LSN;
}

bool Segment::DropGcPageInRecovery(db::PageLockPtr page_lock,
        gaia_apply::lsn_t lsn) {
    std::unique_lock lm(_recovery_info.shared_mutex);
    const uint64_t gc_offset = page_lock->offset();
    const uint64_t idx = gc_offset / gaia_apply::FLAGS_univ_page_size;
    auto& page = _recovery_info.pages_min_lsn[idx];
    if (lsn >= page.min_lsn) {
        page.min_lsn = LOG_START_LSN;
        return true;
    }
    if (_recovery_info.drop_spaces.count(page.space_id) > 0) {
        return true;
    }
    LOG(WARNING) << this << " page recover lsn check failed,"
        << " space_id:[" << page.space_id
        << "] page_no:[" << page.page_no
        << "] offset:[" << gc_offset
        << "] min_lsn:[" << page.min_lsn
        << "] page_lsn:[" << lsn
        << "]";
    return false;
}

bool Segment::CheckRecovery() {
    std::shared_lock slm(_recovery_info.shared_mutex);
    auto page_count = _segment_size / gaia_apply::FLAGS_univ_page_size;
    auto buf = static_cast<gaia_apply::byte*>(std::aligned_alloc(gaia_apply::FLAGS_univ_page_size,
                gaia_apply::FLAGS_univ_page_size));
    if (!buf) {
        return false;
    }
    std::shared_ptr<nullptr_t> buf_guard(nullptr, [&buf](nullptr_t) { std::free(buf); });
    uint32_t nr = 0;
    for (uint64_t i = 0; i < page_count; ++i) {
        auto page = _recovery_info.pages_min_lsn[i];
        if (page.min_lsn > LOG_START_LSN) {
            uint64_t physical_offset = i * gaia_apply::FLAGS_univ_page_size;
            db::PageLockPtr page_lock = GetPageLock(i);
            db::PageSharedLock lm_page(page_lock);
            db::Status st = ReadPhysicalPageData(i, physical_offset, gaia_apply::FLAGS_univ_page_size, buf);
            if (!st.IsOk()) {
                return false;
            }
            const auto local_page_lsn = page_get_page_lsn(buf);
            if (local_page_lsn < page.min_lsn) {
                bool check_failed = true;
                bool is_drop = _recovery_info.drop_spaces.count(page.space_id) > 0;
                if (is_drop && _gc_lsn() >= _recovery_info.drop_spaces[page.space_id]) {
                    check_failed = false;
                }
                LOG(WARNING) << this << " check recovery page failed,"
                    << " physical_offset:[" << physical_offset
                    << "] local_page_lsn:[" << local_page_lsn
                    << "] min_lsn:[" << page.min_lsn
                    << "] space_id:[" << page.space_id
                    << "] page_no:[" << page.page_no
                    << "] id_drop:[" << is_drop
                    << "]";
                if (check_failed) {
                    return false;
                }
            }
            ++nr;
        }
    }
    LOG(NOTICE) << this << " check recovery pages ok, nr:[" << nr << "]";
    return true;
}

void Segment::GetRecoveryInfo(pspb::GetRecoverInfoResponse* rsp) const {
    std::shared_lock slm(_recovery_info.shared_mutex);
    rsp->set_recover_enable(!_recovery_info.stopped);
    rsp->set_total_size(_segment_size);
    rsp->set_recover_size(_recovery_info.finish_size);
    rsp->set_recover_times(_recovery_info.data_check_round_count);
    rsp->set_recover_force(_recovery_info.is_force);
    rsp->set_recover_finish_rate((_recovery_info.finish_size * 1.0 / _segment_size) * 100);
    rsp->set_cluster_id(_cluster_id);
    rsp->set_segment_id(_segment_id);
}

void Segment::GetRecoveryInfo(pspb::MultiGetRecoverInfoResponse::Segment* seg) const {
    std::shared_lock slm(_recovery_info.shared_mutex);
    seg->set_cluster_id(_cluster_id);
    seg->set_segment_id(_segment_id);
    seg->set_recover_enable(!_recovery_info.stopped);
    seg->set_total_size(_segment_size);
    seg->set_recover_size(_recovery_info.finish_size);
    seg->set_recover_times(_recovery_info.data_check_round_count);
    seg->set_recover_force(_recovery_info.is_force);
    seg->set_recover_finish_rate((_recovery_info.finish_size * 1.0 / _segment_size) * 100);
}

void Segment::GetRecoveryInfo(pspb::ListRecoveryInfoResponse::Segment* seg) const {
    std::shared_lock slm(_recovery_info.shared_mutex);
    seg->set_cluster_id(_cluster_id);
    seg->set_segment_id(_segment_id);
    seg->set_segment_size(_segment_size);
    seg->set_store_id(_store_id);
    seg->set_recovery_size(_recovery_info.finish_size);
    seg->set_paiallel_task_count(_recovery_info.inflight_count);
    seg->set_finish_rate((_recovery_info.finish_size * 1.0 / _segment_size) * 100);
}

}
