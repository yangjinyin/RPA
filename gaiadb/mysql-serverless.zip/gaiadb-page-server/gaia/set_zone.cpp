/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_zone.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/set_zone.h"

namespace psvr {
namespace gaia {

int SetZone::Run() {
    RpcStatus status;

    if (_address.empty() || _port < 1) {
        print_error("miss --address and --port");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    if (_type.empty()) {
        print_error("miss --type");
        return 1;
    }

    if (_zone.Invalid() || _zone.region.empty()) {
        print_error("error, --region and --available-zone should always appear in pairs");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Set node %s:%p zone?", _address.c_str(), _port);
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    if (_type == "ls") {
        lspb::lsrv_set_zone_request request;
        lspb::lsrv_set_zone_response response;

        request.mutable_zone()->set_region(_zone.region);
        request.mutable_zone()->set_available_zone(_zone.available_zone);
        if (!_cluster_id.empty()) {
            request.set_cluster_id(_cluster_id);
        }

        _client.Call(_log_id, node, &lspb::LogServiceService_Stub::set_zone, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        }
        response.mutable_status()->set_code(lspb::GIE_FAIL);
        response.mutable_status()->set_msg("set failed");
        return Output(response);
    } else if (_type == "cmp") {
        computenode::set_zone_request request;
        computenode::set_zone_response response;

        request.mutable_zone()->set_region(_zone.region);
        request.mutable_zone()->set_available_zone(_zone.available_zone);
        if (!_cluster_id.empty()) {
            request.set_cluster_id(_cluster_id);
        }

        _client.Call(_log_id, node, &computenode::StatusQueryService_Stub::set_zone, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        }
        response.mutable_status()->set_code(1);
        response.mutable_status()->set_msg("set failed");
        return Output(response);
    } else if (_type == "rpl") {
        replicate::pb::SetZoneRequest request;
        replicate::pb::SetZoneResponse response;

        request.set_log_id(_log_id);
        request.mutable_zone()->set_region(_zone.region);
        request.mutable_zone()->set_available_zone(_zone.available_zone);

        _client.Call(_log_id, node, &replicate::pb::ReplicationService_Stub::SetZone, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        }
        response.mutable_status()->set_code(replicate::pb::RPC_ERROR);
        response.mutable_status()->set_msg("set failed");
        return Output(response);
    } else if (_type == "ps") {
        pspb::SetZoneRequest request;
        pspb::SetZoneResponse response;

        request.set_log_id(_log_id);
        request.mutable_zone()->set_region(_zone.region);
        request.mutable_zone()->set_available_zone(_zone.available_zone);

        _client.Call(_log_id, node, &pspb::ManagerService_Stub::SetZone, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        }
        response.mutable_status()->set_code(pspb::Status::RPC_ERROR);
        response.mutable_status()->set_msg("set failed");
        return Output(response);
    } else {
        print_error("invalid --type)");
        return 1;
    }
}

int SetZone::Format(const lspb::lsrv_set_zone_response& rsp) {
    SHOW_LS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

int SetZone::Format(const computenode::set_zone_response& rsp) {
    SHOW_CMP_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

int SetZone::Format(const replicate::pb::SetZoneResponse& rsp) {
    SHOW_RPL_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

int SetZone::Format(const pspb::SetZoneResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
