/*****************************************************************************
  @file include/bos0read.cc
 * read data from bos
 *******************************************************/

#include "bos0bos.h"
#include "base/logging.h"
#include "sql/binlog.h"

namespace bos {
// Following MySQL conventions, false represents success

bool BosReader::get_object_with_stream(const std::string &filename) {
  bir_bos::FileOutputStream outStream(filename);
  if (get_client()->download_file(bos_info().bucket, filename, outStream)) {
    return true;
  }
  return false;
}

bool BosReader::get_object_to_file(
  const std::string &filename, const int64_t start_lsn, const int64_t end_lsn) {
  bir_bos::ObjectMetaData objectMetaData;
  if (get_client()->download_file(
        bos_info().bucket, filename, filename, 
        start_lsn, end_lsn, &objectMetaData)) {
    return true;
  }
  return false;
}

bool BosReader::get_object_with_progress(const std::string &filename) {
  bir_bos::FileOutputStream outStream(add_bak_suffix(filename)); 

  const std::string object_key = add_cluster_id(filename);
  bir_bos::GetObjectRequest req(bos_info().bucket, object_key);
  bir_bos::GetObjectResponse rsp(&outStream);

  bir_bos::TransferProgress progress;
  progress.transfer_progress_cb = progress_callback;
  rsp.set_progress(progress);

  int ret = get_client()->get_object(req, &rsp);
  if (ret) {
    LOG(WARNING) << "bos get object init client err: " << ret;
    return true;
  }
  if (rsp.is_fail()) {
    LOG(WARNING) << "bos get_object response failed"
      << "[status_code = " << rsp.status_code()
      << "], [message = " << rsp.error().message().c_str()
      << "], [requestid = " << rsp.error().request_id().c_str()
      << "]";
    return true;
  }
  return false;
}

bool BosReader::get_object_in_memory(
    const std::string& filename, std::string &inMemoryData) {
  if (get_client()->get_object(bos_info().bucket, filename, &inMemoryData)) {
    LOG(WARNING) << "bos get_object_in_memory failed, filename: " << filename;
    return true;
  }
  return false;
}

bool BosReader::get_object_in_range(
    const std::string &filename, const uint32_t start_lsn, 
    const uint32_t end_lsn) {
  bir_bos::GetObjectRequest getObjectRequest(bos_info().bucket, filename);
  bir_bos::FileOutputStream outStream(filename);
  bir_bos::GetObjectResponse getObjectResponse(&outStream);
  getObjectRequest.set_range(start_lsn, end_lsn);
  if (get_client()->get_object(getObjectRequest, &getObjectResponse)) {
    LOG(WARNING) << "get_object_in_range failed, filename: " << filename;
    return true;
  }
  return false;
}

bool BosReader::get_object(const std::string &filename) {
  const int retry_count = 3;
  bool ret = true;
  for (int i = 0; i < retry_count; i++) {
    ret = get_object_with_progress(filename);
    if (!ret) {
      break;
    }
  }
  return ret;
}

} // end bos
