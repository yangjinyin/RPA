/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/cluster.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <variant>
#include <gaiadb/utils/aarch64.h>
#include <base/macros.h>
#include <base/containers/doubly_buffered_data.h>
#include "psvr/segment.h"
#include "psvr/psminfo.h"
#include "psvr/encrypt_utils.h"

namespace psvr {

class RpcQuota;
using RpcQuotaPtr = std::shared_ptr<RpcQuota>;

#define set_cluster_stat(cluster, k, v) \
do {    \
    auto stat = cluster->statistic();   \
    if (stat->is_enable()) {  \
        stat->k << (v);  \
    }   \
} while (0)

#define set_cluster_ls_stat(cluster, idx, k, v) \
do {    \
    auto stat = cluster->statistic();   \
    if (stat->is_enable()) {  \
        (stat->stat_log_services[(idx) % stat->stat_log_services_size]->k) << (v);  \
    }   \
} while (0)

struct ClusterStatistic {
private:
    enum {
        kEnable = 0,
        kDisable,
    };
    std::atomic<int> _status;

    struct StatLogService {
        int32_t idx;
        StatCount stat_fetch_switch_count;
        StatLatency stat_fetch_rpc_lat;

        StatLogService(int32_t _idx) : idx(_idx),
            stat_fetch_switch_count(kSlaWindowSize),
            stat_fetch_rpc_lat(kSlaWindowSize) {}

        void expose_as(const std::string& prefix) {
            stat_fetch_switch_count.expose_as(prefix, base::string_printf("cluster_ls%d_fetch_switch_count", idx));
            stat_fetch_rpc_lat.expose_as(prefix, base::string_printf("cluster_ls%d_fetch_rpc", idx));
        }

        void hide() {
            stat_fetch_switch_count.hide();
            stat_fetch_rpc_lat.hide();
        }
    };

public:
    StatLatency stat_psm_req_lat;
    StatCount stat_psm_req_err_count;
    StatCount stat_get_log_service_count;
    StatCount stat_psm_req_merge_count;
    bvar::Adder<int64_t> stat_log_block_size;
    StatBw stat_log_block_buf_bw;
    StatBw stat_log_block_page_bw;
    std::vector<std::shared_ptr<StatLogService>> stat_log_services;
    size_t stat_log_services_size;

    StatLatency stat_rbio_init_lat_primary;
    StatLatency stat_rbio_lat_primary;
    StatCount stat_rbio_error_count_primary;
    StatLatency stat_rbio_req_wait_lsn_lat_primary;
    StatAvg stat_rbio_req_retry_times_avg_primary;
    StatSize stat_rbio_req_lsn_behind_size_primary;
    StatLatency stat_rbio_req_prepare_lat_primary;
    StatLatency stat_rbio_req_apply_lat_primary;
    StatLatency stat_rbio_init_lat_secondary;
    StatLatency stat_rbio_lat_secondary;
    StatCount stat_rbio_error_count_secondary;
    StatLatency stat_rbio_req_wait_lsn_lat_secondary;
    StatAvg stat_rbio_req_retry_times_avg_secondary;
    StatSize stat_rbio_req_lsn_behind_size_secondary;
    StatLatency stat_rbio_req_prepare_lat_secondary;
    StatLatency stat_rbio_req_apply_lat_secondary;

    // for sort
    StatCountT<uint64_t> stat_redo_size_count;
    StatCountT<uint64_t> stat_rbio_size_count;
    StatCountT<uint64_t> stat_write_size_count;

    ClusterStatistic(const std::string& prefix)
        : _status(kDisable),
        stat_psm_req_lat(kSlaWindowSize),
        stat_psm_req_err_count(kSlaWindowSize),
        stat_get_log_service_count(kSlaWindowSize),
        stat_psm_req_merge_count(kSlaWindowSize),
        stat_log_block_buf_bw(kSlaWindowSize),
        stat_log_block_page_bw(kSlaWindowSize),
        stat_rbio_init_lat_primary(kSlaWindowSize),
        stat_rbio_lat_primary(kSlaWindowSize),
        stat_rbio_error_count_primary(kSlaWindowSize),
        stat_rbio_req_wait_lsn_lat_primary(kSlaWindowSize),
        stat_rbio_req_retry_times_avg_primary(kSlaWindowSize),
        stat_rbio_req_lsn_behind_size_primary(kSlaWindowSize),
        stat_rbio_req_prepare_lat_primary(kSlaWindowSize),
        stat_rbio_req_apply_lat_primary(kSlaWindowSize),
        stat_rbio_init_lat_secondary(kSlaWindowSize),
        stat_rbio_lat_secondary(kSlaWindowSize),
        stat_rbio_error_count_secondary(kSlaWindowSize),
        stat_rbio_req_wait_lsn_lat_secondary(kSlaWindowSize),
        stat_rbio_req_retry_times_avg_secondary(kSlaWindowSize),
        stat_rbio_req_lsn_behind_size_secondary(kSlaWindowSize),
        stat_rbio_req_prepare_lat_secondary(kSlaWindowSize),
        stat_rbio_req_apply_lat_secondary(kSlaWindowSize),
        stat_redo_size_count(60),
        stat_rbio_size_count(60),
        stat_write_size_count(60) {
        stat_log_services_size = std::max(FLAGS_psvr_single_az_raft_replica_size,
                FLAGS_psvr_with_backup_az_raft_replica_size);
        for (uint64_t i = 0; i < stat_log_services_size; ++i) {
            stat_log_services.emplace_back(new StatLogService(i));
        }
        if (FLAGS_psvr_auto_enable_cluster_statistic) {
            Enable(prefix);
        }
    }

    ~ClusterStatistic() {
        Disable();
    }

    bool is_enable() const { return _status.load(std::memory_order_relaxed) == kEnable; }

    bool Enable(const std::string& prefix) {
        if (_status.exchange(kEnable) == kDisable) {
#ifndef GTEST
            stat_psm_req_lat.expose_as(prefix, "cluster_status_psm");
            stat_psm_req_err_count.expose_as(prefix, "cluster_status_psm_error_count");
            stat_get_log_service_count.expose_as(prefix, "cluster_get_log_service_count");
            stat_psm_req_merge_count.expose_as(prefix, "cluster_status_psm_merge_count");
            stat_log_block_size.expose_as(prefix, "cluster_log_block_size");
            stat_log_block_buf_bw.expose_as(prefix, "cluster_log_block_buf_bw");
            stat_log_block_page_bw.expose_as(prefix, "cluster_log_block_page_bw");
            stat_rbio_init_lat_primary.expose_as(prefix, "cluster_rbio_primary_init");
            stat_rbio_lat_primary.expose_as(prefix, "cluster_rbio_primary");
            stat_rbio_error_count_primary.expose_as(prefix, "cluster_rbio_primary_error_count");
            stat_rbio_req_wait_lsn_lat_primary.expose_as(prefix, "cluster_rbio_primary_req_wait_lsn");
            stat_rbio_req_retry_times_avg_primary.expose_as(prefix, "cluster_rbio_primary_req_retry_times_avg");
            stat_rbio_req_lsn_behind_size_primary.expose_as(prefix, "cluster_rbio_primary_req_lsn_behind_size");
            stat_rbio_req_prepare_lat_primary.expose_as(prefix, "cluster_rbio_primary_req_prepare");
            stat_rbio_req_apply_lat_primary.expose_as(prefix, "cluster_rbio_primary_req_data");
            stat_rbio_init_lat_secondary.expose_as(prefix, "cluster_rbio_secondary_init");
            stat_rbio_lat_secondary.expose_as(prefix, "cluster_rbio_secondary");
            stat_rbio_error_count_secondary.expose_as(prefix, "cluster_rbio_secondary_error_count");
            stat_rbio_req_wait_lsn_lat_secondary.expose_as(prefix, "cluster_rbio_secondary_wait_lsn");
            stat_rbio_req_retry_times_avg_secondary.expose_as(prefix, "cluster_rbio_secondary_req_retry_times_avg");
            stat_rbio_req_lsn_behind_size_secondary.expose_as(prefix, "cluster_rbio_secondary_req_lsn_behind_size");
            stat_rbio_req_prepare_lat_secondary.expose_as(prefix, "cluster_rbio_secondary_prepare");
            stat_rbio_req_apply_lat_secondary.expose_as(prefix, "cluster_rbio_secondary_data");
            for (auto& stat_ls : stat_log_services) {
                stat_ls->expose_as(prefix);
            }
#endif
            return true;
        }
        return false;
    }

    bool Disable() {
        if (_status.exchange(kDisable) == kEnable) {
            stat_psm_req_lat.hide();
            stat_psm_req_err_count.hide();
            stat_get_log_service_count.hide();
            stat_psm_req_merge_count.hide();
            stat_log_block_size.hide();
            stat_log_block_buf_bw.hide();
            stat_log_block_page_bw.hide();
            stat_rbio_init_lat_primary.hide();
            stat_rbio_lat_primary.hide();
            stat_rbio_req_wait_lsn_lat_primary.hide();
            stat_rbio_error_count_primary.hide();
            stat_rbio_req_retry_times_avg_primary.hide();
            stat_rbio_req_lsn_behind_size_primary.hide();
            stat_rbio_req_prepare_lat_primary.hide();
            stat_rbio_req_apply_lat_primary.hide();
            stat_rbio_init_lat_secondary.hide();
            stat_rbio_lat_secondary.hide();
            stat_rbio_error_count_secondary.hide();
            stat_rbio_req_wait_lsn_lat_secondary.hide();
            stat_rbio_req_retry_times_avg_secondary.hide();
            stat_rbio_req_lsn_behind_size_secondary.hide();
            stat_rbio_req_prepare_lat_secondary.hide();
            stat_rbio_req_apply_lat_secondary.hide();
            for (auto& stat_ls : stat_log_services) {
                stat_ls->hide();
            }
            return true;
        }
        return false;
    }
};

struct ExtentArg {
    uint32_t search_extent_id;
    gaia_apply::page_no_t logical_page_no;
};

using EventClosureArgType = std::variant<std::nullptr_t, ExtentArg>;
struct EventClosure {
    SegmentWeakPtr segment;
    ggpb::Closure* closure;
    pspb::Status* status;
    EventClosureArgType arg;

    EventClosure(SegmentPtr _segment,
        ggpb::Closure* _closure,
        pspb::Status* _status,
        std::nullptr_t)
        : segment(_segment),
        closure(_closure),
        status(_status),
        arg(nullptr) {}
    EventClosure(SegmentPtr _segment,
        ggpb::Closure* _closure,
        pspb::Status* _status,
        ExtentArg extent_arg)
        : segment(_segment),
        closure(_closure),
        status(_status),
        arg(extent_arg) {}
    FUNC_MOCK ~EventClosure() {
        brpc::ClosureGuard closure_guard(closure);
    }
};

struct event_space_extent_t {
    gaia_apply::space_id_t space_id;
    uint32_t begin_extent_id;

    event_space_extent_t(gaia_apply::space_id_t space,
        uint32_t extent)
        : space_id(space),
        begin_extent_id(extent) {
    }
    event_space_extent_t(const event_space_extent_t& rhs)
        : space_id(rhs.space_id),
        begin_extent_id(rhs.begin_extent_id) {
    }

    bool operator==(const event_space_extent_t& rhs) const {
        return space_id == rhs.space_id && begin_extent_id == rhs.begin_extent_id;
    }

    bool operator< (const event_space_extent_t& rhs) const {
        return (space_id != rhs.space_id) ? (space_id < rhs.space_id) : (begin_extent_id < rhs.begin_extent_id);
    }
};

}

namespace std {

template<> struct hash<psvr::event_space_extent_t> {
    size_t operator()(const psvr::event_space_extent_t& f) const {
        return std::hash<uint64_t>{}(u32tou64(f.space_id, f.begin_extent_id));
    }
};
}

namespace psvr {

template<typename T>
struct EventType {

friend class RpcQuota;

    EventType(T k) : _key(k) {}
    ~EventType() {}

    const T& key() { return _key; }

private:
    template<typename ARG>
    void AddClosure(SegmentPtr segment, ggpb::Closure* closure, pspb::Status* status, ARG arg) {
        _closures.emplace_back(segment, closure, status, arg);
    }

    SegmentPtr GetSegment() {
        for (auto& it : _closures) {
            SegmentPtr segment = it.segment.lock();
            if (segment_is_valid(segment)) {
                return segment;
            }
        }
        return nullptr;
    }

    template <typename Fn>
    void Run(Fn fn) {
        while (!_closures.empty()) {
            auto& entry = _closures.front();
            SegmentPtr segment = entry.segment.lock();
            if (segment) {
                fn (segment, _key, entry.status, entry.arg);
            } else {
                if (entry.status) {
                    set_rpc_status(entry.status, pspb::Status::INVALID, "segment maybe release");
                }
            }
            _closures.pop_front();
        }
    }

private:
    const T _key;
    std::list<EventClosure> _closures;
};

using SpaceMetaEventType = EventType<gaia_apply::space_id_t>;
using SpaceExtentEventType = EventType<event_space_extent_t>;
using PeerEventType = EventType<gaiadb::common::segment_t>;

class RpcQuota {
public:
    RpcQuota(const std::string& name);
    FUNC_MOCK ~RpcQuota();

    std::shared_ptr<FlowQuota> flow_quota() { return _flow_quota; }
    FUNC_MOCK uint64_t GetQuota() { return _flow_quota->GetQuota(1); }

    FUNC_MOCK std::shared_ptr<SpaceMetaEventType> CreateSpaceMetaEvent(SegmentPtr segment,
            gaia_apply::space_id_t space_id,
            ggpb::Closure* closure,
            pspb::Status* status);
    FUNC_MOCK std::shared_ptr<SpaceExtentEventType> CreateSpaceExtentEvent(SegmentPtr segment,
            gaia_apply::space_id_t space_id,
            uint32_t begin_extent_id,
            uint32_t search_extent_id,
            gaia_apply::page_no_t logical_page_no,
            ggpb::Closure* closure,
            pspb::Status* status);
    FUNC_MOCK std::shared_ptr<PeerEventType> CreatePeerEvent(SegmentPtr segment,
            ggpb::Closure* closure,
            pspb::Status* status);

    SegmentPtr GetSpaceMetaEventFirstSegment(std::shared_ptr<SpaceMetaEventType> event) {
        return _space_event_ops.GetFirstSegment(event);
    }

    SegmentPtr GetSpaceExtentEventFirstSegment(std::shared_ptr<SpaceExtentEventType> event) {
        return _offset_event_ops.GetFirstSegment(event);
    }

    SegmentPtr GetPeerEventFirstSegment(std::shared_ptr<PeerEventType> event) {
        return _peer_event_ops.GetFirstSegment(event);
    }

    template <typename Fn>
    void RemoveSpaceMetaEvent(std::shared_ptr<SpaceMetaEventType> event, Fn fn) {
        _space_event_ops.Erase(event, fn);
    }

    template <typename Fn>
    void RemoveSpaceExtentEvent(std::shared_ptr<SpaceExtentEventType> event, Fn fn) {
        _offset_event_ops.Erase(event, fn);
    }

    template <typename Fn>
    void RemovePeerEvent(std::shared_ptr<PeerEventType> event, Fn fn) {
        _peer_event_ops.Erase(event, fn);
    }

private:
    template<typename K, typename V>
    struct Event {
        Event() {}
        ~Event() {}

        template <typename Fn>
        void Erase(std::shared_ptr<V> event, Fn fn) {
            std::unique_lock lk(_mutex);
            auto it = _slots.find(event->key());
            if (it != _slots.end()) {
                (*(it->second))->Run(fn);
                _list.erase(it->second);
                _slots.erase(it);
            }
        }

        template<typename ARG = std::nullptr_t>
        std::shared_ptr<V> Add(K key, SegmentPtr segment,
                ggpb::Closure* closure, pspb::Status* status, ARG arg = nullptr) {
            std::unique_lock lk(_mutex);
            if (auto it = _slots.find(key);
                    it != _slots.end()) {
                (*(it->second))->AddClosure(segment, closure, status, arg);
                return nullptr;
            } else {
                std::shared_ptr<V> event(new V(key));
                _list.emplace_front(event);
                bool insert_ret = _slots.emplace(key, _list.begin()).second;
                PSVR_ASSERT(insert_ret);
                event->AddClosure(segment, closure, status, arg);
                return event;
            }
        }

        SegmentPtr GetFirstSegment(std::shared_ptr<V> event) {
            std::unique_lock lk(_mutex);
            auto it = _slots.find(event->key());
            if (it != _slots.end()) {
                return (*(it->second))->GetSegment();
            }
            return nullptr;
        }

    private:
        std::mutex _mutex;
        std::list<std::shared_ptr<V>> _list;
        std::unordered_map<K, typename std::list<std::shared_ptr<V>>::iterator> _slots;
    };

private:
    std::shared_ptr<FlowQuota> _flow_quota;
    Event<gaia_apply::space_id_t, SpaceMetaEventType> _space_event_ops;
    Event<event_space_extent_t, SpaceExtentEventType> _offset_event_ops;
    Event<gaiadb::common::segment_t, PeerEventType> _peer_event_ops;
};

class LogServices {
    using Node = gaiadb::common::PeerZone;
    struct SNode {
        std::vector<Node> nodes;
        uint64_t version;
        SNode() : nodes(), version(0) {}
    };
    using DBDNodes = base::DoublyBufferedData<SNode>;

    static size_t Update(SNode& bg, const std::vector<Node>& nodes, uint64_t* version) {
        if (bg.nodes != nodes) {
            bg.nodes = nodes;
        }
        ++bg.version;
        *version = bg.version;
        return 1;
    }

public:
    LogServices() : _locker() {}
    ~LogServices() {}

    uint64_t get_nodes_start_idx() { return base::RandUint64(); }

    FUNC_MOCK bool GetRefreshLock(std::shared_ptr<Segment> locker);
    void PutRefreshLock();

    FUNC_MOCK bool Get(std::vector<Node>* nodes, uint64_t* version) {
        DBDNodes::ScopedPtr ptr;
        if (_nodes.Read(&ptr) != 0) {
            LOG(WARNING) << "read dbd log_service failed";
            return false;
        }
        if (ptr->nodes.size() == 0) {
            return false;
        }
        *nodes = ptr->nodes;
        *version = ptr->version;
        return true;
    }

    bool Set(const std::vector<Node>& nodes, uint64_t* version) {
        _nodes.Modify(Update, nodes, version);
        return true;
    }

private:
    DBDNodes _nodes;
    rwlock_t _shared_mutex;
    std::weak_ptr<Segment> _locker;
};

class IgnoreCorruptInfo {
public:
    IgnoreCorruptInfo() : _empty(true), _drop_num(0), _spaces(), _segment_spaces() {}
    ~IgnoreCorruptInfo() {}

    bool empty() { return _empty.load(std::memory_order_relaxed); }

    void AddSpace(gaia_apply::space_id_t id) {
        std::unique_lock lk(_shared_mutex);
        if (_spaces.emplace(id).second) {
            if (_drop_num++ == 0) {
                _empty.store(false);
            }
        }
    }

    void AddSegmentSpace(uint32_t segment_id, gaia_apply::space_id_t id) {
        std::unique_lock lk(_shared_mutex);
        bool add = false;
        auto it = _segment_spaces.find(segment_id);
        if (it != _segment_spaces.end()) {
            add = it->second.emplace(id).second;
        } else {
            std::set<gaia_apply::space_id_t> tmp {id};
            add = _segment_spaces.emplace(segment_id, tmp).second;
        }

        if (add) {
            if (_drop_num++ == 0) {
                _empty.store(false);
            }
        }
    }

    void RemoveSpace(gaia_apply::space_id_t id) {
        std::unique_lock lk(_shared_mutex);
        if (_spaces.erase(id) > 0) {
            if (--_drop_num == 0) {
                _empty.store(true);
            }
        }
    }

    void RemoveSegmentSpace(uint32_t segment_id, gaia_apply::space_id_t id, bool gc = false) {
        std::unique_lock lk(_shared_mutex);
        auto it = _segment_spaces.find(segment_id);
        if (it != _segment_spaces.end()) {
            if (it->second.erase(id) > 0) {
                if (it->second.empty()) {
                    _segment_spaces.erase(it);
                }
                if (--_drop_num == 0) {
                    _empty.store(true);
                }
            }
        }
        if (gc) {
            if (_spaces.erase(id) > 0) {
                if (--_drop_num == 0) {
                    _empty.store(true);
                }
            }
        }
    }

    void Clear() {
        std::unique_lock lk(_shared_mutex);
        _drop_num -= _spaces.size();
        _spaces.clear();
        if (_drop_num == 0) {
            _empty.store(true);
        }
    }

    void ClearSegment(uint32_t segment_id) {
        std::unique_lock lk(_shared_mutex);
        auto it = _segment_spaces.find(segment_id);
        if (it != _segment_spaces.end()) {
            _drop_num -= it->second.size();
            _segment_spaces.erase(segment_id);
            if (_drop_num == 0) {
                _empty.store(true);
            }
        }
    }

    bool Exist(uint32_t segment_id, gaia_apply::space_id_t id) {
        std::shared_lock slk(_shared_mutex);
        if (_spaces.count(id) > 0) {
            return true;
        }
        auto it = _segment_spaces.find(segment_id);
        if (it != _segment_spaces.end()) {
            return it->second.count(id) > 0;
        }
        return false;
    }

    void List(std::set<gaia_apply::space_id_t>* ids) {
        std::shared_lock slk(_shared_mutex);
        *ids = _spaces;
    }

    void ListSegment(uint32_t segment_id, std::set<gaia_apply::space_id_t>* ids) {
        std::shared_lock slk(_shared_mutex);
        auto it = _segment_spaces.find(segment_id);
        if (it != _segment_spaces.end()) {
            *ids = it->second;
        }
    }

private:
    std::atomic<bool> _empty;
    size_t _drop_num;
    std::set<gaia_apply::space_id_t> _spaces;
    std::map<uint32_t, std::set<gaia_apply::space_id_t>> _segment_spaces;
    rwlock_t _shared_mutex;
};

class InBackup {
public:
    InBackup(const char* name) : _name(name), _in_backup(1), _lease(0), _change_time(0) {}

    void Update(bool s);
    operator bool() const noexcept;

private:
    const char* _name;
    std::atomic<int32_t> _in_backup;
    std::atomic<int64_t> _lease;
    std::atomic<int64_t> _change_time;
};

class EncryptHelper {
public:
    EncryptHelper() {}
    ~EncryptHelper() {}

    bool InitCipherStream(const gaiapb::EncryptionInfo &encryption_info_pb);
    const BlockAccessCipherStreamPtr cipher_stream();
    const EncryptionInfo &encryption_info();
    void set_cipher_stream_for_test(BlockAccessCipherStreamPtr cipher_stream) {
        _cipher_stream = cipher_stream;
    }

private:
    EncryptionInfo _encryption_info;
    BlockAccessCipherStreamPtr _cipher_stream;
    rwlock_t _shared_mutex;
};
using EncryptHelperPtr = std::shared_ptr<EncryptHelper>;

class Cluster {
public:
    Cluster(const std::string& name);
    FUNC_MOCK ~Cluster() {
        _fetch_quota->hide();
        _recover_redo_quota->hide();
    }

    const std::string& name() { return _name; }
    uint32_t hash_val() const { return _hash_val; }

    bool use_batch_fetch() const { return _use_batch_fetch.load() > 0; }
    void set_use_batch_fetch() { _use_batch_fetch.store(1); }

    gaia_apply::lsn_t real_cn_lowest_lsn() const {
        return std::max(cn_lowest_lsn(), cn_lowest_gc_lsn());
    }

    gaia_apply::lsn_t real_ps_lowest_lsn() const {
        return std::max(ps_lowest_lsn(), ps_lowest_gc_lsn());
    }

    gaia_apply::lsn_t cn_lowest_lsn() const { return _cn_lowest_lsn(); }
    void set_cn_lowest_lsn(gaia_apply::lsn_t lsn) { _cn_lowest_lsn(lsn, true); }
    gaia_apply::lsn_t ps_lowest_lsn() const { return _ps_lowest_lsn(); }
    void set_ps_lowest_lsn(gaia_apply::lsn_t lsn) { _ps_lowest_lsn(lsn, true); }

    gaia_apply::lsn_t cn_lowest_gc_lsn() const { return _cn_lowest_gc_lsn(); }
    void set_cn_lowest_gc_lsn(gaia_apply::lsn_t lsn) { _cn_lowest_gc_lsn(lsn, true); }
    gaia_apply::lsn_t ps_lowest_gc_lsn() const { return _ps_lowest_gc_lsn(); }
    void set_ps_lowest_gc_lsn(gaia_apply::lsn_t lsn) { _ps_lowest_gc_lsn(lsn, true); }

    gaia_apply::lsn_t max_get_log_lsn() const { return _max_get_log_lsn(); }
    void set_max_get_log_lsn(gaia_apply::lsn_t lsn) { _max_get_log_lsn(lsn, true); }

    int64_t last_lsn_update_time() const { return _last_lsn_update_time.load(); }
    void set_last_lsn_update_time(int64_t t) { _last_lsn_update_time.store(t); }

    std::shared_ptr<RpcQuota> rpc_quota() { return _rpc_quota; }

    std::shared_ptr<LogServices> log_services() { return _log_services; }

    std::shared_ptr<IgnoreCorruptInfo> ignore_corrupt_info() { return _ignore_corrupt_info; }

    InBackup& in_backup() { return _in_backup; }

    EncryptHelperPtr encrypt_helper() { return _encrypt_helper; }

    bool EnableQuota(int64_t size, bool is_recover_redo) const {
        return !is_recover_redo ? _fetch_quota->Enable(size) : _recover_redo_quota->Enable(size);
    }
    bool GetQuota(int64_t size, bool is_recover_redo) {
        return !is_recover_redo ? _fetch_quota->Acquire(size) : _recover_redo_quota->Acquire(size);
    }
    void PutQuota(int64_t size, bool is_recover_redo) {
        return !is_recover_redo ? _fetch_quota->Release(size) : _recover_redo_quota->Release(size);
    }

    FUNC_MOCK bool EnableClusterStatistic(const std::string& prefix) { return _statistic->Enable(prefix); }
    FUNC_MOCK bool DisableClusterStatistic() { return _statistic->Disable(); }

    std::shared_ptr<ClusterStatistic> statistic() { return _statistic; }

    bool enable_encrypt() const { return _enable_encrypt.load() > 0; }
    void set_enable_encypt() { _enable_encrypt.store(1); }

private:
    const std::string _name;
    const uint32_t _hash_val;
    std::atomic<int32_t> _use_batch_fetch;
    char pad0 BAIDU_CACHELINE_ALIGNMENT;
    Lsn _cn_lowest_lsn;
    Lsn _ps_lowest_lsn;
    Lsn _cn_lowest_gc_lsn;
    Lsn _ps_lowest_gc_lsn;
    Lsn _max_get_log_lsn;
    std::atomic<int64_t> _last_lsn_update_time;
    char pad1 BAIDU_CACHELINE_ALIGNMENT;
    std::shared_ptr<RpcQuota> _rpc_quota;
    char pad2 BAIDU_CACHELINE_ALIGNMENT;
    std::shared_ptr<Quota> _fetch_quota;
    std::shared_ptr<Quota> _recover_redo_quota;
    char pad3 BAIDU_CACHELINE_ALIGNMENT;
    std::shared_ptr<LogServices> _log_services;
    char pad4 BAIDU_CACHELINE_ALIGNMENT;
    std::shared_ptr<IgnoreCorruptInfo> _ignore_corrupt_info;
    char pad5 BAIDU_CACHELINE_ALIGNMENT;
    InBackup _in_backup;
    // stat
    std::shared_ptr<ClusterStatistic> _statistic;
    // for encryption
    EncryptHelperPtr _encrypt_helper;
    std::atomic<int32_t> _enable_encrypt;
};

}
