/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/repair_primary_standby_space_extent.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class RepairPrimaryStandbySpaceExtent : public Command {
public:
    RepairPrimaryStandbySpaceExtent() : Command(true) {
        SetName("repair-primary-standby-space-extent");
        SetDesc("repair space extent between primary and standby cluster");
        SetDescCn("修复主备集群之间的表空间和大小的差异");

        AddRequiredArgOption("primary-manager-address", nullptr, 'p', "primary cluster manager address", kstring);
        AddRequiredArgOption("standby-manager-address", nullptr, 's', "standby cluster manager address", kstring);
        AddRequiredArgOption("epoch", nullptr, 'e', "standby cluster epoch", kuint64_t, kGroup2Scope);
        AddNoArgOption("delete", nullptr, 'd', "drop space extent which has been repaired", kGroup2Scope);
        AddNoArgOption("daemonize", &_long_opt_val, kOptMax + 1, "run as daemonize", kGroup3Scope);

        AddExample("--primary-manager-address \"bns://xxx\" --standby-manager-address \"bns://xxx\"");
    }
    virtual ~RepairPrimaryStandbySpaceExtent() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'p':
            _primary_addr = opt;
            break;
        case 's':
            _standby_addr = opt;
            break;
        case 'e':
            _standby_epoch = std::strtoull(opt, NULL, 10);
            break;
        case 'd':
            _delete = true;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _daemonize = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    bool GetAllSpace(std::vector<base::EndPoint>& nodes,
            std::set<uint32_t>& ids);
    bool GetSpaceExtentNum(std::vector<base::EndPoint>& nodes,
            uint32_t space_id, uint32_t& alloc_extent_num);
    bool CreateSpace(std::vector<base::EndPoint>& nodes,
            uint32_t space_id, uint32_t alloc_extent_num);
    bool GetSpace(std::vector<base::EndPoint>& nodes,
            uint32_t space_id, bool& exists);
    bool DropSpace(std::vector<base::EndPoint>& nodes,
            uint32_t space_id);
private:
    std::string _primary_addr {};
    std::string _standby_addr {};
    uint64_t _standby_epoch {0};
    bool _delete {false};
    bool _daemonize {false};
};

}
}
