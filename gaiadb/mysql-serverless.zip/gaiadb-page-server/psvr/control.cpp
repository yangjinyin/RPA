/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/control.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <sstream>

#include <gaiadb/common/types.h>
#include <gaiadb/psm_client/config.h>
#include "psvr/config.h"
#include "psvr/store_cfg.h"
#include "psvr/control_context.h"
#include "psvr/file_utils.h"
#include <base/macros.h>

namespace psvr {

static bool check_segment_meta_size(const gaiapb::PageServerInfo& info,
        uint64_t segment_size) {
    if (info.has_max_extent_num()
            && extent_num_to_size(info.max_extent_num()) != segment_size) {
        LOG(ERROR) << "mismatch segment size,"
            << " meta_size:[" << extent_num_to_size(info.max_extent_num())
            << "] expect_size:[" << segment_size
            << "]";
        return false;
    }
    return true;
}

static bool check_segment_meta_id(const gaiapb::PageServerInfo& info,
        uint32_t segment_id) {
    if (info.segment_id() != segment_id) {
        LOG(ERROR) << "mismatch segment id,"
            << " meta_id:[" << info.segment_id()
            << "] expect_id:[" << segment_id
            << "]";
        return false;
    }
    return true;
}

static bool check_segment_meta(const gaiapb::PageServerInfo& info,
        uint64_t segment_size, uint32_t segment_id, uint32_t replica_id) {
    if (!check_segment_meta_size(info, segment_size)) {
        return false;
    }

    if (!check_segment_meta_id(info, segment_id)) {
        return false;
    }

    if (info.replica_id() != replica_id) {
        LOG(ERROR) << "mismatch segment replica id,"
            << " meta_replica_id:[" << info.replica_id()
            << "] expect_replica_id:[" << replica_id
            << "]";
        return false;
    }

    return true;
}

static bool check_segment_meta_replica_version(const gaiapb::PageServerInfo& info,
        uint64_t version) {
    if (info.has_version() && version > 0
            && info.version() != version) {
        LOG(ERROR) << "mismatch segment replica version,"
            << " meta_replica_version:[" << info.version()
            << "] expect_replica_version:[" << version
            << "]";
        return false;
    }
    return true;
}

uint64_t get_heartbeat_interval_us() {
    return second2microseconds(gaiadb::psm_client::FLAGS_heartbeat_interval_second)
        + millisecond2microseconds(gaiadb::psm_client::FLAGS_heartbeat_interval_ms);
}

static const char* action2str(Control::Action action) {
    switch(action) {
    case Control::Action::kInitSegment:
        return "kInitSegment";
    case Control::Action::kLoadSegment:
        return "kLoadSegment";
    case Control::Action::kOnLoadSegment:
        return "kOnLoadSegment";
    case Control::Action::kPreLoadSegment:
        return "kPreLoadSegment";
    case Control::Action::kCreateSegment:
        return "kCreateSegment";
    case Control::Action::kOnCreateSegment:
        return "kOnCreateSegment";
    case Control::Action::kAsyncCreateSegment:
        return "kAsyncCreateSegment";
    case Control::Action::kOnAsyncCreateSegment:
        return "kOnAsyncCreateSegment";
    case Control::Action::kDropSegment:
        return "kDropSegment";
    case Control::Action::kDeleteSegment:
        return "kDeleteSegment";
    case Control::Action::kDisableStore:
        return "kDisableStore";
    case Control::Action::kUpdateStore:
        return "kUpdateStore";
    case Control::Action::kUpdateAllStore:
        return "kUpdateAllStore";
    case Control::Action::kModifySegmentManagerInfo:
        return "kModifySegmentManagerInfo";
    case Control::Action::kMultiModifySegmentManagerInfo:
        return "kMultiModifySegmentManagerInfo";
    case Control::Action::kRefreshPsmInfoNodes:
        return "kRefreshPsmInfoNodes";
    case Control::Action::kLoadSegmentMeta:
        return "kLoadSegmentMeta";
    case Control::Action::kOnLoadSegmentMeta:
        return "kOnLoadSegmentMeta";
    case Control::Action::kGcStoreTrash:
        return "kGcStoreTrash";
    case Control::Action::kMonitorStore:
        return "kMonitorStore";
    case Control::Action::kMonitorSegment:
        return "kMonitorSegment";
    case Control::Action::kHeartbeat:
        return "kHeartbeat";
    case Control::Action::kBatchHeartbeat:
        return "kBatchHeartbeat";
    case Control::Action::kClearSpaceStatus:
        return "kClearSpaceStatus";
    case Control::Action::kResetPsmQuota:
        return "kResetPsmQuota";
    case Control::Action::kIncOrDecThreadNum:
        return "kIncOrDecThreadNum";
    case Control::Action::kUpdateLowestLsn:
        return "kUpdateLowestLsn";
    case Control::Action::kSealDblwrFile:
        return "kSealDblwrFile";
    default:
        return "unknown";
    }
}

bool Control::BatchHeartbeatGroup::EnableLog() const {
    return segment_size > 1 && (max_gc_lsn - min_gc_lsn) >= GBToByte(1lu);
}

RpcBatchPageServerHeartbeatCtx* Control::BatchHeartbeatTask::Add(SegmentPtr segment) {
    auto gc_lsn = segment->gc_lsn();
    if (gc_lsn > max_gc_lsn) {
        max_gc_lsn = gc_lsn;
    }
    if (group_list.empty()
            || group_list.back()->segment_size >= FLAGS_psvr_batch_heartbeat_max_segment_size) {
        group_list.emplace_back(std::make_shared<BatchHeartbeatGroup>(++inflight_count));
    }
    auto& group = group_list.back();
    ++group->segment_size;
    if (gc_lsn > group->max_gc_lsn) {
        group->max_gc_lsn = std::max(gc_lsn, max_gc_lsn);
    }
    if (gc_lsn < group->min_gc_lsn) {
        group->min_gc_lsn = gc_lsn;
        group->slow_segment = segment;
    }
    return &group->rpc_ctx;
}

struct GuardRunningSize {
    GuardRunningSize(std::atomic<int32_t>& n) : _num(n) {
        _num.fetch_add(1, std::memory_order_relaxed);
    }
    ~GuardRunningSize() {
        _num.fetch_sub(1, std::memory_order_relaxed);
    }
private:
    std::atomic<int32_t>& _num;
};

#define AUTO_INC_DEC_RUNNING_CONTEXT_SIZE()  \
    GuardRunningSize BAIDU_CONCAT(l_name_, __LINE__) (_running_context_size)

Control::Context::~Context() {
    if (closure) {
        baidu::rpc::ClosureGuard guard(closure);
        PSVR_LOG(NOTICE, log_id) << "rpc task finish,"
            << " action:[" << action2str(action)
            << "] use_time_ms:[" << timer.m_elapsed()
            << "] " << segment;
    }
}

Control::Control(ClientPtr client, bool multi_type)
    : _client(client),
    _multi_type(multi_type),
    _stopped(true),
    _thread_num(1),
    _task_thread_num(1),
    _one_segment(nullptr),
    _timer(nullptr),
    _thread_pool(nullptr),
    _task_thread_pool(nullptr),
    _segment_manager(nullptr),
    _store_manager(nullptr),
    _buf_pool(nullptr),
    _rpc_server(nullptr),
    _fetcher(nullptr),
    _parser(nullptr),
    _gc(nullptr),
    _recoverer(nullptr),
    _compressor(nullptr),
    _rbio_manager(nullptr),
    _heartheat_epoch(0),
    _dbd_zone(nullptr),
    _server_start_time(0),
    _get_metadata_quota_per_cluster(0),
    _running_context_size(0),
    _in_stopping(false),
    _stat_heartbeat_task_lat(kSlaWindowSize),
    _stat_heartbeat_rpc_lat(kSlaWindowSize) {
    // init endpoint
    if (!InitAddr()) {
        psvr_terminate();
    }
}

Control::~Control() {
    if (!_stopped) {
        Stop();
    }
}

#define PSVR_CORE_THREAD_NUM 1
#define HEARTBEAT_THREAD_NUM 1
#define GC_STORE_TRASH_THREAD_NUM 2
#define SEAL_DBLWR_THRAD_NUM 1

bool Control::InitAddr() {
    if (!FLAGS_psvr_interfaces.empty()) {
        _myself.ip = base::int2ip(gaiadb::common::get_host_ip(FLAGS_psvr_interfaces.c_str(), true));
        if (base::ip2int(_myself.ip) == 0) {
            LOG(ERROR) << "get ip by interfaces failed";
            return false;
        }
        if (base::my_ip() != _myself.ip) {
            LOG(ERROR) << "get ip by interfaces mismatch hostname2ip"
                << " interface:[" << base::ip2str(_myself.ip).c_str()
                << "] hostname2ip:[" << base::my_ip_cstr()
                << "]";
            return false;
        }
        LOG(TRACE) << "get ip info by interface,"
            << " ip:" << base::ip2str(_myself.ip).c_str()
            << "] interface:[" << FLAGS_psvr_interfaces
            << "]";
    } else {
        _myself.ip = base::my_ip();
        LOG(TRACE) << "get ip info by hostname,"
            << " ip:" << base::ip2str(_myself.ip).c_str()
            << "]";
    }

    if (FLAGS_psvr_rbio_server_ip.size()) {
        base::ip_t ip;
        int ret = base::str2ip(FLAGS_psvr_rbio_server_ip.c_str(), &ip);
        if (ret != 0) {
            LOG(ERROR) << "cant convert ip and port to endpoint,"
                << " ip:[" << FLAGS_psvr_rbio_server_ip
                << "]";
            return false;
        }

        if (_myself.ip != ip) {
            LOG(ERROR) << "interfaces or hostname2ip mismatch config ip"
                << " ip:[" << base::ip2str(_myself.ip).c_str()
                << "] cfg_ip:[" << FLAGS_psvr_rbio_server_ip
                << "]";
            return false;
        }
    }

    _myself.port = FLAGS_psvr_rbio_server_port;
    _myself_str = base::endpoint2str(_myself).c_str();

    std::string host_file = "host.cfg";
    gaiadb::common::Config config;
    if (std::filesystem::exists(host_file)) {
        if (!config.Load(host_file)) {
            LOG(ERROR) << "load " << host_file << " failed";
            return false;
        }
        const std::string host_ip = config.GetString("host", "ip", "");
        const int32_t host_port = config.GetInt("host", "port", -1);
        base::ip_t ip;
        int ret = base::str2ip(host_ip.c_str(), &ip);
        if (ret != 0) {
            LOG(ERROR) << host_file << " ip string convert to ip format failed,"
                << " host_ip:[" << host_ip
                << "]";
            return false;
        }

        if (_myself.ip != ip || FLAGS_psvr_rbio_server_port != host_port) {
            LOG(ERROR) << host_file << " ip & port mismatch config,"
                << " host_ip:[" << host_ip
                << "] host_port:[" << host_port
                << "] addr:[" << _myself_str
                << "]";
            return false;
        }
    } else {
        config.SetString("host", "ip", base::ip2str(_myself.ip).c_str());
        config.SetInt("host", "port", _myself.port);
#ifndef GTEST
        if (!atomic_write_file(host_file, config.ToString(), true/*sync*/)) {
            LOG(ERROR) << host_file << " update failed";
            return false;
        }
        db::Status status = db::sync_directoryx(".");
        if (!status.IsOk()) {
            LOG(ERROR) << host_file << " directory sync failed, " << status;
            return false;
        }
#endif
    }
    return true;
}

void Control::Init() {
    _timer.reset(new thread::Timer<thread::TaskContext>("shared"));
    _thread_pool.reset(new ThreadPoolExecutor<Context, thread::TaskContext>);
    _task_thread_pool.reset(new ThreadPoolExecutor<Context, thread::TaskContext>);
    _segment_manager.reset(new SegmentManager);
    _store_manager.reset(new StoreManager);
    _buf_pool.reset(new BufPool);
    _rpc_server.reset(new RPCServer(weak_this(), _multi_type));
    _fetcher.reset(new Fetcher(_client, weak_this()));
    _parser.reset(new Parser(_client, weak_this()));
    _gc.reset(new GcManager(_client, weak_this()));
    _recoverer.reset(new Recoverer(_client, weak_this()));
    _compressor.reset(new Compressor(_client, weak_this()));
    _rbio_manager.reset(new RbioManager(_client, weak_this()));
    _dbd_zone.reset(new gaiadb::common::DoublyBufferedNodeZone);
    _load_stat.reset(new LoadStat());
#ifndef GTEST
    _stat_heartbeat_task_lat.expose("psvr_heartbeat_task");
    _stat_heartbeat_rpc_lat.expose("psvr_heartbeat_rpc");
#endif
}

bool Control::Start() {
    _stopped = false;
    if (!ConfigArgsSinkCheck()) {
        LOG(ERROR) << "config value sink check failed, please fixed!";
        return false;
    }

    if (!FLAGS_psvr_zone_region.empty() && !FLAGS_psvr_zone_available_zone.empty()) {
        _dbd_zone->Set(FLAGS_psvr_zone_region, FLAGS_psvr_zone_available_zone);
        LOG(NOTICE) << "set zone,"
            << " region:[" << FLAGS_psvr_zone_region
            << "] available_zone:[" << FLAGS_psvr_zone_available_zone
            << "]";
    }

    // Warning:
    // restart the page server, some clusters need more quota to get psm meta data,
    // so set FLAGS_psvr_query_metadata_quota_per_cluster value larger
    // and reset it a few minutes later;
    _get_metadata_quota_per_cluster = FLAGS_psvr_query_metadata_quota_per_cluster;
    FLAGS_psvr_query_metadata_quota_per_cluster = FLAGS_psvr_query_metadata_quota_per_cluster_on_restart;
    _server_start_time = base::cpuwide_time_s();

    typename thread::Timer<thread::TaskContext>::TaskFn timer_fn = std::bind(&Control::OnTimer,
            this, ARG::_1);
    _timer->Start(FLAGS_psvr_timer_tick_interval, timer_fn);

    typename thread::Executor<Context, thread::TaskContext>::TaskFn fn = std::bind(&Control::OnCompletion,
            this, ARG::_1);
    const uint32_t set_num = _multi_type ? FLAGS_multi_psvr_control_thread_num : FLAGS_psvr_control_thread_num;
    _task_thread_num = std::max(_task_thread_num, set_num);
    _thread_num = PSVR_CORE_THREAD_NUM;
    _thread_num += HEARTBEAT_THREAD_NUM;
    _thread_num += GC_STORE_TRASH_THREAD_NUM;
    _thread_num += SEAL_DBLWR_THRAD_NUM;
    if (!_thread_pool->Start("control", _timer, _thread_num, fn)) {
        LOG(ERROR) << "start control thread pool failed";
        return false;
    }
    if (!_task_thread_pool->Start("control", _timer, _task_thread_num, true, fn)) {
        LOG(ERROR) << "start control task thread pool failed";
        return false;
    }
    if (!_buf_pool->Init(_multi_type)) {
        LOG(ERROR) << "init buf pool failed";
        return false;
    }
    // single mode default 1
    uint32_t store_count = 1;
    if (_multi_type) {
        if (!_store_manager->Init()) {
            LOG(ERROR) << "init store manager failed";
            return false;
        }
        store_count = _store_manager->StoreCount();
        if (!_store_manager->InitBatchFetch(shared_this())) {
            LOG(ERROR) << "init batch fetch failed";
            return false;
        }
    }
    if (!_rpc_server->Init()) {
        LOG(ERROR) << "init rpc server failed";
        return false;
    }
    _segment_manager->Start(store_count);
    if (!_rbio_manager->Start(store_count)) {
        LOG(ERROR) << "start rbio manager failed";
        return false;
    }
    if (!_recoverer->Start(store_count)) {
        LOG(ERROR) << "start recoverer failed";
        return false;
    }
    if (!_compressor->Start(store_count)) {
        LOG(ERROR) << "start recoverer failed";
        return false;
    }
    if (!_gc->Start(store_count)) {
        LOG(ERROR) << "start gc failed";
        return false;
    }
    if (!_parser->Start(store_count)) {
        LOG(ERROR) << "start parser failed";
        return false;
    }
    if (!_fetcher->Start(store_count)) {
        LOG(ERROR) << "start fetcher failed";
        return false;
    }
    if (_multi_type) {
        _load_stat->start_time = base::cpuwide_time_us();
        if (!_store_manager->Start(shared_this(), _load_stat)) {
            LOG(ERROR) << "load segments failed";
            return false;
        }
        LOG(NOTICE) << "load stores info,"
            << " store_size:[" << store_count
            << "] normal_num:[" << _load_stat->load_num.load(std::memory_order_acquire)
            << "] prepared_num:[" << _load_stat->prepared_num.load(std::memory_order_acquire)
            << "] failed_num:[" << _load_stat->failed_num.load(std::memory_order_acquire)
            << "]";
        if (!_rpc_server->Start()) {
            LOG(ERROR) << "start rpc server failed";
            return false;
        }
    }

    // start heartbeat
    {
        auto* heartbeat_ctx = new Context(!_multi_type ? Action::kHeartbeat : Action::kBatchHeartbeat);
        SetCtxClientId(heartbeat_ctx);
        heartbeat_ctx->log_id = get_log_id();
        const uint64_t delay_us = get_heartbeat_interval_us();
        Schedule(heartbeat_ctx, delay_us);
        LOG(NOTICE) << "schedule heartbeat ctx, task_id:[" << heartbeat_ctx->task_id << "]";
    }

    if (_multi_type) {
        // start gc trash segment
        auto* gc_ctx = new Context(Action::kGcStoreTrash);
        SetCtxClientId(gc_ctx);
        gc_ctx->log_id = get_log_id();
        Schedule(gc_ctx, second2microseconds(FLAGS_multi_psvr_gc_trash_segment_interval_second));
        LOG(NOTICE) << "schedule gc store ctx, task_id:[" << gc_ctx->task_id << "]";
    }

    // start monitor store statistic
    if (_multi_type) {
        auto* monitor_store_ctx = new Context(Action::kMonitorStore);
        SetCtxClientId(monitor_store_ctx);
        monitor_store_ctx->log_id = get_log_id();
        Schedule(monitor_store_ctx); // update store free size ASAP
        LOG(NOTICE) << "schedule monitor store ctx, task_id:[" << monitor_store_ctx->task_id << "]";
    }

    if (_multi_type) {
        auto* monitor_segment_ctx = new Context(Action::kMonitorSegment);
        SetCtxClientId(monitor_segment_ctx);
        monitor_segment_ctx->log_id = get_log_id();
        Schedule(monitor_segment_ctx); // update segment size ASAP
        LOG(NOTICE) << "schedule monitor segment ctx, task_id:[" << monitor_segment_ctx->task_id << "]";
    }

    // start check and clear space status
    {
        auto* check_space_status_ctx = new Context(Action::kClearSpaceStatus);
        SetCtxClientId(check_space_status_ctx);
        check_space_status_ctx->log_id = get_log_id();
        Schedule(check_space_status_ctx, millisecond2microseconds(FLAGS_psvr_clear_space_status_interval_ms));
        LOG(NOTICE) << "schedule check space status ctx, task_id:[" << check_space_status_ctx->task_id << "]";
    }

    {
        auto* reset_psm_quota_ctx = new Context(Action::kResetPsmQuota);
        SetCtxClientId(reset_psm_quota_ctx);
        reset_psm_quota_ctx->log_id = get_log_id();
        Schedule(reset_psm_quota_ctx, second2microseconds(FLAGS_psvr_query_metadate_quota_per_cluster_on_restart_valid_seconds));
        LOG(NOTICE) << "schedule reset psm quota ctx, task_id:[" << reset_psm_quota_ctx->task_id << "]";
    }

    if (_multi_type) {
        auto* inc_or_dec_thread_num_ctx = new Context(Action::kIncOrDecThreadNum);
        SetCtxClientId(inc_or_dec_thread_num_ctx);
        inc_or_dec_thread_num_ctx->log_id = get_log_id();
        Schedule(inc_or_dec_thread_num_ctx, second2microseconds(3));
        LOG(NOTICE) << "schedule inc or dec thread num ctx, task_id:[" << inc_or_dec_thread_num_ctx->task_id << "]";
    }

    {
        auto* update_lowest_lsn_ctx = new Context(Action::kUpdateLowestLsn);
        SetCtxClientId(update_lowest_lsn_ctx);
        update_lowest_lsn_ctx->log_id = get_log_id();
        Schedule(update_lowest_lsn_ctx, second2microseconds(FLAGS_psvr_update_lowest_lsn_interval_second));
        LOG(NOTICE) << "schedule update lowest lsn ctx, task_id:[" << update_lowest_lsn_ctx->task_id << "]";
    }

    {
        auto* seal_dblwr_file = new Context(Action::kSealDblwrFile);
        SetCtxClientId(seal_dblwr_file);
        seal_dblwr_file->log_id = get_log_id();
        Schedule(seal_dblwr_file, second2microseconds(FLAGS_psvr_dblwr_seal_interval_second));
        LOG(NOTICE) << "schedule dblwr seal ctx, task_id:[" << seal_dblwr_file->task_id << "]";
    }

    LOG(NOTICE) << "control start ok, multi_type:[" << _multi_type << "] addr:[" << _myself_str << "]";
    return true;
}

void Control::Stop() {
    if (!_in_stopping.exchange(true)) {
        LOG(NOTICE) << "control will stop ...";
        _stopped = true;
        _store_manager->Stop();
        while (_running_context_size.load() > 0) {
            sleep_for(millisecond2microseconds(10));
            LOG_EVERY_SECOND(NOTICE) << "wait running context to complete,"
                << " size:[" << _running_context_size.load()
                << "]";
        }
        // set models are stopped
        _rpc_server->Stop(false);        // stop rpc first
        _fetcher->Stop();
        _parser->Stop();
        _gc->Stop();
        _recoverer->Stop();
        _compressor->Stop();
        _rbio_manager->Stop();
        _client->Stop(false);
        _timer->Stop(true);
        _thread_pool->Stop(false);
        _task_thread_pool->Stop(false);
        // wait models stopped
        _fetcher->Join();
        _parser->Join();
        _gc->Join();
        _recoverer->Join();
        _compressor->Join();
        _rbio_manager->Join();
        _client->Stop(true);
        _timer->RecycleTask([this](thread::TaskContext* ctx) {
                    OnTimer(ctx);
                });
        _thread_pool->RecycleTask([this](Context* ctx) {
                    delete ctx;
                });
        _task_thread_pool->RecycleTask([this](Context* ctx) {
                    delete ctx;
                });
        _rpc_server->Join();
        _rpc_server.reset();
        _segment_manager->Stop();
#ifndef GTEST
        _stat_heartbeat_task_lat.hide();
        _stat_heartbeat_rpc_lat.hide();
#endif
        bvar::stop_and_join_global_pthreads();
        LOG(NOTICE) << "control stopped!";
    } else {
        LOG(NOTICE) << "control in stopping, wait ...";
    }
}

bool Control::Execute(Context* ctx) {
    const auto& thread_pool = GetThreadPool(ctx);
    if (!thread_pool->EmergentExecute(ctx)) {
        if (_stopped) {
            std::unique_ptr<Context> ctx_guard(ctx);
        } else {
            psvr_terminate();
        }
        return false;
    }
    return true;
}

void Control::Dispatch(Context* ctx) {
    SetCtxClientId(ctx);
    Schedule(ctx);
}

void Control::RefreshPsmInfo(PsmInfoPtr psm_info) {
    if (psm_info && psm_info->AcquireRefreshLock()) {
        auto* ctx = new Context(Action::kRefreshPsmInfoNodes, psm_info);
        SetCtxClientId(ctx);
        Schedule(ctx);
    }
}

void Control::Schedule(Context* ctx, uint64_t delay_us, bool is_retry) {
    const auto& thread_pool = GetThreadPool(ctx);
    if (is_retry) {
        ++ctx->retry_times;
    }
    if (delay_us == 0) {
        if (thread_pool->Execute(ctx)) {
            return;
        }
    } else {
        if (thread_pool->Schedule(ctx, delay_us)) {
            return;
        }
    }
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }
    LOG(ERROR) << "dispatch segment to control pool failed";
    psvr_terminate();
}

const Control::ThreadPoolTypePtr& Control::GetThreadPool(Context* ctx) const {
    return IsCoreAction(ctx) ? _thread_pool : _task_thread_pool;
}

bool Control::IsCoreAction(Context* ctx) const {
    switch(ctx->action) {
    case Action::kInitSegment:
    case Action::kDisableStore:
    case Action::kUpdateStore:
    case Action::kUpdateAllStore:
    case Action::kDeleteSegment:
    case Action::kIncOrDecThreadNum:
    case Action::kHeartbeat:
    case Action::kBatchHeartbeat:
    case Action::kMonitorStore:
    case Action::kGcStoreTrash:
    case Action::kMonitorSegment:
    case Action::kClearSpaceStatus:
    case Action::kResetPsmQuota:
    case Action::kUpdateLowestLsn:
    case Action::kSealDblwrFile:
        return true;
    default:
        return false;
    }
}

void Control::SetCtxClientId(Context* ctx) {
// core pool layout:
// [0] core | [PSVR_CORE_THREAD_NUM] heartbeat | [+HEARTBEAT_THREAD_NUM] monitor store
// | [+HEARTBEAT_THREAD_NUM + 1] gc trash
// | [+HEARTBEAT_THREAD_NUM + GC_STORE_TRASH_THREAD_NUM] seal dblwr
// ordinary actions are dispatched to the shared task pool.
    switch(ctx->action) {
    case Action::kInitSegment:
    case Action::kDisableStore:
    case Action::kUpdateStore:
    case Action::kUpdateAllStore:
    case Action::kDeleteSegment:
    case Action::kIncOrDecThreadNum:
        ctx->client_id = 0;
        break;
    case Action::kHeartbeat:
    case Action::kBatchHeartbeat:
        ctx->client_id = PSVR_CORE_THREAD_NUM;
        break;
    case Action::kMonitorStore:
        ctx->client_id = PSVR_CORE_THREAD_NUM + HEARTBEAT_THREAD_NUM;
        break;
    case Action::kGcStoreTrash:
    case Action::kMonitorSegment:
    case Action::kClearSpaceStatus:
    case Action::kResetPsmQuota:
    case Action::kUpdateLowestLsn:
        ctx->client_id = PSVR_CORE_THREAD_NUM + HEARTBEAT_THREAD_NUM + 1;
        break;
    case Action::kSealDblwrFile:
        ctx->client_id = PSVR_CORE_THREAD_NUM + HEARTBEAT_THREAD_NUM + GC_STORE_TRASH_THREAD_NUM;
        break;
    default:
        static std::atomic<uint32_t> task_count = 0;
        ctx->client_id = (++task_count) % (IsCoreAction(ctx) ? _thread_num : _task_thread_num);
        break;
    }
}

void Control::OnCompletion(Context* ctx) {
    PSVR_LOG_CTX(TRACE, ctx) << "ctx action:[" << static_cast<uint32_t>(ctx->action) << "," << action2str(ctx->action)
        << "] client_id:[" << ctx->client_id
        << "]";
    switch(ctx->action) {
    case Action::kInitSegment:
        return InitSegment(ctx);
    case Action::kLoadSegment:
        return LoadSegment(ctx);
    case Action::kOnLoadSegment:
        return OnLoadSegment(ctx);
    case Action::kPreLoadSegment:
        return PreLoadSegment(ctx);
    case Action::kCreateSegment:
        return CreateSegment(ctx);
    case Action::kOnCreateSegment:
        return OnCreateSegment(ctx);
    case Action::kAsyncCreateSegment:
        return AsyncCreateSegment(ctx);
    case Action::kOnAsyncCreateSegment:
        return OnAsyncCreateSegment(ctx);
    case Action::kDropSegment:
        return DropSegment(ctx);
    case Action::kDeleteSegment:
        return DeleteSegment(ctx);
    case Action::kDisableStore:
        return DisableStore(ctx);
    case Action::kUpdateStore:
        return UpdateStore(ctx);
    case Action::kUpdateAllStore:
        return UpdateAllStore(ctx);
    case Action::kModifySegmentManagerInfo:
        return ModifySegmentManagerInfo(ctx);
    case Action::kMultiModifySegmentManagerInfo:
        return MultiModifySegmentManagerInfo(ctx);
    case Action::kRefreshPsmInfoNodes:
        return RefreshPsmInfoNodes(ctx);
    case Action::kLoadSegmentMeta:
        return LoadSegmentMeta(ctx);
    case Action::kOnLoadSegmentMeta:
        return OnLoadSegmentMeta(ctx);
    case Action::kHeartbeat:
        return Heartbeat(ctx);
    case Action::kBatchHeartbeat:
        return BatchHeartbeat(ctx);
    case Action::kGcStoreTrash:
        return GcStoreTrash(ctx);
    case Action::kMonitorStore:
        return MonitorStore(ctx);
    case Action::kMonitorSegment:
        return MonitorSegment(ctx);
    case Action::kClearSpaceStatus:
        return ClearSpaceStatus(ctx);
    case Action::kResetPsmQuota:
        return ResetPsmQuota(ctx);
    case Action::kIncOrDecThreadNum:
        return IncOrDecThreadNum(ctx);
    case Action::kUpdateLowestLsn:
        return UpdateLowestLsn(ctx);
    case Action::kSealDblwrFile:
        return SealDblwrFile(ctx);
    default:
        PSVR_ASSERT(false);
    }
}

bool Control::OnTimer(thread::TaskContext* ctx) {
    switch(ctx->client_type) {
    case CtxType::kControl:
        return Execute(static_cast<Context*>(ctx));
    case CtxType::kFetch:
        return _fetcher->Execute(reinterpret_cast<Fetcher::Context*>(ctx));
    case CtxType::kParse:
        return _parser->Execute(reinterpret_cast<Parser::Context*>(ctx));
    case CtxType::kGc:
        return _gc->Execute(reinterpret_cast<GcManager::Context*>(ctx));
    case CtxType::kRecovery:
        return _recoverer->Execute(reinterpret_cast<Recoverer::Context*>(ctx));
    case CtxType::kCompress:
        return _compressor->Execute(reinterpret_cast<Compressor::Context*>(ctx));
    case CtxType::kRbio:
        return _rbio_manager->Execute(reinterpret_cast<RbioManager::Context*>(ctx));
    default:
        psvr_terminate();
        break;
    }
    return false;
}

RpcGetPageServerCtx* Control::CreateGetPageServerRpcCtx(PsmInfoPtr psm_info,
        const std::string& cluster_id, uint32_t segment_id) {
    std::vector<base::EndPoint> nodes;
    if (!psm_info->GetOrRefreshNodes(&nodes)) {
        LOG(WARNING) << "parse psm failed,"
            << " cluster_id:[" << cluster_id
            << "] segment_id:[" << segment_id
            << "] " << psm_info;
        return nullptr;
    }
    auto* rpc_ctx = new RpcGetPageServerCtx;
    rpc_ctx->servers = std::move(nodes);
    rpc_ctx->request.set_addr(myself_str());
    rpc_ctx->request.set_is_need_map(false);
    rpc_ctx->request.set_cluster_id(cluster_id);
    if (segment_id > 0) {
        // unknown segment id on single mode
        rpc_ctx->request.set_segment_id(segment_id);
    }
    rpc_ctx->request.set_is_need_encryption_info(true);
    return rpc_ctx;
}

void Control::StartWorking(SegmentPtr segment TRACE_FILE_LINE_DC) {
    if (FLAGS_psvr_enable_get_all_spaces_on_load) {
        _parser->AddGetAllSpaceIdEvent(segment TRACE_FILE_LINE_ARG_CC);
    }
    _fetcher->Dispatch(segment TRACE_FILE_LINE_ARG_CC);
    _recoverer->AddSegmentToCheckList(segment);
    if (segment->recovery_status() == gaiadb::RECOVERY_IN) {
        bool ret = _recoverer->Dispatch(segment, true, true TRACE_FILE_LINE_ARG_CC);
        LOG(NOTICE) << segment << " start to recovery, ret:" << ret;
    }
}

// Only call on single mode.
void Control::InitSegment(Context* ctx) {
    PSVR_ASSERT(!_multi_type);
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        PSVR_LOG_CTX(NOTICE, ctx) << " init segment failed, server stopped";
        return;
    }

    PsmInfoPtr psm_info = _segment_manager->GetOrCreatePsmInfo(gaiadb::psm_client::FLAGS_manager_address);
    auto* rpc_ctx = CreateGetPageServerRpcCtx(psm_info, gaiadb::psm_client::FLAGS_cluster_id);
    if (!rpc_ctx) {
        Schedule(ctx, get_delay_us(ctx->retry_times), true);
        return;
    }

    auto closure = brpc::NewCallback(this, &Control::OnInitSegment, psm_info, ctx, rpc_ctx);
    _client->GetSegmentInfo(rpc_ctx, closure);
}

void Control::OnInitSegment(PsmInfoPtr psm_info, Context* ctx, RpcGetPageServerCtx* rpc_ctx) {
    std::unique_ptr<RpcGetPageServerCtx> rpc_ctx_guard(rpc_ctx);
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }

    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        if (not_exists) {
            PSVR_LOG_CTX(ERROR, ctx) << "segment not found in manager, exit on single mode!";
            psvr_terminate();
            return;
        }
        if (!rpc_ctx->RetryNext()) {
            psm_info->SetFailed();
            Schedule(ctx, get_delay_us(ctx->retry_times), true);
        } else {
            auto closure = brpc::NewCallback(this, &Control::OnInitSegment,
                    psm_info, ctx, rpc_ctx_guard.release());
            _client->GetSegmentInfo(rpc_ctx, closure);
        }
        return;
    }

    psm_info->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());
    if (rpc_ctx->response.has_is_enabled() && !rpc_ctx->response.is_enabled()) {
        PSVR_LOG_CTX(TRACE, ctx) << "segment is not enabled, wait to start working";
        Schedule(ctx, FLAGS_psvr_retry_delay_us_when_segment_not_enabled);
        return;
    }

    const gaiapb::PageServerInfo& info = rpc_ctx->response.page_server();
    if (!check_segment_meta_size(info, FLAGS_psvr_page_store_file_size)) {
        psvr_terminate();
        return;
    }

    ClusterPtr cluster = _segment_manager->GetOrCreateCluster(gaiadb::psm_client::FLAGS_cluster_id);
    if (rpc_ctx->response.has_encryption_info() && cluster.get() != nullptr) {
        const gaiapb::EncryptionInfo &encryption_info_pb = rpc_ctx->response.encryption_info();
        PSVR_LOG_CTX(TRACE, ctx) << "encryption_key:["
                                 << encryption_info_pb.encryption_key() << "] encryption_iv:["
                                 << encryption_info_pb.encryption_iv() << "] encryption_alg:["
                                 << encryption_info_pb.encryption_alg() << "]";
        EncryptHelperPtr encrypt_helper = cluster->encrypt_helper();
        bool res = encrypt_helper->InitCipherStream(encryption_info_pb);
        if (!res) {
            PSVR_LOG_CTX(ERROR, ctx) << "init cipher stream failed for cluster:["
                                     << gaiadb::psm_client::FLAGS_cluster_id << "] encryption_key:["
                                     << encryption_info_pb.encryption_key() << "] encryption_iv:["
                                     << encryption_info_pb.encryption_iv() << "] encryption_alg:["
                                     << encryption_info_pb.encryption_alg() << "]";
            psvr_terminate();
            return;
        }
        cluster->set_enable_encypt();
    }

    bool enable_punch_hole = false;
    const std::string punch_hole_file_name = base::string_printf("%s/%s",
            FLAGS_psvr_page_store_dir.c_str(), kPunchHoleFile.c_str());
    db::check_punch_hole_feature(punch_hole_file_name, &enable_punch_hole);

    std::unique_ptr<Context> ctx_guard(ctx);
    std::unique_lock lm(_mutex); // protect _one_segment
    _one_segment.reset(new Segment(weak_this(),
                gaiadb::psm_client::FLAGS_cluster_id,
                info.segment_id(),
                info.replica_id(),
                info.has_version() ? info.version() : Segment::kUnknownVersion,
                FLAGS_psvr_page_store_file_size,
                enable_punch_hole,
                Segment::Status::kCreating,
                FLAGS_psvr_page_store_dir,
                Segment::kUnknownStoreID,
                cluster));
    _one_segment->InitPsmInfo(psm_info);
    _one_segment->InitMeta(info);
    if (!_one_segment->OpenEngine(Segment::DB_CREATE_IF_MISSING)) {
        PSVR_LOG_CTX(ERROR, ctx) << _one_segment << " open engine failed";
        psvr_terminate();
        return;
    }
    _one_segment->InitLsn(info);

    if (!_segment_manager->AddSegment(_one_segment)) {
        PSVR_LOG_CTX(ERROR, ctx) << _one_segment << " add failed";
        psvr_terminate();
        return;
    }

    if (!_rpc_server->Start()) {
        PSVR_LOG_CTX(ERROR, ctx) << "start rpc server failed";
        psvr_terminate();
        return;
    }

    set_segment_cluster_statistic(_one_segment, stat_psm_req_lat, rpc_ctx->latency_us);

    PSVR_LOG_CTX(NOTICE, ctx) << "start page server with ok";
    StartWorking(_one_segment TRACE_FILE_LINE_CC);
}

StorePtr Control::PickStore(int64_t log_id, const std::string& cluster_id, uint64_t size, int32_t store_id) {
    if (store_id > -1) {
        StorePtr store = _store_manager->GetStore(store_id);
        if (store && store->EnableAddSegment(size)) {
            return store;
        }
        PSVR_LOG(TRACE, log_id) << " store not found or not ok, store_id:[" << store_id << "]";
    } else {
        // pick a best store
        std::map<uint32_t, uint32_t> store_cluster_segments; // store id -> segment count
        SegmentIteratorFn iter_cluster_fn = [&store_cluster_segments] (SegmentPtr seg) {
            ++store_cluster_segments[seg->store_id()];
        };
        _segment_manager->GetClusterSegments(cluster_id, iter_cluster_fn);
        std::vector<StorePtr> stores;
        _store_manager->GetStores(&stores);

        std::sort(stores.begin(), stores.end(), [&store_cluster_segments](StorePtr left, StorePtr right) {
                auto l_count = store_cluster_segments[left->id()];
                auto r_count = store_cluster_segments[right->id()];
                if (l_count != r_count) {
                    return l_count < r_count;
                } else {
                    return left->free_size() > right->free_size();
                }
            });

        for (auto& s : stores) {
            if (s->EnableAddSegment(size)) {
                return s;
            }
        }
        PSVR_LOG(TRACE, log_id) << " not found a store";
    }
    return nullptr;
}

// In prepare create, only store meta file
void Control::PreLoadSegment(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    const auto* request = reinterpret_cast<const pspb::PreLoadSegmentRequest*>(ctx->request);
    auto* response = reinterpret_cast<pspb::PreLoadSegmentResponse*>(ctx->response);
    auto* status = response->mutable_status();

    ctx->segment = _segment_manager->GetSegment(request->cluster_id(), request->segment_id());
    if (ctx->segment) {
        PsmInfoPtr psm_info = ctx->segment->GetPsmInfo();
        if (ctx->segment->segment_size() == request->size()
                && psm_info->address() == request->manager_address()
                && ctx->segment->is_prepare()) {
            set_rpc_status(status, pspb::Status::SUCCESS, "segment:%s/%u exists",
                    request->cluster_id().c_str(), request->segment_id());
        } else {
            set_rpc_status(status, pspb::Status::EXISTS,
                    "segment:%s/%u exists and mismatch request size:%lu or manager_address:%s",
                    request->cluster_id().c_str(), request->segment_id(), ctx->segment->segment_size(),
                    request->manager_address().c_str());
        }
        return;
    }

    int32_t store_id = request->has_store_id() ? request->store_id() : -1;
    StorePtr store = PickStore(ctx->log_id, request->cluster_id(), request->size(), store_id);
    if (!store) {
        PSVR_LOG_CTX(WARNING, ctx) << "pick store failed,"
            << " cluster_id:[" << request->cluster_id()
            << "] size:[" << request->size()
            << "] store_id:[" << store_id
            << "]";
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u pick store:%d failed",
                request->cluster_id().c_str(), request->segment_id(), store_id);
        return;
    }

    std::string db_path = store->GetSegmentDBPath(request->cluster_id(), request->segment_id());
    ctx->segment.reset(new Segment(weak_this(),
                request->cluster_id(),
                request->segment_id(),
                Segment::kUnknownReplicaID,
                Segment::kUnknownVersion,
                request->size(),
                store->enable_punch_hole(),
                Segment::Status::kPrepare,
                db_path,
                store->id(),
                _segment_manager->GetOrCreateCluster(request->cluster_id())));

    if (!store->IncStatistic(ctx->segment)) {
        PSVR_LOG_CTX(WARNING, ctx) << ctx->segment << " add failed, store:[" << store << "] is full";
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u store:%u fail to add segment",
                request->cluster_id().c_str(), request->segment_id(), store->id());
        return;
    }

    PsmInfoPtr psm_info = _segment_manager->GetOrCreatePsmInfo(request->manager_address());
    ctx->segment->InitPsmInfo(psm_info);

    if (!_segment_manager->AddSegment(ctx->segment)) {
        store->DecStatistic(ctx->segment);
        PSVR_LOG_CTX(WARNING, ctx) << ctx->segment << " add failed";
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u add to manager failed",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    if (!ctx->segment->CreateMeta(store->trash_path())) {
        store->DecStatistic(ctx->segment);
        _segment_manager->DropSegment(ctx->segment);
        PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " create meta failed";
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u create meta failed",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    PSVR_LOG_CTX(NOTICE, ctx) << ctx->segment << " add ok";
    set_rpc_status(status, pspb::Status::SUCCESS, "ok");
}

// open preapre segment with db
void Control::LoadSegment(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    const auto* request = reinterpret_cast<const pspb::LoadSegmentRequest*>(ctx->request);
    auto* response = reinterpret_cast<pspb::LoadSegmentResponse*>(ctx->response);
    auto* status = response->mutable_status();

    ctx->segment = _segment_manager->GetSegment(request->cluster_id(), request->segment_id());
    if (!ctx->segment) {
        set_rpc_status(status, pspb::Status::NOT_EXISTS, "segment:%s/%u not found",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    if (!ctx->segment->is_prepare()) {
        set_rpc_status(status, pspb::Status::EXISTS,
                "segment:%s/%u exists and status is not prepare",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    auto* rpc_ctx = CreateGetPageServerRpcCtx(ctx->segment->GetPsmInfo(),
            request->cluster_id(), request->segment_id());
    if (!rpc_ctx) {
        set_rpc_status(status, pspb::Status::INVALID,
                "segment:%s/%u parse or get manager address list failed",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    auto closure = brpc::NewCallback(this, &Control::OnLoadSegmentRPC, ctx_guard.release(), rpc_ctx);
    _client->GetSegmentInfo(rpc_ctx, closure);
}

void Control::OnLoadSegmentRPC(Context* ctx, RpcGetPageServerCtx* rpc_ctx) {
    ctx->rpc_ctx = rpc_ctx;
    ctx->retry_times = 0;
    ctx->action = Action::kOnLoadSegment;
    Schedule(ctx);
}

void Control::OnLoadSegment(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    ctx->action = Action::kLoadSegment;
    auto* rpc_ctx = ctx->get_rpc_ctx<RpcGetPageServerCtx*>();
    std::unique_ptr<RpcGetPageServerCtx> rpc_ctx_guard(rpc_ctx);
    //const auto* request = reinterpret_cast<const pspb::LoadSegmentRequest*>(ctx->request);
    auto* status = reinterpret_cast<pspb::LoadSegmentResponse*>(ctx->response)->mutable_status();
    if (_stopped) {
        set_rpc_status(status, pspb::Status::ERROR, "server is stopped");
        return;
    }
    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        if (not_exists) {
            set_rpc_status(status, pspb::Status::NOT_EXISTS,
                    "segment:%s/%u not found in manager",
                    ctx->segment->cluster_id().c_str(), ctx->segment->segment_id());
            return;
        }
        if (!rpc_ctx->RetryNext()) {
            ctx->segment->GetPsmInfo()->SetFailed();
            set_rpc_status(status, pspb::Status::ERROR,
                    "segment:%s/%u load fail, cant get metadata",
                    ctx->segment->cluster_id().c_str(), ctx->segment->segment_id());
        } else {
            auto closure = brpc::NewCallback(this, &Control::OnLoadSegmentRPC,
                    ctx_guard.release(), rpc_ctx_guard.release());
            _client->GetSegmentInfo(rpc_ctx, closure);
        }
        return;
    }

    ctx->segment->GetPsmInfo()->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());
    if (rpc_ctx->response.has_is_enabled() && !rpc_ctx->response.is_enabled()) {
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u is not enabled when loading",
                ctx->segment->cluster_id().c_str(), ctx->segment->segment_id());
        return;
    }

    const gaiapb::PageServerInfo& info = rpc_ctx->response.page_server();
    if (!check_segment_meta_size(info, ctx->segment->segment_size())) {
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u mismatch size, meta:%lu expect:%lu",
                ctx->segment->cluster_id().c_str(), ctx->segment->segment_id(),
                extent_num_to_size(info.max_extent_num()), ctx->segment->segment_size());
        return;
    }

    if (!check_segment_meta_id(info, ctx->segment->segment_id())) {
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u mismatch id, meta:%u expect:%u",
                ctx->segment->cluster_id().c_str(), ctx->segment->segment_id(),
                info.segment_id(), ctx->segment->segment_id());
        return;
    }

    if (!ctx->segment->LoadEngineWithMeta(info)) {
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u open engine failed or mismatch segment status",
                ctx->segment->cluster_id().c_str(), ctx->segment->segment_id());
        return;
    }

    if (!ctx->segment->is_active()) {
        PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " status is not active";
        set_rpc_status(status, pspb::Status::ERROR, "segment:%s/%u load failed",
                ctx->segment->cluster_id().c_str(), ctx->segment->segment_id());
        return;
    }

    PSVR_LOG_CTX(NOTICE, ctx) << ctx->segment << " load ok";
    set_rpc_status(status, pspb::Status::SUCCESS, "load succ");

    set_segment_cluster_statistic(ctx->segment, stat_psm_req_lat, rpc_ctx->latency_us);
    StartWorking(ctx->segment TRACE_FILE_LINE_CC);
}

void Control::CreateSegment(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    const auto* request = reinterpret_cast<const pspb::CreateSegmentRequest*>(ctx->request);
    auto* response = reinterpret_cast<pspb::CreateSegmentResponse*>(ctx->response);
    auto* status = response->mutable_status();

    PSVR_LOG_CTX(NOTICE, ctx) << "start create segment:"
        << request->cluster_id() << "/" << request->segment_id();
    ctx->segment = _segment_manager->GetSegment(request->cluster_id(), request->segment_id());
    if (ctx->segment) {
        PsmInfoPtr psm_info = ctx->segment->GetPsmInfo();
        if (ctx->segment->segment_size() == request->size()
                && psm_info->address() == request->manager_address()
                && ctx->segment->is_active()) {
            set_rpc_status(status, pspb::Status::SUCCESS, "segment:%s/%u exists",
                    request->cluster_id().c_str(), request->segment_id());
        } else {
            set_rpc_status(status, pspb::Status::EXISTS,
                    "segment:%s/%u exists and mismatch request size:%lu or manager_address:%s",
                    request->cluster_id().c_str(), request->segment_id(), ctx->segment->segment_size(),
                    request->manager_address().c_str());
        }
        return;
    }

    if (request->has_rebalance_from()) {
        base::EndPoint tmp;
        if (base::str2endpoint(request->rebalance_from().c_str(), &tmp) != 0) {
            set_rpc_status(status, pspb::Status::INVALID,
                    "segment:%s/%u rebalance from:%s is not an endpoint type",
                    request->cluster_id().c_str(), request->segment_id(),
                    request->rebalance_from().c_str());
            return;
        }
        if (tmp == _myself) {
            set_rpc_status(status, pspb::Status::INVALID,
                    "segment:%s/%u rebalance from:%s is myself",
                    request->cluster_id().c_str(), request->segment_id(),
                    request->rebalance_from().c_str());
            return;
        }
    }

    PsmInfoPtr psm_info = _segment_manager->GetOrCreatePsmInfo(request->manager_address());
    auto* rpc_ctx = CreateGetPageServerRpcCtx(psm_info, request->cluster_id(), request->segment_id());
    if (!rpc_ctx) {
        set_rpc_status(status, pspb::Status::INVALID,
                "segment:%s/%u parse manager address:%s failed",
                request->cluster_id().c_str(), request->segment_id(),
                request->manager_address().c_str());
        return;
    }
    rpc_ctx->log_id = ctx->log_id;
    ctx->psm_info = psm_info;
    auto closure = brpc::NewCallback(this, &Control::OnCreateSegmentRPC, ctx_guard.release(), rpc_ctx);
    _client->GetSegmentInfo(rpc_ctx, closure);
}

void Control::OnCreateSegmentRPC(Context* ctx, RpcGetPageServerCtx* rpc_ctx) {
    ctx->rpc_ctx = rpc_ctx;
    ctx->retry_times = 0;
    ctx->action = Action::kOnCreateSegment;
    Schedule(ctx);
}

void Control::OnCreateSegment(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    ctx->action = Action::kCreateSegment;
    auto* rpc_ctx = ctx->get_rpc_ctx<RpcGetPageServerCtx*>();
    std::unique_ptr<RpcGetPageServerCtx> rpc_ctx_guard(rpc_ctx);
    const auto* request = reinterpret_cast<const pspb::CreateSegmentRequest*>(ctx->request);
    auto* status = reinterpret_cast<pspb::CreateSegmentResponse*>(ctx->response)->mutable_status();
    if (_stopped) {
        set_rpc_status(status, pspb::Status::ERROR, "server is stopped");
        return;
    }

    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        if (not_exists) {
            set_rpc_status(status, pspb::Status::NOT_EXISTS,
                    "segment:%s/%u metadata not found in manager",
                    request->cluster_id().c_str(), request->segment_id());
            return;
        }
        if (!rpc_ctx->RetryNext()) {
            ctx->psm_info->SetFailed();
            set_rpc_status(status, pspb::Status::ERROR,
                    "segment:%s/%u create failed, cant get metadata",
                    request->cluster_id().c_str(), request->segment_id());
        } else {
            auto closure = brpc::NewCallback(this, &Control::OnCreateSegmentRPC,
                    ctx_guard.release(), rpc_ctx_guard.release());
            _client->GetSegmentInfo(rpc_ctx, closure);
        }
        return;
    }

    ctx->psm_info->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());
    const gaiapb::PageServerInfo& info = rpc_ctx->response.page_server();
    if (!check_segment_meta_size(info, request->size())) {
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u mismatch size, meta:%lu expect:%lu",
                request->cluster_id().c_str(), request->segment_id(),
                extent_num_to_size(info.max_extent_num()), request->size());
        return;
    }

    if (!check_segment_meta_id(info, request->segment_id())) {
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u mismatch id, meta:%u expect:%u",
                request->cluster_id().c_str(), request->segment_id(),
                info.segment_id(), request->segment_id());
        return;
    }

    int32_t store_id = request->has_store_id() ? request->store_id() : -1;
    StorePtr store = PickStore(ctx->log_id, request->cluster_id(), request->size(), store_id);
    if (!store) {
        PSVR_LOG_CTX(WARNING, ctx) << "create segment failed, pick store failed";
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u pick store:%d failed",
                request->cluster_id().c_str(), request->segment_id(), store_id);
        return;
    }

    if (FLAGS_multi_psvr_store_reserve_size > 0
            && store->physical_free_size() < FLAGS_multi_psvr_store_reserve_size) {
        PSVR_LOG_CTX(WARNING, ctx) << "create segment failed, store reserve physical size small";
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u store:%u reserve physical size small, free:%ld reserve:%ld",
                request->cluster_id().c_str(), request->segment_id(), store->id(),
                store->physical_free_size(), FLAGS_multi_psvr_store_reserve_size);
        return;
    }

    std::string db_path = store->GetSegmentDBPath(request->cluster_id(), request->segment_id());
    ctx->segment.reset(new Segment(weak_this(),
                request->cluster_id(),
                request->segment_id(),
                info.replica_id(),
                info.has_version() ? info.version() : Segment::kUnknownVersion,
                request->size(),
                store->enable_punch_hole(),
                Segment::Status::kCreating,
                db_path,
                store->id(),
                _segment_manager->GetOrCreateCluster(request->cluster_id())));
    ctx->segment->InitPsmInfo(ctx->psm_info);
    if (request->has_rebalance_from()) {
        ctx->segment->SetRebalanceNode(request->rebalance_from(), request->rebalance_version());
    }

    if (!store->IncStatistic(ctx->segment)) {
        PSVR_LOG_CTX(WARNING, ctx) << ctx->segment << " add failed, store:[" << store << "] is full";
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u store:%u fail to add segment",
                request->cluster_id().c_str(), request->segment_id(), store->id());
        return;
    }

    if (!_segment_manager->AddSegment(ctx->segment)) {
        store->DecStatistic(ctx->segment);
        PSVR_LOG_CTX(WARNING, ctx) << ctx->segment << " add failed";
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u add to manager failed",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    // only init config except lsn
    ctx->segment->InitConfig(info, true);
    if (!ctx->segment->CreateEngine(store->trash_path())) {
        store->DecStatistic(ctx->segment);
        _segment_manager->DropSegment(ctx->segment);
        PSVR_LOG_CTX(WARNING, ctx) << ctx->segment << " create engine failed";
        set_rpc_status(status, pspb::Status::ERROR,
                "segment:%s/%u open engine failed",
                request->cluster_id().c_str(), request->segment_id());
        return;
    }

    PSVR_LOG_CTX(NOTICE, ctx) << ctx->segment << " add ok,"
        << " cost:[" << (base::cpuwide_time_us() - ctx->segment->start_time()) << "]";
    set_rpc_status(status, pspb::Status::SUCCESS, "ok");
    set_segment_cluster_statistic(ctx->segment, stat_psm_req_lat, rpc_ctx->latency_us);

    if (!rpc_ctx->response.has_is_enabled()
            || rpc_ctx->response.is_enabled()) {
        ctx->segment->InitLsn(info);
        StartWorking(ctx->segment TRACE_FILE_LINE_CC);
    } else {
        PSVR_LOG_CTX(TRACE, ctx) << ctx->segment << " is not enabled, wait to start working";
        auto* ac_ctx = new Context(Action::kAsyncCreateSegment, ctx->segment);
        ac_ctx->log_id = ctx->log_id;
        ac_ctx->timer.reset(ctx->timer.start_time());
        SetCtxClientId(ac_ctx);
        Schedule(ac_ctx, FLAGS_psvr_retry_delay_us_when_segment_not_enabled);
    }
}

// if rpc response fails, retry it.
// the enable status must be true for segment to start working
void Control::AsyncCreateSegment(Context* ctx) {
    if (_stopped || !_segment_manager->ExistSegment(ctx->segment)) {
        std::unique_ptr<Context> ctx_guard(ctx);
        if (!_stopped) {
            ctx->segment->set_init_error();
            PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " not found, deleted?";
        }
        return;
    }

    auto* rpc_ctx = CreateGetPageServerRpcCtx(ctx->segment->GetPsmInfo(),
            ctx->segment->cluster_id(), ctx->segment->segment_id());
    if (!rpc_ctx) {
        Schedule(ctx, FLAGS_psvr_retry_delay_us_when_segment_not_enabled);
        return;
    }
    rpc_ctx->log_id = ctx->log_id;
    auto closure = brpc::NewCallback(this, &Control::OnAsyncCreateSegmentRPC, ctx, rpc_ctx);
    _client->GetSegmentInfo(rpc_ctx, closure);
}

void Control::OnAsyncCreateSegmentRPC(Context* ctx, RpcGetPageServerCtx* rpc_ctx) {
    ctx->rpc_ctx = rpc_ctx;
    ctx->retry_times = 0;
    ctx->action = Action::kOnAsyncCreateSegment;
    Schedule(ctx);
}

void Control::OnAsyncCreateSegment(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    ctx->action = Action::kAsyncCreateSegment;
    auto* rpc_ctx = ctx->get_rpc_ctx<RpcGetPageServerCtx*>();
    std::unique_ptr<RpcGetPageServerCtx> rpc_ctx_guard(rpc_ctx);
    if (_stopped || !_segment_manager->ExistSegment(ctx->segment)) {
        if (!_stopped) {
            PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " not found, deleted?";
            ctx->segment->set_init_error();
        }
        return;
    }

    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        if (not_exists) {
            ctx->segment->set_init_error();
            PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " not exists in manager";
            return;
        }
        if (!rpc_ctx->RetryNext()) {
            ctx->segment->GetPsmInfo()->SetFailed();
            Schedule(ctx_guard.release(), FLAGS_psvr_retry_delay_us_when_segment_not_enabled);
        } else {
            auto closure = brpc::NewCallback(this, &Control::OnAsyncCreateSegmentRPC,
                    ctx_guard.release(), rpc_ctx_guard.release());
            _client->GetSegmentInfo(rpc_ctx, closure);
        }
        return;
    }

    ctx->segment->GetPsmInfo()->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->servers[rpc_ctx->idx]);
    if (rpc_ctx->response.has_is_enabled() && !rpc_ctx->response.is_enabled()) {
        Schedule(ctx_guard.release(), FLAGS_psvr_retry_delay_us_when_segment_not_enabled);
        return;
    }

    const gaiapb::PageServerInfo& info = rpc_ctx->response.page_server();
    if (!check_segment_meta(info, ctx->segment->segment_size(),
                ctx->segment->segment_id(), ctx->segment->replica_id())) {
        ctx->segment->set_init_error();
        return;
    }

    if (!_segment_manager->ExistSegment(ctx->segment)) {
        ctx->segment->set_init_error();
        PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " not found, deleted?";
        return;
    }
    // init lsn
    ctx->segment->InitLsn(info);
    StartWorking(ctx->segment TRACE_FILE_LINE_CC);

    set_segment_cluster_statistic(ctx->segment, stat_psm_req_lat, rpc_ctx->latency_us);
    PSVR_LOG_CTX(NOTICE, ctx) << ctx->segment << " start working";
}

// start server, will async load all store segments
void Control::LoadSegmentMeta(Context* ctx) {
    if (_stopped || !_segment_manager->ExistSegment(ctx->segment)) {
        std::unique_ptr<Context> ctx_guard(ctx);
        if (!_stopped) {
            ctx->segment->set_init_error();
            PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " not found, deleted?";
        }
        return;
    }

    auto* rpc_ctx = CreateGetPageServerRpcCtx(ctx->segment->GetPsmInfo(),
            ctx->segment->cluster_id(), ctx->segment->segment_id());
    if (!rpc_ctx) {
        Schedule(ctx, get_delay_us(ctx->retry_times, 10000, 1000000), true);
        return;
    }

    const auto cost_time = base::cpuwide_time_us() - ctx->segment->start_time();
    PSVR_LOG_IF_CTX(NOTICE, cost_time >= 50000, ctx) << ctx->segment << " to get meta info,"
        << " retry_times:[" << ctx->retry_times
        << "] cost:[" << cost_time
        << "]";
    auto closure = brpc::NewCallback(this, &Control::OnLoadSegmentMetaRPC, ctx, rpc_ctx);
    _client->GetSegmentInfo(rpc_ctx, closure);
}

void Control::OnLoadSegmentMetaRPC(Context* ctx, RpcGetPageServerCtx* rpc_ctx) {
    ctx->rpc_ctx = rpc_ctx;
    ctx->retry_times = 0;
    ctx->action = Action::kOnLoadSegmentMeta;
    Schedule(ctx);
}

void Control::OnLoadSegmentMeta(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    ctx->action = Action::kLoadSegmentMeta;
    auto* rpc_ctx = ctx->get_rpc_ctx<RpcGetPageServerCtx*>();
    std::unique_ptr<RpcGetPageServerCtx> rpc_ctx_guard(rpc_ctx);
    if (_stopped || !_segment_manager->ExistSegment(ctx->segment)) {
        if (!_stopped) {
            ctx->segment->set_init_error();
            PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " not found, deleted?";
        }
        return;
    }
    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        if (not_exists) {
            ctx->segment->set_init_error();
            PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " not exists in manager";
            if (FLAGS_multi_psvr_enable_remove_garbage_segment) {
                RemoveGarbageSegment(ctx->segment->cluster_id(),
                        ctx->segment->segment_id(), ctx->segment->version());
            }
            return;
        }
        if (!rpc_ctx->RetryNext()) {
            ctx->segment->GetPsmInfo()->SetFailed();
            Schedule(ctx_guard.release(), get_delay_us(ctx->retry_times), true);
        } else {
            auto closure = brpc::NewCallback(this, &Control::OnLoadSegmentMetaRPC,
                    ctx_guard.release(), rpc_ctx_guard.release());
            _client->GetSegmentInfo(rpc_ctx, closure);
        }
        return;
    }

    ctx->segment->GetPsmInfo()->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->servers[rpc_ctx->idx]);
    const gaiapb::PageServerInfo& info = rpc_ctx->response.page_server();
    if (!check_segment_meta(info, ctx->segment->segment_size(),
                ctx->segment->segment_id(), ctx->segment->replica_id())
            || !check_segment_meta_replica_version(info, ctx->segment->version())) {
        ctx->segment->set_init_error();
        return;
    }

    if (!_segment_manager->ExistSegment(ctx->segment)) {
        ctx->segment->set_init_error();
        PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " not found, deleted?";
        return;
    }

    if (rpc_ctx->response.has_is_enabled() && !rpc_ctx->response.is_enabled()) {
        Schedule(ctx_guard.release(), FLAGS_psvr_retry_delay_us_when_segment_not_enabled, false);
        return;
    }

    ClusterPtr cluster = _segment_manager->GetCluster(ctx->segment->cluster_id());
    if (rpc_ctx->response.has_encryption_info() && cluster.get() != nullptr) {
        const gaiapb::EncryptionInfo &encryption_info_pb = rpc_ctx->response.encryption_info();
        PSVR_LOG_CTX(TRACE, ctx) << ctx->segment << "] encryption_key:["
                                 << encryption_info_pb.encryption_key() << "] encryption_iv:["
                                 << encryption_info_pb.encryption_iv() << "] encryption_alg:["
                                 << encryption_info_pb.encryption_alg() << "]";
        EncryptHelperPtr encrypt_helper = cluster->encrypt_helper();
        bool res = encrypt_helper->InitCipherStream(encryption_info_pb);
        if (!res) {
            PSVR_LOG_CTX(ERROR, ctx) << ctx->segment
                    << " init cipher stream failed for cluster:[" << ctx->segment->cluster_id()
                    << "] encryption_key:[" << encryption_info_pb.encryption_key()
                    << "] encryption_iv:[" << encryption_info_pb.encryption_iv()
                    << "] encryption_alg:[" << encryption_info_pb.encryption_alg() << "]";
            ctx->segment->set_init_error();
            return;
        }
        cluster->set_enable_encypt();
    }

    const auto prepare_cost = base::cpuwide_time_us() - ctx->segment->start_time();

    ctx->segment->InitConfig(info, false);
    bool ret = ctx->segment->OpenEngine(Segment::DB_OPEN_EXISTS);
    if (!ret) {
        ctx->segment->set_init_error();
        PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " open engine failed";
        return;
    }

    const auto db_cost = base::cpuwide_time_us() - ctx->segment->start_time() - prepare_cost;
    LOG_IF(WARNING, db_cost >= 100000) << ctx->segment
        << " load slow, db_cost:[" << db_cost
        << "]";

    ctx->segment->InitLsn(info);
    ctx->segment->UpdateMetaVersionIf();
    StartWorking(ctx->segment TRACE_FILE_LINE_CC);
    set_segment_cluster_statistic(ctx->segment, stat_psm_req_lat, rpc_ctx->latency_us);
    PSVR_LOG_CTX(NOTICE, ctx) << ctx->segment << " start ok,"
        << " prepare_cost:[" << prepare_cost
        << "] db_cost:[" << db_cost
        << "] retry_times:[" << ctx->retry_times
        << "] rpc_cost:[" << rpc_ctx->latency_us
        << "] cost:[" << (base::cpuwide_time_us() - ctx->segment->start_time()) << "]";

    const auto succ_num = _load_stat->succ_num.fetch_add(1, std::memory_order_relaxed) + 1;
    if (succ_num >= _load_stat->load_num.load(std::memory_order_acquire)) {
        LOG(NOTICE) << "maybe all segments running."
            << " load_num:[" << _load_stat->load_num.load(std::memory_order_relaxed)
            << "] succ_num:[" << succ_num
            << "] cost_time:[" << (base::cpuwide_time_us() - _load_stat->start_time)
            << "]";
    }
}

// mark segment meta to deleted, and make async task to move db files.
void Control::DropSegment(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    const auto* request = reinterpret_cast<const pspb::DropSegmentRequest*>(ctx->request);
    auto* response = reinterpret_cast<pspb::DropSegmentResponse*>(ctx->response);
    auto* status = response->mutable_status();
    // drop one segment
    if (request->has_segment_id()) {
        ctx->segment = _segment_manager->GetSegment(request->cluster_id(), request->segment_id());
        if (!ctx->segment) {
            set_rpc_status(status, pspb::Status::NOT_EXISTS, "segment:%s/%u not found",
                    request->cluster_id().c_str(), request->segment_id());
            return;
        }

        if (request->has_version() && request->version() != ctx->segment->version()) {
            set_rpc_status(status, pspb::Status::INVALID,
                    "segment:%s/%u version mismatch, expect:%lu actual:%lu",
                    request->cluster_id().c_str(), request->segment_id(),
                    request->version(), ctx->segment->version());
            return;
        }

        if (ctx->segment->is_delete()) {
            set_rpc_status(status, pspb::Status::SUCCESS, "segment in deleting");
            return;
        }

        if (!ctx->segment->Delete()) {
            set_rpc_status(status, pspb::Status::ERROR,
                    "segment:%s/%u delete meta failed",
                    request->cluster_id().c_str(), request->segment_id());
            return;
        }

        auto* delete_ctx = new Context(Action::kDeleteSegment, ctx->segment);
        delete_ctx->log_id = ctx->log_id;
        delete_ctx->timer.reset(ctx->timer.start_time());
        SetCtxClientId(delete_ctx);
        Schedule(delete_ctx);

        PSVR_LOG_CTX(NOTICE, ctx) << ctx->segment << " drop it";
        set_rpc_status(status, pspb::Status::SUCCESS, "segment in deleting");
    } else {
        // drop cluster all segments
        uint32_t err_nr = 0;
        uint32_t nr = 0;
        std::vector<SegmentPtr> segments;
        _segment_manager->GetClusterSegments(request->cluster_id(), &segments);
        for (auto& segment : segments) {
            if (segment->is_delete()) {
                continue;
            }

            if (!segment->Delete()) {
                ++err_nr;
                break;
            }

            auto* delete_ctx = new Context(Action::kDeleteSegment, segment);
            delete_ctx->log_id = ctx->log_id;
            delete_ctx->timer.reset(ctx->timer.start_time());
            SetCtxClientId(delete_ctx);
            Schedule(delete_ctx);

            ++nr;
            PSVR_LOG_CTX(NOTICE, ctx) << segment << " drop it";
        };

        if (err_nr) {
            set_rpc_status(status, pspb::Status::ERROR,
                    "cluster:%s drop error, err:%u succ:%u",
                    request->cluster_id().c_str(), err_nr, nr);
        } else {
            set_rpc_status(status, pspb::Status::SUCCESS, "cluster segments in deleting");
        }
        response->set_drop_count(nr);
    }
}

// move deleted segment db files to trash dir.
void Control::DeleteSegment(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    if (!ctx->segment->is_delete()) {
        PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " status is not delete,"
            << " status:[" << ctx->segment->status2str() << "]";
        return;
    }
    if (!_segment_manager->ExistSegment(ctx->segment)) {
        PSVR_LOG_CTX(ERROR, ctx) << ctx->segment << " not found,"
            << " status:[" << ctx->segment->status2str() << "]";
        return;
    }
    StorePtr store = _store_manager->GetStore(ctx->segment->store_id());
    if (store) {
        if (!store->DeleteSegmentPath(ctx->segment->db_path(),
                    ctx->segment->cluster_id(), ctx->segment->segment_id())) {
            PSVR_LOG_CTX(ERROR, ctx) << store << " remove " << ctx->segment << " failed";
            Schedule(ctx_guard.release(), get_delay_us(ctx->retry_times), true);
            return;
        }
        store->DecStatistic(ctx->segment);
    }
    bool ret = _segment_manager->DropSegment(ctx->segment);
    PSVR_LOG_CTX(NOTICE, ctx) << ctx->segment << " drop in manager,"
        << " use_count:[" << ctx->segment.use_count()
        << "] ptr:[" << PTR_P(ctx->segment.get())
        << "] ret:[" << ret
        << "]";
}

// mark store status to disalbe.
// and drop all segments in the store.
void Control::DisableStore(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    const auto* request = reinterpret_cast<const pspb::DisableStoreRequest*>(ctx->request);
    auto* response = reinterpret_cast<pspb::DisableStoreResponse*>(ctx->response);
    auto* status = response->mutable_status();

    StorePtr store = _store_manager->GetStore(request->store_id());
    if (!store) {
        set_rpc_status(status, pspb::Status::NOT_EXISTS, "not found store");
        return;
    }
    if (store->path() != request->store_path()) {
        set_rpc_status(status, pspb::Status::INVALID, "store path mismatch");
        return;
    }

    if (store->Disable()) {
        // if succ, the store is disable at the first time
        bool rc = _store_manager->StoreConfigFile();
        if (!rc) {
            store->Enable();
            set_rpc_status(status, pspb::Status::ERROR, "update store config file failed");
            return;
        }
    }

    set_rpc_status(status, pspb::Status::SUCCESS, "disable store ok");
    // to clean store segments
    SegmentIteratorFn fn = [this, store] (SegmentPtr seg) {
        store->DecStatistic(seg);
        seg->Stop();
    };
    uint32_t n = _segment_manager->DropStoreSegments(store->id(), fn);
    response->set_drop_count(n);

    PSVR_LOG_CTX(NOTICE, ctx) << "disable " << store;
}

// update store capacity or size
void Control::UpdateStore(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    const auto* request = reinterpret_cast<const pspb::UpdateStoreRequest*>(ctx->request);
    auto* response = reinterpret_cast<pspb::UpdateStoreResponse*>(ctx->response);
    auto* status = response->mutable_status();

    StorePtr store = _store_manager->GetStore(request->store_id());
    if (!store) {
        set_rpc_status(status, pspb::Status::NOT_EXISTS, "not found store");
        return;
    }
    if (store->path() != request->store_path()) {
        set_rpc_status(status, pspb::Status::INVALID, "store path mismatch");
        return;
    }

    if (!store->IsActive()) {
        set_rpc_status(status, pspb::Status::ERROR, "store inactive");
        return;
    }

    if (request->has_clear_io_error()
            && request->clear_io_error()) {
        store->ClearIOError();
    }

    uint32_t n = 0;     // bit
    int64_t original_capacity = -1;
    if (request->has_store_capacity()) {
        original_capacity = store->UpdateCapacity(request->store_capacity());
        n |= 1u;
    }

    int64_t original_size  = -1;
    if (request->has_store_size()) {
        original_size = store->UpdateSize(request->store_size());
        n |= 2u;
    }
    LOG(TRACE) << store << " original info,"
        << " capacity:[" << original_capacity
        << "] size:[" << original_size
        << "] new_capacity:[" << request->store_capacity()
        << "] new_size:[" << request->store_size()
        << "] flags:[" << n
        << "]";
    if (n) {
        bool rc = _store_manager->StoreConfigFile();
        if (!rc) {
            // rollback
            if (n & 1u) {
                store->UpdateCapacity(original_capacity);
            }
            if (n & 2u) {
                store->UpdateSize(original_size);
            }
            set_rpc_status(status, pspb::Status::ERROR, "update store config file failed");
            return;
        }
    }

    set_rpc_status(status, pspb::Status::SUCCESS, "update store ok");
}

// update all stores capacity or size
void Control::UpdateAllStore(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    const auto* request = reinterpret_cast<const pspb::UpdateAllStoreRequest*>(ctx->request);
    auto* response = reinterpret_cast<pspb::UpdateAllStoreResponse*>(ctx->response);
    auto* status = response->mutable_status();

    std::vector<StorePtr> stores;
    _store_manager->GetStores(&stores);

    bool changed = false;
    std::map<int32_t, uint32_t> stores_flags;
    std::map<int32_t, int64_t> stores_original_capacity;
    std::map<int32_t, int64_t> stores_original_size;

    bool clear_io_error = request->has_clear_io_error() && request->clear_io_error();

    for (auto& store : stores) {
        const int32_t id = store->id();
        auto store_pb = response->add_stores();
        store_pb->set_id(id);
        store_pb->set_path(store->path());
        if (!store->IsActive()) {
            store_pb->set_active(false);
            continue;
        }

        if (clear_io_error) {
            store->ClearIOError();
        }

        store_pb->set_active(true);

        stores_flags[id] = 0;
        stores_original_capacity[id] = -1;
        stores_original_size[id] = -1;

        if (request->has_store_capacity()) {
            stores_original_capacity[id] = store->UpdateCapacity(request->store_capacity());
            stores_flags[id] |= 1u;
            store_pb->set_original_capacity(stores_original_capacity[id]);
        }
        if (request->has_store_size()) {
            stores_original_size[id] = store->UpdateSize(request->store_size());
            stores_flags[id] |= 2u;
            store_pb->set_original_size(stores_original_size[id]);
        }

        if (!changed) {
            changed = stores_flags[id] > 0;
        }
        LOG(NOTICE) << store << " original info,"
            << " capacity:[" << stores_original_capacity[id]
            << "] size:[" << stores_original_size[id]
            << "] new_capacity:[" << request->store_capacity()
            << "] new_size:[" << request->store_size()
            << "] flags:[" << stores_flags[id]
            << "]";
    }

    if (changed) {
        bool rc = _store_manager->StoreConfigFile();
        if (!rc) {
            // rollback
            for (auto& store : stores) {
                const int32_t id = store->id();
                if (auto it = stores_flags.find(id); it != stores_flags.end()) {
                    const auto flag = it->second;
                    if (flag & 1u) {
                        store->UpdateCapacity(stores_original_capacity[id]);
                    }
                    if (flag & 2u) {
                        store->UpdateSize(stores_original_size[id]);
                    }
                }
            }
            response->mutable_stores()->Clear();
            set_rpc_status(status, pspb::Status::ERROR, "update store config file failed");
            return;
        }
    }

    set_rpc_status(status, pspb::Status::SUCCESS, "update store ok");
}

void Control::ModifySegmentManagerInfo(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    const auto* request = reinterpret_cast<const pspb::ModifyManagerRequest*>(ctx->request);
    auto* response = reinterpret_cast<pspb::ModifyManagerResponse*>(ctx->response);
    auto* status = response->mutable_status();

    PsmInfoPtr psm_info = _segment_manager->GetOrCreatePsmInfo(request->manager_address());
    if (!psm_info->RefreshNodes()) {
        set_rpc_status(status, pspb::Status::ERROR, "parse address failed");
        return;
    }

    if (ctx->segment->ResetPsmInfo(psm_info)) {
        set_rpc_status(status, pspb::Status::SUCCESS, "ok");
    } else {
        set_rpc_status(status, pspb::Status::ERROR, "update failed");
    }
}

void Control::MultiModifySegmentManagerInfo(Context* ctx) {
    const auto* request = reinterpret_cast<const pspb::MultiModifyManagerRequest*>(ctx->request);
    auto* response = reinterpret_cast<pspb::MultiModifyManagerResponse*>(ctx->response);

    if (ctx->idx >= ctx->count) {
        std::unique_ptr<Context> ctx_guard(ctx);
        set_rpc_status(response->mutable_status(), pspb::Status::SUCCESS, "ok");
        LOG(TRACE) << "update all segments manager address done";
        return;
    }

    const pspb::MultiModifyManagerRequest::Segment& req = request->segments(ctx->idx);
    auto* rsp = response->add_segments();
    auto* rsp_status = rsp->mutable_status();

    rsp->set_cluster_id(req.cluster_id());
    if (req.has_segment_id()) {
        rsp->set_segment_id(req.segment_id());
    }

    PsmInfoPtr psm_info = _segment_manager->GetOrCreatePsmInfo(req.manager_address());
    if (!psm_info->RefreshNodes()) {
        set_rpc_status(rsp_status, pspb::Status::ERROR, "parse or get manager addr failed");
    } else {
        if (req.has_segment_id()) {
            SegmentPtr segment = _segment_manager->GetSegment(req.cluster_id(), req.segment_id());
            if (!segment) {
                set_rpc_status(rsp_status, pspb::Status::NOT_EXISTS, "not found segment");
            } else {
                if (segment->ResetPsmInfo(psm_info)) {
                    set_rpc_status(rsp->mutable_status(), pspb::Status::SUCCESS, "ok");
                } else {
                    set_rpc_status(rsp->mutable_status(), pspb::Status::ERROR, "update failed");
                }
            }
        } else {    // update cluster all segments
            uint32_t failed_n = 0;
            SegmentIteratorFn fn = [this, psm_info, &failed_n](SegmentPtr seg) {
                if (!seg->ResetPsmInfo(psm_info)) {
                    ++failed_n;
                }
            };
            uint32_t n = _segment_manager->GetClusterSegments(req.cluster_id(), fn);
            if (n == 0) {
                set_rpc_status(rsp->mutable_status(), pspb::Status::NOT_EXISTS,
                        "not found cluster segments");
            } else if (failed_n > 0) {
                set_rpc_status(rsp->mutable_status(), pspb::Status::ERROR, "update failed");
            } else {
                set_rpc_status(rsp->mutable_status(), pspb::Status::SUCCESS,
                        "update cluster segments succ");
            }
        }
    }
    ++ctx->idx;
    Schedule(ctx);
}

void Control::RefreshPsmInfoNodes(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    if (!ctx->psm_info->RefreshNodes()) {
        PSVR_LOG_CTX(WARNING, ctx) << ctx->psm_info << " get manager address list failed";
#define MAX_REFRESH_SEGMENT_MANAGER_INFO_RETRY_TIMES 3
        if (_stopped || ctx->retry_times >= MAX_REFRESH_SEGMENT_MANAGER_INFO_RETRY_TIMES) {
            ctx->psm_info->ReleaseRefreshLock();
            return;
        }
        Schedule(ctx_guard.release(), get_delay_us(ctx->retry_times), true);
        return;
    }
    ctx->psm_info->ReleaseRefreshLock();
}

void Control::Heartbeat(Context* ctx) {
    AutoStatLat stat_lat(_stat_heartbeat_task_lat);
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        PSVR_LOG_CTX(NOTICE, ctx) << " heartheat failed, server stopped";
        return;
    }

    const uint64_t delay_us = get_heartbeat_interval_us();
    std::shared_lock lm(_mutex);
    if (!_one_segment) {
        Schedule(ctx, delay_us);
        return;
    }

    PsmInfoPtr psm_info = _one_segment->GetPsmInfo();
    std::vector<base::EndPoint> nodes;
    if (!psm_info->GetOrRefreshNodes(&nodes)) {
        PSVR_LOG_CTX(WARNING, ctx) << "fail to get manager nodes";
        Schedule(ctx, delay_us);
        return;
    }

    auto* rpc_ctx = new RpcPageServerHeartbeatCtx;
    rpc_ctx->servers = std::move(nodes);
    rpc_ctx->request.set_addr(gaiadb::common::endpoint2str(myself()));
    rpc_ctx->request.set_checkpoint_lsn(_one_segment->append_lsn());
    rpc_ctx->request.set_apply_lsn(_one_segment->parse_lsn());
    rpc_ctx->request.set_fetch_lsn(_one_segment->fetch_lsn());
    rpc_ctx->request.set_cluster_id(_one_segment->cluster_id());
    rpc_ctx->request.set_server_zone(FLAGS_psvr_topology_zone);

    auto closure = brpc::NewCallback(this, &Control::OnHeartbeat, ctx, rpc_ctx);
    _client->Heartbeat(rpc_ctx, closure);
}

void Control::OnHeartbeat(Context* ctx, RpcPageServerHeartbeatCtx* rpc_ctx) {
    std::unique_ptr<RpcPageServerHeartbeatCtx> rpc_ctx_guard(rpc_ctx);
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        PSVR_LOG_CTX(NOTICE, ctx) << " heartheat failed, server stopped";
        return;
    }

    const uint64_t delay_us = get_heartbeat_interval_us();
    if (!rpc_ctx->status.IsOk()
            || rpc_ctx->response.status().code() != gaiadb::GIE_OK) {
        PSVR_LOG_CTX(WARNING, ctx) << _one_segment << " heartbeat failed, " << rpc_ctx->status
            << " " << rpc_ctx->response.status() << " " << rpc_ctx->current_server();
        if (rpc_ctx->status.IsOk()
                && rpc_ctx->response.status().code() == gaiadb::GIE_NOT_EXIST) {
            PSVR_LOG_CTX(ERROR, ctx) << _one_segment << " not found myself on manager. exit!";
            psvr_terminate();
            return;
        }
        try_update_leader(rpc_ctx, gaiadb::GIE_REDIRECT);
        ++rpc_ctx->idx;
        if (!rpc_ctx->Retryable()) {
            _one_segment->GetPsmInfo()->RefreshNodes();
            PSVR_LOG_CTX(ERROR, ctx) << _one_segment << " heartbeat failed";
            Schedule(ctx, delay_us);
        } else {
            auto closure = brpc::NewCallback(this, &Control::OnHeartbeat, ctx, rpc_ctx_guard.release());
            _client->Heartbeat(rpc_ctx, closure);
        }
        return;
    }

    _one_segment->GetPsmInfo()->SetNodesFromHeartbeat(rpc_ctx->current_server(), rpc_ctx->response.peer_list());
    _one_segment->GetPsmInfo()->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());

    if (rpc_ctx->response.has_seg_lowest_gc_lsn()) {
        _one_segment->set_seg_lowest_gc_lsn(rpc_ctx->response.seg_lowest_gc_lsn());
    } else {
        _one_segment->set_seg_lowest_gc_lsn(rpc_ctx->response.ps_lowest_lsn());
    }

    if (rpc_ctx->response.has_cn_lowest_lsn()) {
        _one_segment->SetClusterCnLowestLsn(rpc_ctx->response.cn_lowest_lsn());
    }
    if (rpc_ctx->response.has_ps_lowest_lsn()) {
        _one_segment->SetClusterPsLowestLsn(rpc_ctx->response.ps_lowest_lsn());
    }
    if (rpc_ctx->response.has_cn_lowest_gc_lsn()) {
        _one_segment->SetClusterCnLowestGcLsn(rpc_ctx->response.cn_lowest_gc_lsn());
    }
    if (rpc_ctx->response.has_ps_lowest_gc_lsn()) {
        _one_segment->SetClusterPsLowestGcLsn(rpc_ctx->response.ps_lowest_gc_lsn());
    }
    if (rpc_ctx->response.has_enable_encrypt() && rpc_ctx->response.enable_encrypt()) {
        ClusterPtr cluster = _one_segment->cluster();
        if (cluster.get() != nullptr && !cluster->enable_encrypt()) {
            cluster->set_enable_encypt();
        }
    }

    _stat_heartbeat_rpc_lat << rpc_ctx->latency_us;
    PSVR_LOG_CTX(TRACE, ctx) << _one_segment << " heartbeat ok";
    Schedule(ctx, delay_us);
}

void Control::BatchHeartbeat(Context* ctx) {
    AutoStatLat stat_lat(_stat_heartbeat_task_lat);
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        PSVR_LOG_CTX(NOTICE, ctx) << "heartheat failed, server stopped";
        return;
    }

    const uint64_t delay_us = get_heartbeat_interval_us();
    std::vector<SegmentPtr> segments;
    _segment_manager->GetAllSegments(&segments);
    if (segments.empty()) {
        PSVR_LOG_CTX(NOTICE, ctx) << "not found any clusters on heartbeat task";
        Schedule(ctx, delay_us);
        return;
    }

    size_t inactive_num = 0;
    auto epoch = _heartheat_epoch.fetch_add(1);
    std::map<PsmInfoPtr, std::shared_ptr<BatchHeartbeatTask>> batch_rpc_ctx;
    for (auto segment : segments) {
        if (!segment->is_active() || !segment->is_init_db()) {
            ++inactive_num;
            continue;
        }
        PsmInfoPtr psm_info = segment->GetPsmInfo();
        std::shared_ptr<BatchHeartbeatTask> heartbeat_ctx = nullptr;
        auto it = batch_rpc_ctx.find(psm_info);
        if (it == batch_rpc_ctx.end()) {
            auto insert_it = batch_rpc_ctx.emplace(psm_info,
                    std::make_shared<BatchHeartbeatTask>(segment->cluster(), epoch));
            heartbeat_ctx = insert_it.first->second;
        } else {
            heartbeat_ctx = it->second;
        }

        auto rpc_ctx = heartbeat_ctx->Add(segment);
        if (rpc_ctx->servers.empty()) {
            std::vector<base::EndPoint> nodes;
            if (psm_info->GetOrRefreshNodes(&nodes)) {
                rpc_ctx->servers = std::move(nodes);
            }
        }

        rpc_ctx->request.set_server_zone(FLAGS_psvr_topology_zone);
        auto* ps_pb = rpc_ctx->request.add_page_servers();
        ps_pb->set_cluster_id(segment->cluster_id());
        ps_pb->set_segment_id(segment->segment_id());
        ps_pb->set_replica_id(segment->replica_id());
        ps_pb->set_addr(_myself_str);
        ps_pb->set_checkpoint_lsn(segment->append_lsn());
        ps_pb->set_apply_lsn(segment->parse_lsn());
        ps_pb->set_fetch_lsn(segment->fetch_lsn());
        ps_pb->set_version(segment->version());
    }

    for (auto& it : batch_rpc_ctx) {
        auto& heartbeat_ctx = it.second;
        for (auto& group : heartbeat_ctx->group_list) {
            if (group->rpc_ctx.servers.empty()) {
                LOG(WARNING) << "not found psm nodes, batch heartbeat failed,"
                    << " cluster:[" << heartbeat_ctx->cluster_id
                    << "] epoch:[" << heartbeat_ctx->epoch
                    << "] size:[" << group->segment_size
                    << "] idx:[" << group->idx
                    << "] min_lsn:[" << group->min_gc_lsn
                    << "] max_lsn:[" << group->max_gc_lsn
                    << "]";
                if (heartbeat_ctx->inflight_count.fetch_sub(1) == 1) {
                    it.first->set_heartheat_epoch(heartbeat_ctx->epoch);
                }
                continue;
            }
            PSVR_LOG_CTX(TRACE, ctx) << "do batch heartbeat,"
                << " cluster:[" << heartbeat_ctx->cluster_id
                << "] epoch:[" << heartbeat_ctx->epoch
                << "] size:[" << group->segment_size
                << "] idx:[" << group->idx
                << "] min_lsn:[" << group->min_gc_lsn
                << "] max_lsn:[" << group->max_gc_lsn
                << "]";
            auto closure = brpc::NewCallback(this, &Control::OnBatchHeartbeat, it.first, it.second, group);
            _client->BatchHeartbeat(&group->rpc_ctx, closure);
        }
    }

    if (inactive_num > 0) {
        PSVR_LOG_EVERY_SECOND_CTX(NOTICE, ctx) << "heartheat fount inactive segments,"
            << " size:[" << inactive_num
            << "]";
    }

    Schedule(ctx, delay_us);
}

void Control::OnBatchHeartbeat(PsmInfoPtr psm_info,
        std::shared_ptr<BatchHeartbeatTask> heartbeat_ctx,
        std::shared_ptr<BatchHeartbeatGroup> group) {
    if (_stopped) {
        LOG(TRACE) << " heartheat failed, server stopped";
        return;
    }
    // check new heartbeat is finish
    if (psm_info->heartheat_epoch() > heartbeat_ctx->epoch) {
        LOG(NOTICE) << "ignore old heartbeat,"
            << " cluster_id:[" << heartbeat_ctx->cluster_id
            << "] epoch:[" << heartbeat_ctx->epoch
            << "] finish_epoch:[" << psm_info->heartheat_epoch()
            << "] idx:[" << group->idx
            << "]";
        return;
    }
    auto rpc_ctx = &group->rpc_ctx;
    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        if (!rpc_ctx->RetryNext()) {
            RefreshPsmInfo(psm_info);
            if (heartbeat_ctx->inflight_count.fetch_sub(1) == 1) {
                psm_info->set_heartheat_epoch(heartbeat_ctx->epoch);
            }
        } else {
            psm_info->SetFailed();
            auto closure = brpc::NewCallback(this, &Control::OnBatchHeartbeat, psm_info, heartbeat_ctx, group);
            _client->BatchHeartbeat(rpc_ctx, closure);
        }
        return;
    }

    auto cluster = heartbeat_ctx->cluster.lock();
    if (cluster && rpc_ctx->response.has_in_backup()) {
        cluster->in_backup().Update(rpc_ctx->response.in_backup());
    }

    if (heartbeat_ctx->inflight_count.fetch_sub(1) == 1) {
        psm_info->set_heartheat_epoch(heartbeat_ctx->epoch);
    }

    auto slow_segment = group->slow_segment.lock();
    std::ostringstream slow_stage_info;
    if (slow_segment) {
        slow_stage_info << slow_segment->stage_info();
    }
    LOG_IF(NOTICE, group->EnableLog()) << "batch heartheat rsp ok,"
        << " cluster_id:[" << heartbeat_ctx->cluster_id
        << "] epoch:[" << heartbeat_ctx->epoch
        << "] size:[" << group->segment_size
        << "] idx:[" << group->idx
        << "] min_lsn:[" << group->min_gc_lsn
        << "] max_lsn:[" << group->max_gc_lsn
        << "] slow_" << slow_segment
        << " " << slow_stage_info.str()
        << " epoch:[" << psm_info->heartheat_epoch()
        << "] parser_unfinished_tasks_count:[" << (slow_segment ? slow_segment->fetch_log_block_queue().Size() : 0)
        << "] gc_unfinished_tasks_count:[" << (slow_segment ? slow_segment->parse_log_block_queue().Size() : 0)
        << "]";

    _stat_heartbeat_rpc_lat << rpc_ctx->latency_us;
    uint64_t cn_lowest_lsn = 0;
    uint64_t ps_lowest_lsn = 0;
    uint64_t cn_lowest_gc_lsn = 0;
    uint64_t ps_lowest_gc_lsn = 0;
    bool enable_encrypt = false;
    for (int32_t i = 0; i < rpc_ctx->response.page_servers_size(); ++i) {
        const auto& ps_pb = rpc_ctx->response.page_servers(i);
        if (ps_pb.status().code() == gaiadb::GIE_OK) {
            SegmentPtr segment = _segment_manager->GetSegment(ps_pb.cluster_id(), ps_pb.segment_id());
            if (!segment) {
                PSVR_LOG_CTX(ERROR, rpc_ctx) << "not found segment on page server,"
                    << " cluster:[" << ps_pb.cluster_id()
                    << "] epoch:[" << heartbeat_ctx->epoch
                    << "] segment_id:[" << ps_pb.segment_id()
                    << "] replica_id:[" << ps_pb.replica_id()
                    << "]";
                continue;
            }

            if (ps_pb.has_seg_lowest_gc_lsn()) {
                segment->set_seg_lowest_gc_lsn(ps_pb.seg_lowest_gc_lsn());
            } else {
                segment->set_seg_lowest_gc_lsn(ps_pb.ps_lowest_lsn());
            }

            if (ps_pb.has_cn_lowest_lsn() && ps_pb.cn_lowest_lsn() > cn_lowest_lsn) {
                cn_lowest_lsn = ps_pb.cn_lowest_lsn();
            }
            if (ps_pb.has_ps_lowest_lsn() && ps_pb.ps_lowest_lsn() > ps_lowest_lsn) {
                ps_lowest_lsn = ps_pb.ps_lowest_lsn();
            }
            if (ps_pb.has_cn_lowest_gc_lsn() && ps_pb.cn_lowest_gc_lsn() > cn_lowest_gc_lsn) {
                cn_lowest_gc_lsn = ps_pb.cn_lowest_gc_lsn();
            }
            if (ps_pb.has_ps_lowest_gc_lsn() && ps_pb.ps_lowest_gc_lsn() > ps_lowest_gc_lsn) {
                ps_lowest_gc_lsn = ps_pb.ps_lowest_gc_lsn();
            }
        } else if (ps_pb.status().code() == gaiadb::GIE_NOT_EXIST) {
            if (FLAGS_multi_psvr_enable_remove_garbage_segment
                    && ps_pb.has_version()) {
                RemoveGarbageSegment(ps_pb.cluster_id(), ps_pb.segment_id(), ps_pb.version());
            }
            PSVR_LOG_CTX(ERROR, rpc_ctx) << "not found segment on manager,"
                << " cluster:[" << ps_pb.cluster_id()
                << "] epoch:[" << heartbeat_ctx->epoch
                << "] segment_id:[" << ps_pb.segment_id()
                << "] replica_id:[" << ps_pb.replica_id()
                << "]";
        } else {
            PSVR_LOG_CTX(WARNING, rpc_ctx) << "heartbeat failed,"
                << " cluster:[" << ps_pb.cluster_id()
                << "] epoch:[" << heartbeat_ctx->epoch
                << "] segment_id:[" << ps_pb.segment_id()
                << "] replica_id:[" << ps_pb.replica_id()
                << "] " << ps_pb.status();
        }
    }
    if (rpc_ctx->response.has_enable_encrypt()) {
        enable_encrypt = rpc_ctx->response.enable_encrypt();
    }

    if (cluster) {
        if (cluster->cn_lowest_lsn() < cn_lowest_lsn) {
            cluster->set_cn_lowest_lsn(cn_lowest_lsn);
        }
        if (cluster->ps_lowest_lsn() < ps_lowest_lsn) {
            cluster->set_ps_lowest_lsn(ps_lowest_lsn);
        }
        if (cluster->cn_lowest_gc_lsn() < cn_lowest_gc_lsn) {
            cluster->set_cn_lowest_gc_lsn(cn_lowest_gc_lsn);
        }
        if (cluster->ps_lowest_gc_lsn() < ps_lowest_gc_lsn) {
            cluster->set_ps_lowest_gc_lsn(ps_lowest_gc_lsn);
        }
        if (enable_encrypt && !cluster->enable_encrypt()) {
            cluster->set_enable_encypt();
        }
    }

    psm_info->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());
    psm_info->SetNodesFromHeartbeat(rpc_ctx->current_server(), rpc_ctx->response.peer_list());
}

void Control::RemoveGarbageSegment(const std::string& cluster_id,
        uint32_t segment_id, uint64_t version) {
    auto request = new pspb::DropSegmentRequest;
    auto response = new pspb::DropSegmentResponse;
    request->set_cluster_id(cluster_id);
    request->set_segment_id(segment_id);
    request->set_version(version);
    auto done = brpc::NewCallback(this, &Control::OnRemoveGarbageSegment, request, response);
    auto* ctx = new Context(Action::kDropSegment,
            nullptr, request, response, done);
    Dispatch(ctx);
    PSVR_LOG_CTX(WARNING, ctx) << "drop segment not existing on manager,"
        << " cluster:[" << cluster_id
        << "] segment_id:[" << segment_id
        << "] version:[" << version
        << "]";
}

void Control::OnRemoveGarbageSegment(pspb::DropSegmentRequest* request, pspb::DropSegmentResponse* response) {
    LOG(NOTICE) << "drop segment not existing on manager,"
        << " cluster:[" << request->cluster_id()
        << "] segment_id:[" << request->segment_id()
        << "] version:[" << request->version()
        << "] " << response->status();
    delete request;
    delete response;
}

void Control::GcStoreTrash(Context* ctx) {
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        LOG(NOTICE) << "gc store failed, server stopped";
        return;
    }

    AUTO_INC_DEC_RUNNING_CONTEXT_SIZE();
    StoreIteratorFn fn = [this](StorePtr store) {
        store->GcTrash(_stopped);
        return !_stopped;
    };
    _store_manager->GetStores(fn);
    Schedule(ctx, second2microseconds(FLAGS_multi_psvr_gc_trash_segment_interval_second));
}

void Control::MonitorStore(Context* ctx) {
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        PSVR_LOG_CTX(NOTICE, ctx) << "monitor store failed, server stopped";
        return;
    }
    AUTO_INC_DEC_RUNNING_CONTEXT_SIZE();
    {
        StoreIteratorFn fn = [this](StorePtr store) {
            store->UpdateFreeSize(_stopped);
            return !_stopped;
        };
        _store_manager->GetStores(fn);
    }
    Schedule(ctx, second2microseconds(FLAGS_multi_psvr_monitor_store_statistic_interval_second));
}

void Control::MonitorSegment(Context* ctx) {
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        PSVR_LOG_CTX(NOTICE, ctx) << "monitor store failed, server stopped";
        return;
    }
    AUTO_INC_DEC_RUNNING_CONTEXT_SIZE();
    {
        std::vector<SegmentPtr> segments;
        _segment_manager->GetAllSegments(&segments);
        for (auto& seg : segments) {
            seg->UpdateDBSize();
            if (BAIDU_UNLIKELY(_stopped)) {
                break;
            }
        }
    }
    Schedule(ctx, second2microseconds(FLAGS_multi_psvr_monitor_segment_statistic_interval_second));
}

void Control::ClearSpaceStatus(Context* ctx) {
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        PSVR_LOG_CTX(NOTICE, ctx) << "check space status failed, server stopped";
        return;
    }

    AUTO_INC_DEC_RUNNING_CONTEXT_SIZE();

    std::vector<SegmentPtr> segments;
    _segment_manager->GetAllSegments(&segments);
    for (auto& seg : segments) {
        if (seg->GetSpaceStatusCount() > MAX_SPACE_STATUS_SIZE) {
            _parser->AddClearSapceStatusEvent(seg TRACE_FILE_LINE_CC);
        }
        if (BAIDU_UNLIKELY(_stopped)) {
            break;
        }
    }

    Schedule(ctx, millisecond2microseconds(FLAGS_psvr_clear_space_status_interval_ms) / 3);
}

void Control::ResetPsmQuota(Context* ctx) {
    std::unique_ptr<Context> ctx_guard(ctx);
    if (_stopped) {
        PSVR_LOG_CTX(NOTICE, ctx) << "reset psm quota failed, server stopped";
        return;
    }
    FLAGS_psvr_query_metadata_quota_per_cluster = _get_metadata_quota_per_cluster;
    PSVR_LOG_CTX(NOTICE, ctx) << "reset psm quota to value:["
        << FLAGS_psvr_query_metadata_quota_per_cluster << "]";
}

void Control::IncOrDecThreadNum(Context* ctx) {
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        PSVR_LOG_CTX(NOTICE, ctx) << "inc or dec thread num failed, server stopped";
        return;
    }

    AUTO_INC_DEC_RUNNING_CONTEXT_SIZE();

    int32_t n = 0;
    n += _fetcher->IncOrDecThreadNum();
    n += _parser->IncOrDecThreadNum();
    n += _gc->IncOrDecThreadNum();
    n += _rbio_manager->IncOrDecThreadNum();
    n += _recoverer->IncOrDecThreadNum();
    n += _compressor->IncOrDecThreadNum();

    LOG_IF(NOTICE, n) << "inc or dec thread num finish, n:[" << n << "]";
    Schedule(ctx, second2microseconds(3));
}

void Control::OnUpdateLowestLsn(RpcGetLowestCtx* rpc_ctx, ClusterPtr cluster) {
    std::unique_ptr<RpcGetLowestCtx> rpc_ctx_guard(rpc_ctx);
    bool not_exists = false;
    set_cluster_stat(cluster, stat_psm_req_lat, rpc_ctx->latency_us);
    if (!rpc_failed(rpc_ctx, &not_exists)) {
#define get_if_has(name) (rpc_ctx->response.has_##name() ? rpc_ctx->response.name() : 0)
        auto ps_lowest_lsn = get_if_has(ps_lowest_lsn);
        auto ps_lowest_gc_lsn = get_if_has(ps_lowest_gc_lsn);
        auto cn_lowest_lsn = get_if_has(cn_lowest_lsn);
        auto cn_lowest_gc_lsn = get_if_has(cn_lowest_gc_lsn);
#undef get_if_has

        if (ps_lowest_lsn > 0) {
            cluster->set_ps_lowest_lsn(ps_lowest_lsn);
        }
        if (ps_lowest_gc_lsn > 0) {
            cluster->set_ps_lowest_gc_lsn(ps_lowest_gc_lsn);
        }
        if (cn_lowest_lsn > 0) {
            cluster->set_cn_lowest_lsn(cn_lowest_lsn);
        }
        if (cn_lowest_gc_lsn > 0) {
            cluster->set_cn_lowest_gc_lsn(cn_lowest_gc_lsn);
        }

        if (cn_lowest_lsn > 0 || cn_lowest_gc_lsn > 0) {
            cluster->set_last_lsn_update_time(base::cpuwide_time_us());
        }
    }

    _segment_manager->PutClusterUpdateLowestLsnLock(cluster->name());
}

void Control::UpdateLowestLsn(Context* ctx) {
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        PSVR_LOG_CTX(NOTICE, ctx) << "update lowest lsn failed, server stopped";
        return;
    }

    AUTO_INC_DEC_RUNNING_CONTEXT_SIZE();

    std::map<ClusterPtr, PsmInfoPtr> cluster2psminfos;
    {
        std::vector<SegmentPtr> segments;
        _segment_manager->GetAllSegments(&segments);
        for (auto& seg : segments) {
            if (auto it = cluster2psminfos.find(seg->cluster()); it == cluster2psminfos.end()) {
                cluster2psminfos[seg->cluster()] = seg->GetPsmInfo();
            }
        }
    }

    size_t num = 0;
    for (auto& it : cluster2psminfos) {
        auto cluster = it.first;

        std::vector<base::EndPoint> servers;
        if (!it.second->GetOrRefreshNodes(&servers)) {
            LOG(TRACE) << "refresh psm list failed";
            RefreshPsmInfo(it.second);
            continue;
        }

        if (!_segment_manager->GetClusterUpdateLowestLsnLock(cluster->name())) {
            continue;
        }

        auto rpc_ctx = new RpcGetLowestCtx;
        rpc_ctx->request.set_cluster_id(cluster->name());
        rpc_ctx->servers = std::move(servers);

        auto closure = brpc::NewCallback(this, &Control::OnUpdateLowestLsn, rpc_ctx, cluster);
        _client->GetLowestLsn(rpc_ctx, closure);
        ++num;
    }

    LOG_IF(NOTICE, num) << "update lowest lsn finish, cluster_num:[" << num << "]";
    Schedule(ctx, second2microseconds(FLAGS_psvr_update_lowest_lsn_interval_second));
}

void Control::SealDblwrFile(Context* ctx) {
    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        PSVR_LOG_CTX(NOTICE, ctx) << "dblwr seal failed, server stopped";
        return;
    }

    AUTO_INC_DEC_RUNNING_CONTEXT_SIZE();

    if (FLAGS_psvr_dblwr_seal_timeout_us > 0) {
        std::vector<SegmentPtr> segments;
        _segment_manager->GetAllSegments(&segments);
        for (auto& seg : segments) {
            if (segment_is_valid(seg)) {
                seg->SealDblwrTimeout(FLAGS_psvr_dblwr_seal_timeout_us);
            }
        }
    }

    Schedule(ctx, second2microseconds(FLAGS_psvr_dblwr_seal_interval_second));
}

}
