/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/status.h
* @author yukeyong@baidu.com
* @brief Lightweight database status definitions.
*/

#pragma once

#include <cerrno>
#include <cstdint>
#include <cstdarg>
#include <cstring>
#include <ostream>
#include <sstream>
#include <string>
#include <utility>

#include <base/strings/string_number_conversions.h>

#include "psvr/common.h"

namespace psvr::db {

enum class Code {
    kOk = 1,
    kIOError,
    kMisMacth,
    kInvalid,
    kStatusError,
    kSysError,
    kBusy,
    kCorrupted,
    kAhead,
    kDown,
    kApplyError,
    kInterrupt,
    kMissData,
    kRetry,
    kEof,
    kEmpty,
    kNotFound,
};

inline const char* Code2Str(Code c) {
    switch (c) {
    case Code::kOk:
        return "Ok";
    case Code::kIOError:
        return "IOError";
    case Code::kMisMacth:
        return "MisMacth";
    case Code::kInvalid:
        return "Invalid";
    case Code::kStatusError:
        return "StatusError";
    case Code::kSysError:
        return "SysError";
    case Code::kBusy:
        return "Busy";
    case Code::kCorrupted:
        return "Corrupted";
    case Code::kAhead:
        return "Ahead";
    case Code::kDown:
        return "Down";
    case Code::kApplyError:
        return "ApplyError";
    case Code::kInterrupt:
        return "Interrupt";
    case Code::kMissData:
        return "MissData";
    case Code::kRetry:
        return "Retry";
    case Code::kEof:
        return "Eof";
    case Code::kEmpty:
        return "Empty";
    case Code::kNotFound:
        return "NotFound";
    default:
        return "Unknown";
    }
}

inline bool is_io_error(int n) {
    return n == EIO || n == ENOSPC;
}

struct Status {
    Code code;
    std::string msg;

    Status() : Status(Code::kOk) {}
    Status(const Status& s) : code(s.code), msg(s.msg) {}
    Status(Status&& s) : code(s.code), msg(std::move(s.msg)) {}
    Status(Code c, const char* m) : code(c), msg(m) {}
    Status(Code c) : code(c), msg(Code2Str(c)) {}
    FUNC_MOCK ~Status() {}

    Status& operator=(const Status& s) {
        if (this != &s) {
            code = s.code;
            msg = s.msg;
        }
        return *this;
    }
    Status& operator=(Status&& s) {
        if (this != &s) {
            code = s.code;
            msg = std::move(s.msg);
        }
        return *this;
    }

    bool IsOk() const { return code == Code::kOk; }
    bool IsIOError() const { return code == Code::kIOError; }
    bool IsMisMacth() const { return code == Code::kMisMacth; }
    bool IsInvalid() const { return code == Code::kInvalid; }
    bool IsStatusError() const { return code == Code::kStatusError; }
    bool IsSysError() const { return code == Code::kSysError; }
    bool IsBusy() const { return code == Code::kBusy; }
    bool IsCorrupted() const { return code == Code::kCorrupted; }
    bool IsAhead() const { return code == Code::kAhead; }
    bool IsDown() const { return code == Code::kDown; }
    bool IsApplyError() const { return code == Code::kApplyError; }
    bool IsInterrupt() const { return code == Code::kInterrupt; }
    bool IsMissData() const { return code == Code::kMissData; }
    bool IsRetry() const { return code == Code::kRetry; }
    bool IsEof() const { return code == Code::kEof; }
    bool IsEmpty() const { return code == Code::kEmpty; }
    bool IsNotFound() const { return code == Code::kNotFound; }

    void Reset(Code c) {
        code = c;
        msg = Code2Str(c);
    }
    void Reset(Code c, const char* fmt, ...) {
        std::string m;
        va_list ap;
        va_start(ap, fmt);
        base::string_vprintf(&m, fmt, ap);
        va_end(ap);
        Reset(c, std::move(m));
    }
    void Reset(Code c, const std::string& m) {
        code = c;
        msg = m;
    }
    void Reset(Code c, std::string&& m) {
        code = c;
        msg = std::move(m);
    }
    void ResetMsg(const char* fmt, ...) {
        std::string m;
        va_list ap;
        va_start(ap, fmt);
        base::string_vprintf(&m, fmt, ap);
        va_end(ap);
        ResetMsg(std::move(m));
    }
    void ResetMsg(const std::string& m) {
        msg = m;
    }
    void ResetMsg(std::string&& m) {
        msg = std::move(m);
    }

    std::string ToStr();
};

inline std::ostream& operator<<(std::ostream& os, const Status& status) {
    return os << "status:[code=(" << static_cast<int32_t>(status.code) << ")" << Code2Str(status.code)
        << ",msg=" << status.msg << "]";
}

inline std::string Status::ToStr() {
    std::stringstream ss;
    ss << (*this);
    return ss.str();
}

inline Code GetErrCode() {
    return is_io_error(errno) ? Code::kIOError : Code::kStatusError;
}

inline Status GetErrStatus() {
    return Status(GetErrCode(), strerror(errno));
}

}  // namespace psvr::db
