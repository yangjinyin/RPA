/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server_compression.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_page_server_compression.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ListPageServerCompression::Run() {
    RpcStatus status;

    if (!_cluster_addr.empty()) {
        return Run2();
    }

    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    pspb::ListCompressSegmentRequest request;
    pspb::ListCompressSegmentResponse response;

    request.set_log_id(_log_id);

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    _client.Call(_log_id, node, &pspb::QueryService_Stub::ListCompressSegment, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int ListPageServerCompression::Format(const pspb::ListCompressSegmentResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.status().code() == 0 && rsp.segments_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({"cluster_id", "segment_id", "store_id", "offset", "size", "finish_rate"}, true);
        for (auto& seg : rsp.segments()) {
            table.AddRowsValue({
                        seg.cluster_id(),
                        seg.segment_id(),
                        seg.store_id(),
                        RowSize(seg.offset(), _human_readable),
                        RowSize(seg.size(), _human_readable),
                        RowPercent(seg.offset(), seg.size()),
                    });
        }
        table.Display();
    }
    return 0;
}

int ListPageServerCompression::Run2() {
    // get all
    PsmInfo psm_info(_cluster_addr, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--cluster-addr parse failed, cant get server list");
        return 1;
    }

    auto wait_finish_fn = [this] () {
        while (!_stopped) {
            if (_task_count.load(std::memory_order_acquire) == 0) {
                break;
            } else {
                gaiadb::common::pause();    // x86
            }
        }
        if (_stopped) {
            print_error("quit by signal");
            return 1;
        }
        return 0;
    };

    _task_count.store(nodes.size());
    pspb::BatchListCompressSegmentResponse response;
    response.set_log_id(_log_id);

    pspb::ListCompressSegmentRequest req;
    req.set_log_id(_log_id);

    for (auto& node : nodes) {
        auto server_status = response.add_server_status();
        server_status->set_addr(gaiadb::common::endpoint2str(node));

        pspb::ListCompressSegmentResponse* rsp = server_status->mutable_status();
        RpcStatus* status = new RpcStatus;
        auto closure = brpc::NewCallback(this, &ListPageServerCompression::Done2, rsp, status);

        _client.Call(_log_id, node, &pspb::QueryService_Stub::ListCompressSegment, &req, rsp,
                closure, status, _timeout_ms);
    }
    if (wait_finish_fn()) {
        return 1;
    }
    return Output(response);
}

void ListPageServerCompression::Done2(pspb::ListCompressSegmentResponse* response, RpcStatus* status) {
    if (!status->IsOk()) {
        LOG(WARNING) << "rpc failed:" << status;
        response->mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response->mutable_status()->set_msg(status->msg);
    }
    _task_count.fetch_sub(1, std::memory_order_release);
    delete status;
}

int ListPageServerCompression::Format(const pspb::BatchListCompressSegmentResponse& rsp) {
    Table __table(_raw_with_table, 2);
    __table.AddRowsValue({"log_id:", _log_id});
    __table.Display();

    for (int32_t j = 0; j < rsp.server_status_size(); ++j) {
        const auto& server_status = rsp.server_status(j);
        const auto& rsp2 = server_status.status();

        Table table(_raw_with_table, 0);
        if (rsp2.status().code() != pspb::Status_ReturnCode_SUCCESS) {
            table.AddRowsWithName({"no", "node", ""});
            table.AddRowsValue({
                        j + 1, server_status.addr(),
                        RowStr(pspb::Status_ReturnCode_Name(rsp2.status().code()), rsp2.status().msg())
                    });
        } else {
            table.AddRowsWithName({"no", "node", ""});
            table.AddRowsValue({j + 1, server_status.addr(), ""});
        }
        table.Display();

        if (rsp2.status().code() == 0 && rsp2.segments_size()) {
            Table table2(_raw_with_table, 0);
            table2.AddRowsWithName({"cluster_id", "segment_id", "store_id", "offset", "size", "finish_rate"}, true);
            for (auto& seg : rsp2.segments()) {
                table2.AddRowsValue({
                        seg.cluster_id(),
                        seg.segment_id(),
                        seg.store_id(),
                        RowSize(seg.offset(), _human_readable),
                        RowSize(seg.size(), _human_readable),
                        RowPercent(seg.offset(), seg.size()),
                    });
            }
            table2.Display();
        }
    }
    return 0;
}

}
}
