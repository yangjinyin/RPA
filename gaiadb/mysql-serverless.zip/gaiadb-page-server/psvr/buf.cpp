/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/buf.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/config.h"
#include "psvr/buf.h"

namespace psvr {

static bvar::Adder<int32_t> l_stat_buf_block_used_count("psvr_buf_block_used_count");

bvar::Vector<uint32_t, 2> get_buf_blocks_info(void* arg) {
    BufPool* buf_pool = static_cast<BufPool*>(arg);
    bvar::Vector<uint32_t, 2> result;
    result[0] = buf_pool->_slices_count;
    result[1] = buf_pool->_used_buf_block_count.load(std::memory_order_relaxed);
    return result;
}

BufPool::BufPool()
    : _stat_buf_blocks(&get_buf_blocks_info, this) {
    auto block_size = ut_uintx_align_up<size_t>(sizeof(psvr_buf_block_t), gaia_apply::FLAGS_univ_page_size);
    PSVR_ASSERT(block_size > 0 && block_size % gaia_apply::FLAGS_univ_page_size == 0);
    _slice_size = gaia_apply::FLAGS_univ_page_size + block_size;
    LOG(TRACE) << "buf pool slice size:[" << _slice_size << "]";
    Expose();
}

void BufPool::Expose() {
#ifndef GTEST
    _stat_buf_blocks.expose("psvr_buf_blocks");
    _stat_buf_blocks.set_vector_names("total,used");
#endif
}

BufPool::~BufPool() {
#ifndef GTEST
    _stat_buf_blocks.hide();
#endif
    std::free(_buf);
}

bool BufPool::Init(bool multi_type) {
    if (FLAGS_psvr_disable_buf) {
        LOG(NOTICE) << "disable buf pool";
        return true;
    }
    return InitSlices(multi_type
            ? FLAGS_multi_psvr_init_page_buf_size
            : FLAGS_psvr_init_page_buf_size);
}

bool BufPool::InitSlices(int64_t buf_size) {
    int64_t queue_size = gaiadb::common::rte_align32pow2((buf_size + _slice_size - 1) / _slice_size);
    if (queue_size < 2) {
        LOG(ERROR) << "failed to init block buf pool, size:[" << buf_size
            << "] queue_size:[" << queue_size
            << "]";
        return false;
    }
    if (!_slices.Init(queue_size, gaiadb::common::RING_TYPE_MP_MC)) {
        LOG(ERROR) << "init ret ring failed, size:[" << queue_size << "]";
        return false;
    }
    uint32_t capacity = _slices.capacity();
    LOG(NOTICE) << "start init buf block pool, capacity:[" << capacity << "]";
    _buf = std::aligned_alloc(_slice_size, capacity * _slice_size);
    if (!_buf) {
        LOG(ERROR) << "alloc block buf pool failed, size:[" << buf_size
            << "] capacity:[" << capacity
            << "] slice_size:[" << _slice_size
            << "]";
        return false;
    }

    /**
     * slice: [frame | buf_block]  32kb
     */
    psvr_buf_block_t* arr[capacity];
    for (uint32_t i = 0; i < capacity; ++i) {
        auto* ptr = static_cast<gaia_apply::byte*>(_buf) + _slice_size * i;
        arr[i] = reinterpret_cast<psvr_buf_block_t*>(ptr + gaia_apply::FLAGS_univ_page_size);
        arr[i]->frame = ptr;
    }
    if (!_slices.EnqueueBulk(arr, capacity)) {
        LOG(ERROR) << "fail to init buf block queue";
        return false;
    }
    _slices_count = capacity;
    return true;
}

BufBlockPtr BufPool::AllocBufBlock(gaia_apply::ulint block_size, gaia_apply::byte* frame) {
    void* buf = std::aligned_alloc(block_size, frame ? block_size : (block_size * 2));
    if (!buf) {
        LOG(WARNING) << "alloc block buf failed";
        return nullptr;
    }

    auto* ptr = static_cast<gaia_apply::byte*>(buf);
    auto buf_block = reinterpret_cast<psvr_buf_block_t*>(ptr + (frame ? 0 : block_size));
    buf_block->frame = frame ? frame : ptr;
#ifdef GTEST
    frame || memset(buf_block->frame, 0x0, block_size);
#endif

    INIT_APPLY_RAW_ARG(false);
    auto is_align_ret = buf_block->frame == gaia_apply::page_align(buf_block->frame APPLY_RAW_ARG_NAME_CC);
    if (!is_align_ret || APPLY_RAW_IS_ERROR()) {
        if (buf) {
            std::free(buf);
        }
        LOG(WARNING) << "check page align failed,"
            << " frame:[" << PTR_P(buf_block->frame)
            << "] is_align_ret:[" << is_align_ret
            << "]";
        return nullptr;
    }

    BufBlockPtr tmp(buf_block,
            [buf](psvr_buf_block_t*) {
                    std::free(buf);
                    l_stat_buf_block_used_count << -1;
#ifdef GTEST
                    LOG(TRACE) << "release buf:" << PTR_P(buf);
#endif
                }
            );
    l_stat_buf_block_used_count << 1;
#ifdef GTEST
    PSVR_ASSERT(tmp->frame != nullptr);
    LOG(TRACE) << "alloc buf:" << PTR_P(buf);
#endif
    return tmp;
}

uint32_t BufPool::GetBufBlockFromPool(BufBlockPtr* buf_block) {
    psvr_buf_block_t* cache = nullptr;
    uint32_t n = _slices.Dequeue(&cache);
    if (n != 1) {
        return n;
    }

    BufBlockPtr tmp(cache, [this](psvr_buf_block_t* p) {
            if (!_slices.Enqueue(p)) {
                LOG(ERROR) << "fail to release pool buf block:[" << p << "]";
                PSVR_ASSERT(false);
            }
            _used_buf_block_count.fetch_sub(1, std::memory_order_relaxed);
        });
#ifdef GTEST
    memset(tmp->frame, 0x0, gaia_apply::FLAGS_univ_page_size);
#endif
    *buf_block = tmp;
    _used_buf_block_count.fetch_add(1, std::memory_order_relaxed);
    return 1;
}

BufBlockPtr BufPool::GetOrAllocBufBlock(gaia_apply::ulint block_size) {
    BufBlockPtr buf_block = nullptr;
    if (FLAGS_psvr_disable_buf
            || block_size != gaia_apply::FLAGS_univ_page_size
            || 0 == GetBufBlockFromPool(&buf_block)) {
        buf_block = AllocBufBlock(block_size, nullptr);
    }
    return buf_block;
}

}
