/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file config_sink.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <baidu/rpc/reloadable_flags.h>
#include <gaiadb/utils/ut.h>
#include <gaiadb/psm_client/config.h>
#include <zstd.h>
#include "psvr/config.h"
#include "psvr/common.h"
#include "psvr/compress_utils.h"
#include "psvr/log.h"

namespace psvr {

static int32_t compress_types[] = {PSVR_COMPRESS_TYPE_SNAPPY, PSVR_COMPRESS_TYPE_ZSTD, PSVR_COMPRESS_TYPE_LZ4};

template<typename T> static bool RangeCheck(T val, T min, T max) {
    return val >= min && val <= max;
}

template<typename T> static bool MinCheck(T val, T min) {
    return val >= min;
}

template<typename T> static bool MaxCheck(T val, T min) {
    return val <= min;
}

template<typename T> static bool InArrayCheck(T val, T arr[], size_t size) {
    for (size_t i = 0; i < size; ++i) {
        if (val == arr[i]) {
            return true;
        }
    }
    return false;
}

template<typename T> static std::string Join(T vec[], size_t n) {
    std::stringstream ss;
    for (size_t i = 0; i < n; ++i) {
        if (i) {
            ss << ",";
        }
        ss << vec[i];
    }
    return ss.str();
}

#define check_min(name, min)    \
do {   \
    decltype(FLAGS_##name) _min = (min);        \
    if (!MinCheck(FLAGS_##name, _min)) {  \
        LOG(ERROR) << "config name:[" << #name  \
                << "] value:[" << FLAGS_##name  \
                << "] lower than min_value:[" << _min << "]";      \
        return false;           \
    }   \
} while (false)

#define check_entry_min(name, entry, min)    \
do {       \
    decltype(FLAGS_##name.entry()) _min = (min);        \
    if (!MinCheck(FLAGS_##name.entry(), _min)) {  \
        LOG(ERROR) << "config name:[" << #name  \
                << "] " << #entry << " value:[" << FLAGS_##name.entry()  \
                << "] lower than min_value:[" << _min << "]";      \
        return false;           \
    }   \
} while (false)

#define check_max(name, max)    \
do {       \
    decltype(FLAGS_##name) _max = (max);        \
    if (!MaxCheck(FLAGS_##name, _max)) {  \
        LOG(ERROR) << "config name:[" << #name  \
                << "] value:[" << FLAGS_##name  \
                << "] more than max_value:[" << _max << "]";      \
        return false;           \
    }       \
} while (false)

#define check_range(name, min, max)    \
do {       \
    decltype(FLAGS_##name) _min = (min);        \
    decltype(FLAGS_##name) _max = (max);        \
    if (!RangeCheck(FLAGS_##name, _min, _max)) {  \
        LOG(ERROR) << "config name:[" << #name  \
                << "] value:[" << FLAGS_##name  \
                << "] not in range:[" << min << "," << max << "]";      \
        return false;           \
    }       \
} while (false)

#define check_in_array(name, _arr, _size)    \
do {   \
    decltype(_arr[0]) value = (FLAGS_##name);        \
    if (!InArrayCheck(value, _arr, _size)) {  \
        LOG(ERROR) << "config name:[" << #name  \
                << "] value:[" << value \
                << "] not in array:[" << Join(_arr, _size) << "]";      \
        return false;           \
    }   \
} while (false)

static bool CompressTypeValidate(const char*, int32_t val) {
    return InArrayCheck(val, compress_types, 3);
}

static bool CompressLevelValidate(const char*, int32_t val) {
    return val >= 1
        && val <= 65537;
}

static bool CompressZstdLevelValidate(const char*, int32_t val) {
    return val >= 1
        && val <= ZSTD_maxCLevel();
}

static bool CompressLz4LevelValidate(const char*, int32_t val) {
#ifdef LZ4_ACCELERATION_MAX
    const static int32_t psvr_LZ4_ACCELERATION_MAX = LZ4_ACCELERATION_MAX;
#else
    const static int32_t psvr_LZ4_ACCELERATION_MAX = 65537;
#endif
    return val >= 1
        && val <= psvr_LZ4_ACCELERATION_MAX;
}

static bool PositiveInteger(const char*, uint64_t val) {
    return val > 0;
}

static bool NonNegativeInteger(const char*, uint64_t) {
    return true;
}

static bool ThreadNumValidate(const char*, int32_t val) {
    return val > 0 && static_cast<uint32_t>(val) < kMaxThreadNum;
}

static bool ThreadNumAllowZeroValidate(const char*, int32_t val) {
    return val >= 0 && static_cast<uint32_t>(val) < kMaxThreadNum;
}

static bool AppendFileBlockSizeValidate(const char*, uint64_t val) {
    return val <= UINT32_MAX;
}

static bool AppendSeekAnchorChunkSizeValidate(const char*, uint64_t val) {
    return val >= (4UL << 20);
}

// enable reset by brpc
BAIDU_RPC_VALIDATE_GFLAG(psvr_annotate_max_num, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_logblock_annotate, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_fetch_annotate, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_gc_annotate, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_recover_annotate, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_rbio_annotate, baidu::rpc::PassValidate);
//BAIDU_RPC_VALIDATE_GFLAG(heartbeat_interval_second, baidu::rpc::NonNegativeInteger);
//BAIDU_RPC_VALIDATE_GFLAG(heartbeat_interval_ms, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_gc_trash_segment_interval_second, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_segment_in_trash_second, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_gc_trash_segment_num, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_monitor_store_statistic_interval_second, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_monitor_segment_statistic_interval_second, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_topology_to_offline, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_max_time_us, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_max_time_us_from_backup, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_abnormal_max_time_us, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_empty_consecutive_time, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_segment_fetch_max_buf_size, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_cluster_fetch_max_buf_size, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_max_buf_size, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetcher_delay_min_us, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetcher_delay_max_us, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_delay_empty, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_delay_non_empty, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_enable_server_push, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_batch_monitor_s, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_server_push_timeout_ms, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_redo_rec_log_timeout_ms, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_long_query_time_us, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_parser_delay_min_us, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_parser_delay_max_us, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_enable_check, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_clear_ignore_cluster_space, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_corrupted_enable_recover, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_enable_incremental_completion, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_use_attachment, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_stop_recovery_work, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_check_interval, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_enable_punch_hole, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_dblwr_enable_punch_hole, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_fallocate_extent_first_page, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_compress_type, CompressTypeValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_compress_level, CompressLevelValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_compress_lz4_level, CompressLz4LevelValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_compress_zstd_level, CompressZstdLevelValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_delay_min_us, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_delay_max_us, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_delay_max_us_for_append, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_dblwr_dump_delay_min_us, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_dblwr_dump_delay_max_us, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_delay_for_recovery_us, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_delay_max_times_for_recovery, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_parallel_num, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_wait_lsn_max_times, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_wait_lsn_sleep_interval_us, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_parser_wait_quota_sleep_interval_us, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_wait_quota_sleep_interval_us, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_compress_wait_quota_sleep_interval_us, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_wait_lsn_max_times, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_wait_lsn_sleep_interval_us, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_wait_lsn_max_times, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_wait_lsn_sleep_interval_us, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_long_query_time_us, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_page_long_query_time_us, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_long_query_time_us, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_src_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_dst_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_delay_min_us, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_delay_max_us, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_src_store_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_dst_store_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_check_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_read_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_read_store_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_get_redo_log_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_get_redo_log_store_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_write_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_write_store_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_check_task_interval_second, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_max_inflight_task_size, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_task_parallel_num_per_store, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_call_timeout_ms, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_max_wait_lsn_size, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_max_read_for_recovery_num, NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_max_read_for_backup_num, NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_max_write_for_backup_num, NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_max_read_redo_log_num, NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_compression, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_check_compress_data, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_compress_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_compress_store_max_speed, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_compress_store_inflight_num, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_compress_calc_priority_interval_second, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_compress_segment_min_interval_second, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_compress_store_max_task_num, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_trim_free_extent, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_trim_free_extent_calc_priority_interval_second, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_update_lowest_lsn_interval_second, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_trim_free_extent_min_interval_us, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_trim_free_extent_max_task_num_per_store, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_enable_wait_queue, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_thread_max_queue_size, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_long_query_time_us, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_long_query_time_print_detail_us, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_delay_min_us, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_delay_max_us, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_max_tasks_size, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_max_timeout_ms, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_enable_direct_get_meta, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_response_compress_type, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_refresh_peers_err_times, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_rbio_max_tasks_size, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_transfer_req_in_recovery, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_get_extent_map_with_high_performance, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_unknown_extent_to_garbage, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_query_metadata_quota_per_cluster, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_disable_buf, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_single_az_raft_replica_size, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_with_backup_az_raft_replica_size, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_batch_heartbeat_max_segment_size, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_fetch_batch_segment_count, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_store_reserve_size, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_enable_reopen_segment, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_enable_reopen_check_times, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_empty_db_file_on_creating, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_fdatasync, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_disable_sync, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_sync_directory, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_sync_on_recovery_or_compression, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_sync_size_on_recovery_or_compression, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_delay_lsn_size, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_delay_time_us, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_gc_prior_thread_num_per_group, ThreadNumAllowZeroValidate);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_dblwr_dump_num_per_group, baidu::rpc::NonNegativeInteger);

BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_delay_append_time_us, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_delay_append_lsn_size, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_delay_append_data_size, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_gc_nowait_peer_recovery_window_s, NonNegativeInteger);

BAIDU_RPC_VALIDATE_GFLAG(psvr_append_disable_cache_key, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_segment_fetch_max_buf_size_by_append, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_redo_max_buf_size, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_cluster_recover_redo_max_buf_size, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_append_merge_max_buf_size, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_append_file_block_size, AppendFileBlockSizeValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_append_seek_anchor_chunk_size, AppendSeekAnchorChunkSizeValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_append_recover_max_empty_block_num, baidu::rpc::PassValidate);

BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_fetcher_thread_num_per_store, ThreadNumValidate);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_parser_thread_num_per_store, ThreadNumValidate);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_gc_thread_num_per_group, ThreadNumValidate);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_rbio_thread_num_per_group, ThreadNumValidate);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_recover_thread_num, ThreadNumValidate);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_dst_recover_thread_num, ThreadNumAllowZeroValidate);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_src_recover_thread_num, ThreadNumAllowZeroValidate);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_compress_thread_num, ThreadNumValidate);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_get_metadata_thread_num, ThreadNumValidate);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_append_thread_num_per_group, ThreadNumValidate);
BAIDU_RPC_VALIDATE_GFLAG(multi_psvr_append_recover_thread_num_pre_store, ThreadNumValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_dblwr_buf_file_limit_per_segment, baidu::rpc::PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_dblwr_seal_timeout_us, baidu::rpc::NonNegativeInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_dblwr_seal_interval_second, PositiveInteger);
BAIDU_RPC_VALIDATE_GFLAG(psvr_dblwr_dump_max_num_per_round, baidu::rpc::PositiveInteger);

BAIDU_RPC_VALIDATE_GFLAG(psvr_mock_rbio_timeout, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_mock_rbio_sleep_us, PositiveInteger);

BAIDU_RPC_VALIDATE_GFLAG(psvr_recover_disabled_as_data_source, baidu::rpc::PassValidate);
BAIDU_RPC_VALIDATE_GFLAG(psvr_rbio_disabled_as_data_source, baidu::rpc::PassValidate);

BAIDU_RPC_VALIDATE_GFLAG(psvr_enable_encrypt, baidu::rpc::PassValidate);

bool ConfigArgsSinkCheck() {
    check_entry_min(psvr_comlog_path, size, 1);
    check_entry_min(psvr_comlog_process, size, 1);

    {
        int32_t arr[] = {0 , 1, 2};
        check_in_array(psvr_comlog_split_type, arr, 3);
    }
    check_min(psvr_comlog_cut_size_mb, 64);
    check_min(psvr_comlog_quota_size, 512);
    check_min(psvr_comlog_quota_day, 0);
    check_min(psvr_spd_log_max_items_num, 1024);
    check_min(psvr_spd_log_thread_num, 1);
    check_min(psvr_spd_log_flush_second, 1);

    //check_min(heartbeat_interval_second, 0);
    //check_min(heartbeat_interval_ms, 0);
    if (gaiadb::psm_client::FLAGS_heartbeat_interval_second * 1000ul
            + gaiadb::psm_client::FLAGS_heartbeat_interval_ms <= 0) {
        LOG(ERROR) << " heartbeat interval time <= 0";
        return false;
    }
    if (!FLAGS_psvr_is_multi_type) {
        if (gaiadb::psm_client::FLAGS_manager_address.size() < 1) {
            LOG(ERROR) << " -manager_address invalid";
            return false;
        }
        if (gaiadb::psm_client::FLAGS_cluster_id.size() < 1) {
            LOG(ERROR) << " -cluster_id invalid";
            return false;
        }
        check_entry_min(psvr_page_store_dir, size, 1);
        check_min(psvr_page_store_file_size, 1);
    } else {
        check_min(multi_psvr_gc_trash_segment_interval_second, 1);
        check_min(multi_psvr_segment_in_trash_second, 0);
        check_min(multi_psvr_monitor_store_statistic_interval_second, 1);
        check_min(multi_psvr_monitor_segment_statistic_interval_second, 1);

        check_entry_min(psvr_store_config_file, size, 1);
        check_range(psvr_topology_zone, 0, 1024);
        check_min(psvr_fetch_batch_segment_count, 1);
    }

    check_min(psvr_timer_tick_interval, 1);

    check_min(psvr_control_thread_num, 1);
    check_min(multi_psvr_control_thread_num, 1);

    check_min(psvr_bthread_num, 1);
    check_range(psvr_rbio_server_port, 1024, 65535);

    if (!gaiadb::common::ut_is_2pow(FLAGS_psvr_get_extent_size)) {
        LOG(ERROR) << "-psvr_get_extent_size is not pow of 2";
        return false;
    }

    check_min(psvr_init_page_buf_size, (8L<<20));
    check_min(multi_psvr_init_page_buf_size, (8L<<20));

    check_min(psvr_fetcher_thread_num, 1);
    check_range(multi_psvr_fetcher_thread_num_per_store, 1, kMaxThreadNum - 1);
    check_min(psvr_segment_fetch_max_buf_size, 0L);
    check_min(psvr_cluster_fetch_max_buf_size, 0L);
    check_min(psvr_fetch_max_buf_size, 0L);
    check_min(psvr_fetcher_delay_min_us, 1);

    check_min(psvr_parser_thread_num, 1);
    check_range(multi_psvr_parser_thread_num_per_store, 1, kMaxThreadNum - 1);
    check_min(psvr_parser_delay_min_us, 1);

    check_min(psvr_gc_thread_num, 1);
    check_range(multi_psvr_gc_thread_num_per_group, 1, kMaxThreadNum - 1);
    check_min(psvr_gc_delay_min_us, 1);
    {
        check_in_array(psvr_gc_compress_type, compress_types, 3);
    }
    check_range(psvr_gc_compress_level, 1, 10000);
    check_range(psvr_gc_compress_lz4_level, 1, 10000);
    check_range(psvr_gc_compress_zstd_level, 1, 10000);

    check_min(psvr_recover_check_interval, 0);
    check_min(psvr_recover_src_max_speed, 0);
    check_min(psvr_recover_dst_max_speed, 0);
    check_min(psvr_recover_src_store_max_speed, 0);
    check_min(psvr_recover_dst_store_max_speed, 0);
    check_min(psvr_recover_read_store_max_speed, 0);
    check_min(psvr_get_redo_log_store_max_speed, 0);
    check_range(psvr_recover_max_inflight_task_size, 1, 2048);
    check_min(psvr_recover_check_task_interval_second, 1);
    check_range(psvr_recover_task_parallel_num_per_store, 1, 128);

    check_min(psvr_rbio_max_tasks_size, 1);
    check_min(multi_psvr_rbio_max_tasks_size, 1024);
    check_min(psvr_rbio_thread_num, 1);
    check_range(multi_psvr_rbio_thread_num_per_group, 1, kMaxThreadNum - 1);
    check_range(multi_psvr_recover_thread_num, 1, kMaxThreadNum - 1);
    check_range(multi_psvr_dst_recover_thread_num, 0, kMaxThreadNum - 1);
    check_range(multi_psvr_src_recover_thread_num, 0, kMaxThreadNum - 1);
    check_range(multi_psvr_compress_thread_num, 1, kMaxThreadNum - 1);
    check_range(multi_psvr_get_metadata_thread_num, 1, kMaxThreadNum - 1);
    check_range(multi_psvr_append_thread_num_per_group, 1, kMaxThreadNum - 1);
    check_range(multi_psvr_append_recover_thread_num_pre_store, 1, kMaxThreadNum - 1);
    check_range(multi_psvr_gc_prior_thread_num_per_group, 0, kMaxThreadNum - 1);
    check_min(psvr_rbio_thread_max_queue_size, 0);
    check_min(psvr_rbio_long_query_time_us, 0);
    check_min(psvr_rbio_long_query_time_print_detail_us, 0);
    check_min(psvr_rbio_delay_min_us, 1);

    return true;
}

}
