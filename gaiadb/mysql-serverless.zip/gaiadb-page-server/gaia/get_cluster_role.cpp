/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_cluster_role.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/get_cluster_role.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int GetClusterRole::Run() {
    RpcStatus status;
    gaiapb::GetClusterRoleRequest request;
    gaiapb::GetClusterRoleResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    request.set_log_id(_log_id);

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_cluster_role, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " get cluster role failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("get failed, all nodes failed");
    return Output(response);
}

int GetClusterRole::Format(const gaiapb::GetClusterRoleResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"cluster_role:", gaiadb::ClusterRole_Name(rsp.cluster_role()).c_str()});
    table.Display();
    return 0;
}

}
}
