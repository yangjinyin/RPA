#pragma once

#include <condition_variable>
#include <atomic>
#include <chrono>
#include <shared_mutex>

#include "gaiadb/redo_fetch/fetch_cache_manager.h"
#include "gaiadb/redo_fetch/fetch_mdc_utils.h"
#include "gflags/gflags.h"
#include "gaiadb/common/global_flags.h"

#include "log0recv.h"
#include "conductor.h"
#include "rpl0fetch.h"
#include "log0log.h"
#include "base/endpoint.h"
#include "bos0conductor.h"

#ifndef __COMPUTE_NODE_MODULE_NAME__
#define __COMPUTE_NODE_MODULE_NAME__ "GAIADB-COMPUTE SERVER"
#endif /* __COMPUTE_NODE_MODULE_NAME__ */

namespace gaiadb {
namespace redo_fetch {
  struct GetObjectContext;
  struct ObjectStorage;
  template <typename Key, typename Value>
  class CacheManager;
  struct Nfs;
}
}

namespace bir {
namespace g_fetch = gaiadb::redo_fetch;
struct BinlogToBosTask;

constexpr uint64_t LOG_FILE_MAX_SIZE = 2lu << 30; // 2GB
constexpr uint64_t CHUNK_FILE_MAX_SIZE = LOG_FILE_MAX_SIZE - LOG_FILE_HDR_SIZE;
static const int MAX_RETRYS = 3;
static const int MAX_SEND_TO_PSM_RETRYS = 20;

void add_binlog_async_info_task(BinlogInRedoInfo &binlog_in_redo_info);
void stop_binlog_async_background_thread();
void start_binlog_async_background_thread();
void bir_binlog_async_init(lsn_t start_lsn, lsn_t apply_lsn);
void bir_binlog_async_reinit(lsn_t start_lsn, lsn_t apply_lsn);
void bir_fetcher();
void bir_parser();
void bir_binlog_sync();
void bir_binlog_bos();
void add_bir_binlog_to_bos_task(BinlogToBosTask &binlog_to_bos);
bool download_binlog_file_from_bos(const char *log_file_name);
lsn_t get_binlog_start_lsn();
void bir_variables_notify();
void set_binlog_ready(bool ready);
void stop_async_binlog();

struct BinlogToBosTask
{
  BinlogToBosTask(const std::string& file_name, 
                  uint64_t file_size, 
                  uint64_t index_id, int32_t end_time) :
    file_name(file_name),
    file_size(file_size),
    index_id(index_id),
    end_time(end_time)
  {}
  std::string file_name;
  uint64_t file_size;
  uint64_t index_id;
  int32_t end_time;
};

class BirAsyncBinlog : public Conductor {
  using ls_stub = log_service::SecondaryService_Stub;
  using lz_stub = log_service::LandingZoneService_Stub;
  BirAsyncBinlog()
    : req_count_(0),
    parse_log_buf_(),
    parse_log_buf_size_(0),
    parse_data_pos_(0),
    parse_data_len_(0),
    fetch_lsn_(0),
    parse_lsn_(0),
    copy_lsn_(0),
    binlog_new_file_(false),
    stop_(false),
    binlog_ready_(false),
    threads_started_(false),
    apply_lsn_(0)
   {}
public:
  enum FETCH_ERROR {
    NOT_FOUND_LSN = -2,
    ERROR = -1,
    SUCCESS = 0,
    DATA_NOT_ENOUGH = 1,
  };
  
  ~BirAsyncBinlog();
  static BirAsyncBinlog &get_instance() {
    static BirAsyncBinlog s_bir_async_binlog;
    return s_bir_async_binlog;
  }

  bool init(lsn_t start_lsn, lsn_t apply_lsn);
  bool init(lsn_t start_lsn, size_t buf_size, lsn_t apply_lsn);
  bool reinit(lsn_t start_lsn, lsn_t apply_lsn);
  void init_common(lsn_t start_lsn);
  bool cleanup();

  std::mutex &thd_mutex() {
    return thd_mutex_;
  }
  lsn_t fetch_lsn() const override {
    return fetch_lsn_;
  }
  lsn_t copy_lsn() const override {
    return copy_lsn_;
  }
  lsn_t parse_lsn() const {
    return parse_lsn_;
  }

  std::queue<BinlogInRedoInfo> &binlog_queue() {
    return binlog_in_redo_infos_;
  }

  std::queue<BinlogToBosTask> &binlog_to_bos() {
    return binlog_to_bos_;
  }

  inline void add_binlog_async_info_task(
      BinlogInRedoInfo &binlog_in_redo_info) {
    binlog_in_redo_infos_.push(binlog_in_redo_info);
  }

  inline void add_binlog_to_bos_task(
      BinlogToBosTask &binlog_to_bos) {
    binlog_to_bos_.push(binlog_to_bos);
    variables_cv_notify();
  }

  inline void set_stop() {
    stop_ = true;
    variables_cv_.notify_all();
  }

  bool is_stop() const {
    return stop_;
  }

  inline void variables_cv_notify() {
    std::unique_lock<std::mutex> lock(thd_mutex_);
    variables_cv_.notify_all();
  }

  inline void set_sync_index_id(const uint32_t index_id) {
    sync_index_id_ = index_id;
  }

  uint32_t sync_index_id() const {
    return sync_index_id_;
  }

  inline void set_binlog_ready(bool ready) {
    binlog_ready_.store(ready, std::memory_order_relaxed);
  }

  inline bool binlog_ready() const {
    return binlog_ready_.load(std::memory_order_relaxed);
  }

  inline void set_threads_started(bool started) {
    threads_started_ = started;
  }

  bool threads_started() const {
    return threads_started_;
  }
  
  inline uint64_t translate_lsn_to_offset(lsn_t lsn) {
    return (lsn - LOG_START_LSN) % CHUNK_FILE_MAX_SIZE + LOG_FILE_HDR_SIZE;
  }
  uint32_t calc_redo_buf_real_block_num(const std::string& redo_buf);

  inline bool binlog_new_file() {
    return binlog_new_file_.load(std::memory_order_relaxed);
  }

  inline void set_binlog_new_file(bool new_file) {
    binlog_new_file_.store(new_file, std::memory_order_relaxed);
  }

  int32_t fetch_log(bool *last_fetch_from_bos, lsn_t end_lsn = 0);
  bool parse_log();
  void fetch_routine();
  void parse_routine();
  void binlog_sync_routine();
  void binlog_bos_routine();
  bool bir_binlog_in_redo_flusher();
  int32_t refresh_replicas(rpl::LogServerInfo &ls_info);
  int32_t copy_to_fetch_log_buf(
      const char *buffer, uint32_t valid_block_num, lsn_t ls_vdl, lsn_t target_lsn);

  int32_t fetch_ls_log(
      rpl::LogServerInfo &ls_info, int wait_for_more_data_count, lsn_t end_lsn = 0);
  int32_t fetch_lz_log(rpl::LogServerInfo &ls_info, lsn_t end_lsn = 0);
  int32_t fetch_mdc_log(lsn_t end_lsn = 0);
  void set_request_meta_for_bos(brpc::Controller *cntl,
        const std::string& ak, const std::string& sk,
        const std::string& host, const std::string& bucket,
        const std::string& object, const std::string& range);
  void bos_get_redo(g_fetch::GetObjectContext* rpc_ctx);
  void nfs_get_redo(g_fetch::GetObjectContext* rpc_ctx);
  void set_request_meta_for_s3(
        brpc::Controller *cntl, const std::string& region,
        const std::string& ak, const std::string& sk,
        const std::string& host, const std::string& bucket,
        const std::string& object, const std::string& range);
  void s3_get_redo(g_fetch::ObjectStorage &object_storage);

  void get_object_mdc_info(
      g_fetch::GetObjectContext* rpc_ctx, 
      g_fetch::ObjectStorage &object_storage, 
      const lsn_t target_lsn);
  std::shared_ptr<brpc::Channel> get_or_creat_channel(const std::string& host);

  void build_headers_for_bos(const std::map<std::string, std::string>& headers,
        std::string* headers_str, std::string* header_keys_str);
  void build_headers_for_s3(std::map<std::string, std::string>& headers,
        std::string* headers_str, std::string* header_keys_str);

  std::string calculate_authrization_for_bos(const std::string& access_key_id,
      const std::string& secret_access_key,
      brpc::HttpMethod method, const std::string& uri, 
      const std::string& query_string,
      const std::string& headers, const std::string& header_keys, 
      const std::string& date);
  std::string calculate_authrization_for_s3(const std::string& str_to_sign,
        const std::string& secret_access_key, const std::string& date,
        const std::string& region, const std::string& service);

  lsn_t copy_fetch_buf(bool move);
  bool log_buf_has_space_for_lsn(lsn_t lsn);
  void resize_buf();

private:
  DISALLOW_COPY_AND_ASSIGN(BirAsyncBinlog);
  std::mutex thd_mutex_;
  std::mutex fetch_mutex_;
  std::mutex parse_mutex_;
  std::mutex sync_mutex_;
  std::mutex bos_mutex_;
  std::condition_variable variables_cv_;
  
  gaiadb::common::RpcClient bir_client_;
  uint32_t req_count_;
  /* for parse */
  ut::aligned_array_pointer<byte, OS_FILE_LOG_BLOCK_SIZE> parse_log_buf_;
  size_t parse_log_buf_size_;
  size_t parse_data_pos_;
  size_t parse_data_len_;
  bool limit_by_parse_buffer_;

  lsn_t fetch_lsn_;
  lsn_t parse_lsn_;
  lsn_t copy_lsn_;

  std::atomic<bool> binlog_new_file_;

  uint32_t sync_index_id_;

  bool stop_;
  std::atomic<bool> binlog_ready_;
  bool threads_started_;

  lsn_t apply_lsn_;

  std::queue<BinlogInRedoInfo> binlog_in_redo_infos_;
  std::queue<BinlogToBosTask> binlog_to_bos_;

  g_fetch::CacheManager<std::string, brpc::Channel> channels;
  using LzCacheManger = 
  g_fetch::CacheManager<std::string, g_fetch::MdcCache>;
  g_fetch::CacheManager<std::string, LzCacheManger> replicator_trunk_files;
  g_fetch::CacheManager<std::string, g_fetch::Nfs> nfs_caches;
};
extern BirAsyncBinlog *g_bir_async;
}
