/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/parse_page.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ParsePage : public Command {
public:
    ParsePage() {
        SetName("parse-page");
        SetDesc("parse and display InnoDB page information from an ibd file");
        SetDescCn("从 ibd 文件中解析并展示 InnoDB 页面信息");

        AddRequiredArgOption("ibd-file", &_long_opt_val, kOptMax + 1, "ibd file path name", kstring);
        AddRequiredArgOption("physical-page-no", &_long_opt_val, kOptMax + 2,
                "physical page number to parse (0-based)", kuint64_t);
        AddRequiredArgOption("offset", &_long_opt_val, kOptMax + 3,
                "byte offset in file (must be page-aligned)", kuint64_t);
        AddNoArgOption("hex-dump", &_long_opt_val, kOptMax + 4, "display hex dump of raw page data");
        AddRequiredArgOption("hex-dump-limit", &_long_opt_val, kOptMax + 5, "limit hex dump to N bytes", kuint32_t);
        AddRequiredArgOption("space-id", &_long_opt_val, kOptMax + 6,
                "expected space id, validate page space_id matches", kuint32_t);
        AddNoArgOption("show-records", &_long_opt_val, kOptMax + 7, "display detailed record content");
        AddNoArgOption("show-record-data", &_long_opt_val, kOptMax + 8,
                "display record raw data (use with --show-records)");
        
        AddExample("--ibd-file xx.ibd --physical-page-no 0");
        AddExample("--ibd-file xx.ibd --space-id 2 --physical-page-no 3");
        AddExample("--ibd-file xx.ibd --physical-page-no 3 --hex-dump");
        AddExample("--ibd-file xx.ibd --offset 49152");
        AddExample("--ibd-file xx.ibd --physical-page-no 0 --hex-dump --hex-dump-limit 128");
        AddExample("--ibd-file xx.ibd --offset 49152 --show-records");
        AddExample("--ibd-file xx.ibd --offset 49152 --show-records --show-record-data");
    }
    virtual ~ParsePage() {}
    virtual int Parser(int ch, const char *opt) override {
        switch (ch) {
            case 0:
                switch (_long_opt_val) {
                    case kOptMax + 1:
                        _ibd_file = opt;
                        break;
                    case kOptMax + 2:
                        _set_physical_page_no = true;
                        _physical_page_no = std::strtoull(opt, nullptr, 10);
                        break;
                    case kOptMax + 3:
                        _set_offset = true;
                        _offset = std::strtoull(opt, nullptr, 10);
                        break;
                    case kOptMax + 4:
                        _hex_dump = true;
                        break;
                    case kOptMax + 5:
                        _hex_dump_limit = std::strtoul(opt, nullptr, 10);
                        break;
                    case kOptMax + 6:
                        _set_space_id = true;
                        _space_id = std::strtoul(opt, nullptr, 10);
                        break;
                    case kOptMax + 7:
                        _show_records = true;
                        break;
                    case kOptMax + 8:
                        _show_record_data = true;
                        break;
                    default:
                        return -1;
                }
                break;
            default:
                return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    void DisplayFilHeader(const gaia_apply::byte *frame);
    void DisplayFilTrailer(const gaia_apply::byte *frame, uint64_t page_size);
    void DisplayPageHeader(const gaia_apply::byte *frame);
    void DisplayRecordsSummary(gaia_apply::byte *frame);
    void DisplayRecordsDetail(gaia_apply::byte *frame);
    void DisplayHexDump(const gaia_apply::byte *frame, uint64_t page_size);
    static const char *PageTypeName(gaia_apply::page_type_t type);

private:
    std::string _ibd_file{};
    uint64_t _physical_page_no{0};
    bool _set_physical_page_no{false};
    uint64_t _offset{0};
    bool _set_offset{false};
    bool _hex_dump{false};
    uint32_t _hex_dump_limit{0};
    uint32_t _space_id{0};
    bool _set_space_id{false};
    bool _show_records{false};
    bool _show_record_data{false};
};

}  // namespace gaia
}  // namespace psvr
