/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_thread_pool.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "test/test_common.h"
#include "gaiadb/utils/queue.hpp"

namespace psvr {
namespace test {


template<typename T>
class MockRetRing : public gaiadb::common::RetRing<T> {
public:
    MockRetRing() : gaiadb::common::RetRing<T>() {
    }
    virtual ~MockRetRing() {}

    MOCK_METHOD2_T(Init, bool(uint32_t, gaiadb::common::ring_type));

    MOCK_METHOD1_T(Enqueue, uint32_t(T));
    MOCK_METHOD3_T(EnqueueBulk, uint32_t(T*, uint32_t, uint32_t*));
    MOCK_METHOD3_T(EnqueueBurst, uint32_t(T*, uint32_t, uint32_t*));

    MOCK_METHOD1_T(Dequeue, uint32_t(T*));
    MOCK_METHOD3_T(DequeueBulk, uint32_t(T*, uint32_t, uint32_t*));
    MOCK_METHOD3_T(DequeueBurst, uint32_t(T*, uint32_t, uint32_t*));
};


}
}
