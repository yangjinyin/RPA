/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_tde_enable_status.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/get_tde_enable_status.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int GetTDEEnableStatus::Run() {
    RpcStatus status;
    gaiapb::EmptyMessage request;
    gaiapb::GetTDEEnableResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_tde_enable_status,
                &request, &response, nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " get tde enable status failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("get tde enable status failed, all nodes failed");
    response.set_enable(false);
    return Output(response);
}

int GetTDEEnableStatus::Format(const gaiapb::GetTDEEnableResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"enable:", rsp.enable()});
    table.Display();
    return 0;
}

}
}
