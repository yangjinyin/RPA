/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test_store.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/store.h"
#include "bmock.h"
#include "psvr/store_cfg.h"

namespace psvr {
namespace test {

class StoreTests : public PsvrTest {
public:
    StoreTests() {
    }

    virtual ~StoreTests() {}

    void SetUp() {
        _store.reset(new Store(0, "./store_a", "./store_trash", 1, 4ul << 40, 4ul << 40, 3ul << 40, 0, 1024));
        _store_manager.reset(new StoreManager());

        EXPECT_CALL(*_mock_segment_manager, GetOrCreatePsmInfo(_)).WillRepeatedly(Return(_psm_info));
        EXPECT_CALL(*_mock_segment_manager, GetOrCreateCluster(_)).WillRepeatedly(Return(g_mock_cluster));
        EXPECT_CALL(*_mock_segment_manager, AddSegment(_)).WillRepeatedly(Return(true));
    }

    void TearDown() {
        std::filesystem::remove_all("./test_unit");
    }

private:
    StorePtr _store;
    StoreManagerPtr _store_manager;
    volatile bool _stopped;
};

//BMOCK_NS_METHOD2(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
//BMOCK_NS_METHOD2(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
//BMOCK_NS_METHOD2(std::filesystem, create_directory, bool(const std::filesystem::path&, std::error_code&));
//BMOCK_NS_METHOD2(std::filesystem, space, filesystem::space_info(const std::filesystem::path&, std::error_code&));
//BMOCK_NS_METHOD3(std::filesystem, rename, void(const std::filesystem::path&, const std::filesystem::path&, std::error_code&));
//BMOCK_NS_METHOD3(std::filesystem, remove_all, std::uintmax_t(const std::filesystem::path&, std::error_code&));
//BMOCK_NS_METHOD3(std::filesystem, remove, bool(const std::filesystem::path&, std::error_code&));
//BMOCK_NS_METHOD3(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));

TEST_F(StoreTests, test_StoreManager_Init) {
    _store_manager->_is_absolute_path = false;
    {
        // load not exists cfg
        FLAGS_psvr_store_config_file = "./store_conf_not_exists.cfg";
        bool rc = _store_manager->Init();
        ASSERT_FALSE(rc);
    } END_OF_CASE;

    {
        // load a empty cfg
        FLAGS_psvr_store_config_file = "./store_config_empty_store.cfg";
        ASSERT_TRUE(atomic_write_file(FLAGS_psvr_store_config_file, ""));
        bool rc = _store_manager->Init();
        ASSERT_FALSE(rc);
        std::filesystem::remove(FLAGS_psvr_store_config_file);
    } END_OF_CASE;

    {
        auto fn = [](Control::Context* ctx) {
            delete ctx;
        };

        // one store in inactive
        EXPECT_CALL(*_mock_control, Dispatch(_)).Times(3).WillRepeatedly(Invoke(fn));

        FLAGS_psvr_store_config_file = "./store_config_test_store.cfg";
        std::ostringstream oss;
        oss << "[store]\n";
        oss << "count=5\n";
        oss << "[store0]\n";
        oss << "path=./test_store0\n";
        oss << "active=1\n";
        oss << "[store1]\n";
        oss << "path=./test_store1\n";
        oss << "active=0\n";
        oss << "[store2]\n";
        oss << "path=./test_store2\n";
        oss << "active=1\n";
        oss << "size=68719476736\n";
        oss << "[store3]\n";
        oss << "path=./test_store3\n";
        oss << "active=1\n";
        oss << "capacity=1024\n";
        oss << "[store4]\n";
        oss << "path=./test_store3\n";
        oss << "active=0\n";
        oss << "capacity=1024\n";
        ASSERT_TRUE(atomic_write_file(FLAGS_psvr_store_config_file, oss.str()));

        std::filesystem::create_directories("./test_store0/test1/1");
        std::filesystem::create_directories("./test_store1/test1/2");
        std::filesystem::create_directories("./test_store2/test1/3");
        std::filesystem::create_directories("./test_store3/test1/4");
        std::filesystem::create_directories("./test_store3/test2/");

        for (int32_t i = 0; i < 4; ++i) {
            std::ostringstream oss2;
            oss2 << "[segment]\n";
            oss2 << "cluster_id=test1\n";
            oss2 << "segment_id=" << i+1 << "\n";
            oss2 << "segment_size=1024\n";
            oss2 << "replica_id=0\n";
            oss2 << "status=Open\n";
            oss2 << "manager_address=gaia://127.0.0.1:9999\n";

            std::string file = base::string_printf("./test_store%d/test1/%d/meta", i, i+1);
            ASSERT_TRUE(atomic_write_file(file, oss2.str()));
        }

        bool rc = _store_manager->Init();
        ASSERT_TRUE(rc);
        ASSERT_EQ(5, _store_manager->_stores.size());
        ASSERT_EQ(5, _store_manager->StoreCount());
        _control->segment_manager()->Start(5);

        StorePtr s0 = _store_manager->GetStore(0);
        ASSERT_TRUE(s0 != nullptr);

        std::vector<StorePtr> stores;
        _store_manager->GetStores(&stores);
        ASSERT_EQ(5, stores.size());

        auto load_stat = std::make_shared<LoadStat>();
        rc = _store_manager->Start(_control, load_stat);
        ASSERT_TRUE(rc);
        ASSERT_EQ(3, load_stat->load_num.load());
        ASSERT_EQ(0, load_stat->prepared_num.load());

        uint32_t n = 0;
        StoreIteratorFn fn2 = [&n](StorePtr s) {
            if (s != nullptr) {
                ++n;
            }
            return true;
        };
        _store_manager->GetStores(fn2);
        ASSERT_EQ(5, n);

        std::filesystem::remove(FLAGS_psvr_store_config_file);
        std::filesystem::remove_all("./test_store0");
        std::filesystem::remove_all("./test_store1");
        std::filesystem::remove_all("./test_store2");
        std::filesystem::remove_all("./test_store3");
    } END_OF_CASE;
    _store_manager->_is_absolute_path = true;
}

TEST_F(StoreTests, test_Stop) {
    _store_manager->Stop();
    ASSERT_TRUE(_store_manager->_stopped);
}


TEST_F(StoreTests, test_StoreConfigFile) {

    FLAGS_psvr_store_config_file = "./test_not_exists/1";
    _store_manager->_stores[g_mock_store->id()] = g_mock_store;

    ASSERT_FALSE(_store_manager->StoreConfigFile());
    FLAGS_psvr_store_config_file = "./test_1";

    ASSERT_TRUE(_store_manager->StoreConfigFile());
    std::filesystem::remove(FLAGS_psvr_store_config_file);
}

TEST_F(StoreTests, test_Store_OpenSegment) {
    {
        FLAGS_multi_psvr_enable_cleanup_store_incomplete_segment = false;
        bool is_trash = false;
        SegmentPtr seg = _store->OpenSegment(_control, "./test_unit/store_a/not_exists_path/1", &is_trash);
        ASSERT_FALSE(seg != nullptr);
    }

    {
        bool is_trash = false;
        std::filesystem::create_directories("./test_unit/store_a/empty/1");
        std::ostringstream oss;
        oss << "[segment]\n";
        oss << "cluster_id=\n";
        oss << "segment_id=1\n";
        oss << "segment_size=1024\n";
        oss << "replica_id=0\n";
        oss << "status=Open\n";
        oss << "manager_address=gaia://127.0.0.1:9999\n";
        ASSERT_TRUE(atomic_write_file("./test_unit/store_a/empty/1/meta", oss.str()));

        SegmentPtr seg = _store->OpenSegment(_control, "./test_unit/store_a/empty/1", &is_trash, false);
        ASSERT_FALSE(seg != nullptr);
    }

    {
        bool is_trash = false;
        std::filesystem::create_directories("./test_unit/store_a/err_status/1");
        std::ostringstream oss;
        oss << "[segment]\n";
        oss << "cluster_id=err_status\n";
        oss << "segment_id=1\n";
        oss << "segment_size=1024\n";
        oss << "replica_id=0\n";
        oss << "status=Unknown\n";
        oss << "manager_address=gaia://127.0.0.1:9999\n";
        ASSERT_TRUE(atomic_write_file("./test_unit/store_a/err_status/1/meta", oss.str()));

        SegmentPtr seg = _store->OpenSegment(_control, "./test_unit/store_a/err_status/1", &is_trash, false);
        ASSERT_FALSE(seg != nullptr);
    }

    {
        bool is_trash = false;
        std::filesystem::create_directories("./test_unit/store_a/address_empty/1");
        std::ostringstream oss;
        oss << "[segment]\n";
        oss << "cluster_id=address_empty\n";
        oss << "segment_id=1\n";
        oss << "segment_size=1024\n";
        oss << "replica_id=0\n";
        oss << "status=Open\n";
        oss << "manager_address=\n";
        ASSERT_TRUE(atomic_write_file("./test_unit/store_a/address_empty/1/meta", oss.str()));

        SegmentPtr seg = _store->OpenSegment(_control, "./test_unit/store_a/address_empty/1", &is_trash, false);
        ASSERT_FALSE(seg != nullptr);
    }

    {
        bool is_trash = false;
        std::filesystem::create_directories("./test_unit/store_a/normal/1");
        std::ostringstream oss;
        oss << "[segment]\n";
        oss << "cluster_id=normal\n";
        oss << "segment_id=1\n";
        oss << "segment_size=1024\n";
        oss << "replica_id=1\n";
        oss << "version=2\n";
        oss << "status=Open\n";
        oss << "manager_address=gaia://127.0.0.1:9999\n";
        oss << "[rebalance]\n";
        oss << "from=127.0.0.1:9999\n";
        oss << "version=88\n";
        ASSERT_TRUE(atomic_write_file("./test_unit/store_a/normal/1/meta", oss.str()));

        SegmentPtr seg = _store->OpenSegment(_control, "./test_unit/store_a/normal/1", &is_trash, false);
        ASSERT_TRUE(seg != nullptr);
        ASSERT_EQ(seg->_cluster_id, "normal");
        ASSERT_EQ(seg->_segment_id, 1);
        ASSERT_EQ(seg->_segment_size, 1024);
        ASSERT_EQ(seg->_replica_id, 1);
        ASSERT_EQ(seg->_version, 2);
        ASSERT_EQ(seg->is_active(), true);
        //ASSERT_EQ(seg->GetPsmInfo()->_address, "gaia://127.0.0.1:9999");
        ASSERT_EQ(seg->_rebalance_from, "127.0.0.1:9999");
        ASSERT_EQ(seg->_rebalance_version, 88);
    }
    {
        FLAGS_multi_psvr_enable_cleanup_store_incomplete_segment = true;
        bool is_trash = false;
        _store->_active = false;
        SegmentPtr seg = _store->OpenSegment(_control, "./test_unit/store_a/not_exists_path/1", &is_trash);
        ASSERT_FALSE(seg != nullptr);
    }
    {
        FLAGS_multi_psvr_enable_cleanup_store_incomplete_segment = true;
        bool is_trash = false;
        _store->_active = true;
        SegmentPtr seg = _store->OpenSegment(_control, "./test_unit/store_a/not_exists_path/1", &is_trash);
        ASSERT_FALSE(seg != nullptr);
    }
}

TEST_F(StoreTests, test_Store_EnableAddSegment) {
    {
        _store->_active = false;
        bool rc = _store->EnableAddSegment(1);
        ASSERT_FALSE(rc);
        _store->_active = true;
    }

    {
        SegmentPtr segment = create_segment();
        ASSERT_TRUE(_store->IncStatistic(segment));

        _store->_capacity = 1;
        bool rc = _store->EnableAddSegment(1);
        ASSERT_FALSE(rc);
        _store->_capacity = 2;
    }

    {
        _store->_free_size = 1;
        bool rc = _store->EnableAddSegment(2);
        ASSERT_FALSE(rc);
        _store->_free_size = 3;
    }

    {
        bool rc = _store->EnableAddSegment(2);
        ASSERT_TRUE(rc);
    }
}

TEST_F(StoreTests, test_Store_IncStatistic_DecStatistic) {
    _store->_capacity = 1;
    SegmentPtr segment = create_segment();
    ASSERT_TRUE(_store->IncStatistic(segment));
    ASSERT_FALSE(_store->IncStatistic(segment));

    SegmentPtr segment2 = create_segment_by_cluster("c2", 1);
    ASSERT_FALSE(_store->IncStatistic(segment2));
    ASSERT_TRUE(_store->IncStatistic(segment2, true));

    _store->DecStatistic(segment);
    ASSERT_FALSE(_store->IncStatistic(segment));
    ASSERT_FALSE(_store->IncStatistic(segment2));
}

TEST_F(StoreTests, test_DeleteSegmentPath) {
    std::string delete_path = base::string_printf("%s/tmp_a/1", _store->path().c_str());
    bool rc = std::filesystem::create_directories(delete_path);
    ASSERT_TRUE(rc || std::filesystem::exists(delete_path));

    rc = _store->DeleteSegmentPath(delete_path, "tmp_a", 1);
    ASSERT_TRUE(rc);

    // do it again
    rc = std::filesystem::create_directory(delete_path);
    ASSERT_TRUE(rc);

    rc = _store->DeleteSegmentPath(delete_path, "tmp_a", 1);
    ASSERT_TRUE(rc);

    FLAGS_multi_psvr_segment_in_trash_second = 0;
    sleep_for(SLEEP_SECOND);
    _stopped = true;
    _store->GcTrash(_stopped);
    _stopped = false;
    _store->GcTrash(_stopped);
}

TEST_F(StoreTests, test_GcTrash_early_returns) {
    _stopped = false;
    _store->_active = false;
    _store->GcTrash(_stopped);

    _store->_active = true;
    _stopped = true;
    _store->GcTrash(_stopped);

    _stopped = false;
    auto store = std::make_shared<Store>(1, "./store_not_exists",
            "./store_trash_not_exists", true, 1, 1, 1, false, 1);
    std::filesystem::remove_all(store->trash_path());
    store->GcTrash(_stopped);
    ASSERT_FALSE(std::filesystem::exists(store->trash_path()));
    END_OF_CASE;
}

TEST_F(StoreTests, test_GcTrash_remove_limit_and_sync) {
    const int32_t old_remove_num =
            FLAGS_multi_psvr_gc_trash_segment_num;
    const int64_t old_trash_second =
            FLAGS_multi_psvr_segment_in_trash_second;
    FLAGS_multi_psvr_gc_trash_segment_num = 1;
    FLAGS_multi_psvr_segment_in_trash_second = 0;

    const std::filesystem::path trash_path = _store->trash_path();
    std::filesystem::remove_all(trash_path);
    ASSERT_TRUE(std::filesystem::create_directories(trash_path));
    const auto old_trash_file =
            trash_path / (kTrashSegmentPrefixName + "_old");
    ASSERT_TRUE(std::filesystem::create_directories(old_trash_file));

    sleep_for(SLEEP_SECOND);
    _stopped = false;
    _store->GcTrash(_stopped);
    ASSERT_FALSE(std::filesystem::exists(old_trash_file));

    const auto retained_trash_file =
            trash_path / (kTrashSegmentPrefixName + "_retained");
    ASSERT_TRUE(std::filesystem::create_directories(retained_trash_file));
    FLAGS_multi_psvr_gc_trash_segment_num = 0;
    _store->GcTrash(_stopped);
    ASSERT_TRUE(std::filesystem::exists(retained_trash_file));

    FLAGS_multi_psvr_gc_trash_segment_num = 1;
    FLAGS_multi_psvr_segment_in_trash_second = 3600;
    _store->GcTrash(_stopped);
    ASSERT_TRUE(std::filesystem::exists(retained_trash_file));

    std::filesystem::remove_all(trash_path);
    FLAGS_multi_psvr_gc_trash_segment_num = old_remove_num;
    FLAGS_multi_psvr_segment_in_trash_second = old_trash_second;
    END_OF_CASE;
}

TEST_F(StoreTests, test_DeleteSegmentPath2) {
    // invalid
    {
        auto segment = create_segment_by_cluster("c1", 1, "./data/c1/1");
        _store->_active = false;
        ASSERT_TRUE(_store->DeleteSegment(segment));
        _store->_active = true;
    }

    {
        // mismatch path
        auto segment = create_segment_by_cluster("c1", 1, "./data/c2/1");
        auto rc = _store->DeleteSegment(segment);
        ASSERT_FALSE(rc);
    }

    {
        // mismatch id
        auto segment = create_segment_by_cluster("c1", 1, "./data/c1/2");
        auto rc = _store->DeleteSegment(segment);
        ASSERT_FALSE(rc);
    }

    {
        auto segment = create_segment_by_cluster("c1", 1, "./data/c1/1");
        auto rc = _store->DeleteSegment(segment);
        ASSERT_TRUE(rc);
    }

    {
        auto segment = create_segment_by_cluster("c1", 1, "./data/c1/1");
        auto rc = std::filesystem::create_directories(segment->_db_path);
        ASSERT_TRUE(rc || std::filesystem::exists(segment->_db_path));
        rc = _store->DeleteSegment(segment);
        ASSERT_TRUE(rc);
    }
}

TEST_F(StoreTests, test_Store_UpdateFreeSize) {
    _stopped = true;
    _store->UpdateFreeSize(_stopped);
    _stopped = false;
    _store->UpdateFreeSize(_stopped);

    pspb::MultiGetStatusResponse::Store info;
    _store->GetStoreInfo(&info);

    ASSERT_EQ(info.store_id(), _store->id());
    ASSERT_EQ(info.free_size(), _store->free_size());
}

TEST_F(StoreTests, test_Disable_Enable_UpdateCapacity_UpdateSize_GetConfigItems) {
    bool val = _store->Disable();
    ASSERT_FALSE(_store->_active);
    ASSERT_TRUE(val);
    val = _store->Disable();
    ASSERT_FALSE(val);

    val = _store->Enable();
    ASSERT_TRUE(_store->_active);
    ASSERT_TRUE(val);
    val = _store->Enable();
    ASSERT_TRUE(_store->_active);
    ASSERT_FALSE(val);

    _store->UpdateCapacity(1);
    ASSERT_EQ(1, _store->_capacity);

    _store->UpdateSize(-1);
    ASSERT_FALSE(_store->_specify_size);

    _store->UpdateSize(1);
    ASSERT_EQ(1, _store->_size);
    ASSERT_TRUE(_store->_specify_size);

    gaiadb::common::Config config;
    _store->GetConfigItems(&config);
}

TEST_F(StoreTests, test_IteratorSegments) {
    StoreCfg::IterSegFn iter_seg_fn = [](const std::string& seg_dir){
        std::cout << seg_dir << std::endl;
    };
    StoreCfg::IterClsFn iter_cluster_fn = [](const std::string& clus_dir, uint32_t seg_count){
        std::cout << clus_dir << ", count:" << seg_count << std::endl;
    };
    {
        std::filesystem::remove_all("./not_exists_path");
        bool ret = StoreCfg::IteratorSegments("./not_exists_path", iter_seg_fn, iter_cluster_fn);
        ASSERT_FALSE(ret);
    } END_OF_CASE;
    {
        std::filesystem::create_directories("./exists_path/cluster/segment");
        atomic_write_file("./exists_path/1.txt", "");
        bool ret = StoreCfg::IteratorSegments("./exists_path", iter_seg_fn, iter_cluster_fn);
        std::filesystem::remove_all("./exists_path");
        ASSERT_TRUE(ret);
    } END_OF_CASE;
}


}
}
