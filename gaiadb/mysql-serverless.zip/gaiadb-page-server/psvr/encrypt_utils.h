#pragma once

#include <psvr0page.h>

#include "psvr/namespace.h"
#include "psvr/common.h"
#include "psvr/utils.h"
#include "gaiadb/utils/encrypt.h"

namespace psvr {

inline bool is_page_need_decrypt(gaia_apply::byte *data) {
    if (data == nullptr) {
        return false;
    }
    gaia_apply::ulint page_type = gaia_apply::fil_page_get_type(data);
    return page_type == gaia_apply::FIL_PAGE_ENCRYPTED;
}

static constexpr const char* AES_ENCRYPTION = "aes_ctr";
static constexpr const char* SM4_ENCRYPTION = "sm4_ctr";

struct EncryptionInfo {
    uint64_t version{0};
    std::string encryption_key{};
    std::string encryption_iv{};
    std::string encryption_alg{};
    gaiadb::common::cipher::opmode mode;

    bool is_valid() const {
        return !encryption_key.empty() && !encryption_iv.empty() && !encryption_alg.empty();
    }

    bool check_alg_supported() const {
        return encryption_alg == AES_ENCRYPTION || encryption_alg == SM4_ENCRYPTION;
    }

    bool is_aes_ctr() const { return encryption_alg == AES_ENCRYPTION; }

    bool is_sm4_ctr() const { return encryption_alg == SM4_ENCRYPTION; }

    bool Init(const gaiapb::EncryptionInfo &encryption_info_pb) {
        if (encryption_info_pb.has_encryption_key()) {
            encryption_key = encryption_info_pb.encryption_key();
        }
        if (encryption_info_pb.has_encryption_iv()) {
            encryption_iv = encryption_info_pb.encryption_iv();
        }
        if (encryption_info_pb.has_encryption_alg()) {
            encryption_alg = encryption_info_pb.encryption_alg();
        }
        if (is_sm4_ctr()) {
            mode = gaiadb::common::cipher::sm4_ecb;
        } else if (is_aes_ctr()) {
            if (encryption_key.size() == 16) {
                mode = gaiadb::common::cipher::aes_128_ecb;
            } else if (encryption_key.size() == 24) {
                mode = gaiadb::common::cipher::aes_192_ecb;
            } else if (encryption_key.size() == 32) {
                mode = gaiadb::common::cipher::aes_256_ecb;
            } else {
                return false;
            }
        } else {
            return false;
        }
        return true;
    }
};

class BlockAccessCipherStream {
public:
    BlockAccessCipherStream(const EncryptionInfo &encryption_info)
        : _key(encryption_info.encryption_key),
          _iv(encryption_info.encryption_iv),
          _mode(encryption_info.mode) {}
    virtual ~BlockAccessCipherStream() {}

    FUNC_MOCK bool encrypt_page(gaia_apply::space_id_t logical_space_id,
                                gaia_apply::page_no_t logical_page_no, gaia_apply::byte *data);
    FUNC_MOCK bool decrypt_page(gaia_apply::byte *data, gaia_apply::ulint size);

private:
    bool encrypt(char *data, size_t data_size);
    bool decrypt(char *data, size_t data_size);

private:
    std::string _key;
    std::string _iv;
    gaiadb::common::cipher::opmode _mode;
};

using BlockAccessCipherStreamPtr = std::shared_ptr<BlockAccessCipherStream>;

}  // namespace psvr
