# PageServer 说明

## 整体简介

PageServer (简称 ps) 是一个分布式多副本的存储服务, 提供 page (大小16kb) 的随机读写服务. 
page 对应 mysql innodb page. 通过应用 redo log 来修改 page 内容.

PageServer 以 Segment 为副本单位, 默认大小为 32GB, Segment 的多副本间是平等关系 (非 raft 模式). 
Segment 由管理服务 PageServer Manager (简称psm) 管理. 一个 Segment 可以包含多个 space 的 多个 page.

PageServer 是支持多磁盘部署, 每个磁盘可以管理多个 Segment. 

PageServer 可以管理多个 Mysql 实例 (即: Cluster). 

更多细节参考: https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/PA2gxLX6I5/SNzdpV2fcc/oGo4fT_n22g-BU


## 模块介绍

PageServer 内部分为多个子模块:
- 写流程: 包含 Fetcher/Parser/GC (Append + Gc + dblwr).
- 读流程: 包含 RBIO.
- 故障恢复: 包含 Recover.
- 其他: 包含 Compress, Control 等.


### Fetcher

Fetcher 的核心就是根据 LSN 来获取属于该 Segment 的 Redo records.  这点由 Log Service (简称ls) 来分发保障. 

正常情况下, Fetcher 会向 ls 发起请求, 获取属于该 Segment 的 Redo records. 
获取方式分为2种, 一种是单个 Segment 依次获取, 另一种为 batch 模式, 即多个 Segment 同时获取. 

当从 ls 获取失败时, 原因只有一种, 即当前 segment 副本为慢节点, 多数派 LSN 已经远超其值了. 
此时 Fetcher 会退化为 单个 Segment 方式, 并且从 ls 转向 peer 去获取. 
当 LSN 追上后, 会从新转为从 ls 获取.

每获取一段 Redo records 后, 会将其以 LogBlock 结构存储, 并以队列的方式执行流转到 Parser. 

### Parser

Parser 的核心功能就是将 LogBlock 中的 redo records 数据流依次解析为 record, 并将其放入 Page 的队列中.
然后将 LogBlock 以队列的方式流转到 GC.

Parser 还负责向 psm 请求 Cluster 的元数据, space 的元数据, page 的逻辑和物理 offset 映射等;
其作用有2个: 
1. 集中元数据的管理和处理.
2. 流控: 控制对 psm 的请求QPS.

### GC

GC 分为 3 部分:
1. Append
2. GC Page
3. dblwr

其核心作用就是将 page 的 redo records 应用到 page 上.

#### Append

Append 的主要功能就是将 LogBlock 的数据以追加的形式先写入 append file 中. 
此时会将后续 GC 依赖的元数据一起写入, 比如: page 的 逻辑和物理 offset 映射.

Append 是可选的流程, 通过 gflags 参数控制; 默认为开启状态.

当 LogBlock 写入 append file 后, 以队列的方式流转到 GC Page.


#### GC Page

GC Page 的核心功能就是将 LogBlock 涉及 page 的 redo records 应用到 page 上.
其大致流程如下:
1. 读取 page 的数据.
2. 应用不超过 cn_lowest_lsn 的 redo records 到 page 上.
3. 写回 page 的数据.

> cn_lowest_lsn: 是指上游 mysql innodb 依赖的最低 LSN.

#### dblwr

dblwr 的核心作用就是 write page 时, 保障 16kb 的 page 可以原子写入, 发送异常时可以恢复 page 数据. 
其大致流程如下:
1. Gc Page 时, read page 先从 dblwr 读取, 如果没有, 则从 engine 中读取.
2. Gc Page 时, write page 将 page 写入 dblwr. 

##### dblwr dump

当一个 dblwr 写满后, 会执行 seal 固话操作. 

dblwr dump 的作用就按照时间顺序, 将 seal dblwr file 中写入的 page 依次读取后, 写回 engine.


### RBIO

RBIO 就是提供对外的读 page 接口. 可以理解为 mysql innodb page 读取接口.

ps 根据请求中的元数据定位到 Segment, 然后读取 Page 的数据, 并根据请求的约束, 应用 page records 到 page 上, 最后返回结果.

通过 base page + page records 可以返回多个 LSN 的 page 版本.


### Recover

当出现磁盘损坏或者物理机宕机, 或者均衡副本时, 会在 ps 中新创建一个副本 Segment. 

新创建的 Segment 根据 psm 中的元数据可以判断是否需要从 peer 恢复数据. 
当一个 Segment 存在历史数据时, 就需要执行恢复操作. 

恢复过程中, Segment 的写入流程不阻塞. 

恢复的核心流程如下:
当前 engine 的类型为 idb file 类型, 因此通过遍历 idb file 中的 offset, 去远端读取物理页数据.

其约束满足:
恢复后的物理页LSN >= Page Gc LSN

其内部还有其他功能:
- 提供周期性的数据扫描, 检查 page 的数据正确性.
- 提供物理页的读取. 
- 提供 append file redo log 的读取.

### Compress

Compress 分为压缩和 trim. 

压缩就是将 page 的数据按照 4k 对齐压缩, 然后通过 PUNCH_HOLE 的方式释放 4k 的尾部空间.

trim 就是当前某个 space 被删除后, 如果该 space 的 page 在物理页的位置未被复用时, 通过 PUNCH_HOLE 的方式释放 16k 的空间.


### Control

Control 中运行了一些全局的任务和管理控制等:
1. 管理控制接口: 创建/删除 Segment 等.
2. Segment 和 psm 的心跳.
3. 周期性采集监控信息等.