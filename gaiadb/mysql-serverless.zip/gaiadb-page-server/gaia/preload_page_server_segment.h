/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/preload_page_server_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class PreLoadPageServerSegment : public Command {
public:
    PreLoadPageServerSegment() {
        SetName("preload-ps-segment");
        SetDesc("create a segment replica on page server for load");
        SetDescCn("在存储服务器上预创建分片副本用于加载");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "cluster id of the segment to create/load", kstring);
        AddRequiredArgOption("segment-id", NULL, 's', "id of the segment to create/load", kuint32_t);
        AddRequiredArgOption("manager-address", NULL, 'M',
                "manager address of the segment to load", kstring);
        AddRequiredArgOption("size", &_long_opt_val, kOptMax + 2, "size of the segment to create/load", kint64_t);
        AddRequiredArgOption("store-id", &_long_opt_val, kOptMax + 3,
                "the segment will be created/loaded on store, if specified",
                kuint32_t, kGroup2Scope);

        AddExample("-a <ip> -p <port> -c gaia-test-perf -s 1 --manager-address \"bns://xxx\" --size 42949672960");
        AddExample("-a <ip> -p <port> -c gaia-test-perf -s 1 "
                "--manager-address \"bns://xxx\" --size 42949672960  --store-id 1");
    }
    virtual ~PreLoadPageServerSegment() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id = std::strtoul(opt, NULL, 10);
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 2:
                _size = std::strtoll(opt, NULL, 10);
                break;
            case kOptMax + 3:
                _store_id = std::strtol(opt, NULL, 10);
                break;
            //case kOptMax + 4:
                //_is_load = opt ? !!std::strtol(opt, NULL, 10) : true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::PreLoadSegmentResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    uint32_t _segment_id {0};
    std::string _manager_address {};
    int64_t _size {-1};
    int32_t _store_id {-1};
    //bool _is_load {false};
};

}
}
