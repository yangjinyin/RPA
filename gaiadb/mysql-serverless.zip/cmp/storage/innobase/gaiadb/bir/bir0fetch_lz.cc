#include "bir0async_binlog.h"
#include <ctype.h>
#include <base/base64.h>
#include <openssl/hmac.h>
#include <baidu/rpc/uri.h>
#include <baidu/rpc/details/http_message.h>
#include <openssl/aes.h>
#include "gaiadb/common/global_flags.h"
#include "rpl0rpl.h"
#include "rpl0parse.h"
#include "gaiadb/redo_fetch/fetch_mdc_object.h"
#include "gaiadb/redo_fetch/fetch_mdc_utils.h"

namespace bir {

int32_t BirAsyncBinlog::fetch_lz_log(rpl::LogServerInfo &ls_info, lsn_t end_lsn) {
  baidu::rpc::Controller cntl;
  log_service::pread_request request;
  log_service::pread_response response;

  if (refresh_replicas(ls_info)) {
    return FETCH_ERROR::ERROR;
  }
  lsn_t start_lsn = fetch_lsn_;

  auto &ls_replica = ls_info.get_replica();

  uint64_t request_lsn = 
      ut_uint64_align_down(start_lsn, OS_FILE_LOG_BLOCK_SIZE);
  uint64_t offset = translate_lsn_to_offset(request_lsn);
  lsn_t target_lsn = end_lsn == 0 ?
    request_lsn + gaiadb::redo_fetch::ut_uintx_align_up<uint64_t>(
      gaiadb::redo_fetch::FLAGS_gaia_fetch_lz_size, OS_FILE_LOG_BLOCK_SIZE) :
    end_lsn;
  uint64_t fetch_size = target_lsn - request_lsn;
  if (fetch_size + offset > LOG_FILE_MAX_SIZE) {
    fetch_size = LOG_FILE_MAX_SIZE - offset;
  }
  request.set_cluster_id(psmcli->get_cluster_id());
  request.set_offset(offset);
  request.set_len(fetch_size);
  request.set_lsn(request_lsn);

  bir_client_.Call(&cntl, ls_replica.addr, &lz_stub::pread, &request,
      &response, nullptr);

  if (cntl.Failed()) {
    LOG(WARNING) << "Gaia binlog recover fetch log failed: rpc "
      "failed on requesting logs at lsn = "
      << start_lsn << "," <<  cntl.ErrorText();
    ++ls_info.fetch_invalid_count;
    return FETCH_ERROR::ERROR;
  }

  if (response.status().code() == log_service::GIE_NOT_EXIST) {
    LOG(WARNING) << "Gaia binlog recover fetch log failed: log not exist, "
      "lsn = " << start_lsn;
    ++ls_info.fetch_invalid_count;
    return FETCH_ERROR::NOT_FOUND_LSN;
  }

  const uint32_t real_block_num =
    calc_redo_buf_real_block_num(response.buffer());
  const uint32_t expect_block_num = response.read_size() / OS_FILE_LOG_BLOCK_SIZE;
  if (expect_block_num > real_block_num) {
    LOG(TRACE) << "Gaia bir binlog recover fetch lz log miss block, "
               << "expect_block_num: " << expect_block_num
               << ", real_block_num: " << real_block_num;
  }
  if (real_block_num == 0) {
    LOG(NOTICE) << "Gaia bir binlog recover fetch lz log failed: no valid data.";
    return FETCH_ERROR::NOT_FOUND_LSN;
  }

  lsn_t ls_vdl = log_get_vdl(*log_sys);

  copy_to_fetch_log_buf(
      response.buffer().c_str(), real_block_num, ls_vdl, end_lsn);
  return FETCH_ERROR::SUCCESS;
}
}
