const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const net = require('net');

const PORT = Number(process.env.PORT || 8100);
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const CLUSTER_CONF = path.join(ROOT, 'cluster.conf');
const EXCLUDE_CLUSTERS = path.join(ROOT, 'exclude.clusters');
const SERVICE_PATH = 'BAIDU_DBA_DBA-GaiaDB_gaia_public_multips';
const TEST_SERVICE_PATH = 'BAIDU_DBA_DBA-GaiaDB_gaia_online_multips';
const PROXY_START_PORT = 8600;
const RECOVERY_VAR_NAMES = [
    'psvr_recover_left_size',
    'psvr_recover_expect_finish_time_s',
];
const RECOVERY_FLAG_NAMES = [
    'psvr_recover_dst_store_max_speed',
    'psvr_recover_src_store_max_speed',
    'psvr_recover_read_store_max_speed',
];
const proxyTargets = new Map();
const proxyServers = new Map();
const SAMPLE_CLUSTERS = [
    'multips00.gaia.gzbh',
    'multips00.gaia.whzj',
    'multips00.gaia.gzdt',
    'multips00.gaia.bdjl',
    'multips00.gaia.cdmt',
    'multips03.gaia.gajl',
];

function runCommand(command, args, timeout = 15000, maxBuffer = 20 * 1024 * 1024) {
    return new Promise((resolve, reject) => {
        execFile(command, args, { timeout, maxBuffer }, (error, stdout, stderr) => {
            if (error) {
                error.stderr = stderr;
                error.stdout = stdout;
                reject(error);
                return;
            }
            resolve(stdout);
        });
    });
}

function throwNodeStatusError(failures) {
    if (!failures.length) {
        return;
    }

    const details = failures
        .map((item) => `${item.addr || '未知节点'}(${item.code || '状态码缺失'})`)
        .join('、');
    const error = new Error(`节点状态异常：${details}`);
    error.statusCode = 502;
    throw error;
}

function collectJsonNodeStatusFailures(data) {
    const failures = [];

    function walk(value) {
        if (Array.isArray(value)) {
            value.forEach(walk);
            return;
        }
        if (!value || typeof value !== 'object') {
            return;
        }

        const serverStatuses = value.server_status || value.serverStatus;
        if (Array.isArray(serverStatuses)) {
            serverStatuses.forEach((item) => {
                const code = item && item.status && item.status.status
                    ? item.status.status.code
                    : null;
                if (code !== 'SUCCESS') {
                    failures.push({
                        addr: item && (item.addr || item.address),
                        code,
                    });
                }
            });
        }

        Object.values(value).forEach(walk);
    }

    walk(data);
    return failures;
}

function validatePbNodeStatuses(text) {
    const failures = [];
    const stack = [];
    let currentNode = null;

    String(text || '').split(/\r?\n/).forEach((line) => {
        const trimmed = line.trim();
        const opening = trimmed.match(/^([a-zA-Z0-9_]+)\s*\{$/);
        if (opening) {
            if (opening[1] === 'server_status') {
                currentNode = { addr: '', code: null };
            }
            stack.push(opening[1]);
            return;
        }

        if (trimmed === '}') {
            const closing = stack.pop();
            if (closing === 'server_status' && currentNode) {
                if (currentNode.code !== 'SUCCESS') {
                    failures.push(currentNode);
                }
                currentNode = null;
            }
            return;
        }

        if (!currentNode) {
            return;
        }
        if (stack[stack.length - 1] === 'server_status') {
            const addrMatch = trimmed.match(/^addr:\s*"?([^"]+)"?$/);
            if (addrMatch) {
                currentNode.addr = addrMatch[1];
            }
        }
        if (stack.slice(-2).join('.') === 'status.status') {
            const codeMatch = trimmed.match(/^code:\s*"?([^"\s]+)"?/);
            if (codeMatch) {
                currentNode.code = codeMatch[1];
            }
        }
    });

    throwNodeStatusError(failures);
}

function sendJson(res, statusCode, payload) {
    const body = JSON.stringify(payload);
    res.writeHead(statusCode, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
        'Cache-Control': 'no-store',
    });
    res.end(body);
}

function readJsonBody(req) {
    return new Promise((resolve, reject) => {
        let body = '';
        req.on('data', (chunk) => {
            body += chunk;
            if (body.length > 1024 * 1024) {
                reject(new Error('请求体过大'));
                req.destroy();
            }
        });
        req.on('end', () => {
            try {
                resolve(body ? JSON.parse(body) : {});
            } catch (error) {
                reject(error);
            }
        });
        req.on('error', reject);
    });
}

function sendFile(res, filePath) {
    fs.readFile(filePath, (error, data) => {
        if (error) {
            res.writeHead(error.code === 'ENOENT' ? 404 : 500, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end(error.code === 'ENOENT' ? 'Not found' : 'Server error');
            return;
        }

        const ext = path.extname(filePath);
        const contentTypes = {
            '.html': 'text/html; charset=utf-8',
            '.css': 'text/css; charset=utf-8',
            '.js': 'application/javascript; charset=utf-8',
        };
        res.writeHead(200, { 'Content-Type': contentTypes[ext] || 'application/octet-stream' });
        res.end(data);
    });
}

function parseClusterOutput(output) {
    return output
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter(Boolean);
}

function readExcludedClusters() {
    try {
        const content = fs.readFileSync(EXCLUDE_CLUSTERS, 'utf8');
        return new Set(content
            .split(/\r?\n/)
            .map((line) => line.trim())
            .filter((line) => line && !line.startsWith('#')));
    } catch (_) {
        return new Set();
    }
}

function filterExcludedClusters(clusters) {
    const excludedClusters = readExcludedClusters();
    return {
        clusters: clusters.filter((cluster) => !excludedClusters.has(cluster)),
        excludedCount: clusters.filter((cluster) => excludedClusters.has(cluster)).length,
    };
}

function getLocalIp() {
    const interfaces = os.networkInterfaces();
    for (const addresses of Object.values(interfaces)) {
        for (const address of addresses || []) {
            if (address.family === 'IPv4' && !address.internal) {
                return address.address;
            }
        }
    }
    return '127.0.0.1';
}

function normalizeMode(mode) {
    return mode === 'test' ? 'test' : 'online';
}

function readServicePath(mode = 'online') {
    if (normalizeMode(mode) === 'test') {
        return TEST_SERVICE_PATH;
    }

    try {
        const content = fs.readFileSync(CLUSTER_CONF, 'utf8');
        const match = content.match(/get_services_by_path\s+([^\s]+)/);
        return match ? match[1] : SERVICE_PATH;
    } catch (_) {
        return SERVICE_PATH;
    }
}

async function getClusters(mode = 'online') {
    const normalizedMode = normalizeMode(mode);
    const servicePath = readServicePath(normalizedMode);
    try {
        const output = await runCommand('get_services_by_path', [servicePath]);
        const result = filterExcludedClusters(parseClusterOutput(output));
        return {
            ...result,
            mode: normalizedMode,
            source: 'command',
            servicePath,
        };
    } catch (error) {
        const result = filterExcludedClusters(SAMPLE_CLUSTERS);
        return {
            ...result,
            mode: normalizedMode,
            source: 'sample',
            servicePath,
            warning: [
                'get_services_by_path 执行失败，当前展示 make.MD 中的示例集群。',
                error.stderr || error.message,
            ].join(''),
        };
    }
}

function validateCluster(cluster) {
    if (!/^[a-zA-Z0-9._-]+$/.test(cluster)) {
        const error = new Error('集群名称包含非法字符');
        error.statusCode = 400;
        throw error;
    }
}

async function getInstanceByServiceCount(cluster) {
    validateCluster(cluster);

    const output = await runCommand('bash', [
        '-lc',
        `get_instance_by_service ${cluster} -a | awk '{print $2}'`,
    ]);
    return parseClusterOutput(output).length;
}

function parseHostPort(target) {
    const match = String(target || '').match(/^([^:\s]+):(\d+)$/);
    if (!match) {
        return null;
    }
    const port = Number(match[2]);
    if (!Number.isInteger(port) || port <= 0 || port > 65535) {
        return null;
    }
    return { host: match[1], port };
}

function createProxyServer(target, localPort) {
    const parsed = parseHostPort(target);
    if (!parsed) {
        throw new Error(`非法节点地址: ${target}`);
    }

    const proxy = net.createServer((clientSocket) => {
        const upstreamSocket = net.connect(parsed.port, parsed.host);
        clientSocket.pipe(upstreamSocket);
        upstreamSocket.pipe(clientSocket);

        const close = () => {
            clientSocket.destroy();
            upstreamSocket.destroy();
        };
        clientSocket.on('error', close);
        upstreamSocket.on('error', close);
    });

    proxy.on('error', (error) => {
        console.error(`Proxy ${localPort} -> ${target} error:`, error.message);
    });

    proxy.listen(localPort, '0.0.0.0');
    return proxy;
}

function ensureProxyTargets(targets) {
    const result = [];
    const uniqueTargets = [...new Set(targets)].filter((target) => parseHostPort(target));

    uniqueTargets.forEach((target) => {
        if (!proxyTargets.has(target)) {
            const localPort = PROXY_START_PORT + proxyTargets.size;
            const server = createProxyServer(target, localPort);
            proxyTargets.set(target, localPort);
            proxyServers.set(localPort, server);
        }
        result.push({
            target,
            localIp: getLocalIp(),
            localPort: proxyTargets.get(target),
            url: `http://${getLocalIp()}:${proxyTargets.get(target)}`,
        });
    });

    return result;
}

function requestText(url, timeout = 5000) {
    return new Promise((resolve, reject) => {
        const req = http.get(url, (response) => {
            let body = '';
            response.setEncoding('utf8');
            response.on('data', (chunk) => {
                body += chunk;
            });
            response.on('end', () => resolve(body.trim()));
        });
        req.setTimeout(timeout, () => {
            req.destroy(new Error(`请求超时: ${url}`));
        });
        req.on('error', reject);
    });
}

function normalizeVarValue(value) {
    const text = String(value || '');
    if (/\[E\d+\]|Fail to find any bvar/i.test(text)) {
        return '';
    }

    const match = text.match(/-?\d+(?:\.\d+)?/g);
    if (!match || !match.length) {
        return '';
    }
    return match[match.length - 1];
}

function normalizeFlagValue(value) {
    const lines = String(value || '').split('\n');
    const dataLine = lines.find((line) => line.includes('|') && !line.startsWith('Name |'));
    if (!dataLine) {
        return '';
    }

    const columns = dataLine.split('|').map((column) => column.trim());
    const match = String(columns[1] || '').match(/-?\d+(?:\.\d+)?/);
    return match ? match[0] : '';
}

async function getNodeRecoveryVars(target) {
    const parsed = parseHostPort(target);
    if (!parsed) {
        throw new Error(`非法节点地址: ${target}`);
    }

    const varPairs = RECOVERY_VAR_NAMES.map(async (name) => {
        const value = await requestText(`http://${target}//vars/${name}`);
        return [name, normalizeVarValue(value)];
    });
    const flagPairs = RECOVERY_FLAG_NAMES.map(async (name) => {
        const value = await requestText(`http://${target}/flags/${name}?getvalue`);
        return [name, normalizeFlagValue(value)];
    });
    const pairs = await Promise.all([...varPairs, ...flagPairs]);
    return Object.fromEntries(pairs);
}

async function getRecoveryVars(targets) {
    const uniqueTargets = [...new Set(targets)].filter((target) => parseHostPort(target));
    const rows = await Promise.all(uniqueTargets.map(async (target) => {
        try {
            return { target, vars: await getNodeRecoveryVars(target) };
        } catch (error) {
            return { target, error: error.message, vars: {} };
        }
    }));
    return rows;
}

async function getStores(cluster) {
    validateCluster(cluster);

    const output = await runCommand(path.join(ROOT, 'gaia'), [
        'list-ps-store',
        '--cluster-addr',
        `bns://${cluster}:6000`,
        '-o',
        'json',
    ], 30000);

    try {
        const data = JSON.parse(output);
        return { data, nodeErrors: collectJsonNodeStatusFailures(data) };
    } catch (_) {
        return { data: { raw: output }, nodeErrors: [] };
    }
}

function parseSegmentManagers(text) {
    const managers = [];
    String(text || '').split(/\r?\n/).forEach((line) => {
        const match = line.trim().match(/^manager_address:\s*(.+)$/);
        if (match) {
            managers.push(match[1].trim().replace(/^"|"$/g, ''));
        }
    });
    return [...new Set(managers)].filter(Boolean);
}

function sumSegmentsUsedExtentNum(segments) {
    if (!Array.isArray(segments) || !segments.length) {
        return null;
    }

    let sum = 0;
    for (const segment of segments) {
        if (!segment || typeof segment !== 'object') {
            continue;
        }
        const total = Number(segment.total_extent_num);
        const free = Number(segment.free_extent_num);
        if (!Number.isFinite(total) || !Number.isFinite(free)) {
            continue;
        }
        sum += total - free;
    }
    return sum;
}

function getExtentStats(response) {
    const hasTopLevelUsed = Object.prototype.hasOwnProperty.call(response || {}, 'used_extent_num')
        && response.used_extent_num !== null
        && response.used_extent_num !== '';
    const hasTopLevelRecycling = Object.prototype.hasOwnProperty.call(response || {}, 'recycling_extent_num')
        && response.recycling_extent_num !== null
        && response.recycling_extent_num !== '';

    let usedExtentNum = null;
    if (hasTopLevelUsed) {
        usedExtentNum = Number(response.used_extent_num);
        if (!Number.isFinite(usedExtentNum)) {
            throw new Error('used_extent_num 不是有效数字');
        }
    } else {
        usedExtentNum = sumSegmentsUsedExtentNum(response && response.segments);
    }

    let recyclingExtentNum = null;
    if (hasTopLevelRecycling) {
        recyclingExtentNum = Number(response.recycling_extent_num);
        if (!Number.isFinite(recyclingExtentNum)) {
            throw new Error('recycling_extent_num 不是有效数字');
        }
    }

    return {
        hasUsedExtentNum: usedExtentNum !== null,
        usedExtentNum,
        hasRecyclingExtentNum: hasTopLevelRecycling,
        recyclingExtentNum,
    };
}

function sumPresentExtentStats(rows, key, presenceKey) {
    const values = rows
        .filter((row) => row[presenceKey])
        .map((row) => row[key]);
    return values.length ? values.reduce((sum, value) => sum + value, 0) : null;
}

async function getPoolAllocatedCapacity(managers) {
    const rows = await Promise.all(managers.map(async (manager) => {
        try {
            const output = await runCommand(path.join(ROOT, 'gaia'), [
                'list-segment',
                '-M',
                manager,
                '--not-show-segments',
                '-o',
                'json',
            ], 120000, 128 * 1024 * 1024);
            return { manager, ...getExtentStats(JSON.parse(output)) };
        } catch (error) {
            return {
                manager,
                hasUsedExtentNum: false,
                usedExtentNum: null,
                hasRecyclingExtentNum: false,
                recyclingExtentNum: null,
                error: error.stderr || error.message,
            };
        }
    }));

    return {
        managerCount: managers.length,
        usedExtentNum: sumPresentExtentStats(rows, 'usedExtentNum', 'hasUsedExtentNum'),
        recyclingExtentNum: sumPresentExtentStats(
            rows,
            'recyclingExtentNum',
            'hasRecyclingExtentNum',
        ),
        managerStats: rows,
        errors: rows.filter((row) => row.error).map((row) => ({
            manager: row.manager,
            error: row.error,
        })),
    };
}

async function getSegments(cluster) {
    validateCluster(cluster);

    const data = await runCommand(path.join(ROOT, 'gaia'), [
        'list-ps-status',
        '-m',
        '--cluster-addr',
        `bns://${cluster}:6000`,
        '-o',
        'pb',
    ], 120000, 512 * 1024 * 1024);
    validatePbNodeStatuses(data);
    const managers = parseSegmentManagers(data);
    const poolCapacity = await getPoolAllocatedCapacity(managers);
    return { data, poolCapacity };
}

async function getRecovery(cluster) {
    validateCluster(cluster);

    const output = await runCommand(path.join(ROOT, 'gaia'), [
        'list-ps-recovery',
        '-m',
        '--cluster-addr',
        `bns://${cluster}:6000`,
        '-o',
        'json',
    ], 120000, 512 * 1024 * 1024);

    try {
        const data = JSON.parse(output);
        return { data, nodeErrors: collectJsonNodeStatusFailures(data) };
    } catch (_) {
        return { data: { raw: output }, nodeErrors: [] };
    }
}

function handleApi(req, res, pathname) {
    if (pathname === '/api/proxies' && req.method === 'POST') {
        readJsonBody(req)
            .then((body) => {
                const proxies = ensureProxyTargets(Array.isArray(body.targets) ? body.targets : []);
                sendJson(res, 200, { proxies });
            })
            .catch((error) => sendJson(res, 400, { error: error.message }));
        return true;
    }

    if (pathname === '/api/recovery-vars' && req.method === 'POST') {
        readJsonBody(req)
            .then((body) => getRecoveryVars(Array.isArray(body.targets) ? body.targets : []))
            .then((vars) => sendJson(res, 200, { vars }))
            .catch((error) => sendJson(res, 400, { error: error.message }));
        return true;
    }

    if (pathname === '/api/clusters') {
        const url = new URL(req.url, `http://${req.headers.host}`);
        const mode = normalizeMode(url.searchParams.get('mode') || 'online');
        getClusters(mode)
            .then((payload) => sendJson(res, 200, payload))
            .catch((error) => sendJson(res, 500, { error: error.message }));
        return true;
    }

    if (pathname === '/api/stores') {
        const url = new URL(req.url, `http://${req.headers.host}`);
        const cluster = url.searchParams.get('cluster') || '';
        getStores(cluster)
            .then((result) => sendJson(res, 200, {
                cluster,
                data: result.data,
                nodeErrors: result.nodeErrors,
            }))
            .catch((error) => sendJson(res, error.statusCode || 500, {
                error: error.message,
                stderr: error.stderr,
                stdout: error.stdout,
            }));
        return true;
    }

    if (pathname === '/api/instance-count') {
        const url = new URL(req.url, `http://${req.headers.host}`);
        const cluster = url.searchParams.get('cluster') || '';
        getInstanceByServiceCount(cluster)
            .then((count) => sendJson(res, 200, { cluster, count }))
            .catch((error) => sendJson(res, error.statusCode || 500, {
                error: error.message,
                stderr: error.stderr,
                stdout: error.stdout,
            }));
        return true;
    }

    if (pathname === '/api/segments') {
        const url = new URL(req.url, `http://${req.headers.host}`);
        const cluster = url.searchParams.get('cluster') || '';
        getSegments(cluster)
            .then((payload) => sendJson(res, 200, { cluster, ...payload }))
            .catch((error) => sendJson(res, error.statusCode || 500, {
                error: error.message,
                stderr: error.stderr,
                stdout: error.stdout,
            }));
        return true;
    }

    if (pathname === '/api/recovery') {
        const url = new URL(req.url, `http://${req.headers.host}`);
        const cluster = url.searchParams.get('cluster') || '';
        getRecovery(cluster)
            .then((result) => sendJson(res, 200, {
                cluster,
                data: result.data,
                nodeErrors: result.nodeErrors,
            }))
            .catch((error) => sendJson(res, error.statusCode || 500, {
                error: error.message,
                stderr: error.stderr,
                stdout: error.stdout,
            }));
        return true;
    }

    return false;
}

const server = http.createServer((req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (handleApi(req, res, url.pathname)) {
        return;
    }

    const requested = url.pathname === '/' ? '/index.html' : url.pathname;
    const filePath = path.normalize(path.join(PUBLIC_DIR, requested));

    if (!filePath.startsWith(PUBLIC_DIR)) {
        res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Forbidden');
        return;
    }

    sendFile(res, filePath);
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`Gaia PS Store Monitor: http://${getLocalIp()}:${PORT}`);
});
