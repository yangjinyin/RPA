/***************************************************************************
* Copyright (c) baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/dblwr.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/dblwr.h"
#include "psvr/dbengine.h"
#include "psvr/page_op.h"
#include "psvr/config.h"
#include "psvr/append_block.h"
#include "psvr/stat.h"
#include <sys/mman.h>

namespace psvr {

static const char* dblwr_tmp_ext_name = ".tmp";
static const char* dblwr_latest_file_name = "latest";

static bvar::Adder<int64_t> l_stat_dblwr_buf_mem_bytes("psvr_dblwr_buf_mem_bytes");
static bvar::LatencyRecorder l_stat_dblwr_write_lat("psvr_dblwr_wrte");
static bvar::LatencyRecorder l_stat_dblwr_read_lat("psvr_dblwr_read");
static bvar::LatencyRecorder l_stat_dblwr_seal_lat("psvr_dblwr_seal");

Dblwr::Dblwr()
    : _max_page_num(0),
    _file_no(0),
    _frames(nullptr),
    _frames_len(0),
    _latest_fd(-1),
    _buf(nullptr),
    _latest_create_time(0),
    _latest_lsn(0),
    _bufs_size(0),
    _in_dump() {
}

Dblwr::~Dblwr() {
    if (_frames) {
        l_stat_dblwr_buf_mem_bytes << -_frames_len;
        munmap(_frames, _frames_len);
        _frames = nullptr;
    }
    if (_latest_fd >= 0) {
        close(_latest_fd);
        _latest_fd = -1;
    }
}

db::Status Dblwr::Open(uint32_t max_page_num, const std::string& db_path,
        gaia_apply::lsn_t* max_ckp_lsn) {
    Timer timer(base::Timer::STARTED);
    _max_page_num = calc_dblwr_page_num(max_page_num);
    db::Status st;
    _db_path = db_path;

    *max_ckp_lsn = 0;

    std::unique_lock lk(_shared_mutex);

    std::error_code ec;
    if (!std::filesystem::exists(_db_path, ec)) {
        if (!std::filesystem::create_directories(_db_path, ec)) {
            st.Reset(db::GetErrCode(), "create dblwr path:%s failed, %m", _db_path.c_str());
            return st;
        }
        st = db::sync_directoryx(std::filesystem::path(_db_path).parent_path().c_str());
        if (!st.IsOk()) {
            return st;
        }
    }

    if (ec) {
        st.Reset(db::Code::kIOError, "create dblwr path:%s failed, %m", _db_path.c_str());
        return st;
    }

    std::vector<uint64_t> fno_vec;
    for (auto& fname : std::filesystem::directory_iterator(_db_path, ec)) {
        if (fname.is_directory()) {
            LOG(WARNING) << "found a not dblwr file,"
                << " path:[" << _db_path
                << "] name:[" << fname.path()
                << "] " << ec.message();
            continue;
        }
        const std::filesystem::path& fpath = fname.path();
        if (fpath.extension() == dblwr_tmp_ext_name) {
            LOG(WARNING) << "dblwr tmp file,"
                << " path:[" << _db_path
                << "] name:[" << fpath
                << "]";
            continue;
        }
        if (fpath.filename() == dblwr_latest_file_name) {
            continue;
        }
        const std::filesystem::path& name = fpath.filename();
        uint64_t fno = std::strtoull(name.c_str(), nullptr, 10);
        if (std::to_string(fno) != name.native()) {
            LOG(WARNING) << "unknown file,"
                << " path:[" << _db_path
                << "] fno:[" << fno
                << "] name:[" << name
                << "]";
            st.Reset(db::Code::kInvalid, "unknown dblwr file:%s", fpath.c_str());
            return st;
        }

        fno_vec.push_back(fno);
    }

    if (ec) {
        st.Reset(db::Code::kIOError, "iterator dblwr path:%s failed, %m", _db_path.c_str());
        return st;
    }

    if (fno_vec.empty()) {
        LOG(NOTICE) << "init dblwr ok, not files,"
            << " db_path:[" << db_path
            << "] cost_time:[" << timer.u_elapsed()
            << "]";
        return st;
    }

    std::sort(fno_vec.begin(), fno_vec.end());  // sort by fno asc, 0 1 2 3 4 5 6 7 8 9
    const uint64_t min_fno = fno_vec.front();
    const uint64_t max_fno = fno_vec.back();
    for (size_t i = 0; i < fno_vec.size(); ++i) {
        uint64_t fno = fno_vec[i];
        st = OpenFile(fno);
        if (!st.IsOk()) {
            // delete by desc
            for (size_t j = fno_vec.size(); j > i; --j) {
                fno = fno_vec[j - 1];
                st = RemoveFile(fno);
                if (!st.IsOk()) {
                    return st;
                }
            }
            st.Reset(db::Code::kOk, "dblwr check failed, remove it");
            LOG(WARNING) << "init dblwr failed, should redo it,"
                << " files_num:" << fno_vec.size()
                << "] min_fno:[" << min_fno
                << "] max_fno:[" << max_fno
                << "] err_fno:[" << fno_vec[i]
                << "]";
            break;
        }
    }

    for (auto& buf : _bufs) {
        if (buf->footer_ptr->ckp_lsn[1] > 0) {
            *max_ckp_lsn = buf->footer_ptr->ckp_lsn[1];
            break;
        }
    }

    _latest_lsn(*max_ckp_lsn, true);

    LOG(NOTICE) << "init dblwr ok,"
        << " db_path:[" << db_path
        << "] files_num:[" << fno_vec.size()
        << "] min_fno:[" << min_fno
        << "] max_fno:[" << max_fno
        << "] max_ckp_lsn:[" << *max_ckp_lsn
        << "] cost_time:[" << timer.u_elapsed()
        << "]";
    return st;
}

db::Status Dblwr::OpenFile(uint64_t fno) {
    db::Status st;
    std::string file_name = base::string_printf("%s/%lu", _db_path.c_str(), fno);
    int fd = open(file_name.c_str(), O_RDONLY, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        st.Reset(db::GetErrCode(), "open dblwr file:%s failed, %m", file_name.c_str());
        return st;
    }

    ssize_t file_size = 0;
    if (!db::get_file_size(fd, &file_size)) {
        close(fd);
        st.Reset(db::GetErrCode(), "get dblwr file:%s size failed, %m", file_name.c_str());
        return st;
    }

    if (file_size < kDblwrFooterSize) {
        close(fd);
        st.Reset(db::GetErrCode(), "dblwr file:%s size invalid, %m", file_name.c_str());
        return st;
    }

    ssize_t buf_size = file_size - kDblwrFooterSize;

    DblwrBufPtr dblwr_buf = AllocBufByBufSize(fno, buf_size);
    if (!dblwr_buf) {
        close(fd);
        st.Reset(db::GetErrCode(), "dblwr file:%s alloc size:%ld failed, %m",
                file_name.c_str(), buf_size);
        return st;
    }

    // read footer from file into the struct member; footer_ptr still points to mmap tail
    st = db::preadx(fd, &dblwr_buf->footer, kDblwrFooterSize, file_size - kDblwrFooterSize);
    if (!st.IsOk()) {
        close(fd);
        st.ResetMsg("read dblwr file:%s footer size:%ld failed, %m",
                file_name.c_str(), kDblwrFooterSize);
        return st;
    }

    // redirect footer_ptr to the struct member (this is an immutable loaded buf)
    dblwr_buf->footer_ptr = &dblwr_buf->footer;

    if (dblwr_buf->footer_ptr->fno != fno) {
        close(fd);
        st.Reset(db::GetErrCode(), "file:%s no mismatch:%lu, %m",
                file_name.c_str(), dblwr_buf->footer_ptr->fno);
        return st;
    }

    PSVR_ASSERT_U(dblwr_buf->footer_ptr->page_num <= dblwr_buf->footer_ptr->max_page_num);
    ssize_t buf_size2 = dblwr_buf->footer_ptr->page_num * gaia_apply::FLAGS_univ_page_size;
    if (dblwr_buf->frames_len < buf_size2) {
        close(fd);
        st.Reset(db::GetErrCode(), "file:%s size:%ld mismatch buf size:%lu",
                file_name.c_str(), dblwr_buf->frames_len, buf_size2);
        return st;
    }

    st = db::preadx(fd, dblwr_buf->frames, buf_size, 0);
    if (!st.IsOk()) {
        close(fd);
        st.ResetMsg("read dblwr file:%s page buf size:%u failed, %m",
                file_name.c_str(), dblwr_buf->footer_ptr->page_num);
        return st;
    }

    // init hash map
    for (uint32_t i = 0; i < dblwr_buf->footer_ptr->page_num; ++i) {
        gaia_apply::byte* frame = dblwr_buf->frames + (i * gaia_apply::FLAGS_univ_page_size);

        bool is_empty = false;
        if (page_is_corrupted(frame, gaia_apply::FLAGS_univ_page_size, &is_empty)) {
            close(fd);
            st.Reset(db::GetErrCode(), "check dblwr file:%s page slot:%u failed",
                    file_name.c_str(), i);
            return st;
        }

        gaia_apply::space_id_t space_id = gaia_apply::page_get_space_id(frame);
        gaia_apply::page_no_t page_no = gaia_apply::page_get_page_no(frame);

        dblwr_buf->pages_to_slot[u32tou64(space_id, page_no)].push_back(i);
        dblwr_buf->offs_to_slot[dblwr_buf->footer_ptr->offs[i]] = i;
    }

    dblwr_buf->fd = fd;
    dblwr_buf->frames = nullptr;

    _bufs.emplace_front(dblwr_buf);
    _bufs_size.fetch_add(1, std::memory_order_relaxed);
    LOG(TRACE) << "add dblwr file ok, name:[" << file_name << "]";

    if (fno > _file_no) {
        _file_no = fno;
    }
    return st;
}

db::Status Dblwr::RemoveFile(uint64_t fno) {
    db::Status st;
    std::string file_name = base::string_printf("%s/%lu",
            _db_path.c_str(), fno);
    std::error_code ec;
    bool ret = std::filesystem::remove(file_name, ec);
    if (ec) {
        st.Reset(db::GetErrCode(), "remove dblwr file:%s failed, %s",
                file_name.c_str(), ec.message().c_str());
        return st;
    }
    LOG_EVERY_SECOND(NOTICE) << "remove dblwr file ok,"
        << " file:[" << file_name
        << "] file_exists:[" << ret
        << "]";
    if (ret) {
        st = db::sync_directoryx(_db_path.c_str());
    }
    return st;
}

DblwrBufPtr Dblwr::AllocBuf() {
    PSVR_ASSERT_U(!_buf);
    _buf = AllocBufByPageNum(_file_no, _max_page_num);
    if (_buf) {
        ++_file_no;

        // copy last buf ckp_lsn for find ckp lsn quickly on start
        _buf->footer_ptr->ckp_lsn[0] = _latest_lsn();
        _buf->footer_ptr->ckp_lsn[1] = _buf->footer_ptr->ckp_lsn[0];

        _latest_create_time.store(base::cpuwide_time_us());
    }
    return _buf;
}

DblwrBufPtr Dblwr::AllocBufByPageNum(uint64_t fno, uint32_t max_page_num) {
    ssize_t buf_size = max_page_num * gaia_apply::FLAGS_univ_page_size;
    return AllocBufByBufSize(fno, buf_size);
}

DblwrBufPtr Dblwr::AllocBufByBufSize(uint64_t fno, ssize_t buf_size) {
    DblwrBufPtr dblwr_buf(new DblwrBuf);
    dblwr_buf->frames_len = buf_size;

    ssize_t mmap_size = buf_size + kDblwrFooterSize;
    if (mmap_size <= _frames_len && _frames) {
        dblwr_buf->frames = _frames;
    } else {
        db::Status st = AllocFramesMmap(buf_size);
        if (!st.IsOk()) {
            return nullptr;
        }
        dblwr_buf->frames = _frames;
    }
    std::memset(dblwr_buf->frames, '\0', mmap_size);

    // footer_ptr points to the tail of the mmap region (the in-place footer area)
    dblwr_buf->footer_ptr = reinterpret_cast<DblwrFooter*>(dblwr_buf->frames + buf_size);
    dblwr_buf->footer_ptr->magic = kDBLWRBufFooterMagic;
    dblwr_buf->footer_ptr->max_page_num = buf_size / gaia_apply::FLAGS_univ_page_size;
    dblwr_buf->footer_ptr->fno = fno;
    dblwr_buf->footer_ptr->page_num = 0;
    dblwr_buf->footer_ptr->ckp_lsn[0] = 0;
    dblwr_buf->footer_ptr->ckp_lsn[1] = 0;
    dblwr_buf->footer_ptr->flags = kDblwrFlagsNone;
    return dblwr_buf;
}

db::Status Dblwr::AllocFramesMmap(ssize_t buf_size) {
    db::Status st;
    if (_frames) {
        munmap(_frames, _frames_len);
        l_stat_dblwr_buf_mem_bytes << -_frames_len;
        _frames = nullptr;
        _frames_len = 0;
    }

    if (_latest_fd < 0) {
        std::string latest_path = _db_path + "/" + dblwr_latest_file_name;
        _latest_fd = open(latest_path.c_str(), O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
        if (_latest_fd < 0) {
            st.Reset(db::GetErrCode(), "open latest mmap file:%s failed, %m", latest_path.c_str());
            return st;
        }
    }

    // allocate extra kDblwrFooterSize at the tail for the in-place footer
    ssize_t mmap_size = buf_size + kDblwrFooterSize;
    if (ftruncate(_latest_fd, mmap_size) != 0) {
        st.Reset(db::GetErrCode(), "ftruncate latest mmap file failed, size:%ld, %m", mmap_size);
        return st;
    }

    void* ptr = mmap(nullptr, mmap_size, PROT_READ | PROT_WRITE, MAP_SHARED, _latest_fd, 0);
    if (ptr == MAP_FAILED) {
        st.Reset(db::GetErrCode(), "mmap latest file failed, size:%ld, %m", mmap_size);
        return st;
    }

    _frames = static_cast<gaia_apply::byte*>(ptr);
    _frames_len = mmap_size;
    l_stat_dblwr_buf_mem_bytes << mmap_size;
    return st;
}

db::Status Dblwr::SealBufByLsn(gaia_apply::lsn_t lsn) {
    db::Status st;
    std::unique_lock lk(_shared_mutex, std::try_to_lock);
    if (!lk) {
        st.Reset(db::Code::kStatusError, "dblwr lock busy, skip seal by lsn");
        return st;
    }
    if (!_buf) {
        st.Reset(db::Code::kStatusError, "dblwr buf not exists");
        return st;
    }

    if (_buf->footer_ptr->ckp_lsn[1] < lsn) {
        // gc slow, wait for next gc write logblock to dblwr
        st.Reset(db::Code::kStatusError, "dblwr ckp lsn:%lu is small", _buf->footer_ptr->ckp_lsn[1]);
        return st;
    }

    st = SealBuf();
    if (st.IsOk()) {
        _bufs.emplace_front(_buf);
        _bufs_size.fetch_add(1, std::memory_order_relaxed);
        _buf = nullptr;
        _latest_create_time.store(0);
    }

    return st;
}

db::Status Dblwr::SealBufByTime(int64_t timeout_us) {
    db::Status st;
    int64_t t = _latest_create_time.load();
    if (t == 0 || t + timeout_us > base::cpuwide_time_us()) {
        st.Reset(db::Code::kOk, "time is valid");
        return st;
    }
    std::unique_lock lk(_shared_mutex, std::try_to_lock);
    if (!lk) {
        st.Reset(db::Code::kStatusError, "dblwr lock busy, skip seal by time");
        return st;
    }

    t = _latest_create_time.load();
    if (!_buf || t == 0) {
        st.Reset(db::Code::kStatusError, "dblwr buf not exists");
        return st;
    }

    if (t + timeout_us > base::cpuwide_time_us()) {
        st.Reset(db::Code::kOk, "time is valid");
        return st;
    }

    st = SealBuf();
    if (st.IsOk()) {
        _bufs.emplace_front(_buf);
        _bufs_size.fetch_add(1, std::memory_order_relaxed);
        _buf = nullptr;
        _latest_create_time.store(0);
    }

    return st;
}

db::Status Dblwr::SealBuf() {
    AutoStatLat stat_lat(l_stat_dblwr_seal_lat);
    db::Status st;
    PSVR_ASSERT_U(_buf);

    // finalize footer at the mmap tail via footer_ptr
    _buf->footer_ptr->crc = db::get_crc(_buf->frames, _buf->footer_ptr->max_page_num * gaia_apply::FLAGS_univ_page_size);
    db::make_checksum(_buf->footer_ptr, kDblwrFooterSize);

    std::string file_name = base::string_printf("%s/%lu%s",
            _db_path.c_str(), _buf->footer_ptr->fno, dblwr_tmp_ext_name);
    int fd = open(file_name.c_str(), O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        st.Reset(db::GetErrCode(), "open dblwr file:%s failed, %m", file_name.c_str());
        return st;
    }

    struct iovec iov[2];
    iov[0].iov_base = reinterpret_cast<void*>(_buf->frames);
    iov[0].iov_len = _buf->frames_len;
    iov[1].iov_base = reinterpret_cast<void*>(_buf->footer_ptr);
    iov[1].iov_len = kDblwrFooterSize;

    st = db::pwritevx(fd, iov, 2, 0);
    if (!st.IsOk()) {
        close(fd);
        st.ResetMsg("write dblwr file:%s failed, usize:%ld %m",
                file_name.c_str(), _buf->frames_len);
        return st;
    }

    if (db::fsync(fd) != 0) {
        close(fd);
        st.Reset(db::GetErrCode(), "fdatasync file:%s failed, %m", file_name.c_str());
        return st;
    }

    {
        std::string real_file_name = base::string_printf("%s/%lu", _db_path.c_str(), _buf->footer_ptr->fno);
        std::error_code ec;
        std::filesystem::rename(file_name, real_file_name, ec);
        if (ec) {
            st.Reset(db::GetErrCode(), "rename file:%s to %s failed, %m",
                    file_name.c_str(), real_file_name.c_str());
            close(fd);
            return st;
        }
        st = db::sync_directoryx(_db_path.c_str());
        if (!st.IsOk()) {
            close(fd);
            return st;
        }

        // copy mmap-tail footer to struct member, then redirect pointer so sealed buf
        // retains footer data after _frames is reused for the next active buf
        _buf->footer = *_buf->footer_ptr;
        _buf->footer_ptr = &_buf->footer;

        close(fd);
        int rfd = open(real_file_name.c_str(), O_RDONLY, S_IRUSR | S_IWUSR);
        if (rfd < 0) {
            st.Reset(db::GetErrCode(), "reopen dblwr file:%s for read failed, %m",
                    real_file_name.c_str());
            return st;
        }
        _buf->fd = rfd;
        _buf->frames = nullptr;
        LOG_EVERY_SECOND(NOTICE) << "dblwr seal buf file ok,"
            << " file:[" << real_file_name
            << "], page_num:[" << _buf->footer_ptr->page_num
            << "]";
    }

    return st;
}

db::Status Dblwr::ReadFile(int fd, gaia_apply::byte* frame, uint32_t slot) {
    return db::preadx(fd, frame, gaia_apply::FLAGS_univ_page_size,
            slot * gaia_apply::FLAGS_univ_page_size);
}

db::Status Dblwr::ReadBuf(DblwrBufPtr buf, gaia_apply::byte* frame, uint32_t slot) {
    db::Status st;
    if (buf->frames) {
        std::memcpy(frame, buf->frames + (slot * gaia_apply::FLAGS_univ_page_size), gaia_apply::FLAGS_univ_page_size);
        return st;
    } else {
        st = ReadFile(buf->fd, frame, slot);
        return st;
    }
}

db::Status Dblwr::Read(uint64_t offset, gaia_apply::byte* frame) {
    AutoStatLat stat_lat(l_stat_dblwr_read_lat);
    db::Status st;
    std::shared_lock slk(_shared_mutex);
    if (_buf) {
        if (auto it = _buf->offs_to_slot.find(offset); it != _buf->offs_to_slot.end()) {
            st = ReadBuf(_buf, frame, it->second);
            return st;
        }
    }
    if (_bufs.empty()) {
        st.Reset(db::Code::kNotFound, "bufs empty");
        return st;
    }
    for (auto buf : _bufs) {
        if (auto it = buf->offs_to_slot.find(offset); it != buf->offs_to_slot.end()) {
            st = ReadBuf(buf, frame, it->second);
            return st;
        }
    }
    st.Reset(db::Code::kNotFound, "not found in bufs");
    return st;
}

db::Status Dblwr::Read(gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no,
        uint64_t offset, gaia_apply::byte* frame) {
    AutoStatLat stat_lat(l_stat_dblwr_read_lat);
    db::Status st;
    std::shared_lock slk(_shared_mutex);
    uint64_t key = u32tou64(space_id, page_no);
    auto find_slot = [&](DblwrBufPtr buf) -> int32_t {
        auto it = buf->pages_to_slot.find(key);
        if (it == buf->pages_to_slot.end()) {
            return -1;
        }
        const auto& slots = it->second;
        for (int32_t i = static_cast<int32_t>(slots.size()) - 1; i >= 0; --i) {
            if (buf->footer_ptr->offs[slots[i]] == offset) {
                return slots[i];
            }
        }
        return -1;
    };
    if (_buf) {
        int32_t slot = find_slot(_buf);
        if (slot >= 0) {
            st = ReadBuf(_buf, frame, static_cast<uint32_t>(slot));
            return st;
        }
    }
    if (_bufs.empty()) {
        st.Reset(db::Code::kNotFound, "bufs empty");
        return st;
    }
    for (auto buf : _bufs) {
        int32_t slot = find_slot(buf);
        if (slot >= 0) {
            st = ReadBuf(buf, frame, static_cast<uint32_t>(slot));
            return st;
        }
    }
    st.Reset(db::Code::kNotFound, "not found in bufs");
    return st;
}

db::Status Dblwr::ReadSealBuf(gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no,
        gaia_apply::byte* frame, uint64_t offset) {
    db::Status st;
    std::shared_lock slk(_shared_mutex);
    if (_bufs.size() < 1) {
        st.Reset(db::Code::kNotFound, "bufs size empty");
        return st;
    }
    uint64_t key = u32tou64(space_id, page_no);
    for (auto buf : _bufs) {
        if (auto it = buf->pages_to_slot.find(key); it != buf->pages_to_slot.end()) {
            for (uint32_t s : it->second) {
                if (offset == buf->footer_ptr->offs[s]) {
                    st = ReadBuf(buf, frame, s);
                    return st;
                }
            }
        }
    }
    st.Reset(db::Code::kNotFound, "not found in bufs");
    return st;
}

db::Status Dblwr::Write(gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no,
            gaia_apply::byte* buf, uint64_t offset, uint32_t flags) {
    AutoStatLat stat_lat(l_stat_dblwr_write_lat);
    db::Status st;
    std::unique_lock lk(_shared_mutex);
    if (!_buf) {
        _buf = AllocBuf();
        if (!_buf) {
            st.Reset(db::Code::kSysError, "alloc dblwr buf failed");
            return st;
        }
    }

    PSVR_ASSERT_U(_buf);
    PSVR_ASSERT(_buf->footer_ptr->page_num < _buf->footer_ptr->max_page_num);

    uint32_t slot = _buf->footer_ptr->page_num;
    auto frame = _buf->frames + (slot * gaia_apply::FLAGS_univ_page_size);
    std::memcpy(frame, buf, gaia_apply::FLAGS_univ_page_size);

    _buf->footer_ptr->offs[_buf->footer_ptr->page_num] = offset;

    uint32_t before_flags = _buf->footer_ptr->flags;
    _buf->footer_ptr->flags |= flags;

    ++_buf->footer_ptr->page_num;
    if (_buf->footer_ptr->page_num >= _buf->footer_ptr->max_page_num) {
        // dump to file & sync
        st = SealBuf();
        if (!st.IsOk()) {
            --_buf->footer_ptr->page_num;
            _buf->footer_ptr->flags = before_flags;
            return st;
        }

        _buf->pages_to_slot[u32tou64(space_id, page_no)].push_back(slot);
        _buf->offs_to_slot[offset] = slot;

        _bufs.emplace_front(_buf);
        _bufs_size.fetch_add(1, std::memory_order_relaxed);
        _buf = nullptr;
        _latest_create_time = 0;
    } else {
        _buf->pages_to_slot[u32tou64(space_id, page_no)].push_back(slot);
        _buf->offs_to_slot[offset] = slot;
    }

    return st;
}

db::Status Dblwr::ReadCkpLsn(gaia_apply::lsn_t* ckp_lsn) {
    db::Status st;
    std::shared_lock slk(_shared_mutex);
    if (_buf) {
        *ckp_lsn = _buf->footer_ptr->ckp_lsn[1];
        return st;
    }
    if (!_bufs.empty()) {
        *ckp_lsn = _bufs.front()->footer_ptr->ckp_lsn[1];
        return st;
    }
    st.Reset(db::Code::kNotFound, "not found bufs");
    return st;
}

db::Status Dblwr::WriteCkpLsn(gaia_apply::lsn_t ckp_lsn) {
    db::Status st;
    std::unique_lock lk(_shared_mutex);
    if (!_buf) {
        _buf = AllocBuf();
        if (!_buf) {
            st.Reset(db::Code::kSysError, "alloc dblwr buf failed");
            return st;
        }
    }
    if (_buf->footer_ptr->ckp_lsn[0] == 0) {
        _buf->footer_ptr->ckp_lsn[0] = ckp_lsn;
    }
    _buf->footer_ptr->ckp_lsn[1] = ckp_lsn;
    _latest_lsn(ckp_lsn, true);
    return st;
}

bool Dblwr::HasBufs() const {
    return DumpBuf() != nullptr;
}

DblwrBufPtr Dblwr::DumpBuf() const {
    std::shared_lock slk(_shared_mutex);
    return _bufs.empty() ? nullptr : _bufs.back();
}

uint64_t Dblwr::NextDumpFileNo() const {
    DblwrBufPtr buf = DumpBuf();
    return buf ? buf->footer.fno : 0;
}

db::Status Dblwr::RemoveBuf(DblwrBufPtr buf) {
    db::Status st;
    std::unique_lock lk(_shared_mutex);

    if (_bufs.back() == buf) {
        st = RemoveFile(buf->footer_ptr->fno);
        if (!st.IsOk()) {
            return st;
        }
        _bufs.pop_back();
        _bufs_size.fetch_sub(1, std::memory_order_relaxed);
        return st;
    }

    st.Reset(db::Code::kCorrupted, "dblwr buf mismatch, %lu", buf->footer_ptr->fno);
    return st;
}

std::ostream& Dblwr::Dump(int fd, std::ostream& os, bool parse) {
    ssize_t file_size = 0;
    if (!db::get_file_size(fd, &file_size)) {
        return os << "get file size failed, errno:" << errno << std::endl;
    }

    if (file_size < kDblwrFooterSize) {
        return os << "file size:" << file_size << " < kDblwrFooterSize:" << kDblwrFooterSize << std::endl;
    }

    DblwrFooter footer;
    ssize_t read_size = db::pread(fd, &footer, kDblwrFooterSize, file_size - kDblwrFooterSize);
    if (read_size != kDblwrFooterSize) {
        return os << "read footer failed, errno:" << errno << " read_size:" << read_size << std::endl;
    }

    if (footer.magic != kDBLWRBufFooterMagic) {
        return os << "invalid magic: 0x" << std::hex << footer.magic
                  << " expected: 0x" << kDBLWRBufFooterMagic << std::dec << std::endl;
    }

    os << "----footer:\n";
    os << "magic:        0x" << std::hex << footer.magic << std::dec << "\n";
    os << "fno:          " << footer.fno << "\n";
    os << "page_num:     " << footer.page_num << "\n";
    os << "max_page_num: " << footer.max_page_num << "\n";
    os << "crc:          " << footer.crc << "\n";
    os << "ckp_lsn[0]:   " << footer.ckp_lsn[0] << "\n";
    os << "ckp_lsn[1]:   " << footer.ckp_lsn[1] << "\n";
    os << "flags:        0x" << std::hex << footer.flags << std::dec;
    if (footer.flags & kDblwrFlagsWithCompress) {
        os << " (compressed)";
    }
    os << "\n";
    os << "checksum:     " << footer.checksum << "\n";

    if (footer.page_num == 0) {
        return os << "no pages\n";
    }

    if (footer.page_num > static_cast<uint32_t>(kMaxDblwrOffsetNum)) {
        return os << "invalid page_num:" << footer.page_num << std::endl;
    }

    os << "----offsets:\n";
    for (uint32_t i = 0; i < footer.page_num; ++i) {
        os << "  [" << i << "] " << footer.offs[i] << "\n";
    }

    ssize_t buf_size = footer.page_num * gaia_apply::FLAGS_univ_page_size;
    auto frames_raw = std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, buf_size);
    if (!frames_raw) {
        return os << "alloc page buf failed, size:" << buf_size << std::endl;
    }

    std::unique_ptr<void, decltype(&std::free)> guard(frames_raw, std::free);
    gaia_apply::byte* frames = static_cast<gaia_apply::byte*>(frames_raw);

    read_size = db::pread(fd, frames, buf_size, 0);
    if (read_size != buf_size) {
        return os << "read page frames failed, errno:" << errno << " read_size:" << read_size << std::endl;
    }

    os << "----pages:\n";
    for (uint32_t i = 0; i < footer.page_num; ++i) {
        gaia_apply::byte* frame = frames + (i * gaia_apply::FLAGS_univ_page_size);
        bool is_empty = false;
        bool corrupted = page_is_corrupted(frame, gaia_apply::FLAGS_univ_page_size, &is_empty);
        gaia_apply::space_id_t space_id = gaia_apply::page_get_space_id(frame);
        gaia_apply::page_no_t page_no = gaia_apply::page_get_page_no(frame);
        os << "  [" << i << "]"
           << " space_id:" << space_id
           << " page_no:" << page_no;
        if (parse) {
            os << " page_lsn:" << page_get_page_lsn(frame);
        }
        os << " offset:" << footer.offs[i]
           << " corrupted:" << (corrupted ? "yes" : "no")
           << " empty:" << (is_empty ? "yes" : "no")
           << "\n";
    }

    return os;
}

}
