/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/rbio.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <bthread/task_group.h>
#include "psvr/config.h"
#include "psvr/control.h"
#include "psvr/page_op.h"
#include "psvr/rbio_context.h"

namespace psvr {

#define rbio_define_control_or_return_invalid(_ctx) \
    ControlPtr control = _control.lock();   \
    while (!control || _stopped) { \
        FinishRbioReqWithError(_ctx, pspb::RbioResponse::RBIO_SERVER_STOP); \
        return;     \
    }

#define rbio_define_segment_or_return_invalid(_ctx) \
    Task* task = _ctx->task;  \
    SegmentPtr segment = task->segment.lock();  \
    while (!segment_is_valid(segment)) { \
        FinishRbioReqWithError(_ctx, pspb::RbioResponse::RBIO_SEGMENT_INACTIVE); \
        return; \
    }

#define stat_rbio_req(_ctx, _name, _value) \
    stat_rbio_req2((_ctx)->task->role, (_ctx)->task->is_peer_read, _name, _value)

#define stat_rbio_req2(_role, _is_peer_read, _name, _value) \
do {    \
    if (_role == Task::RBIO_PRIMARY) {    \
        _name##_primary << (_value);    \
    } else if (_role == Task::RBIO_SECONDARY) {   \
        _name##_secondary << (_value);  \
    } else if (_is_peer_read) { \
        _name##_peer << (_value);  \
    }\
} while (0)

#define stat_segment_cluster_rbio_req(_segment, _ctx, _name, _value) \
    stat_segment_cluster_rbio_req2(segment, (_ctx)->task->role, _name, _value)

#define stat_segment_cluster_rbio_req2(_segment, _role, _name, _value) \
do {    \
    if (_role == Task::RBIO_PRIMARY) {    \
        set_segment_cluster_statistic(_segment, _name##_primary, _value);   \
    } else if (_role == Task::RBIO_SECONDARY) {   \
        set_segment_cluster_statistic(_segment, _name##_secondary, _value); \
    } \
} while (0)

#define inc_rbio_req(_ctx, _name) \
    inc_rbio_req2((_ctx)->task->role, _name)

#define inc_rbio_req2(_role, _name) \
do {    \
    if (_role == Task::RBIO_PRIMARY) {    \
        _name##_primary.fetch_add(1, std::memory_order_relaxed);    \
    } else if (_role == Task::RBIO_SECONDARY) {   \
        _name##_secondary.fetch_add(1, std::memory_order_relaxed);    \
    } \
} while (0)

#define sub_rbio_req(_ctx, _name) \
    sub_rbio_req2((_ctx)->task->role, _name)

#define sub_rbio_req2(_role, _name) \
do {    \
    if (_role == Task::RBIO_PRIMARY) {    \
        _name##_primary.fetch_sub(1, std::memory_order_relaxed);    \
    } else if (_role == Task::RBIO_SECONDARY) {   \
        _name##_secondary.fetch_sub(1, std::memory_order_relaxed);    \
    } \
} while (0)

#define interrupt_rbio_req_if_in_recovery(_ctx) \
do { \
    if (_ctx->task->segment_in_recovery) {  \
        FinishRbioReqWithError(_ctx, pspb::RbioResponse::RBIO_SEGMENT_INACTIVE); \
        return; \
    } \
} while (0)

static const uint32_t STAT_TIMES_STEP = 40;

static uint64_t rbio_get_delay_us(uint32_t retry_times,
        uint64_t retry_interval_us = FLAGS_psvr_rbio_delay_min_us,
        uint64_t max_delay_us = FLAGS_psvr_rbio_delay_max_us) {
    return get_delay_us(retry_times, retry_interval_us, max_delay_us);
}

static bvar::Vector<int64_t, 2> get_inflight_rbio_size(void* arg) {
    RbioManager* rbio_manager = static_cast<RbioManager*>(arg);
    bvar::Vector<int64_t, 2> result;
    result[0] = rbio_manager->rbio_size();
    result[1] = rbio_manager->inflight_rbio_size();
    return result;
}

static int64_t get_rbio_in_wait_count(void* arg) {
    return static_cast<std::atomic<int64_t>*>(arg)->load(std::memory_order_relaxed);
}

inline static bool rbio_req_need_wait_lsn(RbioManager::Task* task,
        RbioManager::Context* ctx, SegmentPtr segment) {
    return rbio_req_need_wait_lsn(task->read_rule, ctx->vlsn, segment->parse_lsn());
}

RbioManager::RbioManager(ClientPtr client, ControlWeakPtr control)
    : Model<RbioManager>(client, control),
    _thread_num(FLAGS_psvr_rbio_thread_num),
    _condi_thread_num(1),
    _rbio_size(&FLAGS_psvr_rbio_max_tasks_size),
    _inflight_rbio_size(0),
    _store_inflight_rbio_size(),
    _rbio_req_in_wait_count_primary(0),
    _rbio_req_in_wait_count_secondary(0),
    _rbio_req_in_wait_count_peer(0),
    _stat_inflight_rbio_size(&get_inflight_rbio_size, this),
    _stat_rbio_schedule_qps(kSlaWindowSize),
    _stat_rbio_err_count(kSlaWindowSize),
    _stat_rbio_write_lat(kSlaWindowSize),
    _stat_rbio_init_lat(kSlaWindowSize),
    _stat_rbio_read_lat_primary(kSlaWindowSize),
    _stat_rbio_read_lat_secondary(kSlaWindowSize),
    _stat_rbio_read_lat_peer(kSlaWindowSize),
    _stat_rbio_req_lsn_behind_size_primary(kSlaWindowSize),
    _stat_rbio_req_lsn_behind_size_secondary(kSlaWindowSize),
    _stat_rbio_req_lsn_behind_size_peer(kSlaWindowSize),
    _stat_rbio_req_wait_lsn_lat_primary(kSlaWindowSize),
    _stat_rbio_req_wait_lsn_lat_secondary(kSlaWindowSize),
    _stat_rbio_req_wait_lsn_lat_peer(kSlaWindowSize),
    _stat_rbio_req_prepare_lat_primary(kSlaWindowSize),
    _stat_rbio_req_prepare_lat_secondary(kSlaWindowSize),
    _stat_rbio_req_prepare_lat_peer(kSlaWindowSize),
    _stat_rbio_req_apply_lat_primary(kSlaWindowSize),
    _stat_rbio_req_apply_lat_secondary(kSlaWindowSize),
    _stat_rbio_req_apply_lat_peer(kSlaWindowSize),
    _stat_rbio_req_in_wait_count_primary(&get_rbio_in_wait_count, &_rbio_req_in_wait_count_primary),
    _stat_rbio_req_in_wait_count_secondary(&get_rbio_in_wait_count, &_rbio_req_in_wait_count_secondary),
    _stat_rbio_req_in_wait_count_peer(&get_rbio_in_wait_count, &_rbio_req_in_wait_count_peer),
    _stat_rbio_req_interrupt_by_lsn_qps_primary(kSlaWindowSize),
    _stat_rbio_req_interrupt_by_lsn_qps_secondary(kSlaWindowSize),
    _stat_rbio_req_interrupt_by_lsn_qps_peer(kSlaWindowSize),
    _stat_rbio_req_interrupt_by_space_extent_qps_primary(kSlaWindowSize),
    _stat_rbio_req_interrupt_by_space_extent_qps_secondary(kSlaWindowSize),
    _stat_rbio_req_interrupt_by_space_extent_qps_peer(kSlaWindowSize) {
    _thread_pool.reset(new ThreadPoolType);
    _condition_thread_pool.reset(new ConditionThreadType);
    Expose();
}

void RbioManager::Expose() {
#ifndef GTEST
    _stat_inflight_rbio_size.expose("psvr_inflight_rbio_size");
    _stat_inflight_rbio_size.set_vector_names("total,inflight");
    _stat_rbio_schedule_qps.expose("psvr_rbio_schedule_qps");
    _stat_rbio_err_count.expose("psvr_rbio_err_count");
    _stat_rbio_write_lat.expose("psvr_rbio_write_page");
    _stat_rbio_init_lat.expose("psvr_rbio_init");
    _stat_rbio_read_lat_primary.expose("psvr_primary_rbio_read_page");
    _stat_rbio_read_lat_secondary.expose("psvr_secondary_rbio_read_page");
    _stat_rbio_read_lat_peer.expose("psvr_peer_rbio_read_page");
    _stat_rbio_req_lsn_behind_size_primary.expose("psvr_primary_rbio_req_lsn_behind_vlsn");
    _stat_rbio_req_lsn_behind_size_secondary.expose("psvr_secondary_rbio_req_lsn_behind_vlsn");
    _stat_rbio_req_lsn_behind_size_peer.expose("psvr_peer_rbio_req_lsn_behind_vlsn");
    _stat_rbio_req_wait_lsn_lat_primary.expose("psvr_primary_rbio_req_wait_lsn");
    _stat_rbio_req_wait_lsn_lat_secondary.expose("psvr_secondary_rbio_req_wait_lsn");
    _stat_rbio_req_wait_lsn_lat_peer.expose("psvr_peer_rbio_req_wait_lsn");
    _stat_rbio_req_prepare_lat_primary.expose("psvr_primary_rbio_req_prepare");
    _stat_rbio_req_prepare_lat_secondary.expose("psvr_secondary_rbio_req_prepare");
    _stat_rbio_req_prepare_lat_peer.expose("psvr_peer_rbio_req_prepare");
    _stat_rbio_req_apply_lat_primary.expose("psvr_primary_rbio_req_apply");
    _stat_rbio_req_apply_lat_secondary.expose("psvr_secondary_rbio_req_apply");
    _stat_rbio_req_apply_lat_peer.expose("psvr_peer_rbio_req_apply");
    _stat_rbio_req_in_wait_count_primary.expose("psvr_primary_rbio_req_in_wait_count");
    _stat_rbio_req_in_wait_count_secondary.expose("psvr_secondary_rbio_req_in_wait_count");
    _stat_rbio_req_in_wait_count_peer.expose("psvr_peer_rbio_req_in_wait_count");
    _stat_rbio_req_interrupt_by_lsn_qps_primary.expose("psvr_primary_rbio_req_interrupt_by_lsn_qps");
    _stat_rbio_req_interrupt_by_lsn_qps_secondary.expose("psvr_secondary_rbio_req_interrupt_by_lsn_qps");
    _stat_rbio_req_interrupt_by_lsn_qps_peer.expose("psvr_peer_rbio_req_interrupt_by_lsn_qps");
    _stat_rbio_req_interrupt_by_space_extent_qps_primary.expose("psvr_primary_rbio_req_interrupt_by_space_extent_qps");
    _stat_rbio_req_interrupt_by_space_extent_qps_secondary.expose("psvr_secondary_rbio_req_interrupt_by_space_extent_qps");
    _stat_rbio_req_interrupt_by_space_extent_qps_peer.expose("psvr_peer_rbio_req_interrupt_by_space_extent_qps");
#endif
}

RbioManager::~RbioManager() {
    if (!_stopped) {
        Stop();
    }
}

bool RbioManager::SetUp() {
    ControlPtr control = _control.lock();
    if (!control) {
        LOG(ERROR) << "failed, control is release";
        return false;
    }
    if (control->multi_type()) {
        _rbio_size = &FLAGS_multi_psvr_rbio_max_tasks_size;
        _thread_num = FLAGS_multi_psvr_rbio_thread_num_per_group;

        auto cfg_cond_tn = static_cast<uint32_t>(FLAGS_multi_psvr_rbio_condition_thread_num);
        uint32_t store_cond_tn = (_store_count + 1u) / 2;
        _condi_thread_num = std::min(cfg_cond_tn, store_cond_tn);
    }

    for (uint32_t i = 0; i < _store_count; ++i) {
        _store_inflight_rbio_size.emplace_back(std::make_shared<std::atomic<int64_t>>(0));
    }

    typename ConditionThreadType::Fn cond_fn
        = std::bind(&RbioManager::ConditionFn, this, std::placeholders::_1);
    _condition_thread_pool->Start(_condi_thread_num, "rbio_cond", cond_fn,
            &FLAGS_psvr_rbio_wait_lsn_sleep_interval_us);

    typename ThreadPoolType::TaskFn fn
        = std::bind(&RbioManager::OnCompletion, this, std::placeholders::_1);

    uint32_t group_num = _store_count;
    if (FLAGS_multi_psvr_rbio_group_num > 0
            && static_cast<uint32_t>(FLAGS_multi_psvr_rbio_group_num) < _store_count) {
        group_num = FLAGS_multi_psvr_rbio_group_num;
    }
    if (!_thread_pool->Start(group_num, "rbio", control->timer(),
                _thread_num, fn, FLAGS_multi_psvr_rbio_thread_enable_shared)) {
        LOG(ERROR) << "rbio thread pool start failed";
        return false;
    }
    return true;
}

void RbioManager::TearDown() {
    LOG(NOTICE) << "rbio manager will stop ...";
    _condition_thread_pool->Stop(false);
    _thread_pool->Stop(false);
    _stat_inflight_rbio_size.hide();
    _stat_rbio_schedule_qps.hide();
    _stat_rbio_err_count.hide();
    _stat_rbio_write_lat.hide();
    _stat_rbio_init_lat.hide();
    _stat_rbio_read_lat_primary.hide();
    _stat_rbio_read_lat_secondary.hide();
    _stat_rbio_read_lat_peer.hide();
    _stat_rbio_req_lsn_behind_size_primary.hide();
    _stat_rbio_req_lsn_behind_size_secondary.hide();
    _stat_rbio_req_lsn_behind_size_peer.hide();
    _stat_rbio_req_wait_lsn_lat_primary.hide();
    _stat_rbio_req_wait_lsn_lat_secondary.hide();
    _stat_rbio_req_wait_lsn_lat_peer.hide();
    _stat_rbio_req_prepare_lat_primary.hide();
    _stat_rbio_req_prepare_lat_secondary.hide();
    _stat_rbio_req_prepare_lat_peer.hide();
    _stat_rbio_req_apply_lat_primary.hide();
    _stat_rbio_req_apply_lat_secondary.hide();
    _stat_rbio_req_apply_lat_peer.hide();
    _stat_rbio_req_in_wait_count_primary.hide();
    _stat_rbio_req_in_wait_count_secondary.hide();
    _stat_rbio_req_in_wait_count_peer.hide();
    _stat_rbio_req_interrupt_by_lsn_qps_primary.hide();
    _stat_rbio_req_interrupt_by_lsn_qps_secondary.hide();
    _stat_rbio_req_interrupt_by_lsn_qps_peer.hide();
    _stat_rbio_req_interrupt_by_space_extent_qps_primary.hide();
    _stat_rbio_req_interrupt_by_space_extent_qps_secondary.hide();
    _stat_rbio_req_interrupt_by_space_extent_qps_peer.hide();
    LOG(NOTICE) << "rbio manager stop ok! inflight_rbio_size:[" << _inflight_rbio_size << "]";
}

void RbioManager::Join() {
    LOG(NOTICE) << "rbio manager will join ...";
    _condition_thread_pool->Stop(true);
    _thread_pool->RecycleTask([this](Context* ctx) {
            // call all received rpc requests done, otherwise block brpc quit
            FinishRbioReqWithError(ctx, pspb::RbioResponse::RBIO_SERVER_STOP);
        });
    while (_inflight_rbio_size.load() > 0) {
        _condition_thread_pool->Clear();
    }
    LOG(NOTICE) << "rbio manager will join ok";
}

bool RbioManager::IncOrDecThreadNum() {
    uint32_t cfg_n = FLAGS_multi_psvr_rbio_thread_num_per_group;
    uint32_t cur_n = IncOrDecGroupThreadNum(_thread_num, cfg_n,
            _thread_pool, _thread_pool->size(),
            [this](Context* ctx){
                Schedule(ctx);
            });

    LOG_IF(NOTICE, cfg_n != cur_n) << "rbio thread num per store changed,"
        << " old:[" << cur_n
        << "] new:[" << cfg_n
        << "]";
    return cfg_n != cur_n;
}

void RbioManager::ScheduleNextAction(Context* ctx, Action action) {
    ctx->action = action;
    Schedule(ctx);
}

void RbioManager::Schedule(Context* ctx, uint64_t delay_us, bool is_retry, bool check_queue_size) {
    if (BAIDU_UNLIKELY(_stopped)) {
        FinishRbioReqWithError(ctx, pspb::RbioResponse::RBIO_SERVER_STOP);
        return;
    }
    const uint64_t max_queue_size = FLAGS_psvr_rbio_thread_max_queue_size;
    if (check_queue_size
            && max_queue_size > 0
            && _thread_pool->GetThreadQueueSize(ctx->thread_pool_idx, ctx->client_id) > max_queue_size) {
        LOG_EVERY_SECOND(ERROR) << "thread queue is full, idx:[" << ctx->client_id << "]";
        FinishRbioReqWithError(ctx, pspb::RbioResponse::RBIO_QUOTA_LIMIT);
        return;
    }
    _stat_rbio_schedule_qps << 1;
    SetRbioReqCtxClientId(ctx);
    if (is_retry) {
        ++ctx->retry_times;
    }
    if (delay_us == 0) {
        if (_thread_pool->Execute(ctx->thread_pool_idx, ctx)) {
            return;
        }
    } else {
        if (_thread_pool->Schedule(ctx->thread_pool_idx, ctx, delay_us)) {
            return;
        }
    }

    if (_stopped) {
        FinishRbioReqWithError(ctx, pspb::RbioResponse::RBIO_SERVER_STOP);
        return;
    }

    LOG(ERROR) << "dispatch rbio to pool failed";
    psvr_terminate();
}

void RbioManager::ConditionScheduleNextAction(Context* ctx,
        Action action, SegmentPtr segment, gaia_apply::lsn_t lsn) {
    ctx->action = action;
    ConditionSchedule(ctx, segment, lsn);
}

void RbioManager::RetryConditionSchedule(Context* ctx,
        SegmentPtr segment, gaia_apply::lsn_t lsn) {
    if (!InterruptRbioReqIf(ctx)) {
        ++ctx->retry_times;
        ConditionSchedule(ctx, segment, lsn);
    }
}

void RbioManager::ConditionSchedule(Context* ctx,
        SegmentPtr segment, gaia_apply::lsn_t lsn) {
    inc_rbio_req(ctx, _rbio_req_in_wait_count);
    LOG(TRACE) << segment << " add to rbio wait queue, lsn:[" << lsn << "]";
    _condition_thread_pool->Schedule(segment->GetClusterHashVal(),
            ConditionTask(ctx, segment, lsn));
}

void RbioManager::ConditionFn(const ConditionTask& task) {
    sub_rbio_req(task.ctx, _rbio_req_in_wait_count);
    Execute(task.ctx);
}

bool RbioManager::Execute(Context* ctx) {
    if (!_thread_pool->EmergentExecute(ctx->thread_pool_idx, ctx)) {
        if (_stopped) {
            FinishRbioReqWithError(ctx, pspb::RbioResponse::RBIO_SERVER_STOP);
        } else {
            psvr_terminate();
        }
        return false;
    }
    return true;
}

void RbioManager::OnCompletion(Context* ctx) {
    if (ctx->task) {
        rbio_define_segment_or_return_invalid(ctx);
    }
    if (BAIDU_UNLIKELY(_stopped)) {
        FinishRbioReqWithError(ctx, pspb::RbioResponse::RBIO_SERVER_STOP);
        return;
    }
    if (InterruptRbioReqIf(ctx)) {
        return;
    }
    switch(ctx->action) {
    case Action::kRbio:
        return Rbio(ctx);
    case Action::kWaitLsn:
        return WaitLsn(ctx);
    case Action::kPrepare:
        return Prepare(ctx);
    case Action::kReadPage:
        return ReadPage(ctx);
    case Action::kWritePage:
        return WritePage(ctx);
    default:
        PSVR_ASSERT(false);
    }
}

int32_t RbioManager::CheckStoreQuota(int32_t store_id, uint32_t nr, bool* pass) {
    const auto max_nr = FLAGS_psvr_rbio_store_max_tasks_size;
    *pass = true;
    if (max_nr == 0) {
        LOG(TRACE) << "store quota is closed";
        return -1;
    }
    if (store_id < 0 || static_cast<size_t>(store_id) >= _store_inflight_rbio_size.size()) {
        LOG(WARNING) << "invalid store id for check quota,"
            << " store_id:[" << store_id
            << "]";
        return -1;
    }
    auto quota = _store_inflight_rbio_size[store_id];
    auto inflight_count = quota->load(std::memory_order_acquire);
    do {
        if (inflight_count + nr > max_nr || _stopped) {
            LOG_EVERY_SECOND(WARNING) << "store rbio ctx use up,"
                << " store_id:[" << store_id
                << "] used_count:[" << inflight_count
                << "] capacity:[" << max_nr
                << "] req_nr:[" << nr
                << "]";
            *pass = false;
            return -1;
        }
    } while (!quota->compare_exchange_strong(inflight_count, inflight_count + nr, std::memory_order_release));
    return store_id;
}

void RbioManager::PutStoreQuota(int32_t store_id, uint32_t nr) {
    if (store_id >= 0) {
        _store_inflight_rbio_size[store_id]->fetch_sub(nr, std::memory_order_relaxed);
    }
}

bool RbioManager::CheckQuota(uint32_t nr) {
    const auto max_nr = rbio_size();
    auto inflight_count = _inflight_rbio_size.load(std::memory_order_acquire);
    do {
        if (inflight_count + nr > max_nr || _stopped) {
            LOG_EVERY_SECOND(WARNING) << "rbio ctx use up,"
                << " used_count:[" << inflight_count
                << "] capacity:[" << max_nr
                << "] req_nr:[" << nr
                << "]";
            return false;
        }
    } while (!_inflight_rbio_size.compare_exchange_strong(inflight_count, inflight_count + nr, std::memory_order_release));
    return true;
}

void RbioManager::PutRbioCtx(Task* task) {
    std::unique_ptr<Task> rbio_guard(task);
    _inflight_rbio_size.fetch_sub(task->req_count, std::memory_order_relaxed);
    PutStoreQuota(task->quota_store_id, task->req_count);
    LOG(TRACE) << "finish," << task;
}

void RbioManager::SetRbioReqCtxClientId(Context* ctx) {
    static std::atomic<uint32_t> round_robin_id = 0;
    SegmentPtr segment = ctx->task->segment.lock();
    if (segment) {
        ctx->client_id = (segment->hash_val() + ctx->idx) % _thread_num;
        ctx->thread_pool_idx = segment->store_id();
    } else {
        auto idx = round_robin_id.fetch_add(1, std::memory_order_relaxed);
        ctx->client_id = idx;
        ctx->thread_pool_idx = 0;
    }
}

void RbioManager::Dispatch(Task* task) {
    const uint32_t req_count = task->req_count;
    for (uint32_t i = 0; i < req_count; ++i) {
        ADD_TRACE_TP(task->reqs[i]->tp, "dispatch");
        Schedule(task->reqs[i], 0, false, true);
    }
}

void RbioManager::ConditionDispatch(Task* task, SegmentPtr segment) {
    const uint32_t req_count = task->req_count;
    for (uint32_t i = 0; i < req_count; ++i) {
        ADD_TRACE_TP(task->reqs[i]->tp, "cond_dispatch");
        task->reqs[i]->fetch_begin_time = base::cpuwide_time_us();
        task->reqs[i]->vlsn_diff_fetch = diff_rbio_lsn(task->reqs[i]->vlsn, segment->fetch_lsn());
        task->reqs[i]->vlsn_diff_ls_dispatch_lsn = diff_rbio_lsn(task->reqs[i]->vlsn, segment->ls_dispatch_lsn());

        if (task->is_secondary_req() && task->secondary_fetch_lsn > 0) {
            task->reqs[i]->secondary_fetch_diff_fetch = diff_rbio_lsn(task->secondary_fetch_lsn, segment->fetch_lsn());
            task->reqs[i]->secondary_fetch_diff_parse = diff_rbio_lsn(task->secondary_fetch_lsn, segment->parse_lsn());
            task->reqs[i]->secondary_ls_dispatch_diff_fetch = diff_rbio_lsn(task->secondary_ls_dispatch_lsn, segment->fetch_lsn());
            task->reqs[i]->secondary_ls_dispatch_diff_parse = diff_rbio_lsn(task->secondary_ls_dispatch_lsn, segment->parse_lsn());
        }

        const auto diff_lsn = diff_rbio_lsn(task->reqs[i]->vlsn, segment->parse_lsn());
        stat_rbio_req2(task->role, task->is_peer_read, _stat_rbio_req_lsn_behind_size, diff_lsn);
        stat_segment_cluster_rbio_req2(segment, task->role, stat_rbio_req_lsn_behind_size, diff_lsn);
        stat_rbio_req2(task->role, task->is_peer_read, _stat_rbio_req_interrupt_by_lsn_qps, 1);

        ConditionScheduleNextAction(task->reqs[i],
                Action::kRbio, segment, task->reqs[i]->vlsn);
    }
}

void RbioManager::Dispatch(SegmentPtr segment,
        const pspb::WritePageRequest* request,
        pspb::WritePageResponse* response,
        ggpb::Closure* done,
        int64_t begin_time) {
    ControlPtr control = _control.lock();
    if (_stopped || !control) {
        baidu::rpc::ClosureGuard done_guard(done);
        auto status = response->mutable_status();
        status->set_code(pspb::WritePageResponse::ERROR);
        return;
    }

    const uint32_t req_vec_size = request->requestvec_size();
    if(request->n() != req_vec_size || req_vec_size < 1) {
        baidu::rpc::ClosureGuard done_guard(done);
        auto status = response->mutable_status();
        status->set_code(pspb::WritePageResponse::INVALID);
        LOG_EVERY_SECOND(WARNING) << segment << " invalid write page request,"
            << " req_id:[" << request->request_id()
            << "] vec_size:[" << req_vec_size << "]";
        return;
    }

    if (request->has_vlsn()) {
        bool wait = false;
        if (FLAGS_psvr_enable_append_file) {
            wait = request->vlsn() > segment->GetAppendDBCheckPointLsn();
            if (FLAGS_psvr_dblwr_max_page_num > 0 && wait) {
                segment->dblwr()->SealBufByLsn(request->vlsn());
            }
        } else {
            wait = request->vlsn() > segment->gc_lsn();
        }
        if (wait) {
            baidu::rpc::ClosureGuard done_guard(done);
            auto status = response->mutable_status();
            status->set_code(pspb::WritePageResponse::LSN_BEHIND);
            return;
        }
    }

    if (!CheckQuota(req_vec_size)) {
        baidu::rpc::ClosureGuard done_guard(done);
        auto status = response->mutable_status();
        status->set_code(pspb::WritePageResponse::QUOTA_LIMIT);
        LOG_EVERY_SECOND(WARNING) << segment << " fail to get write page context,"
            << " req_id:[" << request->request_id()
            << "] vec_size:[" << req_vec_size << "]";
        return;
    }

    bool store_quota_ok = true;
    const int32_t quota_store_id = CheckStoreQuota(segment->store_id(), req_vec_size, &store_quota_ok);
    if (!store_quota_ok) {
        baidu::rpc::ClosureGuard done_guard(done);
        auto status = response->mutable_status();
        status->set_code(pspb::WritePageResponse::QUOTA_LIMIT);
        _inflight_rbio_size.fetch_sub(req_vec_size, std::memory_order_relaxed);
        return;
    }

    auto write_ctx = new WriteTask(segment, req_vec_size, request, response, done);
    write_ctx->quota_store_id = quota_store_id;
    write_ctx->Init(begin_time);
    Dispatch(write_ctx);
}

void RbioManager::Dispatch(SegmentPtr segment,
        ggpb::RpcController* cntl,
        const pspb::RbioRequest* request,
        pspb::RbioResponse* response,
        google::protobuf::Closure* done,
        int64_t begin_time) {
    ControlPtr control = _control.lock();
    auto max_error_code = !request->has_max_error_code()
        ? kRbioMaxErrorCodeOld : static_cast<RbioError>(request->max_error_code());
    if (_stopped || !control) {
        baidu::rpc::ClosureGuard done_guard(done);
        response->set_requestid(request->requestid());
        response->set_errcode(handle_rbio_error_code(pspb::RbioResponse::RBIO_SERVER_STOP, max_error_code));
        return;
    }
    const uint32_t req_vec_size = request->reqvec_size();
    if (req_vec_size != request->n()
            || req_vec_size < 1) {
        baidu::rpc::ClosureGuard done_guard(done);
        response->set_requestid(request->requestid());
        response->set_errcode(handle_rbio_error_code(pspb::RbioResponse::RBIO_INVALID, max_error_code));
        LOG_EVERY_SECOND(WARNING) << segment << " invalid rbio request,"
            << " req_id:[" << request->requestid()
            << "] vec_size:[" << req_vec_size
            << "] is_peer_read:[" << (request->has_peerread() ? request->peerread() : false)
            << "]";
        _stat_rbio_err_count << 1;
        return;
    }

    if (FLAGS_psvr_rbio_disabled_as_data_source) {
        baidu::rpc::ClosureGuard done_guard(done);
        response->set_requestid(request->requestid());
        response->set_errcode(handle_rbio_error_code(pspb::RbioResponse::RBIO_SEGMENT_INACTIVE, max_error_code));
        return;
    }

    if (FLAGS_psvr_recover_disabled_as_data_source
            && request->has_peerread() && request->peerread()) {
        baidu::rpc::ClosureGuard done_guard(done);
        response->set_requestid(request->requestid());
        response->set_errcode(handle_rbio_error_code(pspb::RbioResponse::RBIO_SEGMENT_INACTIVE, max_error_code));
        return;
    }

    if (!CheckQuota(req_vec_size)) {
        baidu::rpc::ClosureGuard done_guard(done);
        response->set_requestid(request->requestid());
        response->set_errcode(handle_rbio_error_code(pspb::RbioResponse::RBIO_QUOTA_LIMIT, max_error_code));
        LOG_EVERY_SECOND(WARNING) << segment << " fail to get rbio ctx,"
            << " req_id:[" << request->requestid()
            << "] vec_size:[" << req_vec_size
            << "] is_peer_read:[" << (request->has_peerread() ? request->peerread() : false)
            << "]";
        _stat_rbio_err_count << 1;
        return;
    }

    bool store_quota_ok = true;
    const int32_t quota_store_id = CheckStoreQuota(segment->store_id(), req_vec_size, &store_quota_ok);
    if (!store_quota_ok) {
        baidu::rpc::ClosureGuard done_guard(done);
        response->set_requestid(request->requestid());
        response->set_errcode(handle_rbio_error_code(pspb::RbioResponse::RBIO_QUOTA_LIMIT, max_error_code));
        _inflight_rbio_size.fetch_sub(req_vec_size, std::memory_order_relaxed);
        return;
    }

    brpc::Controller* cntl2 = dynamic_cast<brpc::Controller*>(cntl);
    if (FLAGS_psvr_rbio_response_compress_type
            && brpc::CompressType_IsValid(FLAGS_psvr_rbio_response_compress_type)) {
        cntl2->set_response_compress_type(static_cast<brpc::CompressType>(FLAGS_psvr_rbio_response_compress_type));
    }

    auto read_ctx = new ReadTask(segment, req_vec_size, cntl2, request, response, done);
    read_ctx->quota_store_id = quota_store_id;
    if (read_ctx->Init(begin_time)) {
        _stat_rbio_init_lat << read_ctx->stat_timer.u_elapsed();
        stat_segment_cluster_rbio_req2(segment, read_ctx->role, stat_rbio_init_lat, read_ctx->stat_timer.u_elapsed());
        TRACEPRINTF("Dispath_to_rbio_thread, nr:%u", req_vec_size);
        if (read_ctx->wait_lsn && FLAGS_psvr_rbio_enable_wait_queue) {
            ConditionDispatch(read_ctx, segment);
        } else {
            Dispatch(read_ctx);
        }
    } else {
        PutRbioCtx(read_ctx);
        control->fetcher()->Wakeup(segment);
        _stat_rbio_err_count << 1;
    }
}

template<typename ErrorType>
void RbioManager::FinishRbioReq(Context* ctx, ErrorType code) {
    bool is_ok = false;
    if (ctx->Finish(code, &is_ok)) {
        SegmentPtr segment = ctx->task->segment.lock();
        const bool is_read = ctx->task->is_read();
        const auto role = ctx->task->role;
        const auto is_peer_read = ctx->task->is_peer_read;
        Timer stat_timer(ctx->stat_timer);

        PutRbioCtx(ctx->task);
        if (is_ok) {
            const auto u_elapsed = stat_timer.u_elapsed();
            if (is_read) {
                stat_rbio_req2(role, is_peer_read, _stat_rbio_read_lat, u_elapsed);
                if (segment) {
                    stat_segment_cluster_rbio_req2(segment, role, stat_rbio_lat, u_elapsed);
                }
            } else {
                _stat_rbio_write_lat << u_elapsed;
            }
        } else {
            _stat_rbio_err_count << 1;
            if (segment) {
                stat_segment_cluster_rbio_req2(segment, role, stat_rbio_error_count, 1);
            }
        }
    }
}

template<typename ERROR>
void RbioManager::FinishRbioReqWithError(Context* ctx, ERROR error) {
    if (ctx->task->is_read()) {
        FinishRbioReq(ctx, error);
    } else {
        FinishRbioReq(ctx, pspb::WritePageResponse::TIMEOUT);
    }
}

void RbioManager::FinishRbioReqWithTimeout(Context* ctx) {
    FinishRbioReqWithError(ctx, pspb::RbioResponse::RBIO_TIMEOUT);
}

bool RbioManager::InterruptRbioReqIf(Context* ctx) {
    bool timeout = ctx->stat_timer.m_elapsed() >= FLAGS_psvr_rbio_max_timeout_ms;
    if (_stopped || timeout || ctx->retry_times >= ctx->max_retry_times) {
        LOG(TRACE) << "interrupt rbio,"
            << " stopped:[" << _stopped
            << "] timeout:[" << timeout
            << "] retry_limit:[" << (ctx->retry_times >= ctx->max_retry_times)
            << "]" << ctx;
        FinishRbioReqWithTimeout(ctx);
        return true;
    }
    return false;
}

void RbioManager::RetryOrErrorRbioReq(Context* ctx, bool emergent) {
    if (!InterruptRbioReqIf(ctx)) {
        if (!emergent) {
            Schedule(ctx, rbio_get_delay_us(ctx->retry_times), true);
        } else {
            Execute(ctx);
        }
    }
}

void RbioManager::Rbio(Context* ctx) {
    rbio_define_control_or_return_invalid(ctx);
    rbio_define_segment_or_return_invalid(ctx);

    ClusterPtr cluster = segment->cluster();
    if (ctx->fetch_begin_time <= 0) {
        ctx->fetch_begin_time = base::cpuwide_time_us();
        ctx->vlsn_diff_fetch = diff_rbio_lsn(ctx->vlsn, segment->fetch_lsn());
        ctx->vlsn_diff_ls_dispatch_lsn = diff_rbio_lsn(ctx->vlsn, segment->ls_dispatch_lsn());

        if (task->is_secondary_req() && task->secondary_fetch_lsn > 0) {
            ctx->secondary_fetch_diff_fetch = diff_rbio_lsn(task->secondary_fetch_lsn, segment->fetch_lsn());
            ctx->secondary_fetch_diff_parse = diff_rbio_lsn(task->secondary_fetch_lsn, segment->parse_lsn());
            ctx->secondary_ls_dispatch_diff_fetch = diff_rbio_lsn(task->secondary_ls_dispatch_lsn, segment->fetch_lsn());
            ctx->secondary_ls_dispatch_diff_parse = diff_rbio_lsn(task->secondary_ls_dispatch_lsn, segment->parse_lsn());
        }
    }

    if (ctx->lowest_lsn && segment->parse_lsn() < ctx->lowest_lsn) {
        FinishRbioReqWithError(ctx, pspb::RbioResponse::RBIO_LSN_WAIT);
        return;
    }

    const bool need_wait_lsn = rbio_req_need_wait_lsn(task, ctx, segment);
    if (ctx->fetch_end_time <= 0 && !need_wait_lsn) {
        ctx->fetch_end_time = base::cpuwide_time_us();
        ctx->fetch_lsn_retry_times = ctx->retry_times;
    }

    do {
        if (BAIDU_UNLIKELY(!task->is_read())) {
            break;
        }

        if (BAIDU_UNLIKELY(task->is_peer_read)) {
            break;
        }

        if (BAIDU_UNLIKELY(!segment->recovery_status_is_finish())) {
            break;
        }

        if (need_wait_lsn) {
            stat_rbio_req(ctx, _stat_rbio_req_interrupt_by_lsn_qps, 1);
            break;
        }

        ctx->parse_end_time = base::cpuwide_time_us();

        auto u_elapsed = ctx->stat_timer.u_elapsed_point();
        stat_rbio_req(ctx, _stat_rbio_req_wait_lsn_lat, u_elapsed);
        stat_segment_cluster_rbio_req(segment, ctx, stat_rbio_req_wait_lsn_lat, u_elapsed);
        stat_segment_cluster_rbio_req(segment, ctx, stat_rbio_req_retry_times_avg, ctx->retry_times);
        ADD_TRACE_TP(ctx->tp, "wait_lsn");

        if (task->req_has_physical_extent_id) {
            ctx->page_physical_offset = calc_physical_offset_by_extent_id(task->req_physical_extent_id, ctx->logical_page_no);
        } else {
            ctx->page_physical_offset = kInvalidOffset;
            const bool ret = segment->GetSpacePagePhysicalOffset(ctx->space_id, ctx->logical_page_no, &ctx->page_physical_offset);
            if (!ret) {
                stat_rbio_req(ctx, _stat_rbio_req_interrupt_by_space_extent_qps, 1);
                break;
            }
        }

        thread_local BufBlockPtr tl_buf_block = nullptr;
        if (!tl_buf_block) {
            tl_buf_block = control->buf_pool()->AllocBufBlock(gaia_physical_page_size());
        }

        ctx->buf_block = tl_buf_block;
        if (task->enable_attachment_type) {
            ctx->buf_block = control->buf_pool()->AllocBufBlock(gaia_physical_page_size());
        }
        if (BAIDU_UNLIKELY(!ctx->buf_block)
                || ctx->size != gaia_physical_page_size()) {
            break;
        }
        init_buf_block(ctx->buf_block, ctx->space_id, ctx->logical_page_no, gaia_page_size());

        u_elapsed = ctx->stat_timer.u_elapsed_point();
        stat_rbio_req(ctx, _stat_rbio_req_prepare_lat, u_elapsed);
        stat_segment_cluster_rbio_req(segment, ctx, stat_rbio_req_prepare_lat, u_elapsed);
        ADD_TRACE_TP(ctx->tp, "prepare");

        bool page_is_empty = false;
        db::Status st = segment->ReadPageData(ctx->log_id, ctx->tp, ctx->space_id, ctx->logical_page_no,
                ctx->page_physical_offset, ctx->vlsn, ctx->buf_block, &page_is_empty, &ctx->real_apply_lsn);

        ADD_TRACE_TP(ctx->tp, "apply_rbio");
        u_elapsed = ctx->stat_timer.u_elapsed_point();
        stat_rbio_req(ctx, _stat_rbio_req_apply_lat, u_elapsed);
        stat_segment_cluster_rbio_req(segment, ctx, stat_rbio_req_apply_lat, u_elapsed);
        set_segment_cluster_statistic(segment, stat_rbio_size_count, 1);

        if (st.IsAhead()) {
            if (task->is_secondary_req()
                    && task->read_rule != pspb::RbioRequest::GE) {
                FinishRbioReq(ctx, pspb::RbioResponse::RBIO_AHEAD_FAILED);
            } else {
                FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SUCCESS);
            }
            return;
        } else if (st.IsOk()) {
            FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SUCCESS);
            return;
        } else if (!st.IsCorrupted()) {
            if (st.IsBusy()) {
                break;
            }
            FinishRbioReq(ctx, pspb::RbioResponse::RBIO_TIMEOUT);
            return;
        } else {
            break;
        }
    } while (false);

    if (need_wait_lsn) {
        ConditionScheduleNextAction(ctx, Action::kWaitLsn, segment, ctx->vlsn);
    } else {
        ScheduleNextAction(ctx, Action::kPrepare);
    }
}

void RbioManager::WaitLsn(Context* ctx) {
    rbio_define_control_or_return_invalid(ctx);
    rbio_define_segment_or_return_invalid(ctx);

    if (ctx->fetch_begin_time <= 0) {
        ctx->fetch_begin_time = base::cpuwide_time_us();
        ctx->vlsn_diff_fetch = diff_rbio_lsn(ctx->vlsn, segment->fetch_lsn());
        ctx->vlsn_diff_ls_dispatch_lsn = diff_rbio_lsn(ctx->vlsn, segment->ls_dispatch_lsn());

        if (task->is_secondary_req() && task->secondary_fetch_lsn > 0) {
            ctx->secondary_fetch_diff_fetch = diff_rbio_lsn(task->secondary_fetch_lsn, segment->fetch_lsn());
            ctx->secondary_fetch_diff_parse = diff_rbio_lsn(task->secondary_fetch_lsn, segment->parse_lsn());
            ctx->secondary_ls_dispatch_diff_fetch = diff_rbio_lsn(task->secondary_ls_dispatch_lsn, segment->fetch_lsn());
            ctx->secondary_ls_dispatch_diff_parse = diff_rbio_lsn(task->secondary_ls_dispatch_lsn, segment->parse_lsn());
        }
    }

    if (ctx->lowest_lsn && segment->parse_lsn() < ctx->lowest_lsn) {
        FinishRbioReqWithError(ctx, pspb::RbioResponse::RBIO_LSN_WAIT);
        return;
    }

    const bool need_wait_lsn = rbio_req_need_wait_lsn(task, ctx, segment);
    if (ctx->fetch_end_time <= 0 && !need_wait_lsn) {
        ctx->fetch_end_time = base::cpuwide_time_us();
        ctx->fetch_lsn_retry_times = ctx->retry_times;
    }

    if (need_wait_lsn) {
        if (ctx->retry_times == 0) {
            const auto diff_lsn = diff_rbio_lsn(ctx->vlsn, segment->parse_lsn());
            stat_rbio_req(ctx, _stat_rbio_req_lsn_behind_size, diff_lsn);
            stat_segment_cluster_rbio_req(segment, ctx, stat_rbio_req_lsn_behind_size, diff_lsn);
        }

        stat_rbio_req(ctx, _stat_rbio_req_interrupt_by_lsn_qps, 1);
        LOG(TRACE) << segment << " wait lsn,"
            << " vlsn:[" << ctx->vlsn
            << "] parse_lsn:[" << segment->parse_lsn()
            << "]";

        const uint32_t index = ((1u + ctx->retry_times) / STAT_TIMES_STEP) - 1;
        if (index < 4 && ctx->vlsn_diff_fetch_after_retry_xx[index] < 0) {
            ctx->vlsn_diff_fetch_after_retry_xx[index] = diff_rbio_lsn(ctx->vlsn, segment->fetch_lsn());
            ctx->vlsn_diff_ls_dispatch_lsn_after_retry_xx[index] = diff_rbio_lsn(ctx->vlsn, segment->ls_dispatch_lsn());
        }

        control->fetcher()->Wakeup(segment);
        if (FLAGS_psvr_rbio_enable_wait_queue) {
            RetryConditionSchedule(ctx, segment, ctx->vlsn);
        } else {
            RetryOrErrorRbioReq(ctx);
        }
        return;
    }

    // parse_lsn >= vlsn ok
    ctx->parse_end_time = base::cpuwide_time_us();
    const auto u_elapsed = ctx->stat_timer.u_elapsed_point();
    // stat
    stat_rbio_req(ctx, _stat_rbio_req_wait_lsn_lat, u_elapsed);
    stat_segment_cluster_rbio_req(segment, ctx, stat_rbio_req_wait_lsn_lat, u_elapsed);
    stat_segment_cluster_rbio_req(segment, ctx, stat_rbio_req_retry_times_avg, ctx->retry_times);

    ADD_TRACE_TP(ctx->tp, "wait_lsn");
    ScheduleNextAction(ctx, Action::kPrepare);
}

void RbioManager::GetSpaceExtent(Context* ctx) {
    rbio_define_control_or_return_invalid(ctx);
    rbio_define_segment_or_return_invalid(ctx);

    const gaia_apply::space_id_t space_id = ctx->space_id;
    const auto begin_extent_id = calc_begin_extent_id(ctx->logical_page_no);
    if (!segment->GetSpaceExtentReqLock(space_id, begin_extent_id)) {
        RetryOrErrorRbioReq(ctx);
        return;
    }

    PsmInfoPtr psm_info = segment->GetPsmInfo();
    std::vector<base::EndPoint> nodes;
    if (!psm_info->GetOrRefreshNodes(&nodes)) {
        control->RefreshPsmInfo(psm_info);
        segment->PutSpaceExtentReqLock(space_id, begin_extent_id);
        RetryOrErrorRbioReq(ctx);
        return;
    }

    auto rpc_ctx = new RpcGetSpaceExtentMapCtx;
    rpc_ctx->servers = std::move(nodes);
    rpc_ctx->request.set_space_id(space_id);
    rpc_ctx->request.set_begin_extent_id(begin_extent_id);
    rpc_ctx->request.set_num(FLAGS_psvr_get_extent_size);
    rpc_ctx->request.set_need_physical_extent_id(true);
    rpc_ctx->request.set_use_bytes(FLAGS_psvr_get_extent_map_with_high_performance);
    rpc_ctx->request.set_cluster_id(segment->cluster_id());

    auto rpc_closure = brpc::NewCallback(this, &RbioManager::OnGetSpaceExtent, ctx, rpc_ctx);
    control->client()->GetSpaceExtentMap(rpc_ctx, rpc_closure);
}

void RbioManager::OnGetSpaceExtent(Context* ctx, RpcGetSpaceExtentMapCtx* rpc_ctx) {
    std::unique_ptr<RpcGetSpaceExtentMapCtx> rpc_ctx_guard(rpc_ctx);
    rbio_define_control_or_return_invalid(ctx);
    rbio_define_segment_or_return_invalid(ctx);

    PsmInfoPtr psm_info = segment->GetPsmInfo();
    const gaia_apply::space_id_t space_id = ctx->space_id;
    const auto begin_extent_id = calc_begin_extent_id(ctx->logical_page_no);
    bool not_exists = false;
    if (rpc_failed(rpc_ctx, &not_exists)) {
        if (!not_exists) {
            if (rpc_ctx->RetryNext()) {
                auto rpc_closure = brpc::NewCallback(this, &RbioManager::OnGetSpaceExtent,
                        ctx, rpc_ctx_guard.release());
                control->client()->GetSpaceExtentMap(rpc_ctx, rpc_closure);
            } else {
                control->RefreshPsmInfo(psm_info);
                segment->PutSpaceExtentReqLock(space_id, begin_extent_id);
                RetryOrErrorRbioReq(ctx);
            }
            return;
        }
    }

    psm_info->MoveLeaderToFirst(rpc_ctx->idx, rpc_ctx->current_server());
    segment->SetSpaceExtent(space_id, begin_extent_id,
            ExtentArg {kInvalidExtentId, ctx->logical_page_no}, not_exists, rpc_ctx->response);
    if (not_exists) {
        control->parser()->Dispatch(segment TRACE_FILE_LINE_CC, 0);
    }
    RetryOrErrorRbioReq(ctx, true);
}

void RbioManager::Prepare(Context* ctx) {
    rbio_define_control_or_return_invalid(ctx);
    rbio_define_segment_or_return_invalid(ctx);

    const bool direct_meta = FLAGS_psvr_rbio_enable_direct_get_meta;
    ctx->buf_block = control->buf_pool()->GetOrAllocBufBlock(gaia_physical_page_size());
    if (!ctx->buf_block) {
        PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << segment << " rbio get buf block failed, " << ctx;
        RetryOrErrorRbioReq(ctx);
        return;
    }

    init_buf_block(ctx->buf_block, ctx->space_id, ctx->logical_page_no, gaia_page_size());
    if (task->is_write()) {
        const auto& frame = ctx->write_req->data().c_str();
        if (ctx->write_req->data().size() != gaia_physical_page_size()) {
            PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << segment
                << " write page data size mismatch,"
                << " expected:[" << gaia_physical_page_size()
                << "] actual:[" << ctx->write_req->data().size()
                << "]";
            FinishRbioReq(ctx, pspb::WritePageResponse::ERROR);
            return;
        }
        std::memcpy(ctx->buf_block->frame, frame, gaia_physical_page_size());
    }

    if (task->req_has_physical_extent_id) {
        LOG(TRACE) << segment << " rbio req with offset," << ctx;
        ctx->page_physical_offset = calc_physical_offset_by_extent_id(task->req_physical_extent_id, ctx->logical_page_no);
    } else {
        ctx->page_physical_offset = kInvalidOffset;
        bool ret = segment->GetSpacePagePhysicalOffset(ctx->space_id, ctx->logical_page_no, &ctx->page_physical_offset);
        if (!ret) {
            interrupt_rbio_req_if_in_recovery(ctx);
            stat_rbio_req(ctx, _stat_rbio_req_interrupt_by_space_extent_qps, 1);
            LOG(TRACE) << segment << " rbio req got offset cache failed," << ctx;
            if (direct_meta) {
                GetSpaceExtent(ctx);
            } else {
                control->parser()->AddGetSpaceExtentEvent(segment TRACE_FILE_LINE_CC,
                        ctx->space_id, ctx->logical_page_no, nullptr, nullptr);
                RetryOrErrorRbioReq(ctx);
            }
            return;
        }
    }

    const auto u_elapsed = ctx->stat_timer.u_elapsed_point();
    stat_rbio_req(ctx, _stat_rbio_req_prepare_lat, u_elapsed);
    stat_segment_cluster_rbio_req(segment, ctx, stat_rbio_req_prepare_lat, u_elapsed);

    ADD_TRACE_TP(ctx->tp, "prepare");
    ScheduleNextAction(ctx,
            task->is_read() ? Action::kReadPage : Action::kWritePage);
}

void RbioManager::ReadPage(Context* ctx) {
    rbio_define_control_or_return_invalid(ctx);
    rbio_define_segment_or_return_invalid(ctx);

    if (ctx->size > gaia_apply::FLAGS_univ_page_size) {
        PSVR_LOG_EVERY_SECOND_CTX(ERROR, ctx) << segment << " rbio page size invalid,"
            << " size:[" << ctx->size
            << "] logical_page_size:[" << gaia_logical_page_size()
            << "]";
        FinishRbioReq(ctx, pspb::RbioResponse::RBIO_INVALID);
        return;
    }

    db::Status st;
    do {
        if (task->read_rule != pspb::RbioRequest::LE) {
            PSVR_ASSERT(segment->parse_lsn() >= ctx->vlsn);
        }

        bool page_is_empty = false;
        st = segment->ReadPageData(ctx->log_id, ctx->tp, ctx->space_id, ctx->logical_page_no,
                ctx->page_physical_offset, ctx->vlsn, ctx->buf_block, &page_is_empty, &ctx->real_apply_lsn);

        ADD_TRACE_TP(ctx->tp, "apply");
        const auto u_elapsed = ctx->stat_timer.u_elapsed_point();
        stat_rbio_req(ctx, _stat_rbio_req_apply_lat, u_elapsed);
        stat_segment_cluster_rbio_req(segment, ctx, stat_rbio_req_apply_lat, u_elapsed);
        set_segment_cluster_statistic(segment, stat_rbio_size_count, 1);
        const bool is_peer_read = task->is_peer_read;

        if (st.IsAhead()) {
            if (is_peer_read) {
                FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SUCCESS);
            } else {
                if (task->is_secondary_req()
                        && task->read_rule != pspb::RbioRequest::GE) {
                    FinishRbioReq(ctx, pspb::RbioResponse::RBIO_AHEAD_FAILED);
                } else {
                    FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SUCCESS);
                }
            }
            return;
        } else if (st.IsOk()) {
            if (is_peer_read) {
                FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SUCCESS);
            } else {
                if (!page_is_empty || segment->recovery_status_is_finish()) {
                    FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SUCCESS);
                } else {
                    // try read peer, if doubt empty page of mysql rbio
                    break;
                }
            }
            return;
        } else if (!st.IsCorrupted()) {
            if (st.IsBusy()) {
                RetryOrErrorRbioReq(ctx);
            } else {
                FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SERVER_ERROR);
            }
            return;
        } else {
            if (is_peer_read) {
                FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SERVER_ERROR);
            } else {
                // corrupt of mysql rbio
                break;
            }
            return;
        }
    } while (false);

    if (!FLAGS_psvr_rbio_transfer_req_in_recovery){
        FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SEGMENT_INACTIVE);
        return;
    }

    PSVR_LOG_EVERY_SECOND_CTX(NOTICE, ctx) << segment << " try to read rbio from peer, " << ctx << " " << st;
    std::vector<gaiadb::common::PeerZone> peers;
    bool ret = segment->GetPeerNodes(&peers);
    if (!ret) {
        if (peers.empty()) {
            control->parser()->AddGetPeerEvent(segment TRACE_FILE_LINE_CC, nullptr, nullptr);
            RetryOrErrorRbioReq(ctx);
            return;
        } else {
            control->parser()->AddGetPeerEvent(segment TRACE_FILE_LINE_CC, nullptr, nullptr);
        }
    }

    auto read_peer_page_ctx = new ReadPeerPageContext(ctx->space_id,
            ctx->logical_page_no, ctx->vlsn, peers, ctx->buf_block);

    auto closure = brpc::NewCallback(this, &RbioManager::OnReadPeerPage, ctx, read_peer_page_ctx);
    segment->ReadPeerPage(read_peer_page_ctx, closure);
}

void RbioManager::OnReadPeerPage(Context* ctx, ReadPeerPageContext* read_peer_page_ctx) {
    std::unique_ptr<ReadPeerPageContext> read_peer_page_ctx_guard(read_peer_page_ctx);
    rbio_define_segment_or_return_invalid(ctx);

    if (!read_peer_page_ctx->response.success) {
        PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << segment << " rbio failed";
        FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SERVER_ERROR);
        return;
    }

    ctx->real_apply_lsn = std::max(ctx->vlsn, buf_block_get_page_lsn(ctx->buf_block));
    if (ctx->real_apply_lsn > ctx->vlsn) {
        if (ctx->task->is_secondary_req()
                && ctx->task->read_rule != pspb::RbioRequest::GE) {
            PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << segment << " rbio failed page lsn > vlsn, " << ctx;
            FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SERVER_ERROR);
        } else {
            FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SUCCESS);
        }
    } else {
        FinishRbioReq(ctx, pspb::RbioResponse::RBIO_SUCCESS);
    }
}

void RbioManager::WritePage(Context* ctx) {
    rbio_define_segment_or_return_invalid(ctx);

    bool is_empty = false;
    if (buf_block_is_corrupted(ctx->buf_block, &is_empty)) {
        PSVR_LOG_EVERY_SECOND_CTX(ERROR, ctx) << segment << " write page data corrupted, " << ctx;
        FinishRbioReq(ctx, pspb::WritePageResponse::ERROR);
        return;
    }

    const uint64_t physical_page_no = ctx->page_physical_offset / gaia_physical_page_size();
    db::PageLockPtr page_lock = segment->GetPageLock(physical_page_no);
    db::PageUniqueLock lm(page_lock);

    db::Status s = segment->WritePhysicalPageData(ctx->log_id,
            ctx->space_id, ctx->logical_page_no, ctx->page_physical_offset,
            gaia_physical_page_size(), ctx->buf_block->frame);
    if (!s.IsOk()) {
        FinishRbioReq(ctx, pspb::WritePageResponse::ERROR);
        return;
    }

    PSVR_LOG_CTX(TRACE, ctx) << segment << " write page success,"
            << " space_id:[" << ctx->space_id
            << "] start_page_no:[" << ctx->logical_page_no
            << "]";

    FinishRbioReq(ctx, pspb::WritePageResponse::SUCCESS);
}

}
