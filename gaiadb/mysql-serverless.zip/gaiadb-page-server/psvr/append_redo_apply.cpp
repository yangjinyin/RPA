/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/append_redo_apply.cpp
* @author yukeyong@baidu.com
* @brief Append file redo log iterator for page apply
*/

#include <cstdlib>
#include <cstring>

#include "psvr/append_redo_apply.h"
#include "psvr/append_file.h"
#include "psvr/log_block.h"
#include "psvr/page_op.h"
#include "psvr/redo_record.h"
#include "psvr/segment.h"

namespace psvr {

AppendLogRecordIterator::AppendLogRecordIterator(AppendDBEnginePtr append_db_engine,
        int64_t log_id,
        uint64_t physical_offset,
        gaia_apply::lsn_t start_lsn,
        gaia_apply::lsn_t apply_end_lsn,
        AppendReadBuf* read_buf)
    : _append_db_engine(append_db_engine),
    _read_buf(read_buf),
    _log_id(log_id),
    _physical_offset(physical_offset),
    _start_lsn(start_lsn),
    _apply_end_lsn(apply_end_lsn),
    _status(),
    _record_storage(),
    _record_initialized(false),
    _redo_buf(nullptr, &std::free),
    _offset_cache_arena(new gaiadb::common::MemArena()),
    _offset_cache(new KeyValueCache<uint64_t, uint32_t>(
            _offset_cache_arena.get())),
    _log_header(),
    _key(),
    _value(),
    _redo_ptr(nullptr),
    _redo_end(nullptr),
    _redo_scan_ptr(nullptr),
    _next_seek_lsn(start_lsn),
    _last_rec_end_lsn(0),
    _fno(0),
    _offset(0),
    _valid(false),
    _finished(false),
    _returned_size(0) {
}

db::Status AppendLogRecordIterator::Init() {
    _status.Reset(db::Code::kOk);
    ResetRecord();
    ClearRedoBlock();
    _next_seek_lsn = _start_lsn;
    _last_rec_end_lsn = 0;
    _fno = 0;
    _offset = 0;
    _valid = false;
    _finished = false;
    _returned_size = 0;
    return LoadNextRecord();
}

bool AppendLogRecordIterator::Valid() const {
    return _valid;
}

void AppendLogRecordIterator::Next() {
    if (!_valid || !_status.IsOk()) {
        return;
    }
    ++_returned_size;
    ResetRecord();
    _valid = false;
    _status = LoadNextRecord();
}

const LogRecord& AppendLogRecordIterator::Get() const {
    return *MutableRecord();
}

void AppendLogRecordIterator::ClearRedoBlock() {
    _redo_buf.reset();
    _offset_cache.reset();
    _offset_cache_arena.reset();
    _key.clear();
    _value.clear();
    _redo_ptr = nullptr;
    _redo_end = nullptr;
    _redo_scan_ptr = nullptr;
}

void AppendLogRecordIterator::ResetRecord() {
    if (_record_initialized) {
        MutableRecord()->~LogRecord();
        _record_initialized = false;
    }
}

LogRecord* AppendLogRecordIterator::MutableRecord() {
    return reinterpret_cast<LogRecord*>(_record_storage);
}

const LogRecord* AppendLogRecordIterator::MutableRecord() const {
    return reinterpret_cast<const LogRecord*>(_record_storage);
}

bool AppendLogRecordIterator::GetCurrentRecordPhysicalOffset(gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no,
        uint64_t* physical_offset) {
    if (!physical_offset) {
        _status.Reset(db::Code::kInvalid, "physical_offset pointer is null");
        return false;
    }
    if (!_offset_cache || !_offset_cache->is_init()) {
        // The offset cache must be initialized before resolving a page offset.
        PSVR_ASSERT(false);
        return false;
    }
    if (!get_physical_offset_from_cache(
                *_offset_cache, space_id, page_no, physical_offset)) {
        // A page modification record must have its fold entry in the key.
        PSVR_ASSERT(false);
        return false;
    }
    return true;
}

db::Status AppendLogRecordIterator::LoadNextRecord() {
    if (!_status.IsOk()) {
        return _status;
    }

    while (true) {
        if (_finished) {
            _valid = false;
            return _status;
        }

        if (_redo_scan_ptr) {
            auto st = ParseNextRecord();
            if (!st.IsOk()) {
                _status = st;
                _valid = false;
                return _status;
            }
            if (_valid) {
                return _status;
            }
            if (_finished) {
                return _status;
            }
        }

        auto st = LoadNextRedoBlock();
        if (!st.IsOk()) {
            _status = st;
            _valid = false;
            return _status;
        }
    }
}

bool AppendLogRecordIterator::IsCurrentRecordApplicable(gaia_apply::mlog_id_t type,
        gaia_apply::lsn_t rec_start_lsn,
        gaia_apply::lsn_t rec_end_lsn,
        gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no,
        uint64_t* physical_offset) {
    if (is_file_delete_record(type)) {
        // File-delete records carry no fold entry in the key; not applicable to a page.
        return false;
    }
    if (!gaia_apply::is_mtr_page_modification_type(type)) {
        return false;
    }
    if (rec_end_lsn <= _start_lsn) {
        return false;
    }
    if (rec_start_lsn > _apply_end_lsn) {
        return false;
    }
    if (!GetCurrentRecordPhysicalOffset(space_id, page_no, physical_offset)) {
        return false;
    }
    return *physical_offset == _physical_offset;
}

db::Status AppendLogRecordIterator::ParseNextRecord() {
    ResetRecord();
    _valid = false;

    if (!_redo_scan_ptr) {
        return _status;
    }

    while (_redo_scan_ptr < _redo_end) {
        const auto remaining =
                static_cast<size_t>(_redo_end - _redo_scan_ptr);
        if (remaining <= sizeof(uint64_t)) {
            _status.Reset(
                    db::Code::kCorrupted,
                    "append redo record is incomplete, "
                    "log_id:%ld remaining:%lu",
                    _log_id,
                    remaining);
            return _status;
        }

        auto rec_end_lsn = get_record_end_lsn(_redo_scan_ptr);
        if (_last_rec_end_lsn != 0 && _last_rec_end_lsn >= rec_end_lsn) {
            _status.Reset(db::Code::kCorrupted,
                    "log_id:%ld, page_lsn > rec_lsn, rec_lsn:[%lu] last_rec_lsn:[%lu]",
                    _log_id, rec_end_lsn, _last_rec_end_lsn);
            return _status;
        }
        _last_rec_end_lsn = rec_end_lsn;
        if (rec_end_lsn > _apply_end_lsn) {
            _finished = true;
            return _status;
        }

        auto* record_start = _redo_scan_ptr + 8;
        LogRecord* record = nullptr;
        gaia_apply::ulint record_len = 0;
        _status = parse_append_redo_record(
                record_start,
                _redo_end,
                rec_end_lsn,
                _record_storage,
                &record,
                &record_len);
        if (!_status.IsOk()) {
            return _status;
        }
        if (record->end_lsn > _log_header.end_lsn) {
            _status.Reset(db::Code::kCorrupted,
                    "append redo record exceeds block lsn, "
                    "log_id:%ld record_end_lsn:%lu block_end_lsn:%lu",
                    _log_id, record->end_lsn, _log_header.end_lsn);
            return _status;
        }

        _redo_scan_ptr = record_start + record_len;
        _record_initialized = true;

        uint64_t current_physical_offset = 0;
        if (!IsCurrentRecordApplicable(
                    record->type,
                    record->start_lsn,
                    record->end_lsn,
                    record->space_id,
                    record->page_no,
                    &current_physical_offset)) {
            ResetRecord();
            if (!_status.IsOk()) {
                return _status;
            }
            continue;
        }

        _valid = true;
        return _status;
    }

    _redo_scan_ptr = nullptr;
    if (!_finished && _next_seek_lsn >= _apply_end_lsn) {
        _finished = true;
    }
    return _status;
}

db::Status AppendLogRecordIterator::LoadNextRedoBlock() {
    ClearRedoBlock();

    while (true) {
        if (!_append_db_engine) {
            _status.Reset(db::Code::kInvalid, "append db engine is null");
            return _status;
        }

        db::LogHeader log_header;
        base::Slice key;
        base::Slice value;
        char* buf = nullptr;
        auto fno = _fno;
        auto offset = _offset;
        auto st = _append_db_engine->FetchRedoLog(_next_seek_lsn,
                &log_header, &key, &value, &buf, fno, offset, _read_buf);
        if (st.IsNotFound() || st.IsEof()) {
            if (buf) {
                std::free(buf);
            }
            if (_next_seek_lsn < _apply_end_lsn) {
                _status.Reset(db::Code::kMissData,
                        "append redo log miss data, log_id:%ld seek_lsn:%lu apply_end_lsn:%lu",
                        _log_id, _next_seek_lsn, _apply_end_lsn);
                return _status;
            }
            _finished = true;
            _status.Reset(db::Code::kOk);
            return _status;
        }
        if (!st.IsOk()) {
            if (buf) {
                std::free(buf);
            }
            return st;
        }

        st = validate_append_redo_block(log_header, key, value);
        if (!st.IsOk()) {
            if (buf) {
                std::free(buf);
            }
            _status = st;
            return _status;
        }

        if (log_header.start_lsn >= log_header.end_lsn
                || log_header.end_lsn <= _next_seek_lsn) {
            if (buf) {
                std::free(buf);
            }
            _status.Reset(db::Code::kCorrupted,
                    "append redo block lsn does not advance, "
                    "log_id:%ld seek_lsn:%lu range:%lu-%lu",
                    _log_id, _next_seek_lsn,
                    log_header.start_lsn, log_header.end_lsn);
            return _status;
        }

        _log_header = log_header;
        _fno = fno;
        _offset = offset;
        _next_seek_lsn = _log_header.end_lsn;
        if (_log_header.end_lsn <= _start_lsn) {
            if (buf) {
                std::free(buf);
            }
            _status.Reset(db::Code::kOk);
            // The skipped block already reaches the apply boundary, so the
            // range is fully consumed. Fetching one more block would seek past
            // the tail of the append data and fail with kMissData.
            if (_next_seek_lsn >= _apply_end_lsn) {
                _finished = true;
                return _status;
            }
            continue;
        }
        if (_log_header.start_lsn >= _apply_end_lsn) {
            if (buf) {
                std::free(buf);
            }
            _finished = true;
            _status.Reset(db::Code::kOk);
            return _status;
        }
        if (_log_header.fold_size == 0) {
            // No fold entries: the block carries no page modification records.
            if (buf) {
                std::free(buf);
            }
            _status.Reset(db::Code::kOk);
            // Same boundary guard as above: a fold-less tail block must not
            // trigger an extra seek at exactly _apply_end_lsn.
            if (_next_seek_lsn >= _apply_end_lsn) {
                _finished = true;
                return _status;
            }
            continue;
        }

        _key = key;
        _value = value;
        _offset_cache_arena.reset(new gaiadb::common::MemArena());
        _offset_cache.reset(new KeyValueCache<uint64_t, uint32_t>(
                _offset_cache_arena.get()));
        // Init with buf decodes the fold entries in native byte order.
        _offset_cache->Init(_log_header.fold_size, const_cast<char*>(_key.data()));
        _redo_buf.reset(buf);
        _redo_ptr = reinterpret_cast<gaia_apply::byte*>(const_cast<char*>(_value.data()));
        _redo_end = _redo_ptr + _value.size();
        _redo_scan_ptr = _redo_ptr;
        _status.Reset(db::Code::kOk);
        return _status;
    }
}

} // namespace psvr
