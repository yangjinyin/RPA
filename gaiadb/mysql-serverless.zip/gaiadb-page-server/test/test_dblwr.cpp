/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_dblwr.cpp
* @author yukeyong@baidu.com
* @brief Unit tests for Dblwr (double-write buffer)
*/

#include <fcntl.h>
#include <sys/stat.h>
#include <filesystem>
#include <mutex>
#include "test/test_common.h"
#include "psvr/dblwr.h"
#include "bmock.h"

namespace psvr {
namespace test {

// The parameter lists below are spelled the way the demangler spells them (iovec const*,
// unsigned long, long instead of const struct iovec*, size_t, off_t) on purpose: bmock
// builds the lookup key "ns::name(params)" and matches it against the demangled symbol
// table with a *prefix* compare, falling back to the bare "ns::name" only when that key
// misses. A key carrying the full parameter list therefore matches exactly one symbol;
// with the C spellings the key misses, and the bare-name fallback also hijacks the sibling
// symbols psvr::db::preadx / psvr::db::pwritevx. fstat keeps the C spelling only because
// the demangled "stat*" collides with the psvr::db::stat function name in C++; it has no
// sibling symbol, so its fallback cannot hijack anything.
BMOCK_NS_METHOD3(psvr, page_is_corrupted, bool(unsigned char const*, unsigned int, bool*));
BMOCK_NS_METHOD4(psvr::db, pwritev, ssize_t(int, iovec const*, int, long));
BMOCK_NS_METHOD4(psvr::db, pread, ssize_t(int, void*, unsigned long, long));
BMOCK_NS_METHOD2(psvr::db, fstat, int(int, struct stat*));

// Helper: write space_id and page_no into a raw frame at the standard InnoDB offsets.
static void make_test_frame(gaia_apply::byte* frame, gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no) {
    memset(frame, 0, gaia_apply::FLAGS_univ_page_size);
    gaia_apply::mach_write_to_4(frame + gaia_apply::FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, space_id);
    gaia_apply::mach_write_to_4(frame + gaia_apply::FIL_PAGE_OFFSET, page_no);
}

class DblwrTests : public PsvrTest {
public:
    DblwrTests() {}
    virtual ~DblwrTests() {}

    void SetUp() {
        gaia_apply::page_size_t page_size(16 << 10, 16 << 10, false);

        std::filesystem::create_directories("./data");
        char tmp[] = "./data/test_dblwr_XXXXXX";
        ASSERT_NE(mkdtemp(tmp), nullptr);
        _tmp_dir = tmp;

        _dblwr = std::make_shared<Dblwr>();

        // The mock objects created by BMOCK_NS_METHOD attach their hooks at static-init
        // time, so they would stay in effect for the whole binary. Stop them all here and
        // let each test enable only the ones it injects with BMOCK_NS_RESUME.
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(unsigned char const*, unsigned int, bool*));
        BMOCK_NS_STOP(psvr::db, pwritev, ssize_t(int, iovec const*, int, long));
        BMOCK_NS_STOP(psvr::db, pread, ssize_t(int, void*, unsigned long, long));
        BMOCK_NS_STOP(psvr::db, fstat, int(int, struct stat*));
    }

    void TearDown() {
        _dblwr.reset();
        std::error_code ec;
        std::filesystem::remove_all(_tmp_dir, ec);
    }

protected:
    std::string _tmp_dir;
    DblwrPtr _dblwr;
};

// --- Open ---

TEST_F(DblwrTests, test_Open_empty_dir) {
    {
        // Open on an empty directory: succeeds and max_ckp_lsn == 0
        gaia_apply::lsn_t max_ckp_lsn = 999;
        auto st = _dblwr->Open(4, _tmp_dir, &max_ckp_lsn);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(max_ckp_lsn, 0);
    }
    END_OF_CASE;
}

TEST_F(DblwrTests, test_Open_nonexistent_dir_creates_it) {
    {
        // Open on a non-existent sub-directory: should create it and succeed
        std::string new_dir = _tmp_dir + "/sub";
        gaia_apply::lsn_t max_ckp_lsn = 0;
        auto st = _dblwr->Open(4, new_dir, &max_ckp_lsn);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_TRUE(std::filesystem::exists(new_dir));
    }
    END_OF_CASE;
}

// --- Write / Read from mutable _buf ---

TEST_F(DblwrTests, test_Write_Read_by_space_page) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());

        const gaia_apply::space_id_t space_id = 10;
        const gaia_apply::page_no_t page_no = 20;
        const uint64_t offset = 0;

        // Prepare src frame
        auto* src = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, space_id, page_no);

        auto st = _dblwr->Write(space_id, page_no, src, offset, kDblwrFlagsNone);
        ASSERT_TRUE(st.IsOk()) << st;

        // Read back by (space_id, page_no)
        auto* dst = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        memset(dst, 0xff, gaia_apply::FLAGS_univ_page_size);
        st = _dblwr->Read(space_id, page_no, offset, dst);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(memcmp(src, dst, gaia_apply::FLAGS_univ_page_size), 0);

        std::free(src);
        std::free(dst);
    }
    END_OF_CASE;
}

TEST_F(DblwrTests, test_Write_Read_by_offset) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());

        const gaia_apply::space_id_t space_id = 5;
        const gaia_apply::page_no_t page_no = 7;
        const uint64_t offset = 3 * gaia_apply::FLAGS_univ_page_size;

        auto* src = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, space_id, page_no);
        src[100] = 0xAB;

        ASSERT_TRUE(_dblwr->Write(space_id, page_no, src, offset, kDblwrFlagsNone).IsOk());

        // Read back by offset (passed as uint32_t, offset / page_size interpreted inside Dblwr)
        // Dblwr::Read(uint32_t offset, ...) stores offset as-is in offs_to_frame
        auto* dst = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        memset(dst, 0, gaia_apply::FLAGS_univ_page_size);
        auto st = _dblwr->Read(static_cast<uint32_t>(offset), dst);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[100], 0xAB);

        std::free(src);
        std::free(dst);
    }
    END_OF_CASE;
}

TEST_F(DblwrTests, test_Read_NotFound_when_empty) {
    {
        // No Open called, no Write done: Read should return NotFound
        auto* dst = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));

        auto st = _dblwr->Read(static_cast<gaia_apply::space_id_t>(1),
                static_cast<gaia_apply::page_no_t>(1), static_cast<uint64_t>(0), dst);
        ASSERT_TRUE(st.IsNotFound()) << st;

        st = _dblwr->Read(static_cast<uint32_t>(0), dst);
        ASSERT_TRUE(st.IsNotFound()) << st;

        std::free(dst);
    }
    END_OF_CASE;
}

TEST_F(DblwrTests, test_Write_overwrites_same_page) {
    {
        // Write the same (space_id, page_no) twice: second write wins in _buf
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());

        const gaia_apply::space_id_t space_id = 1;
        const gaia_apply::page_no_t page_no = 1;
        const uint64_t offset1 = 0;
        const uint64_t offset2 = gaia_apply::FLAGS_univ_page_size;

        auto* frame1 = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(frame1, space_id, page_no);
        frame1[200] = 0x11;

        auto* frame2 = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(frame2, space_id, page_no);
        frame2[200] = 0x22;

        ASSERT_TRUE(_dblwr->Write(space_id, page_no, frame1, offset1, kDblwrFlagsNone).IsOk());
        ASSERT_TRUE(_dblwr->Write(space_id, page_no, frame2, offset2, kDblwrFlagsNone).IsOk());

        auto* dst = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        // Should find the most recent write (frame2) under offset2
        auto st = _dblwr->Read(space_id, page_no, offset2, dst);
        ASSERT_TRUE(st.IsOk()) << st;
        // frame2 is written at offset2; Read with matching offset returns it
        ASSERT_EQ(dst[200], 0x22);

        memset(dst, 0, gaia_apply::FLAGS_univ_page_size);
        // frame1 is still accessible via offset1
        st = _dblwr->Read(space_id, page_no, offset1, dst);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[200], 0x11);

        std::free(frame1);
        std::free(frame2);
        std::free(dst);
    }
    END_OF_CASE;
}

// --- WriteCkpLsn / ReadCkpLsn ---

TEST_F(DblwrTests, test_WriteCkpLsn_ReadCkpLsn) {
    {
        // No buf yet: ReadCkpLsn returns NotFound
        gaia_apply::lsn_t lsn = 999;
        auto st = _dblwr->ReadCkpLsn(&lsn);
        ASSERT_TRUE(st.IsNotFound()) << st;
    }
    END_OF_CASE;

    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());

        // WriteCkpLsn allocates a buf if one doesn't exist
        ASSERT_TRUE(_dblwr->WriteCkpLsn(12345).IsOk());

        gaia_apply::lsn_t lsn = 0;
        ASSERT_TRUE(_dblwr->ReadCkpLsn(&lsn).IsOk());
        ASSERT_EQ(lsn, 12345);

        // Second write updates ckp_lsn[1] (last), ckp_lsn[0] (first) stays at first value
        ASSERT_TRUE(_dblwr->WriteCkpLsn(99999).IsOk());
        ASSERT_TRUE(_dblwr->ReadCkpLsn(&lsn).IsOk());
        ASSERT_EQ(lsn, 99999);
    }
    END_OF_CASE;
}

// --- HasBufs / DumpBuf ---

TEST_F(DblwrTests, test_HasBufs_empty) {
    {
        // Fresh dblwr with no writes: HasBufs == false
        ASSERT_FALSE(_dblwr->HasBufs());
        ASSERT_EQ(_dblwr->DumpBuf(), nullptr);
        ASSERT_EQ(_dblwr->NextDumpFileNo(), 0);
        ASSERT_EQ(_dblwr->bufs_size(), 0u);
    }
    END_OF_CASE;
}

// --- in_dump lock ---

TEST_F(DblwrTests, test_in_dump_lock) {
    {
        // Initially not in_dump
        ASSERT_FALSE(_dblwr->in_dump());

        // First acquire succeeds
        ASSERT_TRUE(_dblwr->acquire_in_dump());
        ASSERT_TRUE(_dblwr->in_dump());

        // Second acquire (try_lock) fails while held
        ASSERT_FALSE(_dblwr->acquire_in_dump());

        // Release, then acquire again
        _dblwr->release_in_dump();
        ASSERT_FALSE(_dblwr->in_dump());
        ASSERT_TRUE(_dblwr->acquire_in_dump());
        _dblwr->release_in_dump();
    }
    END_OF_CASE;
}

// --- SealBuf and Open roundtrip ---

TEST_F(DblwrTests, test_Write_full_triggers_SealBuf_and_Open_reload) {
    {
        // max_page_num = 1: the first Write seals the buf and creates a file
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_FALSE(_dblwr->HasBufs());

        const gaia_apply::space_id_t space_id = 3;
        const gaia_apply::page_no_t page_no = 4;
        const uint64_t offset = 0;

        auto* src = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, space_id, page_no);
        src[50] = 0xDE;
        src[51] = 0xAD;

        auto st = _dblwr->Write(space_id, page_no, src, offset, kDblwrFlagsNone);
        ASSERT_TRUE(st.IsOk()) << st;

        // After SealBuf: HasBufs should be true, one sealed buf
        ASSERT_TRUE(_dblwr->HasBufs());
        ASSERT_EQ(_dblwr->bufs_size(), 1u);

        // DumpBuf returns the sealed buf (oldest = back of list)
        DblwrBufPtr sealed_buf = _dblwr->DumpBuf();
        ASSERT_NE(sealed_buf, nullptr);
        ASSERT_EQ(sealed_buf->footer.page_num, 1u);
        ASSERT_EQ(_dblwr->NextDumpFileNo(), sealed_buf->footer.fno);

        // Verify we can Read from the sealed buf by (space_id, page_no)
        auto* dst = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        st = _dblwr->Read(space_id, page_no, offset, dst);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[50], 0xDE);
        ASSERT_EQ(dst[51], 0xAD);

        // RemoveBuf deletes the file and removes it from _bufs
        st = _dblwr->RemoveBuf(sealed_buf);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_FALSE(_dblwr->HasBufs());
        ASSERT_EQ(_dblwr->bufs_size(), 0u);

        std::free(src);
        std::free(dst);
    }
    END_OF_CASE;

    {
        // Open a new Dblwr on the same dir after RemoveBuf (dir should be empty again)
        auto dblwr2 = std::make_shared<Dblwr>();
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(dblwr2->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_FALSE(dblwr2->HasBufs());
        ASSERT_EQ(max_ckp_lsn, 0u);
    }
    END_OF_CASE;
}

TEST_F(DblwrTests, test_Open_reloads_sealed_file_and_returns_ckp_lsn) {
    {
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(unsigned char const*, unsigned int, bool*));
        // Seal a buf with a checkpoint LSN, then Open a fresh Dblwr on same dir
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        // Write checkpoint LSN before sealing
        ASSERT_TRUE(_dblwr->WriteCkpLsn(5000).IsOk());

        const gaia_apply::space_id_t space_id = 1;
        const gaia_apply::page_no_t page_no = 2;
        auto* src = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, space_id, page_no);

        // This write fills the buf (max_page_num=1) and calls SealBuf
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillRepeatedly(Return(false));

        ASSERT_TRUE(_dblwr->Write(space_id, page_no, src, 0, kDblwrFlagsNone).IsOk());
        ASSERT_TRUE(_dblwr->HasBufs());

        // Open a new Dblwr on the same directory: should load the sealed file
        auto dblwr2 = std::make_shared<Dblwr>();
        gaia_apply::lsn_t recovered_lsn = 0;
        auto st = dblwr2->Open(4, _tmp_dir, &recovered_lsn);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_TRUE(dblwr2->HasBufs());
        ASSERT_EQ(recovered_lsn, 5000u);

        std::free(src);
    }
    END_OF_CASE;
}

// --- Open(): directory entry skipped ---

TEST_F(DblwrTests, test_Open_with_subdirectory) {
    {
        // A subdirectory inside the dblwr dir triggers the is_directory() branch
        // (logged as warning) and is skipped; Open still returns Ok.
        std::error_code ec;
        std::filesystem::create_directory(_tmp_dir + "/sub", ec);
        ASSERT_FALSE(ec);
        gaia_apply::lsn_t max_ckp_lsn = 0;
        auto st = _dblwr->Open(4, _tmp_dir, &max_ckp_lsn);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(max_ckp_lsn, 0u);
    }
    END_OF_CASE;
}

TEST_F(DblwrTests, test_Open_with_tmp_file) {
    {
        // A .tmp file in the dblwr dir is skipped (extension check).
        std::string tmp_file = _tmp_dir + "/1.tmp";
        int fd = ::open(tmp_file.c_str(), O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
        ASSERT_GE(fd, 0);
        ::close(fd);
        gaia_apply::lsn_t max_ckp_lsn = 0;
        auto st = _dblwr->Open(4, _tmp_dir, &max_ckp_lsn);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(max_ckp_lsn, 0u);
    }
    END_OF_CASE;
}

TEST_F(DblwrTests, test_Open_invalid_filename_returns_error) {
    {
        // A file whose name is non-numeric triggers the
        // to_string(fno) != name check and causes Open to return kInvalid.
        std::string bad_file = _tmp_dir + "/badname";
        int fd = ::open(bad_file.c_str(), O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
        ASSERT_GE(fd, 0);
        ::close(fd);
        gaia_apply::lsn_t max_ckp_lsn = 0;
        auto st = _dblwr->Open(4, _tmp_dir, &max_ckp_lsn);
        ASSERT_FALSE(st.IsOk());
        ASSERT_TRUE(st.IsInvalid());
    }
    END_OF_CASE;
}

// --- Open(): create_directories failure ---

TEST_F(DblwrTests, test_Open_create_dir_fails) {
    {
        // The target path's parent is a regular file, so create_directories
        // cannot create it and Open returns an error.
        std::string blocker = _tmp_dir + "/blocker";
        int fd = ::open(blocker.c_str(), O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
        ASSERT_GE(fd, 0);
        ::close(fd);
        std::string bad_path = blocker + "/sub";
        gaia_apply::lsn_t max_ckp_lsn = 0;
        auto st = _dblwr->Open(4, bad_path, &max_ckp_lsn);
        ASSERT_FALSE(st.IsOk());
    }
    END_OF_CASE;
}

// --- Open(): OpenFile error paths + rollback ---

TEST_F(DblwrTests, test_Open_file_too_small_triggers_cleanup) {
    {
        // A file smaller than kDblwrFooterSize causes OpenFile to fail.
        // Open rolls back by calling RemoveFile and returns Ok.
        std::string small_file = _tmp_dir + "/1";
        int fd = ::open(small_file.c_str(), O_WRONLY | O_CREAT | O_TRUNC,
                S_IRUSR | S_IWUSR);
        ASSERT_GE(fd, 0);
        const char data[] = "too small";
        ::write(fd, data, sizeof(data));
        ::close(fd);
        gaia_apply::lsn_t max_ckp_lsn = 0;
        auto st = _dblwr->Open(4, _tmp_dir, &max_ckp_lsn);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_FALSE(std::filesystem::exists(small_file));
    }
    END_OF_CASE;
}

TEST_F(DblwrTests, test_Open_footer_fno_mismatch_triggers_cleanup) {
    {
        // Create a file "1" whose embedded footer has fno=99 (mismatch).
        // OpenFile detects the mismatch, rollback removes the file, Open returns Ok.
        DblwrFooter footer = {};
        footer.fno = 99;    // mismatch: filename "1" implies fno=1
        footer.page_num = 1;
        std::string fname = _tmp_dir + "/1";
        int fd = ::open(fname.c_str(), O_WRONLY | O_CREAT | O_TRUNC,
                S_IRUSR | S_IWUSR);
        ASSERT_GE(fd, 0);
        // Layout: [kDblwrFooterSize zeros][footer], so the footer starts at
        // offset (file_size - kDblwrFooterSize), as expected by OpenFile.
        std::vector<char> padding(static_cast<size_t>(kDblwrFooterSize), 0);
        ::write(fd, padding.data(), static_cast<size_t>(kDblwrFooterSize));
        ::write(fd, &footer, sizeof(footer));
        ::close(fd);
        gaia_apply::lsn_t max_ckp_lsn = 0;
        auto st = _dblwr->Open(4, _tmp_dir, &max_ckp_lsn);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_FALSE(std::filesystem::exists(fname));
    }
    END_OF_CASE;
}

TEST_F(DblwrTests, test_Open_corrupted_page_triggers_cleanup) {
    {
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(unsigned char const*, unsigned int, bool*));
        // Seal a valid buf, then reopen it with page_is_corrupted returning true.
        // OpenFile detects corruption, rollback removes the sealed file, Open returns Ok.
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 1, 1);
        ASSERT_TRUE(_dblwr->Write(1, 1, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);
        ASSERT_TRUE(_dblwr->HasBufs());

        auto dblwr2 = std::make_shared<Dblwr>();
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(Return(true));
        gaia_apply::lsn_t recovered_lsn = 0;
        auto st = dblwr2->Open(4, _tmp_dir, &recovered_lsn);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_FALSE(dblwr2->HasBufs());
    }
    END_OF_CASE;
}

TEST_F(DblwrTests, test_Open_no_ckp_lsn_in_sealed_file) {
    {
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(unsigned char const*, unsigned int, bool*));
        // Seal a buf without calling WriteCkpLsn: ckp_lsn fields stay 0.
        // On reload the ckp_lsn[1] > 0 check is false for every buf in the list,
        // so the loop completes without a break and max_ckp_lsn remains 0.
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 2, 3);
        ASSERT_TRUE(_dblwr->Write(2, 3, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);

        auto dblwr2 = std::make_shared<Dblwr>();
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(Return(false));
        gaia_apply::lsn_t recovered_lsn = 999;
        auto st = dblwr2->Open(4, _tmp_dir, &recovered_lsn);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_TRUE(dblwr2->HasBufs());
        ASSERT_EQ(recovered_lsn, 0u);
    }
    END_OF_CASE;
}

// --- ReadCkpLsn() from sealed _bufs ---

TEST_F(DblwrTests, test_ReadCkpLsn_from_sealed_bufs) {
    {
        // After a buf is sealed (_buf becomes null, _bufs is non-empty),
        // ReadCkpLsn should return ckp_lsn from _bufs.front().
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        ASSERT_TRUE(_dblwr->WriteCkpLsn(7777).IsOk());

        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 5, 6);
        // Write fills the buf (max_page_num=1) and triggers SealBuf;
        // _buf becomes null, the sealed buf is pushed to _bufs.
        ASSERT_TRUE(_dblwr->Write(5, 6, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);

        gaia_apply::lsn_t lsn = 0;
        auto st = _dblwr->ReadCkpLsn(&lsn);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(lsn, 7777u);
    }
    END_OF_CASE;
}

// --- Read() from sealed _bufs ---

TEST_F(DblwrTests, test_Read_offset_found_in_sealed_bufs) {
    {
        // Seal first page (max_page_num=1), then write a second page to a new _buf.
        // Read by the first page's offset: misses _buf (different offset), finds in _bufs.
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        const uint64_t offset1 = 0;
        const uint64_t offset2 = gaia_apply::FLAGS_univ_page_size;

        auto* src1 = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src1, 10, 20);
        src1[100] = 0xAA;
        ASSERT_TRUE(_dblwr->Write(10, 20, src1, offset1, kDblwrFlagsNone).IsOk());
        std::free(src1);
        // Sealed: _buf=null, _bufs has (10,20) at offset1.

        auto* src2 = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src2, 11, 21);
        ASSERT_TRUE(_dblwr->Write(11, 21, src2, offset2, kDblwrFlagsNone).IsOk());
        std::free(src2);
        // _buf has (11,21) at offset2; _bufs has (10,20) at offset1.

        auto* dst = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        // offset1 misses _buf (only has offset2), found in _bufs.
        auto st = _dblwr->Read(static_cast<uint32_t>(offset1), dst);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[100], 0xAA);
        std::free(dst);
    }
    END_OF_CASE;
}

TEST_F(DblwrTests, test_Read_offset_not_found_in_bufs) {
    {
        // After sealing one buf, Read with an unknown offset exhausts the _bufs
        // search and returns kNotFound.
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 1, 2);
        ASSERT_TRUE(_dblwr->Write(1, 2, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);
        // _buf=null, _bufs has offset=0.

        auto* dst = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        auto st = _dblwr->Read(static_cast<uint32_t>(99999), dst);
        ASSERT_TRUE(st.IsNotFound()) << st;
        std::free(dst);
    }
    END_OF_CASE;
}

TEST_F(DblwrTests, test_Read_space_page_not_found_in_bufs) {
    {
        // After sealing one buf, Read an unknown (space_id, page_no) exhausts
        // the _bufs loop and returns kNotFound.
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 10, 20);
        ASSERT_TRUE(_dblwr->Write(10, 20, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);
        // _buf=null, _bufs has (10,20).

        auto* dst = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        auto st = _dblwr->Read(static_cast<gaia_apply::space_id_t>(99),
                static_cast<gaia_apply::page_no_t>(99), static_cast<uint64_t>(0), dst);
        ASSERT_TRUE(st.IsNotFound()) << st;
        std::free(dst);
    }
    END_OF_CASE;
}

// --- RemoveBuf(): buf mismatch ---

TEST_F(DblwrTests, test_RemoveBuf_mismatch_returns_corrupted) {
    {
        // Seal one buf so _bufs is non-empty. Pass a DblwrBufPtr that is not
        // _bufs.back() to RemoveBuf: should return kCorrupted without touching _bufs.
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 1, 1);
        ASSERT_TRUE(_dblwr->Write(1, 1, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);
        ASSERT_EQ(_dblwr->bufs_size(), 1u);

        // A freshly-constructed buf is not in _bufs: RemoveBuf must reject it.
        DblwrBufPtr wrong_buf = std::make_shared<DblwrBuf>();
        wrong_buf->footer.fno = 999;
        auto st = _dblwr->RemoveBuf(wrong_buf);
        ASSERT_FALSE(st.IsOk());
        ASSERT_TRUE(st.IsCorrupted());
        ASSERT_EQ(_dblwr->bufs_size(), 1u);
    }
    END_OF_CASE;
}

// --- Write(): SealBuf failure and state rollback ---

TEST_F(DblwrTests, test_Write_seal_failure_reverts_state) {
    {
        BMOCK_NS_RESUME(psvr::db, pwritev, ssize_t(int, iovec const*, int, long));
        // Mock pwritev to fail so SealBuf cannot write the .tmp file.
        // Write should fail and roll back page_num and flags; no buf is
        // added to _bufs.
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, pwritev), pwritev(_, _, _, _))
            .WillOnce(Return(-1))
            .WillRepeatedly(Invoke([](int fd, const struct iovec* iov, int n, off_t off) {
                return ::pwritev(fd, iov, n, off);
            }));

        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 3, 4);
        auto st = _dblwr->Write(3, 4, src, 0, kDblwrFlagsNone);
        std::free(src);

        ASSERT_FALSE(st.IsOk());
        ASSERT_FALSE(_dblwr->HasBufs());
    }
    END_OF_CASE;
}

// --- ReadSealBuf() ---

// Branch: _bufs is empty (size < 1) -> kNotFound "not found in bufs"
TEST_F(DblwrTests, test_ReadSealBuf_bufs_empty) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_EQ(_dblwr->bufs_size(), 0u);

        auto* dst = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        auto st = _dblwr->ReadSealBuf(1, 1, dst, uint64_t(0));
        ASSERT_TRUE(st.IsNotFound()) << st;
        std::free(dst);
    }
    END_OF_CASE;
}

// Branch: _bufs has exactly one sealed buf -> page found when offset matches
TEST_F(DblwrTests, test_ReadSealBuf_only_one_sealed_buf) {
    {
        // max_page_num=1: a single Write seals the buf -> _bufs.size()==1
        // With guard changed to < 1, single sealed buf is now traversed and page found.
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 3, 5);
        src[16] = 0xAB;
        ASSERT_TRUE(_dblwr->Write(3, 5, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);
        ASSERT_EQ(_dblwr->bufs_size(), 1u);

        auto* dst = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        // Pass offset=0 to match footer.offs[slot]=0 → frame is copied
        auto st = _dblwr->ReadSealBuf(3, 5, dst, uint64_t(0));
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[16], 0xABu);
        std::free(dst);
    }
    END_OF_CASE;
}

// Branch: page found in a non-last sealed buf -> ok, frame copied when offset matches
TEST_F(DblwrTests, test_ReadSealBuf_page_found_in_non_last_buf) {
    {
        // Two Writes with max_page_num=1 produce two sealed bufs:
        //   _bufs = [buf_B(front/newest), buf_A(back/oldest=last_buf)]
        // ReadSealBuf for page_B hits buf_B (non-last) -> ok.
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        const gaia_apply::space_id_t sid_a = 10, sid_b = 20;
        const gaia_apply::page_no_t  pno_a = 1,  pno_b = 2;
        const uint64_t offset_a = 0, offset_b = 0x4000;

        auto* src_a = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src_a, sid_a, pno_a);
        ASSERT_TRUE(_dblwr->Write(sid_a, pno_a, src_a, offset_a, kDblwrFlagsNone).IsOk());
        std::free(src_a);
        // _bufs = [buf_A(back)], size=1

        auto* src_b = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src_b, sid_b, pno_b);
        src_b[128] = 0xBB;
        ASSERT_TRUE(_dblwr->Write(sid_b, pno_b, src_b, offset_b, kDblwrFlagsNone).IsOk());
        std::free(src_b);
        // _bufs = [buf_B(front), buf_A(back/last_buf)], size=2

        ASSERT_EQ(_dblwr->bufs_size(), 2u);

        auto* dst = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        // Pass offset_b to match footer.offs[slot]=offset_b → frame is copied
        auto st = _dblwr->ReadSealBuf(sid_b, pno_b, dst, offset_b);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[128], 0xBBu);
        std::free(dst);
    }
    END_OF_CASE;
}

// Branch: page exists only in last_buf (_bufs.back()) -> loop finds it -> ok
TEST_F(DblwrTests, test_ReadSealBuf_page_found_in_last_buf) {
    {
        // Same two-Write setup: buf_A is last_buf (_bufs.back()).
        // ReadSealBuf for page_A: buf_B does not have it, buf_A is now traversed -> ok.
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        const gaia_apply::space_id_t sid_a = 10, sid_b = 20;
        const gaia_apply::page_no_t  pno_a = 1,  pno_b = 2;

        auto* src_a = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src_a, sid_a, pno_a);
        src_a[16] = 0xCD;
        ASSERT_TRUE(_dblwr->Write(sid_a, pno_a, src_a, 0, kDblwrFlagsNone).IsOk());
        std::free(src_a);

        auto* src_b = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src_b, sid_b, pno_b);
        ASSERT_TRUE(_dblwr->Write(sid_b, pno_b, src_b, 0x4000, kDblwrFlagsNone).IsOk());
        std::free(src_b);
        // last_buf = _bufs.back() = buf_A

        ASSERT_EQ(_dblwr->bufs_size(), 2u);

        auto* dst = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        // Pass offset=0 to match footer.offs[slot]=0 for page_A → frame is copied
        auto st = _dblwr->ReadSealBuf(sid_a, pno_a, dst, uint64_t(0));
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[16], 0xCDu);
        std::free(dst);
    }
    END_OF_CASE;
}

// Branch: page not present in any non-last sealed buf -> exhausts loop -> kNotFound
TEST_F(DblwrTests, test_ReadSealBuf_page_not_in_any_sealed_buf) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        auto* src_a = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src_a, 1, 1);
        ASSERT_TRUE(_dblwr->Write(1, 1, src_a, 0, kDblwrFlagsNone).IsOk());
        std::free(src_a);

        auto* src_b = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src_b, 2, 2);
        ASSERT_TRUE(_dblwr->Write(2, 2, src_b, 0x4000, kDblwrFlagsNone).IsOk());
        std::free(src_b);

        ASSERT_EQ(_dblwr->bufs_size(), 2u);

        auto* dst = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        auto st = _dblwr->ReadSealBuf(99, 99, dst, uint64_t(0));
        ASSERT_TRUE(st.IsNotFound()) << st;
        std::free(dst);
    }
    END_OF_CASE;
}

// --- ReadBuf / ReadFile ---

// Branch: page key found but input offset does not match footer.offs[slot] -> kNotFound
TEST_F(DblwrTests, test_ReadSealBuf_offset_mismatch) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 5, 5);
        // Write page at physical offset 0x8000
        ASSERT_TRUE(_dblwr->Write(5, 5, src, 0x8000, kDblwrFlagsNone).IsOk());
        std::free(src);
        ASSERT_EQ(_dblwr->bufs_size(), 1u);

        auto* dst = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        // Pass a different offset -> mismatch -> kNotFound
        auto st = _dblwr->ReadSealBuf(5, 5, dst, uint64_t(0));
        ASSERT_TRUE(st.IsNotFound()) << st;
        std::free(dst);
    }
    END_OF_CASE;
}

// --- ReadBuf / ReadFile ---

// ReadBuf memory path: when frames != nullptr in active buf, data is copied via memcpy without file IO
TEST_F(DblwrTests, test_ReadBuf_active_buf_memory_path) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());

        const gaia_apply::space_id_t space_id = 77;
        const gaia_apply::page_no_t page_no = 88;
        const uint64_t offset = 0;

        auto* src = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, space_id, page_no);
        src[42] = 0xCC;

        ASSERT_TRUE(_dblwr->Write(space_id, page_no, src, offset, kDblwrFlagsNone).IsOk());
        // _buf is still active: frames != nullptr, Read takes the memory path

        ASSERT_TRUE(_dblwr->_buf->frames);

        auto* dst = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        memset(dst, 0, gaia_apply::FLAGS_univ_page_size);

        // Verify memory path: frames != nullptr so ReadBuf copies from memory directly.
        // Data correctness confirms memory path was taken (no file IO needed).
        auto st = _dblwr->Read(space_id, page_no, offset, dst);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[42], 0xCC);

        std::free(src);
        std::free(dst);
    }
    END_OF_CASE;
}

// ReadBuf file path: when frames == nullptr in sealed buf, ReadFile reads data from the fd
TEST_F(DblwrTests, test_ReadBuf_sealed_buf_file_path) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        const gaia_apply::space_id_t space_id = 30;
        const gaia_apply::page_no_t page_no = 40;
        const uint64_t offset = 0;

        auto* src = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, space_id, page_no);
        src[77] = 0xEE;

        // max_page_num=1: Write triggers SealBuf; buf moves to _bufs with frames=nullptr, fd=O_RDONLY
        ASSERT_TRUE(_dblwr->Write(space_id, page_no, src, offset, kDblwrFlagsNone).IsOk());
        ASSERT_TRUE(_dblwr->HasBufs());

        // Read dispatches through ReadBuf -> frames==nullptr -> ReadFile -> pread (real file IO)
        auto* dst = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        memset(dst, 0, gaia_apply::FLAGS_univ_page_size);
        auto st = _dblwr->Read(space_id, page_no, offset, dst);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[77], 0xEE);

        std::free(src);
        std::free(dst);
    }
    END_OF_CASE;
}

// ReadFile slot offset correctness: data for non-zero slot must be read from slot * page_size in the file
TEST_F(DblwrTests, test_ReadBuf_sealed_buf_reads_correct_slot_offset) {
    {
        // max_page_num=2: two Writes fill and seal the buf;
        // page1 lands at slot 0 (file offset 0), page2 at slot 1 (file offset page_size)
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(2, _tmp_dir, &max_ckp_lsn).IsOk());

        auto* src1 = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src1, 1, 1);
        src1[10] = 0x11;

        auto* src2 = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src2, 2, 2);
        src2[10] = 0x22;

        ASSERT_TRUE(_dblwr->Write(1, 1, src1, 0, kDblwrFlagsNone).IsOk());        // slot 0
        ASSERT_TRUE(_dblwr->Write(2, 2, src2, 0x4000, kDblwrFlagsNone).IsOk());   // slot 1, triggers SealBuf
        ASSERT_EQ(_dblwr->bufs_size(), 1u);

        auto* dst = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        memset(dst, 0, gaia_apply::FLAGS_univ_page_size);

        // Read page at slot 1: ReadFile must use offset 1*page_size
        auto st = _dblwr->Read(static_cast<gaia_apply::space_id_t>(2),
                static_cast<gaia_apply::page_no_t>(2), static_cast<uint64_t>(0x4000), dst);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[10], 0x22);

        // Slot 0 data must not bleed into slot 1 result
        memset(dst, 0, gaia_apply::FLAGS_univ_page_size);
        st = _dblwr->Read(static_cast<gaia_apply::space_id_t>(1),
                static_cast<gaia_apply::page_no_t>(1), static_cast<uint64_t>(0), dst);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[10], 0x11);

        std::free(src1);
        std::free(src2);
        std::free(dst);
    }
    END_OF_CASE;
}

// ReadFile IO error propagation: a failed pread must surface as an error through ReadBuf and Read
TEST_F(DblwrTests, test_ReadFile_io_error_propagated) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        auto* src = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 5, 6);
        // max_page_num=1: Write triggers SealBuf; buf moves to _bufs with frames=nullptr
        ASSERT_TRUE(_dblwr->Write(5, 6, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);
        ASSERT_TRUE(_dblwr->HasBufs());

        // Mock pread to simulate an IO failure
        BMOCK_NS_RESUME(psvr::db, pread, ssize_t(int, void*, unsigned long, long));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, pread), pread(_, _, _, _))
            .WillOnce(Return(-1))
            .WillRepeatedly(Invoke([](int fd, void* buf, size_t count, off_t off) {
                return ::pread(fd, buf, count, off);
            }));

        auto* dst = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        auto st = _dblwr->Read(static_cast<gaia_apply::space_id_t>(5),
                static_cast<gaia_apply::page_no_t>(6), static_cast<uint64_t>(0), dst);
        ASSERT_FALSE(st.IsOk());
        std::free(dst);
        BMOCK_NS_STOP(psvr::db, pread, ssize_t(int, void*, unsigned long, long));
    }
    END_OF_CASE;
}

// --- SealBuf frame management ---

// SealBuf must transfer _buf->frames to Dblwr::_frames (so the next AllocBufLow can reuse the
// memory) and open a read-only fd on the sealed file (so ReadBuf falls through to ReadFile).
TEST_F(DblwrTests, test_SealBuf_transfers_frames_to_member) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_EQ(_dblwr->_frames, nullptr);

        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 7, 8);
        src[20] = 0xAB;
        // Write fills the buf (max_page_num=1) and triggers SealBuf internally
        ASSERT_TRUE(_dblwr->Write(7, 8, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);

        ASSERT_EQ(_dblwr->bufs_size(), 1u);
        ASSERT_EQ(_dblwr->_buf, nullptr);

        DblwrBufPtr sealed_buf = _dblwr->DumpBuf();
        ASSERT_NE(sealed_buf, nullptr);

        // frames must have been transferred to Dblwr::_frames; sealed buf no longer owns them
        ASSERT_EQ(sealed_buf->frames, nullptr);
        ASSERT_NE(_dblwr->_frames, nullptr);
        ASSERT_GE(_dblwr->_frames_len,
                  static_cast<ssize_t>(gaia_apply::FLAGS_univ_page_size));

        // A read-only fd must have been opened so ReadBuf can fall through to ReadFile
        ASSERT_GE(sealed_buf->fd, 0);

        // Reading the sealed page still works via the file path
        auto* dst = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        auto st = _dblwr->Read(static_cast<gaia_apply::space_id_t>(7),
                static_cast<gaia_apply::page_no_t>(8), static_cast<uint64_t>(0), dst);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[20], 0xABu);
        std::free(dst);
    }
    END_OF_CASE;
}

// AllocBufLow must reuse the _frames buffer that SealBuf transferred, avoiding a new allocation.
// After two consecutive single-page seals the same memory pointer should appear in both cycles.
TEST_F(DblwrTests, test_AllocBufLow_reuses_frames_after_seal) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        // --- Seal cycle 1 ---
        auto* src1 = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src1, 1, 1);
        src1[10] = 0xA1;
        ASSERT_TRUE(_dblwr->Write(1, 1, src1, 0, kDblwrFlagsNone).IsOk());
        std::free(src1);

        ASSERT_EQ(_dblwr->_buf, nullptr);
        ASSERT_NE(_dblwr->_frames, nullptr);
        // Record the pointer so we can verify it is reused in cycle 2
        gaia_apply::byte* frames_after_seal1 = _dblwr->_frames;

        // --- Seal cycle 2 ---
        // The first thing Write does is AllocBuf (because _buf == nullptr), which calls
        // AllocBufLow.  Since buf_size (1*page) <= _frames_len, _frames is reused.
        auto* src2 = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src2, 2, 2);
        src2[10] = 0xB2;
        ASSERT_TRUE(_dblwr->Write(2, 2, src2, 0x4000, kDblwrFlagsNone).IsOk());
        std::free(src2);

        // After the second seal _frames is set again (from the second sealed buf).
        // The important invariant: it is the *same* pointer that was reused.
        ASSERT_EQ(_dblwr->bufs_size(), 2u);
        ASSERT_EQ(_dblwr->_buf, nullptr);
        ASSERT_NE(_dblwr->_frames, nullptr);
        ASSERT_EQ(_dblwr->_frames, frames_after_seal1);  // same memory reused

        // Both sealed bufs must have frames=nullptr (fd-based reading path)
        for (auto& buf : _dblwr->_bufs) {
            ASSERT_EQ(buf->frames, nullptr);
            ASSERT_GE(buf->fd, 0);
        }

        // Data from both seals must still be readable via the file path
        auto* dst = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        auto st = _dblwr->Read(static_cast<gaia_apply::space_id_t>(1),
                static_cast<gaia_apply::page_no_t>(1), static_cast<uint64_t>(0), dst);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[10], 0xA1u);

        memset(dst, 0, gaia_apply::FLAGS_univ_page_size);
        st = _dblwr->Read(static_cast<gaia_apply::space_id_t>(2),
                static_cast<gaia_apply::page_no_t>(2), static_cast<uint64_t>(0x4000), dst);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_EQ(dst[10], 0xB2u);
        std::free(dst);
    }
    END_OF_CASE;
}

// AllocBufLow must reallocate when _frames_len < required buf_size.
// Setup: use a helper Dblwr to seal a 1-page file in the same dir, then Open the main
// dblwr with max_page_num=2.  OpenFile sets _frames_len = 1*page_size.  The first Write
// triggers AllocBuf: buf_size = 2*page_size > _frames_len → _frames is freed and a new,
// larger buffer is allocated.
TEST_F(DblwrTests, test_AllocBufLow_reallocates_when_frames_too_small) {
    {
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(unsigned char const*, unsigned int, bool*));
        // Step 1: create a 1-page sealed file in _tmp_dir via a helper Dblwr
        {
            auto helper = std::make_shared<Dblwr>();
            gaia_apply::lsn_t ckp = 0;
            ASSERT_TRUE(helper->Open(1, _tmp_dir, &ckp).IsOk());

            auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                    gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
            make_test_frame(src, 9, 9);
            ASSERT_TRUE(helper->Write(9, 9, src, 0, kDblwrFlagsNone).IsOk());
            std::free(src);
            // helper's destructor closes fds; the file remains in _tmp_dir
        }

        // Step 2: Open main dblwr with max_page_num=2.
        // OpenFile reads the 1-page file; AllocFramesMmap now allocates
        // buf_size + kDblwrFooterSize, so _frames_len = 1*page_size + kDblwrFooterSize.
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillRepeatedly(Return(false));
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(2, _tmp_dir, &max_ckp_lsn).IsOk());

        ASSERT_NE(_dblwr->_frames, nullptr);
        ASSERT_EQ(_dblwr->_frames_len,
                  static_cast<ssize_t>(gaia_apply::FLAGS_univ_page_size + kDblwrFooterSize));

        // Step 3: First Write triggers AllocBuf.
        // mmap_size = 2*page_size + kDblwrFooterSize > _frames_len = 1*page_size + kDblwrFooterSize
        // -> reallocation path.
        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 11, 11);
        ASSERT_TRUE(_dblwr->Write(11, 11, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);

        // New _buf must have a freshly allocated frames buffer sized for 2 pages
        ASSERT_NE(_dblwr->_buf, nullptr);
        ASSERT_NE(_dblwr->_buf->frames, nullptr);
        ASSERT_EQ(_dblwr->_buf->frames_len,
                  static_cast<ssize_t>(2 * gaia_apply::FLAGS_univ_page_size));
        // _frames points to the new mmap (shared with _buf->frames); _frames_len reflects
        // the full mmap size including the in-place footer area
        ASSERT_EQ(_dblwr->_frames, _dblwr->_buf->frames);
        ASSERT_EQ(_dblwr->_frames_len,
                  static_cast<ssize_t>(2 * gaia_apply::FLAGS_univ_page_size + kDblwrFooterSize));
    }
    END_OF_CASE;
}

// --- Dblwr::Dump() ---

// Helper: write a DblwrFooter into a temporary file and return its read-only fd.
// The file layout is just [footer] of kDblwrFooterSize bytes so that
// pread(..., file_size - kDblwrFooterSize) reads from offset 0.
static int make_footer_file(const std::string& path, const DblwrFooter& footer) {
    int wfd = ::open(path.c_str(), O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
    if (wfd < 0) return -1;
    ssize_t n = ::write(wfd, &footer, kDblwrFooterSize);
    ::close(wfd);
    if (n != kDblwrFooterSize) return -1;
    return ::open(path.c_str(), O_RDONLY);
}

// Branch: db::get_file_size (fstat) fails → error message
TEST_F(DblwrTests, test_Dump_fstat_fails) {
    {
        BMOCK_NS_RESUME(psvr::db, fstat, int(int, struct stat*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, fstat), fstat(_, _))
            .WillOnce(Return(-1))
            .WillRepeatedly(Invoke([](int fd, struct stat* buf) {
                return ::fstat(fd, buf);
            }));

        std::ostringstream os;
        Dblwr::Dump(-1, os);
        ASSERT_NE(os.str().find("get file size failed"), std::string::npos) << os.str();
    }
    END_OF_CASE;
}

// Branch: file_size < kDblwrFooterSize → error message
TEST_F(DblwrTests, test_Dump_file_too_small) {
    {
        BMOCK_NS_RESUME(psvr::db, fstat, int(int, struct stat*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, fstat), fstat(_, _))
            .WillOnce(DoAll(
                Invoke([](int fd, struct stat* buf) { ::fstat(fd, buf); buf->st_size = 10; }),
                Return(0)))
            .WillRepeatedly(Invoke([](int fd, struct stat* buf) {
                return ::fstat(fd, buf);
            }));

        std::ostringstream os;
        Dblwr::Dump(-1, os);
        ASSERT_NE(os.str().find("kDblwrFooterSize"), std::string::npos) << os.str();
    }
    END_OF_CASE;
}

// Branch: pread for footer fails → error message
TEST_F(DblwrTests, test_Dump_pread_footer_fails) {
    {
        // Create a real file large enough to pass the size check
        std::string path = _tmp_dir + "/footer_fail";
        DblwrFooter footer;
        memset(&footer, 0, kDblwrFooterSize);
        footer.magic = kDBLWRBufFooterMagic;
        int fd = make_footer_file(path, footer);
        ASSERT_GE(fd, 0);

        BMOCK_NS_RESUME(psvr::db, pread, ssize_t(int, void*, unsigned long, long));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, pread), pread(_, _, _, _))
            .WillOnce(Return(-1))
            .WillRepeatedly(Invoke([](int fd, void* buf, size_t count, off_t off) {
                return ::pread(fd, buf, count, off);
            }));

        std::ostringstream os;
        Dblwr::Dump(fd, os);
        ::close(fd);
        ASSERT_NE(os.str().find("read footer failed"), std::string::npos) << os.str();
        BMOCK_NS_STOP(psvr::db, pread, ssize_t(int, void*, unsigned long, long));
    }
    END_OF_CASE;
}

// Branch: footer.magic != kDBLWRBufFooterMagic → error message
TEST_F(DblwrTests, test_Dump_invalid_magic) {
    {
        DblwrFooter footer;
        memset(&footer, 0, kDblwrFooterSize);
        footer.magic = 0xDEADBEEF;  // wrong magic

        std::string path = _tmp_dir + "/bad_magic";
        int fd = make_footer_file(path, footer);
        ASSERT_GE(fd, 0);

        std::ostringstream os;
        Dblwr::Dump(fd, os);
        ::close(fd);
        ASSERT_NE(os.str().find("invalid magic"), std::string::npos) << os.str();
    }
    END_OF_CASE;
}

// Branch: footer.page_num == 0 → "no pages" message (footer fields still printed)
TEST_F(DblwrTests, test_Dump_page_num_zero) {
    {
        DblwrFooter footer;
        memset(&footer, 0, kDblwrFooterSize);
        footer.magic = kDBLWRBufFooterMagic;
        footer.page_num = 0;

        std::string path = _tmp_dir + "/zero_pages";
        int fd = make_footer_file(path, footer);
        ASSERT_GE(fd, 0);

        std::ostringstream os;
        Dblwr::Dump(fd, os);
        ::close(fd);
        // Footer must be printed and "no pages" returned
        ASSERT_NE(os.str().find("----footer:"), std::string::npos) << os.str();
        ASSERT_NE(os.str().find("no pages"), std::string::npos) << os.str();
    }
    END_OF_CASE;
}

// Branch: footer.page_num > kMaxDblwrOffsetNum → "invalid page_num" error
TEST_F(DblwrTests, test_Dump_page_num_overflow) {
    {
        DblwrFooter footer;
        memset(&footer, 0, kDblwrFooterSize);
        footer.magic = kDBLWRBufFooterMagic;
        footer.page_num = static_cast<uint32_t>(kMaxDblwrOffsetNum) + 1;

        std::string path = _tmp_dir + "/overflow_pages";
        int fd = make_footer_file(path, footer);
        ASSERT_GE(fd, 0);

        std::ostringstream os;
        Dblwr::Dump(fd, os);
        ::close(fd);
        ASSERT_NE(os.str().find("invalid page_num"), std::string::npos) << os.str();
    }
    END_OF_CASE;
}

// Branch: pread for page frames fails → error message
TEST_F(DblwrTests, test_Dump_pread_frames_fails) {
    {
        // Use a real sealed file (1 page) so the footer is valid
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 3, 4);
        ASSERT_TRUE(_dblwr->Write(3, 4, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);

        std::string sealed_path = _tmp_dir + "/0";
        int fd = ::open(sealed_path.c_str(), O_RDONLY);
        ASSERT_GE(fd, 0);

        // First pread (footer) succeeds; second (frames) fails
        BMOCK_NS_RESUME(psvr::db, pread, ssize_t(int, void*, unsigned long, long));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, pread), pread(_, _, _, _))
            .WillOnce(Invoke([](int fd, void* buf, size_t count, off_t off) {
                return ::pread(fd, buf, count, off);
            }))
            .WillOnce(Return(-1))
            .WillRepeatedly(Invoke([](int fd, void* buf, size_t count, off_t off) {
                return ::pread(fd, buf, count, off);
            }));

        std::ostringstream os;
        Dblwr::Dump(fd, os);
        ::close(fd);
        ASSERT_NE(os.str().find("read page frames failed"), std::string::npos) << os.str();
        BMOCK_NS_STOP(psvr::db, pread, ssize_t(int, void*, unsigned long, long));
    }
    END_OF_CASE;
}

// Branch: full success path — all output sections are present
TEST_F(DblwrTests, test_Dump_success) {
    {
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(unsigned char const*, unsigned int, bool*));
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_TRUE(_dblwr->WriteCkpLsn(12345).IsOk());

        auto* src = static_cast<gaia_apply::byte*>(std::aligned_alloc(
                gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 10, 20);
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillRepeatedly(DoAll(SetArgPointee<2>(false), Return(false)));
        ASSERT_TRUE(_dblwr->Write(10, 20, src, 0x8000, kDblwrFlagsNone).IsOk());
        std::free(src);

        std::string sealed_path = _tmp_dir + "/0";
        int fd = ::open(sealed_path.c_str(), O_RDONLY);
        ASSERT_GE(fd, 0);

        std::ostringstream os;
        Dblwr::Dump(fd, os);
        ::close(fd);

        const std::string& out = os.str();
        // All sections must appear
        ASSERT_NE(out.find("----footer:"), std::string::npos) << out;
        ASSERT_NE(out.find("----offsets:"), std::string::npos) << out;
        ASSERT_NE(out.find("----pages:"), std::string::npos) << out;
        // Page info: space_id and page_no from the frame we wrote
        ASSERT_NE(out.find("space_id:10"), std::string::npos) << out;
        ASSERT_NE(out.find("page_no:20"), std::string::npos) << out;
        // Offset we passed to Write
        ASSERT_NE(out.find("offset:32768"), std::string::npos) << out;  // 0x8000 = 32768
        // Page is not corrupted
        ASSERT_NE(out.find("corrupted:no"), std::string::npos) << out;
    }
    END_OF_CASE;
}

// ─── SealBufByLsn ────────────────────────────────────────────────────────────

// Branch: _buf == nullptr → returns error, nothing sealed
TEST_F(DblwrTests, test_SealBufByLsn_no_buf) {
    {
        auto st = _dblwr->SealBufByLsn(1000);
        ASSERT_FALSE(st.IsOk()) << st;
        ASSERT_FALSE(_dblwr->HasBufs());
    }
    END_OF_CASE;
}

// Branch: ckp_lsn[1] == lsn (equal, not strictly greater) → returns error, not sealed

// Branch: ckp_lsn[1] < lsn → returns error, not sealed
TEST_F(DblwrTests, test_SealBufByLsn_ckp_lsn_less_than_lsn) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_TRUE(_dblwr->WriteCkpLsn(500).IsOk());
        // ckp_lsn[1] = 500, lsn = 2000 → 500 <= 2000 → error
        auto st = _dblwr->SealBufByLsn(2000);
        ASSERT_FALSE(st.IsOk());
        ASSERT_FALSE(_dblwr->HasBufs());
    }
    END_OF_CASE;
}

// Branch: ckp_lsn[1] > lsn and SealBuf succeeds → buf moved to _bufs, _buf = nullptr
TEST_F(DblwrTests, test_SealBufByLsn_success) {
    {
        BMOCK_NS_RESUME(psvr::db, pwritev, ssize_t(int, iovec const*, int, long));
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_TRUE(_dblwr->WriteCkpLsn(5000).IsOk());

        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, pwritev), pwritev(_, _, _, _))
            .WillRepeatedly(Invoke([](int fd, const struct iovec* iov, int iovcnt, off_t off) {
                return ::pwritev(fd, iov, iovcnt, off);
            }));

        // ckp_lsn[1] = 5000, lsn = 3000 → 5000 > 3000 → seal
        auto st = _dblwr->SealBufByLsn(3000);
        ASSERT_TRUE(st.IsOk()) << st;
        // buf moved to _bufs, _buf == nullptr
        ASSERT_TRUE(_dblwr->HasBufs());
        ASSERT_EQ(_dblwr->bufs_size(), 1u);
        // seal resets the create time so SealBufByTime won't seal it again
        ASSERT_EQ(_dblwr->_latest_create_time, int64_t{0});
    }
    END_OF_CASE;
}

// Branch: ckp_lsn[1] > lsn but SealBuf fails (pwritev error) → error returned, buf NOT moved
TEST_F(DblwrTests, test_SealBufByLsn_seal_fails) {
    {
        BMOCK_NS_RESUME(psvr::db, pwritev, ssize_t(int, iovec const*, int, long));
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_TRUE(_dblwr->WriteCkpLsn(5000).IsOk());

        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, pwritev), pwritev(_, _, _, _))
            .WillOnce(Return(static_cast<ssize_t>(-1)))
            .WillRepeatedly(Invoke([](int fd, const struct iovec* iov, int iovcnt, off_t off) {
                return ::pwritev(fd, iov, iovcnt, off);
            }));

        auto st = _dblwr->SealBufByLsn(3000);
        ASSERT_FALSE(st.IsOk());
        // buf should NOT be in _bufs
        ASSERT_FALSE(_dblwr->HasBufs());
        ASSERT_EQ(_dblwr->bufs_size(), 0u);
    }
    END_OF_CASE;
}

// ─── _latest_create_time lifecycle (drives SealBufByTime) ──────────────────

// Branch: AllocBuf (triggered by WriteCkpLsn) stamps _latest_create_time
TEST_F(DblwrTests, test_AllocBuf_sets_latest_create_time) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());
        // fresh dblwr has no create time yet
        ASSERT_EQ(_dblwr->_latest_create_time, int64_t{0});

        ASSERT_TRUE(_dblwr->WriteCkpLsn(500).IsOk());
        // buf allocated → create time stamped to now
        ASSERT_GT(_dblwr->_latest_create_time, int64_t{0});
    }
    END_OF_CASE;
}

// Branch: Write filling the buf seals it and clears _latest_create_time
TEST_F(DblwrTests, test_Write_seal_clears_latest_create_time) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());

        auto* src = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 1, 1);
        // max_page_num=1 → first Write seals the buf
        ASSERT_TRUE(_dblwr->Write(1, 1, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);

        ASSERT_TRUE(_dblwr->HasBufs());
        // seal resets the create time
        ASSERT_EQ(_dblwr->_latest_create_time, int64_t{0});
    }
    END_OF_CASE;
}

// ─── SealBufByTime ──────────────────────────────────────────────────────────

// Branch: _latest_create_time == 0 (fresh dblwr, no buf) → fast path returns Ok, nothing sealed
TEST_F(DblwrTests, test_SealBufByTime_no_buf) {
    {
        auto st = _dblwr->SealBufByTime(1000);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_FALSE(_dblwr->HasBufs());
    }
    END_OF_CASE;
}

// Branch: _shared_mutex already held by another thread → try_to_lock fails → returns error
TEST_F(DblwrTests, test_SealBufByTime_lock_failed) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_TRUE(_dblwr->WriteCkpLsn(500).IsOk());
        // force the buf create time into the past so the fast path is bypassed
        _dblwr->_latest_create_time = 1;

        {
            std::unique_lock lk(_dblwr->_shared_mutex);
            auto st = _dblwr->SealBufByTime(0);
            ASSERT_FALSE(st.IsOk()) << st;
        }
        ASSERT_FALSE(_dblwr->HasBufs());
    }
    END_OF_CASE;
}

// Branch: _buf exists but time is still valid → returns Ok, not sealed
TEST_F(DblwrTests, test_SealBufByTime_time_valid) {
    {
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_TRUE(_dblwr->WriteCkpLsn(500).IsOk());
        // _latest_create_time is set to now on buf alloc; a large timeout keeps it valid
        auto st = _dblwr->SealBufByTime(60ll * 1000 * 1000);
        ASSERT_TRUE(st.IsOk()) << st;
        ASSERT_FALSE(_dblwr->HasBufs());
    }
    END_OF_CASE;
}

// Branch: time expired and SealBuf succeeds → buf moved to _bufs, _buf cleared
TEST_F(DblwrTests, test_SealBufByTime_success) {
    {
        BMOCK_NS_RESUME(psvr::db, pwritev, ssize_t(int, iovec const*, int, long));
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_TRUE(_dblwr->WriteCkpLsn(500).IsOk());

        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, pwritev), pwritev(_, _, _, _))
            .WillRepeatedly(Invoke([](int fd, const struct iovec* iov, int iovcnt, off_t off) {
                return ::pwritev(fd, iov, iovcnt, off);
            }));

        // force the buf create time into the past so the seal timeout has elapsed
        _dblwr->_latest_create_time = 1;

        auto st = _dblwr->SealBufByTime(0);
        ASSERT_TRUE(st.IsOk()) << st;
        // buf moved to _bufs, _buf == nullptr
        ASSERT_TRUE(_dblwr->HasBufs());
        ASSERT_EQ(_dblwr->bufs_size(), 1u);
        ASSERT_EQ(_dblwr->_latest_create_time, int64_t{0});
    }
    END_OF_CASE;
}

// Branch: time expired but SealBuf fails (pwritev error) → error, buf NOT moved
TEST_F(DblwrTests, test_SealBufByTime_seal_fails) {
    {
        BMOCK_NS_RESUME(psvr::db, pwritev, ssize_t(int, iovec const*, int, long));
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(4, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_TRUE(_dblwr->WriteCkpLsn(500).IsOk());

        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, pwritev), pwritev(_, _, _, _))
            .WillOnce(Return(static_cast<ssize_t>(-1)))
            .WillRepeatedly(Invoke([](int fd, const struct iovec* iov, int iovcnt, off_t off) {
                return ::pwritev(fd, iov, iovcnt, off);
            }));

        // force the buf create time into the past so the seal timeout has elapsed
        _dblwr->_latest_create_time = 1;

        auto st = _dblwr->SealBufByTime(0);
        ASSERT_FALSE(st.IsOk());
        // buf should NOT be in _bufs
        ASSERT_FALSE(_dblwr->HasBufs());
        ASSERT_EQ(_dblwr->bufs_size(), 0u);
    }
    END_OF_CASE;
}

// ─── Open: failure deletes from max fno descending then breaks ───────────────

TEST_F(DblwrTests, test_Open_file_failure_deletes_desc_and_breaks) {
    {
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(unsigned char const*, unsigned int, bool*));
        BMOCK_NS_RESUME(psvr::db, pwritev, ssize_t(int, iovec const*, int, long));
        // Create 2 sealed files (fno=0, fno=1) via a helper Dblwr instance
        {
            auto setup = std::make_shared<Dblwr>();
            gaia_apply::lsn_t ckp = 0;
            ASSERT_TRUE(setup->Open(1, _tmp_dir, &ckp).IsOk());

            auto* src = static_cast<gaia_apply::byte*>(
                    std::aligned_alloc(gaia_apply::FLAGS_univ_page_size,
                                       gaia_apply::FLAGS_univ_page_size));
            make_test_frame(src, 1, 1);

            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
                .WillRepeatedly(DoAll(SetArgPointee<2>(false), Return(false)));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, pwritev), pwritev(_, _, _, _))
                .WillRepeatedly(Invoke([](int fd, const struct iovec* iov, int iovcnt, off_t off) {
                    return ::pwritev(fd, iov, iovcnt, off);
                }));

            // Each Write fills max_page_num=1 and seals
            ASSERT_TRUE(setup->WriteCkpLsn(1000).IsOk());
            ASSERT_TRUE(setup->Write(1, 1, src, 0, kDblwrFlagsNone).IsOk());  // seals fno=0
            ASSERT_TRUE(setup->WriteCkpLsn(2000).IsOk());
            ASSERT_TRUE(setup->Write(1, 2, src, 0, kDblwrFlagsNone).IsOk());  // seals fno=1
            std::free(src);
        }

        ASSERT_TRUE(std::filesystem::exists(_tmp_dir + "/0"));
        ASSERT_TRUE(std::filesystem::exists(_tmp_dir + "/1"));

        // Corrupt fno=1 by truncating to 0 bytes (size < kDblwrFooterSize)
        {
            int fd = ::open((_tmp_dir + "/1").c_str(), O_WRONLY | O_TRUNC);
            ASSERT_GE(fd, 0);
            ::close(fd);
        }

        // Open: fno=0 succeeds, fno=1 fails → deletes fno=1 desc, breaks
        gaia_apply::lsn_t ckp = 0;
        auto st = _dblwr->Open(1, _tmp_dir, &ckp);
        ASSERT_TRUE(st.IsOk()) << st;

        // fno=0 loaded, fno=1 deleted
        ASSERT_TRUE(_dblwr->HasBufs());
        ASSERT_FALSE(std::filesystem::exists(_tmp_dir + "/1"));
        ASSERT_TRUE(std::filesystem::exists(_tmp_dir + "/0"));
        // max_ckp_lsn comes from successfully loaded fno=0 (ckp=1000)
        ASSERT_EQ(ckp, 1000u);
    }
    END_OF_CASE;
}

// ─── _latest_lsn: initialized from max_ckp_lsn, used in AllocBuf ────────────

// After Open with sealed file (ckp=7777), _latest_lsn=7777.
// New buf from AllocBuf gets ckp_lsn[0]=ckp_lsn[1]=7777.
// WriteCkpLsn(8000) on new buf: ckp_lsn[0] stays 7777 (not 0), ckp_lsn[1]=8000.
TEST_F(DblwrTests, test_Open_latest_lsn_used_in_alloc_buf) {
    {
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(unsigned char const*, unsigned int, bool*));
        BMOCK_NS_RESUME(psvr::db, pwritev, ssize_t(int, iovec const*, int, long));
        // Step 1: seal fno=0 with ckp=7777
        {
            auto setup = std::make_shared<Dblwr>();
            gaia_apply::lsn_t ckp = 0;
            ASSERT_TRUE(setup->Open(1, _tmp_dir, &ckp).IsOk());

            auto* src = static_cast<gaia_apply::byte*>(
                    std::aligned_alloc(gaia_apply::FLAGS_univ_page_size,
                                       gaia_apply::FLAGS_univ_page_size));
            make_test_frame(src, 2, 3);

            EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
                .WillRepeatedly(DoAll(SetArgPointee<2>(false), Return(false)));
            EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, pwritev), pwritev(_, _, _, _))
                .WillRepeatedly(Invoke([](int fd, const struct iovec* iov, int iovcnt, off_t off) {
                    return ::pwritev(fd, iov, iovcnt, off);
                }));

            ASSERT_TRUE(setup->WriteCkpLsn(7777).IsOk());
            ASSERT_TRUE(setup->Write(2, 3, src, 0, kDblwrFlagsNone).IsOk());  // seals fno=0
            std::free(src);
        }

        // Step 2: Open fresh dblwr → max_ckp_lsn=7777, _latest_lsn=7777
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());
        ASSERT_EQ(max_ckp_lsn, 7777u);

        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, pwritev), pwritev(_, _, _, _))
            .WillRepeatedly(Invoke([](int fd, const struct iovec* iov, int iovcnt, off_t off) {
                return ::pwritev(fd, iov, iovcnt, off);
            }));

        // Step 3: WriteCkpLsn(8000) triggers AllocBuf (new buf).
        // AllocBuf initializes: ckp_lsn[0]=ckp_lsn[1]=_latest_lsn=7777.
        // WriteCkpLsn then: ckp_lsn[0] stays 7777 (≠0), ckp_lsn[1]=8000.
        ASSERT_TRUE(_dblwr->WriteCkpLsn(8000).IsOk());

        // Verify via direct access (access control disabled in test builds)
        ASSERT_EQ(_dblwr->_buf->footer_ptr->ckp_lsn[0], static_cast<gaia_apply::lsn_t>(7777));
        ASSERT_EQ(_dblwr->_buf->footer_ptr->ckp_lsn[1], static_cast<gaia_apply::lsn_t>(8000));
    }
    END_OF_CASE;
}

// WriteCkpLsn updates _latest_lsn; after sealing, next AllocBuf inherits latest value.
// Distinguishes new behavior (uses _latest_lsn) from old (uses _bufs.front().ckp_lsn[0]).
TEST_F(DblwrTests, test_WriteCkpLsn_latest_lsn_propagates_to_next_buf) {
    {
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(unsigned char const*, unsigned int, bool*));
        BMOCK_NS_RESUME(psvr::db, pwritev, ssize_t(int, iovec const*, int, long));
        gaia_apply::lsn_t max_ckp_lsn = 0;
        ASSERT_TRUE(_dblwr->Open(1, _tmp_dir, &max_ckp_lsn).IsOk());  // max_page_num=1

        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillRepeatedly(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, pwritev), pwritev(_, _, _, _))
            .WillRepeatedly(Invoke([](int fd, const struct iovec* iov, int iovcnt, off_t off) {
                return ::pwritev(fd, iov, iovcnt, off);
            }));

        // WriteCkpLsn(5000): _latest_lsn = 5000, buf A ckp_lsn = 5000
        ASSERT_TRUE(_dblwr->WriteCkpLsn(5000).IsOk());

        // Write seals buf A (max_page_num=1), _buf=null, _latest_lsn stays 5000
        auto* src = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
        make_test_frame(src, 7, 8);
        ASSERT_TRUE(_dblwr->Write(7, 8, src, 0, kDblwrFlagsNone).IsOk());
        std::free(src);

        // WriteCkpLsn(6000): AllocBuf first (with _latest_lsn=5000),
        // then ckp_lsn[0] stays 5000 (≠0), ckp_lsn[1]=6000, _latest_lsn=6000
        ASSERT_TRUE(_dblwr->WriteCkpLsn(6000).IsOk());

        ASSERT_EQ(_dblwr->_buf->footer_ptr->ckp_lsn[0], static_cast<gaia_apply::lsn_t>(5000));
        ASSERT_EQ(_dblwr->_buf->footer_ptr->ckp_lsn[1], static_cast<gaia_apply::lsn_t>(6000));
    }
    END_OF_CASE;
}

}  // namespace test
}  // namespace psvr
