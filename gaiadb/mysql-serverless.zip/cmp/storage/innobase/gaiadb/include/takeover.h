/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/takeover.h
 The interface to do takeover task

 Created 05/16/2023 Lingjie Guo
 *******************************************************/
#pragma once

#include <atomic>
#include <map>
#include <mutex>
#include <string>
#include "include/my_systime.h"  // my_micro_time
#include "db0err.h"

namespace hotbackup {

enum class Stage : uint32_t {
  None = 0,
  Failed,
  Success,
  Prepare,
  WriteFence,
  PurgeSysShutdown,
  LogSysRecv,
  BinLogInRedoRecv,
  TrxSysShutdown,
  LogSysStart,
  TrxSysRecv,
  DictSysRecv,
  BinLogRecv,
  TrxRecoveryRollbackRecv,
  RpcSysRecv,
  FixStatus,
  FixSysTables,
  CompressGtid,
  BosInfo,
  EndStep,
};

void set_stage(Stage s);
Stage get_stage();
bool stage_is(Stage s);

struct Task;

extern Task task;

struct Task {
  std::mutex lock;
  std::string task_id{};
  uint64_t start_time{};
  uint64_t end_time{};
  std::map<Stage, uint64_t> stages_cost{};
  Stage fail_stage {Stage::None};
  dberr_t fail_ret {DB_ERROR_UNSET};

  void reset(const std::string& id, uint64_t start);
  void finish(bool success);
};

struct ScopedCoster {
  uint64_t *cost;
  int64_t start_us;

  ScopedCoster(uint64_t *cost_, int64_t start);
  ScopedCoster(uint64_t *cost_) : ScopedCoster(cost_, 0) {}
  ~ScopedCoster();
};

void do_takeover_primary();
void takeover_primary_async();

} // namespace hotbackup
