/*****************************************************************************
 @file include/bos0write.cc
 write file to bos 
 *******************************************************/

#include "bos0bos.h"
#include "base/logging.h"

namespace bos {

static const uint64_t MAX_SIZE = 5ULL * 1024 * 1024 * 1024;// 5G

bool BosWriter::put_object_with_filename(const std::string &filename) {
  const std::string object_key = add_cluster_id(filename);
  if (get_client()->put_object(bos_info().bucket, object_key, filename)) {
    LOG(WARNING) << "bos put_object failed, filename: " << filename;
    return true;
  }
  return false;
}

bool BosWriter::put_object_with_progress(const std::string &filename) {
  bir_bos::FileInputStream file(filename); 
  const std::string object_key = add_cluster_id(filename);

  bir_bos::PutObjectRequest req(bos_info().bucket, object_key, &file);
  bir_bos::PutObjectResponse rsp;
    
  bir_bos::TransferProgress progress;
  progress.transfer_progress_cb = progress_callback;
  req.set_progress(progress);

  int ret = get_client()->put_object(req, &rsp);
  if (ret) {
    LOG(WARNING) << "bos put object init client err: " << ret;
    return true;
  }
  if (rsp.is_fail()) {
    LOG(WARNING) << "bos put_object response failed"
      << "[status_code = " << rsp.status_code()
      << "], [message = " << rsp.error().message().c_str()
      << "], [requestid = " << rsp.error().request_id().c_str()
      << "]";
    return true;
  }
  return false;
}

bool BosWriter::put_large_object(const std::string &filename) {
  const std::string object_key = add_cluster_id(filename);
  if (get_client()->upload_super_file(
      bos_info().bucket, object_key, filename)) {
    LOG(WARNING) << "bos upload_super_file failed, filename: " << filename;
    return true;
  }
  return false;
}

bool BosWriter::put_object_in_multi_part(
    const std::string &filename, std::string &uploadId) {
  const std::string object_key = add_cluster_id(filename);
  bir_bos::InitMultiUploadRequest initMultiUploadRequest(bos_info().bucket, object_key);
  bir_bos::InitMultiUploadResponse initMultiUploadResponse;

  if (get_client()->init_multipart_upload(
      initMultiUploadRequest, &initMultiUploadResponse)) {
    LOG(WARNING) << "bos init_multipart_upload failed, filename: " << filename;
    return true;
  }
  uploadId = initMultiUploadResponse.upload_id();
  int64_t partSize = BosWriter::partSize;

  bir_bos::FileInputStream file(filename);
  int64_t file_size = file.get_size() > 0 ? file.get_size() : 0;
  int partCount = static_cast<int>(file_size / partSize);
  if (file_size % BosWriter::partSize != 0){
    partCount++;
  }

  int64_t off = 0;
  std::vector<bir_bos::part_t> partEtags;
  for (int i = 0; off < file_size; ++i) {
    if (off + partSize > file_size) {
      partSize = file_size - off;
    }
    bir_bos::FileInputStream partFile(file.fd(), off, partSize);
    bir_bos::UploadPartRequest uploadPartRequest = 
        bir_bos::UploadPartRequest(bos_info().bucket, 
        object_key, &partFile, i + 1, initMultiUploadResponse.upload_id());
    bir_bos::UploadPartResponse uploadPartResponse;

    if (get_client()->upload_part(uploadPartRequest, &uploadPartResponse)) {
      abort_put_object_in_multi_part(filename, uploadId);
      LOG(WARNING) << "bos upload_part failed, filename: " << filename;
      return true;
    }

    bir_bos::part_t partInfo;
    partInfo.part_number = i + 1;
    partInfo.etag = uploadPartResponse.etag();
    partEtags.push_back(partInfo);
    
    off += partSize;
  }

  bir_bos::CompleteMultipartUploadRequest completeMultipartUploadRequest(
        bos_info().bucket, filename, initMultiUploadResponse.upload_id());
  for (bir_bos::part_t partInfo : partEtags) {
    completeMultipartUploadRequest.add_part(partInfo.part_number, partInfo.etag);
  }
  bir_bos::CompleteMultipartUploadResponse completeMultipartUploadResponse;
  if (get_client()->complete_multipart_upload(
      completeMultipartUploadRequest, &completeMultipartUploadResponse)) {
    LOG(WARNING) << "bos complete_multipart_upload failed, filename: " << filename;
    return true;
  }
  return false;
}

bool BosWriter::abort_put_object_in_multi_part(
    const std::string &filename, const std::string &uploadId) {
  bir_bos::AbortMultipartUploadRequest abortMultipartUploadRequest(
        bos_info().bucket, filename, uploadId);
  bir_bos::AbortMultipartUploadResponse abortMultipartUploadResponse;
  if (get_client()->abort_multipart_upload(
      abortMultipartUploadRequest, &abortMultipartUploadResponse)) {
    LOG(WARNING) << "bos abort_multipart_upload failed, filename: " << filename;
    return true;
  }
  return false;
}

bool BosWriter::get_multi_part_uploads_unfinished(
    std::vector<bir_bos::MultipartUploadSummary> &uploads) {
  bir_bos::ListMultipartUploadsRequest listMultipartUploadsRequest(
      bos_info().bucket);
  bir_bos::ListMultipartUploadsResponse listMultipartUploadsResponse;
  if (get_client()->list_multipart_uploads(
    listMultipartUploadsRequest, &listMultipartUploadsResponse)) {
    LOG(WARNING) << "bos list_multipart_uploads failed";
    return true;
  }  

  uploads = listMultipartUploadsResponse.uploads();
  return false;
}

bool BosWriter::put_object(const std::string &filename, const uint64_t size) {
  const int retry_count = 3;
  bool ret = true;
  for (int i = 0; i < retry_count; ++i) {
    if (size > MAX_SIZE) {
      std::string uploadID;
      ret = put_large_object(filename);
    } else {
      ret = put_object_with_progress(filename);
    }
    if (!ret) {
      break;
    }
  }
  return ret;
}

} // end bos
