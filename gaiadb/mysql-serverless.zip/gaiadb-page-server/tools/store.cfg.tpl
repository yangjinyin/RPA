[store]
count=8

[store0]
# store path must exists
path=/path/store0
active=1
# optional size, unit byte
size=1
# optional capacity
capacity=1024

[store1]
path=/path/store1
active=1
# optional size
size=1
# optional capacity
capacity=1024

[store2]
path=/path/store2
active=1
# optional size
size=1
# optional capacity
capacity=1024

[store3]
path=/path/store3
active=1
# optional size
size=1
# optional capacity
capacity=1024

[store4]
path=/path/store4
active=1
# optional size
size=1
# optional capacity
capacity=1024

[store5]
path=/path/store5
active=1
# optional size
size=1
# optional capacity
capacity=1024

[store6]
path=/path/store6
active=1
# optional size
size=1
# optional capacity
capacity=1024

[store7]
path=/path/store7
active=1
# optional size
size=1
# optional capacity
capacity=1024
