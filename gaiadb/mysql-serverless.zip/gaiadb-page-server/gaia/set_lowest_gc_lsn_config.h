/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_lowest_gc_lsn_config.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class SetLowestGcLsnConfig : public Command {
public:
    SetLowestGcLsnConfig() {
        SetName("set-lowest-gc-lsn-config");
        SetDesc("set lowest gc lsn config to cluster");
        SetDescCn("开启或关闭集群的最低 GC LSN 功能");

        AddPsmClusterOption();
        AddRequiredArgOption("status", &_long_opt_val, kOptMax + 1, "enable or disable lowest gc lsn", kenum);
        
        AddExample("--manager-address \"bns://xxx\" --status 0");
    }
    virtual ~SetLowestGcLsnConfig() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _status.Set(!!std::strtoull(opt, NULL, 10));
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::SetLowestGcLsnConfigResponse& rsp);

private:
    std::string _manager_address {};
    VarOptional<bool> _status;
};

}
}
