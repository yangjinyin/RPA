/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_parser.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/parse_context.h"
#include "test/test_util.h"

namespace psvr {
namespace test {

class MockParser : public Parser {
public:
    MockParser(ClientPtr client, ControlWeakPtr control) : Parser(client, control) {}
    virtual ~MockParser() {}

    MOCK_METHOD1(Start, bool(uint32_t));
    TRACE_MOCK_METHOD2(Dispatch, void(SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::lsn_t));
    TRACE_MOCK_METHOD4(AddGetSpaceMetaEvent, void(SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, ggpb::Closure*, pspb::Status*));
    TRACE_MOCK_METHOD5(AddGetSpaceExtentEvent, void(SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, gaia_apply::page_no_t, ggpb::Closure*, pspb::Status*));
    TRACE_MOCK_METHOD6(AddGetSpaceExtentEvent, void(SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, gaia_apply::page_no_t, uint64_t, ggpb::Closure*, pspb::Status*));
    TRACE_MOCK_METHOD3(AddGetPeerEvent, void(SegmentPtr TRACE_FILE_LINE_DTC, ggpb::Closure*, pspb::Status*));
    TRACE_MOCK_METHOD1(AddClearSapceStatusEvent, void(SegmentPtr TRACE_FILE_LINE_DTC));
    TRACE_MOCK_METHOD1(AddGetAllSpaceIdEvent, void(SegmentPtr TRACE_FILE_LINE_DTC));

    MOCK_METHOD1(Execute, bool(Parser::Context*));
};

}
}
