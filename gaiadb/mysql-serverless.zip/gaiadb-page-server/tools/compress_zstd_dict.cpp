/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/rw16k.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <memory>
#include <map>
#include <iostream>
#include <filesystem>
#include <sys/stat.h>
#include <psvr/config.h>
#include <psvr/compress_utils.h>

namespace psvr {

DEFINE_string(file_name, "", "file name");
DEFINE_int64(file_size, 0, "file size");
DEFINE_int32(dict_buf_size, 128<<10, "dict buf size");
DEFINE_int64(compress_size, 33554432, "test compress size");
DEFINE_int64(compress_max_times, 10000, "test compress max times");
DEFINE_bool(disable_compress_normal, true, "disable compress normal");
DEFINE_string(build_secondary_file_name, "", "build secondary index file name");
DEFINE_uint64(sample_buf_size, (4<<10), "sample buf size");
DEFINE_bool(enable_check_index_data, false, "check data is secondary index");

constexpr static size_t kPageSize = (16<<10);

class Demo {
public:
    Demo() {}
    ~Demo() {}

    int Run() {
        if (FLAGS_file_name.empty()) {
            std::cout << "-file_name is empty" << std::endl;
            return -1;
        }
        if (FLAGS_dict_buf_size < (32<<10)) {
            std::cout << "-dict_buf_size value < 32KB" << std::endl;
            return -2;
        }
        int64_t file_size = 0;
        {
            dict::Compress compress(FLAGS_psvr_gc_compress_zstd_level);
            file_size = compress.GetFileSize(FLAGS_file_name);
            if (file_size <= 0) {
                std::cout << "-file_name size <= 0" << std::endl;
                return -2;
            }
            if (FLAGS_file_size > 0 && FLAGS_file_size < file_size) {
                file_size = FLAGS_file_size;
            }
        }

        int fd = open(FLAGS_file_name.c_str(), O_RDONLY, S_IRUSR | S_IWUSR);
        if (fd < 0) {
            std::cout << "-file_name open failed," << strerror(errno) << std::endl;
            return -3;
        }

        if (!FLAGS_build_secondary_file_name.empty()) {
            int64_t nsize = BuildSecondaryIndexFile(fd, file_size, FLAGS_build_secondary_file_name);
            if (nsize) {
                std::cout << "build new secondary index file size:" << nsize << std::endl;
            } else {
                std::cout << "build new secondary index file failed, ret:" << nsize << std::endl;
            }
            return nsize ? 0 : -4;
        }

        int64_t nr = 0;
        double dict_rate = 0;
        double dict_rate_real = 0;
        double normal_rate = 0;
        int64_t valid_nr = 0;

        bvar::IntRecorder dict_page_avg_size;
        bvar::IntRecorder dict_real_page_avg_size;
        bvar::IntRecorder normal_page_avg_size;

        char* buf = static_cast<char*>(std::malloc(FLAGS_compress_size));
        for (int64_t offset = 0; offset < file_size; offset += FLAGS_compress_size) {
            size_t buf_size = GetIndexPage(fd, offset, FLAGS_compress_size, buf);
            if (buf_size == 0 || buf_size != static_cast<size_t>(FLAGS_compress_size)) {
                std::cout << "offset:" << offset
                    << ", size:" << FLAGS_compress_size
                    << ", not found index pages"
                    << std::endl;
                continue;
            }

            size_t dict_compressed_buf_size = 0;
            if (!CompressByDict(buf, buf_size, &dict_compressed_buf_size, dict_page_avg_size)) {
                std::cout << "dict compress failed" << std::endl;
                return -4;
            }
            size_t dict_compressed_buf_size_real = dict_compressed_buf_size + FLAGS_dict_buf_size;

            size_t normal_compressed_buf_size = 0;
            if (!FLAGS_disable_compress_normal) {
                if (!CompressNormal(buf, buf_size, &normal_compressed_buf_size, normal_page_avg_size)) {
                    std::cout << "normal compress failed" << std::endl;
                    return -4;
                }
            }

            double buf_dict_rate = 1.0 * buf_size / dict_compressed_buf_size;
            double buf_dict_rate_real = 1.0 * buf_size / dict_compressed_buf_size_real;
            double buf_normal_rate = 1.0 * buf_size / normal_compressed_buf_size;
            if (buf_normal_rate < 10.0) {
                if (!FLAGS_compress_max_times) {
                    std::cout << "offset:" << offset
                        << ", size:" << FLAGS_compress_size
                        << ", buf_size:" << buf_size
                        << ", buf_rate:" << 1.0 * buf_size / FLAGS_compress_size
                        << ", dict_csize:" << dict_compressed_buf_size
                        << ", dict_rate:" << buf_dict_rate
                        << ", dict_csize_real:" << dict_compressed_buf_size_real
                        << ", dict_rate_real:" << buf_dict_rate_real
                        << ", normal_csize:" << normal_compressed_buf_size
                        << ", normal_rate:" << buf_normal_rate
                        << std::endl;
                }
                dict_rate += buf_dict_rate;
                dict_rate_real += buf_dict_rate_real;
                normal_rate += buf_normal_rate;
                ++valid_nr;
            }
            if (FLAGS_compress_max_times && nr && nr % 10 == 0) {
                std::cout << "nr:" << nr << std::endl;
            }
            if (FLAGS_compress_max_times && ++nr >= FLAGS_compress_max_times) {
                std::cout << "nr:" << nr
                    << " dict_rate:" << (dict_rate / valid_nr)
                    << " dict_rate_real:" << (dict_rate_real / valid_nr)
                    << " normal_rate:" << (normal_rate / valid_nr)
                    << " dict_page_avg_size:" << dict_page_avg_size.get_value()
                    << " normal_page_avg_size:" << normal_page_avg_size.get_value()
                    << std::endl;
                return 0;
            }
        }
        std::cout << "nr:" << nr
            << " valid_nr:" << valid_nr
            << " dict_rate:" << (dict_rate / valid_nr)
            << " dict_rate_real:" << (dict_rate_real / valid_nr)
            << " normal_rate:" << (normal_rate / valid_nr)
            << " dict_page_avg_size:" << dict_page_avg_size.get_value()
            << " normal_page_avg_size:" << normal_page_avg_size.get_value()
            << std::endl;
        return 0;
    }

    bool WriteSecondaryIndexFile(const std::string& file_prefix,
            gaia_apply::space_id_t space_id,
            void* buf, size_t buf_size) {
        static std::map<gaia_apply::space_id_t, int> space_id_fd_map;
        int nfd = 0;
        auto it = space_id_fd_map.find(space_id);
        if (it == space_id_fd_map.end()) {
            std::string new_file = file_prefix + std::to_string(space_id);
            nfd = open(new_file.c_str(), O_RDWR | O_CREAT | O_EXCL | O_APPEND, S_IRUSR | S_IWUSR);
            if (nfd < 0) {
                std::cout << "open secondary index failed," << strerror(errno) << std::endl;
                return false;
            }
            space_id_fd_map.emplace(space_id, nfd);
        } else {
            nfd = it->second;
        }
        ssize_t n = ::write(nfd, buf, buf_size);
        return static_cast<size_t>(n) == buf_size;
    }

    int64_t BuildSecondaryIndexFile(int32_t fd, int64_t size, const std::string& new_file) {
        int64_t nsize = 0;
        void* buf = std::malloc(kPageSize);
        for (int64_t i = 0; i < size; i += kPageSize) {
            ssize_t read_size = ::pread(fd, buf, kPageSize, i);
            if (read_size != static_cast<ssize_t>(kPageSize)) {
                std::cout << "read fail on create new file" << std::endl;
                break;
            }
            if (!FLAGS_enable_check_index_data
                    || gaia_apply::FIL_PAGE_INDEX == gaia_apply::fil_page_get_type(static_cast<gaia_apply::byte*>(buf))) {
                auto space_id = gaia_apply::page_get_space_id(static_cast<gaia_apply::byte*>(buf));
                if (!WriteSecondaryIndexFile(new_file, space_id, buf, kPageSize)) {
                    std::cout << "write fail on create new file" << std::endl;
                    return -1;
                }
                nsize += kPageSize;
            }
            if (i && i % 536870912 == 0) {
                std::cout << "create secondary index file, size:" << i << std::endl;
            }
        }
        return nsize;
    }

    size_t GetIndexPage(int32_t fd, int64_t offset, int64_t size, char* buf) {
        size_t buf_size = 0;
        for (int64_t off = 0; off < size; off += kPageSize) {
            char* page_buf = buf + buf_size;
            ssize_t read_size = ::pread(fd, page_buf, kPageSize, offset + off);
            if (read_size != static_cast<ssize_t>(kPageSize)) {
                std::cout << "read fail" << std::endl;
                return 0;
            }

            if (!FLAGS_enable_check_index_data
                    || gaia_apply::FIL_PAGE_INDEX == gaia_apply::fil_page_get_type(reinterpret_cast<gaia_apply::byte*>(page_buf))) {
                buf_size += kPageSize;
            }
        }
        return buf_size;
    }

    bool CompressByDict(char* buf, size_t buf_size, size_t* compressed_buf_size, bvar::IntRecorder& stat) {
        static void* cbuf = std::malloc(kPageSize * 2);
        std::string dict_buf;
        dict::TrainDict train(FLAGS_dict_buf_size);
        for (size_t i = 0; i < buf_size; i += FLAGS_sample_buf_size) {
            std::string sample(buf + i, FLAGS_sample_buf_size);
            train.AddSample(std::move(sample));
        }

        //std::cout << "dict sample buf size:" << train.samples_buf().size()
            //<< ", size:" << train.samples_size() << std::endl;
        if (!train.Train(&dict_buf)) {
            std::cout << "train dict failed" << std::endl;
            return false;
        }

        dict::Compress compress(FLAGS_psvr_gc_compress_zstd_level);
        compress.CreateDict(dict_buf);
        static ZSTD_CCtx* cctx = nullptr;
        if (!cctx) {
            cctx = compress.NewCtx();
        }
        for (size_t i = 0; i < buf_size; i += kPageSize) {
            size_t compressed_size = 0;
            bool rc = compress.Execute(cctx, buf + i, kPageSize,
                    cbuf, kPageSize * 2, &compressed_size);
            if (!rc) {
                std::cout << "dict compress failed, ret:" << compressed_size << std::endl;
                return false;
            }
            *compressed_buf_size += compressed_size;
            stat << compressed_size;
        }
        return true;
    }

    bool CompressNormal(char* buf, size_t buf_size, size_t* compressed_buf_size, bvar::IntRecorder& stat) {
        static void* cbuf = std::malloc(kPageSize * 2);
        for (size_t i = 0; i < buf_size; i += kPageSize) {
            size_t compressed_size = 0;
            bool rc = compress_data(PSVR_COMPRESS_TYPE_ZSTD, FLAGS_psvr_gc_compress_zstd_level,
                    reinterpret_cast<gaia_apply::byte*>(buf + i), kPageSize,
                    reinterpret_cast<gaia_apply::byte*>(cbuf), kPageSize * 2, &compressed_size);
            if (!rc) {
                std::cout << "normal compress failed, ret:" << compressed_size << std::endl;
                return false;
            }
            *compressed_buf_size += compressed_size;
            stat << compressed_size;
        }
        return true;
    }

private:
};

}

int main(int argc, char *argv[]) {
    const char* psvr_proc_name = strrchr(argv[0], '/');
    if (nullptr == psvr_proc_name) {
        psvr_proc_name = argv[0];
    } else {
        psvr_proc_name++;
    }

    std::string help_str;
    base::string_printf(&help_str,
            "Usage: %s [OPTIONS...]\n"
            "Options:\n"
            " -file_name=<file>                 file name\n"
            " -file_size=%lu                    file size\n"
            " -dict_buf_size=%d                 dict file size\n"
            " -compress_size=%ld                test compress buf size\n"
            " -compress_max_times=%ld           test compress max times\n"
            " -psvr_gc_compress_zstd_level=%d   zstd level \n",
            psvr_proc_name,
            psvr::FLAGS_file_size,
            psvr::FLAGS_dict_buf_size,
            psvr::FLAGS_compress_size,
            psvr::FLAGS_compress_max_times,
            psvr::FLAGS_psvr_gc_compress_zstd_level);
    google::SetUsageMessage(help_str);

    google::ParseCommandLineFlags(&argc, &argv, true);

    psvr::Demo demo;
    return demo.Run();
}

