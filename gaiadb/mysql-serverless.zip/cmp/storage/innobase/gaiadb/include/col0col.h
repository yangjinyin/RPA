/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/include/col0col.h
 The general function for column index

 Created 8/8/2023 guolingjie
 *******************************************************/
#pragma once

#include "dict0mem.h"
#include "row0row.h"
#include "sql/table.h"
#include "gaiadb/proto/formula/query.pb.h"

struct ColumnarExeContext;
// return a match string use tuple fileds for search
std::string match_string_from_record(dtuple_t *tuple, dict_index_t *index);

row_search_result row_search_column_index_entry(dtuple_t *tuple,
                                                dict_index_t *index,
                                                uint32_t &info_bits);

dberr_t row_update_column_index_info_bits(dtuple_t *entry, dict_index_t *index,
                                          uint16_t info_bits, que_thr_t *thr,
                                          mtr_t *mtr);

namespace formula {
DECLARE_string(formula_db_name);

void get_table_with_partition(const std::string &dict_name, std::string &schema,
               std::string &table);
               
// when index is creating, verbose must be true, otherwise false
void get_duckdb_table_name(const dict_index_t *index, std::string &full_name,
                           bool verbose = false);

// when index is creating, verbose must be true, otherwise false
void get_duckdb_table_name(const dict_index_t *index,
                           std::string &duckdb_schema,
                           std::string &duckdb_table, bool verbose = false);
                           
// when index is creating, verbose must be true, otherwise false
void get_duckdb_table_name(const std::string& origin_table, uint32_t space_id,
                           uint64_t index_id,
                           std::string &duckdb_table, bool verbose = false);

// return 0 if success, otherwise return -1
int handle_sql(const dict_index_t *index, ColumnarExeContext* ctx);

// return 0 if success, otherwise return -1
int handle_primary_key_scan(const dict_index_t *columnar_index,
                                const dict_index_t *cluster_index,
                                ColumnarExeContext* ctx);

dberr_t gaiadb_create_columnar_index(space_id_t space_id, uint64_t index_id);


/** drop remote columnar index*/
dberr_t gaiadb_drop_columnar_index(uint32_t space_id, uint64_t index_id);

/** get columnar index group id*/
dberr_t gaiadb_get_space_columnar_group(uint32_t space_id, uint64_t index_id,
                                        uint32_t &group_id);
}  // namespace formula
