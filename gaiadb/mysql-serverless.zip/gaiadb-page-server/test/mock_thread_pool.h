/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_thread_pool.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "test/test_common.h"
#include "psvr/thread_pool.hpp"

namespace psvr {
namespace test {


template<typename TaskType, typename TimerType>
class MockExecutor : public psvr::ThreadPoolExecutor<TaskType, TimerType> {
public:
    using ThreadType = std::shared_ptr<thread::Thread<TaskType, TimerType>>;
    MockExecutor() : psvr::ThreadPoolExecutor<TaskType, TimerType>() {
        //ON_CALL(*this, Execute(_))
            //.WillByDefault(Return(true));
        //ON_CALL(*this, EmergentExecute(_))
            //.WillByDefault(Return(true));
        //ON_CALL(*this, Schedule(_, _))
            //.WillByDefault(Return(true));
    }
    virtual ~MockExecutor() {}

    MOCK_METHOD4_T(Start, bool(const std::string&, std::shared_ptr<thread::Timer<TimerType>>,
                uint32_t, typename thread::Executor<TaskType, TimerType>::TaskFn&));
    MOCK_METHOD4_T(Start, bool(const std::string&, uint64_t,
                uint32_t, typename thread::Executor<TaskType, TimerType>::TaskFn&));

    MOCK_METHOD5_T(Start, bool(const std::string&, std::shared_ptr<thread::Timer<TimerType>>,
                uint32_t, bool, typename thread::Executor<TaskType, TimerType>::TaskFn&));
    MOCK_METHOD5_T(Start, bool(const std::string&, uint64_t,
                uint32_t, bool , typename thread::Executor<TaskType, TimerType>::TaskFn&));

    MOCK_METHOD1_T(GetThreadQueueSize, uint64_t(uint32_t));

    MOCK_METHOD1_T(Stop, void(bool));
    MOCK_METHOD1_T(Execute, bool(TaskType*));
    MOCK_METHOD1_T(EmergentExecute, bool(TaskType*));
    MOCK_METHOD2_T(Schedule, bool(TimerType*, uint64_t));
    MOCK_METHOD1_T(Cancel, bool(TimerType*));
    MOCK_METHOD1_T(IncThread, bool(uint32_t));
    MOCK_METHOD1_T(DecThread, std::vector<ThreadType>(uint32_t));

};

template<typename TaskType, typename TimerType>
class MockGroupThreadPoolExecutor : public GroupThreadPoolExecutor<TaskType, TimerType> {
    using VecThread = std::vector<std::shared_ptr<thread::Thread<TaskType, TimerType>>>;
    MockGroupThreadPoolExecutor() {}
    virtual ~MockGroupThreadPoolExecutor() {}

    MOCK_METHOD6_T(Start, bool(size_t, const std::string&, std::shared_ptr<thread::Timer<TimerType>>,
                uint32_t, typename thread::Executor<TaskType, TimerType>::TaskFn&, bool));

    MOCK_METHOD2_T(GetThreadQueueSize, uint64_t(size_t, uint32_t));

    MOCK_METHOD2_T(Execute, bool(size_t, TaskType*));
    MOCK_METHOD2_T(EmergentExecute, bool(size_t, TaskType*));
    MOCK_METHOD3_T(Schedule, bool(size_t, TimerType*, uint64_t));
    MOCK_METHOD2_T(Cancel, bool(size_t, TimerType*));
    MOCK_METHOD2_T(IncThread, bool(size_t, uint32_t));
    MOCK_METHOD2_T(DecThread, VecThread(size_t, uint32_t));
};

template<typename TaskType, typename QueueType>
class MockGroupConditionThread : public GroupConditionThread<TaskType, QueueType> {
    MockGroupConditionThread() {}
    virtual ~MockGroupConditionThread() {}

    MOCK_METHOD4_T(Start, bool(size_t, const std::string&,
                typename ConditionThread<TaskType, QueueType>::Fn&,
                const int64_t*));

    MOCK_METHOD2_T(Schedule, void(size_t, const TaskType&));
};

template<typename TaskType, typename QuotaType>
class MockQuotaThread : public QuotaThread<TaskType, QuotaType> {
    MockQuotaThread() {}
    virtual ~MockQuotaThread() {}

    MOCK_METHOD3_T(Start, bool(const std::string&, typename QuotaThread<TaskType, QuotaType>::Fn, const int64_t*));
    MOCK_METHOD2_T(GetQuota, bool(TaskType, QuotaType));

};


}
}
