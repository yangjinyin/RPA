/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test_segment.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <sys/stat.h>
#include <unistd.h>

#include <sstream>

#include "test/test_common.h"
#include "psvr/segment.h"
#include "test/mock_dbengine.h"
#include "test/mock_dblwr.h"
#include "bmock.h"

namespace psvr {
namespace test {

class SegmentTests : public PsvrTest {
 public:
    SegmentTests() {

    }
    virtual ~SegmentTests() {}

    void SetUp() {
        _segment = create_segment();
        gaia_apply::page_size_t page_size(16<<10, 16<<10, false);
        _mock_db_engine = new MockDBEngine();
        _mock_db_engine->_page_size = (16<<10);
        _segment->_db_engine.reset(_mock_db_engine);

        _mock_append_db_engine = new MockAppendDBEngine;
        _segment->_append_db_engine.reset(_mock_append_db_engine);

        _mock_dblwr = new MockDblwr();
        _segment->_dblwr.reset(_mock_dblwr);

        _mock_store_manager = new MockStoreManager();
        _control->_store_manager.reset(_mock_store_manager);

        // The mock objects created by BMOCK_NS_METHOD attach their hooks at static-init
        // time, so they would stay in effect for the whole binary. Stop them all here and
        // let each test enable only the ones it injects with BMOCK_NS_RESUME.
        BMOCK_NS_STOP(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        BMOCK_NS_STOP(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
        BMOCK_NS_STOP(std::filesystem, create_directory, bool(const std::filesystem::path&, std::error_code&));
        BMOCK_NS_STOP(std::filesystem, rename, void(const std::filesystem::path&, const std::filesystem::path&, std::error_code&));
        BMOCK_NS_STOP(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        BMOCK_NS_STOP(psvr::db, fsync, int(int));
        BMOCK_NS_STOP(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
        BMOCK_NS_CLASS_STOP(psvr, PsmInfo, RefreshNodesNoLock, bool());
    }

    void TearDown() {
    }

    void InitMeta() {
        gaiapb::PageServerInfo meta;
        meta.set_segment_id(1);
        meta.set_replica_id(0);
        meta.set_checkpoint_lsn(0);
        meta.set_apply_lsn(5000);
        meta.set_state(gaiadb::NODE_ACTIVE);
        meta.set_addr("127.0.0.1:8001");
        meta.set_fetch_lsn(6000);
        meta.set_max_extent_num(1);
        meta.set_recovery_status(gaiadb::RECOVERY_FINISH);

        _segment->InitMeta(meta);
        _segment->_init_flag.fetch_xor(Segment::kInitDB);
        _segment->InitLsn(meta);
    }

private:
    SegmentPtr _segment;
    MockDBEngine* _mock_db_engine;
    MockAppendDBEngine* _mock_append_db_engine;
    MockDblwr* _mock_dblwr;
    MockStoreManager* _mock_store_manager;
};

TEST_F(SegmentTests, test_StageInfo) {
    StageInfo stage_info;
    google::protobuf::RepeatedPtrField<pspb::SegmentStageInfo> infos;
    std::ostringstream os;

    os << stage_info;
    ASSERT_EQ(os.str(), "stage_info:[FetchStageUnInit,ParseStageUnInit,"
            "AppendStageUnInit,GCStageUnInit,RecoverStageUnInit,DblwrStageUnInit]");

    EXPECT_CALL(*_mock_dblwr, DumpBuf())
        .Times(3)
        .WillRepeatedly(Return(nullptr));
    stage_info.GetStageInfos(_segment.get(), &infos);
    ASSERT_EQ(infos.size(), 6);
    for (const auto& info : infos) {
        ASSERT_FALSE(info.has_action());
    }

    stage_info.SetStage(pspb::FetchStageSchedule, 1);
    stage_info.SetStage(pspb::ParseStageSchedule, 1);
    stage_info.SetStage(pspb::AppendStageSchedule, 1);
    stage_info.SetStage(pspb::GCStageSchedule, 1);
    stage_info.SetStage(pspb::RecoverStageSchedule, 1);
    stage_info.SetStage(pspb::DblwrStageSchedule, 1);
    os.str("");
    os << stage_info;
    ASSERT_EQ(os.str(), "stage_info:[FetchStageSchedule:kGetLogService,"
            "ParseStageSchedule:kParse,AppendStageSchedule:kRecoverPage,"
            "GCStageSchedule:kRecoverPage,RecoverStageSchedule:kDispatchRecovery,"
            "DblwrStageSchedule:kRecoverPage]");
    infos.Clear();
    stage_info.GetStageInfos(_segment.get(), &infos);
    ASSERT_EQ(infos.size(), 6);
    for (const auto& info : infos) {
        ASSERT_TRUE(info.has_action());
    }

    _segment->fetch_log_block_queue().PushFront(create_empty_log_block(
            static_cast<gaia_apply::lsn_t>(0), static_cast<gaia_apply::lsn_t>(10)));
    _segment->parse_log_block_queue().PushFront(create_empty_log_block(
            static_cast<gaia_apply::lsn_t>(10), static_cast<gaia_apply::lsn_t>(20)));
    _segment->append_log_block_queue().PushFront(create_empty_log_block(
            static_cast<gaia_apply::lsn_t>(20), static_cast<gaia_apply::lsn_t>(30)));
    infos.Clear();
    stage_info.GetStageInfos(_segment.get(), &infos);
    ASSERT_EQ(infos.Get(0).queue_size(), 1);
    ASSERT_EQ(infos.Get(1).queue_size(), 1);
    ASSERT_EQ(infos.Get(2).queue_size(), 1);
    ASSERT_EQ(infos.Get(5).file_no(), 0);
}

TEST_F(SegmentTests, test_LogBlockQueueSize) {
    LogBlockQueue queue;
    gaia_apply::lsn_t last_lsn = 999;
    auto first = create_empty_log_block(
            static_cast<gaia_apply::lsn_t>(0), static_cast<gaia_apply::lsn_t>(10));
    auto second = create_empty_log_block(
            static_cast<gaia_apply::lsn_t>(10), static_cast<gaia_apply::lsn_t>(20));

    ASSERT_TRUE(queue.PushBack(first, &last_lsn));
    ASSERT_EQ(last_lsn, 0);
    ASSERT_EQ(queue.log_block_size(), 1);
    queue.PushFront(second);
    ASSERT_EQ(queue.log_block_size(), 2);

    ASSERT_EQ(queue.Pop(), second);
    ASSERT_EQ(queue.log_block_size(), 1);
    ASSERT_EQ(queue.Pop(), first);
    ASSERT_EQ(queue.log_block_size(), 0);
    ASSERT_EQ(queue.Pop(), nullptr);

    auto invalid = create_empty_log_block(
            static_cast<gaia_apply::lsn_t>(100), static_cast<gaia_apply::lsn_t>(110));
    ASSERT_FALSE(queue.PushBack(invalid, &last_lsn));
    ASSERT_EQ(last_lsn, 10);
    ASSERT_EQ(queue.log_block_size(), 0);
    END_OF_CASE;
}

BMOCK_NS_METHOD2(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
BMOCK_NS_METHOD2(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
BMOCK_NS_METHOD2(std::filesystem, create_directory, bool(const std::filesystem::path&, std::error_code&));
BMOCK_NS_METHOD3(std::filesystem, rename, void(const std::filesystem::path&, const std::filesystem::path&, std::error_code&));
BMOCK_NS_METHOD3(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
BMOCK_NS_METHOD1(psvr::db, fsync, int(int));

#ifdef WITH_GAIA_APPLY_BAN_ASSERT
BMOCK_NS_METHOD9(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*,
                gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
#define TEST_ARG_C _
#define TEST_ARG_CC , TEST_ARG_C
#else
BMOCK_NS_METHOD8(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*,
                gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*));
#define TEST_ARG_C
#define TEST_ARG_CC
#endif

void set_buf_block(BufBlockPtr buf_block, gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no, const gaia_apply::page_size_t& page_size, gaia_apply::lsn_t lsn = 1024) {
    init_buf_block(buf_block, space_id, page_no, page_size);
    gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, space_id);
    gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_OFFSET, page_no);
    page_set_page_lsn(buf_block->frame, page_size.physical(), lsn);
}

TEST_F(SegmentTests, test_Statistic) {
    auto segment = create_segment();
    Statistic* s = new Statistic(segment.get(), "test");
    s->HideBvar();
    ASSERT_TRUE(s->_is_hid);
    s->_is_hid = false;
    delete s;
    LOG(NOTICE) << segment;

    SegmentPtr empty;
    LOG(NOTICE) << empty;
    Segment* empty2 = nullptr;
    LOG(NOTICE) << empty2;
}

BMOCK_NS_CLASS_METHOD0(psvr, PsmInfo, RefreshNodesNoLock, bool());
TEST_F(SegmentTests, test_PsmInfo) {
    std::vector<base::EndPoint> nodes;
    {
        // ok
        PsmInfo* psminfo = new PsmInfo("gaia://127.0.0.1:8999,127.0.0.2:8999,127.0.0.3:8999");
        ASSERT_TRUE(psminfo->ParseAddress());
        ASSERT_TRUE(psminfo->ParseAddress());
        ASSERT_TRUE(psminfo->RefreshNodes());

        base::EndPoint ep1;
        base::str2endpoint("127.0.0.5:8999", &ep1);
        gaiapb::BatchPageServerHeartbeatResponse req;
        req.add_peer_list("127.0.0.4:8999");
        req.add_peer_list("127.0.0.5:8999");
        req.add_peer_list("127.0.0.6:8999");
        psminfo->SetNodesFromHeartbeat(ep1, req.peer_list());
        psminfo->SetFailed();
        ASSERT_TRUE(psminfo->GetOrRefreshNodes(&nodes, true));
        psminfo->ToString(std::cout); std::cout << std::endl;

        base::EndPoint ep0;
        base::str2endpoint("127.0.0.1:8999", &ep0);
        ASSERT_EQ(nodes[0], ep0);
        ASSERT_EQ(nodes[3], ep1);

        base::EndPoint ep;
        base::str2endpoint("127.0.0.2:8999", &ep);
        psminfo->MoveLeaderToFirst(1, ep);
        base::EndPoint ep2;
        base::str2endpoint("127.0.0.4:8999", &ep2);
        psminfo->MoveLeaderToFirst(4, ep2);
        psminfo->ToString(std::cout); std::cout << std::endl;

        ASSERT_TRUE(psminfo->GetOrRefreshNodes(&nodes, false));
        ASSERT_EQ(nodes[0], ep);
        ASSERT_EQ(nodes[3], ep2);

        delete psminfo;
    }
    {
        // failed
        PsmInfo* psminfo = new PsmInfo("gaia1://127.0.0.1:8999");
        ASSERT_FALSE(psminfo->ParseAddress());
        ASSERT_FALSE(psminfo->RefreshNodes());
        ASSERT_FALSE(psminfo->GetOrRefreshNodes(&nodes));
        delete psminfo;
    }
    {
        // failed
        PsmInfo* psminfo = new PsmInfo("gaia://127.0.0.1");
        ASSERT_TRUE(psminfo->ParseAddress());
        ASSERT_FALSE(psminfo->RefreshNodes());
        ASSERT_FALSE(psminfo->GetOrRefreshNodes(&nodes, true));
        delete psminfo;
    }
    {
        // GetOrRefreshBNSNodes fail 1
        PsmInfo* psminfo = new PsmInfo("gaia1://127.0.0.1:8999,127.0.0.2:8999,127.0.0.3:8999");
        psminfo->_is_parsed = false;
        std::vector<base::EndPoint> nodes;
        ASSERT_FALSE(psminfo->GetOrRefreshBNSNodes(&nodes));
    }
    {
        // GetOrRefreshBNSNodes fail 2
        PsmInfo* psminfo = new PsmInfo("gaia://127.0.0.1:8999,127.0.0.2:8999,127.0.0.3:8999");
        ASSERT_TRUE(psminfo->ParseAddress());
        psminfo->_nodes.clear();
        psminfo->_err_times.store(2);
        BMOCK_NS_CLASS_RESUME(psvr, PsmInfo, RefreshNodesNoLock, bool());
        EXPECT_CALL(BMOCK_NS_CLASS_OBJECT(psvr, PsmInfo, RefreshNodesNoLock), RefreshNodesNoLock()).WillOnce(Return(false));
        std::vector<base::EndPoint> nodes;
        ASSERT_FALSE(psminfo->GetOrRefreshBNSNodes(&nodes));
    }
    BMOCK_NS_CLASS_STOP(psvr, PsmInfo, RefreshNodesNoLock, bool());
    {
        // GetOrRefreshBNSNodes success
        PsmInfo* psminfo = new PsmInfo("gaia://127.0.0.1:8999,127.0.0.2:8999,127.0.0.3:8999");
        ASSERT_TRUE(psminfo->ParseAddress());
        ASSERT_TRUE(psminfo->RefreshNodes());
        std::vector<base::EndPoint> nodes;
        ASSERT_TRUE(psminfo->GetOrRefreshBNSNodes(&nodes));
    }
}

TEST_F(SegmentTests, test_LogServices) {
    LogServices ls;
    std::vector<gaiadb::common::PeerZone> nodes;
    uint64_t version = 0;
    ASSERT_TRUE(ls.Set(nodes, &version));
    ASSERT_EQ(1, version);

    std::vector<gaiadb::common::PeerZone> nodes2;
    version = 0;
    ASSERT_FALSE(ls.Get(&nodes2, &version));

    FillServers(&nodes, 1);
    version = 0;
    ASSERT_TRUE(ls.Set(nodes, &version));
    ASSERT_EQ(2, version);
    version = 0;
    ASSERT_TRUE(ls.Get(&nodes2, &version));
    ASSERT_EQ(version, 2);
    ASSERT_EQ(nodes2.size(), 1);

    {
        ASSERT_TRUE(ls.GetRefreshLock(_segment));
        ASSERT_TRUE(ls.GetRefreshLock(_segment));

        auto segment = create_segment();
        ASSERT_FALSE(ls.GetRefreshLock(segment));

        _segment->_stopped = true;
        ASSERT_TRUE(ls.GetRefreshLock(segment));

        segment.reset();
        auto segment2 = create_segment();
        ASSERT_TRUE(ls.GetRefreshLock(segment2));
    }
}

TEST_F(SegmentTests, test_Compress) {
    int64_t page_count, data_size;
    _segment->UpdateStatCompress(page_count, data_size);
    ASSERT_TRUE(_segment->_stat_compress.inited);
    _segment->UpdateStatCompress(page_count, data_size);

    _segment->CompressFinish(false, 1, 1);
    {
        FLAGS_psvr_sync_on_recovery_or_compression = true;
        EXPECT_CALL(*_mock_db_engine, Sync(_)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(g_mock_store));
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(true));
        _segment->CompressFinish(true, 1, 1);
    }
    {
        EXPECT_CALL(*_mock_db_engine, Sync(_)).WillOnce(Return(db::Status()));
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(g_mock_store)).WillOnce(Return(g_mock_store));
        _segment->CompressFinish(true, 1, 1);
    }
    {
         FLAGS_psvr_sync_on_recovery_or_compression = false;
        //EXPECT_CALL(*_mock_db_engine, Sync(_)).WillOnce(Return(db::Status()));
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(nullptr));
        _segment->CompressFinish(true, 1, 1);
    }
    BMOCK_NS_STOP(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
}

TEST_F(SegmentTests, test_initflag2str) {
    _segment->_init_flag = 0;
    ASSERT_EQ(_segment->initflag2str(), "UnInit");
    _segment->_init_flag = Segment::kInitMeta;
    ASSERT_EQ(_segment->initflag2str(), "InitMeta");
    _segment->_init_flag = Segment::kInitMeta | Segment::kInitDB;
    ASSERT_EQ(_segment->initflag2str(), "InitDB");
    _segment->_init_flag = Segment::kInitMeta | Segment::kInitDB | Segment::kInitAppendDB;
    ASSERT_EQ(_segment->initflag2str(), "InitSucc");
    _segment->_init_flag = Segment::kInitError;
    ASSERT_EQ(_segment->initflag2str(), "InitError");
}

TEST_F(SegmentTests, test_InitMeta2) {
    InitMeta();
    ASSERT_EQ(0, _segment->replica_id());
    ASSERT_EQ(8204, _segment->_start_checkpoint_lsn);
    ASSERT_EQ(gaiadb::RECOVERY_FINISH, _segment->_recovery_status);
    ASSERT_EQ(true, _segment->_recovery_info.stopped);
    ASSERT_EQ(LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE, _segment->fetch_lsn());
    ASSERT_EQ(LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE, _segment->parse_lsn());
    ASSERT_EQ(LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE, _segment->gc_lsn());
    ASSERT_EQ(LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE, _segment->recovery_lsn());

    {
        _segment->SetClusterPsLowestLsn(9999999);
        ASSERT_EQ(9999999, _segment->GetClusterPsLowestLsn());
    }
    {
        _segment->SetClusterPsLowestGcLsn(9999999 + 1);
        ASSERT_EQ(9999999 + 1, _segment->GetClusterPsLowestLsn());
    }
    {
        _segment->SetClusterCnLowestLsn(9999999);
        ASSERT_EQ(9999999, _segment->GetClusterCnLowestLsn());
    }
    {
        _segment->SetClusterCnLowestLsn(9999999 + 1);
        ASSERT_EQ(9999999 + 1, _segment->GetClusterCnLowestLsn());
    }
}

TEST_F(SegmentTests, test_Cluster) {
    Cluster cluster("test");
    { // test statistic
        auto stat = cluster.statistic();
        ASSERT_EQ(stat->is_enable(), FLAGS_psvr_auto_enable_cluster_statistic);
        if (FLAGS_psvr_auto_enable_cluster_statistic) {
            ASSERT_FALSE(stat->Enable("bvar"));
            ASSERT_TRUE(stat->Disable());
            ASSERT_FALSE(stat->Disable());
            ASSERT_FALSE(stat->is_enable());
        } else {
            ASSERT_FALSE(stat->Disable());
            ASSERT_TRUE(stat->Enable("bvar"));
            ASSERT_FALSE(stat->Enable("bvar2"));
            ASSERT_TRUE(stat->is_enable());
        }
    }
    {
        // test RpcQuota
        auto rpc_quota = cluster.rpc_quota();

        auto segment = create_segment();
        auto segment2 = create_segment_by_cluster("c1", 2);

        {
            auto event = rpc_quota->CreateSpaceMetaEvent(segment, 1, nullptr, nullptr);
            ASSERT_TRUE(event != nullptr);
            {
                auto event2 = rpc_quota->CreateSpaceMetaEvent(segment, 1, nullptr, nullptr);
                ASSERT_TRUE(event2 == nullptr);
            }
            {
                auto event2 = rpc_quota->CreateSpaceMetaEvent(segment2, 1, nullptr, nullptr);
                ASSERT_TRUE(event2 == nullptr);
            }
            {
                auto event2 = rpc_quota->CreateSpaceMetaEvent(segment, 2, nullptr, nullptr);
                ASSERT_TRUE(event2 != nullptr);
            }
            rpc_quota->RemoveSpaceMetaEvent(event, [](SegmentPtr, gaia_apply::space_id_t, pspb::Status*, const EventClosureArgType&) {
                    });
            event = rpc_quota->CreateSpaceMetaEvent(segment, 1, nullptr, nullptr);
            ASSERT_TRUE(event != nullptr);
        }
        {
            auto event = rpc_quota->CreateSpaceExtentEvent(segment, 1, 2, 3, 2, nullptr, nullptr);
            ASSERT_TRUE(event != nullptr);
            {
                auto event2 = rpc_quota->CreateSpaceExtentEvent(segment, 1, 2, 3, 6, nullptr, nullptr);
                ASSERT_TRUE(event2 == nullptr);
            }
            {
                auto event2 = rpc_quota->CreateSpaceExtentEvent(segment2, 1, 2, 3, 5, nullptr, nullptr);
                ASSERT_TRUE(event2 == nullptr);
            }
            {
                auto event2 = rpc_quota->CreateSpaceExtentEvent(segment, 1, 3, 3, 4, nullptr, nullptr);
                ASSERT_TRUE(event2 != nullptr);
            }
            {
                auto event2 = rpc_quota->CreateSpaceExtentEvent(segment, 2, 2, 3, 3, nullptr, nullptr);
                ASSERT_TRUE(event2 != nullptr);
            }
            rpc_quota->RemoveSpaceExtentEvent(event, [](SegmentPtr, const event_space_extent_t&, pspb::Status*, const EventClosureArgType&) {
                    });
            event = rpc_quota->CreateSpaceExtentEvent(segment, 1, 2, 3, 7, nullptr, nullptr);
            ASSERT_TRUE(event != nullptr);
        }
        {
            auto event = rpc_quota->CreatePeerEvent(segment, nullptr, nullptr);
            ASSERT_TRUE(event != nullptr);
            {
                auto event2 = rpc_quota->CreatePeerEvent(segment, nullptr, nullptr);
                ASSERT_TRUE(event2 == nullptr);
            }
            {
                auto event2 = rpc_quota->CreatePeerEvent(segment2, nullptr, nullptr);
                ASSERT_TRUE(event2 != nullptr);
            }
            rpc_quota->RemovePeerEvent(event, [](SegmentPtr, gaiadb::common::segment_t, pspb::Status*, const EventClosureArgType&) {
                    });
            event = rpc_quota->CreatePeerEvent(segment, nullptr, nullptr);
            ASSERT_TRUE(event != nullptr);
        }
    }
}

TEST_F(SegmentTests, test_segment_is_valid) {
    {
        auto segment = create_segment();
        ASSERT_TRUE(segment_is_valid(segment));
    }
    {
        auto segment = create_segment();
        segment->_stopped = true;
        ASSERT_FALSE(segment_is_valid(segment));
    }
    {
        auto segment = create_segment();
        segment->_status = Segment::Status::kDelete;
        ASSERT_FALSE(segment_is_valid(segment));
    }
    {
        ASSERT_FALSE(segment_is_valid(nullptr));
    }
}

TEST_F(SegmentTests, test_Stop) {
    InitMeta();
    _segment->Stop();
    {
        _segment->_statistic.reset();
        _segment->Stop();
    }
    {
        _segment->_db_engine.reset();
        _segment->Stop();
    }
}

TEST_F(SegmentTests, test_InitConfigNoLock) {
    gaiapb::PageServerInfo meta;
    meta.set_segment_id(_segment->_segment_id + 1);
    {
        ASSERT_FALSE(_segment->InitConfigNoLock(meta));
    }
    meta.set_segment_id(_segment->_segment_id);
    {
        ASSERT_TRUE(_segment->InitConfigNoLock(meta));
        ASSERT_TRUE(_segment->_compress_cfg.enable);
    }
    {
        meta.set_recovery_status(gaiadb::RECOVERY_FINISH);
        ASSERT_TRUE(_segment->InitConfigNoLock(meta));
        ASSERT_TRUE(_segment->_compress_cfg.enable);
    }
    {
        meta.mutable_compress_cfg()->set_enable(false);
        meta.mutable_compress_cfg()->set_type("none");
        meta.mutable_compress_cfg()->set_level(-1);
        ASSERT_TRUE(_segment->InitConfigNoLock(meta));
        ASSERT_TRUE(_segment->_compress_cfg.enable);
    }
    {
        meta.mutable_compress_cfg()->set_enable(false);
        meta.mutable_compress_cfg()->set_type("zstd");
        meta.mutable_compress_cfg()->set_level(-1);
        ASSERT_TRUE(_segment->InitConfigNoLock(meta));
        ASSERT_FALSE(_segment->_compress_cfg.enable);
    }
    {
        meta.mutable_compress_cfg()->set_enable(false);
        meta.mutable_compress_cfg()->set_type("none");
        meta.mutable_compress_cfg()->set_level(1);
        ASSERT_TRUE(_segment->InitConfigNoLock(meta));
        ASSERT_FALSE(_segment->_compress_cfg.enable);
    }
    {
        meta.mutable_compress_cfg()->set_enable(true);
        meta.mutable_compress_cfg()->set_type("zstd");
        meta.mutable_compress_cfg()->set_level(3);
        FLAGS_psvr_auto_enable_segment_statistic = true;
        ASSERT_TRUE(_segment->InitConfigNoLock(meta));
        ASSERT_TRUE(_segment->_compress_cfg.enable);
        FLAGS_psvr_auto_enable_segment_statistic = false;
    }
}

TEST_F(SegmentTests, test_InitLsnNoLock) {
    gaiapb::PageServerInfo meta;
    meta.set_checkpoint_lsn(LOG_START_LSN);
    meta.set_apply_lsn(11111);
    _segment->_init_flag.fetch_xor(Segment::kInitDB);
    {
        // invalid lsn
        ASSERT_FALSE(_segment->InitLsnNoLock(meta));
    } END_OF_CASE;
    meta.set_checkpoint_lsn(0);
    {
        // ok
        auto segment = create_segment();
        segment->_init_flag.fetch_xor(Segment::kInitDB);
        ASSERT_TRUE(segment->InitLsnNoLock(meta));
        ASSERT_EQ(segment->_fetch_lsn(), LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE);
        ASSERT_EQ(segment->_parse_lsn(), LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE);
        ASSERT_EQ(segment->_gc_lsn(), LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE);
        ASSERT_EQ(segment->GetClusterCnLowestLsn(), LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE);
        ASSERT_EQ(segment->_recovery_lsn(), LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE);
    } END_OF_CASE;
    {
        // ok
        meta.set_checkpoint_lsn(19999);
        ASSERT_TRUE(_segment->InitLsnNoLock(meta));
        ASSERT_EQ(_segment->_fetch_lsn(), 19999);
        ASSERT_EQ(_segment->_parse_lsn(), 19999);
        ASSERT_EQ(_segment->_gc_lsn(), 19999);
        ASSERT_EQ(_segment->GetClusterCnLowestLsn(), 19999);
        ASSERT_EQ(_segment->_recovery_lsn(), 19999);
    } END_OF_CASE;
    {
        // again
        ASSERT_FALSE(_segment->InitLsn(meta));
    } END_OF_CASE;
    {
        // invalid _db_append_lsn
        auto segment = create_segment();
        segment->_init_flag.fetch_xor(Segment::kInitDB);
        segment->_db_append_lsn = 9999;
        meta.set_checkpoint_lsn(19999);
        ASSERT_FALSE(segment->InitLsnNoLock(meta));
    } END_OF_CASE;
    {
        // invalid _db_checkpoint_lsn
        auto segment = create_segment();
        segment->_init_flag.fetch_xor(Segment::kInitDB);
        segment->_db_append_lsn = 20000;
        segment->_db_checkpoint_lsn = 1;
        meta.set_checkpoint_lsn(19999);
        ASSERT_FALSE(segment->InitLsnNoLock(meta));
    } END_OF_CASE;
    {
        // invalid _db_checkpoint_lsn
        auto segment = create_segment();
        segment->_init_flag.fetch_xor(Segment::kInitDB | Segment::kInitMeta);
        segment->_db_append_lsn = 20000;
        segment->_db_checkpoint_lsn = LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE;
        meta.set_checkpoint_lsn(19999);
        ASSERT_TRUE(segment->InitLsnNoLock(meta));
        ASSERT_FALSE(segment->is_init());
        ASSERT_EQ(segment->_fetch_lsn(), LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE);
        ASSERT_EQ(segment->_parse_lsn(), LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE);
        ASSERT_EQ(segment->_gc_lsn(), LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE);
        ASSERT_EQ(segment->_recovery_lsn(), LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE);
    } END_OF_CASE;
    {
        // ok
        auto segment = create_segment();
        segment->_init_flag.fetch_xor(Segment::kInitDB | Segment::kInitMeta);
        segment->_db_append_lsn = 19999;
        segment->_db_checkpoint_lsn = 19999;
        meta.set_checkpoint_lsn(19999);
        ASSERT_TRUE(segment->InitLsnNoLock(meta));
        ASSERT_TRUE(segment->is_init());
    } END_OF_CASE;
}

TEST_F(SegmentTests, test_InitMeta) {
    gaiapb::PageServerInfo meta;
    meta.set_segment_id(_segment->_segment_id + 1);
    {
        ASSERT_FALSE(_segment->InitMeta(meta));
    }
    {
        meta.set_segment_id(_segment->_segment_id);
        ASSERT_TRUE(_segment->InitMeta(meta));
    }
}

TEST_F(SegmentTests, test_InitVersionNoLock) {
    gaiapb::PageServerInfo meta;
    {
        _segment->InitVersionNoLock(meta);
        ASSERT_EQ(0, _segment->_version);
    }
    {
        meta.set_version(1);
        _segment->InitVersionNoLock(meta);
        ASSERT_EQ(1, _segment->_version);
    }
}

TEST_F(SegmentTests, test_InitConfig) {
    gaiapb::PageServerInfo meta;
    meta.set_segment_id(_segment->_segment_id + 1);
    {
        // mismatch id
        ASSERT_FALSE(_segment->InitConfig(meta, true));
        ASSERT_FALSE(_segment->InitConfig(meta, false));
    }
    {
        // not control
        auto segment = create_segment();
        segment->_control.reset();
        meta.set_version(segment->_version + 1);
        ASSERT_FALSE(segment->InitConfig(meta, false));
    }
    {
        // mismatch id
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(true));
        ASSERT_FALSE(_segment->InitConfig(meta, false));
    }
    BMOCK_NS_STOP(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
}

TEST_F(SegmentTests, test_SetCompressConfig_GetCompressConfig){
    pspb::CompressConfig cfg;
    cfg.set_enable(true);
    cfg.set_type("zstd");
    cfg.set_level(3);
    _segment->SetCompressConfig(cfg);

    _segment->GetCompressConfig(&cfg);
    ASSERT_EQ(true, cfg.enable());
    ASSERT_EQ("zstd", cfg.type());
    ASSERT_EQ(3, cfg.level());
}

TEST_F(SegmentTests, test_StoreMeta) {
    {
        _control->_multi_type = false;
        ASSERT_TRUE(_segment->StoreMetaNoLock());
        _control->_multi_type = true;
    }
    {
        // save fail
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(nullptr));
        ASSERT_FALSE(_segment->StoreMetaNoLock());
    }
    {
        // save fail 2
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(g_mock_store));
        ASSERT_FALSE(_segment->StoreMetaNoLock());
    }
    {
        std::string from;
        uint64_t version;
        ASSERT_FALSE(_segment->GetRebalanceNode(&from, &version));
        // save ok
        _segment->_version = 1;
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _))
            .WillOnce(Return(true))
            .WillOnce(Return(true));
        _segment->SetRebalanceNode("127.0.0.1:9988", 2);
        ASSERT_TRUE(_segment->StoreMetaNoLock());
        ASSERT_TRUE(_segment->GetRebalanceNode(&from, &version));
        ASSERT_EQ(version, 2);
        ASSERT_EQ(from, "127.0.0.1:9988");

        _segment->ClearRebalanceNode();
        ASSERT_FALSE(_segment->GetRebalanceNode(&from, &version));

        _segment->ClearRebalanceNode();
        ASSERT_FALSE(_segment->GetRebalanceNode(&from, &version));
    }
    {
        const bool old_enable_sync_directory = FLAGS_psvr_enable_sync_directory;
        FLAGS_psvr_enable_sync_directory = true;
        const_cast<std::string&>(_segment->_db_path) = ".";
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _))
            .WillOnce(Return(true));
        BMOCK_NS_RESUME(psvr::db, fsync, int(int));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, fsync), fsync(_))
            .WillOnce(Invoke([](int) {
                errno = EIO;
                return -1;
            }));
        const bool ret = _segment->StoreMetaNoLock();
        FLAGS_psvr_enable_sync_directory = old_enable_sync_directory;
        ASSERT_FALSE(ret);
    }
    BMOCK_NS_STOP(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
    BMOCK_NS_STOP(psvr::db, fsync, int(int));
}

TEST_F(SegmentTests, test_Get_Init_Reset_PsmInfo) {
    auto psminfo = _segment->GetPsmInfo();
    ASSERT_TRUE(psminfo != nullptr);
    _segment->_psm_info.reset();
    ASSERT_TRUE(_segment->GetPsmInfo() == nullptr);
    _segment->InitPsmInfo(psminfo);
    ASSERT_TRUE(_segment->ResetPsmInfo(psminfo));

    {
        // save fail
        auto new_psminfo = std::make_shared<PsmInfo>("gaia:://test2");
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(g_mock_store));
        ASSERT_FALSE(_segment->ResetPsmInfo(new_psminfo));
        ASSERT_EQ(_segment->GetPsmInfo(), psminfo);
    }
    {
        // save ok
        auto new_psminfo = std::make_shared<PsmInfo>("gaia:://test2");
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(true));
        ASSERT_TRUE(_segment->ResetPsmInfo(new_psminfo));
        ASSERT_EQ(_segment->GetPsmInfo(), new_psminfo);
    }
    BMOCK_NS_STOP(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
}

TEST_F(SegmentTests, test_InitPath) {
    {
        // std::filesystem::exists false
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(false));
        BMOCK_NS_RESUME(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directories), create_directories(_, _)).WillOnce(Return(false));
        ASSERT_FALSE(_segment->InitPathNoLock("./data/trash"));
    }
    {
        // create tmp failed
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _))
            .WillOnce(Return(true))
            .WillOnce(Return(false));
        BMOCK_NS_RESUME(std::filesystem, create_directory, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directory), create_directory(_, _)).WillOnce(Return(false));
        ASSERT_FALSE(_segment->InitPathNoLock("./data/trash"));
    }
    {
        // rename old dir failed
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _))
            .WillOnce(Return(true))
            .WillOnce(Return(true))
            .WillOnce(Return(true))
            .WillOnce(Return(false));
        auto ec = std::error_code(1, std::system_category());
        BMOCK_NS_RESUME(std::filesystem, rename, void(const std::filesystem::path&, const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, rename), rename(_, _, _)).WillOnce(DoAll(SetArgReferee<2>(ec), Return()));
        ASSERT_FALSE(_segment->InitPathNoLock("./data/trash"));
    }
    {
        // ok
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(false));
        BMOCK_NS_RESUME(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directories), create_directories(_, _)).WillOnce(Return(true));
        ASSERT_TRUE(_segment->InitPathNoLock("./data/tarsh"));
        // again
        ASSERT_FALSE(_segment->InitPathNoLock("./data/tarsh"));
    }
    BMOCK_NS_STOP(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(std::filesystem, create_directory, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(std::filesystem, rename, void(const std::filesystem::path&, const std::filesystem::path&, std::error_code&));
}

TEST_F(SegmentTests, test_InitPath_directory_sync_failure) {
    const bool old_enable_sync_directory = FLAGS_psvr_enable_sync_directory;
    FLAGS_psvr_enable_sync_directory = true;

    BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
    EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _))
        .WillOnce(Return(false));
    BMOCK_NS_RESUME(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
    EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directories),
            create_directories(_, _))
        .WillOnce(Return(true));
    BMOCK_NS_RESUME(psvr::db, fsync, int(int));
    EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, fsync), fsync(_))
        .WillOnce(Invoke([](int) {
            errno = EIO;
            return -1;
        }));

    ASSERT_FALSE(_segment->InitPathNoLock("./data/trash"));
    ASSERT_FALSE(_segment->_db_is_init);
    FLAGS_psvr_enable_sync_directory = old_enable_sync_directory;
    BMOCK_NS_STOP(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(psvr::db, fsync, int(int));
    END_OF_CASE;
}

TEST_F(SegmentTests, test_CreateMeta) {
    {
        // std::filesystem::exists false
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(false));
        BMOCK_NS_RESUME(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directories), create_directories(_, _)).WillOnce(Return(false));
        ASSERT_FALSE(_segment->CreateMeta("./data/trash"));
    }
    {
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(false));
        BMOCK_NS_RESUME(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directories), create_directories(_, _)).WillOnce(Return(true));
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(g_mock_store));
        ASSERT_FALSE(_segment->CreateMeta("./trash"));
    }
    {
        //_segment->_store_id = -1;
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(false));
        BMOCK_NS_RESUME(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directories), create_directories(_, _)).WillOnce(Return(true));
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(true));
        ASSERT_TRUE(_segment->CreateMeta("./trash"));
    }
    BMOCK_NS_STOP(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
}

TEST_F(SegmentTests, test_LoadEngineWithMeta) {
    gaiapb::PageServerInfo meta;
    meta.set_segment_id(2);
    meta.set_replica_id(0);
    meta.set_checkpoint_lsn(0);
    meta.set_apply_lsn(5000);
    meta.set_state(gaiadb::NODE_ACTIVE);
    meta.set_addr("127.0.0.1:8001");
    meta.set_fetch_lsn(6000);
    meta.set_max_extent_num(1);
    meta.set_recovery_status(gaiadb::RECOVERY_FINISH);
    {
        // mismatch status
        ASSERT_FALSE(_segment->LoadEngineWithMeta(meta));
    } END_OF_CASE;
    _segment->_status = Segment::Status::kPrepare;
    {
        // mismatch seg id
        ASSERT_FALSE(_segment->LoadEngineWithMeta(meta));
    } END_OF_CASE;
    meta.set_segment_id(1);
    {
        // fail OpenEngineNoLock
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kBusy)));
        ASSERT_FALSE(_segment->LoadEngineWithMeta(meta));
    } END_OF_CASE;
    {
        // fail StoreMeta
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_db_engine, GetSize(_)).WillOnce(Return(1));
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(g_mock_store));
        EXPECT_CALL(*_mock_append_db_engine, Open(_, _, _, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*_mock_dblwr, Open(_, _, _)).WillOnce(Return(db::Status()));
        ASSERT_FALSE(_segment->LoadEngineWithMeta(meta));
    } END_OF_CASE;
    {
        // ok
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_db_engine, GetSize(_)).WillOnce(Return(1));
        EXPECT_CALL(*_mock_append_db_engine, Open(_, _, _, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*_mock_dblwr, Open(_, _, _)).WillOnce(Return(db::Status()));
        ASSERT_TRUE(_segment->LoadEngineWithMeta(meta));
    } END_OF_CASE;
    BMOCK_NS_STOP(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
}

TEST_F(SegmentTests, test_OpenEngineNoLock_OpenEngine) {
    {
        auto segment = create_segment();
        segment->_control.reset();
        ASSERT_FALSE(segment->OpenEngine(false));
    } END_OF_CASE;
    {
        // failed
        auto segment = create_segment_by_store_id(-1);
        ASSERT_FALSE(segment->OpenEngineNoLock(true));
    } END_OF_CASE;
    {
        // open failed
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kBusy)));
        ASSERT_FALSE(_segment->OpenEngineNoLock(false));
    } END_OF_CASE;
    {
        // open fail2
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_dblwr, Open(_, _, _)).WillOnce(Return(db::Status(db::Code::kIOError)));
        ASSERT_FALSE(_segment->OpenEngineNoLock(false));
    } END_OF_CASE;
    {
        // open fail2
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_dblwr, Open(_, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_append_db_engine, Open(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kIOError)));
        ASSERT_FALSE(_segment->OpenEngineNoLock(false));
    } END_OF_CASE;
    {
        // open ok
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_dblwr, Open(_, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_append_db_engine, Open(_, _, _, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*_mock_db_engine, GetSize(_)).WillOnce(Return(1));
        ASSERT_TRUE(_segment->OpenEngineNoLock(false));
        ASSERT_TRUE(_segment->is_active());
    } END_OF_CASE;
}

TEST_F(SegmentTests, test_CreateEngine) {
    {
        // OpenEngineNoLock failed
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(false));
        BMOCK_NS_RESUME(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directories), create_directories(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kBusy)));
        ASSERT_FALSE(_segment->CreateEngine("./trash"));
    } END_OF_CASE;
    {
        // StoreMeta failed
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(false));
        BMOCK_NS_RESUME(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directories), create_directories(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_dblwr, Open(_, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_append_db_engine, Open(_, _, _, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*_mock_db_engine, GetSize(_)).WillOnce(Return(1));
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(g_mock_store));
        ASSERT_FALSE(_segment->CreateEngine("./trash"));
    } END_OF_CASE;
    {
        // ok
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(false));
        BMOCK_NS_RESUME(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directories), create_directories(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_dblwr, Open(_, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_append_db_engine, Open(_, _, _, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*_mock_db_engine, GetSize(_)).WillOnce(Return(1));
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(true));
        ASSERT_TRUE(_segment->CreateEngine("./trash"));
        // again
        ASSERT_FALSE(_segment->CreateEngine("./trash"));
    } END_OF_CASE;
    BMOCK_NS_STOP(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(std::filesystem, create_directories, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
}

TEST_F(SegmentTests, test_CloseEngine) {
    ASSERT_TRUE(_segment->CloseEngine());
}

TEST_F(SegmentTests, test_ReOpen) {
    gaiapb::PageServerInfo meta;
    meta.set_segment_id(1);
    meta.set_replica_id(0);
    meta.set_checkpoint_lsn(0);
    meta.set_apply_lsn(5000);
    meta.set_state(gaiadb::NODE_ACTIVE);
    meta.set_addr("127.0.0.1:8001");
    meta.set_fetch_lsn(6000);
    meta.set_max_extent_num(1);
    meta.set_recovery_status(gaiadb::RECOVERY_FINISH);
    meta.set_checkpoint_lsn(1);
    meta.mutable_compress_cfg()->set_enable(false);

    {
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(false));
        ASSERT_FALSE(_segment->ReOpen(meta));
    } END_OF_CASE;
    {
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kBusy)));
        ASSERT_FALSE(_segment->ReOpen(meta));
    } END_OF_CASE;
    {
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_dblwr, Open(_, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_append_db_engine, Open(_, _, _, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*_mock_db_engine, GetSize(_)).WillOnce(Return(1));
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(nullptr));
        ASSERT_FALSE(_segment->ReOpen(meta));
    } END_OF_CASE;
    {
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_db_engine, Open(_)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_dblwr, Open(_, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_append_db_engine, Open(_, _, _, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*_mock_db_engine, GetSize(_)).WillOnce(Return(1));
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(true));
        ASSERT_FALSE(_segment->ReOpen(meta));
    } END_OF_CASE;

    {
        ASSERT_TRUE(_segment->GetPreDisable());
        ASSERT_FALSE(_segment->GetPreDisable());
        _segment->PutPreDisable();
    } END_OF_CASE;
    {
        _segment->_stopped = true;
        ASSERT_FALSE(_segment->PreDisable());
        _segment->_stopped = false;

        _control->_multi_type = false;
        ASSERT_FALSE(_segment->PreDisable());
        _control->_multi_type = true;

        ASSERT_TRUE(_segment->PreDisable());
        ASSERT_TRUE(_segment->PreDisable());

    } END_OF_CASE;
    {
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(false));
        BMOCK_NS_RESUME(std::filesystem, create_directory, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directory), create_directory(_, _)).WillOnce(Return(false));
        ASSERT_FALSE(_segment->Disable());
    } END_OF_CASE;
    {
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _))
            .WillOnce(Return(true))
            .WillOnce(Return(false))
            .WillOnce(Return(false))
            .WillOnce(Return(true));

        auto ec = std::error_code(1, std::system_category());
        BMOCK_NS_RESUME(std::filesystem, rename, void(const std::filesystem::path&, const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, rename), rename(_, _, _)).WillOnce(DoAll(SetArgReferee<2>(ec), Return()));
        ASSERT_FALSE(_segment->Disable());
    } END_OF_CASE;
    {
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _))
            .WillOnce(Return(true))
            .WillOnce(Return(true))
            .WillOnce(Return(false))
            .WillOnce(Return(false));

        std::error_code ec;
        BMOCK_NS_RESUME(std::filesystem, rename, void(const std::filesystem::path&, const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, rename), rename(_, _, _)).WillOnce(DoAll(SetArgReferee<2>(ec), Return()));
        ASSERT_TRUE(_segment->Disable());
    } END_OF_CASE;
    {
        _segment->_disable = false;
        ASSERT_FALSE(_segment->Disable());
    } END_OF_CASE;
    BMOCK_NS_STOP(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(std::filesystem, create_directory, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(std::filesystem, rename, void(const std::filesystem::path&, const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
}

TEST_F(SegmentTests, test_Disable_directory_sync_failures) {
    const bool old_enable_sync_directory = FLAGS_psvr_enable_sync_directory;
    const std::string old_db_path = _segment->_db_path;
    const std::string sync_test_path = base::string_printf(
            "./test_segment_disable_sync_%d", static_cast<int>(::getpid()));
    const std::string disable_path = sync_test_path + "/disable";
    ASSERT_EQ(0, ::mkdir(sync_test_path.c_str(), 0755));
    ASSERT_EQ(0, ::mkdir(disable_path.c_str(), 0755));

    FLAGS_psvr_enable_sync_directory = true;
    _segment->_db_path = sync_test_path;
    _segment->_disable = true;

    {
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _))
            .WillOnce(Return(false));
        BMOCK_NS_RESUME(std::filesystem, create_directory, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directory),
                create_directory(_, _))
            .WillOnce(Return(true));
        BMOCK_NS_RESUME(psvr::db, fsync, int(int));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, fsync), fsync(_))
            .WillOnce(Invoke([](int) {
                errno = EIO;
                return -1;
            }));
        ASSERT_FALSE(_segment->Disable());
    } END_OF_CASE;

    {
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _))
            .WillOnce(Return(true))
            .WillOnce(Return(false))
            .WillOnce(Return(false))
            .WillOnce(Return(false));
        BMOCK_NS_RESUME(psvr::db, fsync, int(int));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, fsync), fsync(_))
            .Times(2)
            .WillRepeatedly(Invoke([](int) {
                errno = EIO;
                return -1;
            }));
        ASSERT_FALSE(_segment->Disable());
    } END_OF_CASE;

    _segment->_db_path = old_db_path;
    FLAGS_psvr_enable_sync_directory = old_enable_sync_directory;
    ASSERT_EQ(0, ::rmdir(disable_path.c_str()));
    ASSERT_EQ(0, ::rmdir(sync_test_path.c_str()));
    BMOCK_NS_STOP(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(std::filesystem, create_directory, bool(const std::filesystem::path&, std::error_code&));
    BMOCK_NS_STOP(psvr::db, fsync, int(int));
}

TEST_F(SegmentTests, test_Delete) {
    {
        // StoreMeta failed
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(g_mock_store));
        ASSERT_FALSE(_segment->Delete());
    }
    gaiapb::PageServerInfo meta;
    meta.set_segment_id(1);
    meta.set_replica_id(0);
    meta.set_checkpoint_lsn(0);
    meta.set_apply_lsn(5000);
    meta.set_state(gaiadb::NODE_ACTIVE);
    meta.set_addr("127.0.0.1:8001");
    meta.set_fetch_lsn(6000);
    meta.set_max_extent_num(1);
    meta.set_recovery_status(gaiadb::RECOVERY_FINISH);
    meta.set_checkpoint_lsn(1);
    meta.mutable_compress_cfg()->set_enable(false);
    _segment->InitConfigNoLock(meta);
    {
        // ok
        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(true));
        ASSERT_TRUE(_segment->Delete());
        // again
        ASSERT_TRUE(_segment->Delete());
    }
    BMOCK_NS_STOP(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
}

TEST_F(SegmentTests, test_UpdateDBSize) {
    {
        ASSERT_EQ(0, _segment->_segment_physical_size);
        // invalid status
        _segment->UpdateDBSize();
        ASSERT_EQ(0, _segment->_segment_physical_size);

        _segment->_status = Segment::Status::kOpen;
        _segment->_init_flag.fetch_xor(Segment::kInitDB);
        _segment->_stopped = true;
        _segment->UpdateDBSize();
        ASSERT_EQ(0, _segment->_segment_physical_size);

        EXPECT_CALL(*_mock_db_engine, GetSize(_))
            .WillOnce(Return(-1))
            .WillOnce(Return(1));
        _segment->_stopped = false;
        _segment->UpdateDBSize();
        ASSERT_EQ(0, _segment->_segment_physical_size);
        _segment->UpdateDBSize();
        ASSERT_EQ(1, _segment->_segment_physical_size);
    }
}

TEST_F(SegmentTests, test_SetSpaceStatus) {
    ASSERT_TRUE(_segment->SetSpaceStatus(1, kSpaceStatusWork));
    ASSERT_FALSE(_segment->SetSpaceStatus(1, kSpaceStatusDeleted | kSpaceStatusWithPSM));   // parse work

    ASSERT_TRUE(_segment->SetSpaceStatus(2, kSpaceStatusDeleted | kSpaceStatusWithPSM));    // unknown

    ASSERT_TRUE(_segment->SetSpaceStatus(3, kSpaceStatusWork | kSpaceStatusWithPSM));
    ASSERT_TRUE(_segment->SetSpaceStatus(3, kSpaceStatusDeleted | kSpaceStatusWithPSM));    // delete

    ASSERT_TRUE(_segment->SetSpaceStatus(4, kSpaceStatusDeleted));
    ASSERT_TRUE(_segment->SetSpaceStatus(4, kSpaceStatusDeleted | kSpaceStatusWithPSM));    // delete


    ASSERT_TRUE(_segment->SetSpaceStatus(5, kSpaceStatusDeleted));
    ASSERT_FALSE(_segment->SetSpaceStatus(5, kSpaceStatusWork | kSpaceStatusWithPSM));

    ASSERT_TRUE(_segment->SetSpaceStatus(6, kSpaceStatusWork));
    ASSERT_FALSE(_segment->SetSpaceStatus(6, kSpaceStatusWork | kSpaceStatusWithPSM));

    ASSERT_TRUE(_segment->SetSpaceStatus(7, kSpaceStatusWork | kSpaceStatusWithPSM));   // unknown

    ASSERT_TRUE(_segment->SetSpaceStatus(8, kSpaceStatusDeleted | kSpaceStatusWithPSM));
    ASSERT_TRUE(_segment->SetSpaceStatus(8, kSpaceStatusWork | kSpaceStatusWithPSM));
}

TEST_F(SegmentTests, test_AddFetchLogBlock) {
    {
        LogBlockPtr log_block = create_empty_log_block(9999);
        _segment->_fetch_log_block_queue.SetlastLsn(log_block->start_lsn);
        ASSERT_TRUE(_segment->AddFetchLogBlock(log_block));
        ASSERT_EQ(9999, _segment->fetch_lsn());

        LogBlockPtr log_block_err = create_log_block(9998);
        ASSERT_FALSE(_segment->AddFetchLogBlock(log_block_err));
        ASSERT_EQ(9999, _segment->fetch_lsn());

        LogBlockPtr log_block2 = create_log_block(9999lu, 11111lu);
        ASSERT_TRUE(_segment->AddFetchLogBlock(log_block2));
        ASSERT_EQ(11111, _segment->fetch_lsn());

        LogBlockPtr log_block3 = create_empty_log_block(11111lu + 1, 11111lu + 1000);
        ASSERT_FALSE(_segment->AddFetchLogBlock(log_block3));
        ASSERT_EQ(11111, _segment->fetch_lsn());
    }
}

TEST_F(SegmentTests, test_AddParseLogBlock) {
    LogBlockPtr log_block2 = create_log_block(11111, false);
    _segment->_parse_log_block_queue.SetlastLsn(log_block2->start_lsn);
    _segment->AddParseLogBlock(log_block2);
    ASSERT_EQ(11111, _segment->parse_lsn());
}

TEST_F(SegmentTests, test_DropSpace) {
    {
        // ok
        LogRecord record(gaia_apply::MLOG_LSN, nullptr, 0, 1024, 10240, 1, 2, false, 0);
        _segment->SetClusterCnLowestLsn(10240);
        _segment->DropSpace(record.space_id, record.end_lsn);
    }
    {
        // ok 2
        LogRecord record(gaia_apply::MLOG_LSN, nullptr, 0, 1024, 10240, 1, 2, false, 0);
        _segment->SetClusterCnLowestLsn(10240 + 1);
        _segment->DropSpace(record.space_id, record.end_lsn);
    }
}

TEST_F(SegmentTests, test_PushGcLsn) {
    {
        auto segment = create_segment();
        segment->SetClusterCnLowestLsn(99999);
        LogBlockPtr log_block = create_log_block();
        log_block->chunks.emplace_back(destroy_only::make_unique_ptr<LogBlockChunk>(&log_block->mb_arena, 1, &log_block->mb_arena));
        log_block->chunks.emplace_back(destroy_only::make_unique_ptr<LogBlockChunk>(&log_block->mb_arena, 4, &log_block->mb_arena));
        log_block->chunks.emplace_back(destroy_only::make_unique_ptr<LogBlockChunk>(&log_block->mb_arena, 3, &log_block->mb_arena));
        segment->RetryPushGcLsn(log_block, *log_block->chunks[2]);
        ASSERT_EQ(1, segment->gc_lsn());
    }
    {
        auto segment = create_segment();
        segment->SetClusterCnLowestLsn(99999);
        LogBlockPtr log_block = create_log_block();
        log_block->chunks.emplace_back(destroy_only::make_unique_ptr<LogBlockChunk>(&log_block->mb_arena, 2, &log_block->mb_arena));
        log_block->chunks.emplace_back(destroy_only::make_unique_ptr<LogBlockChunk>(&log_block->mb_arena, 4, &log_block->mb_arena));
        log_block->chunks.emplace_back(destroy_only::make_unique_ptr<LogBlockChunk>(&log_block->mb_arena, 3, &log_block->mb_arena));
        log_block->chunks[2]->real_gc_page_count = 1;
        //EXPECT_CALL(*_mock_db_engine, Sync(_)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(g_mock_store));
        segment->RetryPushGcLsn(log_block, *log_block->chunks[2]);
        ASSERT_EQ(2, segment->gc_lsn());
        segment->RetryPushGcLsn(log_block, *log_block->chunks[1]);
        ASSERT_EQ(2, segment->gc_lsn());
    }
    {
        LogBlockPtr log_block = create_log_block();
        log_block->real_gc_page_count = 1;
        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(g_mock_store));
        _segment->PushGcLsn(log_block);

        // invaid control
        _segment->_control.reset();
        _segment->PushGcLsn(log_block);
    }
}

TEST_F(SegmentTests, test_AddAppendLogBlock) {
    FLAGS_psvr_enable_append_file = false;
    {
        auto segment = create_segment();
        LogBlockPtr log_block2 = create_log_block(11111, false);
        segment->_append_log_block_queue.SetlastLsn(log_block2->start_lsn);
        segment->AddAppendLogBlock(log_block2);
        ASSERT_EQ(0, segment->append_lsn());
    }
    FLAGS_psvr_enable_append_file = true;
    {
        auto segment = create_segment();
        LogBlockPtr log_block2 = create_log_block(11111, false);
        segment->_append_log_block_queue.SetlastLsn(log_block2->start_lsn);
        segment->AddAppendLogBlock(log_block2);
        ASSERT_EQ(11111, segment->append_lsn());
    }
    FLAGS_psvr_enable_append_file = false;
}

TEST_F(SegmentTests, test_InitAllSpaceId) {
    gaiapb::GetAllSpaceIdsResponse rsp;
    rsp.add_space_ids(1);
    rsp.add_space_ids(2);
    rsp.add_encrypt_space_ids(2);

    ASSERT_TRUE(space_status_is_unknown(_segment->GetSpaceStatus(1)));
    ASSERT_TRUE(space_status_is_unknown(_segment->GetSpaceStatus(2)));
    _segment->InitAllSpaceId(rsp);
    ASSERT_TRUE(space_status_is_work(_segment->GetSpaceStatus(1)));
    ASSERT_TRUE(space_status_is_work(_segment->GetSpaceStatus(2)));
    ASSERT_TRUE(space_status_with_psm(_segment->GetSpaceStatus(1)));
    ASSERT_TRUE(space_status_with_psm(_segment->GetSpaceStatus(2)));
    ASSERT_TRUE(space_encrypt_status_is_enable(_segment->GetSpaceEncryptStatus(2)));
}

TEST_F(SegmentTests, test_GcDelayForRecovery) {
    {
        _segment->_recovery_lsn(10);
        _segment->_peer_gc_lsn(20);
        ASSERT_FALSE(_segment->GcDelayForRecovery(1));

        _segment->_gc_delay_flag = 1;
        ASSERT_FALSE(_segment->GcDelayForRecovery(1));

        _segment->_recovery_status = gaiadb::RECOVERY_IN;
        ASSERT_FALSE(_segment->GcDelayForRecovery(1));

        ASSERT_TRUE(_segment->GcDelayForRecovery(21));
    }
}

TEST_F(SegmentTests, test_ParseLogBlockToLogRecords) {
    {
        // _parse_lsn > lb lsn
        _segment->_parse_lsn(11111);
        auto lb = create_empty_log_block(8888);
        bool ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);
        ASSERT_FALSE(ret);
    }

    {
        // ok
        _segment->_parse_lsn(11111);
        auto lb = create_empty_log_block(22222);
        _segment->_parse_log_block_queue.SetlastLsn(lb->start_lsn);

        bool ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);
        ASSERT_TRUE(ret);
        ASSERT_EQ(22222, _segment->parse_lsn());

        // twice
        ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);
        ASSERT_FALSE(ret);
    }

    {
        // invalid rec_end_lsn rec
        auto lb = create_log_block(33333);
        _segment->_parse_log_block_queue.SetlastLsn(lb->start_lsn);
        gaia_apply::mach_write_to_8(static_cast<void*>(lb->buf), 1111);
        bool ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);

        ASSERT_FALSE(ret);
        ASSERT_EQ(22222, _segment->parse_lsn());
    }
    {
        // incomplete record header
        auto lb = create_log_block(33333);
        _segment->_parse_log_block_queue.SetlastLsn(lb->start_lsn);
        lb->buf_size = sizeof(uint64_t);

        bool ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);
        ASSERT_FALSE(ret);
        ASSERT_EQ(22222, _segment->parse_lsn());
    } END_OF_CASE;
    {
        // rec_len = 0
        auto lb = create_log_block(33333);
        _segment->_parse_log_block_queue.SetlastLsn(lb->start_lsn);

        BMOCK_NS_RESUME(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, psvr_recv_parse_log_rec), psvr_recv_parse_log_rec(_, _, _, _, _, _, _ TEST_ARG_CC, _))
            .WillOnce(Return(0));

        bool ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);
        ASSERT_FALSE(ret);
        ASSERT_EQ(22222, _segment->parse_lsn());
    } END_OF_CASE;
    {
        // is_corrupt
        auto lb = create_log_block(33333);
        _segment->_parse_log_block_queue.SetlastLsn(lb->start_lsn);

        BMOCK_NS_RESUME(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, psvr_recv_parse_log_rec), psvr_recv_parse_log_rec(_, _, _, _, _, _, _ TEST_ARG_CC, _))
            .WillOnce(DoAll(SetArgPointee<8>(true), Return(1)));

        bool ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);
        ASSERT_FALSE(ret);
        ASSERT_EQ(22222, _segment->parse_lsn());
    } END_OF_CASE;
    {
        // APPLY_RAW_IS_ERROR
        auto lb = create_log_block(33333);
        _segment->_parse_log_block_queue.SetlastLsn(lb->start_lsn);

        BMOCK_NS_RESUME(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, psvr_recv_parse_log_rec), psvr_recv_parse_log_rec(_, _, _, _, _, _, _ TEST_ARG_CC, _))
            .WillOnce(DoAll(SetArgPointee<7>(true), Return(1)));

        bool ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);
        ASSERT_FALSE(ret);
        ASSERT_EQ(22222, _segment->parse_lsn());
    } END_OF_CASE;
    {
        // rec_end_sn = 0
        auto lb = create_log_block(33333);
        _segment->_parse_log_block_queue.SetlastLsn(lb->start_lsn);
        gaia_apply::mach_write_to_8(static_cast<void*>(lb->buf), 512 * 100);

        BMOCK_NS_RESUME(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, psvr_recv_parse_log_rec), psvr_recv_parse_log_rec(_, _, _, _, _, _, _ TEST_ARG_CC, _))
            .WillOnce(Return(10));

        bool ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);
        ASSERT_FALSE(ret);
        ASSERT_EQ(22222, _segment->parse_lsn());
    } END_OF_CASE;
    {
        // rec_end_sn < rec_len
        auto lb = create_log_block(33333);
        _segment->_parse_log_block_queue.SetlastLsn(lb->start_lsn);
        gaia_apply::mach_write_to_8(static_cast<void*>(lb->buf), 512 * 100 + gaia_apply::LOG_BLOCK_HDR_SIZE + 14);

        BMOCK_NS_RESUME(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, psvr_recv_parse_log_rec), psvr_recv_parse_log_rec(_, _, _, _, _, _, _ TEST_ARG_CC, _))
            .WillOnce(Return(1000000));

        bool ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);
        ASSERT_FALSE(ret);
        ASSERT_EQ(22222, _segment->parse_lsn());
    } END_OF_CASE;
    {
        // log_lsn_validate
        auto lb = create_log_block(33333);
        _segment->_parse_log_block_queue.SetlastLsn(lb->start_lsn);

        BMOCK_NS_RESUME(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, psvr_recv_parse_log_rec), psvr_recv_parse_log_rec(_, _, _, _, _, _, _ TEST_ARG_CC, _))
            .WillOnce(DoAll(SetArgPointee<6>(gaia_apply::RECORD_CHECK_BITS_LEN * 2), Return(5)));

        bool ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);
        ASSERT_FALSE(ret);
        ASSERT_EQ(22222, _segment->parse_lsn());
    } END_OF_CASE;
    {
        // log_lsn_validate
        auto lb = create_log_block(33333);
        _segment->_parse_log_block_queue.SetlastLsn(lb->start_lsn);

        BMOCK_NS_RESUME(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, psvr_recv_parse_log_rec), psvr_recv_parse_log_rec(_, _, _, _, _, _, _ TEST_ARG_CC, _))
            .WillOnce(DoAll(SetArgPointee<6>(gaia_apply::RECORD_CHECK_BITS_LEN), Return(5)));

        bool ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);
        ASSERT_FALSE(ret);
        ASSERT_EQ(22222, _segment->parse_lsn());
    } END_OF_CASE;
    {
        // log_lsn_validate
        auto lb = create_log_block(33333);
        _segment->_parse_log_block_queue.SetlastLsn(lb->start_lsn);

        BMOCK_NS_RESUME(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, psvr_recv_parse_log_rec), psvr_recv_parse_log_rec(_, _, _, _, _, _, _ TEST_ARG_CC, _))
            .WillOnce(DoAll(SetArgPointee<6>(gaia_apply::RECORD_CHECK_BITS_LEN * 3), Return(5)));

        bool ret = _segment->ParseLogBlockToLogRecords(get_log_id(), lb);
        ASSERT_FALSE(ret);
        ASSERT_EQ(22222, _segment->parse_lsn());
    } END_OF_CASE;
    BMOCK_NS_STOP(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));

    // TODO
}

TEST_F(SegmentTests, test_ParseSpaceLifecycleSafeTrimLsn) {
    constexpr gaia_apply::space_id_t kSpaceId = 123;
    constexpr gaia_apply::lsn_t kDeleteBlockStart = 512 * 100 + 100;
    constexpr gaia_apply::lsn_t kDeleteRecordEnd = kDeleteBlockStart + 50;
    constexpr gaia_apply::lsn_t kDeleteBlockEnd = kDeleteBlockStart + 100;
    constexpr gaia_apply::lsn_t kCreateRecordEnd = kDeleteBlockEnd + 50;
    constexpr gaia_apply::lsn_t kCreateBlockEnd = kDeleteBlockEnd + 100;

    auto parse_record = [](gaia_apply::mlog_id_t type,
                                gaia_apply::space_id_t space_id) {
        return [type, space_id](auto* out_type, auto* start_ptr, auto* end_ptr,
                       auto* out_space_id, auto* out_page_no, auto** body,
                       uint32_t* check_bits_len,
                       auto*... tail) -> gaia_apply::ulint {
            *out_type = type;
            *out_space_id = space_id;
            *out_page_no = 0;
            *body = start_ptr;
            *check_bits_len = 0;
            return static_cast<gaia_apply::ulint>(end_ptr - start_ptr);
        };
    };

    _segment->_parse_lsn(kDeleteBlockStart);
    auto delete_block = create_log_block(
            kDeleteBlockStart, kDeleteBlockEnd, false, 0, false);
    gaia_apply::mach_write_to_8(delete_block->buf, kDeleteRecordEnd);
    _segment->_parse_log_block_queue.SetlastLsn(delete_block->start_lsn);
    BMOCK_NS_RESUME(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
    EXPECT_CALL(BMOCK_NS_OBJECT(psvr, psvr_recv_parse_log_rec),
            psvr_recv_parse_log_rec(
                    _, _, _, _, _, _, _ TEST_ARG_CC, _))
        .WillOnce(Invoke(parse_record(
                gaia_apply::MLOG_FILE_DELETE, kSpaceId)));

    ASSERT_TRUE(_segment->ParseLogBlockToLogRecords(
            get_log_id(), delete_block));
    ASSERT_TRUE(space_status_is_deleted(
            _segment->GetSpaceStatus(kSpaceId)));
    ASSERT_EQ(_segment->GetSpaceSafeTrimLsn(kSpaceId), kDeleteRecordEnd);

    auto create_block = create_log_block(
            kDeleteBlockEnd, kCreateBlockEnd, false, 0, false);
    gaia_apply::mach_write_to_8(create_block->buf, kCreateRecordEnd);
    BMOCK_NS_RESUME(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
    EXPECT_CALL(BMOCK_NS_OBJECT(psvr, psvr_recv_parse_log_rec),
            psvr_recv_parse_log_rec(
                    _, _, _, _, _, _, _ TEST_ARG_CC, _))
        .WillOnce(Invoke(parse_record(
                gaia_apply::MLOG_FILE_CREATE, kSpaceId)));

    ASSERT_TRUE(_segment->ParseLogBlockToLogRecords(
            get_log_id(), create_block));
    ASSERT_TRUE(space_status_is_work(
            _segment->GetSpaceStatus(kSpaceId)));
    ASSERT_EQ(_segment->GetSpaceSafeTrimLsn(kSpaceId), 0);
    BMOCK_NS_STOP(psvr, psvr_recv_parse_log_rec, gaia_apply::ulint(gaia_apply::mlog_id_t*, gaia_apply::byte*, gaia_apply::byte*, gaia_apply::space_id_t*, gaia_apply::page_no_t*, gaia_apply::byte**, uint32_t*, bool*, bool*));
    END_OF_CASE;
}


TEST_F(SegmentTests, test_GetSpacePagePhysicalOffset) {
    std::vector<base::EndPoint> nodes;
    nodes.push_back(base::EndPoint());
    nodes.push_back(base::EndPoint());
    uint64_t physical_offset = 0;
    {
        // not found
        ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, 1, &physical_offset));
        ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, 1));
        ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(100, 1)); // not exist id
    }
    {
        gaiapb::GetSpaceExtentMapResponse response;
        response.set_total_extent_num(2048);
        auto extent_map = response.mutable_extent_map();
        for (int32_t i = 0; i < 64; ++i) {
            auto entries = extent_map->add_entries();
            entries->set_segment_id(1);
            entries->set_physical_extent_id(i);
            if (i == 2) {
                entries->set_segment_id(2);
            }
            if (i == 3) {
                entries->set_physical_extent_id(98);
            }
            if (i == 4) {
                entries->set_segment_id(2);
                entries->set_physical_extent_id(99);
            }
        }
        event_space_extent_t fold(1, 0); // space id,  begin extent id
        _segment->SetSpaceExtent(fold, ExtentArg{1024, 2 * GAIADB_EXTENT_PAGE_NUM} /*search extent id, logical_page_no*/, false, response);

        for (int32_t i = 0; i < 64 + 8; ++i) {
            LOG(NOTICE) << i;
            if (i >= 64) {
                ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, i * GAIADB_EXTENT_PAGE_NUM, &physical_offset));
                ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, i * GAIADB_EXTENT_PAGE_NUM));
                continue;
            }
            if (i == 2){
                ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, i * GAIADB_EXTENT_PAGE_NUM, &physical_offset));
                ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, i * GAIADB_EXTENT_PAGE_NUM));
            } else if (i == 3){
                ASSERT_TRUE(_segment->GetSpacePagePhysicalOffset(1, i * GAIADB_EXTENT_PAGE_NUM, &physical_offset));
                ASSERT_TRUE(_segment->ExistSpacePagePhysicalOffset(1, i * GAIADB_EXTENT_PAGE_NUM));
                ASSERT_EQ(physical_offset, 98 * GAIADB_EXTENT_SIZE);
            } else if (i == 4){
                ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, i * GAIADB_EXTENT_PAGE_NUM, &physical_offset));
                ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, i * GAIADB_EXTENT_PAGE_NUM));
            } else {
                ASSERT_TRUE(_segment->GetSpacePagePhysicalOffset(1, i * GAIADB_EXTENT_PAGE_NUM, &physical_offset));
                ASSERT_TRUE(_segment->ExistSpacePagePhysicalOffset(1, i * GAIADB_EXTENT_PAGE_NUM));
                ASSERT_EQ(physical_offset, i * GAIADB_EXTENT_SIZE);
            }
        } END_OF_CASE;

        {
            bool data_invalid = false;
            physical_offset = 1lu * GAIADB_EXTENT_SIZE;
            // extent 2 mismatch segment id, but physical_offset is belong space 1 extent 1
            ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, 2 * GAIADB_EXTENT_PAGE_NUM, &physical_offset, &data_invalid));
            ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, 2 * GAIADB_EXTENT_PAGE_NUM));
            ASSERT_TRUE(data_invalid);
        } END_OF_CASE;
        {
            bool data_invalid = false;
            physical_offset = 1024lu * GAIADB_EXTENT_SIZE;
            // extent 100 is unknown, but physical_offset is search reqeust
            ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, 100 * GAIADB_EXTENT_PAGE_NUM, &physical_offset, &data_invalid));
            ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, 100 * GAIADB_EXTENT_PAGE_NUM));
            ASSERT_TRUE(data_invalid);
        } END_OF_CASE;
        {
            bool data_invalid = false;
            physical_offset = 8lu * GAIADB_EXTENT_SIZE;
            // space 2 extent 8 is unknown, but physical_offset is belong extent 8
            ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(2, 8 * GAIADB_EXTENT_PAGE_NUM, &physical_offset, &data_invalid));
            ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(2, 8 * GAIADB_EXTENT_PAGE_NUM));
            ASSERT_TRUE(data_invalid);
        } END_OF_CASE;
        {
            bool data_invalid = false;
            physical_offset = 2048lu * GAIADB_EXTENT_SIZE;
            // extent 2 mismatch segment id, but physical_offset is unknown
            ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, 2 * GAIADB_EXTENT_PAGE_NUM, &physical_offset, &data_invalid));
            ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, 2 * GAIADB_EXTENT_PAGE_NUM));
            ASSERT_FALSE(data_invalid);
        } END_OF_CASE;
        {
            bool data_invalid = false;
            physical_offset = 98lu * GAIADB_EXTENT_SIZE;
            // extent 98 is unknown, but physical_offset is logical extent 3
            ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, 98 * GAIADB_EXTENT_PAGE_NUM, &physical_offset, &data_invalid));
            ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, 98 * GAIADB_EXTENT_PAGE_NUM));
            ASSERT_TRUE(data_invalid);
        } END_OF_CASE;
        {
            bool data_invalid = false;
            physical_offset = 98lu * GAIADB_EXTENT_SIZE;
            // space 2 extent 99 is unknown, but physical_offset is space 1 logical extent 3
            ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(2, 98 * GAIADB_EXTENT_PAGE_NUM, &physical_offset, &data_invalid));
            ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(2, 98 * GAIADB_EXTENT_PAGE_NUM));
            ASSERT_TRUE(data_invalid);
        } END_OF_CASE;
        {
            bool data_invalid = false;
            physical_offset = 1lu * GAIADB_EXTENT_SIZE;
            // extent 4 mismatch segment id, but physical_offset is belong space 1 extent 1
            ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, 4 * GAIADB_EXTENT_PAGE_NUM, &physical_offset, &data_invalid));
            ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, 4 * GAIADB_EXTENT_PAGE_NUM));
            ASSERT_TRUE(data_invalid);
        } END_OF_CASE;
    } END_OF_CASE;
    {
        _segment->_extent_meta_manager->CleanSpaceExtent(1);
        ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, 1, &physical_offset));
        ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, 1));
    }
    {
        gaiapb::GetSpaceExtentMapResponse response;
        response.set_total_extent_num(128);
        response.set_actual_get_num(64);
        std::string* buf = response.mutable_extent_map_bytes();
        buf->resize(64 * 2 * sizeof(uint32_t));
        uint32_t* ptr = reinterpret_cast<uint32_t*>(&(*buf)[0]);
        for (uint32_t i = 0; i < 64; ++i) {
            uint32_t segment_id = 1;
            uint32_t physical_extent_id = i;
            if (i == 3) {
                segment_id = 2;
            }
            *ptr = segment_id;
            *++ptr = physical_extent_id;
            ++ptr;
        }
        event_space_extent_t fold(1, 0);
        _segment->SetSpaceExtent(fold, ExtentArg{1025, 64*3}, false, response);

        for (int32_t i = 0; i < 64 * 64; ++i) {
            if (i / 64 == 3) {
                ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, i, &physical_offset));
                ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, i));
            } else {
                ASSERT_TRUE(_segment->GetSpacePagePhysicalOffset(1, i, &physical_offset));
                ASSERT_TRUE(_segment->ExistSpacePagePhysicalOffset(1, i));
                ASSERT_EQ(physical_offset, i *(16<<10));
            }
        }

        ASSERT_TRUE(_segment->GetSpacePagePhysicalOffset(1, 2, &physical_offset));
        ASSERT_TRUE(_segment->ExistSpacePagePhysicalOffset(1, 2));
        ASSERT_EQ(physical_offset, 2 * (16<<10));

        ASSERT_TRUE(_segment->GetSpacePagePhysicalOffset(1, 64*2, &physical_offset));
        ASSERT_TRUE(_segment->ExistSpacePagePhysicalOffset(1, 64*2));
        ASSERT_EQ(physical_offset, 128 * (16<<10));

        bool data_invalid = false;
        physical_offset = 1025 * (1<<20);
        ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, 64*3, &physical_offset, &data_invalid));
        ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, 64*3));
        ASSERT_TRUE(data_invalid);
    }
    {
        _segment->_extent_meta_manager->CleanSpaceExtent(1);
        ASSERT_FALSE(_segment->GetSpacePagePhysicalOffset(1, 2, &physical_offset));
        ASSERT_FALSE(_segment->ExistSpacePagePhysicalOffset(1, 2));
    }
    {
        event_space_extent_t fold(2, 0);
        gaiapb::GetSpaceExtentMapResponse response;
        _segment->SetSpaceExtent(fold, ExtentArg{1024, 65}, true, response);
    }
    {
        event_space_extent_t fold(1, 0);
        gaiapb::GetSpaceExtentMapResponse response;
        *response.mutable_extent_map_bytes() = std::string();
        _segment->SetSpaceExtent(fold, ExtentArg{1024, 65}, true, response);
    }
    {
        event_space_extent_t fold(1, 0);
        gaiapb::GetSpaceExtentMapResponse response;
        _segment->SetSpaceExtent(fold, ExtentArg{1024, 65}, false, response);
    }
    {
        event_space_extent_t fold(1, 0);
        gaiapb::GetSpaceExtentMapResponse response;
        *response.mutable_extent_map_bytes() = std::string();
        _segment->SetSpaceExtent(fold, ExtentArg{1024, 65}, false, response);
    }
}

TEST_F(SegmentTests, test_GetPeerNodes) {
    std::vector<base::EndPoint> nodes;
    nodes.emplace_back(base::EndPoint());
    nodes.emplace_back(base::EndPoint());

    std::vector<gaiadb::common::PeerZone> replicas;
    {
        // empty _peer_info.replicas
        ASSERT_FALSE(_segment->GetPeerNodes(&replicas));
    }
    {
        gaiapb::GetSegmentResponse response;
        _segment->UpdatePeerNodes(_segment->_segment_id, true, response);
        _segment->_rebalance_from = "127.0.0.1:8888";
        _segment->_rebalance_version = 2;
        {
            auto ps = response.add_page_servers();
            ps->set_segment_id(1);
            ps->set_replica_id(0);
            ps->set_checkpoint_lsn(0);
            ps->set_apply_lsn(0);
            ps->set_state(gaiadb::NODE_ACTIVE);
            ps->set_addr("127.0.0.1:8888");
            ps->set_version(1);
        }
        {
            auto ps = response.add_page_servers();
            ps->set_segment_id(1);
            ps->set_replica_id(1);
            ps->set_checkpoint_lsn(0);
            ps->set_apply_lsn(0);
            ps->set_state(gaiadb::NODE_ACTIVE);
            ps->set_addr("127.0.0.1:8889");
        }
        {
            auto ps = response.add_page_servers();
            ps->set_segment_id(1);
            ps->set_replica_id(2);
            ps->set_checkpoint_lsn(0);
            ps->set_apply_lsn(0);
            ps->set_state(gaiadb::NODE_ACTIVE);
            ps->set_addr(_control->myself_str());
        }

        BMOCK_NS_RESUME(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, atomic_write_file), atomic_write_file(_, _, _)).WillOnce(Return(true));
        _segment->UpdatePeerNodes(_segment->_segment_id, false, response);
        ASSERT_TRUE(_segment->_rebalance_from.empty());
        ASSERT_TRUE(_segment->_rebalance_version == 0);
    } END_OF_CASE;
    {
        // get from cache
        bool ret = _segment->GetPeerNodes(&replicas);
        ASSERT_TRUE(ret);
        ASSERT_EQ(2, replicas.size());
        LOG(NOTICE) << replicas[0] << "," << replicas[1];
    } END_OF_CASE;
    {
        // get from cache 2
        bool ret = _segment->GetPeerNodes(&replicas);
        ASSERT_TRUE(ret);
        ASSERT_EQ(2, replicas.size());
        LOG(NOTICE) << replicas[0] << "," << replicas[1];
    } END_OF_CASE;
    {
        _segment->MovePeerNodeToFirst(1, replicas[1]);
        _segment->SetPeerNodeFailed(0, replicas[0]);
    } END_OF_CASE;
    BMOCK_NS_STOP(psvr, atomic_write_file, bool(const std::string&, const std::string&, bool));
}

TEST_F(SegmentTests, test_GetPeerNodes2) {
    std::vector<base::EndPoint> nodes;
    nodes.emplace_back(base::EndPoint());
    nodes.emplace_back(base::EndPoint());

    std::vector<gaiadb::common::PeerZone> replicas;
    {
        // empty _peer_info.replicas
        ASSERT_FALSE(_segment->GetPeerNodes(&replicas));
    }
    {
        gaiapb::GetSegmentResponse response;
        _segment->UpdatePeerNodes(_segment->_segment_id, true, response);
        _segment->_rebalance_from = "127.0.0.1:8888";
        _segment->_rebalance_version = 1;
        {
            auto ps = response.add_page_servers();
            ps->set_segment_id(1);
            ps->set_replica_id(0);
            ps->set_checkpoint_lsn(0);
            ps->set_apply_lsn(0);
            ps->set_state(gaiadb::NODE_ACTIVE);
            ps->set_addr("127.0.0.1:8888");
            ps->mutable_zone()->set_region("r1");
            ps->mutable_zone()->set_available_zone("a1");
            ps->set_addr("127.0.0.1:8888");
            ps->set_version(1);
        }
        {
            auto ps = response.add_page_servers();
            ps->set_segment_id(1);
            ps->set_replica_id(1);
            ps->set_checkpoint_lsn(0);
            ps->set_apply_lsn(0);
            ps->set_state(gaiadb::NODE_ACTIVE);
            ps->set_addr("127.0.0.1:8889");
            ps->mutable_zone()->set_region("r1");
            ps->mutable_zone()->set_available_zone("a2");
        }
        {
            auto ps = response.add_page_servers();
            ps->set_segment_id(1);
            ps->set_replica_id(2);
            ps->set_checkpoint_lsn(0);
            ps->set_apply_lsn(0);
            ps->set_state(gaiadb::NODE_ACTIVE);
            ps->set_addr(_control->myself_str());
            ps->mutable_zone()->set_region("r1");
            ps->mutable_zone()->set_available_zone("a1");
        }
        _segment->UpdatePeerNodes(_segment->_segment_id, false, response);
    } END_OF_CASE;
    {
        // get from cache
        bool ret = _segment->GetPeerNodes(&replicas);
        ASSERT_TRUE(ret);
        ASSERT_EQ(2, replicas.size());
        LOG(NOTICE) << replicas[0] << "," << replicas[1];
    } END_OF_CASE;
    {
        // get from cache
        bool ret = _segment->GetPeerNodes(&replicas);
        ASSERT_TRUE(ret);
        ASSERT_EQ(2, replicas.size());
        LOG(NOTICE) << replicas[0] << "," << replicas[1];
    } END_OF_CASE;
    {
        _segment->MovePeerNodeToFirst(1, replicas[1]);
        _segment->SetPeerNodeFailed(0, replicas[0]);
    } END_OF_CASE;
}

TEST_F(SegmentTests, test_Recovery) {
    auto segment = create_segment(gaia_apply::FLAGS_univ_page_size * 3);
    {
        // ok
        ASSERT_TRUE(segment->TurnOnRecovery(true));
        // again failed
        ASSERT_FALSE(segment->TurnOnRecovery(true));
    }
    {
        segment->StartRecovery();
        ASSERT_TRUE(!!segment->_recovery_info.pages_min_lsn);
    } END_OF_CASE;
    {
        segment->SetGcDelayForRecovery(true);
        ASSERT_EQ(segment->_gc_delay_flag, 1);
        segment->SetGcDelayForRecovery(false);
        ASSERT_EQ(segment->_gc_delay_flag, 0);
    }
    {
        // get task 1
        RecoverBlockTask task;
        ASSERT_TRUE(segment->GetRecoveryNextBlockTask(&task));
        ASSERT_EQ(task.offset, 0);
        ASSERT_EQ(task.size, gaia_apply::FLAGS_univ_page_size);
        // get task 2
        RecoverBlockTask task2;
        ASSERT_TRUE(segment->GetRecoveryNextBlockTask(&task2));
        ASSERT_EQ(task2.offset, gaia_apply::FLAGS_univ_page_size);
        ASSERT_EQ(task2.size, gaia_apply::FLAGS_univ_page_size);
        // get task 3
        RecoverBlockTask task3;
        ASSERT_TRUE(segment->GetRecoveryNextBlockTask(&task3));
        ASSERT_EQ(task3.offset, gaia_apply::FLAGS_univ_page_size * 2);
        ASSERT_EQ(task3.size, gaia_apply::FLAGS_univ_page_size);

        RecoverBlockTask task4;
        ASSERT_FALSE(segment->GetRecoveryNextBlockTask(&task));

        //EXPECT_CALL(*_mock_db_engine, Sync(_)).WillOnce(Return(db::Status()));
        BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
        EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_, _)).WillOnce(Return(false));

        segment->FinishRecoveryBlockTask(task);
        ASSERT_NE(0, segment->_recovery_info.inflight_count);
        segment->FinishRecoveryBlockTask(task2);
        ASSERT_NE(0, segment->_recovery_info.inflight_count);
        segment->FinishRecoveryBlockTask(task3);
        ASSERT_EQ(0, segment->_recovery_info.inflight_count);
        ASSERT_EQ(gaiadb::RECOVERY_FINISH, segment->_recovery_status);
    } END_OF_CASE;
    {
        pspb::GetRecoverInfoResponse rsp;
        segment->GetRecoveryInfo(&rsp);

        pspb::MultiGetRecoverInfoResponse::Segment seg;
        segment->GetRecoveryInfo(&seg);

        pspb::ListRecoveryInfoResponse::Segment seg2;
        segment->GetRecoveryInfo(&seg2);
    } END_OF_CASE;
    {
        ASSERT_FALSE(segment->RecoveryStoped());
        segment->TurnOffRecovery();
        ASSERT_TRUE(segment->RecoveryStoped());
    }
    {
        segment->FinishRecovery();
        ASSERT_EQ(segment->_gc_delay_flag, 0);
    }
    {
        bool status;
        bool is_force;
        segment->GetRecoveryStatus(&status, &is_force);
        ASSERT_FALSE(status);
    }
    BMOCK_NS_STOP(std::filesystem, exists, bool(const std::filesystem::path&, std::error_code&));
}

TEST_F(SegmentTests, test_Recovery2) {
    auto segment = create_segment(gaia_apply::FLAGS_univ_page_size * 3);
    ASSERT_TRUE(segment->_recovery_info.stopped);
    bool retry = false;
    auto lock = segment->GetPageLock(0);
    auto lock2 = segment->GetPageLock(1);
    {
        ASSERT_FALSE(segment->AddGcPageInRecovery(lock, 0, 0, 100000, &retry));
    }
    segment->_recovery_info.stopped = false;
    {
        ASSERT_TRUE(segment->StartRecovery());
        ASSERT_TRUE(segment->StartRecovery());
    }
    {
        segment->_recovery_status = gaiadb::RECOVERY_FINISH;
        ASSERT_FALSE(segment->AddGcPageInRecovery(lock, 0, 0, 100000, &retry));
    }
    segment->_recovery_status = gaiadb::RECOVERY_IN;
    ASSERT_TRUE(segment->StartRecovery());
    {
        ASSERT_TRUE(segment->AddGcPageInRecovery(lock, 0, 0, 100000, &retry));
    }
    {
        gaia_apply::lsn_t page_min_lsn;
        gaia_apply::lsn_t min_lsn;
        bool ret = segment->CheckGcPageInRecovery(lock2, &page_min_lsn, &min_lsn);
        ASSERT_FALSE(ret);
        ASSERT_TRUE(segment->AddGcPageInRecovery(lock2, 1, 0, 100000, &retry));
        ret = segment->CheckGcPageInRecovery(lock2, &page_min_lsn, &min_lsn);
        ASSERT_TRUE(ret);

        ASSERT_FALSE(segment->DropGcPageInRecovery(lock2, 0));
        segment->AddGcDropSpaceInRecovery(1, 1000);

        segment->AddGcDropSpaceInRecovery(1, 200000);
        ret = segment->CheckGcPageInRecovery(lock2, &page_min_lsn, &min_lsn);
        ASSERT_FALSE(ret);

        ret = segment->CheckGcPageInRecovery(lock, &page_min_lsn, &min_lsn);
        ASSERT_TRUE(ret);

        ASSERT_TRUE(segment->DropGcPageInRecovery(lock2, 0));
    }
    {
        ASSERT_TRUE(segment->DropGcPageInRecovery(lock, 100000));
        ASSERT_FALSE(segment->AddGcPageInRecovery(lock, 0, 0, 100000, &retry));
        ASSERT_TRUE(retry);
    }
    {
        segment->FinishRecovery();
        segment->FinishRecovery();
    }
    {
        ASSERT_TRUE(segment->AddGcPageInRecovery(lock, 0, 0, 100000, &retry));
        segment->AddGcDropSpaceInRecovery(1, 100000);
    }
}

TEST_F(SegmentTests, test_Recovery3) {
    auto segment = create_segment(gaia_apply::FLAGS_univ_page_size * 3);
    segment->_db_engine = _segment->_db_engine;
    ASSERT_TRUE(segment->StartRecovery());
    segment->_recovery_info.stopped = false;
    segment->_recovery_status = gaiadb::RECOVERY_IN;
    segment->_recovery_info.pages_min_lsn[0].min_lsn = 0;

    segment->_recovery_info.pages_min_lsn[1].space_id = 1;
    segment->_recovery_info.pages_min_lsn[1].min_lsn = LOG_START_LSN + 2;

    EXPECT_CALL(*_mock_store_manager, GetStore(_))
        .WillRepeatedly(Return(g_mock_store));
    g_mock_store->_active = true;

    {
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kBusy)));
        ASSERT_FALSE(segment->CheckRecovery());
    }
    {
        auto fun1 = [this](const db::ReadOptions&, uint64_t, uint64_t, void* buf, db::ReadOutputs*) -> db::Status {
            page_set_page_lsn(static_cast<gaia_apply::page_t*>(buf), gaia_page_size().logical(), LOG_START_LSN + 1);
            return db::Status(db::Code::kOk);
        };
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Invoke(fun1));
        ASSERT_FALSE(segment->CheckRecovery());
    }
    {
        auto fun1 = [this](const db::ReadOptions&, uint64_t, uint64_t, void* buf, db::ReadOutputs*) -> db::Status {
            page_set_page_lsn(static_cast<gaia_apply::page_t*>(buf), gaia_page_size().logical(), LOG_START_LSN + 1);
            return db::Status(db::Code::kOk);
        };
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Invoke(fun1));
        segment->AddGcDropSpaceInRecovery(1, 10000);
        segment->_gc_lsn(10000 - 1);
        ASSERT_TRUE(segment->_recovery_info.drop_spaces.count(1) > 0);
        ASSERT_FALSE(segment->CheckRecovery());
    }
    {
        auto fun1 = [this](const db::ReadOptions&, uint64_t, uint64_t, void* buf, db::ReadOutputs*) -> db::Status {
            page_set_page_lsn(static_cast<gaia_apply::page_t*>(buf), gaia_page_size().logical(), LOG_START_LSN + 1);
            return db::Status(db::Code::kOk);
        };
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Invoke(fun1));
        segment->AddGcDropSpaceInRecovery(1, 10000);
        segment->_gc_lsn(10000);
        ASSERT_TRUE(segment->_recovery_info.drop_spaces.count(1) > 0);
        ASSERT_TRUE(segment->CheckRecovery());
    }

    segment->_recovery_info.pages_min_lsn[1].space_id = 2;

    segment->_recovery_info.pages_min_lsn[2].min_lsn = LOG_START_LSN + 3;
    {
        auto fun1 = [this](const db::ReadOptions&, uint64_t, uint64_t, void* buf, db::ReadOutputs*) -> db::Status {
            page_set_page_lsn(static_cast<gaia_apply::page_t*>(buf), gaia_page_size().logical(), LOG_START_LSN + 4);
            return db::Status(db::Code::kOk);
        };
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun1));
        ASSERT_TRUE(segment->CheckRecovery());
    }
}

TEST_F(SegmentTests, test_LogBlock) {
    LogBlock lb(1, 1024, 4096);
    {
        LogRecord log_record(gaia_apply::MLOG_FILE_DELETE, nullptr, 1,
                1024, 1026, 1, -1, true, 1024);
        lb.PushRecord(&log_record);
    }
    {
        LogRecord log_record(gaia_apply::MLOG_LSN, nullptr, 1,
                1024, 1026, 2, 1, true, 1024);
        lb.PushRecord(&log_record);
    }
    {
        LogRecord log_record(gaia_apply::MLOG_LSN, nullptr, 1,
                1024, 1026, 2, 2, true, 1024);
        lb.PushRecord(&log_record);
    }
    {
        LogRecord log_record(gaia_apply::MLOG_LSN, nullptr, 1,
                1028, 1036, 2, 1, true, 1024);
        lb.PushRecord(&log_record);
    }

    lb.PrepareGc();
    ASSERT_EQ(2, lb.parallel_size);

    {
        auto lb2 = create_log_block(1024, 1039, true, 2);
        ASSERT_TRUE(lb2->check_buf_crc());
        lb2->HexEncode();
        ASSERT_EQ(1039 - 1024, lb2->lsn_length());
    }
}

TEST_F(SegmentTests, test_IgnoreCorruptInfo) {
    IgnoreCorruptInfo ignore_corrupt_info;
    ASSERT_TRUE(ignore_corrupt_info.empty());

    ignore_corrupt_info.AddSpace(1);
    ASSERT_FALSE(ignore_corrupt_info.empty());

    ignore_corrupt_info.AddSpace(1);
    ignore_corrupt_info.AddSpace(2);


    ignore_corrupt_info.AddSegmentSpace(1, 3);
    ignore_corrupt_info.AddSegmentSpace(1, 2);

    ignore_corrupt_info.RemoveSegmentSpace(2, 1);

    ignore_corrupt_info.RemoveSegmentSpace(1, 2);
    ignore_corrupt_info.RemoveSegmentSpace(1, 3);
    ASSERT_FALSE(ignore_corrupt_info.empty());

    ignore_corrupt_info.RemoveSpace(1);
    ASSERT_FALSE(ignore_corrupt_info.empty());
    ignore_corrupt_info.RemoveSpace(2);
    ASSERT_TRUE(ignore_corrupt_info.empty());
}


}
}
