/*****************************************************************************
 @file include/bos0conductor.h
 *******************************************************/

#ifndef bos0conductor_h
#define bos0conductor_h

#include <bcesdk/bos/client.h>
#include <bcesdk/bos/sts_client.h>

#include <memory>
#include <string>

#include "sql/binlog.h"

namespace bos {

namespace bir_bos = baidu::bos::cppsdk;

void progress_callback(int64_t increment, int64_t transfered, 
                              int64_t total, void* user_data);
bool write_to_bos(const std::string &filename, const uint64_t size);
bool download_from_bos(const std::string &filename);
std::string normalize_filename(const std::string &filename);
std::string add_cluster_id(const std::string &filename);
class BosConductor {
public:
  BosConductor() {}
public:
  bool init(const std::string &ak, const std::string &sk, 
            const std::string &account_id, const std::string &endpoint, 
            const std::string &bucket, const bool current);
  bool init_use_sts(const std::string &ak, const std::string &sk, 
                    const std::string &account_id, const std::string &endpoint, 
                    const std::string &bucket, const bool current);
  std::vector<BosInfo> build();
  bir_bos::Client *get_client() {
    return bos_client_.get();
  }
  const BosInfo &bos_info() {
    return bos_info_;
  }

private:
  bir_bos::Credential bos_credential_;
  std::shared_ptr<bir_bos::StsClient> sts_client_;
  bir_bos::ClientOptions bos_config_;
  std::shared_ptr<bir_bos::Client> bos_client_;
  BosInfo bos_info_;
};
} // end bos
#endif
