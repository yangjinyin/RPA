/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/drop_standby_cluster.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class DropStandbyCluster : public Command {
public:
    DropStandbyCluster() {
        SetName("drop-standby-cluster");
        SetDesc("drop an existing standby cluster from manager");
        SetDescCn("从管理服务中删除从集群");

        AddPsmClusterOption();
        AddRequiredArgOption("standby-cluster-id", &_long_opt_val, kOptMax + 1, "the standby cluster id", kstring);
        
        AddExample("--manager-address \"bns://xxx\" --standby-cluster-id xxx");
    }
    virtual ~DropStandbyCluster() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _standby_cluster_id = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::DropStandbyClusterResponse& rsp);

private:
    std::string _manager_address {};
    std::string _standby_cluster_id {};
};

}
}
