/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file main.cpp
* @author
* @brief
*/

#include <gaiadb/utils/ut.h>
#include <gaiadb/utils/pid_lock.h>
#include "psvr/config.h"
#include "psvr/segment_server.h"
#include "psvr/version.h"

DEFINE_bool(h, false, "print help information");
DEFINE_bool(v, false, "print version information");
DEFINE_string(pid_file_path, "bin", "pid file path");
DEFINE_string(lock_file_path, "bin", "raft file path");

static const char *psvr_proc_name = nullptr;

int main(int argc, char *argv[]) {
    psvr_proc_name = strrchr(argv[0], '/');
    if (nullptr == psvr_proc_name) {
        psvr_proc_name = argv[0];
    } else {
        psvr_proc_name++;
    }

    {
        std::string help_str;
        base::string_printf(&help_str,
                "Usage: %s [OPTIONS...]\n"
                "Options:\n"
                "  -h              Print this help message.\n"
                "  -v              Print version number.\n"
                "  -flagfile=$path Load flags from file.",
                psvr_proc_name);
        google::SetUsageMessage(help_str);

        std::string psvr_version_str = psvr::get_version();
        google::SetVersionString(psvr_version_str);

        google::ParseCommandLineFlags(&argc, &argv, true);
        // show version and help message
        if (FLAGS_v) {
            fprintf(stderr, "%s\n", psvr_version_str.c_str());
            _exit(0);
        }
        if (FLAGS_h) {
            fprintf(stderr, "%s\n", help_str.c_str());
            _exit(0);
        }
    }

    gaiadb::common::ut_crc32_init();
    if (!psvr::init_logger()) {
        std::cerr << "failed to init log";
        return -1;
    }

    // lock and create pid file
    gaiadb::common::Files files;
    std::string lock_file = FLAGS_lock_file_path + "/" + std::string(psvr_proc_name) + ".lock";
    std::string pid_file = FLAGS_pid_file_path + "/" + std::string(psvr_proc_name) + ".pid";
    if (!gaiadb::common::server_check_and_lock(lock_file, pid_file, files)) {
        std::cout << "another " << psvr_proc_name << " already running"
            << std::endl;
        return -1;
    }
    LOG(NOTICE) << "pid file:" << files.pid_file->name()
        << " lock file:" << files.file_lock->name();

    if (psvr::FLAGS_psvr_is_multi_type) {
        psvr::MultiSegmentPtr multi(new psvr::MultiSegment());
        if (!multi->Start()) {
            LOG(ERROR) << "page server start failed (multi segments)";
            return -1;
        }
        pause();
    } else {
        psvr::OneSegmentPtr one(new psvr::OneSegment());
        if (!one->Start()) {
            LOG(ERROR) << "page server start failed (one segment)";
            return -1;
        }
        pause();
    }
    return 0;
}
