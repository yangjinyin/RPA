/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_page_server_recovery.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class UpdatePageServerRecovery : public Command {
public:
    UpdatePageServerRecovery() {
        SetName("update-ps-recovery");
        SetDesc("start recovery for segment replica on page server");
        SetDescCn("启动存储服务器上分片副本的恢复任务");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c',
                "update segments that matches the cluster id",
                kstring, kGroup2Scope);
        AddRequiredArgOption("segment-id", NULL, 's',
                "and match the segment id, if specified",
                kuint32_t, kGroup2Scope);
        AddRequiredArgOption("multi-segment", &_long_opt_val, kOptMax + 1,
                "in multi type. change segments you want",
                kjson, kGroup3Scope);
        AddRequiredArgOption("recover-enable", &_long_opt_val, kOptMax + 2,
                "start or stop segment recovery task", kbool);
        AddRequiredArgOption("recover-force", &_long_opt_val, kOptMax + 3,
                "set or unset recovery task type to force", kbool);

        AddExample("-a <ip> -p <port> -c gaia-test-perf -s 1 --recover-enable x");
        AddExample("-m -a <ip> -p <port> -c gaia-test-perf --recover-enable x");
        AddExample("-m -a <ip> -p <port> -c gaia-test-perf -s 1 --recover-enable x");
        AddExample("-m -a <ip> -p <port> --multi-segment json_data");
    }
    virtual ~UpdatePageServerRecovery() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtol(opt, NULL, 10));
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _segments = opt;
                break;
            case kOptMax + 2:
                _recover_enable.Set(!!std::strtol(opt, NULL, 10));
                break;
            case kOptMax + 3:
                _recover_force.Set(!!std::strtol(opt, NULL, 10));
                break;
            default:
                return 1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::SetRecoverInfoResponse& rsp);
    int Format(const pspb::MultiSetRecoverInfoResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
    std::string _segments {};
    VarOptional<bool> _recover_enable;
    VarOptional<bool> _recover_force;
};

}
}
