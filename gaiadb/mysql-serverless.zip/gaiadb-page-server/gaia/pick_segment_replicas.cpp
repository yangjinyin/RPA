/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/pick_segment_replicas.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <base/rand_util.h>
#include <base/string_printf.h>
#include "gaia/pick_segment_replicas.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

struct Store {
    std::string addr {};
    int32_t zone {0};
    int32_t store_id {-1};
    bool active {false};

    int32_t store_size {0};
    bool specify_store_size {0};
    int64_t free_size {0};
    int64_t capacity {0};
    int64_t used_capacity {0};
    int64_t free_capacity_rate {0};

    uint32_t segment_num {0};
    bool has_io_error {false};

    uint32_t in_recovery_replica_num {0};

    Store(const std::string& _addr, int32_t _zone,
            const pspb::MultiGetStatusResponse_Store& store)
            : addr(_addr), zone(_zone),
            store_id(store.store_id()),
            active(store.active()),
            store_size(store.store_size()),
            specify_store_size(store.specify_store_size()),
            free_size(store.free_size()),
            capacity(store.capacity()),
            used_capacity(store.used_capacity()),
            segment_num(0),
            has_io_error(store.io_error_count() > 0),
            in_recovery_replica_num(0) {
        if (capacity > 0 && capacity > used_capacity) {
            free_capacity_rate = (capacity - used_capacity) * 1.0 / capacity * 1000;
        } else if (capacity == 0) {
            free_capacity_rate = 1000;
        }
    }
};
using StorePtr = std::shared_ptr<Store>;

std::ostream& operator<<(std::ostream& os, const StorePtr& store) {
    return os << store->addr << ", zone:" << store->zone << ", store_id:" << store->store_id;
}

struct ServerPickFailReason {
    bool exists_replica_on_server {false};
    bool exists_replica_on_zone {false};
    std::vector<int32_t> stores_inactive;
    std::vector<int32_t> size_not_enough;
    std::vector<int32_t> capacity_not_enough;
    std::vector<int32_t> has_io_error;
};

void PickSegmentReplicas::Done(pspb::BatchMultiGetStatusResponse_ServerStatus* server_status,
        pspb::MultiGetStatusResponse* response, RpcStatus* status) {
    if (!status->IsOk()) {
        LOG(WARNING) << "rpc failed:" << status;
        response->mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response->mutable_status()->set_msg("rpc failed");
    }
    server_status->mutable_status()->CopyFrom(*response);
    _task_count.fetch_sub(1, std::memory_order_release);
    delete response;
    delete status;
}

int PickSegmentReplicas::Execute(const base::EndPoint& node,
        pspb::MultiGetStatusResponse* response, RpcStatus* status, ggpb::Closure* closure) {
    pspb::MultiGetStatusRequest request;
    request.set_log_id(_log_id);
    auto segment_pb = request.add_segments();
    segment_pb->set_cluster_id(_cluster_id);
    request.set_get_store_info(true);

    _client.Call(_log_id++, node, &pspb::QueryService_Stub::MultiGetServerStatus, &request, response,
            closure, status, _timeout_ms);
    return 0;
}

int PickSegmentReplicas::Run() {
    if (_cluster_addr.empty()) {
        print_error("miss --cluster-addr");
        return 1;
    }

    if (_cluster_id.empty()) {
        print_error("miss --cluster-id or -c");
        return 1;
    }

    if (_replica_num < 1) {
        print_error("miss --replica-num or -n");
        return 1;
    }

    if (_segment_id.has_val && _segment_id.val < 1) {
        print_error("error --segment-id or -s, %u", _segment_id.val);
        return 1;
    }

    if (_segment_size < 1) {
        print_error("error --size:%ld", _segment_size);
        return 1;
    }

    if (_zone && _replica_num > 1) {
        print_error("error --replica-num or -n if zone specified");
        return 1;
    }

    PsmInfo psm_info(_cluster_addr, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--cluster-addr parse failed, cant get server list from it");
        return 1;
    }

    _task_count.store(nodes.size());
    pspb::BatchMultiGetStatusResponse response;
    response.set_log_id(_log_id);
    for (auto& node : nodes) {
        auto server_status = response.add_server_status();
        server_status->set_addr(gaiadb::common::endpoint2str(node));
        pspb::MultiGetStatusResponse* rsp = new pspb::MultiGetStatusResponse;
        RpcStatus* status = new RpcStatus;
        auto closure = brpc::NewCallback(this, &PickSegmentReplicas::Done, server_status, rsp, status);
        int ret = Execute(node, rsp, status, closure);
        if (ret) {
            status->Reset(RpcCode::kInvalidArgs, "invalid");
            closure->Run();
        }
    }

    while (!_stopped) {
        if (_task_count.load(std::memory_order_acquire) == 0) {
            break;
        } else {
            gaiadb::common::pause();    // x86
        }
    }
    if (_stopped) {
        print_error("quit by signal");
        return 1;
    }

    std::vector<StorePtr> server_store_info;
    pspb::PickSegmentReplicaResponse pick_response;
    std::set<int32_t> peer_exists_zones;
    std::set<std::string> peer_exists_servers;
    for (int32_t i = 0; i < response.server_status_size(); ++i) {
        const auto& server_status = response.server_status(i);
        const auto& rsp = server_status.status();
        const auto& addr = server_status.addr();
        const int32_t zone = rsp.has_topology_zone() ? rsp.topology_zone() : 0;
        if (rsp.status().code() != pspb::Status_ReturnCode_SUCCESS) {
            auto error_error = pick_response.add_error_server();
            error_error->set_addr(addr);
            error_error->mutable_status()->CopyFrom(rsp.status());
            continue;
        }

        if (rsp.has_topology_to_offline() && rsp.topology_to_offline()) {
            auto error_error = pick_response.add_error_server();
            error_error->set_addr(addr);
            error_error->mutable_status()->set_code(pspb::Status_ReturnCode_INVALID);
            error_error->mutable_status()->set_msg("server topology to offine");
            continue;
        }

        if (_zone > 0 && zone != _zone) {
            auto error_error = pick_response.add_error_server();
            error_error->set_addr(addr);
            error_error->mutable_status()->set_code(pspb::Status_ReturnCode_INVALID);
            error_error->mutable_status()->set_msg("mismatch zone");
            continue;
        }

        std::map<int32_t, StorePtr> stores;
        for (int32_t j = 0; j < rsp.stores_size(); ++j) {
            const auto& store_pb = rsp.stores(j);
            StorePtr store(new Store(addr, zone, store_pb));
            server_store_info.emplace_back(store);
            stores.emplace(std::make_pair(store->store_id, store));
        }

        bool exists_replica_on_server = false;
        for (int32_t j = 0; j < rsp.segments_size(); ++j) {
            const auto& seg_pb = rsp.segments(j);
            if (seg_pb.status().code() == pspb::Status_ReturnCode_SUCCESS) {
                auto& store = stores[seg_pb.store_id()];

                ++store->segment_num;
                if (seg_pb.in_recovery()) {
                    ++store->in_recovery_replica_num;
                }
            }
            if (_segment_id.has_val && !exists_replica_on_server) {
                if (seg_pb.segment_id() == _segment_id.val) {
                    exists_replica_on_server = true;
                }
            }
        }

        if (_segment_id.has_val && exists_replica_on_server) {
            peer_exists_servers.emplace(addr);
            if (zone > 0) {
                peer_exists_zones.emplace(zone);
            }
        }
    } // end of loop servers

    auto sort_func = [this](StorePtr a, StorePtr b) {
        if (_segment_id.has_val && _limit_recovery_num > 0) {
            int trigger_limit_a = a->in_recovery_replica_num > _limit_recovery_num ? 1: 0;
            int trigger_limit_b = b->in_recovery_replica_num > _limit_recovery_num ? 1: 0;
            if (trigger_limit_a != trigger_limit_b) {
                return trigger_limit_a < trigger_limit_b;
            }
        }

        if (a->segment_num != b->segment_num) {
            return a->segment_num < b->segment_num;
        } else if (a->free_capacity_rate != b->free_capacity_rate) {
            return a->free_capacity_rate > b->free_capacity_rate;
        } else {
            return a->free_size > b->free_size;
        }
    };
    std::sort(server_store_info.begin(), server_store_info.end(), sort_func);

    if (_debug) {
        LOG(NOTICE) << "--print sort store info start";
        for (auto& zone : peer_exists_zones) {
            LOG(NOTICE) << "replica zone exists on:" << zone;
        }
        for (auto& server : peer_exists_servers) {
            LOG(NOTICE) << "replica node exists on:" << server;
        }
        for (auto& store : server_store_info) {
            LOG(NOTICE) << store->addr << ":" << store->store_id << " active:" << store->active
                << " zone:" << store->zone
                << " segment_num:" << store->segment_num
                << " in_recovery_replica_num:" << store->in_recovery_replica_num
                << " has_io_error:" << store->has_io_error
                << " free_size:" << store->free_size
                << " store_size:" << store->store_size
                << " capacity:" << store->capacity
                << " used_capacity:" << store->used_capacity
                << " free_capacity_rate:" << store->free_capacity_rate;
        }
        LOG(NOTICE) << "--print sort store info end";
    }

    std::vector<StorePtr> candidates;
    size_t candidate_size = 0;
    std::map<std::string, ServerPickFailReason> server_pick_fail_reason;

    for (auto& store : server_store_info) {
        if (!store->active) {
            server_pick_fail_reason[store->addr].stores_inactive.emplace_back(store->store_id);
            continue;
        }
        {
            auto it = peer_exists_servers.find(store->addr);
            if (it != peer_exists_servers.end()) {
                server_pick_fail_reason[store->addr].exists_replica_on_server = 1;
                continue;
            }
        }
        if (store->free_size < _segment_size) {
            server_pick_fail_reason[store->addr].size_not_enough.emplace_back(store->store_id);
            continue;
        }
        if (store->capacity > -1 && store->capacity <= store->used_capacity) {
            server_pick_fail_reason[store->addr].capacity_not_enough.emplace_back(store->store_id);
            continue;
        }
        if (store->zone > 0) {
            auto it = peer_exists_zones.find(store->zone);
            if (it != peer_exists_zones.end()) {
                server_pick_fail_reason[store->addr].exists_replica_on_zone = 1;
                continue;
            }
        }
        if (!_pick_error_store && store->has_io_error) {
            server_pick_fail_reason[store->addr].has_io_error.emplace_back(store->store_id);
            continue;
        }

        candidates.emplace_back(store);
        ++candidate_size;
    }

    for (auto& it : server_pick_fail_reason) {
        auto& reason = it.second;
        auto error_error = pick_response.add_error_server();
        error_error->set_addr(it.first);
        error_error->mutable_status()->set_code(pspb::Status_ReturnCode_INVALID);
        if (reason.exists_replica_on_server) {
            error_error->mutable_status()->set_msg("exists replica on server");
        } else if (reason.exists_replica_on_zone) {
            error_error->mutable_status()->set_msg("exists zone on server");
        } else if (!reason.stores_inactive.empty()) {
            error_error->mutable_status()->set_msg("inactive store:" + JoinVec(reason.stores_inactive, ",%d"));
        } else if (!reason.size_not_enough.empty()) {
            error_error->mutable_status()->set_msg("store size not enough:" + JoinVec(reason.size_not_enough, ",%d"));
        } else if (!reason.capacity_not_enough.empty()) {
            error_error->mutable_status()->set_msg("store capacity not enough:" + JoinVec(reason.capacity_not_enough, ",%d"));
        } else if (!reason.has_io_error.empty()) {
            error_error->mutable_status()->set_msg("store io error:" + JoinVec(reason.has_io_error, ",%d"));
        }
    }

    // compute candidates' unique servers and unique zones(>0) for diagnostics
    std::set<std::string> candidate_servers;
    std::set<int32_t> candidate_zones;
    bool has_zoneless_candidate = false;
    for (auto& s : candidates) {
        candidate_servers.emplace(s->addr);
        if (s->zone > 0) {
            candidate_zones.emplace(s->zone);
        } else {
            has_zoneless_candidate = true;
        }
    }

    if (candidate_size < _replica_num) {
        pick_response.mutable_status()->set_code(pspb::Status_ReturnCode_ERROR);
        pick_response.mutable_status()->set_msg(base::string_printf(
                "pick failed, candidate size %zu is less than expected replica_num %u"
                " (unique_servers:%zu, unique_zones:%zu, peer_exists_servers:%zu,"
                " peer_exists_zones:%zu)",
                candidate_size, _replica_num,
                candidate_servers.size(), candidate_zones.size(),
                peer_exists_servers.size(), peer_exists_zones.size()));
        return Output(pick_response);
    }

    uint32_t pick_succ_num = 0;
    const size_t pre_pick_peer_servers = peer_exists_servers.size();
    const size_t pre_pick_peer_zones = peer_exists_zones.size();
    const uint32_t idx = base::RandInt(0, candidate_size) % candidate_size;
    for (uint32_t i = idx; i < candidate_size && pick_succ_num < _replica_num; ++i) {
        auto& best = candidates[i];
        if (best->zone > 0 && peer_exists_zones.count(best->zone) > 0) {
            LOG_IF(NOTICE, _debug) << "zone invalid, " << best;
            continue;
        }
        if (peer_exists_servers.count(best->addr) > 0) {
            LOG_IF(NOTICE, _debug) << "peer invalid, " << best;
            continue;
        }

        peer_exists_zones.emplace(best->zone);
        peer_exists_servers.emplace(best->addr);

        auto replica_pb = pick_response.add_replicas();
        replica_pb->set_addr(best->addr);
        replica_pb->set_store_id(best->store_id);
        ++pick_succ_num;
    }
    for (uint32_t i = 0; i < idx && pick_succ_num < _replica_num; ++i) {
        auto& best = candidates[i];
        if (best->zone > 0 && peer_exists_zones.count(best->zone) > 0) {
            LOG_IF(NOTICE, _debug) << "zone invalid, " << best;
            continue;
        }
        if (peer_exists_servers.count(best->addr) > 0) {
            LOG_IF(NOTICE, _debug) << "peer invalid, " << best;
            continue;
        }

        peer_exists_zones.emplace(best->zone);
        peer_exists_servers.emplace(best->addr);

        auto replica_pb = pick_response.add_replicas();
        replica_pb->set_addr(best->addr);
        replica_pb->set_store_id(best->store_id);
        ++pick_succ_num;
    }

    if (static_cast<uint32_t>(pick_response.replicas_size()) == _replica_num
            || (pick_response.replicas_size() > 0 && _segment_id.has_val)) {
        pick_response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
        pick_response.mutable_status()->set_msg("ok");
    } else {
        pick_response.mutable_status()->set_code(pspb::Status_ReturnCode_ERROR);
        pick_response.mutable_status()->set_msg(base::string_printf(
                "pick failed, picked %d, expected %u, candidates:%zu"
                " (unique_servers:%zu, unique_zones:%zu, zoneless:%d,"
                " peer_exists_servers:%zu, peer_exists_zones:%zu);"
                " candidates may concentrate on same server/zone with existing replicas",
                pick_response.replicas_size(), _replica_num, candidate_size,
                candidate_servers.size(), candidate_zones.size(),
                has_zoneless_candidate ? 1 : 0,
                pre_pick_peer_servers, pre_pick_peer_zones));
    }

    return Output(pick_response);
}

int PickSegmentReplicas::Format(const pspb::PickSegmentReplicaResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.replicas_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({"server", "store_id"}, true);
        for (const auto& replica : rsp.replicas()) {
            table.AddRowsValue({replica.addr(), replica.store_id()});
        }
        table.Display();
    }
    if (rsp.error_server_size()) {
        Table table2(_raw_with_table, 0);
        table2.AddRowsWithName({"server", "code(reason)"}, true);
        for (const auto& err_s : rsp.error_server()) {
            table2.AddRowsValue({
                        err_s.addr(),
                        RowStr(pspb::Status_ReturnCode_Name(err_s.status().code()), err_s.status().msg())
                    });
        }
        table2.Display();
    }
    return 0;
}

}
}
