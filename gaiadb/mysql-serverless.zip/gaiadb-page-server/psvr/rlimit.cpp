/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/rlimit.h
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/rlimit.h"

namespace psvr {

int set_memory_limit(rlim_t rlim_cur, rlim_t rlim_max) {
    struct rlimit cfg;
    int rc = getrlimit(RLIMIT_AS, &cfg);
    if (rc) {
        return -1;
    }
    if (rlim_cur > 0 && rlim_max > 0 && rlim_cur > rlim_max) {
        rlim_cur = rlim_max;
    }
    if (rlim_cur > 0 && rlim_cur > cfg.rlim_cur) {
        return 1;
    }
    if (rlim_max > 0 && rlim_max > cfg.rlim_max) {
        return 2;
    }
    if (rlim_cur > 0) {
        cfg.rlim_cur = rlim_cur;
    }
    if (rlim_max > 0) {
        cfg.rlim_max = rlim_max;
    }
    return setrlimit(RLIMIT_AS, &cfg);
}

}
