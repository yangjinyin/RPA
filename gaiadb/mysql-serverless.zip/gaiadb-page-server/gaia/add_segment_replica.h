/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/add_segment_replica.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class AddSegmentReplica : public Command {
public:
    AddSegmentReplica() {
        SetName("add-segment-replica");
        SetDesc("add a new replica to an existing segment");
        SetDescCn("为已有分片添加新副本");
        
        AddPsmClusterOption();
        AddRequiredArgOption("segment-id", NULL, 's', "the segment to add a replica to", kuint32_t);
        AddRequiredArgOption("replica-id", &_long_opt_val, kOptMax + 2, "the new replica id", kuint32_t);
        AddRequiredArgOption("replica-addr", &_long_opt_val, kOptMax + 3,
                "the new replica endpoint information", kip_port);
        AddZoneOption();

        AddExample("--manager-address \"bns://xxx\" --segment-id xx --replica-id 2 --replica-addr xxx:11");
        AddExample("--manager-address \"bns://xxx\" --segment-id xx"
                " --replica-id 2 --replica-addr xxx:11"
                " --region a --available-zone xxx");
    }
    virtual ~AddSegmentReplica() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 's':
            _segment_id = std::strtoul(opt, NULL, 10);
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptRegion:
                _zone.region = opt;
                break;
            case kOptAvailableZone:
                _zone.available_zone = opt;
                break;
            case kOptMax + 2:
                _replica_id.Set(std::strtoul(opt, NULL, 10));
                break;
            case kOptMax + 3:
                _replica_addr = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::AckResponse& rsp);

private:
    std::string _manager_address {};
    uint32_t _segment_id {0};
    VarOptional<uint32_t> _replica_id;
    std::string _replica_addr {};
    VarZone _zone;
};

}
}
