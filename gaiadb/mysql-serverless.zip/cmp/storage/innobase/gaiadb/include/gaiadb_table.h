/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/include/table.h
 The interface for table related

 Created 12/16/2022 Shenghu Zhu
 *******************************************************/
#ifndef gaiadb_table_h
#define gaiadb_table_h

#include <string>

[[nodiscard]] std::string fil_convert_filename_to_tablename(const std::string& tablespace_name);

[[nodiscard]] std::size_t fil_convert_filename_to_tablename(const char* tablespace_name, char* name_after_converting);

 #endif /* gaiadb_table_h */
