#!/bin/bash

set -e

CHECK_WORK=1

# Get the script directory
PROJECT_DIR=$(cd "$(dirname "$0")" && pwd)

if [ ! -f "$PROJECT_DIR/bin/page_server" ]; then
    echo "not found $PROJECT_DIR/bin/page_server"
    exit 1
fi

if [ $CHECK_WORK -eq 1 ]; then
    if [ "`whoami`" != "work" ]; then
        echo "Need work account to execute, current is "`whoami`
        exit 1;
    fi
fi

mkdir -p "$PROJECT_DIR/upgrade"

source_addr=$1
backup_name=$2

if [ -z $source_addr ]; then
    echo "sh $0 <ip:port> [<backup_name>]"
    echo "will download page server upgrade file from it"
    exit 1
fi

function backup() {
    src=$1
    cp "$PROJECT_DIR/$src" "$PROJECT_DIR/upgrade/$backup_name/"
}

if [ ! -z $backup_name ]; then
    echo "=== Creating backup: $backup_name ==="
    mkdir -p "$PROJECT_DIR/upgrade/$backup_name"
    backup bin/page_server
    backup bin/gaia
    backup load.sh
    echo "Backup completed"
fi

function download() {
    src=$1
    dst=$2
    echo "Downloading: $src"
    wget -q -O "$dst.tmp" "$source_addr/output/$src"
    if [ ! -s "$dst.tmp" ]; then
        echo "Download failed: $src"
        rm -f "$dst.tmp"
        exit 1
    fi
    mv "$dst.tmp" "$dst"
}

function load_supports_not_check() {
    # The new load.sh only accepts "--not_check" as its 2nd argument, while the
    # old one takes 0/1. Probe with an invalid command so that no real
    # start/stop is triggered: the new script rejects the "1" argument and
    # exits non-zero, while the old one falls through to its usage branch.
    ! sh "$1" __probe__ 1 >/dev/null 2>&1
}

function check_work_arg() {
    if load_supports_not_check "$1"; then
        echo "--not_check"
    else
        echo "$CHECK_WORK"
    fi
}

echo ""
echo "=== Downloading upgrade files from $source_addr ==="


download  bin/page_server "$PROJECT_DIR/upgrade/page_server"
download  bin/gaia "$PROJECT_DIR/upgrade/gaia"
download  load.sh "$PROJECT_DIR/upgrade/load.sh"

chmod +x "$PROJECT_DIR/upgrade/page_server"
chmod +x "$PROJECT_DIR/upgrade/gaia"
chmod +x "$PROJECT_DIR/upgrade/load.sh"

echo "Download completed"

echo ""
echo "=== Updating gaia ==="
mv "$PROJECT_DIR/upgrade/gaia" "$PROJECT_DIR/bin/gaia"

# use old script to stop server
echo ""
echo "=== Stopping service ==="
sh "$PROJECT_DIR/load.sh" stop "$(check_work_arg "$PROJECT_DIR/load.sh")"

echo ""
echo "=== Updating page_server ==="
mv "$PROJECT_DIR/upgrade/page_server" "$PROJECT_DIR/bin/page_server"

# use new script to start server
echo ""
echo "=== Updating load.sh ==="
mv "$PROJECT_DIR/upgrade/load.sh" "$PROJECT_DIR/load.sh"

echo ""
echo "=== Starting service ==="
sh "$PROJECT_DIR/load.sh" start "$(check_work_arg "$PROJECT_DIR/load.sh")"

echo ""
echo "=== Upgrade completed ==="


