/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_fetch.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/fetch_context.h"
#include "test/mock_thread_pool.h"
#include "test/mock_rpc_client.h"
#include "test/mock_quota.h"
#include "test/mock_dbengine.h"
#include "bmock.h"

namespace psvr {
namespace test {

class FetcherTests : public PsvrTest {
 public:
    FetcherTests() : _fetcher(nullptr) {
        _mock_control->fetcher()->Stop();
        FLAGS_psvr_dblwr_max_page_num = 0;
    }

    virtual ~FetcherTests() {
    }

    void SetUp() {
        _fetcher.reset(new Fetcher(_mock_client, _control));
        _mock_thread_pool = new MockExecutor<Fetcher::Context, thread::TaskContext>;
        _fetcher->_thread_pool.reset(_mock_thread_pool);
        _fetcher->_append_recover_thread_pool = _fetcher->_thread_pool;

        // The mock objects created by BMOCK_NS_METHOD attach their hooks at static-init
        // time, so they would stay in effect for the whole binary. Stop them all here and
        // let each test enable only the ones it injects with BMOCK_NS_RESUME.
        BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
    }

    void TearDown() {
    }

    bool MockExecuteDo(Fetcher::Context* ctx) {
        _fetcher->OnCompletion(ctx);
        return true;
    }

private:
    FetcherPtr _fetcher;
    MockExecutor<Fetcher::Context, thread::TaskContext>* _mock_thread_pool;
};

bool MockExecuteOk(Fetcher::Context* ctx) {
    delete ctx;
    return true;
}

// Same as MockExecuteOk but keeps ctx alive so the caller can release it, used by
// the cases that assert the ctx advanced to kFetchRedoLog via the cache fallback.
bool MockExecuteOkCheckRedoLog(Fetcher::Context* ctx) {
    EXPECT_EQ(static_cast<uint32_t>(ctx->action),
            static_cast<uint32_t>(Fetcher::Action::kFetchRedoLog));
    return true;
}

bool MockScheduleOk(thread::TaskContext* ctx, uint64_t) {
    delete ctx;
    return true;
}

TEST_F(FetcherTests, test_Start_Stop) {

    { // not stores
        ASSERT_FALSE(_fetcher->Start(0));
    }

    { // start failed
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, FLAGS_multi_psvr_fetcher_thread_enable_shared, _)).WillOnce(Return(false));
        ASSERT_FALSE(_fetcher->Start(1));
    } END_OF_CASE;

    { // start failed
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, FLAGS_multi_psvr_fetcher_thread_enable_shared, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, true, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillOnce(Return());
        ASSERT_FALSE(_fetcher->Start(1));
    } END_OF_CASE;

    { // start ok
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, FLAGS_multi_psvr_fetcher_thread_enable_shared, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, true, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Stop(_))
            .WillOnce(Return())
            .WillOnce(Return());
        ASSERT_TRUE(_fetcher->Start(1));
    } END_OF_CASE;
    {
        // start fail
        _fetcher->_control.reset();
        ASSERT_FALSE(_fetcher->Start(1));
    }

    _fetcher->Stop();
}

// Recovery work (local append recover, and the peer redo-rec fetch/dispose) runs on
// the dedicated append-recover pool, the steady-state fetch stays on the fetch pool.
TEST_F(FetcherTests, test_GetThreadPool_by_action) {
    auto recover_pool = std::make_shared<MockExecutor<Fetcher::Context, thread::TaskContext>>();
    _fetcher->_append_recover_thread_pool = recover_pool;

    auto segment = create_segment();
    const Fetcher::Action recovery_actions[] = {
        Fetcher::Action::kAppendRecover,
        Fetcher::Action::kGetRedoRecLog,
        Fetcher::Action::kDisposeRedoRecLog,
    };
    for (auto action : recovery_actions) {
        Fetcher::Context* ctx = new Fetcher::Context(action, segment);
        ASSERT_EQ(_fetcher->GetThreadPool(ctx).get(), recover_pool.get());
        delete ctx;
    }

    const Fetcher::Action fetch_actions[] = {
        Fetcher::Action::kFetchRedoLog,
        Fetcher::Action::kGetLogService,
    };
    for (auto action : fetch_actions) {
        Fetcher::Context* ctx = new Fetcher::Context(action, segment);
        ASSERT_EQ(_fetcher->GetThreadPool(ctx).get(), _fetcher->_thread_pool.get());
        delete ctx;
    }
    END_OF_CASE;
}

TEST_F(FetcherTests, test_IncOrDecThreadNum) {
    _fetcher->_store_count = 2;
    _fetcher->_thread_num = FLAGS_multi_psvr_fetcher_thread_num_per_store * _fetcher->_store_count;
    _fetcher->_thread_num = FLAGS_multi_psvr_append_recover_thread_num_pre_store * _fetcher->_store_count;
    {
        _fetcher->IncOrDecThreadNum();
    }
    {
        // inc
        std::vector<MockExecutor<Fetcher::Context, thread::TaskContext>::ThreadType> vec;
        FLAGS_multi_psvr_fetcher_thread_num_per_store = FLAGS_multi_psvr_fetcher_thread_num_per_store + 1;
        FLAGS_multi_psvr_append_recover_thread_num_pre_store = FLAGS_multi_psvr_append_recover_thread_num_pre_store - 1;
        EXPECT_CALL(*_mock_thread_pool, IncThread(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, DecThread(_)).WillOnce(Return(vec));
        _fetcher->_stopped = true;
        _fetcher->IncOrDecThreadNum();
        _fetcher->_stopped = false;
        _fetcher->IncOrDecThreadNum();
    }
    {
        // dec
        std::vector<MockExecutor<Fetcher::Context, thread::TaskContext>::ThreadType> vec;
        FLAGS_multi_psvr_fetcher_thread_num_per_store = FLAGS_multi_psvr_fetcher_thread_num_per_store - 1;
        FLAGS_multi_psvr_append_recover_thread_num_pre_store = FLAGS_multi_psvr_append_recover_thread_num_pre_store + 1;
        EXPECT_CALL(*_mock_thread_pool, IncThread(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, DecThread(_)).WillOnce(Return(vec));
        _fetcher->IncOrDecThreadNum();
    }
    _fetcher->_stopped = true;
}

TEST_F(FetcherTests, test_Start_Stop_for_batch) {
    { // start ok
        FLAGS_psvr_fetch_batch_type = 1;
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, FLAGS_multi_psvr_fetcher_thread_enable_shared, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, true, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillOnce(Return()).WillOnce(Return());
        ASSERT_TRUE(_fetcher->Start(1));
        _fetcher->Stop();
        FLAGS_psvr_fetch_batch_type = 0;
    }
}

BMOCK_NS_METHOD1(gaiadb::common, terminate, void(int));
TEST_F(FetcherTests, Dispatch_Schedule) {
    _fetcher->_stopped = true;
    { // fetcher stoped
        SegmentPtr segment = create_segment();
        _fetcher->Dispatch(segment TRACE_FILE_LINE_CC);
    }

    { // stop
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        _fetcher->Schedule(ctx TRACE_FILE_LINE_CC, 0, false);
    }

    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    { // ok
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        SegmentPtr segment = create_segment();
        _fetcher->Dispatch(segment TRACE_FILE_LINE_CC);
    }
    {
        // append
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        SegmentPtr segment = create_segment();
        segment->_fetch_lsn.set(999);
        segment->_start_lsn = 10000;
        _fetcher->Dispatch(segment TRACE_FILE_LINE_CC);
    }

    { // ok with batch
        SegmentPtr segment = create_segment();
        segment->cluster()->_use_batch_fetch.store(1);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->Dispatch(segment TRACE_FILE_LINE_CC);
        segment->cluster()->_use_batch_fetch.store(0);
    }

    { // dblwr dump triggered when append file and dblwr enabled
        FLAGS_psvr_dblwr_max_page_num = 128;
        SegmentPtr segment = create_segment();
        EXPECT_CALL(*_mock_gc_manager, DumpDblwrBuf(_));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->Dispatch(segment TRACE_FILE_LINE_CC);
        FLAGS_psvr_dblwr_max_page_num = 0;
    }

    { // ok
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->Schedule(ctx TRACE_FILE_LINE_CC, 0, false);
    }

    { // ok
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->Schedule(ctx TRACE_FILE_LINE_CC, 1000, true);
    }

    {
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Invoke(MockExecuteOk));
        ASSERT_TRUE(_fetcher->Execute(ctx));
    }
    {
        _fetcher->_stopped = true;
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Return(false));
        ASSERT_FALSE(_fetcher->Execute(ctx));
    }
    {
        _fetcher->_stopped = false;
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Return(false));
        BMOCK_NS_RESUME(gaiadb::common, terminate, void(int));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaiadb::common, terminate), terminate(_)).WillOnce(Return());
        ASSERT_FALSE(_fetcher->Execute(ctx));
        BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
    }
}

TEST_F(FetcherTests, test_Wakeup) {
    {
        // no ctx
        auto segment = create_segment();
        _fetcher->Wakeup(segment);
    }
    {
        // has ctx
        auto segment = create_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        segment->set_fetch_ctx(ctx);
        EXPECT_CALL(*_mock_thread_pool, Cancel(_)).WillOnce(Return(false));
        _fetcher->Wakeup(segment);
    }
    {
        // has ctx
        auto segment = create_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        segment->set_fetch_ctx(ctx);
        EXPECT_CALL(*_mock_thread_pool, Cancel(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->Wakeup(segment);
        // wake up agian
        _fetcher->Wakeup(segment);
    }
}

TEST_F(FetcherTests, test_OnCompletion) {
    {
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        segment->_status = Segment::Status::kDelete;
        _fetcher->OnCompletion(ctx);
    }
    {
        _fetcher->_stopped = true;
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        _fetcher->OnCompletion(ctx);
    }
}

TEST_F(FetcherTests, test_GetLogService) {
    {
        // is stopped
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        auto rpc_ctx = new ClientContext<gaiapb::LogServiceBatchGetRequest, gaiapb::LogServiceBatchGetResponse>;
        _fetcher->_stopped = true;
        _fetcher->OnGetLogService(ctx, rpc_ctx);
    }

    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());
    std::vector<gaiadb::common::PeerZone> new_nodes;
    FillServers(&new_nodes, 3);
    {
        // get cache ok
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(DoAll(
                    SetArgPointee<0>(new_nodes),
                    SetArgPointee<1>(1),
                    Return(true)));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // get cache fail 1
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(DoAll(
                    SetArgPointee<0>(new_nodes),
                    SetArgPointee<1>(1),
                    Return(false)));
        EXPECT_CALL(*_mock_log_services, GetRefreshLock(_)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOkCheckRedoLog));
        _fetcher->OnCompletion(ctx);
        delete ctx;
    } END_OF_CASE;
    {
        // get cache fail 2
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(DoAll(
                    SetArgPointee<1>(1),
                    Return(true)));
        EXPECT_CALL(*_mock_log_services, GetRefreshLock(_)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // get cache fail 3
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        ctx->log_service_nodes_version = 1;
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(DoAll(
                    SetArgPointee<0>(new_nodes),
                    SetArgPointee<1>(ctx->log_service_nodes_version),
                    Return(true)));
        EXPECT_CALL(*_mock_log_services, GetRefreshLock(_)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOkCheckRedoLog));
        _fetcher->OnCompletion(ctx);
        delete ctx;
    } END_OF_CASE;

    {
        // GetOrRefreshNodes fail
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_log_services, GetRefreshLock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {  // rpc fail 5 times, and ok
        auto fun1 = [this](ClientContext<gaiapb::LogServiceBatchGetRequest, gaiapb::LogServiceBatchGetResponse>* rpc_ctx,
                ggpb::Closure* closure) {
            ASSERT_EQ(rpc_ctx->servers.size(), 6);
            if (rpc_ctx->idx < 2) {
                rpc_ctx->status.Reset(RpcCode::kCntlFailed, "mock failed");
            } else {
                rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
                rpc_ctx->response.mutable_status()->set_code(1);
            }
            closure->Run();
        };
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_log_services, GetRefreshLock(_)).WillOnce(Return(true));

        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));
        EXPECT_CALL(*_mock_client, ListLogService(_, _))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &FetcherTests::MockExecuteDo))
            .WillOnce(Invoke(this, &FetcherTests::MockExecuteDo))
            .WillOnce(Invoke(this, &FetcherTests::MockExecuteDo))
            .WillOnce(Invoke(this, &FetcherTests::MockExecuteDo))
            .WillOnce(Invoke(this, &FetcherTests::MockExecuteDo))
            .WillOnce(Invoke(this, &FetcherTests::MockExecuteDo));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    { // not zone
        auto fun1 = [this](ClientContext<gaiapb::LogServiceBatchGetRequest, gaiapb::LogServiceBatchGetResponse>* rpc_ctx,
                ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
            rpc_ctx->response.mutable_status()->set_code(0);
            for (uint32_t i = 0; i < 3; ++i) {
                auto log_services = rpc_ctx->response.add_log_services();
                log_services->set_addr(base::string_printf("127.0.0.1:%d", i));
                log_services->set_state(gaiadb::NODE_ACTIVE);
                log_services->mutable_zone()->set_region("test");
                log_services->mutable_zone()->set_available_zone(base::string_printf("b%d", i));
            }
            closure->Run();
        };
        auto segment = create_segment();
        _mock_control->_dbd_zone->Clear();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_log_services, GetRefreshLock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        EXPECT_CALL(*_mock_client, ListLogService(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &FetcherTests::MockExecuteDo))
            .WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    }
    {
        // with zone
        auto fun1 = [this](ClientContext<gaiapb::LogServiceBatchGetRequest, gaiapb::LogServiceBatchGetResponse>* rpc_ctx,
                ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
            rpc_ctx->response.mutable_status()->set_code(0);
            for (uint32_t i = 0; i < 3; ++i) {
                auto log_services = rpc_ctx->response.add_log_services();
                log_services->set_addr(base::string_printf("127.0.0.1:%d", i));
                log_services->set_state(gaiadb::NODE_ACTIVE);
                log_services->mutable_zone()->set_region("test");
                log_services->mutable_zone()->set_available_zone(base::string_printf("b%d", i));
            }
            closure->Run();
        };
        auto segment = create_segment();
        _mock_control->_dbd_zone->Set("test", "b2");
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetLogService, segment);
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_log_services, GetRefreshLock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));
        EXPECT_CALL(*_mock_client, ListLogService(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &FetcherTests::MockExecuteDo))
            .WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    }
}

TEST_F(FetcherTests, test_FetchLogBlock_StartFetchRedoLog) {
    {
        // is stopped
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        _fetcher->_stopped = true;
        _fetcher->DisposeLogBlock(ctx);
    }
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());
    {
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnFetchLogBlock(ctx);
    }
    {
        // last dbd zone mismatch
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->last_zone_version = 1;
        ctx->log_id = get_log_id();
        for (int32_t i = 0; i < 3; ++i) {
            ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        }
        ctx->get_log_ctx.idx = ctx->get_log_ctx.servers.size();
        _mock_control->_dbd_zone->_version = 2;
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // miss ls replica
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->last_zone_version = _mock_control->_dbd_zone->_version;
        ctx->log_id = get_log_id();
        for (int32_t i = 0; i < 2; ++i) {
            ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        }
        auto fun1 = [this](RpcGetLogCtx* rpc_ctx, ggpb::Closure* done){
            LOG(NOTICE) << "mock rpc closure";
            rpc_ctx->status.Reset(RpcCode::kInvalidArgs, "idx over size");
            if (done) {
                done->Run();
            }
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        EXPECT_CALL(*_mock_client, GetLog(_, _)).WillOnce(Invoke(fun1));
        _fetcher->OnCompletion(ctx);
    }

    {
        // fetch_fail_count
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->last_zone_version = _mock_control->_dbd_zone->_version;
        for (int32_t i = 0; i < 3; ++i) {
            ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        }
        ctx->abnormal_fetch_begin_time = base::cpuwide_time_us() - FLAGS_psvr_fetch_abnormal_max_time_us - 1;
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    }

    {
        // enable server push
        auto fun1 = [this](RpcGetLogCtx* rpc_ctx, ggpb::Closure* done){
            LOG(NOTICE) << "mock rpc closure";
            // server push path: verify extra 2s is added to timeout
            EXPECT_EQ(rpc_ctx->timeout_ms, FLAGS_psvr_fetch_server_push_timeout_ms + 2000);
            rpc_ctx->status.Reset(RpcCode::kInvalidArgs, "idx over size");
            if (done) {
                done->Run();
            }
        };
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->last_zone_version = _mock_control->_dbd_zone->_version;
        for (int32_t i = 0; i < 3; ++i) {
            ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        }
        ctx->enable_server_push = true;
        FLAGS_psvr_fetch_enable_server_push = true;
        ctx->continuous_empty_fetch_count = ctx->get_log_ctx.servers.size();

        EXPECT_CALL(*_mock_client, GetLog(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _fetcher->OnCompletion(ctx);
    }

    {
        // send with zone
        auto fun1 = [this](RpcGetLogCtx* rpc_ctx, ggpb::Closure* done){
            LOG(NOTICE) << "mock rpc closure";
            rpc_ctx->status.Reset(RpcCode::kInvalidArgs, "idx over size");
            if (done) {
                done->Run();
            }
        };
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->last_zone_version = _mock_control->_dbd_zone->_version;
        for (int32_t i = 0; i < 3; ++i) {
            base::EndPoint ep;
            ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone(ep, "r1", "a1"));
        }
        _mock_control->_dbd_zone->_has_zone = true;
        ctx->enable_server_push = false;

        EXPECT_CALL(*_mock_client, GetLog(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _fetcher->OnCompletion(ctx);
        _mock_control->_dbd_zone->_has_zone = false;
    }

    {
        // fetch fail
        auto fun1 = [this](RpcGetLogCtx* rpc_ctx, ggpb::Closure* done){
            LOG(NOTICE) << "mock rpc closure";
            rpc_ctx->status.Reset(RpcCode::kInvalidArgs, "idx over size");
            if (done) {
                done->Run();
            }
        };

        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->log_id = get_log_id();
        ctx->last_zone_version = _mock_control->_dbd_zone->_version;
        for (int32_t i = 0; i < 3; ++i) {
            ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        }
        ctx->get_log_ctx.status.Reset(RpcCode::kCntlFailed, "mock failed");
        EXPECT_CALL(*_mock_client, GetLog(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // fetch fail
        auto fun1 = [this](RpcGetLogCtx* rpc_ctx, ggpb::Closure* done){
            LOG(NOTICE) << "mock rpc closure";
            rpc_ctx->status.Reset(RpcCode::kInvalidArgs, "idx over size");
            if (done) {
                done->Run();
            }
        };

        _mock_control->_dbd_zone->Set("r1", "a1");

        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->log_id = get_log_id();
        ctx->last_zone_version = _mock_control->_dbd_zone->_version;
        for (int32_t i = 0; i < 3; ++i) {
            ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        }

        ctx->get_log_ctx.status.Reset(RpcCode::kCntlFailed, "mock failed");
        EXPECT_CALL(*_mock_client, GetLog(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &FetcherTests::MockExecuteDo));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // fail wtih FLAGS_multi_psvr_enable_reopen_segment
        auto segment = create_segment();
        segment->_fetch_lsn(9999);
        segment->_cluster->_ps_lowest_lsn(99999);
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kCntlFailed, "fail");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(MockExecuteOk));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
            .WillOnce(Invoke(MockScheduleOk));
        FLAGS_multi_psvr_enable_reopen_segment = true;
        ASSERT_FALSE(ctx->get_log_ctx.status.IsOk());
        _fetcher->DisposeLogBlock(ctx);
        FLAGS_multi_psvr_enable_reopen_segment = false;
    } END_OF_CASE;

    {
        // fail wtih GIT_INVALID_LSN
        auto segment = create_segment();
        segment->_fetch_lsn(9999);
        segment->_cluster->_ps_lowest_lsn(99999);
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->cntl.SetFailed(lspb::GIT_INVALID_LSN, "mock fail");
        ctx->get_log_ctx.status.Reset(RpcCode::kCntlFailed, "fail");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(MockExecuteOk));
        ASSERT_FALSE(ctx->get_log_ctx.status.IsOk());
        _fetcher->DisposeLogBlock(ctx);
    } END_OF_CASE;

    {
        // error empty
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(0);
        ctx->get_log_ctx.response.set_total_len(1);
        ctx->get_log_ctx.response.set_refresh_zone(true);
        ctx->get_log_ctx.response.mutable_zone()->set_region("r1");
        ctx->get_log_ctx.response.mutable_zone()->set_available_zone("a1");
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
    } END_OF_CASE;

    {
        // empty
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(0);
        ctx->get_log_ctx.response.set_total_len(0);
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(1024);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
    } END_OF_CASE;

    {
        // empty & has_zone
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(0);
        ctx->get_log_ctx.response.set_total_len(0);
        ctx->get_log_ctx.response.set_last_lsn(1024);
        ctx->has_zone = true;
        ctx->zone_count = 0;
        segment->_fetch_lsn(1024);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
    } END_OF_CASE;

    {
        // empty & has_zone & in backup
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(2);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(0);
        ctx->get_log_ctx.response.set_total_len(0);
        ctx->get_log_ctx.response.set_last_lsn(1024);
        ctx->has_zone = true;
        ctx->zone_count = 1;
        ctx->get_log_ctx.idx = 1;
        segment->_fetch_lsn(1024);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
    } END_OF_CASE;

    {
        // empty & retry 3
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(2);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(0);
        ctx->get_log_ctx.response.set_total_len(0);
        ctx->get_log_ctx.response.set_last_lsn(1024);
        ctx->has_zone = true;
        ctx->zone_count = 1;
        ctx->get_log_ctx.idx = 0;
        ctx->continuous_empty_fetch_count = 2;
        segment->_fetch_lsn(1024);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
    } END_OF_CASE;

    {
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(1);
        ctx->get_log_ctx.response.set_total_len(1024);
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(1024);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
    } END_OF_CASE;

    { // fetch lsn >= rsp lsn
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(1);
        ctx->get_log_ctx.response.set_total_len(1024);
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(10240);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
    } END_OF_CASE;

    { // fetch lsn >= rsp lsn
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(1);
        ctx->get_log_ctx.response.set_total_len(1024);
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(10240);
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
        FLAGS_multi_psvr_enable_reopen_segment = false;
    } END_OF_CASE;

    { // size mismatch
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(1);
        ctx->get_log_ctx.response.set_total_len(1024 + 11);
        ctx->get_log_ctx.response.set_data_returned(std::string(1024, 'c'));
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(0);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
    }END_OF_CASE;

    { // checksum not consistent
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(1);
        ctx->get_log_ctx.response.set_total_len(1024);
        ctx->get_log_ctx.response.set_data_returned(std::string(1024, 'c'));
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(0);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
    }END_OF_CASE;

    { // segment quota failed
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(1);
        ctx->get_log_ctx.response.set_total_len(1024);
        ctx->get_log_ctx.response.set_data_returned(std::string(1024, 'c'));
        ctx->get_log_ctx.response.set_data_checksum(gaiadb::common::ut_crc32(reinterpret_cast<const gaia_apply::byte*>(ctx->get_log_ctx.response.data_returned().c_str()), ctx->get_log_ctx.response.data_returned().size()));
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(0);

        MockQuota* _mock_quota = new MockQuota;
        segment->_fetch_quota.reset(_mock_quota);
        EXPECT_CALL(*_mock_quota, Acquire(_)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->DisposeLogBlock(ctx);
    } END_OF_CASE;

    { // cluster quota failed
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(1);
        ctx->get_log_ctx.response.set_total_len(1024);
        ctx->get_log_ctx.response.set_data_returned(std::string(1024, 'c'));
        ctx->get_log_ctx.response.set_data_checksum(gaiadb::common::ut_crc32(reinterpret_cast<const gaia_apply::byte*>(ctx->get_log_ctx.response.data_returned().c_str()), ctx->get_log_ctx.response.data_returned().size()));
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(0);

        MockQuota* _mock_quota = new MockQuota;
        segment->_fetch_quota.reset(_mock_quota);
        segment->cluster()->_fetch_quota = segment->_fetch_quota;
        _fetcher->_fetch_quota = segment->_fetch_quota;

        EXPECT_CALL(*_mock_quota, Acquire(_)).WillOnce(Return(true)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_quota, Release(_)).WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->DisposeLogBlock(ctx);

    } END_OF_CASE;

    { // global quota failed
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(1);
        ctx->get_log_ctx.response.set_total_len(1024);
        ctx->get_log_ctx.response.set_data_returned(std::string(1024, 'c'));
        ctx->get_log_ctx.response.set_data_checksum(gaiadb::common::ut_crc32(reinterpret_cast<const gaia_apply::byte*>(ctx->get_log_ctx.response.data_returned().c_str()), ctx->get_log_ctx.response.data_returned().size()));
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(0);

        MockQuota* _mock_quota = new MockQuota;
        segment->_fetch_quota.reset(_mock_quota);
        segment->cluster()->_fetch_quota = segment->_fetch_quota;
        _fetcher->_fetch_quota = segment->_fetch_quota;

        EXPECT_CALL(*_mock_quota, Acquire(_)).WillOnce(Return(true)).WillOnce(Return(true)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_quota, Release(_)).WillOnce(Return()).WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->DisposeLogBlock(ctx);

    } END_OF_CASE;

    { // AddFetchLogBlock failed
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(1);
        ctx->get_log_ctx.response.set_total_len(1024);
        ctx->get_log_ctx.response.set_data_returned(std::string(1024, 'c'));
        ctx->get_log_ctx.response.set_data_checksum(gaiadb::common::ut_crc32(reinterpret_cast<const gaia_apply::byte*>(ctx->get_log_ctx.response.data_returned().c_str()), ctx->get_log_ctx.response.data_returned().size()));
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(0);

        MockQuota* _mock_quota = new MockQuota;
        segment->_fetch_quota.reset(_mock_quota);
        segment->cluster()->_fetch_quota = segment->_fetch_quota;
        _fetcher->_fetch_quota = segment->_fetch_quota;
        ASSERT_EQ(_mock_quota->total(), quota_size);

        EXPECT_CALL(*_mock_quota, Acquire(_)).WillOnce(Return(true)).WillOnce(Return(true)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_quota, Release(_)).WillOnce(Return()).WillOnce(Return()).WillOnce(Return());

        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(false));

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);

    } END_OF_CASE;

    { // ok
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(1);
        ctx->get_log_ctx.response.set_total_len(1024);
        ctx->get_log_ctx.response.set_data_returned(std::string(1024, 'c'));
        ctx->get_log_ctx.response.set_data_checksum(gaiadb::common::ut_crc32(reinterpret_cast<const gaia_apply::byte*>(ctx->get_log_ctx.response.data_returned().c_str()), ctx->get_log_ctx.response.data_returned().size()));
        ctx->get_log_ctx.response.set_last_lsn(1024);
        ctx->node_fetch_begin_time = base::cpuwide_time_us();
        segment->_fetch_lsn(0);

        MockQuota* _mock_quota = new MockQuota;
        segment->_fetch_quota.reset(_mock_quota);
        FLAGS_psvr_cluster_fetch_max_buf_size = 0;
        segment->cluster()->_fetch_quota.reset(new Quota(&FLAGS_psvr_cluster_fetch_max_buf_size));
        _fetcher->_fetch_quota = segment->_fetch_quota;

        EXPECT_CALL(*_mock_quota, Acquire(_)).WillOnce(Return(true)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_quota, Release(_)).WillOnce(Return()).WillOnce(Return());

        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);

    } END_OF_CASE;

    { // ok && over time
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(1);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.response.set_record_num(1);
        ctx->get_log_ctx.response.set_total_len(1024);
        ctx->get_log_ctx.response.set_data_returned(std::string(1024, 'c'));
        ctx->get_log_ctx.response.set_data_checksum(gaiadb::common::ut_crc32(reinterpret_cast<const gaia_apply::byte*>(ctx->get_log_ctx.response.data_returned().c_str()), ctx->get_log_ctx.response.data_returned().size()));
        ctx->get_log_ctx.response.set_last_lsn(1024);
        ctx->node_fetch_begin_time = base::cpuwide_time_us() - FLAGS_psvr_fetch_max_time_us - 1;
        segment->_fetch_lsn(0);

        MockQuota* _mock_quota = new MockQuota;
        segment->_fetch_quota.reset(_mock_quota);
        segment->cluster()->_fetch_quota = segment->_fetch_quota;
        FLAGS_psvr_fetch_max_buf_size = 0;
        _fetcher->_fetch_quota.reset(new Quota(&FLAGS_psvr_fetch_max_buf_size));

        EXPECT_CALL(*_mock_quota, Acquire(_)).WillOnce(Return(true)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_quota, Release(_)).WillOnce(Return()).WillOnce(Return());

        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);

    } END_OF_CASE;

    { // ok && over backup time
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(2);
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->get_log_ctx.servers.push_back(gaiadb::common::PeerZone());
        ctx->has_zone = true;
        ctx->zone_count = 1;
        ctx->get_log_ctx.idx = 1;
        ctx->get_log_ctx.response.set_record_num(1);
        ctx->get_log_ctx.response.set_total_len(1024);
        ctx->get_log_ctx.response.set_data_returned(std::string(1024, 'c'));
        ctx->get_log_ctx.response.set_data_checksum(gaiadb::common::ut_crc32(reinterpret_cast<const gaia_apply::byte*>(ctx->get_log_ctx.response.data_returned().c_str()), ctx->get_log_ctx.response.data_returned().size()));
        ctx->get_log_ctx.response.set_last_lsn(1024);
        ctx->node_fetch_begin_time = base::cpuwide_time_us() - FLAGS_psvr_fetch_max_time_us_from_backup - 1;
        segment->_fetch_lsn(0);

        FLAGS_psvr_segment_fetch_max_buf_size = 0;
        segment->_fetch_quota.reset(new Quota(&FLAGS_psvr_segment_fetch_max_buf_size));
        MockQuota* _mock_quota = new MockQuota;
        segment->cluster()->_fetch_quota.reset(_mock_quota);
        _fetcher->_fetch_quota = segment->cluster()->_fetch_quota;

        EXPECT_CALL(*_mock_quota, Acquire(_)).WillOnce(Return(true)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_quota, Release(_)).WillOnce(Return()).WillOnce(Return());

        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);

    } END_OF_CASE;

    { // ok 2 && fetch emtpy && lsn == max get log lsn
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(2);
        ctx->get_log_ctx.servers.emplace_back(base::EndPoint(), "r1", "a1");
        ctx->get_log_ctx.servers.emplace_back(base::EndPoint(), "r2", "a1");
        ctx->has_zone = true;
        ctx->zone_count = 1;
        ctx->get_log_ctx.idx = 0;
        ctx->node_fetch_begin_time = base::cpuwide_time_us();
        ctx->get_log_ctx.response.set_record_num(0);
        ctx->get_log_ctx.response.set_total_len(0);
        ctx->get_log_ctx.response.set_data_returned("");
        ctx->get_log_ctx.response.set_data_checksum(0);
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(0);
        segment->cluster()->set_max_get_log_lsn(1024);

        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
    } END_OF_CASE;

    { // ok 3 && fetch empty &&  lsn < max get log lsn
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(2);
        ctx->get_log_ctx.servers.emplace_back(base::EndPoint(), "r1", "a1");
        ctx->get_log_ctx.servers.emplace_back(base::EndPoint(), "r2", "a1");
        ctx->has_zone = true;
        ctx->zone_count = 1;
        ctx->get_log_ctx.idx = 1;
        ctx->node_fetch_begin_time = base::cpuwide_time_us();
        ctx->continuous_empty_fetch_count = 0;

        ctx->get_log_ctx.response.set_record_num(0);
        ctx->get_log_ctx.response.set_total_len(0);
        ctx->get_log_ctx.response.set_data_returned("");
        ctx->get_log_ctx.response.set_data_checksum(0);
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(0);
        segment->cluster()->set_max_get_log_lsn(1025);

        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
    } END_OF_CASE;

    { // ok 3 && fetch empty && continuous_empty_fetch_count over size
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        ctx->get_log_ctx.status.Reset(RpcCode::kSuccess, "ok");
        ctx->log_id = get_log_id();
        ctx->ls_nodes_status.Reset(2);
        ctx->get_log_ctx.servers.emplace_back(base::EndPoint(), "r1", "a1");
        ctx->get_log_ctx.servers.emplace_back(base::EndPoint(), "r2", "a1");
        ctx->has_zone = true;
        ctx->zone_count = 1;
        ctx->get_log_ctx.idx = 1;
        ctx->node_fetch_begin_time = base::cpuwide_time_us();
        ctx->continuous_empty_fetch_count = FLAGS_psvr_fetch_empty_consecutive_time;

        ctx->get_log_ctx.response.set_record_num(0);
        ctx->get_log_ctx.response.set_total_len(0);
        ctx->get_log_ctx.response.set_data_returned("");
        ctx->get_log_ctx.response.set_data_checksum(0);
        ctx->get_log_ctx.response.set_last_lsn(1024);
        segment->_fetch_lsn(0);
        segment->cluster()->set_max_get_log_lsn(1025);

        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeLogBlock(ctx);
    } END_OF_CASE;
    {
        //  new_nodes empty
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kFetchRedoLog, segment);
        std::vector<gaiadb::common::PeerZone> new_nodes;
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->StartFetchRedoLog(ctx, new_nodes);
    } END_OF_CASE;
}

TEST_F(FetcherTests, test_BatchManager) {
    Fetcher::BatchManager batch_manger;
    std::list<SegmentPtr> segments;
    int32_t batch_idx = 0;
    uint64_t version = 0;
    rwlock_t* batch_muext = nullptr;
    FLAGS_psvr_fetch_batch_segment_count = 2;
    {
        ClusterPtr cluster(new Cluster(_cluster->name()));
        auto seg = create_segment_by_cluster(cluster->name(), 1);
        seg->_cluster = cluster;
        bool ret = batch_manger.Add(seg, &batch_idx, &version);
        ASSERT_TRUE(ret);
        ASSERT_EQ(batch_idx, 0);
        ASSERT_EQ(version, 1);
    }
    {
        auto seg = create_segment_by_cluster(_cluster->name(), 1);
        bool ret = batch_manger.Add(seg, &batch_idx, &version);
        ASSERT_TRUE(ret);
        ASSERT_EQ(batch_idx, 0);
        ASSERT_EQ(version, 2);
    } END_OF_CASE;
    {
        auto seg = create_segment_by_cluster(_cluster->name(), 2);
        bool ret = batch_manger.Add(seg, &batch_idx, &version);
        ASSERT_FALSE(ret);
        ASSERT_EQ(batch_idx, 0);
        ASSERT_EQ(version, 2);
        segments.emplace_back(seg);
    } END_OF_CASE;
    {   // batch add new member
        auto seg = create_segment_by_cluster(_cluster->name(), 3);
        bool ret = batch_manger.Add(seg, &batch_idx, &version);
        ASSERT_TRUE(ret);
        ASSERT_EQ(batch_idx, 1);
        ASSERT_EQ(version, 2);
        segments.emplace_back(seg);
    } END_OF_CASE;
    {
        auto seg = create_segment_by_cluster(_cluster->name(), 4);
        bool ret = batch_manger.Add(seg, &batch_idx, &version);
        ASSERT_FALSE(ret);
        ASSERT_EQ(batch_idx, 1);
        ASSERT_EQ(version, 2);
        segments.emplace_back(seg);
    } END_OF_CASE;

    {
        // Exist now returns two mutexes: outer _shared_mutex (shared) and
        // batch->shared_mutex (exclusive). Both must be unlocked by the caller.
        rwlock_t* outer_mutex = nullptr;
        bool ret = batch_manger.Exist(_cluster, 0, &version, &outer_mutex, &batch_muext);
        ASSERT_TRUE(ret);
        ASSERT_EQ(version, 2);
        outer_mutex->unlock_shared();  // release _shared_mutex shared lock
        batch_muext->unlock();         // release batch->shared_mutex exclusive lock
        ret = batch_manger.Exist(_cluster, 1, &version, &outer_mutex, &batch_muext);
        ASSERT_TRUE(ret);
        ASSERT_EQ(version, 2);
        outer_mutex->unlock_shared();
        batch_muext->unlock();
        ret = batch_manger.Exist(_cluster, 2, &version, &outer_mutex, &batch_muext);
        ASSERT_FALSE(ret);
        ClusterPtr cluster(new Cluster("c2"));
        ret = batch_manger.Exist(cluster, 0, &version, &outer_mutex, &batch_muext);
        ASSERT_FALSE(ret);
    } END_OF_CASE;
    {
        std::list<SegmentWeakPtr> segments;
        int32_t size = batch_manger.Get(_cluster, 0, &segments, &version);
        ASSERT_EQ(size, 2);
        ASSERT_EQ(version, 2);
    } END_OF_CASE;
    {
        std::list<SegmentWeakPtr> segments;
        int32_t size = batch_manger.Get(_cluster, 1, &segments, &version);
        ASSERT_EQ(size, 2);
        ASSERT_EQ(version, 2);
    } END_OF_CASE;
    {
        std::list<SegmentWeakPtr> segments;
        int32_t size = batch_manger.Get(_cluster, 2, &segments, &version);
        ASSERT_LE(size, 0);
    } END_OF_CASE;
    {
        ClusterPtr cluster(new Cluster("c2"));
        std::list<SegmentWeakPtr> segments;
        int32_t size = batch_manger.Get(cluster, 0, &segments, &version);
        ASSERT_LE(size, 0);
    } END_OF_CASE;

    {
        ClusterPtr cluster(new Cluster("c2"));
        int32_t size = batch_manger.TrimBatch(cluster->name(), 1, &version);
        ASSERT_EQ(size, 0);
    }
    {
        int32_t size = batch_manger.TrimBatch(_cluster->name(), 1, &version);
        ASSERT_EQ(size, 0);
        size = batch_manger.TrimBatch(_cluster->name(), 2, &version);
        ASSERT_EQ(size, 2);
    }
    {
        std::list<SegmentWeakPtr> segments;
        int32_t size = batch_manger.Get(_cluster, 0, &segments, &version);
        ASSERT_EQ(size, 2);
        ASSERT_EQ(version, 3);
    }
    {
        std::list<SegmentWeakPtr> segments;
        int32_t size = batch_manger.Get(_cluster, 1, &segments, &version);
        ASSERT_EQ(size, 1);
        ASSERT_EQ(version, 3);
    }
    {
        std::list<SegmentWeakPtr> segments;
        int32_t size = batch_manger.Get(_cluster, 2, &segments, &version);
        ASSERT_LE(size, 0);
    } END_OF_CASE;
    FLAGS_psvr_fetch_batch_segment_count = 3;
    {
        int32_t size = batch_manger.TrimBatch(_cluster->name(), 2, &version);
        ASSERT_EQ(size, 0);
        size = batch_manger.TrimBatch(_cluster->name(), 3, &version);
        ASSERT_EQ(size, 1);
    }
    {
        std::list<SegmentWeakPtr> segments;
        int32_t size = batch_manger.Get(_cluster, 0, &segments, &version);
        ASSERT_EQ(size, 3);
        ASSERT_EQ(version, 4);
    }
    {
        std::list<SegmentWeakPtr> segments;
        int32_t size = batch_manger.Get(_cluster, 1, &segments, &version);
        ASSERT_LE(size, 0);
    } END_OF_CASE;
    FLAGS_psvr_fetch_batch_segment_count = 2;
    {
        std::string cluster_id;
        bool ret = batch_manger.TrimFirst(&cluster_id, &version);
        ASSERT_FALSE(ret);

        batch_manger.BuildTrims();

        ret = batch_manger.TrimFirst(&cluster_id, &version);
        ASSERT_TRUE(ret);

        uint64_t version2;
        int32_t size = batch_manger.TrimBatch(cluster_id, version, &version2);
        ASSERT_EQ(size, 2);

        batch_manger.TrimPop(cluster_id, version);
        ret = batch_manger.TrimFirst(&cluster_id, &version);
        ASSERT_FALSE(ret);

        batch_manger.AddTrimCluster(_cluster, 1);
        ret = batch_manger.TrimFirst(&cluster_id, &version);
        ASSERT_TRUE(ret);
    } END_OF_CASE;
}


TEST_F(FetcherTests, test_BatchManager_Add_dedup) {
    // When the same segment_id is added to an existing (non-full) member, the segment
    // pointer must be updated but member->size must NOT be incremented (dedup fix).
    Fetcher::BatchManager batch_manger;
    int32_t batch_idx = 0;
    uint64_t version = 0;
    FLAGS_psvr_fetch_batch_segment_count = 2;

    auto seg1 = create_segment_by_cluster(_cluster->name(), 1);
    bool ret = batch_manger.Add(seg1, &batch_idx, &version);
    ASSERT_TRUE(ret);          // new batch + new member; member[0].size = 1
    ASSERT_EQ(batch_idx, 0);

    // Add a different segment object with the same segment_id=1.
    // Expected: pointer updated, size stays 1, returns false (no new member).
    auto seg1b = create_segment_by_cluster(_cluster->name(), 1);
    ret = batch_manger.Add(seg1b, &batch_idx, &version);
    ASSERT_FALSE(ret);
    ASSERT_EQ(batch_idx, 0);

    // Confirm size is still 1, not 2.
    std::list<SegmentWeakPtr> out;
    int32_t size = batch_manger.Get(_cluster, 0, &out, &version);
    ASSERT_EQ(size, 1);

    // Confirm the stored pointer was updated to seg1b.
    ASSERT_EQ(out.size(), 1u);
    ASSERT_EQ(out.front().lock(), seg1b);
    END_OF_CASE;
}

TEST_F(FetcherTests, test_BatchManager_RemoveNoLock) {
    Fetcher::BatchManager batch_manger;
    int32_t batch_idx = 0;
    uint64_t version = 0;
    FLAGS_psvr_fetch_batch_segment_count = 2;

    // Add segments to batch
    auto seg1 = create_segment_by_cluster(_cluster->name(), 1);
    auto seg2 = create_segment_by_cluster(_cluster->name(), 2);
    auto seg3 = create_segment_by_cluster(_cluster->name(), 3);
    auto seg4 = create_segment_by_cluster(_cluster->name(), 4);

    batch_manger.Add(seg1, &batch_idx, &version);
    seg1->_fetch_batch_idx = batch_idx;
    ASSERT_EQ(batch_idx, 0);
    batch_manger.Add(seg2, &batch_idx, &version);
    seg2->_fetch_batch_idx = batch_idx;
    ASSERT_EQ(batch_idx, 0);
    batch_manger.Add(seg3, &batch_idx, &version);
    seg3->_fetch_batch_idx = batch_idx;
    ASSERT_EQ(batch_idx, 1);
    batch_manger.Add(seg4, &batch_idx, &version);
    seg4->_fetch_batch_idx = batch_idx;
    ASSERT_EQ(batch_idx, 1);

    {
        // RemoveNoLock: cluster not found
        ClusterPtr other_cluster(new Cluster("other_cluster"));
        bool ret = batch_manger.RemoveNoLock(other_cluster, seg1);
        ASSERT_FALSE(ret);
    } END_OF_CASE;

    {
        // RemoveNoLock: segment not in any batch
        auto seg_not_exist = create_segment_by_cluster(_cluster->name(), 999);
        bool ret = batch_manger.RemoveNoLock(_cluster, seg_not_exist);
        ASSERT_FALSE(ret);
    } END_OF_CASE;

    {
        // RemoveNoLock: remove with correct batch_idx
        std::list<SegmentWeakPtr> segments;
        int32_t size = batch_manger.Get(_cluster, 0, &segments, &version);
        ASSERT_EQ(size, 2);

        // seg1 has batch_idx=0, should be removed from batch 0
        ASSERT_EQ(seg1->fetch_batch_idx(), 0);
        bool ret = batch_manger.RemoveNoLock(_cluster, seg1);
        ASSERT_TRUE(ret);

        segments.clear();
        size = batch_manger.Get(_cluster, 0, &segments, &version);
        ASSERT_EQ(size, 1);  // only seg2 left
    } END_OF_CASE;

    {
        // RemoveNoLock: remove with wrong batch_idx (fallback to iteration)
        // seg3 is in batch 1, but we set its batch_idx to invalid value
        seg3->_fetch_batch_idx = -1;
        bool ret = batch_manger.RemoveNoLock(_cluster, seg3);
        ASSERT_TRUE(ret);  // should still find and remove via iteration

        std::list<SegmentWeakPtr> segments;
        int32_t size = batch_manger.Get(_cluster, 1, &segments, &version);
        ASSERT_EQ(size, 1);  // only seg4 left
    } END_OF_CASE;

    {
        // RemoveNoLock: remove last segment in batch
        bool ret = batch_manger.RemoveNoLock(_cluster, seg2);
        ASSERT_TRUE(ret);

        std::list<SegmentWeakPtr> segments;
        int32_t size = batch_manger.Get(_cluster, 0, &segments, &version);
        ASSERT_EQ(size, 0);  // batch 0 is empty now
    } END_OF_CASE;

    {
        // RemoveNoLock: remove already removed segment
        bool ret = batch_manger.RemoveNoLock(_cluster, seg1);
        ASSERT_FALSE(ret);
    } END_OF_CASE;
}

TEST_F(FetcherTests, test_BatchMonitor) {
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());
    {
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchMonitor);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_,_)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    }
    {
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchMonitor);
        FLAGS_psvr_fetch_batch_segment_count += 1;
        _fetcher->_batch_manager->AddTrimCluster(_cluster, 1);
        EXPECT_CALL(*_mock_segment_manager, GetCluster(_)).WillOnce(Return(nullptr));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_,_)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        auto seg = create_segment_by_cluster(_cluster->name(), 1);
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchMonitor);
        FLAGS_psvr_fetch_batch_segment_count += 1;
        _fetcher->_batch_manager->AddTrimCluster(_cluster, 1);
        int32_t idx = -1;
        uint64_t version = 0;
        _fetcher->_batch_manager->Add(seg, &idx, &version);
        EXPECT_CALL(*_mock_segment_manager, GetCluster(_)).WillOnce(Return(_cluster));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_,_)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        FLAGS_psvr_fetch_batch_segment_count = 2;
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchMonitor);
        _fetcher->_batch_manager->AddTrimCluster(_cluster, 1);
        int32_t idx = -1;
        uint64_t version = 0;
        auto seg = create_segment_by_cluster(_cluster->name(), 2);
        _fetcher->_batch_manager->Add(seg, &idx, &version);

        auto seg2 = create_segment_by_cluster(_cluster->name(), 3);
        _fetcher->_batch_manager->Add(seg2, &idx, &version);

        auto seg3 = create_segment_by_cluster(_cluster->name(), 4);
        _fetcher->_batch_manager->Add(seg3, &idx, &version);
        seg2.reset();

        EXPECT_CALL(*_mock_segment_manager, GetCluster(_)).WillOnce(Return(_cluster));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_,_)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    }
}

TEST_F(FetcherTests, test_BatchGetLogService) {
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    auto mock_batch_manager = new MockBatchFetchManager;
    _fetcher->_batch_manager.reset(mock_batch_manager);

    std::vector<gaiadb::common::PeerZone> empty_new_nodes;
    std::vector<gaiadb::common::PeerZone> new_nodes;
    FillServers(&new_nodes, 3);
    {
        // get cache ok
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kBatchGetLogService);
        ctx->cluster = _cluster;
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(DoAll(
                    SetArgPointee<0>(new_nodes),
                    SetArgPointee<1>(1),
                    Return(true)));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // get cache fail
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kBatchGetLogService);
        ctx->cluster = _cluster;
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(DoAll(
                    SetArgPointee<0>(empty_new_nodes),
                    SetArgPointee<1>(0),
                    Return(true)));
        EXPECT_CALL(*mock_batch_manager, Get(_, _, _, _)).WillOnce(Return(-1));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // get cache ok & version mismatch
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kBatchGetLogService);
        ctx->cluster = _cluster;
        ctx->batch_version = 1;
        ctx->log_service_nodes_version = 1;
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(DoAll(
                    SetArgPointee<0>(empty_new_nodes),
                    SetArgPointee<1>(1),
                    Return(true)));
        EXPECT_CALL(*mock_batch_manager, Get(_, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<3>(2),
                    Return(1)));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // get cache empty
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kBatchGetLogService);
        ctx->cluster = _cluster;
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(DoAll(
                    SetArgPointee<0>(empty_new_nodes),
                    SetArgPointee<1>(0),
                    Return(true)));
        EXPECT_CALL(*mock_batch_manager, Get(_, _, _, _)).WillOnce(Return(0));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    std::list<SegmentWeakPtr> segments;
    auto seg1 = create_mock_segment();
    segments.emplace_back(seg1);
    auto seg2 = create_segment();
    seg2->_psm_info.reset();
    segments.emplace_back(seg2);
    {
        auto seg3 = create_segment();
        segments.emplace_back(seg3);
    }
    {
        // get cache fail & GetOrRefreshNodes fail
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kBatchGetLogService);
        ctx->cluster = _cluster;
        ctx->batch_version = 1;
        ctx->batch_version = 1;
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*mock_batch_manager, Get(_, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<2>(segments),
                    SetArgPointee<3>(1),
                    Return(3)));

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // get cache fail & GetOrRefreshNodes ok & rpc
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kBatchGetLogService);
        ctx->cluster = _cluster;
        ctx->batch_version = 1;
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*mock_batch_manager, Get(_, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<2>(segments),
                    SetArgPointee<3>(1),
                    Return(3)));

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Return(true));

        auto fun2 = [this](ClientContext<gaiapb::LogServiceBatchGetRequest, gaiapb::LogServiceBatchGetResponse>* rpc_ctx,
                ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
            rpc_ctx->response.mutable_status()->set_code(0);
            closure->Run();
        };
        EXPECT_CALL(*_mock_client, ListLogService(_, _)).WillOnce(Invoke(fun2));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        segments.clear();
        // get cache fail & all segment invalid
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kBatchGetLogService);
        ctx->cluster = _cluster;
        ctx->batch_version = 1;
        EXPECT_CALL(*_mock_log_services, Get(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*mock_batch_manager, Get(_, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<2>(segments),
                    SetArgPointee<3>(1),
                    Return(1)));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // rsp all failed
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogService);
        ctx->cluster = _cluster;
        ctx->psm_info = _psm_info;
        auto rpc_ctx = new RpcBatchGetLogServiceCtx;
        ctx->rpc_get_log_service_ctx.reset(rpc_ctx);
        FillServers(&rpc_ctx->servers, 3);
        rpc_ctx->status.Reset(RpcCode::kCntlFailed, "mock fail");
        auto fun1 = [this](ClientContext<gaiapb::LogServiceBatchGetRequest, gaiapb::LogServiceBatchGetResponse>* rpc_ctx,
                ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
            rpc_ctx->response.mutable_status()->set_code(1);
            closure->Run();
        };
        EXPECT_CALL(*_mock_client, ListLogService(_, _))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(this, &FetcherTests::MockExecuteDo))
            .WillOnce(Invoke(this, &FetcherTests::MockExecuteDo));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // rsp ok & empty ls
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogService);
        ctx->cluster = _cluster;
        ctx->psm_info = _psm_info;
        auto rpc_ctx = new RpcBatchGetLogServiceCtx;
        ctx->rpc_get_log_service_ctx.reset(rpc_ctx);
        FillServers(&rpc_ctx->servers, 3);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
        rpc_ctx->response.mutable_status()->set_code(0);

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // rsp ok & no zone
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogService);
        ctx->cluster = _cluster;
        ctx->psm_info = _psm_info;
        auto rpc_ctx = new RpcBatchGetLogServiceCtx;
        ctx->rpc_get_log_service_ctx.reset(rpc_ctx);
        FillServers(&rpc_ctx->servers, 3);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
        rpc_ctx->response.mutable_status()->set_code(0);
        auto ls_pb = rpc_ctx->response.add_log_services();
        ls_pb->set_addr("127.0.0.1:8999");
        ls_pb->set_state(gaiadb::NODE_ACTIVE);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // rsp ok & has zone
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogService);
        ctx->cluster = _cluster;
        ctx->psm_info = _psm_info;
        auto rpc_ctx = new RpcBatchGetLogServiceCtx;
        ctx->rpc_get_log_service_ctx.reset(rpc_ctx);
        FillServers(&rpc_ctx->servers, 3);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
        rpc_ctx->response.mutable_status()->set_code(0);
        {
            auto ls_pb = rpc_ctx->response.add_log_services();
            ls_pb->set_addr("127.0.0.1:8999");
            ls_pb->set_state(gaiadb::NODE_ACTIVE);
        }
        {
            auto ls_pb = rpc_ctx->response.add_log_services();
            ls_pb->set_addr("127.0.0.1:8991");
            ls_pb->set_state(gaiadb::NODE_ACTIVE);
            ls_pb->mutable_zone()->set_region("r1");
            ls_pb->mutable_zone()->set_available_zone("a1");
        }
        _mock_control->_dbd_zone->Set("r1", "a1");

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
}

TEST_F(FetcherTests, test_BatchFetchRedoLog) {
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    auto mock_batch_manager = new MockBatchFetchManager;
    _fetcher->_batch_manager.reset(mock_batch_manager);
    {
        // last zone version mismatch
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchFetchRedoLog);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        FillServers(&rpc_ctx->servers, 3);

        ctx->last_zone_version = _control->dbd_zone()->version() + 1;
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // lack ls nodes size
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchFetchRedoLog);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        FillServers(&rpc_ctx->servers, FLAGS_psvr_single_az_raft_replica_size - 1);

        ctx->last_zone_version = _control->dbd_zone()->version();
        ctx->abnormal_fetch_begin_time = base::cpuwide_time_us() - FLAGS_psvr_fetch_abnormal_max_time_us;
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // size or version mismatch
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchFetchRedoLog);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        FillServers(&rpc_ctx->servers, FLAGS_psvr_single_az_raft_replica_size - 1);

        ctx->last_zone_version = _control->dbd_zone()->version();
        EXPECT_CALL(*mock_batch_manager, Get(_, _, _, _)).WillOnce(Return(-1));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // size or version mismatch
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchFetchRedoLog);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        FillServers(&rpc_ctx->servers, FLAGS_psvr_single_az_raft_replica_size - 1);

        ctx->last_zone_version = _control->dbd_zone()->version();
        EXPECT_CALL(*mock_batch_manager, Get(_, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<3>(ctx->batch_version + 1),
                    Return(1)
                    ));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // size or version mismatch
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchFetchRedoLog);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        FillServers(&rpc_ctx->servers, FLAGS_psvr_single_az_raft_replica_size - 1);

        ctx->last_zone_version = _control->dbd_zone()->version();
        EXPECT_CALL(*mock_batch_manager, Get(_, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<3>(ctx->batch_version),
                    Return(0)
                    ));

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // no invalid segments
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchFetchRedoLog);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        FillServers(&rpc_ctx->servers, FLAGS_psvr_single_az_raft_replica_size - 1);

        ctx->last_zone_version = _control->dbd_zone()->version();
        ctx->abnormal_fetch_begin_time = base::cpuwide_time_us() ;
        std::list<SegmentWeakPtr> segments;
        {
            auto seg = create_segment();
            segments.emplace_back(seg);
        }
        EXPECT_CALL(*mock_batch_manager, Get(_, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<2>(segments),
                    SetArgPointee<3>(ctx->batch_version),
                    Return(1)
                    ));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // rpc
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchFetchRedoLog);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        FillServers(&rpc_ctx->servers, 1);

        ctx->last_zone_version = _control->dbd_zone()->version();
        ctx->abnormal_fetch_begin_time = 0;

        std::list<SegmentWeakPtr> segments;
        auto seg1 = create_segment();
        seg1->_fetch_lsn.set(999);
        segments.emplace_back(seg1);

        auto seg2 = create_segment();
        seg2->_fetch_lsn.set(888);
        segments.emplace_back(seg2);

        auto seg3 = create_segment();
        seg3->_fetch_lsn.set(1111);
        segments.emplace_back(seg3);

        EXPECT_CALL(*mock_batch_manager, Get(_, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<2>(segments),
                    SetArgPointee<3>(ctx->batch_version),
                    Return(3)
                    ));

        auto fun1 = [this](RpcBatchGetLogCtx* rpc_ctx,
                ggpb::Closure* closure) {
            // BatchFetchRedoLog must initialise timeout_ms before RPC
            EXPECT_EQ(rpc_ctx->timeout_ms, FLAGS_psvr_fetch_server_push_timeout_ms + 2000);
            rpc_ctx->status.Reset(RpcCode::kCntlFailed, "mock fail");
            closure->Run();
        };
        EXPECT_CALL(*_mock_client, BatchGetLog(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // rsp fail
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogBlock);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        ctx->ls_nodes_status.Reset(1);
        FillServers(&rpc_ctx->servers, 1);

        rpc_ctx->status.Reset(RpcCode::kCntlFailed, "mock fail");
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // exist fail
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogBlock);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        ctx->ls_nodes_status.Reset(1);
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
        EXPECT_CALL(*mock_batch_manager, Exist(_, _, _, _, _)).WillOnce(Return(false));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    rwlock_t mutex;
    {
        // version mismatch
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogBlock);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        ctx->ls_nodes_status.Reset(1);
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
        mutex.lock_shared();
        EXPECT_CALL(*mock_batch_manager, Exist(_, _, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<2>(ctx->batch_version + 1),
                    SetArgPointee<3>(&mutex),
                    Return(true)
                    ));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // no rsp segment
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogBlock);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        ctx->ls_nodes_status.Reset(1);
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
        mutex.lock_shared();
        EXPECT_CALL(*mock_batch_manager, Exist(_, _, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<2>(ctx->batch_version),
                    SetArgPointee<3>(&mutex),
                    Return(true)
                    ));

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    MockQuota* _mock_quota = new MockQuota;
    {
        // rsp segment
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogBlock);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        ctx->ls_nodes_status.Reset(1);
        FillServers(&rpc_ctx->servers, 1);

        mutex.lock_shared();
        EXPECT_CALL(*mock_batch_manager, Exist(_, _, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<2>(ctx->batch_version),
                    SetArgPointee<3>(&mutex),
                    Return(true)
                    ));

        rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
        {
            // not exists
            auto seg_pb = rpc_ctx->response.add_segments();
            seg_pb->set_segment_id(1);
        }
        auto seg1 = create_segment_by_cluster("c1", 2);
        {
            // fail
            auto seg_pb = rpc_ctx->response.add_segments();
            seg_pb->set_segment_id(seg1->segment_id());
            seg_pb->set_is_ok(false);
        }
        auto seg2 = create_segment_by_cluster("c1", 3);
        {
            // empty ok
            auto seg_pb = rpc_ctx->response.add_segments();
            seg_pb->set_segment_id(seg2->segment_id());
            seg_pb->set_is_ok(true);
            seg_pb->set_last_lsn(9999);
            seg_pb->set_record_num(0);
        }
        auto seg3 = create_segment_by_cluster("c1", 4);
        seg3->_fetch_lsn.set(99999);
        {
            // empty error
            auto seg_pb = rpc_ctx->response.add_segments();
            seg_pb->set_segment_id(seg3->segment_id());
            seg_pb->set_is_ok(true);
            seg_pb->set_last_lsn(9999 + 2);
            seg_pb->set_record_num(0);
        }
        auto seg4 = create_segment_by_cluster("c1", 5);;
        seg4->_fetch_lsn.set(99999);
        {
            // data with error lsn
            auto seg_pb = rpc_ctx->response.add_segments();
            seg_pb->set_segment_id(seg4->segment_id());
            seg_pb->set_is_ok(true);
            seg_pb->set_last_lsn(9999 + 2);
            seg_pb->set_record_num(1);
        }
        auto seg5 = create_segment_by_cluster("c1", 6);;
        seg5->_fetch_lsn.set(8888);
        seg5->_fetch_log_block_queue.SetlastLsn(8888);
        {
            // data with error size
            auto seg_pb = rpc_ctx->response.add_segments();
            seg_pb->set_segment_id(seg5->segment_id());
            seg_pb->set_is_ok(true);
            seg_pb->set_last_lsn(9999);
            seg_pb->set_record_num(1);
            seg_pb->set_total_len(1);
            seg_pb->set_data_returned("");
        }
        {
            // data with error crc
            auto seg_pb = rpc_ctx->response.add_segments();
            seg_pb->set_segment_id(seg5->segment_id());
            seg_pb->set_is_ok(true);
            seg_pb->set_last_lsn(9999);
            seg_pb->set_record_num(1);
            seg_pb->set_total_len(1);
            seg_pb->set_data_returned("1");
            seg_pb->set_data_checksum(gaiadb::common::ut_crc32(reinterpret_cast<const gaia_apply::byte*>("2"), 1));
        }
        {
            // data quota fail
            auto seg_pb = rpc_ctx->response.add_segments();
            seg_pb->set_segment_id(seg5->segment_id());
            seg_pb->set_is_ok(true);
            seg_pb->set_last_lsn(9999);
            seg_pb->set_record_num(1);
            seg_pb->set_total_len(1);
            seg_pb->set_data_returned("2");
            seg_pb->set_data_checksum(gaiadb::common::ut_crc32(reinterpret_cast<const gaia_apply::byte*>("2"), 1));
        }
        {
            // data ok
            auto seg_pb = rpc_ctx->response.add_segments();
            seg_pb->set_segment_id(seg5->segment_id());
            seg_pb->set_is_ok(true);
            seg_pb->set_last_lsn(9999);
            seg_pb->set_record_num(1);
            seg_pb->set_total_len(1);
            seg_pb->set_data_returned("2");
            seg_pb->set_data_checksum(gaiadb::common::ut_crc32(reinterpret_cast<const gaia_apply::byte*>("2"), 1));
        }

        //ctx->batch_segments.emplace(1, nullptr);
        ctx->batch_segments.emplace(2, seg1);
        ctx->batch_segments.emplace(3, seg2);
        ctx->batch_segments.emplace(4, seg3);
        ctx->batch_segments.emplace(5, seg4);
        ctx->batch_segments.emplace(6, seg5);

        _fetcher->_fetch_quota.reset(_mock_quota);
        EXPECT_CALL(*_mock_quota, Acquire(_))
            .WillOnce(Return(false))
            .WillOnce(Return(true));
        EXPECT_CALL(*_mock_quota, Release(_))
            .WillOnce(Return());

        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _))
            .WillOnce(Return())
            .WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // rsp fail
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogBlock);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        ctx->ls_nodes_status.Reset(2);
        FillServers(&rpc_ctx->servers, 2);
        rpc_ctx->idx = 1;

        rpc_ctx->status.Reset(RpcCode::kCntlFailed, "mock ok");
        ctx->abnormal_fetch_begin_time = base::cpuwide_time_us() + 1;
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // rsp ok
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogBlock);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        ctx->ls_nodes_status.Reset(3);
        FillServers(&rpc_ctx->servers, 3);
        ctx->has_zone = true;
        ctx->zone_count = 2;
        rpc_ctx->idx = 1;

        rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
        rpc_ctx->response.set_refresh_zone(true);
        ctx->get_log_ctx.response.mutable_zone()->set_region("r1");
        ctx->get_log_ctx.response.mutable_zone()->set_available_zone("a1");
        _mock_control->_dbd_zone->Set("test", "b2");

        mutex.lock_shared();
        EXPECT_CALL(*mock_batch_manager, Exist(_, _, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<2>(ctx->batch_version),
                    SetArgPointee<3>(&mutex),
                    Return(true)
                    ));

        auto seg = create_segment();
        {
            // data ok
            auto seg_pb = rpc_ctx->response.add_segments();
            seg_pb->set_segment_id(seg->segment_id());
            seg_pb->set_is_ok(true);
            seg_pb->set_last_lsn(9999);
            seg_pb->set_record_num(1);
            seg_pb->set_total_len(1);
            seg_pb->set_data_returned("2");
            seg_pb->set_data_checksum(gaiadb::common::ut_crc32(reinterpret_cast<const gaia_apply::byte*>("2"), 1));
        }
        ctx->batch_segments.emplace(seg->segment_id(), seg);
        //EXPECT_CALL(*_mock_segment_manager, GetSegment(_, _))
            //.WillOnce(Return(seg));
        EXPECT_CALL(*_mock_quota, Acquire(_))
            .WillOnce(Return(true));
        EXPECT_CALL(*_mock_quota, Release(_))
            .WillOnce(Return());
        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _))
            .WillOnce(Return());

        ctx->node_fetch_begin_time = base::cpuwide_time_us() - FLAGS_psvr_fetch_max_time_us_from_backup;
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // rsp ok
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogBlock);
        ctx->cluster = _cluster;
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        ctx->ls_nodes_status.Reset(4);
        FillServers(&rpc_ctx->servers, 4);
        ctx->has_zone = true;
        ctx->zone_count = 2;
        rpc_ctx->idx = 0;

        rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");
        rpc_ctx->response.set_refresh_zone(true);
        ctx->get_log_ctx.response.mutable_zone()->set_region("r1");
        ctx->get_log_ctx.response.mutable_zone()->set_available_zone("a1");

        mutex.lock_shared();
        EXPECT_CALL(*mock_batch_manager, Exist(_, _, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<2>(ctx->batch_version),
                    SetArgPointee<3>(&mutex),
                    Return(true)
                    ));

        auto seg = create_segment();
        {
            // data ok
            auto seg_pb = rpc_ctx->response.add_segments();
            seg_pb->set_segment_id(seg->segment_id());
            seg_pb->set_is_ok(true);
            seg_pb->set_last_lsn(9999);
            seg_pb->set_record_num(0);
            seg_pb->set_total_len(0);
            seg_pb->set_data_returned("");
        }
        ctx->batch_segments.emplace(seg->segment_id(), seg);
        //EXPECT_CALL(*_mock_segment_manager, GetSegment(_, _))
            //.WillOnce(Return(seg));
        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _))
            .WillOnce(Return());

        ctx->node_fetch_begin_time = base::cpuwide_time_us() - FLAGS_psvr_fetch_max_time_us;
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
}

TEST_F(FetcherTests, test_BatchFetchRedoLog_GIT_INVALID_LSN) {
    // Test that RemoveNoLock is called when segment response has GIT_INVALID_LSN error
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    auto mock_batch_manager = new MockBatchFetchManager;
    _fetcher->_batch_manager.reset(mock_batch_manager);

    rwlock_t mutex;
    {
        auto ctx = new Fetcher::Context(Fetcher::Action::kBatchDisposeLogBlock);
        ctx->cluster = _cluster;
        ctx->has_zone = true;  // Set has_zone to use Schedule instead of Execute at the end
        auto rpc_ctx = new RpcBatchGetLogCtx;
        ctx->batch_get_log_ctx.reset(rpc_ctx);
        ctx->ls_nodes_status.Reset(1);
        FillServers(&rpc_ctx->servers, 1);

        mutex.lock_shared();
        EXPECT_CALL(*mock_batch_manager, Exist(_, _, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<2>(ctx->batch_version),
                    SetArgPointee<3>(&mutex),
                    Return(true)
                    ));

        rpc_ctx->status.Reset(RpcCode::kSuccess, "mock ok");

        // Create segment with GIT_INVALID_LSN error
        auto seg = create_segment_by_cluster("c1", 1);
        {
            auto seg_pb = rpc_ctx->response.add_segments();
            seg_pb->set_segment_id(seg->segment_id());
            seg_pb->set_is_ok(false);
            seg_pb->set_error_code(lspb::GIT_INVALID_LSN);
        }
        ctx->batch_segments.emplace(seg->segment_id(), seg);

        // Enable append file for GIT_INVALID_LSN handling
        PSVR_ASSERT(FLAGS_psvr_enable_append_file == true);

        // RemoveNoLock should be called and return true
        EXPECT_CALL(*mock_batch_manager, RemoveNoLock(_, _)).WillOnce(Return(true));

        // After RemoveNoLock, Fetcher::Dispatch is called which calls Execute
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        // At the end of BatchDisposeLogBlock, Schedule is called for next batch
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
}

TEST_F(FetcherTests, test_TrimBatch_1) {
    FLAGS_psvr_fetch_batch_segment_count = 64;
    Fetcher::BatchManager batch_manger;
    std::vector<SegmentPtr> segments;
    int32_t batch_idx = -1;
    uint64_t version = 0;
    for (int32_t i = 0; i < FLAGS_psvr_fetch_batch_segment_count; ++i) {
        auto seg = create_segment_by_cluster(_cluster->name(), i + 1);
        segments.emplace_back(seg);
        bool ret = batch_manger.Add(seg, &batch_idx, &version);
        if (i == 0) {
            ASSERT_TRUE(ret);
        } else {
            ASSERT_FALSE(ret);
        }
        ASSERT_EQ(batch_idx, 0);
        ASSERT_EQ(version, 1);
    }

    int32_t size = batch_manger.TrimBatch(_cluster->name(), version, &version);
    ASSERT_EQ(size, 0);
    ASSERT_EQ(version, 1);

    for (int32_t i = 0; i < FLAGS_psvr_fetch_batch_segment_count; ++i) {
        if (i % 2 == 0 || i % 5 == 0) {
            segments[i] = nullptr;
        }
    }

    size = batch_manger.TrimBatch(_cluster->name(), version, &version);
    ASSERT_EQ(size, 0);
    ASSERT_EQ(version, 1);

    for (int32_t i = 0; i < FLAGS_psvr_fetch_batch_segment_count; ++i) {
        segments[i] = nullptr;
    }

    size = batch_manger.TrimBatch(_cluster->name(), version, &version);
    ASSERT_EQ(size, 0);
}

TEST_F(FetcherTests, test_TrimBatch_2) {
    FLAGS_psvr_fetch_batch_segment_count = 64;
    Fetcher::BatchManager batch_manger;
    std::vector<SegmentPtr> segments;
    int32_t batch_idx = -1;
    uint64_t version = 0;
    for (int32_t i = 0; i < FLAGS_psvr_fetch_batch_segment_count * 4; ++i) {
        auto seg = create_segment_by_cluster(_cluster->name(), i + 1);
        segments.emplace_back(seg);
        bool ret = batch_manger.Add(seg, &batch_idx, &version);
        if (i % FLAGS_psvr_fetch_batch_segment_count == 0) {
            ASSERT_TRUE(ret);
        } else {
            ASSERT_FALSE(ret);
        }
        ASSERT_EQ(batch_idx, i / FLAGS_psvr_fetch_batch_segment_count);
        ASSERT_EQ(version, 1);
    }

    int32_t size = batch_manger.TrimBatch(_cluster->name(), version, &version);
    ASSERT_EQ(size, 4);
    ASSERT_EQ(version, 2);

    int32_t j = 0;
    for (int32_t i = 0; i < FLAGS_psvr_fetch_batch_segment_count * 4; ++i) {
        if (i % 2 == 0 || i % 5 == 0) {
            ++j;
            segments[i] = nullptr;
        }
    }

    int32_t n = (FLAGS_psvr_fetch_batch_segment_count * 5 - j - 1) / FLAGS_psvr_fetch_batch_segment_count;
    size = batch_manger.TrimBatch(_cluster->name(), version, &version);
    ASSERT_EQ(size, n);
    ASSERT_EQ(version, 3);

    for (int32_t i = 0; i < FLAGS_psvr_fetch_batch_segment_count * 4; ++i) {
        segments[i] = nullptr;
    }

    size = batch_manger.TrimBatch(_cluster->name(), version, &version);
    ASSERT_EQ(size, 0);
}

TEST_F(FetcherTests, test_DoReopenSegment) {
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    auto seg = create_mock_segment();
    {
        EXPECT_CALL(*seg, GetPreDisable()).WillOnce(Return(false));
        _fetcher->DoReopenSegment(seg TRACE_FILE_LINE_CC, false);
    } END_OF_CASE;

    {
        EXPECT_CALL(*seg, GetPreDisable()).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DoReopenSegment(seg TRACE_FILE_LINE_CC, false);
    } END_OF_CASE;

    {
        EXPECT_CALL(*seg, GetPreDisable()).WillOnce(Return(true));
        EXPECT_CALL(*seg, PreDisable()).WillOnce(Return(false));
        _fetcher->DoReopenSegment(seg TRACE_FILE_LINE_CC, true);
    } END_OF_CASE;

    {
        EXPECT_CALL(*seg, GetPreDisable()).WillOnce(Return(true));
        EXPECT_CALL(*seg, PreDisable()).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DoReopenSegment(seg TRACE_FILE_LINE_CC, true);
    } END_OF_CASE;
}

static void wait_done(std::atomic<int32_t>* n) {
    n->fetch_add(1);
}

TEST_F(FetcherTests, test_DoReopenSegment_rpc) {
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    std::atomic<int32_t> n = 0;
    auto seg = create_mock_segment();
    {
        pspb::ReopenSegmentRequest request;
        pspb::ReopenSegmentResponse response;
        ggpb::Closure* done = brpc::NewCallback(wait_done, &n);
        request.set_force(false);
        EXPECT_CALL(*seg, GetPreDisable()).WillOnce(Return(false));
        _fetcher->DoReopenSegment(seg TRACE_FILE_LINE_CC, &request, &response, done);
    } END_OF_CASE;

    {
        pspb::ReopenSegmentRequest request;
        pspb::ReopenSegmentResponse response;
        ggpb::Closure* done = brpc::NewCallback(wait_done, &n);
        request.set_force(false);
        EXPECT_CALL(*seg, GetPreDisable()).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DoReopenSegment(seg TRACE_FILE_LINE_CC, &request, &response, done);
    } END_OF_CASE;

    {
        pspb::ReopenSegmentRequest request;
        pspb::ReopenSegmentResponse response;
        ggpb::Closure* done = brpc::NewCallback(wait_done, &n);
        request.set_force(true);
        request.set_not_recover(true);
        EXPECT_CALL(*seg, GetPreDisable()).WillOnce(Return(true));
        EXPECT_CALL(*seg, PreDisable()).WillOnce(Return(false));
        _fetcher->DoReopenSegment(seg TRACE_FILE_LINE_CC, &request, &response, done);
    } END_OF_CASE;

    {
        pspb::ReopenSegmentRequest request;
        pspb::ReopenSegmentResponse response;
        ggpb::Closure* done = brpc::NewCallback(wait_done, &n);
        request.set_force(true);
        EXPECT_CALL(*seg, GetPreDisable()).WillOnce(Return(true));
        EXPECT_CALL(*seg, PreDisable()).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DoReopenSegment(seg TRACE_FILE_LINE_CC, &request, &response, done);
    } END_OF_CASE;

    ASSERT_EQ(4, n.load());
}

TEST_F(FetcherTests, test_CheckReopenSegment) {
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        // fetch lsn > lowest lsn
        auto segment = create_segment();
        segment->_fetch_lsn(9999);
        segment->_cluster->_ps_lowest_lsn(9998);
        segment->_cluster->_ps_lowest_gc_lsn(0);

        auto ctx = new Fetcher::Context(Fetcher::Action::kCheckReopenSegment, segment);
        _fetcher->CheckReopenSegment(ctx);
    } END_OF_CASE;

    {
        // fetch lsn < lowest lsn
        auto segment = create_segment();
        segment->_fetch_lsn(999);
        segment->_cluster->_ps_lowest_lsn(9998);
        segment->_cluster->_ps_lowest_gc_lsn(0);

        auto ctx = new Fetcher::Context(Fetcher::Action::kCheckReopenSegment, segment);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->CheckReopenSegment(ctx);
    } END_OF_CASE;

    {
        // fetch lsn < lowest lsn
        auto segment = create_mock_segment();
        segment->_fetch_lsn(999);
        segment->_cluster->_ps_lowest_lsn(9998);
        segment->_cluster->_ps_lowest_gc_lsn(0);

        auto ctx = new Fetcher::Context(Fetcher::Action::kCheckReopenSegment, segment);
        ctx->retry_times = FLAGS_multi_psvr_enable_reopen_check_times;
        EXPECT_CALL(*segment, PreDisable()).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->CheckReopenSegment(ctx);
    } END_OF_CASE;

    {
        // fetch lsn < lowest lsn
        auto segment = create_mock_segment();
        segment->_fetch_lsn(999);
        segment->_cluster->_ps_lowest_lsn(9998);
        segment->_cluster->_ps_lowest_gc_lsn(0);

        auto ctx = new Fetcher::Context(Fetcher::Action::kCheckReopenSegment, segment);
        ctx->retry_times = FLAGS_multi_psvr_enable_reopen_check_times;
        EXPECT_CALL(*segment, PreDisable()).WillOnce(Return(false));
        _fetcher->CheckReopenSegment(ctx);
    } END_OF_CASE;
}

TEST_F(FetcherTests, test_PreReopenSegment) {
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kPreReopenSegment, segment);

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kPreReopenSegment, segment);

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [this](RpcSetReplicaRecovery* rpc_ctx,
                ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kCntlFailed, "mock failed");
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, SetReplicaRecovery(_, _))
            .WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kReopenSegment, segment);
        auto rpc_ctx = new RpcSetReplicaRecovery;
        ctx->rpc_set_replica_recovery_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // rpc fail and not_exists
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_NOT_EXIST);
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kReopenSegment, segment);
        auto rpc_ctx = new RpcSetReplicaRecovery;
        ctx->rpc_set_replica_recovery_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // rpc fail and invalid
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_INVALID);
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kReopenSegment, segment);
        auto rpc_ctx = new RpcSetReplicaRecovery;
        ctx->rpc_set_replica_recovery_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // rpc retry
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_TIMEOUT);
        FillServers(&rpc_ctx->servers, 2);

        auto fun1 = [this](RpcSetReplicaRecovery* rpc_ctx,
                ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kCntlFailed, "mock failed");
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, SetReplicaRecovery(_, _))
            .WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kReopenSegment, segment);
        auto rpc_ctx = new RpcSetReplicaRecovery;
        ctx->rpc_set_replica_recovery_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // rpc retry
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_TIMEOUT);
        FillServers(&rpc_ctx->servers, 1);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kReopenSegment, segment);
        auto rpc_ctx = new RpcSetReplicaRecovery;
        ctx->rpc_set_replica_recovery_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // Disable fail
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
        FillServers(&rpc_ctx->servers, 1);
        EXPECT_CALL(*segment, Disable()).WillOnce(Return(false));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kReopenSegment, segment);
        auto rpc_ctx = new RpcSetReplicaRecovery;
        ctx->rpc_set_replica_recovery_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // Reopen fail
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
        rpc_ctx->response.mutable_page_server()->set_segment_id(segment->segment_id() + 1);
        FillServers(&rpc_ctx->servers, 1);
        EXPECT_CALL(*segment, Disable()).WillOnce(Return(true));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 1, "./data/c1/1");
        auto ctx = new Fetcher::Context(Fetcher::Action::kReopenSegment, segment);
        auto rpc_ctx = new RpcSetReplicaRecovery;
        ctx->rpc_set_replica_recovery_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // replace failed
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
        rpc_ctx->response.mutable_page_server()->set_segment_id(segment->segment_id());
        rpc_ctx->response.mutable_page_server()->set_replica_id(segment->replica_id());

        std::filesystem::create_directories(segment->db_path());

        FillServers(&rpc_ctx->servers, 1);
        EXPECT_CALL(*segment, Disable()).WillOnce(Return(true));
        EXPECT_CALL(*_mock_segment_manager, ReplaceSegment(_, _)).WillOnce(Return(false));

        _fetcher->OnCompletion(ctx);
        std::filesystem::remove_all(segment->db_path());
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 1, "./data/c1/1");
        auto ctx = new Fetcher::Context(Fetcher::Action::kReopenSegment, segment);
        auto rpc_ctx = new RpcSetReplicaRecovery;
        ctx->rpc_set_replica_recovery_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // ok
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
        rpc_ctx->response.mutable_page_server()->set_segment_id(segment->segment_id());
        rpc_ctx->response.mutable_page_server()->set_replica_id(segment->replica_id());

        std::filesystem::create_directories(segment->db_path());

        FillServers(&rpc_ctx->servers, 1);
        EXPECT_CALL(*segment, Disable()).WillOnce(Return(true));
        EXPECT_CALL(*_mock_segment_manager, ReplaceSegment(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_fetcher, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());

        _fetcher->OnCompletion(ctx);
        std::filesystem::remove_all(segment->db_path());
    } END_OF_CASE;
}

TEST_F(FetcherTests, test_RestartSegment) {
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        // GetOrRefreshNodes failed
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kPreReopenSegment, segment);
        ctx->reopen_not_recover = true;

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // rpc fail
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kPreReopenSegment, segment);
        ctx->reopen_not_recover = true;

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Invoke(MockGetOrRefreshNodesOk));

        auto fun1 = [this](RpcGetPageServerCtx* rpc_ctx,
                ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kCntlFailed, "mock failed");
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSegmentInfo(_, _))
            .WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // rpc rsp fail
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kRestartSegment, segment);
        ctx->reopen_not_recover = true;

        auto rpc_ctx = new RpcGetPageServerCtx;
        ctx->rpc_segment_replica_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // rpc fail and not_exists
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_NOT_EXIST);
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // rpc rsp fail2
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kRestartSegment, segment);
        ctx->reopen_not_recover = true;

        auto rpc_ctx = new RpcGetPageServerCtx;
        ctx->rpc_segment_replica_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // rpc fail and invalid
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_INVALID);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // rpc fail, retry
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kRestartSegment, segment);
        ctx->reopen_not_recover = true;

        auto rpc_ctx = new RpcGetPageServerCtx;
        ctx->rpc_segment_replica_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // rpc retry
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_TIMEOUT);
        FillServers(&rpc_ctx->servers, 2);

        auto fun1 = [this](RpcGetPageServerCtx* rpc_ctx,
                ggpb::Closure* closure) {
            rpc_ctx->status.Reset(RpcCode::kCntlFailed, "mock failed");
            closure->Run();
        };

        EXPECT_CALL(*_mock_client, GetSegmentInfo(_, _))
            .WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kRestartSegment, segment);
        ctx->reopen_not_recover = true;

        auto rpc_ctx = new RpcGetPageServerCtx;
        ctx->rpc_segment_replica_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // rpc retry
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_TIMEOUT);
        FillServers(&rpc_ctx->servers, 1);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment();
        auto ctx = new Fetcher::Context(Fetcher::Action::kRestartSegment, segment);
        ctx->reopen_not_recover = true;

        auto rpc_ctx = new RpcGetPageServerCtx;
        ctx->rpc_segment_replica_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
        ASSERT_EQ(1, segment->segment_id());
        // LoadEngineWithMeta fail
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
        rpc_ctx->response.mutable_page_server()->set_segment_id(0);
        rpc_ctx->response.mutable_page_server()->set_replica_id(1);
        rpc_ctx->response.mutable_page_server()->set_checkpoint_lsn(1);
        rpc_ctx->response.mutable_page_server()->set_apply_lsn(1);
        rpc_ctx->response.mutable_page_server()->set_state(gaiadb::NODE_ACTIVE);
        rpc_ctx->response.mutable_page_server()->set_addr("127.0.0.1:8888");

        FillServers(&rpc_ctx->servers, 1);

        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        auto segment = create_mock_segment_by_cluster("c1", 1, "./data/c1/1");
        auto ctx = new Fetcher::Context(Fetcher::Action::kRestartSegment, segment);
        ctx->reopen_not_recover = true;

        auto rpc_ctx = new RpcGetPageServerCtx;
        ctx->rpc_segment_replica_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // replace failed
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
        rpc_ctx->response.mutable_page_server()->set_segment_id(segment->segment_id());
        rpc_ctx->response.mutable_page_server()->set_replica_id(segment->replica_id());
        rpc_ctx->response.mutable_page_server()->set_checkpoint_lsn(1);
        rpc_ctx->response.mutable_page_server()->set_apply_lsn(1);
        rpc_ctx->response.mutable_page_server()->set_state(gaiadb::NODE_ACTIVE);
        rpc_ctx->response.mutable_page_server()->set_addr("127.0.0.1:8888");

        LOG(NOTICE) << segment->db_path();
        std::filesystem::create_directories(segment->db_path());
        std::system("touch ./data/c1/1/data.ibd");

        FillServers(&rpc_ctx->servers, 1);

        EXPECT_CALL(*_mock_segment_manager, ReplaceSegment(_, _)).WillOnce(Return(false));

        _fetcher->OnCompletion(ctx);
        std::filesystem::remove_all(segment->db_path());
    } END_OF_CASE;

    {
        auto segment = create_mock_segment_by_cluster("c1", 1, "./data/c1/1");
        auto ctx = new Fetcher::Context(Fetcher::Action::kRestartSegment, segment);
        ctx->reopen_not_recover = true;

        auto rpc_ctx = new RpcGetPageServerCtx;
        ctx->rpc_segment_replica_ctx.reset(rpc_ctx);
        rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");

        // ok
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
        rpc_ctx->response.mutable_page_server()->set_segment_id(segment->segment_id());
        rpc_ctx->response.mutable_page_server()->set_replica_id(segment->replica_id());
        rpc_ctx->response.mutable_page_server()->set_checkpoint_lsn(1);
        rpc_ctx->response.mutable_page_server()->set_apply_lsn(1);
        rpc_ctx->response.mutable_page_server()->set_state(gaiadb::NODE_ACTIVE);
        rpc_ctx->response.mutable_page_server()->set_addr("127.0.0.1:8888");

        std::filesystem::create_directories(segment->db_path());
        std::system("touch ./data/c1/1/data.ibd");

        FillServers(&rpc_ctx->servers, 1);

        EXPECT_CALL(*_mock_segment_manager, ReplaceSegment(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_fetcher, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());

        _fetcher->OnCompletion(ctx);
        std::filesystem::remove_all(segment->db_path());
    } END_OF_CASE;
}

TEST_F(FetcherTests, test_AppendRecover) {
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());
    {
        // eof & ok
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kAppendRecover, segment);
        EXPECT_CALL(*segment, AppendRecover(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kEof)));
        EXPECT_CALL(*segment, AppendRecoverFetchFinish()).WillOnce(Return(true));
        EXPECT_CALL(*segment, FinishAppendRecover()).WillOnce(Return(db::Status(db::Code::kEof)));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // eof & ok
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kAppendRecover, segment);
        EXPECT_CALL(*segment, AppendRecover(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kEof)));
        EXPECT_CALL(*segment, AppendRecoverFetchFinish()).WillOnce(Return(true)).WillOnce(Return(true));
        EXPECT_CALL(*segment, FinishAppendRecover()).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // other err
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kAppendRecover, segment);
        EXPECT_CALL(*segment, AppendRecover(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kIOError)));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // quota fail
        auto segment = create_mock_segment();
        MockQuota* _mock_quota = new MockQuota;
        segment->_fetch_quota.reset(_mock_quota);
        EXPECT_CALL(*_mock_quota, Acquire(_)).WillOnce(Return(false));

        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kAppendRecover, segment);
        EXPECT_CALL(*segment, AppendRecover(_, _, _, _, _, _)).WillOnce(
                Invoke([](gaia_apply::lsn_t, db::LogHeader* header, AppendInfo*, base::Slice*,
                          base::Slice*, char**) -> db::Status {
                    // The caller sizes the quota by log_header.records_count.
                    *header = db::LogHeader();
                    return db::Status(db::Code::kOk);
                }));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // fetch empty & AddFetchLogBlock fail
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kAppendRecover, segment);
        EXPECT_CALL(*segment, AppendRecover(_, _, _, _, _, _)).WillOnce(
                Invoke([](gaia_apply::lsn_t, db::LogHeader* header, AppendInfo*, base::Slice*,
                          base::Slice*, char**) -> db::Status {
                    // The caller sizes the quota by log_header.records_count.
                    *header = db::LogHeader();
                    return db::Status(db::Code::kOk);
                }));
        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // fetch empty & AddFetchLogBlock fail
        char* buf = static_cast<char*>(std::malloc(1024));
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kAppendRecover, segment);
        EXPECT_CALL(*segment, AppendRecover(_, _, _, _, _, _)).WillOnce(
                Invoke([buf](gaia_apply::lsn_t, db::LogHeader* header, AppendInfo*,
                          base::Slice*, base::Slice*, char** out_buf) -> db::Status {
                    *header = db::LogHeader();
                    *out_buf = buf;
                    return db::Status(db::Code::kOk);
                }));
        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());
        _fetcher->OnCompletion(ctx);
    } END_OF_CASE;
}

TEST_F(FetcherTests, test_GetRedoRecLog) {
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        // 1. first call, GetPeerNodes returns empty, triggers AddGetPeerEvent
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetRedoRecLog, segment);
        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_parser, AddGetPeerEvent(_ TRACE_MOCK_ARG_CC, _, _)).WillOnce(Return());
        _fetcher->GetRedoRecLog(ctx);
        delete ctx;
    } END_OF_CASE;

    {
        // 2. GetPeerNodes returns servers, sets up RPC and calls client
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetRedoRecLog, segment);
        segment->_fetch_lsn(100);
        auto fun = [](std::vector<gaiadb::common::PeerZone>* peers, bool need_random) {
            FillServers(peers, 3);
            return true;
        };
        auto rpc_fun = [](RpcGetRedoRecLog* rpc_ctx, ggpb::Closure* done) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            if (done) { done->Run(); }
        };
        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(Invoke(fun));
        EXPECT_CALL(*_mock_client, GetRedoRecLog(_, _)).WillOnce(Invoke(rpc_fun));
        // OnFetchRedoRecLog schedules kDisposeRedoRecLog
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->GetRedoRecLog(ctx);
    } END_OF_CASE;

    {
        // 3. second call with existing rpc_get_redo_rec_log_ctx (servers already filled)
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 2);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();
        segment->_fetch_lsn(200);

        auto rpc_fun = [](RpcGetRedoRecLog* rpc_ctx, ggpb::Closure* done) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            if (done) { done->Run(); }
        };
        EXPECT_CALL(*_mock_client, GetRedoRecLog(_, _)).WillOnce(Invoke(rpc_fun));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->GetRedoRecLog(ctx);
    } END_OF_CASE;

    {
        // 4. GetPeerNodes returns false but with some servers (partial), still proceeds
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetRedoRecLog, segment);
        segment->_fetch_lsn(300);
        auto fun = [](std::vector<gaiadb::common::PeerZone>* peers, bool need_random) {
            FillServers(peers, 2);
            return false;
        };
        auto rpc_fun = [](RpcGetRedoRecLog* rpc_ctx, ggpb::Closure* done) {
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            if (done) { done->Run(); }
        };
        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(Invoke(fun));
        EXPECT_CALL(*_mock_parser, AddGetPeerEvent(_ TRACE_MOCK_ARG_CC, _, _)).WillOnce(Return());
        EXPECT_CALL(*_mock_client, GetRedoRecLog(_, _)).WillOnce(Invoke(rpc_fun));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->GetRedoRecLog(ctx);
    } END_OF_CASE;

    {
        // 5. request sets append_db fields from previous response
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kGetRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 1);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();
        ctx->rpc_get_redo_rec_log_ctx->response.set_next_append_db_block_no(5);
        ctx->rpc_get_redo_rec_log_ctx->response.set_next_append_db_block_offset(128);
        segment->_fetch_lsn(400);

        auto rpc_fun = [](RpcGetRedoRecLog* rpc_ctx, ggpb::Closure* done) {
            ASSERT_EQ(rpc_ctx->request.append_db_block_no(), 5u);
            ASSERT_EQ(rpc_ctx->request.append_db_block_offset(), 128u);
            rpc_ctx->status.Reset(RpcCode::kSuccess, "ok");
            if (done) { done->Run(); }
        };
        EXPECT_CALL(*_mock_client, GetRedoRecLog(_, _)).WillOnce(Invoke(rpc_fun));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->GetRedoRecLog(ctx);
    } END_OF_CASE;
}

TEST_F(FetcherTests, test_DisposeRedoRecLog) {
    _fetcher->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_))
        .WillOnce(Return())
        .WillOnce(Return());

    {
        // 1. RPC failed - switch peer and retry
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 2);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kCntlFailed, "timeout");
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeRedoRecLog(ctx);
    } END_OF_CASE;

    {
        // 2. RPC failed - no more peers, rpc_get_redo_rec_log_ctx reset
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 1);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kCntlFailed, "timeout");
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->DisposeRedoRecLog(ctx);
    } END_OF_CASE;

    {
        // 3. RECOVERY_FINISH with batch fetch - dispatch with new ctx
        auto segment = create_segment();
        segment->set_fetch_batch_idx(0);
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 1);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kSuccess, "ok");
        ctx->rpc_get_redo_rec_log_ctx->response.mutable_status()->set_code(pspb::Status::RECOVERY_FINISH);
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->DisposeRedoRecLog(ctx);
    } END_OF_CASE;

    {
        // 4. RECOVERY_FINISH without batch fetch - transition to kFetchRedoLog
        auto segment = create_segment();
        segment->set_fetch_batch_idx(-1);
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 1);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kSuccess, "ok");
        ctx->rpc_get_redo_rec_log_ctx->response.mutable_status()->set_code(pspb::Status::RECOVERY_FINISH);
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeRedoRecLog(ctx);
    } END_OF_CASE;

    {
        // 5. LIMIT status - delay retry without switching peer
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 2);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kSuccess, "ok");
        ctx->rpc_get_redo_rec_log_ctx->response.mutable_status()->set_code(pspb::Status::LIMIT);
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->DisposeRedoRecLog(ctx);
    } END_OF_CASE;

    {
        // 6. other error status - switch peer
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 2);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kSuccess, "ok");
        ctx->rpc_get_redo_rec_log_ctx->response.mutable_status()->set_code(pspb::Status::ERROR);
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeRedoRecLog(ctx);
    } END_OF_CASE;

    {
        // 7. data checksum mismatch
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 2);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kSuccess, "ok");
        auto& rsp = ctx->rpc_get_redo_rec_log_ctx->response;
        rsp.mutable_status()->set_code(pspb::Status::SUCCESS);
        rsp.set_data(std::string(64, 'a'));
        rsp.set_data_len(64);
        rsp.set_data_checksum(12345); // wrong checksum
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeRedoRecLog(ctx);
    } END_OF_CASE;

    {
        // 8. key checksum mismatch
        auto segment = create_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 2);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kSuccess, "ok");
        auto& rsp = ctx->rpc_get_redo_rec_log_ctx->response;
        rsp.mutable_status()->set_code(pspb::Status::SUCCESS);
        rsp.set_key(std::string(32, 'b'));
        rsp.set_key_len(32);
        rsp.set_key_checksum(99999); // wrong checksum
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeRedoRecLog(ctx);
    } END_OF_CASE;

    {
        // 9. success - AddFetchLogBlock ok
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 1);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kSuccess, "ok");
        auto& rsp = ctx->rpc_get_redo_rec_log_ctx->response;
        rsp.mutable_status()->set_code(pspb::Status::SUCCESS);
        std::string data(128, 'x');
        rsp.set_data(data);
        rsp.set_data_len(128);
        rsp.set_data_checksum(gaiadb::common::ut_crc32(
            reinterpret_cast<const gaia_apply::byte*>(data.c_str()), data.size()));
        rsp.set_record_num(1);
        rsp.set_last_lsn(1024);
        rsp.set_fold_size(64);
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();
        segment->_fetch_lsn(0);

        MockQuota* _mock_quota = new MockQuota;
        segment->_fetch_quota.reset(_mock_quota);
        FLAGS_psvr_cluster_fetch_max_buf_size = 0;
        segment->cluster()->_fetch_quota.reset(new Quota(&FLAGS_psvr_cluster_fetch_max_buf_size));
        _fetcher->_fetch_quota = segment->_fetch_quota;
        _fetcher->_recover_redo_quota = segment->_fetch_quota;

        EXPECT_CALL(*_mock_quota, Acquire(_)).WillOnce(Return(true)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_quota, Release(_)).WillOnce(Return()).WillOnce(Return());

        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeRedoRecLog(ctx);

    } END_OF_CASE;

    {
        // 10. success - AddFetchLogBlock fails
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 1);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kSuccess, "ok");
        auto& rsp = ctx->rpc_get_redo_rec_log_ctx->response;
        rsp.mutable_status()->set_code(pspb::Status::SUCCESS);
        std::string data(128, 'y');
        rsp.set_data(data);
        rsp.set_data_len(128);
        rsp.set_data_checksum(gaiadb::common::ut_crc32(
            reinterpret_cast<const gaia_apply::byte*>(data.c_str()), data.size()));
        rsp.set_record_num(1);
        rsp.set_last_lsn(2048);
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();
        segment->_fetch_lsn(0);

        MockQuota* _mock_quota = new MockQuota;
        segment->_fetch_quota.reset(_mock_quota);
        FLAGS_psvr_cluster_fetch_max_buf_size = 0;
        segment->cluster()->_fetch_quota.reset(new Quota(&FLAGS_psvr_cluster_fetch_max_buf_size));
        _fetcher->_fetch_quota = segment->_fetch_quota;
        _fetcher->_recover_redo_quota = segment->_fetch_quota;

        EXPECT_CALL(*_mock_quota, Acquire(_)).WillOnce(Return(true)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_quota, Release(_)).WillOnce(Return()).WillOnce(Return());

        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(false));

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeRedoRecLog(ctx);

    } END_OF_CASE;

    {
        // 11. success with time exceeded - switch peer
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 2);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kSuccess, "ok");
        auto& rsp = ctx->rpc_get_redo_rec_log_ctx->response;
        rsp.mutable_status()->set_code(pspb::Status::SUCCESS);
        std::string data(128, 'z');
        rsp.set_data(data);
        rsp.set_data_len(128);
        rsp.set_data_checksum(gaiadb::common::ut_crc32(
            reinterpret_cast<const gaia_apply::byte*>(data.c_str()), data.size()));
        rsp.set_record_num(1);
        rsp.set_last_lsn(3000);
        FLAGS_psvr_fetch_redo_rec_max_time_s = 1;
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s() - FLAGS_psvr_fetch_redo_rec_max_time_s - 1;
        segment->_fetch_lsn(0);

        MockQuota* _mock_quota = new MockQuota;
        segment->_fetch_quota.reset(_mock_quota);
        FLAGS_psvr_cluster_fetch_max_buf_size = 0;
        segment->cluster()->_fetch_quota.reset(new Quota(&FLAGS_psvr_cluster_fetch_max_buf_size));
        _fetcher->_fetch_quota = segment->_fetch_quota;
        _fetcher->_recover_redo_quota = segment->_fetch_quota;

        EXPECT_CALL(*_mock_quota, Acquire(_)).WillOnce(Return(true)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_quota, Release(_)).WillOnce(Return()).WillOnce(Return());

        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeRedoRecLog(ctx);

        FLAGS_psvr_fetch_redo_rec_max_time_s = 0;
    } END_OF_CASE;

    {
        // 12. success with empty data (data_len=0), no quota check
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 1);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kSuccess, "ok");
        auto& rsp = ctx->rpc_get_redo_rec_log_ctx->response;
        rsp.mutable_status()->set_code(pspb::Status::SUCCESS);
        rsp.set_data_len(0);
        rsp.set_record_num(0);
        rsp.set_last_lsn(500);
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();
        segment->_fetch_lsn(0);

        EXPECT_CALL(*segment, AddFetchLogBlock(_)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_parser, Dispatch(_ TRACE_MOCK_ARG_CC, _)).WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _fetcher->DisposeRedoRecLog(ctx);
    } END_OF_CASE;

    {
        // 13. quota check fails
        auto segment = create_mock_segment();
        Fetcher::Context* ctx = new Fetcher::Context(Fetcher::Action::kDisposeRedoRecLog, segment);
        ctx->rpc_get_redo_rec_log_ctx.reset(new RpcGetRedoRecLog);
        FillServers(&ctx->rpc_get_redo_rec_log_ctx->servers, 1);
        ctx->rpc_get_redo_rec_log_ctx->idx = 0;
        ctx->rpc_get_redo_rec_log_ctx->status.Reset(RpcCode::kSuccess, "ok");
        auto& rsp = ctx->rpc_get_redo_rec_log_ctx->response;
        rsp.mutable_status()->set_code(pspb::Status::SUCCESS);
        std::string data(64, 'q');
        rsp.set_data(data);
        rsp.set_data_len(64);
        rsp.set_data_checksum(gaiadb::common::ut_crc32(
            reinterpret_cast<const gaia_apply::byte*>(data.c_str()), data.size()));
        rsp.set_record_num(1);
        rsp.set_last_lsn(600);
        ctx->fetch_redo_rec_begin_time = base::cpuwide_time_s();
        segment->_fetch_lsn(0);

        MockQuota* _mock_quota = new MockQuota;
        segment->_fetch_quota.reset(_mock_quota);
        FLAGS_psvr_cluster_fetch_max_buf_size = 0;
        segment->cluster()->_fetch_quota.reset(new Quota(&FLAGS_psvr_cluster_fetch_max_buf_size));
        _fetcher->_fetch_quota = segment->_fetch_quota;
        _fetcher->_recover_redo_quota = segment->_fetch_quota;

        EXPECT_CALL(*_mock_quota, Acquire(_)).WillOnce(Return(false));

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _fetcher->DisposeRedoRecLog(ctx);

    } END_OF_CASE;
}

}
}
