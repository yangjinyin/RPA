--psvr_rbio_server_port=%(port)s

--manager_address=%(manager_address)s
--cluster_id=%(cluster_id)s

--psvr_comlog_quota_size=20480
--psvr_comlog_cut_size_mb=1024
--min_log_level=1

--heartbeat_interval_second=0
--heartbeat_interval_ms=500

--psvr_is_multi_type=%(is_multi_type)s
--psvr_store_config_file=%(store_cfg_file)s
--psvr_topology_zone=%(psvr_topology_zone)s

--psvr_zone_region=%(psvr_zone_region)s
--psvr_zone_available_zone=%(psvr_zone_available_zone)s

--psvr_gc_enable_punch_hole=%(gc_enable_punch_hole)s
# compress type: snappy(8), zstd(9), lz4(10)
--psvr_gc_compress_type=%(gc_compress_type)s

--psvr_recover_src_store_max_speed=104857600
--psvr_recover_dst_store_max_speed=104857600

--bvar_dump=true
--bvar_dump_file=%(bvar_dump_file)s
--bvar_dump_interval=40
--bvar_dump_exclude=*_cluster_*;*query_service*latency*;*manager_service*latency*
