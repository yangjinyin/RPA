/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/gaiadb.cc
 Component of gaiadb

 Created 11/1/2022 Hongyu Qiao
 *******************************************************/

#include <gflags/gflags.h>
#include <base/logging.h>
#include <base/endpoint.h>
#include <base/logging.h>
#include <base/comlog_sink.h>
#include <gaiadb/psm_client/client.h>

#include "srv0srv.h"
#include "trx0sys.h"
#include "log0log.h"

#include "events.h"
#include "gaiadb.h"
#include "gaiadb/polar/utils.h"
#include "landing_zone_client.h"
#include "rbio.h"
#include "rpl0rpl.h"
#include "sql/dd/impl/bootstrap/bootstrap_ctx.h"
#include "srv0start.h"
#include "takeover.h"
#include "formula_client.h"
#include "gaiadb_manager.h"
#include "space.h"
#include "time_recorder.h"
#include "bir0async_binlog.h"
#include "sql/binlog.h"
#include "gaiadb/common/types.h"
#include "mysql/components/services/log_builtins.h"
#include "sql/server_component/log_builtins_internal.h"
#include "gaiadb/polar/cpu_affinity.h"
#include "gaiadb/utils/thread_affinity.h"
#include "os0once.h"

DEFINE_string(gaia_interfaces, "bond0,xgbe0,xgbe1,eth1,eth0", "Interface list of this server");
DEFINE_int32(gaia_port, 3307, "Rpc server port");

DEFINE_bool(enable_comlog_to_mysql_err, true,
            "enable comlog data to mysql.err");
DEFINE_string(compute_node_comlog_path, "com_log", "comlog path");
DEFINE_string(compute_node_comlog_process, "compute_node",
              "comlog process name, use argv[0] if empty");
DEFINE_int32(compute_node_comlog_split_type, 1, "comlog split type: "
             "0(TRUNCT), 1(SIZECUT, split per 2048mb), 2(DATECUT, split per 60min)");
DEFINE_int32(compute_node_comlog_quota_size, 20480, "comlog quota size in mb, "\
             "use when split_type is SIZECUT, > 0 valid. split per 2048mb defaultly");
DEFINE_int32(compute_node_comlog_quota_day, 0, "comlog quota day in min, "\
             "use when split_type is DATECUT, > 0 valid. split per 60min defaultly");
DEFINE_int32(compute_node_comlog_quota_hour, 0, "comlog quota hour in min, "\
             "use when split_type is DATECUT, > 0 valid. split per 60min defaultly");
DEFINE_bool(compute_node_comlog_enable_async, false, "comlog enable AFILE");
DEFINE_bool(compute_node_comlog_enable_wf, true, "comlog enable wf");

DEFINE_int32(idle_timeout_s, -1, "Connection will be closed if there is no "
             "read/write operations during the last `idle_timeout_s'");
DEFINE_bool(psm_with_polar_client, false, "psm rquest with use polar client");
BAIDU_RPC_VALIDATE_GFLAG(psm_with_polar_client, baidu::rpc::PassValidate);
DEFINE_int32(gaia_log_checkpoint_every, 30, "Checkpoint every N millisecond");
BAIDU_RPC_VALIDATE_GFLAG(gaia_log_checkpoint_every, baidu::rpc::PositiveInteger);
DEFINE_bool(enable_explicit_undo_space, false, "whether support explicit undo spaces");
DEFINE_bool(enable_purge_time_monitor, false, "whether enable bvars on purge time and some logs");
BAIDU_RPC_VALIDATE_GFLAG(enable_purge_time_monitor, baidu::rpc::PassValidate);

DEFINE_int32(max_gap_wm_primary_secondary_mb, 200,
             "max gap water mark between primary and secondary");
BAIDU_RPC_VALIDATE_GFLAG(max_gap_wm_primary_secondary_mb,
                         baidu::rpc::PositiveInteger);

const char* primary = "PRIMARY";
const char* secondary = "SECONDARY";

extern bvar::LatencyRecorder gaia_sql_execute_by_columnar;

std::shared_ptr<gaiadb::psm_client::Psmgr_client> psmcli{nullptr};
gaiadb::psm_client::ComputeNodeInfo *compute_node_info = nullptr;
std::shared_ptr<gaiadb::psm_client::Heartbeat_data> gaiadb_data(new Gaiadb_heartbeat(srv_gaia_binlog_in_redo_log));
rpc_t rpc_sys;

gaiadb::psm_client::BinlogInRedoMeta binlog_in_redo_meta;
std::vector<bos::BosInfo> bos_infos;
bool psm_binlog_in_redo = false;

static std::shared_ptr<gaiadb::polar::RpcClient> polar_rbio_client = nullptr;
static std::shared_ptr<gaiadb::polar::RpcClient> psm_user_polar_check() {
  if (FLAGS_psm_with_polar_client
      && gaiadb::polar::enable_polar()) {
    return polar_rbio_client;
  }
  return nullptr;
}

const std::string& get_cluster_id() {
  return psmcli->get_cluster_id();
}

struct cpuinfo {
  int count;
  cpu_set_t *cpuset;
};

static void get_cpus_info_for_gaiadb_low(void *arg) {
  struct cpuinfo *info = (struct cpuinfo*)arg;

  int cpuset_num = 0; // from /sys/fs/cgroup/cpuset/cpuset.cpus
  int online_num = 0;
  int hardware_num = std::thread::hardware_concurrency();

#ifdef UNIV_LINUX_ONLY
  CPU_ZERO(info->cpuset);
  std::string cpus_str;
  if (gaiadb::polar::get_global_cpusets(cpus_str)) {
    if (gaiadb::common::parse_cpu_set("[" + cpus_str + "]", info->cpuset)) {
      cpuset_num = CPU_COUNT(info->cpuset);
    }
  }

  online_num = sysconf(_SC_NPROCESSORS_ONLN);
#endif
  ib_system() << "Show cpu info, cpuset_num:" << cpuset_num
    << ", hardware_num:" << hardware_num
    << ", online_num:" << online_num;
  info->count = cpuset_num > 0 ? cpuset_num :
    online_num > 0 ? online_num : hardware_num;
}

int get_cpus_info_for_gaiadb(cpu_set_t *cpuset, bool no_cached) {
  static std::atomic<os_once::state_t> count_cpu_info_mutex;
  static cpu_set_t cpu_set;
  static struct cpuinfo info {0, &cpu_set};
  os_once::do_or_wait_for_done(&count_cpu_info_mutex,
      get_cpus_info_for_gaiadb_low, &info);
  if (!no_cached) {
    if (cpuset) {
      *cpuset = cpu_set;
    }
    return info.count;
  }

  struct cpuinfo info2 {0, cpuset};
  get_cpus_info_for_gaiadb_low(&info2);
  return info2.count;
}

namespace computenode {
class StatusQueryServiceImpl : public computenode::StatusQueryService {
 public:
  /* constructor */
  StatusQueryServiceImpl() {}
  /* deconstruct */
  virtual ~StatusQueryServiceImpl() {}
  /* status query interface */
  virtual void get_compute_node_role(google::protobuf::RpcController* cntl_base,
      const compute_role_request* request,
      compute_role_response* response,
      google::protobuf::Closure* done) override {
    baidu::rpc::ClosureGuard done_guard(done);
    response->set_role(srv_rpl_primary ? 1 : 2);
  }

  virtual void modify_manager(google::protobuf::RpcController* cntl_base,
      const modify_manager_request* request,
      modify_manager_response* response,
      google::protobuf::Closure* done) override {
    baidu::rpc::ClosureGuard done_guard(done);
    const std::string& manager_address = request->manager_address();
    LOG(TRACE) << "StatusQueryServiceService do modify manager. New manager address are: " << manager_address;
    auto status = response->mutable_status();
    if (psmcli->modify_manager_address(manager_address) == gaiadb::GIE_OK) {
      status->set_code(0);
      status->set_msg("do modify address success");
    } else {
      status->set_code(1);
      status->set_msg("do modify address failed");
    }
  }

  virtual void set_zone(google::protobuf::RpcController* cntl_base,
      const set_zone_request* request,
      set_zone_response* response,
      google::protobuf::Closure* done) override {
    baidu::rpc::ClosureGuard done_guard(done);
    auto status = response->mutable_status();
    if (request->zone().region().empty()
        || request->zone().available_zone().empty()) {
      status->set_code(1);
      status->set_msg("invalid zone");
      return;
    }
    std::string region;
    std::string available_zone;
    if (psmcli->get_zone(&region, &available_zone)
        && region == request->zone().region()
        && available_zone == request->zone().available_zone()) {
      status->set_code(0);
      status->set_msg("not change");
      return;
    }
    if (psmcli->set_zone(request->zone().region(), request->zone().available_zone())) {
      status->set_code(0);
      status->set_msg("ok");
    } else {
      status->set_code(1);
      status->set_msg("update fail");
    }
  }

  virtual void clear_zone(google::protobuf::RpcController* cntl_base,
      const clear_zone_request* request,
      clear_zone_response* response,
      google::protobuf::Closure* done) override {
    baidu::rpc::ClosureGuard done_guard(done);
    auto status = response->mutable_status();
    std::string region;
    std::string available_zone;
    if (!psmcli->has_zone()) {
      status->set_code(0);
      status->set_msg("not zone");
      return;
    }
    if (psmcli->get_zone(&region, &available_zone)
        && region.empty()
        && available_zone.empty()) {
      status->set_code(0);
      status->set_msg("not change");
      return;
    }
    if (psmcli->clear_zone()) {
      status->set_code(0);
      status->set_msg("ok");
    } else {
      status->set_code(1);
      status->set_msg("clear fail");
    }
  }

  virtual void get_zone(google::protobuf::RpcController* cntl_base,
      const get_zone_request* request,
      get_zone_response* response,
      google::protobuf::Closure* done) override {
    baidu::rpc::ClosureGuard done_guard(done);
    auto status = response->mutable_status();
    std::string region;
    std::string available_zone;
    if (!psmcli->has_zone()) {
      status->set_code(0);
      status->set_msg("not zone");
      return;
    }
    if (psmcli->get_zone(&region, &available_zone)) {
      status->set_code(0);
      status->set_msg("ok");
      if (!region.empty() && !available_zone.empty()) {
        response->mutable_zone()->set_region(region);
        response->mutable_zone()->set_available_zone(available_zone);
      }
    } else {
      status->set_code(1);
      status->set_msg("get fail");
    }
  }

  virtual void get_latest_lsn(google::protobuf::RpcController* cntl_base,
      const get_latest_lsn_request* request,
      get_latest_lsn_response* response,
      google::protobuf::Closure* done) override {

    if(!rpc_sys.is_innodb_ready()) {
      cntl_base->SetFailed("innodb server is not ready, please retry");
      return;
    }
    baidu::rpc::ClosureGuard done_guard(done);
    lsn_t latest_lsn = 0;
    if (srv_rpl_primary) {
      if (srv_flush_log_at_trx_commit == 0) {
        latest_lsn = log_translate_sn_to_lsn(log_sys->sn.load());
      } else {
        latest_lsn = log_sys->write_lsn.load();
      }
    } else {
      latest_lsn = rpl::get_apply_lsn();
    }

    response->set_latest_lsn(latest_lsn);
  }

  virtual void query_takeover_status(
      ::google::protobuf::RpcController *controller,
      const ::computenode::takeover_status_request *request,
      ::computenode::takeover_status_response *response,
      ::google::protobuf::Closure *done) override {
    baidu::rpc::ClosureGuard done_guard(done);
    [[maybe_unused]] baidu::rpc::Controller *cntl =
        static_cast<baidu::rpc::Controller *>(controller);
    std::lock_guard<std::mutex> lck_guard(hotbackup::task.lock);
    if (hotbackup::task.task_id.empty() ||
        hotbackup::task.task_id != request->task_id()) {
      auto status = response->mutable_status();
      status->set_code(1);
      status->set_msg("can't find this takover task");
      response->set_current_task_id(hotbackup::task.task_id);
      if (!hotbackup::task.task_id.empty()) {
        response->set_current_task_id(hotbackup::task.task_id);
      }
      return;
    }

    auto status = response->mutable_status();
    status->set_code(0);

    switch (hotbackup::get_stage()) {
      case hotbackup::Stage::Success:
        response->set_task_status(computenode::TAKEOVER_SUCCESS);
        break;
      case hotbackup::Stage::Failed:
        response->set_task_status(computenode::TAKEOVER_FAILED);
        break;
      default:
        response->set_task_status(computenode::TAKEOVER_RUNNING);
    }
  }

  virtual void query_status(::google::protobuf::RpcController *controller,
      const ::computenode::EmptyMessage *request,
      ::computenode::QueryStatusResponse *response,
      ::google::protobuf::Closure *done) override {
    baidu::rpc::ClosureGuard done_guard(done);
    response->set_query_beyond_columnar_qps(gaia_sql_execute_by_columnar.qps());
  }

  virtual void health(::google::protobuf::RpcController *controller,
      const ::computenode::EmptyMessage *request,
      ::computenode::HealthResponse *response,
      ::google::protobuf::Closure *done) override {
    baidu::rpc::ClosureGuard done_guard(done);
    bool ok = false;
    std::string msg;
    uint64_t total = 0;
    uint64_t finish = 0;
    bool server_ok = true;
    GaiaHealth::instance().get_status(ok, msg, total, finish, server_ok);
    response->mutable_status()->set_code(ok ? 0 : 1);
    response->mutable_status()->set_msg(msg);
    response->set_total(total);
    response->set_finish(finish);
    response->set_server_status(server_ok);
  }

  virtual void read_page_from_bp(::google::protobuf::RpcController *controller,
      const ::computenode::ReadPageFromBPRequest *request,
      ::computenode::ReadPageFromBPResponse *response,
      ::google::protobuf::Closure *done) override {
    baidu::rpc::ClosureGuard done_guard(done);
    page_no_t page_no = request->page_no();
    space_id_t space_id = request->space_id();
    mtr_t mtr;
    mtr_start(&mtr);
    buf_block_t* page = buf_page_get_gen(page_id_t(space_id, page_no),
                                         univ_page_size, RW_S_LATCH, nullptr,
                                         Page_fetch::PEEK_IF_IN_POOL,
                                         UT_LOCATION_HERE, &mtr);
    if (page) {
      auto checksum = mach_read_from_4(page->frame + FIL_PAGE_SPACE_OR_CHKSUM);
      response->mutable_status()->set_code(0);
      response->mutable_status()->set_msg("OK");
      response->set_page_content(page->frame, UNIV_PAGE_SIZE);
      response->set_checksum(checksum);
    } else {
      response->mutable_status()->set_code(1);
      response->mutable_status()->set_msg("Cannot read page from BP");
    }
    mtr_commit(&mtr);
  }
};

class PrimaryServiceImpl : public computenode::PrimaryService {
 public:
  PrimaryServiceImpl() {}
  virtual ~PrimaryServiceImpl() {}
  virtual void get_vdl(google::protobuf::RpcController *cntl_base,
      const vdl_request *request, vdl_response *response,
      google::protobuf::Closure *done) override {
    baidu::rpc::ClosureGuard done_guard(done);
    baidu::rpc::Controller* cntl =
          static_cast<baidu::rpc::Controller*>(cntl_base);
    if (!srv_rpl_primary) {
      cntl->SetFailed("server is not primary");
      return;
    }

    LOG(NOTICE) << "Received get_vdl request from backup tool."
                << " [log_id=" << cntl->log_id()
                << "] from " << cntl->remote_side()
                << " to " << cntl->local_side();
    uint64_t time_ms = my_micro_time();
    response->set_vdl(log_get_vdl(*log_sys));
    response->set_backup_time(time_ms);
    response->set_written_lsn(log_sys->write_lsn.load());
  }
};

class SecondaryServiceImpl : public computenode::SecondaryService {
public:
  SecondaryServiceImpl() {}
  virtual ~SecondaryServiceImpl() {}
  virtual void takeover_primary(::google::protobuf::RpcController* controller,
      const ::computenode::takeover_primary_request* request,
      ::computenode::takeover_primary_response* response,
      ::google::protobuf::Closure* done) override {

    const auto start_time = my_micro_time();

    baidu::rpc::ClosureGuard done_guard(done);
    baidu::rpc::Controller* cntl =
          static_cast<baidu::rpc::Controller*>(controller);
    if (srv_rpl_primary) {
      cntl->SetFailed("server is not secondary");
      return;
    }

    std::string task_id = request->has_task_id()
                              ? request->task_id()
                              : std::to_string(base::gettimeofday_us());
    LOG(NOTICE) << "Received takeover primary request. "
                << "log_id[" << cntl->log_id() << "], from["
                << cntl->remote_side() << "] to[" << cntl->local_side()
                << "], task_id[" << task_id << "]";

    {
      std::lock_guard<std::mutex> lck_guard(hotbackup::task.lock);
      auto current_dd_version =
          dd::bootstrap::DD_bootstrap_ctx::instance().get_actual_dd_version();
      if (current_dd_version != dd::bootstrap::DD_VERSION_80023) {
        auto status = response->mutable_status();
        status->set_code(1);
        std::stringstream ss;
        ss << "dd version must be 80023, current is " << current_dd_version;
        status->set_msg(ss.str());
        LOG(WARNING) << "cant process takeover primary request"
                     << ". task_id[" << task_id << "], message[" << ss.str()
                     << "]";
        return;
      }

      // check water mark diff from primary
      auto apply_lsn = rpl::get_apply_lsn();
      auto primary_vdl = rpl::get_master_vdl();
      if (apply_lsn < primary_vdl &&
          (primary_vdl - apply_lsn >
           (static_cast<lsn_t>(FLAGS_max_gap_wm_primary_secondary_mb) * (1<< 20)))) {
        auto status = response->mutable_status();
        status->set_code(1);
        std::stringstream ss;
        ss << "watermark diff between primary and secondary is too large"
           << ", secondary_apply_lsn: " << apply_lsn
           << ", primary_vdl: " << primary_vdl;
        status->set_msg(ss.str());
        LOG(WARNING) << "cant process takeover primary request"
                     << ". task_id[" << task_id << "], message[" << ss.str()
                     << "]";
        return;
      }

      if (!hotbackup::task.task_id.empty() &&
          (!hotbackup::stage_is(hotbackup::Stage::Success) ||
           !hotbackup::stage_is(hotbackup::Stage::Failed))) {
        auto status = response->mutable_status();
        status->set_code(1);
        status->set_msg("other task already running");
        response->set_current_task_id(hotbackup::task.task_id);
        LOG(WARNING) << "cant process takeover primary request"
                     << ". task_id[" << task_id
                     << "], message[cant process takeover primary request]";
        return;
      }

      if (!srv_gaia_enable_hot_backup) {
        auto status = response->mutable_status();
        status->set_code(1);
        status->set_msg("innodb_gaia_enable_hot_backup should be set to true");
        LOG(WARNING) << "cant process takeover primary request"
                     << ". task_id[" << task_id
                     << "], message[innodb_gaia_enable_hot_backup should be set to true]";
        return;
      }

      if (srv_is_being_started ||
          srv_shutdown_state.load() != SRV_SHUTDOWN_NONE) {
        auto status = response->mutable_status();
        status->set_code(1);
        status->set_msg("secondary is being started or shutdown");
        LOG(WARNING) << "cant process takeover primary request"
                     << ". task_id[" << task_id
                     << "], message[secondary is being started or shutdown]";
        return;
      }

      hotbackup::task.reset(task_id, start_time);
      hotbackup::set_stage(hotbackup::Stage::Prepare);

      response->set_current_task_id(hotbackup::task.task_id);
      auto status = response->mutable_status();
      status->set_code(0);
    }

    hotbackup::takeover_primary_async();
  }
};
} // namespace computenode

computenode::PrimaryServiceImpl primary_service_impl;
computenode::StatusQueryServiceImpl compute_service_impl;
computenode::SecondaryServiceImpl secondary_service_impl;

rpc_t::rpc_t() : started(false) {
  cmp_server_ = std::make_shared<baidu::rpc::Server>();
}

bool rpc_t::init_server() {
  if (cmp_server_->AddService(&compute_service_impl,
                              baidu::rpc::SERVER_DOESNT_OWN_SERVICE) != 0) {
    LOG(ERROR) << "Fail to add compute_service_impl service";
    return false;
  }
  if (cmp_server_->AddService(&primary_service_impl,
                              baidu::rpc::SERVER_DOESNT_OWN_SERVICE) != 0) {
    LOG(ERROR) << "Fail to add primary_service_impl service";
    return false;
  }

  if (cmp_server_->AddService(&secondary_service_impl,
                              baidu::rpc::SERVER_DOESNT_OWN_SERVICE) != 0) {
    LOG(ERROR) << "Fail to add secondary_service_impl service";
    return false;
  }

  return true;
}

bool rpc_t::start_server() {
   /* Start the brpc server. */
  baidu::rpc::ServerOptions options;
  options.idle_timeout_sec = FLAGS_idle_timeout_s + 1000;
  options.use_rdma = false;
  options.num_threads = -1; //Must be set -1, otherwise the bthread_concurrency parameter will not take effect
  bool ret = false;
  for (int i = 0; i < 3; ++i) {
    ret = cmp_server_->Start(FLAGS_gaia_port, &options) == 0;
    if (ret) {
      break;
    } else {
      std::this_thread::sleep_for(std::chrono::milliseconds(300 + 300 * i));
    }
  }
  if (!ret) {
    ib_error() << "Fail to start BRPC service on port=" << FLAGS_gaia_port;
    return false;
  }
  LOG(NOTICE) << "ComputeNode BRPC service is started on port: "
            << FLAGS_gaia_port << ", Service type: "
            << (srv_rpl_primary ? "Primary" : "Secondary");

  started = true;
  return true;
}

bool rpc_t::stop_server(bool wait) {
  if (!started) {
    return true;
  }
  cmp_server_->Stop(0);
  if (wait) {
    cmp_server_->Join();
    cmp_server_.reset(new baidu::rpc::Server());
  }
  return true;
}

uint64_t Gaiadb_heartbeat::get_apply_lsn() {
  if (srv_rpl_primary && log_sys) {
    return log_get_vdl(*log_sys);
  } else if(!srv_rpl_primary) {
    // During startup, rpl_sys is not initialized, use start lsn to replace it
    return std::max(std::min(rpl::get_apply_lsn(), rpl::get_flush_lsn()),
        compute_node_info->apply_lsn);
  }
  return 0;
}

uint64_t Gaiadb_heartbeat::get_trx_id() {
  if (!trx_sys || !trx_sys->mvcc) {
    return 0;
  }
  if (srv_rpl_primary) {
    return trx_sys->low_limit_no.load();
  } else {
    ReadView oldest_view;
    trx_sys->mvcc->clone_oldest_view(&oldest_view);
    //the reason for oldest_view.low_limit_no()+1:
    ////to make secondary low_limit_no = primary's low_limit_no, then primary can purge all the undo logs when unneeded
    return oldest_view.low_limit_no() + 1;
  }
}

static void reset_binlog_in_redo_meta() {
  static std::atomic<int> binlog_in_redo_count(0);
  if (srv_rpl_primary && log_sys) {
    if (binlog_in_redo_meta.sync_lsn != log_get_vdl(*log_sys)) {
      auto n = binlog_in_redo_count.fetch_add(1);
      if (n + 1 >= 10) {
        binlog_in_redo_meta.sync_lsn = log_get_vdl(*log_sys);
        binlog_in_redo_count.store(0);
      }
    } else {
      binlog_in_redo_count.store(0);
    }
  }
}

bool Gaiadb_heartbeat::get_binlog_in_redo_meta(gaiadb::psm_client::BinlogInRedoMeta& meta) {
  reset_binlog_in_redo_meta();
  meta.sync_lsn = binlog_in_redo_meta.sync_lsn;
  meta.file_id = binlog_in_redo_meta.file_id;
  meta.pos = binlog_in_redo_meta.pos;
  return srv_gaia_binlog_in_redo_log;
}


namespace gaiadb {
static const int sink_log_levels[] = {INFORMATION_LEVEL, INFORMATION_LEVEL,
                                      WARNING_LEVEL, ERROR_LEVEL, ERROR_LEVEL};
class LogSink : public logging::LogSink {
  // BLOG_INFO(BLOG_TRACE) 0, BLOG_NOTICE 1, BLOG_WARNING 2, BLOG_ERROR 3, BLOG_FATAL 4
  static int basename_index(const char *const path, const int index) {
    return (index == -1 || path[index] == '/' || path[index] == '\\')
      ? index + 1
      : basename_index(path, index - 1);
  }
public:
  static LogSink* GetInstance() {
    return Singleton<LogSink, LeakySingletonTraits<LogSink> >::get();
  }

  LogSink() {}
  virtual ~LogSink() {}

  virtual bool OnLogMessage(int severity, const char *file, int line,
      const base::StringPiece &log_content) override {
    if (!log_builtins_started() ||
        severity < logging::BLOG_INFO ||
        severity > logging::BLOG_FATAL) {
      return false;
    }
    const char *sfile = file + basename_index(file, strlen(file) - 1);
    LogEvent()
      .type(LOG_TYPE_ERROR)
      .prio(sink_log_levels[severity])
      .errcode(ER_GAIA_LOG)
      .subsys("GaiaDB")
      .source_line(line)
      .source_file(sfile)
      .verbatim(log_content.data());
    return true;
  }
};
} // end of ns gaiadb

bool init_com_log() {
  static bool inited = false;
  if (inited) {
    return true;
  }

  inited = true;

  if (FLAGS_enable_comlog_to_mysql_err) {
    update_gaia_log_level();
    logging::SetLogSink(gaiadb::LogSink::GetInstance());
    return true;
  }

  //Base on struct ComlogSinkOptions from 'base/comlog_sink.h';
  logging::ComlogSinkOptions options;
  /* true - "AFILE", false - "FILE" */
  options.async = FLAGS_compute_node_comlog_enable_async;
  /* Use F W N T instead of FATAL WARNING NOTICE TRACE for shorter prefixes */
  options.shorter_log_level = false;
  /* The directory to put logs. Could be absolute or relative path. */
  options.log_dir = FLAGS_compute_node_comlog_path;
  /* Name of the process. Use argv[0] when it's empty. */
  options.process_name = FLAGS_compute_node_comlog_process;
  /* Print VLOG(n) as WARNING instead of TRACE since many online servers */
  options.print_vlog_as_warning = false;
  options.min_log_level = 0;
  /* Split Comlog type:
   * COMLOG_SPLIT_TRUNCT[default]/COMLOG_SPLIT_SIZECUT/COMLOG_SPLIT_DATECUT */
  options.split_type = (logging::ComlogSplitType)FLAGS_compute_node_comlog_split_type;
  /* Remove oldest cutoff log files when they exceed so many megabytes(roughly)
   * */
  options.quota_size = FLAGS_compute_node_comlog_quota_size;
  options.max_log_length = 8192;
  /* Remove cutoff log files older than so many minutes:
   *   quota_day * 24 * 60 + quota_hour * 60 + quota_min */
  options.quota_day = FLAGS_compute_node_comlog_quota_day;
  options.quota_hour = FLAGS_compute_node_comlog_quota_hour;
  options.enable_wf_device = FLAGS_compute_node_comlog_enable_wf;

  if (logging::ComlogSink::GetInstance()->Setup(&options) != 0) {
    std::cerr << "fail to setup comlog";
    return false;
  }
  logging::SetLogSink(logging::ComlogSink::GetInstance());
  return true;
}

static void async_load_all_space_meta_handler(void*) {
  auto start_time = base::monotonic_time_us();
  std::vector<uint32_t> ids;
  if (!gaiadb_get_all_space_ids(ids)) {
    return;
  }
  for (auto& id : ids) {
    gaiadb_space_exist(id);
    if (srv_shutdown_state.load() == SRV_SHUTDOWN_EXIT_THREADS) {
      return;
    }
  }
  ib_system() << "async load all spaces meta, cost "
    << (base::monotonic_time_us() - start_time) << "us";
}

static void async_load_all_space_meta() {
  IB_thread thread;
  thread = os_thread_create(async_load_all_space_meta_key, 0,
      async_load_all_space_meta_handler, nullptr);
  thread.start();
}


static bool check_support_binlog_in_redo_v2(uint64_t psm_features) {
  return (psm_features &
          gaiadb::common::PsmFeature::PSM_FEATURE_BINLOG_IN_REDO) != 0;
}

static bool check_support_tde(uint64_t psm_features) {
  return (psm_features &
          gaiadb::common::PsmFeature::PSM_FEATURE_TDE) != 0;
}

/** Init gaiadb components
@return true if all OK */
bool gaiadb_init() {
  CREATE_TIME_RECORDER;
  if (!init_com_log()) {
    ib_error(ER_GAIA_INIT_FAILED) << "Gaia failed to init com_log";
    return false;
  }

  base::EndPoint local_addr;
  local_addr.ip = base::int2ip(gaiadb::common::get_host_ip(FLAGS_gaia_interfaces.c_str()));
  local_addr.port = FLAGS_gaia_port;
  if (!polar_rbio_client) {
    polar_rbio_client = std::make_shared<gaiadb::polar::RpcClient>();
  }
  gaiadb::psm_client::GetPolarClientFn get_polar_client_fn = psm_user_polar_check;
  psmcli = std::make_shared<gaiadb::psm_client::Psmgr_client>(local_addr, get_polar_client_fn);

  compute_node_info = new gaiadb::psm_client::ComputeNodeInfo();
  uint64_t psm_features = 0;
  auto psm_ret = psmcli->init_compute_node(compute_node_info, psm_features);
  if (psm_ret != gaiadb::GIE_OK) {
    ib_error(ER_GAIA_INIT_FAILED) << "Gaia get compute node info from manager failed,"
      << " addr:" << local_addr
      << ", errno:" << gaiadb::GaiaErrno_Name(static_cast<gaiadb::GaiaErrno>(psm_ret));
    return false;
  }

  if (!check_support_binlog_in_redo_v2(psm_features)) {
    ib_error(ER_GAIA_INIT_FAILED) << "binlog in redo is not supported in this psm version,"
      << ", should upgrade PSM to 4.4.2.0 or bigger";
    return false;
  }

  if (!check_support_tde(psm_features)) {
    ib_error(ER_GAIA_INIT_FAILED) << "tde is not supported in this psm version,"
      << ", should upgrade PSM to 4.4.4.0 or bigger";
    return false;
  }

  int cpu_num = get_cpus_info_for_gaiadb();
  ib_system(ER_GAIA_INIT_MSG) << "Gaia compute node start up with apply_lsn:"
    << compute_node_info->apply_lsn
    << " cpu_num:" << cpu_num;

  if (!compute_node_info->region.empty() && !compute_node_info->available_zone.empty()) {
    if (!psmcli->set_zone(compute_node_info->region, compute_node_info->available_zone)) {
      ib_error(ER_GAIA_INIT_FAILED) << "Manager: failed on set comput node zone";
      return false;
    }
    ib_system(ER_GAIA_INIT_MSG) << "Gaia set zone, region:" << compute_node_info->region
      << ", available_zone:" << compute_node_info->available_zone;
  }

  binlog_in_redo_meta = compute_node_info->binlog_in_redo_meta;
  binlog_in_redo_meta.sync_lsn = compute_node_info->apply_lsn;

  if (psmcli->init_rpc_backup_request()) {
    ib_error(ER_GAIA_INIT_FAILED) << "Manager: failed on init_rpc_backup_request()";
    return false;
  }

  async_load_all_space_meta();

  psm_ret = psmcli->load_segment_list();
  if (psm_ret < 0) {
    ib_warn(ER_GAIA_INIT_FAILED) << "Gaia load all segments failed, " << psm_ret;
  }

  if (!landing_zone::g_landing_zone_client.init(psmcli.get())) {
    ib_error(ER_GAIA_INIT_FAILED) << "Gaia landing_zone init failed";
    return false;
  }

  if (srv_rpl_primary) {
    uint32_t try_count = 0;
    bool success = false;
    while (try_count < 3) {
      auto ret = landing_zone::g_landing_zone_client.increase_epoch();
      if (ret == 0){
        success = true;
        break;
      }
      try_count++;
      std::this_thread::sleep_for(srv_delay_send_request);
    }
    if (!success) {
      ib_error(ER_GAIA_INIT_FAILED) << "Log Service: open landing_zone(increase_epoch) failed";
      return false;
    }

    if (FLAGS_enable_quorum_mode) {
      try_count = 0;
      success = false;
      while (try_count < 3){
        auto ret = landing_zone::g_landing_zone_client.init_membership_epoch();
        if (ret == 0){
          success = true;
          break;
        }
        try_count++;
        std::this_thread::sleep_for(srv_delay_send_request);
      }
      if (!success) {
        ib_error(ER_GAIA_INIT_FAILED) << "Log Service: landing_zone(init membership epoch) failed";
        return false;
      }
    }

    /* avoid rbio vlsn greater than ls vdl on start */
    try_count = 0;
    success = false;
    while (try_count < 3) {
      auto vdl = landing_zone::g_landing_zone_client.last_increase_epoch_lsn();
      auto ret = landing_zone::g_landing_zone_client.send_vdl(vdl);
      if (ret == 0){
        success = true;
        break;
      }
      try_count++;
      std::this_thread::sleep_for(srv_delay_send_request);
    }
    if (!success) {
      ib_error(ER_GAIA_INIT_FAILED) << "Log Service: landing_zone(set_vdl) failed";
      return false;
    }
  }

  if (!RbioClient::get_instance().init(psmcli.get())) {
    ib_error(ER_GAIA_INIT_FAILED) << "Rbio client init failed";
    return false;
  }

  if (!formula::FormulaClient::get_instance().init(psmcli.get())) {
    ib_error(ER_GAIA_INIT_FAILED) << "formula client init failed";
    return false;
  }

  if (srv_rpl_primary) {
    strcpy(export_vars.gaiadb_role, primary);
  } else {
    strcpy(export_vars.gaiadb_role, secondary);
  }

  if (!srv_rpl_primary) {
    set_secondary_initial_vars();
  }

  int32_t regist_ret = psmcli->regist_heartbeat(gaiadb_data);

  if (regist_ret < 0) {
    ib_error(ER_GAIA_INIT_FAILED) << "Failed on regist_heartbeat(): " << regist_ret;
    return false;
  }

  if (!rpc_sys.init_server()) {
    ib_error(ER_GAIA_INIT_FAILED) << "Failed on init rpc service";
    return false;
  }
  if (!rpc_sys.start_server()) {
    ib_error(ER_GAIA_INIT_FAILED) << "Failed on start rpc service";
    return false;
  }

  if (srv_rpl_primary && opt_bin_log && srv_gaia_binlog_in_redo_log_for_primary) {
    bool ret = false;
    ret = gaiadb_get_psm_binlog_switch_v2(&psm_binlog_in_redo);
    if (ret) {
      ib_warn(ER_GAIA_INIT_FAILED) << "Failed on gaiadb_get_psm_binlog_switch_v2(), "
        << "psm version maybe old";
    }
    ret = gaiadb_update_psm_binlog_switch_v2(
      srv_gaia_binlog_in_redo_log_for_primary);
    if (ret) {
      ib_warn(ER_GAIA_INIT_FAILED) << "Failed on gaiadb_update_psm_binlog_switch_v2(), "
        << "psm version maybe old";
    }
    bir::set_binlog_ready(srv_gaia_binlog_in_redo_log_for_primary);
    ret = gaiadb_update_block_write_switch(srv_gaia_block_write_switch);
    if (ret) {
      ib_error(ER_GAIA_INIT_FAILED) << "Failed on gaiadb_update_block_write_switch(), "
        << "psm version maybe old";
      return false;
    }
  }

  ib_system(ER_GAIA_INIT_MSG) << "gaiadb init success";
  return true;
}

bool gaiadb_rpl_init() {
  CREATE_TIME_RECORDER;
  rpl::rpl_sys_init();
  rpl::rpl_sys_start();
  return true;
}

bool gaiadb_shutdown() {
  ib_info() << "Shutting down gaiadb";
  rpc_sys.stop_server();
  if (psmcli) {
    gaiadb_data->run_once_now();
    psmcli->destroy_timer();
  }
  RbioClient::get_instance().deinit();
  return true;
}

bool gaiadb_async_binlog_init() {
  if(!opt_bin_log) {
    return true;
  }

  if (srv_gaia_binlog_in_redo_log_for_primary) {
    bir::bir_binlog_async_init(
      compute_node_info->apply_lsn,
      compute_node_info->apply_lsn);
    gaiadb_set_async_binlog_start_lsn();
    bir::start_binlog_async_background_thread();
  }
  return true;
}

/* In GaiaDB, some secondary's initial vars should be different from those of primary.
 * We set them here.
 * */
void set_secondary_initial_vars() {
  assert(!srv_rpl_primary);

  // set event_scheduler to disabled.
  Events::old_opt_event_scheduler = Events::opt_event_scheduler;
  Events::opt_event_scheduler = Events::EVENTS_DISABLED;
}

/** Update binlog in redo info file to psm
@param[in]      binlog_in_redo_info       binlog in redo info
@return DB_SUCCESS if all OK */
bool gaiadb_update_binlog_in_redo_info(const BinlogInRedoInfo* binlog_in_redo_info) {
  binlog_in_redo_meta.sync_lsn = binlog_in_redo_info->binlog_sync_lsn;
  binlog_in_redo_meta.file_id = binlog_in_redo_info->binlog_file_id;
  binlog_in_redo_meta.pos = binlog_in_redo_info->binlog_pos;
  return true;
}

// 1. Update index_id, simultaneously updating the start_lsn corresponding to this index_id 
//    and the end_time corresponding to the previous index_id.
// 2. Update the LSN for asynchronous disk writes.
// 3. Update the index_id for successful uploads to Boss.
bool gaiadb_update_binlog_in_redo_info_v2(
    const BinlogInRedoInfoMeta* binlog_in_redo_info, int64_t end_time) {
  gaiadb::psm_client::BinlogInRedoMeta async_info;
  async_info.sync_lsn = binlog_in_redo_info->async_info.binlog_sync_lsn;
  async_info.file_id = binlog_in_redo_info->async_info.binlog_file_id;
  async_info.pos = binlog_in_redo_info->async_info.binlog_pos;

  gaiadb::psm_client::BinlogInRedoMetaV2 binlog_info;
  binlog_info.start_lsn = binlog_in_redo_info->binlog_info.start_lsn;
  binlog_info.end_time = end_time;
  LOG(TRACE) << "gaiadb_update_binlog_in_redo_info_v2: sync_lsn=" << async_info.sync_lsn 
             << ", file_id=" << async_info.file_id << ", pos=" << async_info.pos
             << ", index_id=" << binlog_in_redo_info->index_id
             << ", purge_index_id=" << binlog_in_redo_info->purge_index_id
             << ", last_bos_index_id=" << binlog_in_redo_info->last_bos_index_id
             << ", start_lsn=" << binlog_info.start_lsn
             << " end_time=" << binlog_info.end_time;

  if (psmcli->update_binlog_in_redo_info_v2(
      &async_info, binlog_in_redo_info->index_id, end_time,
      &binlog_info, binlog_in_redo_info->purge_index_id,
      binlog_in_redo_info->last_bos_index_id)) {
    LOG(WARNING) << "psmcli->update_binlog_in_redo_info_v2 failed. "
                 << "start_lsn=" << binlog_info.start_lsn
                 << ", end_time=" << end_time
                 << ", index_id=" << binlog_in_redo_info->index_id
                 << ", purge_index_id=" << binlog_in_redo_info->purge_index_id
                 << ", last_bos_index_id=" << binlog_in_redo_info->last_bos_index_id;
    return true;
  }
  return false;
}

bool gaiadb_get_binlog_in_redo_info_v2_index_infos(std::vector<uint32_t> &index_infos) {
  if (psmcli->get_binlog_in_redo_info_v2_index_infos(index_infos)) {
    LOG(WARNING) << "psmcli->get_binlog_in_redo_info_v2_index_infos failed.";
    return true;
  }
  return false;
}

// At startup, retrieve the replay position of the last binlog.
bool gaiadb_get_binlog_in_redo_info_v2_start_info(
    BinlogInRedoInfo *binlog_info, uint32_t &last_index_id, 
    BinlogInRedoInfoV2 *binlog_info_v2) {
  gaiadb::psm_client::BinlogInRedoMeta psm_binlog_info;
  gaiadb::psm_client::BinlogInRedoMetaV2 psm_binlog_info_v2;
  if (psmcli->get_binlog_in_redo_info_v2_start_info(
      &psm_binlog_info, last_index_id, &psm_binlog_info_v2)) {
    LOG(WARNING) << "psmcli->get_binlog_in_redo_info_v2_start_info failed. "
                 << "last_index_id=" << last_index_id;
    return true;
  }
  gaiadb_binlog_meta_to_binlog_info(binlog_info, &psm_binlog_info);
  gaiadb_binlog_meta_v2_to_binlog_info_v2(binlog_info_v2, &psm_binlog_info_v2);
  LOG(NOTICE) << "binlog_info pos:" << binlog_info->binlog_pos
              << ", file_id:" << binlog_info->binlog_file_id
              << ", sync_lsn:" << binlog_info->binlog_sync_lsn
              << ", index_id:" << last_index_id
              << ", start_lsn:" << binlog_info_v2->start_lsn
              << ", end_time:" << binlog_info_v2->end_time;
  return false;
}

// The starting LSN of the asynchronous replay thread. 
// start_lsn is the starting LSN of the corresponding index_id. 
// binlog_info is the information reported asynchronously.
bool gaiadb_get_binlog_in_redo_info_v2_start_lsn(
    uint32_t index_id, lsn_t &start_lsn, 
    BinlogInRedoInfo *binlog_info, lsn_t &async_start_lsn) {
  gaiadb::psm_client::BinlogInRedoMeta psm_binlog_info;
  if (psmcli->get_binlog_in_redo_info_v2_start_lsn(
      index_id, start_lsn, &psm_binlog_info, async_start_lsn)) {
    LOG(WARNING) << "psmcli->get_binlog_in_redo_info_v2_start_lsn failed. "
                 << "index_id=" << index_id
                 << ", start_lsn=" << start_lsn
                 << ", async_start_lsn=" << async_start_lsn;
    return true;
  }
  gaiadb_binlog_meta_to_binlog_info(binlog_info, &psm_binlog_info);
  return false;
}

void gaiadb_binlog_meta_to_binlog_info(
    BinlogInRedoInfo *binlog_info, gaiadb::psm_client::BinlogInRedoMeta *psm_binlog_info) {
  binlog_info->binlog_sync_lsn = psm_binlog_info->sync_lsn;
  binlog_info->binlog_file_id = psm_binlog_info->file_id;
  binlog_info->binlog_pos = psm_binlog_info->pos;
}

void gaiadb_binlog_meta_v2_to_binlog_info_v2(
    BinlogInRedoInfoV2 *binlog_info, gaiadb::psm_client::BinlogInRedoMetaV2 *psm_binlog_info) {
  binlog_info->start_lsn = psm_binlog_info->start_lsn;
  binlog_info->end_time = psm_binlog_info->end_time;
}

bool gaiadb_get_binlog_in_redo_info_v2_start_indexes(std::vector<uint32_t> &index_infos) {
  if (psmcli->get_binlog_in_redo_info_v2_start_indexes(index_infos)) {
    LOG(WARNING) << "psmcli->get_binlog_in_redo_info_v2_start_indexes failed."
                 << "index_infos_size=" << index_infos.size();
    return true;
  }
  return false;
}

BinlogInRedoInfo gaiadb_get_binlog_in_redo_info() {
  return BinlogInRedoInfo(binlog_in_redo_meta.sync_lsn,
                          binlog_in_redo_meta.file_id,
                          binlog_in_redo_meta.pos);
}

std::pair<bool, BinlogInRedoInfo> gaiadb_get_primary_binlog_in_redo_info() {
  gaiadb::psm_client::BinlogInRedoMeta primary_binlog_in_redo_meta;
  bool primary_binlog_in_redo_status = 
    gaiadb_data->get_primary_binlog_info_meta(&primary_binlog_in_redo_meta);
  return std::pair<bool, BinlogInRedoInfo> {primary_binlog_in_redo_status,
         BinlogInRedoInfo(primary_binlog_in_redo_meta.sync_lsn,
                          primary_binlog_in_redo_meta.file_id,
                          primary_binlog_in_redo_meta.pos)};
}


void gaiadb_set_async_binlog_start_lsn() {
  if (!psm_binlog_in_redo) {
    bir::bir_binlog_async_reinit(
      compute_node_info->apply_lsn, compute_node_info->apply_lsn);
    return;
  }
  std::vector<uint32_t> index_infos;
  // Collect the index information after the boss fight and find the oldest unuploaded index.
  gaiadb_get_binlog_in_redo_info_v2_start_indexes(index_infos);
  LOG(TRACE) << "gaiadb_get_binlog_in_redo_info_v2_start_indexes: " << index_infos.size();
  uint32_t last_bos_index_id = 0;
  for (auto index_id : index_infos) {
    char new_name[FN_REFLEN];
    build_new_binlog_file_name(new_name, index_id);
    if (!check_binlog_file_exist(new_name)) {
      last_bos_index_id = index_id;
      break;
    } else {
      MY_STAT stat_area;
      PSI_file_key m_key_file_log;
      mysql_file_stat(m_key_file_log, new_name, &stat_area, MYF(0));
      std::string filename = std::string(new_name);
      if (filename.find("./") == 0) {
        filename.erase(0, 2);
      }
      // Add time information
      bir::BinlogToBosTask binlog_to_bos(
        filename, stat_area.st_size, index_id, stat_area.st_mtime);
      bir::add_bir_binlog_to_bos_task(binlog_to_bos);
    }
  }
  lsn_t last_bos_start_lsn = 0;
  lsn_t async_start_lsn = 0;
  BinlogInRedoInfo binlog_info;
  gaiadb_get_binlog_in_redo_info_v2_start_lsn(
      last_bos_index_id, last_bos_start_lsn, &binlog_info, async_start_lsn);
  LOG(NOTICE) << "gaiadb_get_binlog_in_redo_info_v2_start_lsn: last_bos_index_id=" 
              << last_bos_index_id
              << ", last_bos_start_lsn=" << last_bos_start_lsn
              << ", binlog_info.binlog_file_id=" << binlog_info.binlog_file_id
              << ", binlog_info.binlog_pos=" << binlog_info.binlog_pos
              << ", binlog_info.binlog_sync_lsn=" << binlog_info.binlog_sync_lsn
              << ", async_start_lsn" << async_start_lsn;

  if (last_bos_index_id > binlog_info.binlog_file_id || last_bos_index_id == 0) {
    bir::bir_binlog_async_reinit(
      binlog_info.binlog_sync_lsn == 0 ? compute_node_info->apply_lsn : binlog_info.binlog_sync_lsn,
      compute_node_info->apply_lsn);
  } else {
    bir::bir_binlog_async_reinit(
      last_bos_start_lsn == 0 ? compute_node_info->apply_lsn : last_bos_start_lsn,
      compute_node_info->apply_lsn);
  }
}

bool gaiadb_update_purge_index(int32_t purge_time) {
  if (psmcli->update_purge_index_for_binlog(purge_time)) {
    LOG(WARNING) << "psmcli->update_purge_index failed";
    return true;
  }
  return false;
}

void gaiadb_bir_flusher() {
  bir::g_bir_async->bir_binlog_in_redo_flusher();
}

bool gaiadb_update_psm_binlog_switch_v2(bool switch_info) {
  auto ret = psmcli->update_primary_binlog_switch_v2(switch_info);
  if (ret) {
    ib_error(ER_GAIA_INIT_FAILED) << "psmcli->update_primary_binlog_switch_v2 failed."
      << ", switch_info=" << switch_info
      << ", ret=" << ret;
    return true;
  }
  return false;
}

bool gaiadb_get_psm_binlog_switch_v2(bool *switch_info) {
  auto ret = psmcli->get_primary_binlog_switch_v2(*switch_info);
  if (ret) {
    LOG(WARNING) << "psmcli->get_primary_binlog_switch_v2 failed."
                 << "ret=" << ret;
    return true;
  }
  return false;
}

bool gaiadb_update_block_write_switch(bool switch_info) {
  auto ret = psmcli->update_block_write_switch_for_binlog(switch_info);
  if (ret) {
    ib_error(ER_GAIA_INIT_FAILED) << "psmcli->update_block_write_switch failed."
      << ", switch_info=" << switch_info
      << ", ret=" << ret;
    return true;
  }
  return false;
}

bool gaiadb_get_block_write_switch(bool *switch_info) {
  auto ret = psmcli->get_block_write_switch_for_binlog(*switch_info);
  if (ret) {
    LOG(WARNING) << "psmcli->get_block_write_switch failed."
                 << "ret=" << ret;
    return true;
  }
  return false;
}

uint64_t get_gaia_apply_lsn() {
  if (srv_rpl_primary && log_sys) {
    return log_get_vdl(*log_sys);
  } else if(!srv_rpl_primary) {
    return std::min(rpl::get_apply_lsn(), rpl::get_flush_lsn());
  }
  return 0;
}

uint32_t gaiadb_get_new_index_id() {
  std::vector<uint32_t> index_infos;
  gaiadb_get_binlog_in_redo_info_v2_start_indexes(index_infos);
  uint32_t new_index_id = 0;
  if (!index_infos.empty()) {
    new_index_id = index_infos.back() + 1;
  }
  return new_index_id;
}

static std::string reverse_str(const std::string& s) {
  return std::string(s.rbegin(), s.rend());
}

bool gaiadb_get_bos_infos() {
  std::vector<gaiadb::psm_client::BosInfo> psm_bos_infos;
  auto ret = psmcli->get_bos_infos_for_binlog(psm_bos_infos);
  if (ret) {
    LOG(WARNING) << "psmcli->get_bos_infos failed."
                 << "ret=" << ret;
    return true;
  }
  bos_infos.clear();
  // Reverse AK, etc.
  for (auto &psm_bos_info : psm_bos_infos) {
    bos_infos.push_back(bos::BosInfo(
      reverse_str(psm_bos_info.ak), reverse_str(psm_bos_info.sk), 
      psm_bos_info.bucket, psm_bos_info.endpoint, 
      reverse_str(psm_bos_info.account_id), 
      psm_bos_info.current));
  }
  return false;
}

bool gaiadb_update_bos_infos(const std::vector<bos::BosInfo> &not_in_psm_bos_infos) {
  std::vector<gaiadb::psm_client::BosInfo> psm_bos_infos;
  for (auto &bos_info : not_in_psm_bos_infos) {
    // CMP uploads to PSM only occur when there is data in the local table but no data in the PSM. 
    // In this case, a hot active cluster exists, 
    // and the original host's binlog information needs to be transferred to the new PSM. 
    // Therefore, the BOS information is not current.
    gaiadb::psm_client::BosInfo psm_bos_info;
    psm_bos_info.ak = reverse_str(bos_info.ak);
    psm_bos_info.sk = reverse_str(bos_info.sk);
    psm_bos_info.bucket = bos_info.bucket;
    psm_bos_info.endpoint = bos_info.endpoint;
    psm_bos_info.account_id = reverse_str(bos_info.account_id);
    psm_bos_info.current = false;
    psm_bos_infos.push_back(psm_bos_info);
  }
  auto ret = psmcli->update_bos_infos_for_binlog(psm_bos_infos);
  if (ret) {
    LOG(WARNING) << "psmcli->update_bos_infos failed"
                 << "ret=" << ret;
    return true;
  }
  return false;
}

// Combine local boss information with boss information in PSM.
bool gaiadb_build_all_bos_infos(const bool update_psm, std::vector<bos::BosInfo> &out_infos) {
  static std::mutex build_mutex;
  std::lock_guard<std::mutex> lk(build_mutex);
  if (gaiadb_get_bos_infos()) {
    LOG(WARNING) << "gaiadb_get_bos_infos failed";
    return true;
  }
  std::vector<bos::BosInfo> table_bos_infos;
  std::vector<bos::BosInfo> not_in_psm_infos;
  std::vector<bos::BosInfo> not_in_table_infos;
  select_gaia_bos_info_table(table_bos_infos);

  auto bos_hash = [](const bos::BosInfo& info) {
    return std::hash<std::string>{}(info.ak) ^
            (std::hash<std::string>{}(info.sk) << 1) ^
            (std::hash<std::string>{}(info.bucket) << 2) ^
            (std::hash<std::string>{}(info.endpoint) << 3) ^
            (std::hash<std::string>{}(info.account_id) << 4);
  };
  auto bos_equal = [](const bos::BosInfo& a, const bos::BosInfo& b) {
    return a == b;
  };

  std::unordered_set<bos::BosInfo, decltype(bos_hash), decltype(bos_equal)>
      table_set(table_bos_infos.begin(), table_bos_infos.end(), 0, bos_hash, bos_equal),
      psm_set(bos_infos.begin(), bos_infos.end(), 0, bos_hash, bos_equal);

  for (const auto& bos_info : bos_infos) {
    if (table_set.find(bos_info) == table_set.end()) {
      not_in_table_infos.push_back(bos_info);
    }
  }
  for (const auto& bos_info : table_bos_infos) {
    if (psm_set.find(bos_info) == psm_set.end()) {
      not_in_psm_infos.push_back(bos_info);
    }
  }
  if (update_psm) {
    if (!not_in_psm_infos.empty()) {
      if (gaiadb_update_bos_infos(not_in_psm_infos)) {
        LOG(WARNING) << "gaiadb_update_bos_infos failed";
        return true;
      }
      bos_infos.insert(bos_infos.end(), not_in_psm_infos.begin(), not_in_psm_infos.end());
    }
  }
  if (!not_in_table_infos.empty()) {
    for (const auto &info : not_in_table_infos) {
      insert_gaia_bos_info_table(info);
    }
  }
  out_infos = bos_infos;
  return false;
}
