/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/gc.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/common.h"
#include "psvr/utils.h"
#include "psvr/log_block.h"
#include "psvr/space.h"
#include "psvr/model.h"
#include "psvr/thread_pool.hpp"
#include "psvr/segment.h"

namespace psvr {

class GcManager;
using GcManagerPtr = std::shared_ptr<GcManager>;

class GcManager : public Model<GcManager> {
public:
struct Context;

enum class Action {
    kRecoverPage = 1,
    kDisposeRecoveryPage,
    kGcLogBlock,
    kPreAppendFileGc,
    kAppendFileGc,
    kFinishGcLogBlock,
    kDblwrDump,
};

private:
struct ConditionTask;
struct ConditionGcQueue;

using ThreadPoolType = GroupThreadPoolExecutor<Context, thread::TaskContext>;
using ThreadPoolTypePtr = std::shared_ptr<ThreadPoolType>;
using ConditionThreadType = GroupConditionThread<ConditionTask, ConditionGcQueue>;
using ConditionThreadTypePtr = std::shared_ptr<ConditionThreadType>;

public:
    GcManager(ClientPtr client, ControlWeakPtr control);
    FUNC_MOCK ~GcManager() {
        if (!_stopped) {
            Stop();
        }
    }

    static const char* action2str(GcManager::Action action);

    virtual bool SetUp() override;
    virtual void TearDown() override;
    virtual void Join() override;

    bool IncOrDecThreadNum();

    FUNC_MOCK void Dispatch(SegmentPtr segment TRACE_FILE_LINE_DC, gaia_apply::lsn_t lsn);
    FUNC_MOCK bool Execute(Context* ctx);

    FUNC_MOCK void DumpDblwrBuf(SegmentPtr segment);

    int32_t in_wait_size() const { return _in_wait_size.load(std::memory_order_relaxed); }
private:
    void Expose();

    const ThreadPoolTypePtr& GetThreadPool(Context* ctx) const;
    void Schedule(Context* ctx TRACE_FILE_LINE_DC, uint64_t delay_us = 0, bool is_retry = false);
    void OnCompletion(Context* ctx);
    void SetCtxClientId(Context* ctx);

    void ConditionSchedule(SegmentPtr segment,
            Context* ctx, gaia_apply::lsn_t min_lsn, gaia_apply::lsn_t max_lsn);
    void ConditionFn(const ConditionTask& task);

    void DoAppendFileGc(SegmentPtr segment, LogBlockPtr log_block);
    void OnPreAppendFileGc(Context* ctx);
    void PreAppendFileGc(Context* ctx);
    void AppendFileGc(Context* ctx);

    void OnPreEvent(Context* ctx);
    void OnEvent(Context* ctx, pspb::Status* st);
    void RetryGcLogBlock(Context* ctx TRACE_FILE_LINE_DC, bool ok = false);

    void PreGcLogBlock(SegmentPtr segment, LogBlockPtr log_block);
    void GcLogBlock(Context* ctx);
    void FinishGcLogBlock(Context* ctx);

    void RecoverPage(Context* ctx);
    void OnRecoverPage(Context* ctx);
    void DisposeRecoveryPage(Context* ctx);

    void WakeupDblwr(SegmentPtr segment);
    void DblwrDump(Context* ctx);

private:
    uint32_t _thread_num;
    uint32_t _append_thread_num;
    uint32_t _prior_thread_num;
    uint32_t _condi_thread_num;
    uint32_t _dblwr_dump_thread_num;
    ThreadPoolTypePtr  _thread_pool;
    ThreadPoolTypePtr _append_thread_pool;
    ConditionThreadTypePtr _condition_thread_pool;
    ThreadPoolTypePtr _dblwr_dump_thread_pool;
    std::atomic<int32_t> _in_wait_size;
    // statistic
    StatLatency _stat_gc_task_lat;
    StatSize _stat_gc_task_dispatch_size;
    StatLatency _stat_gc_parallel_size;
    StatLatency _stat_gc_recover_lat;
    StatLatency _stat_gc_recover_rpc_lat;
    StatLatency _stat_gc_dblwr_dump_lat;
    StatBw _stat_gc_log_block_bw;
    StatSize _stat_gc_log_block_lsn_size;
    bvar::PassiveStatus<int32_t> _stat_gc_in_wait_count;
    StatQps _stat_gc_schedule_qps;
    StatQps _stat_gc_retry_qps;
    StatQps _stat_gc_ignore_qps;
    StatQps _stat_gc_interrupt_by_lsn_qps;
    StatQps _stat_gc_interrupt_by_space_extent_qps;
    StatQps _stat_gc_interrupt_by_recover_qps;
    StatQps _stat_gc_get_space_extent_in_advance_qps;
    StatSize _stat_gc_append_merge_size;
    StatSize _stat_gc_page_count;
    StatCount _stat_gc_real_page_count;
    StatCount _stat_gc_incomplete_lift_count;
    StatCount _stat_gc_record_err_count;
    StatCount _stat_gc_recover_err_count;
};

}

