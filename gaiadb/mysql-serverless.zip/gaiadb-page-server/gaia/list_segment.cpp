/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_segment.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_segment.h"
#include "psvr/psminfo.h"
#include "psvr/common.h"

namespace psvr {
namespace gaia {

int ListSegment::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (_segment_id == 0) {
        gaiapb::ListSegmentRequest request;
        gaiapb::ListSegmentResponse response;

        request.set_log_id(_log_id);
        if (_not_show_segments) {
            request.set_not_show_segments(true);
        }

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_segment, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                return Output(response);
            } else {
                LOG(WARNING) << node << " list segment failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("list failed, all nodes failed");
        return Output(response);
    } else {
        gaiapb::GetSegmentRequest request;
        gaiapb::GetSegmentResponse response;

        request.set_segment_id(_segment_id);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_segment, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                return Output(response);
            } else {
                LOG(WARNING) << node << " get segment failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("get failed, all nodes failed");
        return Output(response);
    }
}

int ListSegment::Format(const gaiapb::GetSegmentResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table_lsn(_raw_with_table, 2);
    table_lsn.AddRowsValue({"seg_lowest_gc_lsn", rsp.seg_lowest_gc_lsn()});
    table_lsn.AddRowsValue({"seg_multi_gc_lsn", rsp.seg_multi_gc_lsn()});
    table_lsn.AddRowsValue({"max_allocated_extent_no",
            get_unknown_type(rsp.has_max_allocated_extent_no(), rsp.max_allocated_extent_no(), "-1")});
    table_lsn.Display();

    Table table(_raw_with_table, 0);
    table.AddRowsWithName({
            "segment_id", "addr", "replica_id", "fetch_lsn", "apply_lsn", "checkpoint_lsn",
            "max_extent_num", "recovery_status", "state", "version", "zone",
            "seg_lowest_gc_lsn", "seg_multi_gc_lsn"
            });
    for (auto& page_server : rsp.page_servers()) {
        table.AddRowsValue({
                page_server.segment_id(),
                page_server.addr(),
                page_server.replica_id(),
                page_server.fetch_lsn(),
                page_server.apply_lsn(),
                page_server.checkpoint_lsn(),
                page_server.max_extent_num(),
                gaiadb::RecoveryStatus_Name(page_server.recovery_status()),
                gaiadb::NodeState_Name(page_server.state()),
                page_server.version(),
                GetZoneStr(page_server),
                });
    }
    table.Display();
    return 0;
}

int ListSegment::Format(const gaiapb::ListSegmentResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.segments_size()) {
        int64_t total_extent_num = 0;
        int64_t used_extent_num = 0;
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({
                "segment_id", "extent_num", "free_num", "usage_rate", "max_allocated_extent_no", "enabled",
                "task_id", "replicas(count)", "seg_lowest_gc_lsn", "seg_multi_gc_lsn"
            });
        for (auto& segment : rsp.segments()) {
            std::string replicas_str(std::to_string(segment.replica_addrs_size()));
            for (int32_t i = 0; i < segment.replica_addrs_size(); ++i) {
                replicas_str.append(base::string_printf(" %s", segment.replica_addrs(i).c_str()));
            }
            total_extent_num += segment.total_extent_num();
            used_extent_num += segment.total_extent_num() - segment.free_extent_num();
            table.AddRowsValue({
                    segment.segment_id(),
                    segment.total_extent_num(), segment.free_extent_num(),
                    RowPercent((segment.total_extent_num() - segment.free_extent_num()), segment.total_extent_num()),
                    get_unknown_type(segment.has_max_allocated_extent_no(), segment.max_allocated_extent_no(), ""),
                    segment.is_enabled(),
                    get_unknown_type(segment.has_task_id(), segment.task_id(), ""),
                    replicas_str,
                    segment.seg_lowest_gc_lsn(),
                    segment.seg_multi_gc_lsn()
                });
        }
        table.Display();
        if (_show_total) {
            Table table1(_raw_with_table, 2);
            table1.AddRowsValue({"total_size:", RowSize(total_extent_num * MBToByte(1lu), _human_readable)});
            table1.AddRowsValue({"used_size:", RowSize(used_extent_num * MBToByte(1lu), _human_readable)});
            table1.Display();
        }
    }
    if (rsp.has_total_extent_num()) {
        Table table2(_raw_with_table, 2);
        table2.AddRowsValue({"total_extent_num", rsp.total_extent_num()});
        table2.AddRowsValue({"used_extent_num", rsp.used_extent_num()});
        table2.AddRowsValue({"recycling_extent_num", rsp.recycling_extent_num()});
        table2.Display();
    }
    return 0;
}

}
}
