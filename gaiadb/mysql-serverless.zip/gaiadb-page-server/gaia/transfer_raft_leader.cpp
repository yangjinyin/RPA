/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/transfer_raft_leader.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <raft/configuration.h>
#include "gaia/transfer_raft_leader.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int TransferRaftLeader::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_group_id.empty()) {
        print_error("miss --group-id");
        return 1;
    }

    if (_new_leader_id.empty()) {
        print_error("miss --leader-id");
        return 1;
    }

    raft::PeerId new_leader_id;
    int ret = new_leader_id.parse(_new_leader_id);
    if (ret != 0) {
        print_error("error --leader-id, like, ip:port:idx");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Transfer raft leader to: %s?", _new_leader_id.c_str());
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    raft::GetLeaderRequest request;
    raft::GetLeaderResponse response;
    request.set_group_id(_group_id);
    raft::PeerId leader_id;
    for (auto& node : nodes) {
        //request.set_peer_id();
        _client.Call(_log_id, node, &raft::CliService_Stub::get_leader, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            ret = leader_id.parse(response.leader_id());
            if (ret != 0) {
                LOG(WARNING) << node << " leader parse failed, " << response.leader_id();
                print_error("leader parse failed, %s", response.leader_id().c_str());
                return 1;
            }
            break;
        } else {
            LOG(WARNING) << node << " get leader failed, " << status;
        }
    }

    if (leader_id.is_empty()) {
        print_error("get leader failed");
        return 1;
    }

    raft::TransferLeaderRequest request2;
    raft::TransferLeaderResponse response2;

    request2.set_group_id(_group_id);
    request2.set_leader_id(leader_id.to_string());
    request2.set_peer_id(_new_leader_id);

    _client.Call(_log_id, leader_id.addr, &raft::CliService_Stub::transfer_leader, &request2, &response2,
            nullptr, &status, _timeout_ms);
    if (status.IsOk()) {
        return Output(response2);
    } else {
        LOG(WARNING) << leader_id.addr << " transfer failed, " << status;
        print_error("transfer leader failed");
        return 1;
    }
}

int TransferRaftLeader::Format(const raft::TransferLeaderResponse&) {
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"log_id:", _log_id});
    table.AddRowsValue({"code:", "ok"});
    table.Display();
    return 0;
}

}
}
