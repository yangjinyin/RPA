/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_page_server_store.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class UpdatePageServerStore : public Command {
public:
    UpdatePageServerStore() {
        SetName("update-ps-store");
        SetDesc("update a store or all store on page server (change capacity or size)");
        SetDescCn("更新存储服务器上的磁盘配置 (修改容量或大小)");
        AddClusterAndNodeOptions();

        AddRequiredArgOption("id", &_long_opt_val, kOptMax + 1,
                "the store id of we want to update",
                kint32_t, kGroup3Scope);
        AddRequiredArgOption("path", &_long_opt_val, kOptMax + 2,
                "check if the store path match",
                kstring, kGroup3Scope);
        AddRequiredArgOption("capacity", &_long_opt_val, kOptMax + 3, "set store capacity", kint32_t);
        AddRequiredArgOption("size", &_long_opt_val, kOptMax + 4, "set store free size", kstring);
        AddNoArgOption("all", &_long_opt_val, kOptMax + 5, "all stores", kGroup2Scope);
        AddNoArgOption("clear-io-error", &_long_opt_val, kOptMax + 6, "clear io error count");

        AddExample("-a <ip> -p <port> --id 1 --path \"/data/store0/data\" --capacity 1024");
        AddExample("-a <ip> -p <port> --id 1 --path \"/data/store0/data\" --size 1024000000");
        AddExample("-a <ip> -p <port> --id 1 --path \"/data/store0/data\" --capacity -1 --size -1");
        AddExample("-a <ip> -p <port> --all --capacity 1024");
        AddExample("-a <ip> -p <port> --all --size 1024000000");
        AddExample("-a <ip> -p <port> --all --capacity -1 --size -1");
        AddExample("-a <ip> -p <port> --all --clear-io-error");
        AddExample("--cluster-addr <bns://xx> --all --capacity 1024");
    }
    virtual ~UpdatePageServerStore() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'C':
            _cluster_addr = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _store_id = std::strtol(opt, NULL, 10);
                break;
            case kOptMax + 2:
                _store_path = opt;
                break;
            case kOptMax + 3:
                _store_capacity = std::strtoll(opt, NULL, 10);
                break;
            case kOptMax + 4:
                _store_size = std::strtoll(opt, NULL, 10);
                break;
            case kOptMax + 5:
                _update_all = true;
                break;
            case kOptMax + 6:
                _clear_io_error = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;
private:
    int RunOne(const base::EndPoint& node);
    int RunCluster();

    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::UpdateStoreResponse& rsp);
    int Format(const pspb::UpdateAllStoreResponse& rsp);

private:
    std::string _cluster_addr {};
    std::string _address {};
    int32_t _port {0};
    int32_t _store_id {-1};
    bool _update_all {false};
    bool _clear_io_error {false};
    std::string _store_path {};
    int64_t _store_capacity {-2};
    int64_t _store_size {-2};
};

}
}
