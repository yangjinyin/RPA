/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/fetch.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/common.h"
#include "psvr/model.h"
#include "psvr/quota.h"
#include "psvr/segment.h"
#include "psvr/thread_pool.hpp"

namespace psvr {

class Fetcher;
using FetcherPtr = std::shared_ptr<Fetcher>;
using FetcherWeakPtr = std::weak_ptr<Fetcher>;

struct FetcherType {
    static bool IsSingleSegment();
    static bool IsBatchByAll();
    static bool IsBatchByCluster();

    static int32_t SingleSegment();
    static int32_t BatchByAll();
    static int32_t BatchByCluster();
};

class Fetcher : public Model<Fetcher> {
public:
struct Context;

enum class Action : uint32_t {
    kGetLogService = 1,
    kDisposeLogService,
    kFetchRedoLog,
    kDisposeLogBlock,
    kBatchMonitor,
    kBatchGetLogService,
    kBatchDisposeLogService,
    kBatchFetchRedoLog,
    kBatchDisposeLogBlock,
    kCheckReopenSegment,
    kPreReopenSegment,
    kReopenSegment,
    kRestartSegment,
    kAppendRecover,
    kGetRedoRecLog,
    kDisposeRedoRecLog,
};

private:
using ThreadPoolType = ThreadPoolExecutor<Context, thread::TaskContext>;
using ThreadPoolTypePtr = std::shared_ptr<ThreadPoolType>;

class BatchManager {
public:
    BatchManager() : _version(0), _batch_clusters() {}
    FUNC_MOCK ~BatchManager() {}

    bool Add(SegmentPtr segment, int32_t* batch_idx, uint64_t* version);
    FUNC_MOCK bool Exist(ClusterPtr cluster, int32_t batch_idx,
            uint64_t* version, rwlock_t** shared_mutex,
            rwlock_t** batch_shared_mutex);
    FUNC_MOCK int32_t Get(ClusterPtr cluster, int32_t batch_idx,
            std::list<SegmentWeakPtr>* segments, uint64_t* version);
    FUNC_MOCK bool RemoveNoLock(ClusterPtr cluster, SegmentPtr segment);

    void BuildTrims();
    void AddTrimCluster(ClusterPtr cluster, uint64_t version);
    bool TrimFirst(std::string* cluster_id, uint64_t* version);
    void TrimPop(const std::string& cluster_id, uint64_t version);
    int32_t TrimBatch(const std::string& cluster_id, uint64_t version, uint64_t* new_version);

private:
    void AddTrimCluster(const std::string& cluster_id, uint64_t version);

    struct Member {
        int32_t size;
        std::map<uint32_t, SegmentWeakPtr> segments;
        Member() : size(0), segments() {}
        ~Member() {}
    };
    struct Batch {
        int32_t size;
        uint64_t version;
        ClusterWeakPtr cluster;
        std::vector<std::shared_ptr<Member>> members;
        rwlock_t shared_mutex;
        Batch(uint64_t v, ClusterPtr c) : size(0), version(v), cluster(c), members() {}
        ~Batch() {}
    };
    struct Trim {
        const std::string cluster_id;
        uint64_t version;
        Trim (const std::string& id, uint64_t v) : cluster_id(id), version(v) {}
        ~Trim() {}

        bool operator< (const Trim& lhs) const {
            if (cluster_id == lhs.cluster_id) {
                return version < lhs.version;
            } else {
                return cluster_id < lhs.cluster_id;
            }
        }
    };

    uint64_t _version;
    std::map<std::string, std::shared_ptr<Batch>> _batch_clusters;
    rwlock_t _shared_mutex;

    std::set<Trim> _trims;
    rwlock_t _trims_shared_mutex;
};

public:
    Fetcher(ClientPtr client, ControlWeakPtr control);
    FUNC_MOCK ~Fetcher() {
        if (!_stopped) {
            Stop();
        }
    }

    static const char* action2str(Fetcher::Action action);

    virtual bool SetUp() override;
    virtual bool PrepareTask() override;
    virtual void TearDown() override;
    virtual void Join() override;

    bool IncOrDecThreadNum();

    FUNC_MOCK void Dispatch(SegmentPtr segment TRACE_FILE_LINE_DC, bool force_single = false);
    FUNC_MOCK void Wakeup(SegmentPtr segment);
    FUNC_MOCK bool Execute(Context* ctx);

    FUNC_MOCK void DoReopenSegment(SegmentPtr segment TRACE_FILE_LINE_DC,
            const pspb::ReopenSegmentRequest* request,
            pspb::ReopenSegmentResponse* response,
            ggpb::Closure* done);

private:
    FUNC_MOCK void DoReopenSegment(SegmentPtr segment TRACE_FILE_LINE_DC,
            bool force = false, bool not_recover = false);
    void SetCtxClientId(Context* ctx);

    void StartFetchRedoLog(Context* ctx,
            const std::vector<gaiadb::common::PeerZone>& new_nodes, uint32_t idx = 0);
    void BatchStartFetchRedoLog(Context* ctx,
            const std::vector<gaiadb::common::PeerZone>& new_nodes, uint32_t idx = 0);
    void Expose();

    const ThreadPoolTypePtr& GetThreadPool(Context* ctx) const;
    void Schedule(Context* ctx TRACE_FILE_LINE_DC, uint64_t delay_us = 0, bool is_retry = false);
    void OnCompletion(Context* ctx);

    void BatchMonitor(Context* ctx);
    void BatchGetLogService(Context* ctx);
    void OnBatchGetLogService(Context* ctx, RpcBatchGetLogServiceCtx* rpc_ctx);
    void BatchDisposeLogService(Context* ctx);
    void BatchFetchRedoLog(Context* ctx);
    void OnBatchFetchRedoLog(Context* ctx);
    void BatchDisposeLogBlock(Context* ctx);

    void GetLogService(Context* ctx);
    void OnGetLogService(Context* ctx, RpcBatchGetLogServiceCtx* rpc_ctx);
    void DisposeLogService(Context* ctx);

    void FetchLogBlock(Context* ctx);
    void OnFetchLogBlock(Context* ctx);
    void DisposeLogBlock(Context* ctx);

    void AppendRecover(Context* ctx);

    void OnGetPeersEvent(Context *ctx);
    void GetRedoRecLog(Context *ctx);
    void OnFetchRedoRecLog(Context* ctx);
    void DisposeRedoRecLog(Context *ctx);

    bool CheckQuota(SegmentPtr segment, ClusterPtr cluster,
            bool is_recover_redo, int64_t quota_size, uint32_t& quota_flags);
    bool EnableQuota(int64_t quota_size, bool is_recover_redo) const {
        return !is_recover_redo ? _fetch_quota->Enable(quota_size) : _recover_redo_quota->Enable(quota_size);
    }
    bool GetQuota(int64_t quota_size, bool is_recover_redo) {
        return !is_recover_redo ? _fetch_quota->Acquire(quota_size) : _recover_redo_quota->Acquire(quota_size);
    }
public:
    void PutQuota(int64_t quota_size, bool is_recover_redo) {
        return !is_recover_redo ? _fetch_quota->Release(quota_size) : _recover_redo_quota->Release(quota_size);
    }
private:

    void CheckReopenSegment(Context* ctx);
    void PreReopenSegment(Context* ctx);
    void OnSetReplicaRecovery(Context* ctx, RpcSetReplicaRecovery* rpc_ctx);
    void ReopenSegment(Context* ctx);
    void OnLoadSegment(Context* ctx, RpcGetPageServerCtx* rpc_ctx);
    void RestartSegment(Context* ctx);

private:
    std::shared_ptr<Quota> _fetch_quota;
    std::shared_ptr<Quota> _recover_redo_quota;
    uint32_t _thread_num;
    uint32_t _append_thread_num;
    ThreadPoolTypePtr _thread_pool;
    ThreadPoolTypePtr _append_recover_thread_pool;
    // for batch fetch
    std::shared_ptr<BatchManager> _batch_manager;
    // statistic
    StatLatency _stat_batch_fetch_disposer_lat;
    StatLatency _stat_fetch_task_lat;
    StatLatency _stat_fetch_rpc_lat;
    StatLatency _stat_fetch_rpc_callback_cost_lat;
    StatLatency _stat_fetch_rpc_disposer_wait_lat;
    StatLatency _stat_fetch_redo_rec_log_lat;
    StatLatency _stat_fetch_append_recover_lat;
    StatSize _stat_fetch_log_buf_size;
    StatSize _stat_fetch_log_lsn_size_kb;
    StatSize _stat_fetch_size_per_node;
    StatQps _stat_fetch_empty_qps;
    StatQps _stat_fetch_by_server_push_qps;
    StatCount _stat_fetch_error_count;
    StatCount _stat_fetch_redo_rec_log_error_count;
    // CheckQuota failures, split by the layer that hit the limit
    StatCount _stat_fetch_quota_fail_seg_count;
    StatCount _stat_fetch_quota_fail_cluster_count;
    StatCount _stat_fetch_quota_fail_global_count;
};

}
