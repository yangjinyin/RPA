/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_log_service.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"
#include <gaiadb/proto/log_service/lsrv_message_service.pb.h>
#include <gaiadb/proto/log_service/lsrv_error_code.pb.h>

namespace psvr {
namespace gaia {

class ListLogService : public Command {
public:
    ListLogService() {
        SetName("list-log-service");
        SetDesc("list all or one log service information in cluster");
        SetDescCn("列出集群中所有或指定日志服务的信息");

        AddPsmClusterOption();
        AddNoArgOption("with-status", &_long_opt_val, kOptMax + 1, "show node more information", kGroup3Scope);
        AddRequiredArgOption("addr", &_long_opt_val, kOptMax + 2,
                "show information if the specified node exists", kip_port, kGroup2Scope);

        AddExample("--manager-address \"bns://xxx\"");
        AddExample("--manager-address \"bns://xxx\" --addr 127.0.0.1:8888");
        AddExample("--manager-address \"bns://xxx\" --with-status");
        AddExample("--manager-address \"bns://xxx\" --addr 127.0.0.1:8888 --with-status");
    }
    virtual ~ListLogService() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _with_status = true;
                break;
            case kOptMax + 2:
                _addr = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::GetLogServiceResponse& rsp);
    int Format(const gaiapb::LogServiceBatchGetResponse& rsp);
    int Format(const log_service::lsrv_status_response& rsp);
    int Format(const log_service::batch_lsrv_status_response& rsp);

private:
    std::string _manager_address {};
    std::string _addr {};
    bool _with_status {false};
};

}
}
