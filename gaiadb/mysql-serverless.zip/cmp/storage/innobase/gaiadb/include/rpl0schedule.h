/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file include/rpl0schedule.h
 Gaiadb redo log replication

 Created 01/16/2023
 Authors: wanglonglong01@baidu.com
 *******************************************************/

#pragma once

#include <cstdint>
#include <list>
#include <map>
#include "base/macros.h"
#include "rpl0assemble.h"
#include <boost/lockfree/spsc_queue.hpp>

namespace rpl {

class RplScheduler;
class RplAssembly;

extern RplScheduler *g_rpl_scheduler;

extern void *update_lowest_lsn(void *);
extern void *rpl_recycle(void *);

class RplScheduler {
 private:
  RplScheduler() {}

  struct GcJob {
    RplAssembly *asmb{nullptr};
    uint64_t time{0};
  };

 public:
  using TaskFunc = void *(*)(void *);
  static constexpr uint64_t SCHEDULE_PRECISION = 5;

  struct ScheduleTask {
    TaskFunc task_func;
    uint64_t interval;
    std::string task_name;
  };

  using Tasks = std::list<ScheduleTask>;

 public:
  static RplScheduler &get_instance();
  // should be called before RplScheduler.routine()
  void register_task(const std::string &task_name, uint64_t interval,
                     TaskFunc task_func);

  void add_gc_job(RplAssembly *asmb);
  void routine();

 private:
  DISALLOW_COPY_AND_ASSIGN(RplScheduler);
  uint64_t start_time_{0};
  std::map<std::string, ScheduleTask> job_conf_;
  std::map<uint64_t, Tasks> job_timer_;
  boost::lockfree::spsc_queue<GcJob *, boost::lockfree::capacity<RPL_ASMB_BUCKETS>>
      gc_queue_;
};

}  // namespace rpl

