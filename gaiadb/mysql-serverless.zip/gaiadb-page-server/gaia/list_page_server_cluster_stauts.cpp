/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server_cluster_stauts.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_page_server_cluster_stauts.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ListPageServerClusterStatus::Run() {
    if (_cluster_addr.empty() && (_address.empty() || _port < 1)) {
        print_error("miss --cluster-addr or (--address and --port)");
        return 1;
    }

    pspb::ListClusterStatusRequest request;
    request.set_log_id(_log_id);
    if (_sort == "segment") {
        request.set_sort_segment_num(true);
    } else if (_sort == "redo") {
        request.set_sort_redo_size(true);
    } else if (_sort == "rbio") {
        request.set_sort_rbio_size(true);
    } else if (_sort == "write") {
        request.set_sort_write_size(true);
    } else {
        print_error("--sort empty or unsupported");
        return 1;
    }

    RpcStatus status;
    pspb::ListClusterStatusResponse response;

    if (_cluster_addr.empty()) {
        base::EndPoint node;
        int ret = base::str2endpoint(_address.c_str(), _port, &node);
        if (ret != 0) {
            print_error("--address and --port convert to endpoint error");
            return 1;
        }

        _client.Call(_log_id, node, &pspb::QueryService_Stub::ListClusterStatus, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }
        return Output(response);
    }

    PsmInfo psm_info(_cluster_addr, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--cluster-addr parse failed, cant get server list from it");
        return 1;
    }

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &pspb::QueryService_Stub::ListClusterStatus, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " list ps cluster status failed, " << status;
        }
    }
    response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
    response.mutable_status()->set_msg("list failed, all nodes failed");
    return Output(response);
}

int ListPageServerClusterStatus::Format(const pspb::ListClusterStatusResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table2(_raw_with_table, 0);
    table2.AddRowsWithName({
            "cluster", "segment_num", "redo_records_num", "rbio_page_num", "write_page_num"});
    for (int32_t i = 0; i < rsp.clusters_size(); ++i) {
        const auto& cluster = rsp.clusters(i);
        table2.AddRowsValue({
                cluster.cluster_id(),
                get_unknown_type(cluster.has_segment_num(), cluster.segment_num(), "-"),
                get_unknown_type(cluster.has_redo_size(), cluster.redo_size(), "-"),
                get_unknown_type(cluster.has_rbio_size(), cluster.rbio_size(), "-"),
                get_unknown_type(cluster.has_write_size(), cluster.write_size(), "-")
                });
    }
    table2.Display();
    return 0;
}

}
}
