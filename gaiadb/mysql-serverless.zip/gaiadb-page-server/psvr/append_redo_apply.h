/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/append_redo_apply.h
* @author yukeyong@baidu.com
* @brief Append file redo log iterator for page apply
*/

#pragma once

#include <cstdlib>
#include <memory>
#include <new>

#include "psvr/append_block.h"
#include "psvr/append_file.h"
#include "psvr/log_block.h"
#include "psvr/page.h"

namespace psvr {

class AppendLogRecordIterator : public LogRecordIteratorInterface {
public:
    AppendLogRecordIterator(AppendDBEnginePtr append_db_engine, int64_t log_id,
            uint64_t physical_offset,
            gaia_apply::lsn_t start_lsn,
            gaia_apply::lsn_t apply_end_lsn,
            AppendReadBuf* read_buf = nullptr);
    ~AppendLogRecordIterator() override {
        ResetRecord();
    }

    db::Status Init();

    bool Valid() const override;
    void Next() override;
    const LogRecord& Get() const override;
    const db::Status& Status() const override { return _status; }

private:
    db::Status LoadNextRecord();
    db::Status LoadNextRedoBlock();
    void ClearRedoBlock();
    void ResetRecord();
    LogRecord* MutableRecord();
    const LogRecord* MutableRecord() const;
    db::Status ParseNextRecord();
    bool IsCurrentRecordApplicable(gaia_apply::mlog_id_t type,
            gaia_apply::lsn_t rec_start_lsn,
            gaia_apply::lsn_t rec_end_lsn,
            gaia_apply::space_id_t space_id,
            gaia_apply::page_no_t page_no,
            uint64_t* physical_offset);
    bool GetCurrentRecordPhysicalOffset(gaia_apply::space_id_t space_id,
            gaia_apply::page_no_t page_no,
            uint64_t* physical_offset);

private:
    AppendDBEnginePtr _append_db_engine;
    AppendReadBuf* _read_buf;
    const int64_t _log_id;
    const uint64_t _physical_offset;
    const gaia_apply::lsn_t _start_lsn;
    const gaia_apply::lsn_t _apply_end_lsn;
    db::Status _status;
    alignas(LogRecord) unsigned char _record_storage[sizeof(LogRecord)];
    bool _record_initialized;
    std::unique_ptr<char, decltype(&std::free)> _redo_buf;
    std::unique_ptr<gaiadb::common::MemArena> _offset_cache_arena;
    std::unique_ptr<KeyValueCache<uint64_t, uint32_t>> _offset_cache;
    db::LogHeader _log_header;
    base::Slice _key;
    base::Slice _value;
    gaia_apply::byte* _redo_ptr;
    gaia_apply::byte* _redo_end;
    gaia_apply::byte* _redo_scan_ptr;
    gaia_apply::lsn_t _next_seek_lsn;
    gaia_apply::lsn_t _last_rec_end_lsn;
    uint64_t _fno;
    uint64_t _offset;
    bool _valid;
    bool _finished;
    size_t _returned_size;
};

} // namespace psvr
