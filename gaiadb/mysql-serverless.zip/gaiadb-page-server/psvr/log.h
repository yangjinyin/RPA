/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/log.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <stdarg.h>
#include <stdint.h>
#include <string>
#include <cstring>
#include <base/comlog_sink.h>
#include <spdlog/spdlog.h>
#include <spdlog/async.h>

#define gettid() syscall(__NR_gettid)

namespace psvr {

class LogSink : public logging::LogSink {
public:
    static LogSink* GetInstance();

    int Setup(const logging::ComlogSinkOptions* options);
    void Stop() {
        _disable = true;
        spdlog::shutdown();
    }

    void set_disable(bool status) {
        _disable = status;
    }

    virtual bool OnLogMessage(int severity, const char* file, int line,
            const base::StringPiece& log_content) override;

public:
    LogSink() {}
    virtual ~LogSink() {}
private:
    logging::ComlogSinkOptions _options;
    bool _disable {false};
    std::shared_ptr<spdlog::details::thread_pool> _spd_thread_pool;
    std::shared_ptr<spdlog::logger> _spd_logger;
};

}

