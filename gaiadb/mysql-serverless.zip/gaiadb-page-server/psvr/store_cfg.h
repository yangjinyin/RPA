/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/store_cfg.hpp
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/common.h"

namespace psvr {

extern const char* kMetaFileName;
extern const char* kDataFileName;
extern const char* kCompressFileName;

extern const std::string kTmpDirName;
extern const std::string kTrashSegmentPrefixName;
extern const std::string kPunchHoleFile;

extern const std::string kAppendFilePath;
extern const std::string kAppendCheckPointName;
extern const std::string kDblwrFilePath;

class StoreCfg {
public:
    using ParseFn = std::function<bool(int32_t, const std::string&, const std::string&, bool, int64_t, int64_t)>;
    using IterSegFn = std::function<void(const std::string& seg_dir)>;
    using IterClsFn = std::function<void(const std::string& clus_dir, uint32_t seg_count)>;
public:

    static bool Parse(const std::string& cfg, ParseFn& fn);

    static bool IteratorSegments(const std::string& path, IterSegFn& iter_seg_fn, IterClsFn& iter_cluster_fn);
};


}
