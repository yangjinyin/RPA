/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_log_service_manager.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/update_log_service_manager.h"

namespace psvr {
namespace gaia {

int UpdateLogServiceManager::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    RpcStatus status;
    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    lspb::lsrv_modify_manager_request request;
    lspb::lsrv_modify_manager_response response;
    request.set_manager_address(_manager_address);

    if (!_force) {
        bool cf_ret = execute_confirm("Update log service[%s:%d] manager?", _address.c_str(), _port);
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    _client.Call(_log_id++, node, &lspb::LogServiceService_Stub::modify_manager, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(lspb::GIE_TIMEOUT);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int UpdateLogServiceManager::Format(const lspb::lsrv_modify_manager_response& rsp) {
    SHOW_LS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
