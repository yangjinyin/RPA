#include "bir0async_binlog.h"
#include <ctype.h>
#include <base/base64.h>
#include <openssl/hmac.h>
#include <baidu/rpc/uri.h>
#include <baidu/rpc/details/http_message.h>
#include <openssl/aes.h>
#include "gaiadb/common/global_flags.h"
#include "rpl0rpl.h"
#include "rpl0parse.h"
#include "gaiadb/redo_fetch/fetch_mdc_object.h"
#include "gaiadb/redo_fetch/fetch_mdc_utils.h"

namespace bir {

// fetch nfs redo
void BirAsyncBinlog::nfs_get_redo(gaiadb::redo_fetch::GetObjectContext* rpc_ctx) {
  // set offset
  // API: https://cloud.baidu.com/doc/BOS/s/xkc5pcmcj
  lsn_t start_lsn = fetch_lsn_;
  lsn_t request_lsn = ut_uint64_align_down(start_lsn, OS_FILE_LOG_BLOCK_SIZE);
  const uint64_t lz_start_lsn = gaiadb::redo_fetch::calc_lz_start_lsn(request_lsn);
  const uint64_t offset = request_lsn - lz_start_lsn;
  rpc_ctx->offset = offset;

  // get or open nfs
  const auto& object = rpc_ctx->object;
  auto nfs = nfs_caches.Get(object);
  if (!nfs) {
    std::string file = rpc_ctx->file_path + "/" + object;
    int32_t fd = open(file.c_str(), O_RDONLY, S_IRUSR | S_IWUSR);
    if (fd < 0) {
      LOG(WARNING) << "fail to open file,"
                   << " file:[" << file
                   << "] " << strerror(errno);
      return;
    }
    nfs.reset(new gaiadb::redo_fetch::Nfs);
    nfs->fd = fd;
    nfs->name = object;
    nfs = nfs_caches.Put(object, nfs);
  }

  if (!nfs) {
    LOG(WARNING) << "fail to get nfs";
    return;
  }

  void* buf = std::malloc(rpc_ctx->fetch_size);
  if (!buf) {
    LOG(WARNING) << "get nfs malloc buf failed,"
                 << " size:[" << rpc_ctx->fetch_size
                 << "]";
    return;
  }

  std::shared_ptr<nullptr_t> buf_guard(nullptr, [&buf](nullptr_t) {
        std::free(buf);
    });

  ssize_t read_size = pread(nfs->fd, buf, rpc_ctx->fetch_size, rpc_ctx->offset);
  if (read_size <= 0) {
    LOG(WARNING) << "read nfs failed," << strerror(errno);
    nfs_caches.Erase(nfs->name);
    return;
  }

  LOG(NOTICE) << " fetch redo from nfs,"
              << " file_path:[" << rpc_ctx->file_path
              << "] length:[" << rpc_ctx->fetch_size
              << "] offset:[" << rpc_ctx->offset
              << "] read_size:[" << read_size
              << "] align_fetch_lsn:[" << fetch_lsn_
              << "]";

  std::string redo_data(static_cast<char*>(buf), read_size);
  uint32_t real_block_num = rpc_ctx->fetch_size / OS_FILE_LOG_BLOCK_SIZE;

  if (rpc_ctx->tail_redo.size()) {
    real_block_num++;
    redo_data.append(rpc_ctx->tail_redo);
  }

  copy_to_fetch_log_buf(
    redo_data.c_str(), real_block_num, log_get_vdl(*log_sys), 0);
}

}
