/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/segment_server.cpp
* @author
* @brief
*/

#include <base/comlog_sink.h>
#include <gaiadb/common/types.h>
#include <gaiadb/utils/utils.h>
#include <gaiadb/psm_client/config.h>
#include "psvr/config.h"
#include "psvr/control_context.h"
#include "psvr/log.h"
#include "psvr/segment_server.h"

namespace psvr {

/** Init comlog */
bool init_logger() {
    // Base on struct ComlogSinkOptions from 'base/comlog_sink.h';
    logging::ComlogSinkOptions options;
    /* true - "AFILE", false - "FILE" */
    options.async = FLAGS_psvr_comlog_enable_async;
    /* Use F W N T instead of FATAL WARNING NOTICE TRACE for shorter prefixes */
    options.shorter_log_level = false;
    /* The directory path(could be absolute or relative path) and name to put
     * comlog file. */
    options.log_dir = FLAGS_psvr_comlog_path;
    options.process_name = FLAGS_psvr_comlog_process;
    /* Print VLOG(n) as WARNING instead of TRACE since many online servers */
    options.print_vlog_as_warning = false;
    /* Split Comlog type:
     * COMLOG_SPLIT_TRUNCT[default]/COMLOG_SPLIT_SIZECUT/COMLOG_SPLIT_DATECUT */
    options.split_type = static_cast<logging::ComlogSplitType>(FLAGS_psvr_comlog_split_type);
    /* Remove oldest cutoff log files when they exceed so many megabytes(roughly)
     */
    options.quota_size = FLAGS_psvr_comlog_quota_size;
    options.cut_size_megabytes = FLAGS_psvr_comlog_cut_size_mb;
    options.quota_day = FLAGS_psvr_comlog_quota_day;
    options.enable_wf_device = FLAGS_psvr_comlog_enable_wf;
    //if (logging::ComlogSink::GetInstance()->Setup(&options) != 0) {
        //return false;
    //}
    //logging::SetLogSink(logging::ComlogSink::GetInstance());
    if (LogSink::GetInstance()->Setup(&options) != 0) {
        return false;
    }
    logging::SetLogSink(LogSink::GetInstance());
    LOG(NOTICE) << "PSVR comlog_sys start!";
    return true;
}

MultiSegment::MultiSegment() : _stopped(false) {
    _client.reset(new Client());
    _control.reset(new Control(_client, true));
    _control->Init();
}

MultiSegment::~MultiSegment() {
    if (!_stopped) {
        Stop();
    }
}

bool MultiSegment::Start() {
    if (FLAGS_psvr_rbio_server_port < 1) {
        LOG(ERROR) << "port not set? --psvr_rbio_server_port invalid";
        return false;
    }
    if (FLAGS_psvr_store_config_file.empty()) {
        LOG(ERROR) << "--psvr_store_config_file not set";
        return false;
    }
    if (!std::filesystem::exists(FLAGS_psvr_store_config_file)) {
        LOG(ERROR) << "not exists store config file:" << FLAGS_psvr_store_config_file;
        return false;
    }
    if (SignalRegister() != 0) {
        LOG(ERROR) << "signal register failed";
        return false;
    }
    if (!_control->Start()) {
        LOG(ERROR) << "control start failed";
        return false;
    }
    return true;
}

void MultiSegment::Stop() {
    _stopped = true;
    _control->Stop();
    //LogSink::GetInstance()->Stop();
}

OneSegment::OneSegment() : _stopped(false) {
    _client.reset(new Client());
    _control.reset(new Control(_client, false));
    _control->Init();
}

OneSegment::~OneSegment() {
    if (!_stopped) {
        Stop();
    }
}

bool OneSegment::Start() {
    if (gaiadb::psm_client::FLAGS_manager_address.empty()) {
        LOG(ERROR) << "--manager_address not set";
        return false;
    }
    if (FLAGS_psvr_page_store_dir.empty()) {
        LOG(ERROR) << "store dir empty, --psvr_page_store_dir not set";
        return false;
    }
    if (FLAGS_psvr_rbio_server_port < 1) {
        LOG(ERROR) << "port not set? --psvr_rbio_server_port invalid";
        return false;
    }
    if (!std::filesystem::exists(FLAGS_psvr_page_store_dir)) {
        if (!std::filesystem::create_directories(FLAGS_psvr_page_store_dir)) {
            LOG(ERROR) << "create store dir failed, " << FLAGS_psvr_page_store_dir;
            return false;
        }
        const auto store_parent_path =
                std::filesystem::path(FLAGS_psvr_page_store_dir).parent_path();
        db::Status status = db::sync_directoryx(store_parent_path.c_str());
        if (!status.IsOk()) {
            LOG(ERROR) << "sync store parent dir failed, dir:[" << store_parent_path
                << "], " << status;
            return false;
        }
    }
    if (SignalRegister() != 0) {
        LOG(ERROR) << "signal register failed";
        return false;
    }
    if (!_control->Start()) {
        LOG(ERROR) << "control start failed";
        return false;
    }

    // init segment
    auto* ctx = new Control::Context(Control::Action::kInitSegment);
    ctx->log_id = get_log_id();
    _control->Dispatch(ctx);
    return true;
}

void OneSegment::Stop() {
    _stopped = true;
    _control->Stop();
    //LogSink::GetInstance()->Stop();
}


}
