/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_recover.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/recover_context.h"
#include "test/mock_thread_pool.h"
#include "test/mock_recover.h"
#include "test/mock_dbengine.h"
#include "test/mock_dblwr.h"
#include "bmock.h"

namespace psvr {
namespace test {

class RecoveryTests : public PsvrTest {
 public:
    RecoveryTests() {}
    virtual ~RecoveryTests() {}

    void SetUp() {
        _saved_dst_recover_thread_num = FLAGS_multi_psvr_dst_recover_thread_num;
        _saved_src_recover_thread_num = FLAGS_multi_psvr_src_recover_thread_num;
        FLAGS_multi_psvr_dst_recover_thread_num = 0;
        FLAGS_multi_psvr_src_recover_thread_num = 0;
        _recoverer.reset(new Recoverer(_mock_client, _control));
        auto mock_pool = std::make_shared<MockExecutor<Recoverer::Context, thread::TaskContext>>();
        _mock_thread_pool = mock_pool.get();
        _recoverer->_thread_pool = mock_pool;
        _recoverer->_dst_thread_pool = mock_pool;
        _recoverer->_src_thread_pool = mock_pool;

        _mock_condition_thread_pool = new MockGroupConditionThread<Recoverer::ConditionTask, Recoverer::ConditionQueue>;
        _recoverer->_condition_thread_pool.reset(_mock_condition_thread_pool);

        _mock_quota_thread = new MockQuotaThread<Recoverer::Context*, std::shared_ptr<FlowQuota>>;
        _recoverer->_quota_thread.reset(_mock_quota_thread);

        gaia_apply::page_size_t page_size(16<<10, 16<<10, false);

        _mock_src_flow_cntl = new MockFlowControl;
        _mock_dst_flow_cntl = new MockFlowControl;
        _mock_check_flow_cntl = new MockFlowQuota;
        _mock_read_flow_cntl = new MockFlowControl;
        _mock_write_flow_cntl = new MockFlowControl;
        //_mock_compress_flow_cntl = new MockFlowControl;
        _recoverer->_src_flow_cntl.reset(_mock_src_flow_cntl);
        _recoverer->_dst_flow_cntl.reset(_mock_dst_flow_cntl);
        _recoverer->_check_flow_cntl.reset(_mock_check_flow_cntl);
        _recoverer->_read_flow_cntl.reset(_mock_read_flow_cntl);
        _recoverer->_write_flow_cntl.reset(_mock_write_flow_cntl);
        //_recoverer->_compress_flow_cntl.reset(_mock_compress_flow_cntl);

        // The mock objects created by BMOCK_NS_METHOD attach their hooks at static-init
        // time, so they would stay in effect for the whole binary. Stop them all here and
        // let each test enable only the ones it injects with BMOCK_NS_RESUME.
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        BMOCK_STOP(bthread_timer_add, int(bthread_timer_t*, timespec, void (*on_timer)(void*), void*));
        BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
    }

    void TearDown() {
        FLAGS_multi_psvr_dst_recover_thread_num = _saved_dst_recover_thread_num;
        FLAGS_multi_psvr_src_recover_thread_num = _saved_src_recover_thread_num;
    }

private:
    RecovererPtr _recoverer;
    MockExecutor<Recoverer::Context, thread::TaskContext>* _mock_thread_pool;
    MockGroupConditionThread<Recoverer::ConditionTask, Recoverer::ConditionQueue>* _mock_condition_thread_pool;
    MockQuotaThread<Recoverer::Context*, std::shared_ptr<FlowQuota>>* _mock_quota_thread;
    MockFlowControl* _mock_src_flow_cntl;
    MockFlowControl* _mock_dst_flow_cntl;
    MockFlowQuota* _mock_check_flow_cntl;
    MockFlowControl* _mock_read_flow_cntl;
    MockFlowControl* _mock_write_flow_cntl;
    int32_t _saved_dst_recover_thread_num {0};
    int32_t _saved_src_recover_thread_num {0};
    //MockFlowControl* _mock_compress_flow_cntl;
};

BMOCK_NS_METHOD3(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
BMOCK_METHOD4(bthread_timer_add, int(bthread_timer_t*, timespec, void (*on_timer)(void*), void*));

bool MockExecuteOk(Recoverer::Context* ctx) {
    delete ctx;
    return true;
}

bool MockScheduleOk(thread::TaskContext* ctx, uint64_t) {
    delete ctx;
    return true;
}

bool MockCondScheduleOk(size_t, const Recoverer::ConditionTask& task) {
    delete task.ctx;
    return true;
}

bool MockGetQuotaFail(Recoverer::QuotaThreadTypePtr, Recoverer::Context* ctx, int32_t) {
    delete ctx;
    return false;
}

bool MockGetQuotaFail2(Recoverer::Context* ctx, std::shared_ptr<FlowQuota>) {
    delete ctx;
    return false;
}

static void set_page_data(gaia_apply::byte* page, gaia_apply::lsn_t lsn = 1024) {
    INIT_APPLY_RAW_ARG(false);
    memset(page, 0x1, 16384);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_SPACE_OR_CHKSUM, 0);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_OFFSET, 1);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_PREV, 0);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_NEXT, 2);
    gaia_apply::mach_write_to_8(page + gaia_apply::FIL_PAGE_LSN, lsn);
    gaia_apply::mach_write_to_2(page + gaia_apply::FIL_PAGE_TYPE, gaia_apply::FIL_PAGE_INODE APPLY_RAW_ARG_NAME_CC);
    gaia_apply::mach_write_to_8(page + gaia_apply::FIL_PAGE_FILE_FLUSH_LSN, 0);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_SPACE_ID, 2);

    uint32_t crc = calc_page_crc32(page);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_SPACE_OR_CHKSUM, crc);
    gaia_apply::mach_write_to_4(page + (16<<10) - gaia_apply::FIL_PAGE_END_LSN_OLD_CHKSUM, crc);

    memcpy(page + (16<<10) - gaia_apply::FIL_PAGE_END_LSN_OLD_CHKSUM + 4, page + gaia_apply::FIL_PAGE_LSN + 4, 4);
}

void set_buf_block(BufBlockPtr buf_block, gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no, const gaia_apply::page_size_t& page_size, gaia_apply::lsn_t lsn = 1024) {
    init_buf_block(buf_block, space_id, page_no, page_size);
    gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, space_id);
    gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_OFFSET, page_no);
    page_set_page_lsn(buf_block->frame, page_size.physical(), lsn);
}

TEST_F(RecoveryTests, test_FlowControl) {
    int64_t quota_size = 100;
    {
        Recoverer::FlowControl fcntl("test", 1, &quota_size, &quota_size);
        sleep_for(1 * 1000 * 1000);
        ASSERT_EQ(0, fcntl.GetQuota(8, 0));
        ASSERT_NE(0, fcntl.GetQuota(99, 0));
        // over max
        ASSERT_EQ(0, fcntl.GetQuota(1024 * 2, 0));
    }
    {
        int64_t quota_size2 = 30;
        Recoverer::FlowControl fcntl("test", 1, &quota_size, &quota_size2);
        sleep_for(1 * 1000 * 1000);
        ASSERT_EQ(0, fcntl.GetQuota(8, 0));
        ASSERT_NE(0, fcntl.GetQuota(25, 0));
    } END_OF_CASE;
    {
        int64_t quota_size2 = 30;
        Recoverer::FlowControl fcntl("test", 1, &quota_size, &quota_size2);
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
            .WillOnce(Return(false))
            .WillOnce(Return(true)).WillOnce(Return(false))
            .WillOnce(Return(true)).WillOnce(Return(true));
        ASSERT_FALSE(fcntl.GetQuota(_recoverer->_quota_thread, nullptr, 0));
        ASSERT_FALSE(fcntl.GetQuota(_recoverer->_quota_thread, nullptr, 0));
        ASSERT_TRUE(fcntl.GetQuota(_recoverer->_quota_thread, nullptr, 0));
    } END_OF_CASE;
    {
        Recoverer::Context ctx(Recoverer::Action::kRecoverBlock);
        ctx.task.size = 100;
        EXPECT_CALL(*_mock_check_flow_cntl, GetQuota(_)).WillOnce(Return(0));
        bool ret = _recoverer->_check_flow_cntl >= &ctx;
        ASSERT_TRUE(ret);
    }
}

TEST_F(RecoveryTests, test_Recoverer_ConditionTask) {
    auto segment = create_segment();
    {
        FLAGS_psvr_recover_wait_lsn_max_times = 1;
        Recoverer::ConditionTask task(nullptr, segment, 999);
        segment->_append_lsn(100);
        ASSERT_FALSE(task);
        ASSERT_TRUE(task);
    }
    {
        Recoverer::ConditionTask task(nullptr, segment, 99);
        ASSERT_TRUE(task);
    }
    {
        _recoverer->_on_recover_in_wait_size.store(1);
        ASSERT_EQ(1, _recoverer->on_recover_in_wait_size());
    }
    {
        _recoverer->_on_recover_inflight_req_size.store(2);
        ASSERT_EQ(2, _recoverer->on_recover_inflight_req_size());
    }
}

TEST_F(RecoveryTests, test_Start_Stop) {
    {
        FLAGS_multi_psvr_recover_thread_num = 0;
        EXPECT_CALL(*_mock_condition_thread_pool, Start(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_quota_thread, Start(_, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, _)).WillOnce(Return(false));
        ASSERT_FALSE(_recoverer->Start(1));
    }

    {
        FLAGS_multi_psvr_recover_thread_num = 4;
        EXPECT_CALL(*_mock_condition_thread_pool, Start(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_quota_thread, Start(_, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _mock_control->timer(), _, _, _)).Times(2).WillRepeatedly(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _))
            .WillOnce(Invoke(MockScheduleOk))
            .WillOnce(Invoke(MockScheduleOk))
            .WillOnce(Invoke(MockScheduleOk));
        ASSERT_TRUE(_recoverer->Start(1));
    }
    {
        _recoverer->_control.reset();
        ASSERT_FALSE(_recoverer->Start(1));
    }
    {
        _recoverer->_on_recover_inflight_req_size.store(1);
        auto t1 = std::thread([this]{
                    sleep_for(50 * 1000);
                    _recoverer->_on_recover_inflight_req_size.store(0);
                });
        _recoverer->Stop();
        t1.join();
        ASSERT_TRUE(_recoverer->_stopped);
    }
}

TEST_F(RecoveryTests, test_IncOrDecThreadNum) {
    _recoverer->_store_count = FLAGS_multi_psvr_recover_thread_num + 1;
    _recoverer->_dst_thread_num = FLAGS_multi_psvr_recover_thread_num;
    _recoverer->_src_thread_num = FLAGS_multi_psvr_recover_thread_num;
    {
        _recoverer->_stopped = false;
        FLAGS_multi_psvr_recover_thread_num = 0;
        EXPECT_CALL(*_mock_thread_pool, IncThread(_)).Times(2).WillRepeatedly(Return(true));
        _recoverer->IncOrDecThreadNum();
        FLAGS_multi_psvr_recover_thread_num = _recoverer->_dst_thread_num;
    }
    {
        // inc
        FLAGS_multi_psvr_recover_thread_num = FLAGS_multi_psvr_recover_thread_num + 1;
        EXPECT_CALL(*_mock_thread_pool, IncThread(_)).Times(2).WillRepeatedly(Return(true));
        _recoverer->IncOrDecThreadNum();
        _recoverer->IncOrDecThreadNum();
    }
    {
        // dec
        std::vector<MockExecutor<Recoverer::Context, thread::TaskContext>::ThreadType> vec;
        FLAGS_multi_psvr_recover_thread_num = FLAGS_multi_psvr_recover_thread_num - 1;
        EXPECT_CALL(*_mock_thread_pool, DecThread(_)).Times(2).WillRepeatedly(Return(vec));
        _recoverer->IncOrDecThreadNum();
    }
    _recoverer->_stopped = true;
}

void noting() {}

BMOCK_NS_METHOD1(gaiadb::common, terminate, void(int));
TEST_F(RecoveryTests, test_Dispatch) {
    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());

    {
        SegmentPtr segment = create_segment();
        ASSERT_TRUE(_recoverer->Dispatch(segment, true, true TRACE_FILE_LINE_CC));
        ASSERT_EQ(1, _recoverer->_recover_task_num);
        ASSERT_FALSE(_recoverer->Dispatch(segment, true, true TRACE_FILE_LINE_CC));
        ASSERT_EQ(1, _recoverer->_recover_task_num);

        pspb::ListRecoveryInfoResponse response;
        _recoverer->GetRecoveryInfo(&response);
        ASSERT_EQ(1, response.segments_size());
    } END_OF_CASE;
    {
        FLAGS_psvr_recover_disabled_as_data_source = true;
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        ggpb::Closure* closure = nullptr;
        _recoverer->Dispatch(create_segment(), nullptr, &request, &response, closure);
        ASSERT_EQ(0, _recoverer->_on_recover_inflight_req_size);
        FLAGS_psvr_recover_disabled_as_data_source = false;
    } END_OF_CASE;
    {
        FLAGS_psvr_recover_disabled_as_data_source = true;
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        ggpb::Closure* closure = nullptr;
        _recoverer->Dispatch(create_segment(), nullptr, &request, &response, closure);
        ASSERT_EQ(0, _recoverer->_on_recover_inflight_req_size);
        FLAGS_psvr_recover_disabled_as_data_source = false;
    } END_OF_CASE;
    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        auto segment = create_segment();
        _recoverer->Dispatch(segment, nullptr, &request, &response, nullptr);
        ASSERT_EQ(response.status().code(), pspb::Status::INVALID);
    } END_OF_CASE;
    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        request.set_ignore_segment_prepare(true);
        request.set_log_id(123);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->Dispatch(create_segment(), nullptr, &request, &response, nullptr);
        ASSERT_EQ(response.status().code(), pspb::Status::INVALID);
    } END_OF_CASE;
    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        auto segment = create_segment();
        segment->_status = Segment::Status::kPrepare;
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->Dispatch(segment, nullptr, &request, &response, nullptr);
        ASSERT_EQ(response.status().code(), pspb::Status::INVALID);
    } END_OF_CASE;
    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        request.set_ignore_segment_prepare(false);
        auto segment = create_segment();
        segment->_status = Segment::Status::kPrepare;
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->Dispatch(segment, nullptr, &request, &response, nullptr);
        ASSERT_EQ(response.status().code(), pspb::Status::INVALID);
    } END_OF_CASE;
    {
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        ggpb::Closure* closure = nullptr;
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->Dispatch(create_segment(), nullptr, &request, &response, closure);
        ASSERT_EQ(1, _recoverer->_on_recover_inflight_req_size);
    } END_OF_CASE;
    {
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        ggpb::Closure* closure = nullptr;
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->Dispatch(create_segment(), nullptr, &request, &response, closure);
        ASSERT_EQ(2, _recoverer->_on_recover_inflight_req_size);
    } END_OF_CASE;
    {
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        response.mutable_status()->set_code(pspb::Status::SUCCESS);
        ggpb::Closure* closure = brpc::NewCallback(&noting);
        {
            SegmentPtr segment = create_segment();
            Recoverer::Context ctx(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, closure);
            ctx.task.size = 16<<10;
        }
        ASSERT_EQ(response.size(), 0);
        ASSERT_EQ(2, _recoverer->_on_recover_inflight_req_size);
        --_recoverer->_on_recover_inflight_req_size;
        --_recoverer->_on_recover_inflight_req_size;
    } END_OF_CASE;
    {
        SegmentPtr segment = create_segment();
        Recoverer::Context* ctx = new Recoverer::Context(Recoverer::Action::kStartRecovery, segment);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->Execute(ctx);
    } END_OF_CASE;
    {
        SegmentPtr segment = create_segment();
        _recoverer->AddSegmentToCheckList(segment);

        SegmentPtr segment2 = create_segment();
        _recoverer->AddSegmentToCheckList(segment2);
    } END_OF_CASE;
    {
        _recoverer->_stopped = true;
        SegmentPtr segment = create_segment();
        Recoverer::Context* ctx = new Recoverer::Context(Recoverer::Action::kStartRecovery, segment);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Return(false));
        _recoverer->Execute(ctx);
    } END_OF_CASE;
    {
        _recoverer->_stopped = false;
        SegmentPtr segment = create_segment();
        Recoverer::Context* ctx = new Recoverer::Context(Recoverer::Action::kStartRecovery, segment);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Return(false));
        BMOCK_NS_RESUME(gaiadb::common, terminate, void(int));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaiadb::common, terminate), terminate(_)).WillOnce(Return());
        _recoverer->Execute(ctx);
        BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
    } END_OF_CASE;
}

TEST_F(RecoveryTests, test_OnWriteValidationAndSuccess) {
    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    auto segment = create_mock_segment_by_cluster("c1", 1, "./data/",
            32ul << 30, Segment::Status::kOpen);

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        _recoverer->_stopped = true;
        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment, &request, &response, nullptr);
        _recoverer->OnWrite(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::ERROR);
        _recoverer->_stopped = false;
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        auto expired_segment = create_mock_segment_by_cluster("c1", 2, "./data/",
                32ul << 30, Segment::Status::kOpen);
        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, expired_segment,
                &request, &response, nullptr);
        expired_segment.reset();
        _recoverer->OnWrite(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::NOT_EXISTS);
    } END_OF_CASE;

    auto verify_invalid_range = [&](uint64_t offset, uint64_t size) {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment,
                &request, &response, nullptr);
        ctx->task.offset = offset;
        ctx->task.size = size;
        _recoverer->OnWrite(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::INVALID);
    };

    verify_invalid_range(0, (4lu << 20) + 16384);
    verify_invalid_range(1, 16384);
    verify_invalid_range(16384, 1);
    verify_invalid_range(segment->segment_size(), 16384);
    verify_invalid_range(segment->segment_size() - 16384, 32768);
    END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        request.set_size(0);
        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment, &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = 0;
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::INVALID);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(16384, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(0);
        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment, &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = data.size();
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::INVALID);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        request.set_size(16384);
        request.set_data("short");
        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment,
                &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = request.size();
        _recoverer->OnWrite(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::INVALID);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        auto* frame = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size,
                        gaia_apply::FLAGS_univ_page_size));
        set_page_data(frame);
        std::string data(reinterpret_cast<const char*>(frame), 16384);
        std::free(frame);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()), data.size()));

        set_buf_block(_buf_block, 2, 1, gaia_page_size());
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, 2, 1, 0, 16384, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));

        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment, &request, &response, nullptr);
        ctx->log_id = 123;
        ctx->task.offset = 0;
        ctx->task.size = data.size();
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::SUCCESS);
    } END_OF_CASE;

    {
        auto prepare_segment = create_mock_segment_by_cluster(
                "c1", 3, "./data/", 32ul << 30, Segment::Status::kPrepare);
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(16384, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()), data.size()));

        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        EXPECT_CALL(*prepare_segment,
                WritePhysicalPageData(_, _, _, _, _, _)).Times(0);

        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, prepare_segment,
                &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = data.size();
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::SUCCESS);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(16384, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()), data.size()));

        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, 0, 0, 0, 16384, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));

        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment,
                &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = data.size();
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::SUCCESS);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        brpc::Controller cntl;
        auto* frame = static_cast<gaia_apply::byte*>(
                std::aligned_alloc(gaia_apply::FLAGS_univ_page_size,
                        gaia_apply::FLAGS_univ_page_size));
        set_page_data(frame);
        std::string data(reinterpret_cast<const char*>(frame), 16384);
        std::free(frame);
        request.set_size(data.size());
        request.set_use_attachment(true);
        cntl.request_attachment().append(data);

        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, 2, 1, 0, 16384, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));

        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment, &request, &response, nullptr);
        ctx->cntl = &cntl;
        ctx->task.offset = 0;
        ctx->task.size = data.size();
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::SUCCESS);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(16384, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()), data.size()));
        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(_, _)).WillOnce(Return(1));
        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment, &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = data.size();
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::LIMIT);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(16384, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()), data.size()));
        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        auto page_lock = segment->GetPageLock(0);
        db::PageUniqueLock lock(page_lock);
        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment, &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = data.size();
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.succ_size(), 0);
        ASSERT_EQ(response.status().code(), pspb::Status::LIMIT);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(16384, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()), data.size()));
        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(true)));
        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment, &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = data.size();
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.succ_size(), 0);
        ASSERT_EQ(response.status().code(), pspb::Status::INVALID);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(16384, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()), data.size()));
        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kIOError)));
        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment, &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = data.size();
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.succ_size(), 0);
        ASSERT_EQ(response.status().code(), pspb::Status::ERROR);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        brpc::Controller cntl;
        request.set_size(16384);
        request.set_use_attachment(true);
        cntl.request_attachment().append("short");
        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment, &request, &response, nullptr);
        ctx->cntl = &cntl;
        ctx->task.offset = 0;
        ctx->task.size = request.size();
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::INVALID);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(2 * 16384, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()), data.size()));
        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .Times(2)
            .WillRepeatedly(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)))
            .WillOnce(Return(db::Status(db::Code::kIOError)));
        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment, &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = data.size();
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.succ_size(), 16384);
        ASSERT_EQ(response.status().code(), pspb::Status::ERROR);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(2 * 16384, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()), data.size()));
        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, 0, 16384, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        auto page_lock = segment->GetPageLock(1);
        db::PageUniqueLock lock(page_lock);

        Recoverer::Context* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment,
                &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = data.size();
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.succ_size(), 16384);
        ASSERT_EQ(response.status().code(), pspb::Status::LIMIT);
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    } END_OF_CASE;
}

TEST_F(RecoveryTests, test_OnWriteControlAndMaxSize) {
    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    auto segment = create_mock_segment_by_cluster("c1", 40, "./data/",
            32ul << 30, Segment::Status::kOpen);

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        auto control = _control;
        _recoverer->_control.reset();
        auto* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment,
                &request, &response, nullptr);

        _recoverer->OnWrite(ctx);

        ASSERT_EQ(response.status().code(), pspb::Status::ERROR);
        _recoverer->_control = control;
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(16384, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()),
                data.size()));
        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(_, _))
            .WillOnce(Return(0));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(nullptr));

        std::thread write_thread([&]() {
            auto* ctx = new Recoverer::Context(
                    Recoverer::Action::kOnWrite, segment,
                    &request, &response, nullptr);
            ctx->task.offset = 0;
            ctx->task.size = data.size();
            _recoverer->OnWrite(ctx);
        });
        write_thread.join();

        ASSERT_EQ(response.status().code(), pspb::Status::LIMIT);
    } END_OF_CASE;

    {
        constexpr uint64_t kMaxWriteSize = 4lu << 20;
        constexpr uint64_t kPageSize = 16384;
        constexpr uint64_t kPageCount = kMaxWriteSize / kPageSize;
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(kMaxWriteSize, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()),
                data.size()));
        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(kMaxWriteSize, _))
            .WillOnce(Return(0));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(_buf_block));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .Times(kPageCount)
            .WillRepeatedly(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment,
                WritePhysicalPageData(_, 0, 0, _, kPageSize, _))
            .Times(kPageCount)
            .WillRepeatedly(Return(db::Status(db::Code::kOk)));

        std::thread write_thread([&]() {
            auto* ctx = new Recoverer::Context(
                    Recoverer::Action::kOnWrite, segment,
                    &request, &response, nullptr);
            ctx->task.offset = 0;
            ctx->task.size = data.size();
            _recoverer->OnWrite(ctx);
        });
        write_thread.join();

        ASSERT_EQ(response.status().code(), pspb::Status::SUCCESS);
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    } END_OF_CASE;
}

TEST_F(RecoveryTests, test_OnWriteMultiPage) {
    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
        .Times(AnyNumber())
        .WillRepeatedly(Return(_buf_block));
    auto segment = create_mock_segment_by_cluster("c1", 41, "./data/",
            32ul << 30, Segment::Status::kOpen);
    constexpr uint64_t kPageSize = 16384;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        brpc::Controller cntl;
        std::string data(2 * kPageSize, 0);
        request.set_size(data.size());
        request.set_use_attachment(true);
        cntl.request_attachment().append(data);
        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(data.size(), _))
            .WillOnce(Return(0));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .Times(2)
            .WillRepeatedly(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment,
                WritePhysicalPageData(_, 0, 0, _, kPageSize, _))
            .Times(2)
            .WillRepeatedly(Return(db::Status(db::Code::kOk)));
        auto* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment,
                &request, &response, nullptr);
        ctx->cntl = &cntl;
        ctx->task.offset = 0;
        ctx->task.size = data.size();

        _recoverer->OnWrite(ctx);

        ASSERT_EQ(response.status().code(), pspb::Status::SUCCESS);
    } END_OF_CASE;

    {
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(2 * kPageSize, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()),
                data.size()));
        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(data.size(), _))
            .WillOnce(Return(0));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(true)));
        EXPECT_CALL(*segment,
                WritePhysicalPageData(_, 0, 0, 0, kPageSize, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        auto* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, segment,
                &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = data.size();

        _recoverer->OnWrite(ctx);

        ASSERT_EQ(response.succ_size(), kPageSize);
        ASSERT_EQ(response.status().code(), pspb::Status::INVALID);
    } END_OF_CASE;

    {
        auto prepare_segment = create_mock_segment_by_cluster(
                "c1", 42, "./data/", 32ul << 30,
                Segment::Status::kPrepare);
        pspb::WritePhysicalPageRequest request;
        pspb::WritePhysicalPageResponse response;
        std::string data(2 * kPageSize, 0);
        request.set_size(data.size());
        request.set_data(data);
        request.set_data_checksum(gaiadb::common::ut_crc32(
                reinterpret_cast<const gaia_apply::byte*>(data.data()),
                data.size()));
        EXPECT_CALL(*_mock_write_flow_cntl, GetQuota(data.size(), _))
            .WillOnce(Return(0));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted),
                page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*prepare_segment,
                WritePhysicalPageData(_, 0, 0, kPageSize, kPageSize, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        auto* ctx = new Recoverer::Context(
                Recoverer::Action::kOnWrite, prepare_segment,
                &request, &response, nullptr);
        ctx->task.offset = 0;
        ctx->task.size = data.size();

        _recoverer->OnWrite(ctx);

        ASSERT_EQ(response.status().code(), pspb::Status::SUCCESS);
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    } END_OF_CASE;
}

TEST_F(RecoveryTests, test_RecoveryStats) {
    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());

    {
        const uint64_t segment_size = 1024;
        SegmentPtr segment = create_segment(segment_size);
        ASSERT_TRUE(_recoverer->Dispatch(segment, true, true TRACE_FILE_LINE_CC));
        ASSERT_EQ(static_cast<int64_t>(segment_size), _recoverer->_stat_recover_left_size.get_value());

        auto recover_task = _recoverer->_recover_store_tasks[segment->store_id()].front();
        ASSERT_EQ(segment_size, recover_task->recover_total_size.load());

        _recoverer->_stat_recover_left_size << -768;
        recover_task->recover_total_size.store(256);
        _recoverer->FinishRecovery(recover_task);
        ASSERT_EQ(0, _recoverer->_stat_recover_left_size.get_value());
    } END_OF_CASE;
    {
        const uint64_t segment_size = 2048;
        SegmentPtr segment = create_segment(segment_size);
        ASSERT_TRUE(_recoverer->Dispatch(segment, true, true TRACE_FILE_LINE_CC));
        segment.reset();

        auto* ctx = new Recoverer::Context(Recoverer::Action::kDispatchRecovery);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->DispatchRecovery(ctx);
        ASSERT_EQ(0, _recoverer->_stat_recover_left_size.get_value());
    } END_OF_CASE;
    {
        _recoverer->_stat_recover_left_size << 512;
        auto* ctx = new Recoverer::Context(Recoverer::Action::kUpdateRecoveryStats);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(-1, _recoverer->recover_expect_finish_time_s());
    } END_OF_CASE;
}

TEST_F(RecoveryTests, test_Schedule) {
    auto segment = create_segment();
    {
        Recoverer::Context* ctx = new Recoverer::Context(Recoverer::Action::kStartRecovery, segment);
        _recoverer->Schedule(ctx TRACE_FILE_LINE_CC, 10, false);
    }

    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    {
        Recoverer::Context* ctx = new Recoverer::Context(Recoverer::Action::kStartRecovery, segment);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->Schedule(ctx TRACE_FILE_LINE_CC, 0, true);
    }

    {
        Recoverer::Context* ctx = new Recoverer::Context(Recoverer::Action::kStartRecovery, segment);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->Schedule(ctx TRACE_FILE_LINE_CC, 10, false);
    }
}

TEST_F(RecoveryTests, test_OnCompletion) {
    {
        // stopped
        _recoverer->_stopped = true;
        auto segment = create_segment();
        Recoverer::Context* ctx = new Recoverer::Context(Recoverer::Action::kStartRecovery, segment);
        _recoverer->OnCompletion(ctx);
    }
}

TEST_F(RecoveryTests, test_DispatchRecovery_FinishRecovery) {
    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());

    FLAGS_psvr_recover_task_parallel_num_per_store = 2;
    ASSERT_EQ(FLAGS_psvr_recover_task_parallel_num_per_store, 2);
    {
        // add one
        SegmentPtr segment = create_segment();
        ASSERT_TRUE(_recoverer->Dispatch(segment, true, true TRACE_FILE_LINE_CC));
        ASSERT_EQ(1, _recoverer->_recover_task_num);

        {
            auto* ctx = new Recoverer::Context(Recoverer::Action::kDispatchRecovery);
            //EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
            EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
            _recoverer->DispatchRecovery(ctx);

            ASSERT_EQ(0, _recoverer->_recover_task_running_num);
            ASSERT_EQ(1, _recoverer->_recover_store_tasks[0].size());
        }

        {
            segment->set_is_invalid_start_lsn(false);
            auto* ctx = new Recoverer::Context(Recoverer::Action::kDispatchRecovery);
            EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
            EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
            _recoverer->DispatchRecovery(ctx);

            ASSERT_EQ(1, _recoverer->_recover_task_running_num);
            ASSERT_EQ(1, _recoverer->_recover_store_tasks[0].size());
        }
    }
    {
        // add invalid segment
        SegmentPtr segment = create_segment();
        ASSERT_TRUE(_recoverer->Dispatch(segment, true, true TRACE_FILE_LINE_CC));
        ASSERT_EQ(2, _recoverer->_recover_task_num);
        segment.reset();

        auto* ctx = new Recoverer::Context(Recoverer::Action::kDispatchRecovery);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->DispatchRecovery(ctx);

        ASSERT_EQ(1, _recoverer->_recover_task_num);
        ASSERT_EQ(1, _recoverer->_recover_task_running_num);
        ASSERT_EQ(1, _recoverer->_recover_store_tasks[0].size());
    }

    {
        // add one again
        SegmentPtr segment = create_segment();
        segment->set_is_invalid_start_lsn(false);

        ASSERT_TRUE(_recoverer->Dispatch(segment, true, true TRACE_FILE_LINE_CC));
        ASSERT_EQ(2, _recoverer->_recover_task_num);

        auto* ctx = new Recoverer::Context(Recoverer::Action::kDispatchRecovery);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->DispatchRecovery(ctx);

        ASSERT_EQ(2, _recoverer->_recover_task_running_num);
        ASSERT_EQ(2, _recoverer->_recover_store_tasks[0].size());
    }

    {
        // add one again
        SegmentPtr segment = create_segment();
        segment->set_is_invalid_start_lsn(false);

        ASSERT_TRUE(_recoverer->Dispatch(segment, true, true TRACE_FILE_LINE_CC));
        ASSERT_EQ(3, _recoverer->_recover_task_num);

        auto* ctx = new Recoverer::Context(Recoverer::Action::kDispatchRecovery);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->DispatchRecovery(ctx);

        ASSERT_EQ(2, _recoverer->_recover_task_running_num);
        ASSERT_EQ(3, _recoverer->_recover_store_tasks[0].size());
    }
    {
        // add one again in other store
        SegmentPtr segment = create_segment_by_store_id(1);
        segment->set_is_invalid_start_lsn(false);

        ASSERT_TRUE(_recoverer->Dispatch(segment, true, true TRACE_FILE_LINE_CC));
        ASSERT_EQ(4, _recoverer->_recover_task_num);

        auto* ctx = new Recoverer::Context(Recoverer::Action::kDispatchRecovery);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->DispatchRecovery(ctx);

        ASSERT_EQ(3, _recoverer->_recover_task_running_num);
        ASSERT_EQ(3, _recoverer->_recover_store_tasks[0].size());
        ASSERT_EQ(1, _recoverer->_recover_store_tasks[1].size());
    }

    {
        auto it = _recoverer->_recover_store_tasks[0].begin();
        auto recover_task = *(++it);
        _recoverer->FinishRecovery(recover_task);

        ASSERT_EQ(2, _recoverer->_recover_task_running_num);
        ASSERT_EQ(2, _recoverer->_recover_store_tasks[0].size());
    }
}

TEST_F(RecoveryTests, test_Check_FinishRecovery) {
    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    {
        // no task
        auto* ctx = new Recoverer::Context(Recoverer::Action::kCheck);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    }
    {
        // invalid segment
        auto segment = create_segment();
        _recoverer->AddSegmentToCheckList(segment);
        segment.reset();
        auto* ctx = new Recoverer::Context(Recoverer::Action::kCheck);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    }
    FLAGS_psvr_recover_enable_check = true;
    {
        // segment delete
        auto segment = create_segment();
        segment->_status = Segment::Status::kDelete;
        _recoverer->AddSegmentToCheckList(segment);
        auto* ctx = new Recoverer::Context(Recoverer::Action::kCheck);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    }
    {
        // segment not recovery_status_is_finish
        auto segment = create_segment();
        segment->_recovery_status = gaiadb::RECOVERY_IN;
        _recoverer->AddSegmentToCheckList(segment);
        auto* ctx = new Recoverer::Context(Recoverer::Action::kCheck);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);

        // segment is not active
        segment->_recovery_status = gaiadb::RECOVERY_FINISH;
        segment->_status = Segment::Status::kPrepare;
        auto* ctx2 = new Recoverer::Context(Recoverer::Action::kCheck);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx2);

        // segment in last time
        segment->_status = Segment::Status::kOpen;
        segment->_recovery_info.last_recover_time = base::cpuwide_time_us() + 99;
        auto* ctx3 = new Recoverer::Context(Recoverer::Action::kCheck);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx3);

        // segment in recovery
        segment->_recovery_info.last_recover_time = base::cpuwide_time_us() - (FLAGS_psvr_recover_check_interval * 1000 * 1000) - 1;
        segment->TurnOnRecovery(false);
        segment->StartRecovery();
        auto* ctx4 = new Recoverer::Context(Recoverer::Action::kCheck);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx4);
        segment->FinishRecovery();

        // ok
        auto* ctx5 = new Recoverer::Context(Recoverer::Action::kCheck);
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->OnCompletion(ctx5);

        // FLAGS_psvr_recover_enable_check
        FLAGS_psvr_recover_enable_check = false;
        auto segment2 = create_segment();
        _recoverer->AddSegmentToCheckList(segment2);
        auto* ctx6 = new Recoverer::Context(Recoverer::Action::kCheck);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx6);

        std::shared_ptr<Recoverer::Task> recover_task(new Recoverer::Task(segment, true));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->FinishRecovery(recover_task);

        std::shared_ptr<Recoverer::Task> recover_task2(new Recoverer::Task(create_segment(), true));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->FinishRecovery(recover_task2);
    }
}

TEST_F(RecoveryTests, test_StartRecovery2) {
    _recoverer->_stopped = true;
    {
        // stop
        auto segment = create_mock_segment();
        auto ctx = new Recoverer::Context(Recoverer::Action::kStartRecovery, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(create_segment(), false);
        _recoverer->OnCompletion(ctx);
    }
}

TEST_F(RecoveryTests, test_StartRecovery) {
    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    {
        // invalid segment
        auto ctx = new Recoverer::Context(Recoverer::Action::kStartRecovery, create_segment());
        ctx->recover_task = std::make_shared<Recoverer::Task>(create_segment(), false);
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    //{
        //// StartRecovery fail
        //auto segment = create_mock_segment();
        //auto ctx = new Recoverer::Context(Recoverer::Action::kStartRecovery, segment);
        //ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ////EXPECT_CALL(*segment, StartRecovery()).WillOnce(Return(false));
        //EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        //_recoverer->OnCompletion(ctx);
    //} END_OF_CASE;
    {
        // stop GetRecoveryNextBlockTask
        FLAGS_psvr_recover_max_inflight_task_size = 1;
        auto segment = create_mock_segment();
        auto ctx = new Recoverer::Context(Recoverer::Action::kStartRecovery, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        RecoverBlockTask task;
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_)).WillOnce(DoAll(SetArgPointee<0>(task), Return(false)));

        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // ok GetRecoveryNextBlockTask
        FLAGS_psvr_recover_max_inflight_task_size = 3;
        auto segment = create_mock_segment();
        auto ctx = new Recoverer::Context(Recoverer::Action::kStartRecovery, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        RecoverBlockTask task;
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_))
            .WillOnce(DoAll(SetArgPointee<0>(task), Return(true)))
            .WillOnce(DoAll(SetArgPointee<0>(task), Return(true)))
            .WillOnce(DoAll(SetArgPointee<0>(task), Return(false)));

        EXPECT_CALL(*_mock_dst_flow_cntl, GetQuota(_, _, _))
            .WillOnce(Return(true))
            .WillOnce(Invoke(MockGetQuotaFail));

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
}

TEST_F(RecoveryTests, test_RecoverNextBlock) {
    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    {
        // invalid segment
        auto segment = create_mock_segment();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->recover_task->IncInflightReqSize();
        segment.reset();
        _recoverer->RecoverNextBlock(ctx);
    } END_OF_CASE;
    {
        // recovery_is_finish
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->recover_task->IncInflightReqSize();
        EXPECT_CALL(*segment, FinishRecoveryBlockTask(_)).WillOnce(Return());
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        _recoverer->RecoverNextBlock(ctx);
    } END_OF_CASE;
    FLAGS_psvr_recover_enable_check = true;
    {
        // recovery_is_finish with check
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, true);
        ctx->recover_task->IncInflightReqSize();
        EXPECT_CALL(*segment, FinishRecoveryBlockTask(_)).WillOnce(Return());
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_)).WillOnce(Return(false));

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->RecoverNextBlock(ctx);
    } END_OF_CASE;
    {
        // recovery_is_finish is not & GetRecoveryNextBlockTask ok
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, true);
        ctx->recover_task->IncInflightReqSize();
        EXPECT_CALL(*segment, FinishRecoveryBlockTask(_)).WillOnce(Return());
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_))
            .Times(2)
            .WillOnce(Return(true))
            .WillOnce(Return(false));

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));

        FLAGS_psvr_recover_long_query_time_us = 0;
        _recoverer->RecoverNextBlock(ctx);
    } END_OF_CASE;
    {
        // Decrease the configured concurrency and retire this context.
        FLAGS_psvr_recover_max_inflight_task_size = 1;
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(
                Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task =
                std::make_shared<Recoverer::Task>(segment, true);
        ctx->recover_task->task_size.store(3);
        ctx->recover_task->IncInflightReqSize(3);
        auto recover_task = ctx->recover_task;
        EXPECT_CALL(*segment, FinishRecoveryBlockTask(_)).WillOnce(Return());
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_)).Times(0);

        _recoverer->RecoverNextBlock(ctx);
        ASSERT_EQ(recover_task->task_size.load(), 2);
        ASSERT_EQ(recover_task->InflightReqSize(), 2);
    } END_OF_CASE;
    {
        // recovery_is_finish is not & GetRecoveryNextBlockTask ok
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, true);
        ctx->recover_task->IncInflightReqSize();
        EXPECT_CALL(*segment, FinishRecoveryBlockTask(_)).WillOnce(Return());
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_))
            .Times(2)
            .WillOnce(Return(true))
            .WillOnce(Return(false));

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Invoke(MockGetQuotaFail2));

        FLAGS_psvr_recover_long_query_time_us = 0;
        _recoverer->RecoverNextBlock(ctx);
    } END_OF_CASE;
    FLAGS_psvr_recover_enable_check = false;
}

TEST_F(RecoveryTests, test_RecoverBlock) {
    _recoverer->_stopped = false;
    FLAGS_psvr_recover_enable_check = true;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    {
        // invalid segment
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, true);
        ctx->recover_task->IncInflightReqSize();
        segment->_status = Segment::Status::kDelete;
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // GetQuota failed
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);

        EXPECT_CALL(*_mock_dst_flow_cntl, GetQuota(_, _, _)).WillOnce(Invoke(MockGetQuotaFail));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // GetQuota failed 2
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, true);

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Invoke(MockGetQuotaFail2));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // Get buf failed
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);

        EXPECT_CALL(*_mock_dst_flow_cntl, GetQuota(_, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(nullptr));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // ReadPhysicalPageData fail
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, true);
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        ctx->task.offset = (16 << 10) * 4;
        ctx->task.size = 16 << 10;

        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kBusy)));

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // page_is_corrupted is true
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, true);
        ctx->task.offset = (16 << 10) * 4;
        ctx->task.size = 16 << 10;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        //EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(Return(true));

        FLAGS_psvr_recover_block_if_check_fail = true;

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // page_is_corrupted is true
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, true);
        ctx->recover_task->IncInflightReqSize();
        ctx->task.offset = (16 << 10) * 4;
        ctx->task.size = 16 << 10;

        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        //EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(Return(true));

        FLAGS_psvr_recover_block_if_check_fail = false;
        EXPECT_CALL(*segment, FinishRecoveryBlockTask(_)).WillOnce(Return());
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_)).WillOnce(Return(false));

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // local_is_empty
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->recover_task->IncInflightReqSize();
        EXPECT_CALL(*_mock_dst_flow_cntl, GetQuota(_, _, _)).WillOnce(Return(true));
        ctx->task.offset = (16 << 10) * 4;
        ctx->task.size = 16 << 10;
        segment->_recovery_status = gaiadb::RECOVERY_FINISH;

        //EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        EXPECT_CALL(*segment, FinishRecoveryBlockTask(_)).WillOnce(Return());
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_)).WillOnce(Return(false));

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // space_status_is_unknown
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        EXPECT_CALL(*_mock_dst_flow_cntl, GetQuota(_, _, _)).WillOnce(Return(true));
        ctx->local_space_id = 0;
        ctx->task.offset = (16 << 10) * 4;
        ctx->task.size = 16 << 10;
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusUnknown));

        //EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, ggpb::Closure* closure, pspb::Status* status) {
            if (status) {
                status->set_code(pspb::Status::INVALID);
            }
            if (closure) {
                closure->Run();
            }
        };
        EXPECT_CALL(*_mock_parser, AddGetSpaceMetaEvent(_ TRACE_MOCK_ARG_CC, _, _, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // space_status_is_deleted
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, true);
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _))
            .WillOnce(Return(true))
            .WillOnce(Return(true));
        ctx->local_space_id = 0;
        ctx->task.offset = (16 << 10) * 4;
        ctx->task.size = 16 << 10;
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusDeleted));

        //EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, FinishRecoveryBlockTask(_)).WillOnce(Return());
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_))
            .Times(2)
            .WillOnce(Return(true))
            .WillOnce(Return(false));
        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // GetSpacePagePhysicalOffset fail
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, true);
        EXPECT_CALL(*_mock_quota_thread, GetQuota(_, _)).WillOnce(Return(true));
        ctx->local_space_id = 0;
        ctx->task.offset = (16 << 10) * 4;
        ctx->task.size = 16 << 10;
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
        //segment->rpc_quota()->EraseOffsetEvent(segment->segment_id(), 1, 1);

        //EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(false));

        auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, gaia_apply::page_no_t, uint64_t, ggpb::Closure* closure, pspb::Status* status) {
            if (status) {
                status->set_code(pspb::Status::INVALID);
            }
            if (closure) {
                closure->Run();
            }
        };
        EXPECT_CALL(*_mock_parser, AddGetSpaceExtentEvent(_ TRACE_MOCK_ARG_CC, _, _, _, _, _)).WillOnce(Invoke(fun1));

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // GetSpacePagePhysicalOffset ok
        auto segment = create_mock_segment();
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlock, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->recover_task->IncInflightReqSize();
        EXPECT_CALL(*_mock_dst_flow_cntl, GetQuota(_, _, _)).WillOnce(Return(true));
        ctx->local_space_id = 0;
        ctx->task.offset = (16 << 10) * 4;
        ctx->task.size = 16 << 10;
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));

        //EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(DoAll(SetArgPointee<2>(ctx->task.offset), Return(true)));
        EXPECT_CALL(*segment, FinishRecoveryBlockTask(_)).WillOnce(Return());
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_)).WillOnce(Return(false));

        EXPECT_CALL(*_mock_thread_pool, Execute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->OnCompletion(ctx);
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    } END_OF_CASE;
}

TEST_F(RecoveryTests, test_RecoverBlockFromPeer_DisposeRecoveryBlock) {
    _recoverer->_stopped = false;
    auto set_append_checkpoint_default = [](const std::shared_ptr<MockSegment>& segment) {
        EXPECT_CALL(*segment, GetAppendDBCheckPointLsn())
            .Times(AnyNumber())
            .WillRepeatedly(Return(0));
    };
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    std::vector<gaiadb::common::PeerZone> replicas;
    FillServers(&replicas, 2);

    auto buf_block2 = _mock_bufpool->RealAllocBufBlock(16<<10, nullptr);

    std::vector<gaiadb::common::PeerZone> replicas_1;
    FillServers(&replicas_1, 1);
    {
        // invalid segment
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, true);
        ctx->recover_task->IncInflightReqSize();
        segment->_status = Segment::Status::kDelete;
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // GetPeerNodes fail
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);

        EXPECT_CALL(*segment, GetPeerNodes(_, _))
            .WillOnce(Return(false));

        auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, ggpb::Closure* closure, pspb::Status* status) {
            brpc::ClosureGuard closure_guard(closure);
            if (status) {
                status->set_code(pspb::Status::INVALID);
            }
        };
        EXPECT_CALL(*_mock_parser, AddGetPeerEvent(_ TRACE_MOCK_ARG_CC, _, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // GetPeerNodes fail & not empty & rpc fail
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(2222);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas), Return(false)));

        EXPECT_CALL(*_mock_parser, AddGetPeerEvent(_ TRACE_MOCK_ARG_CC, _, _)).WillOnce(Return());

        auto fun2 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kCntlFailed;
        };
        auto fun3 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.set_refresh_zone(true);
            rpc_ctx->response.set_checkpoint_lsn(1024);
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_ERROR);

        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun2)).WillOnce(Invoke(fun3));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4))
            .WillOnce(Invoke(fun4));

        auto fun5 = [](bthread_timer_t*, timespec, void (*on_timer)(void*), void* arg) {
            on_timer(arg);
            return 0;
        };
        BMOCK_RESUME(bthread_timer_add, int(bthread_timer_t*, timespec, void (*on_timer)(void*), void*));
        EXPECT_CALL(BMOCK_OBJECT(bthread_timer_add), bthread_timer_add(_, _, _, _))
            .WillOnce(Invoke(fun5));

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(buf_block2));

        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // lsn invalid
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(2222);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas), Return(true)));

        auto fun2 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_max_lsn(1111);
        };
        auto fun3 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun2)).WillOnce(Invoke(fun3));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4))
            .WillOnce(Invoke(fun4));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));

        auto fun5 = [](bthread_timer_t*, timespec, void (*on_timer)(void*), void* arg) {
            return 1;
        };
        BMOCK_RESUME(bthread_timer_add, int(bthread_timer_t*, timespec, void (*on_timer)(void*), void*));
        EXPECT_CALL(BMOCK_OBJECT(bthread_timer_add), bthread_timer_add(_, _, _, _))
            .WillOnce(Invoke(fun5));

        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // size invalid & crc error
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas), Return(true)));

        auto fun2 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_max_lsn(1111);
            rpc_ctx->response.set_size((16<<10) + 1);
        };
        auto fun3 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_data_crc(1111);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            rpc_ctx->response.set_size((16<<10));
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun2)).WillOnce(Invoke(fun3));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4))
            .WillOnce(Invoke(fun4));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));

        auto fun5 = [](bthread_timer_t*, timespec, void (*on_timer)(void*), void* arg) {
            on_timer(arg);
            return 0;
        };
        BMOCK_RESUME(bthread_timer_add, int(bthread_timer_t*, timespec, void (*on_timer)(void*), void*));
        EXPECT_CALL(BMOCK_OBJECT(bthread_timer_add), bthread_timer_add(_, _, _, _))
            .WillOnce(Invoke(fun5));

        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // page_is_corrupted & is_empty
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas), Return(true)));

        auto fun2 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_max_lsn(1111);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        auto fun3 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_valid_empty(false);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun2)).WillOnce(Invoke(fun3));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(Return(true))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4))
            .WillOnce(Invoke(fun4));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));

        auto fun5 = [](bthread_timer_t*, timespec, void (*on_timer)(void*), void* arg) {
            on_timer(arg);
            return 0;
        };
        BMOCK_RESUME(bthread_timer_add, int(bthread_timer_t*, timespec, void (*on_timer)(void*), void*));
        EXPECT_CALL(BMOCK_OBJECT(bthread_timer_add), bthread_timer_add(_, _, _, _))
            .WillOnce(Invoke(fun5));

        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // GetOrAllocBufBlock fail
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas), Return(true)));

        auto fun1 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_valid_empty(true);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun1));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(nullptr));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4))
            .WillOnce(Invoke(MockExecuteOk));

        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // check gc_page_in_recovery
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas_1), Return(true)));

        auto fun1 = [this](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_valid_empty(true);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun1));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(_buf_block));

        EXPECT_CALL(*segment, CheckGcPageInRecovery(_, _, _)).WillOnce(DoAll(SetArgPointee<1>(1025), SetArgPointee<2>(888), Return(true)));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4))
            .WillOnce(Invoke(MockExecuteOk));
        //EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // check gc_page_in_recovery 2
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas_1), Return(true)));

        auto fun1 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_valid_empty(true);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun1));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        EXPECT_CALL(*segment, CheckGcPageInRecovery(_, _, _)).WillOnce(DoAll(SetArgPointee<1>(888), SetArgPointee<2>(10000), Return(false)));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4))
            .WillOnce(Invoke(MockExecuteOk));
        //EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // ReadPhysicalPageData fail
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas_1), Return(true)));

        auto fun1 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_valid_empty(true);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun1));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        EXPECT_CALL(*segment, CheckGcPageInRecovery(_, _, _)).WillOnce(DoAll(SetArgPointee<1>(0), SetArgPointee<2>(888), Return(false)));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kIOError)));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // local page_is_corrupted true
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas_1), Return(true)));

        auto fun1 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_valid_empty(true);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun1));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(true)));
        EXPECT_CALL(*segment, CheckGcPageInRecovery(_, _, _)).WillOnce(DoAll(SetArgPointee<1>(0), SetArgPointee<2>(998), Return(false)));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kBusy)));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // local_is_empty
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas_1), Return(true)));

        auto fun1 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_valid_empty(true);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun1));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        EXPECT_CALL(*segment, CheckGcPageInRecovery(_, _, _)).WillOnce(DoAll(SetArgPointee<1>(888), SetArgPointee<2>(LOG_START_LSN), Return(true)));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kBusy)));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // remote is empty & local is not empty
        const bool saved_enable_append_file = FLAGS_psvr_enable_append_file;
        FLAGS_psvr_enable_append_file = false;
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);
        ctx->local_space_id = 1;
        ctx->local_page_no = 1;
        ctx->local_page_lsn = 9999;

        set_buf_block(_buf_block, 1, ctx->local_page_no, gaia_page_size(), ctx->local_page_lsn);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas_1), Return(true)));

        auto fun1 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_valid_empty(true);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun1));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, CheckGcPageInRecovery(_, _, _)).WillOnce(DoAll(SetArgPointee<1>(888), SetArgPointee<2>(LOG_START_LSN), Return(true)));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*segment, TrimPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kBusy)));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
        FLAGS_psvr_enable_append_file = saved_enable_append_file;
    } END_OF_CASE;
    {
        // remote is empty & local is empty
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->recover_task->IncInflightReqSize();
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas_1), Return(true)));

        auto fun1 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_valid_empty(true);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun1));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        EXPECT_CALL(*segment, CheckGcPageInRecovery(_, _, _)).WillOnce(DoAll(SetArgPointee<1>(888), SetArgPointee<2>(998), Return(false)));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(DoAll(
                    SetArgPointee<5>(0),
                    Return(db::Status(db::Code::kOk))));
        EXPECT_CALL(*segment, FinishRecoveryBlockTask(_)).WillOnce(Return());
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_)).WillOnce(Return(false));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4))
            .WillOnce(Invoke(MockExecuteOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // local is changed & space id changed
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);
        ctx->local_space_id = 1;
        ctx->local_page_no = 1;
        ctx->local_page_lsn = 9999;

        set_buf_block(_buf_block, 1 + 1, ctx->local_page_no, gaia_page_size(), ctx->local_page_lsn);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas_1), Return(true)));

        auto fun1 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_valid_empty(true);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun1));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, CheckGcPageInRecovery(_, _, _)).WillOnce(DoAll(SetArgPointee<1>(888), SetArgPointee<2>(LOG_START_LSN), Return(true)));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // local is changed & page no changed
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);
        ctx->local_space_id = 1;
        ctx->local_page_no = 1;
        ctx->local_page_lsn = 9999;

        set_buf_block(_buf_block, 1, ctx->local_page_no + 1, gaia_page_size(), ctx->local_page_lsn);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas_1), Return(true)));

        auto fun1 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_valid_empty(true);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun1));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, CheckGcPageInRecovery(_, _, _)).WillOnce(DoAll(SetArgPointee<1>(888), SetArgPointee<2>(LOG_START_LSN), Return(true)));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // local is changed & lsn changed
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);
        ctx->local_space_id = 1;
        ctx->local_page_no = 1;
        ctx->local_page_lsn = 9999;

        set_buf_block(_buf_block, 1, ctx->local_page_no, gaia_page_size(), ctx->local_page_lsn + 1);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas_1), Return(true)));

        auto fun1 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_valid_empty(true);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun1));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, CheckGcPageInRecovery(_, _, _)).WillOnce(DoAll(SetArgPointee<1>(888), SetArgPointee<2>(LOG_START_LSN), Return(true)));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // local not changed
        auto segment = create_mock_segment();
        set_append_checkpoint_default(segment);
        segment->TurnOnRecovery(true);
        segment->StartRecovery();
        auto ctx = new Recoverer::Context(Recoverer::Action::kRecoverBlockFromPeer, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->recover_task->IncInflightReqSize();
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_gc_lsn(999);
        ctx->local_space_id = 1;
        ctx->local_page_no = 1;
        ctx->local_page_lsn = 9999;

        set_buf_block(_buf_block, 1, ctx->local_page_no, gaia_page_size(), ctx->local_page_lsn);

        EXPECT_CALL(*segment, GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas_1), Return(true)));

        auto fun1 = [](ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* closure){
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(pspb::Status_ReturnCode_SUCCESS);
            rpc_ctx->response.set_checkpoint_lsn(1111);
            rpc_ctx->response.set_size((16<<10));
            rpc_ctx->response.set_valid_empty(true);
            rpc_ctx->response.mutable_data()->resize(16<<10);
            set_page_data(reinterpret_cast<gaia_apply::byte*>(&((*rpc_ctx->response.mutable_data())[0])));
        };
        EXPECT_CALL(*_mock_client, ReadPhysicalPage(_, _)).WillOnce(Invoke(fun1));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, CheckGcPageInRecovery(_, _, _)).WillOnce(DoAll(SetArgPointee<1>(888), SetArgPointee<2>(LOG_START_LSN), Return(true)));
        //EXPECT_CALL(*segment, DropGcPageInRecovery(_, _)).WillOnce(Return());

        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*segment, FinishRecoveryBlockTask(_)).WillOnce(Return());
        EXPECT_CALL(*segment, GetRecoveryNextBlockTask(_)).WillOnce(Return(false));

        auto fun4 = [this] (Recoverer::Context* ctx) {
            _recoverer->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Execute(_))
            .WillOnce(Invoke(fun4))
            .WillOnce(Invoke(MockExecuteOk));
        _recoverer->OnCompletion(ctx);
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        BMOCK_STOP(bthread_timer_add, int(bthread_timer_t*, timespec, void (*on_timer)(void*), void*));
    } END_OF_CASE;
}

TEST_F(RecoveryTests, test_UpdateMetaStatus) {
    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    std::vector<base::EndPoint> replicas;
    FillServers(&replicas, 2);
    {
        // invalid segment
        auto segment = create_mock_segment();
        auto ctx = new Recoverer::Context(Recoverer::Action::kUpdateMetaStatus, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, true);
        segment->_status = Segment::Status::kDelete;
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // GetPeerNodes fail
        auto segment = create_mock_segment();
        auto ctx = new Recoverer::Context(Recoverer::Action::kUpdateMetaStatus, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // CheckRecovery fail
        auto segment = create_mock_segment();
        auto ctx = new Recoverer::Context(Recoverer::Action::kUpdateMetaStatus, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas), Return(true)));
        EXPECT_CALL(*segment.get(), CheckRecovery()).WillOnce(Return(false));

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // rpc error
        auto segment = create_mock_segment();
        auto ctx = new Recoverer::Context(Recoverer::Action::kUpdateMetaStatus, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas), Return(true)));
        EXPECT_CALL(*segment.get(), CheckRecovery()).WillOnce(Return(true));
        auto fun1 = [](ClientContext<gaiapb::UpdateReplicaRecoveryStatusRequest, gaiapb::AckResponse>* rpc_ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kCntlFailed;
        };
        auto fun2 = [](ClientContext<gaiapb::UpdateReplicaRecoveryStatusRequest, gaiapb::AckResponse>* rpc_ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_TIMEOUT);
        };


        EXPECT_CALL(*_mock_client, UpdateReplicaRecoveryStatus(_, _))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun2));

        EXPECT_CALL(*_mock_control, RefreshPsmInfo(_)).WillOnce(Return());

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockScheduleOk));
        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // rpc ok
        auto segment = create_mock_segment();
        auto ctx = new Recoverer::Context(Recoverer::Action::kUpdateMetaStatus, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas), Return(true)));
        EXPECT_CALL(*segment.get(), CheckRecovery()).WillOnce(Return(true));
        auto fun1 = [](ClientContext<gaiapb::UpdateReplicaRecoveryStatusRequest, gaiapb::AckResponse>* rpc_ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
        };
        EXPECT_CALL(*_mock_client, UpdateReplicaRecoveryStatus(_, _))
            .WillOnce(Invoke(fun1));

        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // rpc not exists
        auto segment = create_mock_segment();
        auto ctx = new Recoverer::Context(Recoverer::Action::kUpdateMetaStatus, segment);
        ctx->recover_task = std::make_shared<Recoverer::Task>(segment, false);
        ctx->task.offset = (16<<10) * 10;
        ctx->task.size = (16<<10);
        segment->_version = 1;

        EXPECT_CALL(*_mock_psm_info, GetOrRefreshNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(replicas), Return(true)));
        EXPECT_CALL(*segment.get(), CheckRecovery()).WillOnce(Return(true));
        auto fun1 = [](ClientContext<gaiapb::UpdateReplicaRecoveryStatusRequest, gaiapb::AckResponse>* rpc_ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_NOT_EXIST);
        };
        EXPECT_CALL(*_mock_client, UpdateReplicaRecoveryStatus(_, _))
            .WillOnce(Invoke(fun1));

        _recoverer->OnCompletion(ctx);
    } END_OF_CASE;
}

TEST_F(RecoveryTests, test_OnRecoverBlock2) {
    _recoverer->_stopped = true;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    {
        // stop
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;

    _recoverer->_stopped = false;
    {
        // invalid control
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        _recoverer->_control.reset();
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    _recoverer->_control = _control;
    {
        // incremental completion waits for the append redo boundary
        auto segment = create_mock_segment();
        segment->_gc_lsn(1000);
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16 << 10);
        request.set_size(16 << 10);
        request.set_request_lsn(3000);
        request.set_append_min_lsn(2000);
        auto ctx = new Recoverer::Context(
                Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        ctx->in_condition = true;
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::LIMIT);
    } END_OF_CASE;
}

TEST_F(RecoveryTests, test_OnRecoverBlock) {
    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    std::vector<base::EndPoint> replicas;
    FillServers(&replicas, 2);
    {
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);

        Recoverer::ConditionTask task(ctx, segment, 1024);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_)).WillOnce(Invoke(MockExecuteOk));
        _recoverer->ConditionFn(task);
    }
    {
        // invalid segment
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        segment.reset();
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // lsn invalid
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        ctx->in_condition = true;
        segment->_parse_lsn(888);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // lsn invalid 2
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        ctx->in_condition = false;
        segment->_parse_lsn(888);
        EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockCondScheduleOk));
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // quota fail
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(1));
        segment->_parse_lsn(8888);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // GetOrAllocBufBlock fail
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(nullptr));
        segment->_parse_lsn(8888);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // lock fail
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(_buf_block));
        segment->_parse_lsn(8888);
        {
            const uint64_t physical_page_no = ctx->task.offset / ctx->task.size;
            db::PageLockPtr page_lock = segment->GetPageLock(physical_page_no);
            db::PageUniqueLock lk(page_lock);

            _recoverer->OnCompletion(ctx);
        }
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // ReadPhysicalPageData fail
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kIOError)));
        segment->_parse_lsn(8888);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // page_is_corrupted
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(true)));

        segment->_parse_lsn(8888);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // empty 1
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));

        segment->_parse_lsn(8888);
        segment->_gc_lsn(7777);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // empty 2
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));

        segment->_parse_lsn(8888);
        segment->_gc_lsn(777);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // space_status_is_unknown
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, ggpb::Closure* closure, pspb::Status* status) {
            if (status) {
                status->set_code(pspb::Status::INVALID);
            }
            if (closure) {
                closure->Run();
            }
        };
        EXPECT_CALL(*_mock_parser, AddGetSpaceMetaEvent(_ TRACE_MOCK_ARG_CC, _, _, _)).WillOnce(Invoke(fun1));

        segment->_parse_lsn(8888);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusUnknown));
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // space_status_is_deleted
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        segment->_parse_lsn(8888);
        segment->_gc_lsn(1024);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusDeleted));
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // GetSpacePagePhysicalOffset fail
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _))
            .WillOnce(Return(false));

        auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, gaia_apply::page_no_t, uint64_t, ggpb::Closure* closure, pspb::Status* status) {
            if (status) {
                status->set_code(pspb::Status::INVALID);
            }
            if (closure) {
                closure->Run();
            }
        };
        EXPECT_CALL(*_mock_parser, AddGetSpaceExtentEvent(_ TRACE_MOCK_ARG_CC, _, _, _, _, _)).WillOnce(Invoke(fun1));

        segment->_parse_lsn(8888);
        segment->_gc_lsn(1024 - 1);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // offset mismatch
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(DoAll(SetArgPointee<2>(ctx->task.offset + 1), Return(true)));

        segment->_parse_lsn(8888);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // gc_lsn > lsn
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(DoAll(SetArgPointee<2>(ctx->task.offset), Return(true)));

        segment->_parse_lsn(8888);
        segment->_gc_lsn(8888);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // page not_exists
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(DoAll(SetArgPointee<2>(ctx->task.offset), Return(true)));

        segment->_parse_lsn(8888);
        segment->_gc_lsn(888);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // page rec empty
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(DoAll(SetArgPointee<2>(ctx->task.offset), Return(true)));

        segment->_parse_lsn(8888);
        segment->_gc_lsn(888);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
        segment->GetPage(1, 1, true);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // ok
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(DoAll(SetArgPointee<2>(ctx->task.offset), Return(true)));
        EXPECT_CALL(*segment, ApplyPageLogRecordsNoLock(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));

        segment->_parse_lsn(8888);
        segment->_gc_lsn(888);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
        auto page = segment->GetPage(1, 1, true);
        LogRecord rec(gaia_apply::MLOG_LSN, nullptr, 0, 1000, 1001, 1, 1, false, 0);
        page->AppendLogRecord(&rec);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // ahead
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(DoAll(SetArgPointee<2>(ctx->task.offset), Return(true)));
        EXPECT_CALL(*segment, ApplyPageLogRecordsNoLock(_, _, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kAhead)));

        segment->_parse_lsn(8888);
        segment->_gc_lsn(888);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
        auto page = segment->GetPage(1, 1, true);
        LogRecord rec(gaia_apply::MLOG_LSN, nullptr, 0, 1001, 1002, 1, 1, false, 0);
        page->AppendLogRecord(&rec);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
    } END_OF_CASE;
    {
        // error
        auto segment = create_mock_segment();
        pspb::ReadPageRequest request;
        pspb::ReadPageResponse response;
        request.set_physical_offset(16<<10);
        request.set_size(16<<10);
        request.set_request_lsn(1024);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRecoverBlock, segment, &request, &response, nullptr);
        ctx->lsn = request.request_lsn();
        ctx->task.offset = request.physical_offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_src_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        set_buf_block(_buf_block, 1, 1, gaia_page_size(), 99);
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(DoAll(SetArgPointee<2>(ctx->task.offset), Return(true)));
        EXPECT_CALL(*segment, ApplyPageLogRecordsNoLock(_, _, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kIOError)));

        segment->_parse_lsn(8888);
        segment->_gc_lsn(888);
        EXPECT_CALL(*segment, GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
        auto page = segment->GetPage(1, 1, true);
        LogRecord rec(gaia_apply::MLOG_LSN, nullptr, 0, 1002, 1003, 1, 1, false, 0);
        page->AppendLogRecord(&rec);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    } END_OF_CASE;
}

TEST_F(RecoveryTests, test_OnRead) {
    _recoverer->_stopped = true;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    std::vector<base::EndPoint> replicas;
    FillServers(&replicas, 2);
    {
        auto segment = create_mock_segment();
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        request.set_offset(16<<10);
        request.set_size(16<<10);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRead, segment, &request, &response, nullptr);
        _recoverer->OnRead(ctx);
        LOG(NOTICE) << response.status();
        ASSERT_EQ(response.status().code(), pspb::Status::ERROR);
    }
    _recoverer->_stopped = false;
    {
        // invalid segment
        auto segment = create_mock_segment();
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        request.set_offset(16<<10);
        request.set_size(16<<10);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRead, segment, &request, &response, nullptr);
        segment.reset();
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
        ASSERT_EQ(response.status().code(), pspb::Status::NOT_EXISTS);
    } END_OF_CASE;
    {
        // in recovery
        auto segment = create_mock_segment();
        segment->_recovery_status = gaiadb::RECOVERY_IN;
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        request.set_offset(16<<10);
        request.set_size(16<<10);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRead, segment, &request, &response, nullptr);
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
        ASSERT_EQ(response.status().code(), pspb::Status::IN_RECOVERY);
    } END_OF_CASE;
    {
        // quota fail
        auto segment = create_mock_segment();
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        request.set_offset(16<<10);
        request.set_size(16<<10);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRead, segment, &request, &response, nullptr);
        ctx->task.offset = request.offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_read_flow_cntl, GetQuota(_, _)).WillOnce(Return(1));
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
        ASSERT_EQ(response.status().code(), pspb::Status::LIMIT);
    } END_OF_CASE;
    {
        // GetOrAllocBufBlock fail
        auto segment = create_mock_segment();
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        request.set_offset(16<<10);
        request.set_size(16<<10);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRead, segment, &request, &response, nullptr);
        ctx->task.offset = request.offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_read_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(nullptr));
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
        ASSERT_EQ(response.status().code(), pspb::Status::LIMIT);
    } END_OF_CASE;
    {
        // ReadPhysicalPageData fail
        auto segment = create_mock_segment();
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        request.set_offset(16<<10);
        request.set_size(16<<10);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRead, segment, &request, &response, nullptr);
        ctx->task.offset = request.offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_read_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kIOError)));
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
        ASSERT_EQ(response.status().code(), pspb::Status::ERROR);
    } END_OF_CASE;
    {
        // page_is_corrupted
        auto segment = create_mock_segment();
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        request.set_offset(16<<10);
        request.set_size(16<<10);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRead, segment, &request, &response, nullptr);
        ctx->task.offset = request.offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_read_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        //EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(true)));

        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
        ASSERT_EQ(response.status().code(), pspb::Status::ERROR);
    } END_OF_CASE;
    {
        // ok
        auto segment = create_mock_segment();
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        request.set_offset(16<<10);
        request.set_size(16<<10);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRead, segment, &request, &response, nullptr);
        ctx->task.offset = request.offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_read_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        //EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        _recoverer->OnCompletion(ctx);
        LOG(NOTICE) << response.status();
        ASSERT_EQ(response.status().code(), pspb::Status::SUCCESS);
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    } END_OF_CASE;
}


TEST_F(RecoveryTests, test_OnRead_dblwr_gc_lsn) {
    _recoverer->_stopped = false;
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    {
        // dblwr ckp_lsn > segment gc_lsn → response gc_lsn bumped to dblwr ckp_lsn
        auto segment = create_mock_segment();
        segment->_gc_lsn(1000);
        auto mock_dblwr = new MockDblwr();
        segment->_dblwr.reset(mock_dblwr);
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        request.set_offset(16<<10);
        request.set_size(16<<10);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRead, segment, &request, &response, nullptr);
        ctx->task.offset = request.offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_read_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        ON_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillByDefault(Return(_buf_block));
        EXPECT_CALL(*mock_dblwr, ReadCkpLsn(_))
            .WillOnce(DoAll(SetArgPointee<0>(2000), Return(db::Status())));
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::SUCCESS);
        ASSERT_EQ(response.gc_lsn(), static_cast<gaia_apply::lsn_t>(2000));
    } END_OF_CASE;
    {
        // dblwr ckp_lsn <= segment gc_lsn → response gc_lsn unchanged
        auto segment = create_mock_segment();
        segment->_gc_lsn(2000);
        auto mock_dblwr = new MockDblwr();
        segment->_dblwr.reset(mock_dblwr);
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        request.set_offset(16<<10);
        request.set_size(16<<10);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRead, segment, &request, &response, nullptr);
        ctx->task.offset = request.offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_read_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        ON_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillByDefault(Return(_buf_block));
        EXPECT_CALL(*mock_dblwr, ReadCkpLsn(_))
            .WillOnce(DoAll(SetArgPointee<0>(1000), Return(db::Status())));
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::SUCCESS);
        ASSERT_EQ(response.gc_lsn(), static_cast<gaia_apply::lsn_t>(2000));
    } END_OF_CASE;
    {
        // dblwr ReadCkpLsn fails → response gc_lsn unchanged (uses segment gc_lsn)
        auto segment = create_mock_segment();
        segment->_gc_lsn(1500);
        auto mock_dblwr = new MockDblwr();
        segment->_dblwr.reset(mock_dblwr);
        pspb::ReadRequest request;
        pspb::ReadResponse response;
        request.set_offset(16<<10);
        request.set_size(16<<10);
        auto ctx = new Recoverer::Context(Recoverer::Action::kOnRead, segment, &request, &response, nullptr);
        ctx->task.offset = request.offset();
        ctx->task.size = request.size();
        EXPECT_CALL(*_mock_read_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        ON_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillByDefault(Return(_buf_block));
        EXPECT_CALL(*mock_dblwr, ReadCkpLsn(_))
            .WillOnce(Return(db::Status(db::Code::kIOError)));
        EXPECT_CALL(*segment, ReadPhysicalPageDataWithDblwr(_, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        _recoverer->OnCompletion(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::SUCCESS);
        ASSERT_EQ(response.gc_lsn(), static_cast<gaia_apply::lsn_t>(1500));
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    } END_OF_CASE;
}

TEST_F(RecoveryTests, test_SetPriorNum) {
    auto segment1 = create_segment();
    auto segment2 = create_segment_by_cluster("cluster2", 200);

    // add tasks to the same store
    {
        auto task1 = std::make_shared<Recoverer::Task>(segment1, false);
        task1->prior_num = 0;
        auto task2 = std::make_shared<Recoverer::Task>(segment2, false);
        task2->prior_num = 0;
        _recoverer->_recover_store_tasks[segment1->store_id()].push_back(task1);
        _recoverer->_recover_store_tasks[segment1->store_id()].push_back(task2);
    }

    {
        // set prior_num for segment2, should reorder
        _recoverer->SetPriorNum(segment2, 10);

        auto& tasks = _recoverer->_recover_store_tasks[segment1->store_id()];
        ASSERT_EQ(tasks.size(), 2);
        // segment2 (prior_num=10) should be first (DESC order)
        auto it = tasks.begin();
        ASSERT_EQ((*it)->segment.lock(), segment2);
        ASSERT_EQ((*it)->prior_num, 10);
        ++it;
        ASSERT_EQ((*it)->segment.lock(), segment1);
        ASSERT_EQ((*it)->prior_num, 0);
    } END_OF_CASE;

    {
        // set same prior_num, no reorder
        _recoverer->SetPriorNum(segment2, 10);
        auto& tasks = _recoverer->_recover_store_tasks[segment1->store_id()];
        auto it = tasks.begin();
        ASSERT_EQ((*it)->segment.lock(), segment2);
        ASSERT_EQ((*it)->prior_num, 10);
    } END_OF_CASE;

    {
        // set prior_num for segment1 to higher value, reorder again
        _recoverer->SetPriorNum(segment1, 20);
        auto& tasks = _recoverer->_recover_store_tasks[segment1->store_id()];
        auto it = tasks.begin();
        ASSERT_EQ((*it)->segment.lock(), segment1);
        ASSERT_EQ((*it)->prior_num, 20);
        ++it;
        ASSERT_EQ((*it)->segment.lock(), segment2);
        ASSERT_EQ((*it)->prior_num, 10);
    } END_OF_CASE;

    {
        // non-existent segment - no crash
        auto segment3 = create_segment_by_cluster("cluster3", 300);
        _recoverer->SetPriorNum(segment3, 5);
        // should simply return without modifying anything
        auto& tasks = _recoverer->_recover_store_tasks[segment1->store_id()];
        ASSERT_EQ(tasks.size(), 2);
    } END_OF_CASE;

    _recoverer->_recover_store_tasks.clear();
}

TEST_F(RecoveryTests, test_OnGetLog) {
    EXPECT_CALL(*_mock_thread_pool, Stop(_)).WillRepeatedly(Return());
    auto segment = create_segment();
    auto mock_append_db_engine = new MockAppendDBEngine();
    segment->_append_db_engine.reset(mock_append_db_engine);
    auto mock_get_redo_log_flow_cntl = new MockFlowControl;
    _recoverer->_get_redo_log_flow_cntl.reset(mock_get_redo_log_flow_cntl);

    pspb::GetRedoRecLogRequest request;
    pspb::GetRedoRecLogResponse response;

    {
        // server stopped
        _recoverer->_stopped = true;
        auto* ctx = new Recoverer::Context(Recoverer::Action::kGetLog, segment,
                &request, &response, nullptr);
        _recoverer->OnGetLog(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::ERROR);
        _recoverer->_stopped = false;
    } END_OF_CASE;

    {
        // segment expired (weak_ptr)
        auto tmp_segment = create_segment_by_cluster("tmp_cluster", 999);
        auto* ctx = new Recoverer::Context(Recoverer::Action::kGetLog, tmp_segment,
                &request, &response, nullptr);
        tmp_segment.reset();  // expire weak_ptr
        _recoverer->OnGetLog(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::NOT_EXISTS);
    } END_OF_CASE;

    {
        // segment in recovery
        segment->_recovery_status.store(gaiadb::RECOVERY_IN);
        auto* ctx = new Recoverer::Context(Recoverer::Action::kGetLog, segment,
                &request, &response, nullptr);
        _recoverer->OnGetLog(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::IN_RECOVERY);
        segment->_recovery_status.store(gaiadb::RECOVERY_FINISH);
    } END_OF_CASE;

    {
        // fetch_lsn >= gc_lsn => RECOVERY_FINISH
        segment->set_gc_lsn(5000);
        request.set_fetch_lsn(5000);
        auto* ctx = new Recoverer::Context(Recoverer::Action::kGetLog, segment,
                &request, &response, nullptr);
        _recoverer->OnGetLog(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::RECOVERY_FINISH);
    } END_OF_CASE;

    {
        // flow control limit
        segment->set_gc_lsn(10000);
        segment->_append_lsn(10000);
        request.set_fetch_lsn(5000);
        EXPECT_CALL(*mock_get_redo_log_flow_cntl, GetQuota(_, _)).WillOnce(Return(100));
        auto* ctx = new Recoverer::Context(Recoverer::Action::kGetLog, segment,
                &request, &response, nullptr);
        _recoverer->OnGetLog(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::LIMIT);
    } END_OF_CASE;

    {
        // FetchRedoLog fails
        segment->set_gc_lsn(10000);
        segment->_append_lsn(10000);
        request.set_fetch_lsn(5000);
        EXPECT_CALL(*mock_get_redo_log_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        EXPECT_CALL(*mock_append_db_engine, FetchRedoLog(_, _, _, _, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kCorrupted)));
        auto* ctx = new Recoverer::Context(Recoverer::Action::kGetLog, segment,
                &request, &response, nullptr);
        _recoverer->OnGetLog(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::ERROR);
    } END_OF_CASE;

    {
        // FetchRedoLog success
        segment->set_gc_lsn(10000);
        segment->_append_lsn(10000);
        request.set_fetch_lsn(5000);
        request.set_append_db_block_no(1);
        request.set_append_db_block_offset(100);

        db::LogHeader log_header;
        //memset(&log_header, 0, sizeof(log_header));
        log_header.start_lsn = 4900;
        log_header.end_lsn = 5100;
        log_header.records_count = 0;
        log_header.fold_size = 3;
        log_header.key_size = 0;
        log_header.key_crc = db::get_crc(nullptr, 0);
        log_header.buf_crc = db::get_crc(nullptr, 0);
        db::make_checksum(&log_header, db::kLogHeaderSize);

        EXPECT_CALL(*mock_get_redo_log_flow_cntl, GetQuota(_, _)).WillOnce(Return(0));
        EXPECT_CALL(*mock_append_db_engine, FetchRedoLog(_, _, _, _, _, _, _, _))
            .WillOnce(DoAll(
                        SetArgPointee<1>(log_header),
                        Return(db::Status(db::Code::kOk))));
        auto* ctx = new Recoverer::Context(Recoverer::Action::kGetLog, segment,
                &request, &response, nullptr);
        _recoverer->OnGetLog(ctx);
        ASSERT_EQ(response.status().code(), pspb::Status::SUCCESS);
        ASSERT_EQ(response.record_num(), 0);
        ASSERT_EQ(response.fold_size(), 3);
        ASSERT_EQ(response.last_lsn(), 5100);
    } END_OF_CASE;
}

}
}
