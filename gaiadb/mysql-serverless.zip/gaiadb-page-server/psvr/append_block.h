/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/append_block.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <sys/uio.h>
#include <atomic>
#include "psvr/common.h"
#include "psvr/dbengine.h"
#include <base/slice.h>

namespace psvr {
namespace db {

uint32_t get_crc(const void* buf, uint32_t buf_size);

template<typename F>
bool check_is_corrupt(const F& data, uint32_t data_size) {
    const uint32_t data_crc = get_crc(reinterpret_cast<const void*>(&data),
            data_size - sizeof(data.checksum));
    LOG_IF(TRACE, data_crc != data.checksum) << "calc_crc:" << data_crc
        << " expected:" << data.checksum;
    return data_crc != data.checksum;
}

template<typename F>
void make_checksum(F* data, uint32_t data_size) {
    const uint32_t data_crc = get_crc(reinterpret_cast<const void*>(data),
            data_size - sizeof(data->checksum));
    data->checksum = data_crc;
}

static constexpr uint64_t kBlockHeaderMagic = 0xe0bc05774c521ea;     // echo "kBlockHeaderMagic" |md5sum| cut -c 1-15
static constexpr uint32_t kBlockHeaderProtoVersion = 0x01;
static constexpr uint32_t kBlockHeaderSize = 4096;
struct ALIGNAS(sizeof(uint32_t)) BlockHeader {
    uint64_t magic;
    uint32_t proto_version;
    uint32_t pad1;
    uint64_t start_lsn;
    char pad[4068]; // 4k
    uint32_t checksum;   // checksum must be at the end
    BlockHeader(uint64_t lsn)
        : magic(kBlockHeaderMagic), proto_version(kBlockHeaderProtoVersion),
        pad1(0), start_lsn(lsn), checksum(0) {
        memset(pad, 0x0, sizeof(pad));
    }
};
static_assert(sizeof(BlockHeader) == kBlockHeaderSize);

std::ostream& DumpBlockHeader(const BlockHeader& header, std::ostream& os);

inline std::ostream& operator<<(std::ostream& os, const BlockHeader& log) {
    return DumpBlockHeader(log, os);
}

static constexpr uint64_t kBlockFooterMagic = 0xc1bbb9702885f55;     // echo "kBlockFooterMagic" |md5sum| cut -c 1-15
static constexpr uint32_t kBlockFooterProtoVersion = 0x01;
static constexpr uint32_t kBlockFooterSize = 512;
static constexpr uint32_t kBlockFooterSlotNum = 24;

struct BlockFooterSlot {
    uint64_t start_lsn;
    uint32_t offset;
    uint32_t log_num;
};
static_assert(sizeof(BlockFooterSlot) == 16);

class BlockFooterSlots {
public:
    bool Add(uint32_t index, uint64_t start_lsn, uint64_t offset, uint32_t log_num);
    void Reset(const BlockFooterSlot* slots);
    bool Find(uint64_t seek_lsn, uint64_t* offset, uint64_t* start_lsn = nullptr) const;
    void CopyTo(BlockFooterSlot* slots) const;

private:
    mutable rwlock_t _mutex;
    BlockFooterSlot _slots[kBlockFooterSlotNum] = {};
};
using BlockFooterSlotsPtr = std::shared_ptr<BlockFooterSlots>;

struct ALIGNAS(sizeof(uint32_t)) BlockFooter {
    uint64_t magic;
    uint32_t proto_version;
    uint32_t log_num;
    uint64_t start_lsn;
    uint64_t end_lsn;
    uint64_t last_start_lsn;
    uint32_t file_size;
    uint32_t pad1;
    BlockFooterSlot slots[kBlockFooterSlotNum];
    char pad[76];
    uint32_t checksum;      // checksum must be at the end
    BlockFooter()
        : magic(kBlockFooterMagic), proto_version(kBlockFooterProtoVersion),
        log_num(0), start_lsn(0), end_lsn(0),
        last_start_lsn(0), file_size(0), pad1(0), checksum(0) {
        memset(slots, 0x0, sizeof(slots));
        memset(pad, 0x0, sizeof(pad));
    }
};
static_assert(sizeof(BlockFooter) == kBlockFooterSize);

static constexpr uint64_t kBlockSlotsMagic = 0x62393f2825371b2;
static constexpr uint32_t kBlockSlotsVersion = 0x01;
static constexpr uint32_t kBlockSlotsSize = 4096;

struct ALIGNAS(sizeof(uint32_t)) BlockSlots {
    uint64_t magic;
    uint32_t proto_version;
    uint32_t pad1;
    uint64_t fno;
    uint64_t start_lsn;
    uint64_t seq;
    BlockFooterSlot slots[kBlockFooterSlotNum];
    char pad[3668];
    uint32_t checksum;      // checksum must be at the end
    BlockSlots()
        : magic(kBlockSlotsMagic), proto_version(kBlockSlotsVersion), pad1(0),
        fno(0), start_lsn(0), seq(0), checksum(0) {
        memset(slots, 0x0, sizeof(slots));
        memset(pad, 0x0, sizeof(pad));
    }
};
static_assert(sizeof(BlockSlots) == kBlockSlotsSize);

std::ostream& DumpBlockSlots(const BlockSlots& slots, std::ostream& os);

inline std::ostream& operator<<(std::ostream& os, const BlockSlots& log) {
    return DumpBlockSlots(log, os);
}

class DualSectorFile {
public:
    DualSectorFile(std::string fname, uint32_t sector_size)
        : _file_name(std::move(fname)), _sector_size(sector_size),
        _fd(-1), _sector(false) {}
    FUNC_MOCK ~DualSectorFile();

    Status Open(bool* need_init);
    Status Close();
    Status Read(void* sectors) const;
    Status Write(const void* sector);
    Status Reset(const void* empty);
    void SetNextSector(bool sector) { _sector = sector; }

private:
    const std::string _file_name;
    const uint32_t _sector_size;
    int _fd;
    bool _sector;
};

class BlockSlotsBlock {
public:
    explicit BlockSlotsBlock(const std::string& fname)
        : _file_name(fname), _file(fname, kBlockSlotsSize), _seq(0) {}
    FUNC_MOCK ~BlockSlotsBlock();

    FUNC_MOCK Status Open();
    FUNC_MOCK Status Close();
    BlockFooterSlotsPtr NewSlots();
    bool AddSlot(uint32_t index, uint64_t start_lsn, uint64_t offset, uint32_t log_num);
    FUNC_MOCK Status Update(uint64_t fno, uint64_t start_lsn);
    FUNC_MOCK Status Load(uint64_t fno, uint64_t start_lsn,
            BlockFooterSlot* slots, bool* found) const;
    FUNC_MOCK Status Reset();

    static std::ostream& Dump(int fd, std::ostream& os);

private:
    Status ResetNoLock();

private:
    const std::string _file_name;
    DualSectorFile _file;
    BlockFooterSlotsPtr _slots;
    uint64_t _seq;
    BlockSlots _last;
    mutable std::mutex _mutex;
};

std::ostream& DumpBlockFooter(const BlockFooter& footer, std::ostream& os);

inline std::ostream& operator<<(std::ostream& os, const BlockFooter& log) {
    return DumpBlockFooter(log, os);
}

static constexpr uint64_t kCheckPointMagic = 0x77ac772a2deb592;     // echo "kCheckPointMagic" |md5sum| cut -c 1-15
static constexpr uint32_t kCheckPointVersion = 0x01;
static constexpr uint32_t kCheckPointSize = 4096;
struct ALIGNAS(sizeof(uint32_t)) CheckPoint {
    uint64_t magic;
    uint32_t proto_version;
    uint32_t pad1;
    uint64_t lsn;
    uint64_t last_lsn;
    char pad[4060]; // 4096
    uint32_t checksum;      // checksum must be at the end
    CheckPoint() : magic(kCheckPointMagic), proto_version(kCheckPointVersion),
        pad1(0), lsn(0), last_lsn(0), checksum(0) {
        memset(pad, 0x0, sizeof(pad));
    }
};
static_assert(sizeof(CheckPoint) == kCheckPointSize);

std::ostream& DumpCheckPoint(const CheckPoint& ckp, std::ostream& os);

inline std::ostream& operator<<(std::ostream& os, const CheckPoint& log) {
    return DumpCheckPoint(log, os);
}

class RandomAccessBlock;

class Block {
public:
    Block(const std::string& fname, uint64_t fno)
        : _fd(-1), _file_name(fname), _file_no(fno), _file_size(0),
        _start_lsn(0), _write_start_lsn(0), _write_end_lsn(0), _log_num(0),
        _is_seal(false) {}
    FUNC_MOCK ~Block();

    uint64_t file_no() const { return _file_no; }
    size_t file_size() const { return _file_size; }
    uint32_t log_num() const { return _log_num; }
    const std::string& file_name() const { return _file_name; }

    uint64_t start_lsn() const { return _start_lsn; }
    uint64_t write_end_lsn() const { return _write_end_lsn; }

    FUNC_MOCK Status Open(uint64_t start_lsn);
    FUNC_MOCK Status Close();

    FUNC_MOCK Status Append(const struct iovec* iov, int iovcnt, size_t data_size,
            uint64_t log_start_lsn, uint64_t log_end_lsn,
            uint64_t* fno, uint64_t* off, bool sync,
            uint32_t log_num = 1, uint64_t last_start_lsn = 0);

    FUNC_MOCK Status Seal();

    void set_slots(const BlockFooterSlotsPtr& slots) { _slots = slots; }

    FUNC_MOCK Status Sync(bool data = false);

    static Status AppendFooter(bool sync, int fd, uint64_t off,
            uint32_t log_num, uint64_t start_lsn, uint64_t end_lsn, uint64_t last_start_lsn,
            const BlockFooterSlot* slots = nullptr);

private:
    int _fd;
    const std::string _file_name;
    const uint64_t _file_no;
    size_t _file_size;
    uint64_t _start_lsn;
    uint64_t _write_start_lsn;
    uint64_t _write_end_lsn;
    uint32_t _log_num;
    bool _is_seal;
    BlockFooterSlotsPtr _slots;
    std::mutex _mutex;
};

class RandomAccessBlock {
public:
    RandomAccessBlock(const std::string& fname,
        uint64_t fno, int fd, uint64_t start_lsn)
        : _file_name(fname), _file_no(fno), _fd(fd),
        _start_lsn(start_lsn), _end_lsn(0), _file_size(0) {}
    FUNC_MOCK ~RandomAccessBlock() { close(_fd); }

    const std::string& file_name() { return _file_name; }
    int fd() const { return _fd; }
    uint64_t file_no() const { return _file_no; }
    uint64_t start_lsn() const { return _start_lsn; }

    uint64_t end_lsn() const { return _end_lsn.load(); }
    void set_end_lsn(uint64_t lsn) { _end_lsn.store(lsn); }

    uint64_t file_size() const { return _file_size.load(); }
    void set_file_size(uint64_t size) { _file_size.store(size); }

    void set_slots(const BlockFooterSlotsPtr& slots) { _slots = slots; }
    bool FindSlotOffset(uint64_t seek_lsn, uint64_t* offset, uint64_t* start_lsn = nullptr) const;

    FUNC_MOCK Status Read(uint64_t offset, size_t n, base::Slice* result, char* buf) const;
    FUNC_MOCK Status Readx(uint64_t offset, size_t n, base::Slice* result, char* buf) const;

    FUNC_MOCK Status Delete();

    using ParseFn = std::function<bool(gaia_apply::byte*, gaia_apply::byte*, gaia_apply::lsn_t)>;
    static std::ostream& DumpAndParse(int fd, std::ostream& os, ParseFn fn, bool dump_key = false);

    static std::ostream& Dump(int fd, std::ostream& os);

private:
    const std::string _file_name;
    const uint64_t _file_no;
    const int _fd;
    const uint64_t _start_lsn;
    std::atomic<uint64_t> _end_lsn;
    std::atomic<uint64_t> _file_size;
    BlockFooterSlotsPtr _slots;
};

class CheckPointBlock {
public:
    CheckPointBlock(const std::string& fname)
        : _file_name(fname), _file(fname, kCheckPointSize),
        _lsn(0), _delete_obsolete_lsn(0) {}
    FUNC_MOCK ~CheckPointBlock() { Close(); }

    gaia_apply::lsn_t lsn() const { return _lsn(); }
    gaia_apply::lsn_t delete_obsolete_lsn() { return _delete_obsolete_lsn(); }

    FUNC_MOCK Status Open();
    FUNC_MOCK Status Close();

    FUNC_MOCK Status Update(uint64_t lsn);

    FUNC_MOCK Status Reset();

    static std::ostream& Dump(int fd, std::ostream& os);

private:
    Status ResetNoLock();

private:
    const std::string _file_name;
    DualSectorFile _file;
    Lsn _lsn;
    Lsn _delete_obsolete_lsn;
    std::mutex _mutex;
};

static constexpr uint32_t kLogHeaderMagic = 0x138e3d7;   // echo "LogHeader" | md5sum | cut -c 1-7
static constexpr uint32_t kLogHeaderVserion = 0x1;
static constexpr uint32_t kLogHeaderSize = 128;
static constexpr uint64_t kReadBufMinSize = kLogHeaderSize * 8;

struct ALIGNAS(sizeof(uint32_t)) LogHeader {
    uint32_t magic;
    uint32_t proto_version;
    uint64_t start_lsn;
    uint64_t end_lsn;
    uint32_t key_crc;
    uint32_t buf_crc;
    uint32_t records_count;
    uint32_t fetch_from_ip;
    uint32_t fetch_from_port;
    uint32_t fold_size;
    uint32_t key_size;
    uint32_t value_size;
    char pad[68];
    uint32_t checksum;      // checksum must be at the end
    LogHeader () {
        memset(pad, 0x0, sizeof(pad));
    }
};
static_assert(sizeof(uint32_t) == 4);
static_assert(sizeof(LogHeader) == kLogHeaderSize);

std::ostream& DumpLogHeader(const LogHeader& log, std::ostream& os);

inline std::ostream& operator<<(std::ostream& os, const LogHeader& log) {
    return DumpLogHeader(log, os);
}

}
}
