/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/rw16k.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <memory>
#include <iostream>
#include <filesystem>
#include <sys/stat.h>
#include <base/time.h>
#include <cstdio>
#include <psvr/compress_utils.h>
#include <gflags/gflags.h>
#include <base/fast_rand.h>
#include <baidu/rpc/channel.h>
#include <baidu/rpc/controller.h>
#include <baidu/rpc/errno.pb.h>
#include <baidu/rpc/server.h>
#include <bvar/bvar.h>

DEFINE_string(action, "", "action: test_lat, test_rw, test_create, test_sync");
DEFINE_string(file_name, "", "file name for test_lat or test_rw or test_sync");
DEFINE_int32(test_num, 10, "number of test");
DEFINE_int32(port, 8989, "brpc server port");

DEFINE_string(pre_file_name, "", "prefix file name for test_create");
DEFINE_int32(test_create_file_num, 100, "number of create files for test_create");
DEFINE_int64(test_create_file_size, 34359738368, "file size for test_create");
DEFINE_int32(test_create_thread_num, 8, "thread num for test_create");
DEFINE_uint64(sync_size, 34359738368, "sync when update size");

DEFINE_string(disk_file_name, "", "file name for test_sync");
DEFINE_string(disk2_file_name, "", "file name for test_sync");

bvar::LatencyRecorder read_lat("io_read", 10);
bvar::LatencyRecorder write_lat("io_write", 10);

bvar::LatencyRecorder disk_read_lat("disk_io_read", 10);
bvar::LatencyRecorder disk_write_lat("disk_io_write", 10);

bvar::LatencyRecorder disk2_read_lat("disk2_io_read", 10);
bvar::LatencyRecorder disk2_write_lat("disk2_io_write", 10);

const char* test_rw_cmd = " -action=test_rw -file_name=<file_name>";
const char* test_lat_cmd = " -action=test_lat -file_name=<file_name> -test_num=<num>";
const char* test_create_cmd = " -action=test_create -pre_file_name=<pre_file_name> -test_create_file_num=<num> -test_create_thread_num<num>";
const char* test_sync_cmd = " -action=test_sync -test_num=<num> -file_name=<file_name> -sync_size=<size> -disk_file_name=<file_name2> -disk2_file_name=<disk2_file_name>";

void run_rw() {
    if (FLAGS_file_name.empty()) {
        std::cout << "missing -file_name" << std::endl;
        return;
    }

    const char* file_name = FLAGS_file_name.c_str();
    int fd = open(file_name, O_CREAT | O_RDWR | O_EXCL, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        printf("open file:%s failed:%s\n", file_name, strerror(errno));
        return;
    }

    std::cout << "create file, file_size:" << std::filesystem::file_size(file_name) << std::endl;

    char buf[8192];
    off_t off = 0;
    off_t len = 8192;
    ssize_t read_size = pread(fd, buf, len, off);
    std::cout<< "read non write range,"
        <<  " offset:" << off
        << " len:" << len
        << " return_size:" << read_size
        << " file_size:" << std::filesystem::file_size(file_name)
        << " errno:" << errno << " err:" << strerror(errno) << std::endl;

    off = 4096;
    ssize_t write_size = pwrite(fd, buf, len, off);
    std::cout<< "write new range,"
        <<  " offset:" << off
        << " len:" << len
        << " return_size:" << write_size
        << " file_size:" << std::filesystem::file_size(file_name)
        << " errno:" << errno << " err:" << strerror(errno) << std::endl;

    off = 0;
    read_size = pread(fd, buf, len, off);
    std::cout<< "read half write range,"
        <<  " offset:" << off
        << " len:" << len
        << " return_size:" << read_size
        << " file_size:" << std::filesystem::file_size(file_name)
        << " errno:" << errno << " err:" << strerror(errno) << std::endl;

    off = 8196;
    read_size = pread(fd, buf, len, off);
    std::cout<< "read half write range,"
        <<  " offset:" << off
        << " len:" << len
        << " return_size:" << read_size
        << " file_size:" << std::filesystem::file_size(file_name)
        << " errno:" << errno << " err:" << strerror(errno) << std::endl;

    off = 4<<20;
    int ret = fallocate(fd, FALLOC_FL_PUNCH_HOLE | FALLOC_FL_KEEP_SIZE, off, len);
    std::cout<< "fallocate non write range,"
        <<  " offset:" << off
        << " len:" << len
        << " file_size:" << std::filesystem::file_size(file_name)
        << " ret:" << ret << std::endl;

    close(fd);

    auto file_size = std::filesystem::file_size(file_name);
    std::cout<< "file_size:" << file_size << std::endl;

    std::filesystem::remove_all(file_name);
}

void run_lat() {
    if (FLAGS_file_name.empty()) {
        std::cout << "missing -file_name" << std::endl;
        return;
    }

    const char* file_name = FLAGS_file_name.c_str();

    size_t size_arr[] = {16<<10, 64<<10, 128<<10, 256<<10, 512<<10,
        1<<20, 4<<20, 16<<20, 64<<20, 128<<20, 256<<20, 512<<20,
        1lu<<30, 4lu<<30, 8lu<<30, 16lu<<30, 32lu<<30};
    size_t size_arr_count = sizeof(size_arr) / sizeof(size_arr[0]);

    for (size_t i = 0; i < size_arr_count; ++i) {
        int64_t max = 0;
        int64_t min = std::numeric_limits<int64_t>::max();
        int64_t total = 0;
        int32_t test_nr = FLAGS_test_num;
        for (int32_t n = 0; n < test_nr; ++n) {
            int fd = open(file_name, O_CREAT | O_RDWR | O_EXCL, S_IRUSR | S_IWUSR);
            if (fd < 0) {
                printf("open file:%s failed:%s\n", file_name, strerror(errno));
                return;
            }

            auto begin = base::cpuwide_time_us();
            if (fallocate(fd, 0, 0/*offset*/, size_arr[i]) != 0) {
                printf("resize file:%s size:%lu failed:%s\n", file_name, size_arr[i], strerror(errno));
                return;
            }

            auto cost = base::cpuwide_time_us() - begin;

            close(fd);
            std::filesystem::remove_all(file_name);

            if (cost > max) {
                max = cost;
            }
            if (cost < min) {
                min = cost;
            }
            total += cost;
        }

        std::cout << "test_num:" << test_nr
            << " size:" << size_arr[i]
            << " max_cost:" << max << "us"
            << " min_cost:" << min << "us"
            << " avg_cost:" << (total * 1.0 / test_nr) << "us" << std::endl;
    }
}

void run_create() {
    if (FLAGS_pre_file_name.empty()) {
        std::cout << "missing -pre_file_name" << std::endl;
        return;
    }

    int32_t file_num = FLAGS_test_create_file_num;
    auto flags = O_CREAT | O_RDWR | O_EXCL;
    int64_t file_size = FLAGS_test_create_file_size;
    int32_t thread_num = FLAGS_test_create_thread_num;
    auto page_num = file_size / (16<<10);

    std::mutex mutex;
    std::list<int32_t> file_list;
    std::atomic<int32_t> finish_file_num = 0;
    bool stopped = false;

    std::cout << "file num:" << file_num
              << " file size:" << file_size
              << " thread_num:" << thread_num
              << std::endl;

    for (int32_t n = 0; n < thread_num; ++n) {
        std::cout << "create thread id:" << n << std::endl;
        std::thread t([&](){
            while (!stopped) {
                int32_t file_id = -1;
                {
                    std::unique_lock lk(mutex);
                    if (!file_list.empty()) {
                        file_id = file_list.front();
                        file_list.pop_front();
                    }
                }
                if (file_id == -1) {
                    std::this_thread::sleep_for(std::chrono::microseconds(3000));
                    continue;
                }

                std::string file_name = FLAGS_pre_file_name + "_" + std::to_string(file_id);
                int fd = open(file_name.c_str(), flags, S_IRUSR | S_IWUSR);
                if (fd < 0) {
                    std::cout << "open failed," << " file_name:[" << file_name << "] err:[" << strerror(errno) << "]" << std::endl;
                    return;
                }
                std::cout << "create file, name:" << file_name << std::endl;
                // reset file size, holding file system physical size
                if (fallocate(fd, 0, 0/*offset*/, file_size) != 0) {
                    std::cout << "fallocate fail, retry ftruncate" << std::endl;
                    return;
                }
                std::cout << "fallocate file, name:" << file_name
                          << " size:" << file_size
                          << std::endl;

                uint64_t offset = 0;
                uint64_t size = 0;
                for (int64_t j = 0; j < page_num; ++j) {
                    offset = j * (16 << 10);
                    size = ((base::fast_rand() % 3) + 1) * 4096;
                    offset += (16 << 10) - size;
                    if (fallocate(fd, FALLOC_FL_PUNCH_HOLE | FALLOC_FL_KEEP_SIZE, offset, size) != 0) {
                        std::cout << "fallocate file failed,"
                            << " file_id:" << file_id
                            << " offset:" << offset
                            << " size:" << size
                            << std::endl;
                    }
                }

                int64_t start_time = base::cpuwide_time_us();
                fsync(fd);
                std::cout << "sync used time:" << (base::cpuwide_time_us() - start_time)
                          << "us" << std::endl;

                close(fd);
                finish_file_num.fetch_add(1);
            }
        });
        t.detach();
    }

    for (int32_t i = 0; i < file_num; ++i) {
        {
            std::unique_lock lk(mutex);
            file_list.push_back(i);
        }
    }

    std::cout << "push task done" << std::endl;

    while (true) {
        if (finish_file_num.load() == file_num) {
            stopped = true;
            break;
        }
        std::this_thread::sleep_for(std::chrono::microseconds(3000));
    }

    exit(1);
}

void rw_disk(const char* file_name, bool* stopped,
        bvar::LatencyRecorder* rlat, bvar::LatencyRecorder* wlat) {
    int fd = open(file_name, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        printf("open file:%s failed:%s\n", file_name, strerror(errno));
        return;
    }

    bool rw = false;
    char buf[16<<10];
    size_t buf_size = 16<<10;
    while (!*stopped) {
        size_t pos = (base::fast_rand() / buf_size * buf_size) % (32lu<<30);
        auto st = base::cpuwide_time_us();
        if (rw) {
            pread(fd, buf, buf_size, pos);
            (*rlat) << (base::cpuwide_time_us() - st);
        } else {
            pwrite(fd, buf, buf_size, pos);
            (*wlat) << (base::cpuwide_time_us() - st);
        }
        rw = !rw;
    }
    close(fd);
}

void run_sync() {
    if (FLAGS_file_name.empty()) {
        std::cout << "missing -file_name" << std::endl;
        return;
    }


    bool test_stopped = false;
    if (FLAGS_disk_file_name.size()) {
        std::thread disk_rw_t(&rw_disk, FLAGS_disk_file_name.c_str(), &test_stopped, &disk_read_lat, &disk_write_lat);
        disk_rw_t.detach();
    }

    if (FLAGS_disk2_file_name.size()) {
        std::thread disk2_rw_t(&rw_disk, FLAGS_disk2_file_name.c_str(), &test_stopped, &disk2_read_lat, &disk2_write_lat);
        disk2_rw_t.detach();
    }

    const char* file_name = FLAGS_file_name.c_str();
    int32_t test_nr = FLAGS_test_num;
    int64_t max = 0;
    int64_t min = std::numeric_limits<int64_t>::max();;

    char buf[16<<10];
    uint64_t buf_size = 16<<10;
    for (int32_t n = 0; n < test_nr; ++n) {

        int fd = open(file_name, O_CREAT | O_RDWR | O_EXCL, S_IRUSR | S_IWUSR);
        if (fd < 0) {
            printf("open file:%s failed:%s\n", file_name, strerror(errno));
            test_stopped = true;
            return;
        }

        uint64_t i = 0;
        volatile bool stopped = false;
        std::thread read_t([&fd, &i, &stopped](){
            char read_buf[16<<10];
            size_t read_buf_size = 16<<10;
            while(!stopped) {
                if (i == 0) {
                    std::this_thread::sleep_for(std::chrono::microseconds(10000));
                    continue;
                }
                size_t pos = (base::fast_rand() / read_buf_size * read_buf_size) % i;
                auto st = base::cpuwide_time_us();
                pread(fd, read_buf, read_buf_size, pos);
                read_lat << (base::cpuwide_time_us() - st);
            }
        });

        uint64_t update_size = 0;

        int64_t w_max = 0;
        int64_t w_min = std::numeric_limits<int64_t>::max();
        int64_t w_count = 0;
        int64_t w_total = 0;

        auto task_begin = base::cpuwide_time_us();
        for (; i < (32lu<<30); i += buf_size) {
            {
                auto begin = base::cpuwide_time_us();
                pwrite(fd, buf, buf_size, i);
                auto cost = base::cpuwide_time_us() - begin;
                write_lat << cost;

                w_max = std::max(w_max, cost);
                w_min = std::min(w_min, cost);
                w_total += cost;
                ++w_count;
            }

            update_size += buf_size;
            if (update_size == FLAGS_sync_size) {
                auto begin = base::cpuwide_time_us();
                std::cout << "start sync:" << std::endl;
                fsync(fd);
                auto cost = base::cpuwide_time_us() - begin;

                max = std::max(max, cost);
                min = std::min(min, cost);

                std::cout << "sync size:" << update_size
                    << " cost:" << cost << "us"
                    << " write cost:" << (base::cpuwide_time_us() - task_begin) << "us"
                    << std::endl;
                std::cout << "pwrite cost:"
                    << " max:" << w_max
                    << " min:" << w_min
                    << " avg:" << (w_total * 1.0) / w_count
                    << std::endl;

                update_size = 0;
                w_max = 0;
                w_min = std::numeric_limits<int64_t>::max();
                w_count = 0;
                w_total = 0;
                task_begin = base::cpuwide_time_us();
            }
        }

        stopped = true;
        read_t.join();

        close(fd);
        std::filesystem::remove_all(file_name);
    }

    test_stopped = true;
    std::cout << "test_num:" << test_nr
        << " max_cost:" << max << "us"
        << " min_cost:" << min << "us"
        << std::endl;
}

int main(int argc, char *argv[]) {
    google::ParseCommandLineFlags(&argc, &argv, true);
    if (FLAGS_action.empty()) {
        std::cout << "missing -action" << std::endl;
        std::cout << "Usage: https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/PA2gxLX6I5/SNzdpV2fcc/w7muODTXQyZGeu" << std::endl;
        std::cout << argv[0] << " [OPTION]" << std::endl;
        std::cout << "  " << test_rw_cmd << std::endl;
        std::cout << "  " << test_lat_cmd << std::endl;
        std::cout << "  " << test_create_cmd << std::endl;
        std::cout << "  " << test_sync_cmd << std::endl;
        return -1;
    }

    baidu::rpc::Server rpc_server;
    baidu::rpc::ServerOptions options;
    options.num_threads = 9;
    options.idle_timeout_sec = -1;
    if (rpc_server.Start(FLAGS_port, &options)) {
        std::cout << "brpc server start failed" << std::endl;
        return -1;
    }

    if (FLAGS_action == "test_lat") {
        run_lat();
    } else if (FLAGS_action == "test_rw") {
        run_rw();
    } else if (FLAGS_action == "test_create") {
        run_create();
    } else if (FLAGS_action == "test_sync") {
        run_sync();
    } else {
        std::cout << "invalid -action=" << FLAGS_action << std::endl;
    }

    return 0;
}
