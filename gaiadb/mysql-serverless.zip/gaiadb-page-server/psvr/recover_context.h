/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/recover_context.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/context_types.h"
#include "psvr/client.h"
#include "psvr/namespace.h"
#include "psvr/time_point.h"
#include "psvr/recover.h"

namespace psvr {

struct Recoverer::Task {
    SegmentWeakPtr segment;
    bool is_check;
    int32_t store_id;
    bool start_status;
    std::atomic<int32_t> task_size;
    uint32_t prior_num;
    std::atomic<uint32_t> inflight_req_size;
    std::atomic<uint64_t> recover_total_size;

    Task(SegmentPtr seg, bool check)
        : segment(seg),
        is_check(check),
        store_id(seg->store_id()),
        start_status(false),
        task_size(0),
        prior_num(0),
        inflight_req_size(0),
        recover_total_size(0) {}

    ~Task() {}

    uint32_t IncInflightReqSize(uint32_t n = 1) {
        return inflight_req_size.fetch_add(n, std::memory_order_relaxed);
    }

    uint32_t TryDecInflightReqSize(uint32_t v, uint32_t n = 1) {
        uint32_t val = inflight_req_size.load();
        if (val >= v + n) {
            return inflight_req_size.compare_exchange_strong(val, val - n);
        }
        return false;
    }

    uint32_t DecInflightReqSize(uint32_t n = 1) {
        uint32_t nr = inflight_req_size.fetch_sub(n, std::memory_order_relaxed);
        PSVR_ASSERT(nr >= 1);
        return nr;
    }

    uint32_t InflightReqSize() const {
        return inflight_req_size.load();
    }
};

struct Recoverer::Context : public thread::TaskContext {
    Action action;

    int32_t fix_client_id {-1};
    int32_t shift_client_id {0};

    SegmentWeakPtr segment {};
    RecoverBlockTask task {};
    gaia_apply::lsn_t lsn {0};
    //
    std::shared_ptr<Task> recover_task {nullptr};
    //
    gaia_apply::space_id_t local_space_id {gaia_apply::SPACE_UNKNOWN};
    gaia_apply::page_no_t local_page_no {gaia_apply::FIL_NULL};
    gaia_apply::lsn_t local_page_lsn {0};
    //
    int32_t recover_from_peer_fail_num {0};
    //
    std::vector<gaiadb::common::PeerZone> replicas {};
    std::set<base::EndPoint> empty_replicas {};
    brpc::Controller rpc_ctx_cntl {};
    std::unique_ptr<RpcReadPageCtx> rpc_ctx {nullptr};
    brpc::Controller* cntl {nullptr};
    // for src
    const pspb::ReadPageRequest* request {nullptr};
    pspb::ReadPageResponse* response {nullptr};
    // for read
    const pspb::ReadRequest* read_req {nullptr};
    pspb::ReadResponse* read_rsp {nullptr};
    // for write
    const pspb::WritePhysicalPageRequest* write_req {nullptr};
    pspb::WritePhysicalPageResponse* write_rsp {nullptr};
    // for get redo log
    const pspb::GetRedoRecLogRequest* get_log_req {nullptr};
    pspb::GetRedoRecLogResponse* get_log_rsp {nullptr};
    //
    ggpb::Closure* closure {nullptr};
    //
    pspb::Status st;
    uint32_t retry_times {0};
    bool has_quota {false};
    bool in_condition {false};
    bool wait_gc {false};
    bool peer_wait_gc_lsn {false};
    bool counted_inflight {false};

    Timer stat_timer;
    TimePoint* tp {nullptr};

    Context(Action _action)
            : thread::TaskContext(CtxType::kRecovery), action(_action) {}
    Context(Action _action, SegmentPtr _segment)
            : thread::TaskContext(CtxType::kRecovery),
            action(_action), segment(_segment) {}
    Context(Action _action, SegmentPtr _segment,
            const pspb::ReadPageRequest* _request,
            pspb::ReadPageResponse* _response,
            ggpb::Closure* _closure)
            : thread::TaskContext(CtxType::kRecovery),
            action(_action), segment(_segment),
            request(_request), response(_response), closure(_closure) {}
    Context(Action _action, SegmentPtr _segment,
            const pspb::ReadRequest* _request,
            pspb::ReadResponse* _response,
            ggpb::Closure* _closure)
            : thread::TaskContext(CtxType::kRecovery),
            action(_action), segment(_segment),
            read_req(_request), read_rsp(_response), closure(_closure) {}
    Context(Action _action, SegmentPtr _segment,
            const pspb::GetRedoRecLogRequest* _request,
            pspb::GetRedoRecLogResponse* _response,
            ggpb::Closure* _closure)
            : thread::TaskContext(CtxType::kRecovery),
            action(_action), segment(_segment),
            get_log_req(_request), get_log_rsp(_response), closure(_closure) {}
    Context(Action _action, SegmentPtr _segment,
            const pspb::WritePhysicalPageRequest* _request,
            pspb::WritePhysicalPageResponse* _response,
            ggpb::Closure* _closure)
            : thread::TaskContext(CtxType::kRecovery),
            action(_action), segment(_segment),
            write_req(_request), write_rsp(_response), closure(_closure) {}
    virtual ~Context() {
        if (closure) {
            baidu::rpc::ClosureGuard guard(closure);
        }
        TP_DESTROY(tp);
    }

    void Reset(Action _action) {
        action = _action;
        lsn = 0;
        local_space_id = gaia_apply::SPACE_UNKNOWN;
        local_page_no = gaia_apply::FIL_NULL;
        local_page_lsn  = 0;
        replicas.clear();
        empty_replicas.clear();
        rpc_ctx = nullptr;
        retry_times = 0;
        has_quota = false;
        wait_gc = false;
        peer_wait_gc_lsn = false;
        stat_timer.reset();
    }
};

}
