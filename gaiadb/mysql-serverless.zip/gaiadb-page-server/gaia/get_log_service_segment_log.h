/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_log_service_segment_log.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"
#include <gaiadb/proto/log_service/psrv_message_servcie.pb.h>
#include <gaiadb/proto/log_service/lsrv_error_code.pb.h>

namespace psvr {
namespace gaia {

class GetLogServiceSegmentLog : public Command {
public:
    GetLogServiceSegmentLog() {
        SetName("get-ls-seg-log");
        SetDesc("get segment redo log from a specified log service node");
        SetDescCn("从指定的日志服务节点获取分片的 redo 日志");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "the cluster id", kstring, kGroup2Scope);
        AddRequiredArgOption("segment-id", NULL, 's',
                "the segment id, can be specified multiple times", kuint32_t, kGroup2Scope);
        AddRequiredArgOption("fetch-lsn", &_long_opt_val, kOptMax + 1,
                "fetch redo log start lsn, one for each --segment-id", kuint64_t, kGroup2Scope);

        AddExample("-a <ip> -p <port> -c cluster_id -s segment_id --fetch-lsn lsn");
        AddExample("-a <ip> -p <port> -c cluster_id"
                " -s segment_id1 --fetch-lsn lsn1"
                " -s segment_id2 --fetch-lsn lsn2");
    }
    virtual ~GetLogServiceSegmentLog() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_ids.push_back(std::strtoul(opt, NULL, 10));
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _fetch_lsns.push_back(std::strtoull(opt, NULL, 10));
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    bool CheckSegments();
    int RunSingle(const base::EndPoint& node);
    int RunBatch(const base::EndPoint& node);

    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const lspb::psrv_get_log_response& rsp);
    int Format(const lspb::batch_psrv_get_log_response& rsp);
    bool PrintRecords(const std::string& data, uint32_t total_len, uint32_t checksum);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    std::vector<uint32_t> _segment_ids;
    std::vector<uint64_t> _fetch_lsns;
};

}
}
