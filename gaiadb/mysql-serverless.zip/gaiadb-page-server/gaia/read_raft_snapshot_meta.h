/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/read_raft_snapshot_meta.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <raft/cli.pb.h>
#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ReadRaftSnapshotMeta : public Command {
public:
    ReadRaftSnapshotMeta() {
        SetName("read-raft-snapshot-meta");
        SetDesc("read raft snapshot meta file");
        SetDescCn("解析 Raft 快照元数据文件");

        AddRequiredArgOption("file", &_long_opt_val, kOptMax + 1, "raft meta file name", kstring);

        AddNoArgOption("fix-path", &_long_opt_val, kOptMax + 2, "fix snapshot file path", kGroup2Scope);

        AddExample("--file <file_name>");
    }
    virtual ~ReadRaftSnapshotMeta() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _file = opt;
                break;
            case kOptMax + 2:
                _fix_path = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

private:
    std::string _file{};
    bool _fix_path {false};
};

}
}
