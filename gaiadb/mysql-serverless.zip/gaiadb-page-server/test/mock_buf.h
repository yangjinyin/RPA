/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_buf.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/buf.h"

namespace psvr {
namespace test {

class MockBufPool : public BufPool {
public:
    MockBufPool() : BufPool() {}
    virtual ~MockBufPool() {}

    MOCK_METHOD1(Init, bool(bool));

    MOCK_METHOD2(AllocBufBlock, BufBlockPtr(gaia_apply::ulint, gaia_apply::byte*));
    MOCK_METHOD1(GetOrAllocBufBlock, BufBlockPtr(gaia_apply::ulint));

    BufBlockPtr RealAllocBufBlock(gaia_apply::ulint size, gaia_apply::byte* frame) {
        return BufPool::AllocBufBlock(size, frame);
    }

};

}
}
