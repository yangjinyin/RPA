/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/add_segment_replica.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/add_segment_replica.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int AddSegmentReplica::Run() {
    RpcStatus status;
    gaiapb::AddReplicaRequest request;
    gaiapb::AckResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_segment_id < 1) {
        print_error("miss --segment-id or error, %u", _segment_id);
        return 1;
    }

    if (!_replica_id.has_val) {
        print_error("miss --replica-id");
        return 1;
    }

    if (_replica_addr.empty()) {
        print_error("miss --replica-addr");
        return 1;
    }

    if (_zone.Invalid()) {
        print_error("error, --region and --available-zone should always appear in pairs");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("add this segment replica=%s?", _replica_addr.c_str());
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    request.set_segment_id(_segment_id);
    request.set_replica_id(_replica_id.val);
    request.set_addr(_replica_addr);
    request.set_log_id(_log_id);
    if (_zone.region.size()) {
        request.mutable_zone()->set_region(_zone.region);
        request.mutable_zone()->set_available_zone(_zone.available_zone);
    }

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::add_replica, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " add replica failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("add replica failed, all nodes failed");
    return Output(response);
}

int AddSegmentReplica::Format(const gaiapb::AckResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
