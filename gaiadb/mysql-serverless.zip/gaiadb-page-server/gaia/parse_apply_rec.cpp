/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/parse_apply_rec.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/parse_apply_rec.h"

namespace psvr::gaia {

GaiaLogRecordIterator::GaiaLogRecordIterator(
        gaia_apply::byte* start_ptr,
        gaia_apply::byte* end_ptr,
        gaia_apply::lsn_t page_apply_lsn,
        const gaia_apply::space_id_t* apply_space_id,
        const gaia_apply::page_no_t* apply_page_no)
        : _scan_ptr(start_ptr),
          _start_ptr(start_ptr),
          _end_ptr(end_ptr),
          _last_record_end_lsn(page_apply_lsn),
          _apply_space_id(apply_space_id),
          _apply_page_no(apply_page_no),
          _record(nullptr),
          _record_len(0),
          _record_initialized(false),
          _valid(false) {
    LoadNext();
}

GaiaLogRecordIterator::~GaiaLogRecordIterator() {
    ResetRecord();
}

size_t GaiaLogRecordIterator::ConsumedSize() const {
    auto* consumed_ptr = _scan_ptr;
    if (_valid) {
        consumed_ptr += sizeof(uint64_t) + _record_len;
    }
    return static_cast<size_t>(consumed_ptr - _start_ptr);
}

void GaiaLogRecordIterator::ResetRecord() {
    if (_record_initialized) {
        _record->~LogRecord();
        _record = nullptr;
        _record_initialized = false;
    }
}

void GaiaLogRecordIterator::Next() {
    if (!_valid) {
        return;
    }
    _scan_ptr += sizeof(uint64_t) + _record_len;
    ResetRecord();
    _valid = false;
    LoadNext();
}

void GaiaLogRecordIterator::LoadNext() {
    while (_scan_ptr && _scan_ptr < _end_ptr) {
        const auto remaining =
                static_cast<size_t>(_end_ptr - _scan_ptr);
        if (remaining <= sizeof(uint64_t)) {
            // Keep the incomplete record header for the next input buffer.
            return;
        }

        const auto rec_end_lsn = get_record_end_lsn(_scan_ptr);
        if (rec_end_lsn <= _last_record_end_lsn) {
            _status.Reset(db::Code::kCorrupted,
                    "page lsn is not less than redo record lsn");
            return;
        }

        auto* record_start = _scan_ptr + sizeof(uint64_t);
        gaia_apply::ulint record_len = 0;
        LogRecord* record = nullptr;
        auto st = parse_append_redo_record(
                record_start,
                _end_ptr,
                rec_end_lsn,
                _record_storage,
                &record,
                &record_len);
        if (st.IsNotFound() || st.IsMissData()) {
            return;
        }
        if (!st.IsOk()) {
            _status = st;
            return;
        }

        _record = record;
        _record_len = record_len;
        _record_initialized = true;
        _last_record_end_lsn = rec_end_lsn;
        if (_apply_space_id && _apply_page_no
                && (_record->space_id != *_apply_space_id
                    || _record->page_no != *_apply_page_no)) {
            _scan_ptr += sizeof(uint64_t) + _record_len;
            ResetRecord();
            continue;
        }
        _valid = true;
        return;
    }
}

bool ApplyPageLogRecordsNoLock(
        BufBlockPtr apply_buf_block,
        gaia_apply::lsn_t* page_apply_lsn,
        uint64_t* apply_records_size,
        LogRecordIteratorInterface& iter,
        uint32_t max_apply_num) {
    for (; iter.Valid(); iter.Next()) {
        const auto& record = iter.Get();
        const auto rec_end_lsn = record.end_lsn;
        const auto type = record.type;
        const auto body = record.body;
        const auto body_len = record.body_len;
        const auto space_id = record.space_id;
        const auto page_no = record.page_no;

        std::cout << "record info,"
            << " rec_start_lsn:[" << record.start_lsn
            << "] rec_end_lsn:[" << rec_end_lsn
            << "] type:[" << static_cast<int32_t>(type)
            << "] type_str:[" << gaia_apply::rec_type_name(type)
            << "] space:[" << space_id
            << "] page:[" << page_no
            << "] body_len:[" << body_len
            << "] real_page_last_lsn:[" << record.last_page_lsn
            << "]" << std::endl;

        if (!apply_buf_block) {
            continue;
        }
        if (*page_apply_lsn >= rec_end_lsn) {
            std::cout << "page_apply_lsn > rec_end_lsn" << std::endl;
            continue;
        }
        if (*apply_records_size == 0) {
            gaia_apply::page_size_t page_size(
                    gaia_apply::FLAGS_univ_page_size,
                    gaia_apply::FLAGS_univ_page_size, false);
            init_buf_block(apply_buf_block, space_id, page_no, page_size);
        }

        LOG(INFO) << "apply record info,"
            << " rec_start_lsn:[" << record.start_lsn
            << "] rec_end_lsn:[" << rec_end_lsn
            << "] type:[" << static_cast<int32_t>(type)
            << "] type_str:[" << gaia_apply::rec_type_name(type)
            << "] body_len:[" << body_len << "]";

        auto st = page_apply_log_record(record, apply_buf_block,
                page_apply_lsn);
        if (!st.IsOk()) {
            std::cout << "apply redo record failed,"
                << " rec_body:[" << base::HexEncode(body, body_len)
                << "] status:[" << st << "]" << std::endl;
            return false;
        }

        ++(*apply_records_size);
        std::cout << "apply record ok, records size:"
            << (*apply_records_size) << std::endl;

        if (max_apply_num > 0 && *apply_records_size >= max_apply_num) {
            std::cout << "apply record num over limit:"
                << (*apply_records_size) << std::endl;
            break;
        }
    }
    if (!iter.Status().IsOk()) {
        std::cout << "parse redo record failed: "
            << iter.Status() << std::endl;
        return false;
    }
    return true;
}

bool parse_records(gaia_apply::byte* start_ptr,
        gaia_apply::byte* end_ptr,
        gaia_apply::lsn_t* page_apply_lsn,
        uint64_t* apply_records_size,
        BufBlockPtr apply_buf_block,
        const gaia_apply::space_id_t* apply_space_id,
        const gaia_apply::page_no_t* apply_page_no,
        uint32_t max_apply_num,
        size_t* consumed_size) {

    uint64_t apply_num = 0;
    if (!apply_records_size) {
        apply_records_size = &apply_num;
    }

    if (apply_buf_block) {
        if (!apply_space_id || !apply_page_no) {
            std::cout << "apply need specify page";
            return false;
        }
    }

    GaiaLogRecordIterator iter(start_ptr, end_ptr, *page_apply_lsn,
            apply_space_id, apply_page_no);
    auto st = ApplyPageLogRecordsNoLock(apply_buf_block,
            page_apply_lsn, apply_records_size, iter, max_apply_num);
    if (consumed_size) {
        *consumed_size = iter.ConsumedSize();
    }
    return st;
}

}
