/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/create_space.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/create_space.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int CreateSpace::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_space_id.has_val) {
        print_error("miss --space-id");
        return 1;
    }

    if (!_force) {
        if (!execute_confirm("create space:%u ?", _space_id.val)) {
            std::cout << "quit!" << std::endl;
            return -1;
        }
    }

    gaiapb::CreateSpaceRequest request;
    gaiapb::CreateSpaceResponse response;

    request.set_space_id(_space_id.val);
    request.set_alloc_number(_alloc_extent_num);
    auto meta = request.mutable_space_meta();
    meta->set_is_compressed(false);
    meta->set_is_encrypted(false);
    meta->set_logical_page_size(gaia_apply::FLAGS_univ_page_size);
    meta->set_physical_page_size(gaia_apply::FLAGS_univ_page_size);
    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::create_space, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " create space failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("create failed, all nodes failed");
    return Output(response);
}

int CreateSpace::Format(const gaiapb::CreateSpaceResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
