/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/append_block.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/append_block.h"
#include <filesystem>
#include <algorithm>
#include <cstring>
#include "psvr/utils.h"

namespace psvr {
namespace db {

uint32_t get_crc(const void* buf, uint32_t buf_size) {
    return gaiadb::common::ut_crc32(reinterpret_cast<const gaiadb::common::detail::ut_byte*>(buf),
            static_cast<gaiadb::common::detail::ut_ulint>(buf_size));
}

std::ostream& DumpBlockHeader(const BlockHeader& header, std::ostream& os) {
    os << "magic:0x" << std::hex << header.magic << std::dec
        << " proto_version:" << std::hex << header.proto_version << std::dec
        << " start_lsn:" << header.start_lsn
        << " checksum:" << header.checksum;
    if (header.magic != kBlockHeaderMagic) {
        os << " expect_magic:0x" << std::hex << kBlockHeaderMagic << std::dec;
    }
    const uint32_t calc_crc = get_crc(reinterpret_cast<const void*>(&header),
            kBlockHeaderSize - sizeof(header.checksum));
    if (header.checksum != calc_crc) {
        os << " calc_checksum:" << calc_crc;
    }
    return os;
}

std::ostream& DumpBlockFooter(const BlockFooter& footer, std::ostream& os) {
    os << "magic:0x" << std::hex << footer.magic << std::dec
        << " proto_version:" << std::hex << footer.proto_version << std::dec
        << " log_num:" << footer.log_num
        << " start_lsn:" << footer.start_lsn
        << " end_lsn:" << footer.end_lsn
        << " last_start_lsn:" << footer.last_start_lsn
        << " file_size:" << footer.file_size
        << " checksum:" << footer.checksum;
    if (footer.magic != kBlockFooterMagic) {
        os << " expect_magic:0x" << std::hex << kBlockFooterMagic << std::dec;
    }
    const uint32_t calc_crc = get_crc(reinterpret_cast<const void*>(&footer),
            kBlockFooterSize - sizeof(footer.checksum));
    if (footer.checksum != calc_crc) {
        os << " calc_checksum:" << calc_crc;
    }
    return os;
}

std::ostream& DumpCheckPoint(const CheckPoint& ckp, std::ostream& os) {
    os << "magic:0x" << std::hex << ckp.magic << std::dec
        << " proto_version:" << std::hex << ckp.proto_version << std::dec
        << " lsn:" << ckp.lsn
        << " last_lsn:" << ckp.last_lsn
        << " checksum:" << ckp.checksum;
    if (ckp.magic != kCheckPointMagic) {
        os << " expect_magic:0x" << std::hex << kCheckPointMagic << std::dec;
    }
    const uint32_t calc_crc = get_crc(reinterpret_cast<const void*>(&ckp),
            kCheckPointSize - sizeof(ckp.checksum));
    if (ckp.checksum != calc_crc) {
        os << " calc_checksum:" << calc_crc;
    }
    return os;
}


Block::~Block() {
    if (_fd > -1) {
        Close();
    }
}

Status Block::Open(uint64_t start_lsn) {
    std::unique_lock lk(_mutex);
    Status st;
    if (_fd > - 1) {
        st.Reset(Code::kOk, "file is opened");
        return st;
    }
    if (std::filesystem::exists(_file_name)) {
        std::string tmp(_file_name);
        tmp.append(".").append(std::to_string(time(NULL)));
        std::error_code ec;
        std::filesystem::rename(_file_name, tmp, ec);
        if (ec) {
            st.Reset(GetErrCode(), "rename file:%s to %s failed, %m",
                    _file_name.c_str(), tmp.c_str());
            return st;
        }
    }
    _fd = open(_file_name.c_str(), O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
    if (_fd < 0) {
        st.Reset(GetErrCode(), "open file:%s failed, %m", _file_name.c_str());
        return st;
    }
    PSVR_ASSERT(_file_size == 0);
    BlockHeader header(start_lsn);
    make_checksum(&header, kBlockHeaderSize);
    st = db::pwritex(_fd, &header, kBlockHeaderSize, _file_size);
    if (!st.IsOk()) {
        st.ResetMsg("append file:%s header failed, %m", _file_name.c_str());
        return st;
    }
    _file_size += kBlockHeaderSize;
    _start_lsn = start_lsn;
    _write_start_lsn = _start_lsn;
    _write_end_lsn = _start_lsn;
    st = Sync();
    if (!st.IsOk()) {
        return st;
    }
    return db::sync_directoryx(std::filesystem::path(_file_name).parent_path().c_str());
}

Status Block::Close() {
    Status st = Seal();
    if (!st.IsOk()) {
        return st;
    }
    if (_fd > -1) {
        if (db::fdatasync(_fd) != 0) {
            st.Reset(GetErrCode(), "fdatasync file:%s failed, %m", _file_name.c_str());
        }
        close(_fd);
        _fd = -1;
    }
    LOG(TRACE) << "block close,"
        << " file:[" << _file_name
        << "]";
    return st;
}

Status Block::Append(const struct iovec* iov, int iovcnt, size_t data_size,
        uint64_t log_start_lsn, uint64_t log_end_lsn,
        uint64_t* fno, uint64_t* off, bool sync,
        uint32_t log_num, uint64_t last_start_lsn) {
    std::unique_lock lk(_mutex);
    Status st;
    st = db::pwritevx(_fd, iov, iovcnt, _file_size);
    if (!st.IsOk()) {
        st.ResetMsg("append file:%s failed, off:%lu, usize:%lu %m",
                _file_name.c_str(), _file_size, data_size);
        return st;
    }

    if (sync && db::fdatasync(_fd) != 0) {
        st.Reset(GetErrCode(), "fdatasync file:%s failed, %m", _file_name.c_str());
        return st;
    }

    PSVR_ASSERT(log_start_lsn >= _write_end_lsn);
    _write_start_lsn = log_num == 1 ? log_start_lsn : last_start_lsn;
    _write_end_lsn = log_end_lsn;

    _log_num += log_num;

    *fno = _file_no;
    *off = _file_size;

    _file_size += data_size;
    return st;
}

Status Block::AppendFooter(bool sync, int fd, uint64_t off,
        uint32_t log_num, uint64_t start_lsn, uint64_t end_lsn, uint64_t last_start_lsn,
        const BlockFooterSlot* slots) {
    BlockFooter footer;
    footer.log_num = log_num;
    footer.start_lsn = start_lsn;
    footer.end_lsn = end_lsn;
    footer.last_start_lsn = last_start_lsn;
    footer.file_size = static_cast<uint32_t>(off + kBlockFooterSize);
    if (slots != nullptr) {
        std::memcpy(footer.slots, slots, sizeof(footer.slots));
    }
    make_checksum(&footer, kBlockFooterSize);
    Status st = db::pwritex(fd, &footer, kBlockFooterSize, off);
    if (!st.IsOk()) {
        return st;
    }
    if (sync && db::fdatasync(fd) != 0) {
        st.Reset(GetErrCode(), "fdatasync footer failed, fd:%d, %m", fd);
    }
    return st;
}

Status Block::Seal() {
    std::unique_lock lk(_mutex);
    Status st;
    if (_is_seal) {
        return st;
    }
    BlockFooterSlot slots[kBlockFooterSlotNum] = {};
    if (_slots) {
        _slots->CopyTo(slots);
    }
    st = AppendFooter(false, _fd, _file_size,
                _log_num, _start_lsn, _write_end_lsn, _write_start_lsn,
                _slots ? slots : nullptr);
    if (!st.IsOk()) {
        st.ResetMsg("append file:%s footer failed, off:%lu, usize:%u %m",
                _file_name.c_str(), _file_size, kBlockFooterSize);
        return st;
    }
    _is_seal = true;
    _file_size += kBlockFooterSize;
    return st;
}

bool BlockFooterSlots::Add(uint32_t index, uint64_t start_lsn, uint64_t offset, uint32_t log_num) {
    if (index >= kBlockFooterSlotNum || offset > UINT32_MAX) {
        return false;
    }
    std::unique_lock lk(_mutex);
    BlockFooterSlot& slot = _slots[index];
    if (slot.offset != 0) {
        return false;
    }
    slot.start_lsn = start_lsn;
    slot.offset = offset;
    slot.log_num = log_num;
    return true;
}

void BlockFooterSlots::Reset(const BlockFooterSlot* slots) {
    std::unique_lock lk(_mutex);
    std::memcpy(_slots, slots, sizeof(_slots));
}

bool BlockFooterSlots::Find(uint64_t seek_lsn, uint64_t* offset, uint64_t* start_lsn) const {
    std::shared_lock lk(_mutex);
    const BlockFooterSlot* best = nullptr;
    for (const auto& slot : _slots) {
        if (slot.start_lsn == 0 || slot.offset == 0 || slot.start_lsn > seek_lsn) {
            continue;
        }
        if (best == nullptr || slot.start_lsn > best->start_lsn) {
            best = &slot;
        }
    }
    if (best == nullptr) {
        return false;
    }
    *offset = best->offset;
    if (start_lsn != nullptr) {
        *start_lsn = best->start_lsn;
    }
    return true;
}

void BlockFooterSlots::CopyTo(BlockFooterSlot* slots) const {
    std::shared_lock lk(_mutex);
    std::memcpy(slots, _slots, sizeof(_slots));
}

bool RandomAccessBlock::FindSlotOffset(uint64_t seek_lsn, uint64_t* offset,
        uint64_t* start_lsn) const {
    return _slots != nullptr && _slots->Find(seek_lsn, offset, start_lsn);
}

Status Block::Sync(bool data) {
    Status st;
    int ret = data ? db::fdatasync(_fd) : db::fsync(_fd);
    if (ret != 0) {
        st.Reset(GetErrCode(), "sync file:%s failed, %m", _file_name.c_str());
    }
    return st;
}

Status RandomAccessBlock::Read(uint64_t offset, size_t n,
        base::Slice* result, char* buf) const {
    Status st;
    ssize_t rsize  = db::pread(_fd, buf, n, offset);
    *result = base::Slice(buf, (rsize < 0) ? 0 : rsize);
    if (rsize < 0) {
        st.Reset(GetErrCode(), "read random file:%s failed, rsize:%ld, off:%lu, usize:%lu %m",
                _file_name.c_str(), rsize, offset, n);
    }
    return st;
}

Status RandomAccessBlock::Readx(uint64_t offset, size_t n,
        base::Slice* result, char* buf) const {
    Status st = db::preadx(_fd, buf, n, offset);
    if (st.IsOk()) {
        *result = base::Slice(buf, n);
    }
    return st;
}

Status RandomAccessBlock::Delete() {
    Status st;
    std::error_code ec;
    bool ret = std::filesystem::remove(_file_name, ec);
    if (ec) {
        st.Reset(GetErrCode(), "remove file:%s failed, %s",
                _file_name.c_str(), ec.message().c_str());
        return st;
    }
    LOG(NOTICE) << "remove file ok,"
        << " file:[" << _file_name
        << "] file_exists:[" << ret
        << "]";
    if (ret) {
        st = db::sync_directoryx(std::filesystem::path(_file_name).parent_path().c_str());
    }
    return st;
}

std::ostream& RandomAccessBlock::DumpAndParse(int fd, std::ostream& os, ParseFn fn, bool dump_key) {
    ssize_t file_size = 0;
    if (!get_file_size(fd, &file_size)) {
        return os << "get file size failed, errno:" << errno << std::endl;
    }

    if (file_size < kBlockHeaderSize) {
        return os << "file size < kBlockHeaderSize" << std::endl;
    }

    BlockHeader header(0);
    ssize_t off = 0;
    ssize_t r = db::pread(fd, &header, kBlockHeaderSize, off);
    if (r != kBlockHeaderSize) {
        return os << "read file header failed, errno:" << errno << " read_size:" << r << std::endl;
    }

    os << "file-size:" << file_size << "\n";
    os << "---header:\n";
    os << "off:" << off << " ";
    DumpBlockHeader(header, os);
    os << "\n";
    off += kBlockHeaderSize;

    BlockFooter footer;
    r = db::pread(fd, &footer, kBlockFooterSize, file_size - kBlockFooterSize);
    if (r == kBlockFooterSize) {
        if (footer.magic == kBlockFooterMagic && !check_is_corrupt(footer, kBlockFooterSize)) {
            os << "---footer:\n";
            os << "off:" << (file_size - kBlockFooterSize) << " ";
            DumpBlockFooter(footer, os);
            os << "\n";
            file_size -= kBlockFooterSize;
        } else {
            os << "---invalid footer:\n";
            os << "off:" << (file_size - kBlockFooterSize) << " ";
            DumpBlockFooter(footer, os);
            os << "\n";
        }
    }

    os << "---data:\n";
    LogHeader log_header;
    size_t num = 1;

    uint32_t buf_size = MBToByte(2);
    gaia_apply::byte* buf = static_cast<gaia_apply::byte*>(std::malloc(buf_size));

    while (off < file_size) {
        r = db::pread(fd, &log_header, kLogHeaderSize, off);
        if (r != kLogHeaderSize) {
            return os << "read file log header failed, errno:" << errno << " read_size:" << r << std::endl;
        }
        os << "No:" << num << " off:" << off << " ";
        DumpLogHeader(log_header, os);
        off  += kLogHeaderSize;
        const ssize_t key_off = off;
        off += log_header.key_size;
        os << " key_off:" << key_off;
        os << " value_off:" << off;
        os << "\n";
        if (check_is_corrupt(log_header, kLogHeaderSize)) {
            return os << "log is corrupt" << std::endl;
        }

        if (dump_key && log_header.key_size > 0) {
            if (log_header.key_size <= buf_size) {
                r = db::pread(fd, buf, log_header.key_size, key_off);
                if (r != log_header.key_size) {
                    return os << "read file key data failed, errno:" << errno << " read_size:" << r << std::endl;
                }
                constexpr size_t kFoldEntrySize = sizeof(uint64_t) + sizeof(uint32_t);
                const uint32_t fold_num = std::min<uint32_t>(
                        log_header.fold_size, log_header.key_size / kFoldEntrySize);
                for (uint32_t i = 0; i < fold_num; ++i) {
                    uint64_t fold_key = 0;
                    uint32_t extent_id = 0;
                    std::memcpy(&fold_key, buf + i * kFoldEntrySize, sizeof(uint64_t));
                    std::memcpy(&extent_id, buf + i * kFoldEntrySize + sizeof(uint64_t), sizeof(uint32_t));
                    os << "  key[" << i << "] space_id:" << u64tou32first(fold_key)
                        << " aligned_page_no:" << u64tou32second(fold_key)
                        << " extent_id:" << extent_id << "\n";
                }
            } else {
                os << "  key_size:" << log_header.key_size << " exceeds buf_size, skip key dump\n";
            }
        }

        if (buf_size >= log_header.value_size) {
            r = db::pread(fd, buf, log_header.value_size, off);
            if (r != log_header.value_size) {
                return os << "read file log data failed, errno:" << errno << " read_size:" << r << std::endl;
            }

            if (!fn(buf, buf + log_header.value_size, log_header.start_lsn)) {
                return os << "parse failed" << std::endl;
            }
        }

        off += log_header.value_size;
        ++num;
    }

    if (off == file_size) {
        os << "block data is ok\n";
    }

    return os;
}

std::ostream& RandomAccessBlock::Dump(int fd, std::ostream& os) {
    return DumpAndParse(fd, os,
            [](gaia_apply::byte*, gaia_apply::byte*, gaia_apply::lsn_t) { return true; });
}

DualSectorFile::~DualSectorFile() {
    Close();
}

Status DualSectorFile::Open(bool* need_init) {
    Status st;
    *need_init = false;
    int32_t fd = open(_file_name.c_str(), O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        st.Reset(GetErrCode(), "open file:%s failed, %m", _file_name.c_str());
        return st;
    }
    GuardFd guard(fd);

    ssize_t file_size = 0;
    if (!get_file_size(fd, &file_size)) {
        st.Reset(GetErrCode(), "get file:%s size failed, %m", _file_name.c_str());
        return st;
    }

    const ssize_t file_bytes = static_cast<ssize_t>(_sector_size) * 2;
    if (file_size < file_bytes) {
        if (file_size != 0) {
            LOG(WARNING) << "reset dual sector file size,"
                << " file:[" << _file_name
                << "] file_size:[" << file_size
                << "]";
        }
        if (db::ftruncate(fd, file_bytes) != 0) {
            st.Reset(GetErrCode(), "truncate file:%s failed, %m", _file_name.c_str());
            return st;
        }
        if (db::fsync(fd) != 0) {
            st.Reset(GetErrCode(), "sync file:%s failed, %m", _file_name.c_str());
            return st;
        }
        *need_init = true;
    }
    _fd = fd;
    fd = -1;
    return st;
}

Status DualSectorFile::Close() {
    Status st;
    if (_fd > -1) {
        if (db::fdatasync(_fd) != 0) {
            st.Reset(GetErrCode(), "fdatasync file:%s failed, %m", _file_name.c_str());
        }
        close(_fd);
        _fd = -1;
    }
    return st;
}

Status DualSectorFile::Read(void* sectors) const {
    return db::preadx(_fd, sectors, static_cast<size_t>(_sector_size) * 2, 0);
}

Status DualSectorFile::Write(const void* sector) {
    Status st;
    const size_t off = _sector ? _sector_size : 0;
    st = db::pwritex(_fd, sector, _sector_size, off);
    if (!st.IsOk()) {
        st.ResetMsg("write file:%s failed, off:%lu, %m",
                _file_name.c_str(), static_cast<unsigned long>(off));
        return st;
    }
    if (db::fdatasync(_fd) != 0) {
        st.Reset(GetErrCode(), "sync file:%s failed, %m", _file_name.c_str());
        return st;
    }
    _sector = !_sector;
    return st;
}

Status DualSectorFile::Reset(const void* empty) {
    Status st;
    st = db::pwritex(_fd, empty, _sector_size, 0);
    if (!st.IsOk()) {
        st.ResetMsg("reset file:%s failed, %m", _file_name.c_str());
        return st;
    }
    st = db::pwritex(_fd, empty, _sector_size, _sector_size);
    if (!st.IsOk()) {
        st.ResetMsg("reset file:%s failed, %m", _file_name.c_str());
        return st;
    }
    if (db::fsync(_fd) != 0) {
        st.Reset(GetErrCode(), "sync file:%s failed, %m", _file_name.c_str());
        return st;
    }
    _sector = false;
    return st;
}

Status CheckPointBlock::Open() {
    std::unique_lock lk(_mutex);
    Status st;
    bool need_init = false;
    st = _file.Open(&need_init);
    if (!st.IsOk()) {
        return st;
    }
    if (need_init) {
        return ResetNoLock();
    }

    CheckPoint sectors[2];
    st = _file.Read(&sectors);
    if (!st.IsOk()) {
        st.ResetMsg("read file:%s failed, %m", _file_name.c_str());
        return st;
    }

    if (sectors[0].magic != kCheckPointMagic
            || sectors[1].magic != kCheckPointMagic) {
        st.Reset(Code::kMissData, "file:%s magic mismatch, magic0:%lu, magic1:%lu, expected:%lu",
                _file_name.c_str(), sectors[0].magic, sectors[1].magic, kCheckPointMagic);
        return st;
    }

    const bool corrupt0 = check_is_corrupt(sectors[0], kCheckPointSize);
    const bool corrupt1 = check_is_corrupt(sectors[1], kCheckPointSize);
    if (corrupt0 && corrupt1) {
        st.Reset(Code::kCorrupted, "file:%s checksum are failed, corrupt0:%d, corrupt1:%d",
                _file_name.c_str(), corrupt0, corrupt1);
        return st;
    }

    if (corrupt1) {
        _file.SetNextSector(true);
        _lsn(sectors[0].lsn);
        _delete_obsolete_lsn(sectors[0].last_lsn);
        return st;
    }

    if (corrupt0) {
        _file.SetNextSector(false);
        _lsn(sectors[1].lsn);
        _delete_obsolete_lsn(sectors[1].last_lsn);
        return st;
    }

    if (sectors[0].lsn > sectors[1].lsn) {
        _file.SetNextSector(true);
        _lsn(sectors[0].lsn);
        _delete_obsolete_lsn(sectors[0].last_lsn);
    } else {
        _file.SetNextSector(false);
        _lsn(sectors[1].lsn);
        _delete_obsolete_lsn(sectors[1].last_lsn);
    }

    return st;
}

Status CheckPointBlock::Close() {
    return _file.Close();
}

Status CheckPointBlock::Update(uint64_t lsn) {
    std::unique_lock lk(_mutex);
    Status st;
    if (_lsn() >= lsn) {
        st.Reset(Code::kAhead, "checkpoint lsn:%lu less than cur:%lu", lsn, _lsn());
        return st;
    }

    CheckPoint sector;
    sector.lsn = lsn;
    sector.last_lsn = _lsn();
    make_checksum(&sector, kCheckPointSize);

    st = _file.Write(&sector);
    if (!st.IsOk()) {
        st.ResetMsg("write file:%s failed, %m", _file_name.c_str());
        return st;
    }
    _delete_obsolete_lsn(_lsn());
    _lsn(lsn, true);
    return st;
}

Status CheckPointBlock::Reset() {
    std::unique_lock lk(_mutex);
    return ResetNoLock();
}

Status CheckPointBlock::ResetNoLock() {
    Status st;
    CheckPoint empty;
    make_checksum(&empty, kCheckPointSize);
    st = _file.Reset(&empty);
    if (!st.IsOk()) {
        st.ResetMsg("reset file:%s failed, %m", _file_name.c_str());
    }
    return st;
}

BlockSlotsBlock::~BlockSlotsBlock() {
    Close();
}

Status BlockSlotsBlock::Open() {
    std::unique_lock lk(_mutex);
    Status st;
    bool need_init = false;
    st = _file.Open(&need_init);
    if (!st.IsOk()) {
        return st;
    }
    if (need_init) {
        return ResetNoLock();
    }

    BlockSlots sectors[2];
    st = _file.Read(&sectors);
    if (!st.IsOk()) {
        st.ResetMsg("read file:%s failed, %m", _file_name.c_str());
        return st;
    }

    const bool valid0 = sectors[0].magic == kBlockSlotsMagic &&
            !check_is_corrupt(sectors[0], kBlockSlotsSize);
    const bool valid1 = sectors[1].magic == kBlockSlotsMagic &&
            !check_is_corrupt(sectors[1], kBlockSlotsSize);
    if (!valid0 && !valid1) {
        LOG(WARNING) << "block slots file both sectors invalid, reset it,"
            << " file:[" << _file_name
            << "]";
        return ResetNoLock();
    }

    if (valid0 && (!valid1 || sectors[0].seq > sectors[1].seq)) {
        _last = sectors[0];
        _file.SetNextSector(true);
    } else {
        _last = sectors[1];
        _file.SetNextSector(false);
    }
    _seq = _last.seq;
    return st;
}

Status BlockSlotsBlock::Close() {
    return _file.Close();
}

BlockFooterSlotsPtr BlockSlotsBlock::NewSlots() {
    _slots = std::make_shared<BlockFooterSlots>();
    return _slots;
}

bool BlockSlotsBlock::AddSlot(uint32_t index, uint64_t start_lsn, uint64_t offset,
        uint32_t log_num) {
    return _slots != nullptr && _slots->Add(index, start_lsn, offset, log_num);
}

Status BlockSlotsBlock::Update(uint64_t fno, uint64_t start_lsn) {
    std::unique_lock lk(_mutex);
    Status st;
    BlockSlots sector;
    sector.fno = fno;
    sector.start_lsn = start_lsn;
    sector.seq = ++_seq;
    if (_slots) {
        _slots->CopyTo(sector.slots);
    }
    make_checksum(&sector, kBlockSlotsSize);

    st = _file.Write(&sector);
    if (!st.IsOk()) {
        st.ResetMsg("write file:%s failed, %m", _file_name.c_str());
        return st;
    }
    _last = sector;
    return st;
}

Status BlockSlotsBlock::Load(uint64_t fno, uint64_t start_lsn,
        BlockFooterSlot* slots, bool* found) const {
    std::unique_lock lk(_mutex);
    Status st;
    *found = _last.fno == fno && _last.start_lsn == start_lsn;
    if (*found) {
        std::memcpy(slots, _last.slots, sizeof(_last.slots));
    }
    return st;
}

Status BlockSlotsBlock::Reset() {
    std::unique_lock lk(_mutex);
    return ResetNoLock();
}

Status BlockSlotsBlock::ResetNoLock() {
    Status st;
    BlockSlots empty;
    make_checksum(&empty, kBlockSlotsSize);
    st = _file.Reset(&empty);
    if (!st.IsOk()) {
        st.ResetMsg("reset file:%s failed, %m", _file_name.c_str());
        return st;
    }
    _seq = 0;
    _last = BlockSlots();
    _slots = nullptr;
    return st;
}

std::ostream& DumpBlockSlots(const BlockSlots& slots, std::ostream& os) {
    os << "magic:0x" << std::hex << slots.magic << std::dec
        << " proto_version:" << std::hex << slots.proto_version << std::dec
        << " fno:" << slots.fno
        << " start_lsn:" << slots.start_lsn
        << " seq:" << slots.seq
        << " checksum:" << slots.checksum;
    if (slots.magic != kBlockSlotsMagic) {
        os << " expect_magic:0x" << std::hex << kBlockSlotsMagic << std::dec;
    }
    const uint32_t calc_crc = get_crc(reinterpret_cast<const void*>(&slots),
            kBlockSlotsSize - sizeof(slots.checksum));
    if (slots.checksum != calc_crc) {
        os << " calc_checksum:" << calc_crc;
    }
    os << "\nslots:";
    for (uint32_t i = 0; i < kBlockFooterSlotNum; ++i) {
        if (slots.slots[i].start_lsn == 0 && slots.slots[i].offset == 0) {
            continue;
        }
        os << " [" << i << "]{lsn:" << slots.slots[i].start_lsn
            << ",off:" << slots.slots[i].offset
            << ",log_num:" << slots.slots[i].log_num << "}";
    }
    return os;
}

std::ostream& BlockSlotsBlock::Dump(int fd, std::ostream& os) {
    ssize_t file_size = 0;
    if (!get_file_size(fd, &file_size)) {
        return os << "get file size failed, errno:" << errno << std::endl;
    }

    const ssize_t slots_size = kBlockSlotsSize * 2;
    if (file_size < slots_size) {
        return os << "file size < kBlockSlotsSize * 2" << std::endl;
    }

    BlockSlots sectors[2];
    ssize_t r = db::pread(fd, &sectors, sizeof(BlockSlots) * 2, 0);
    if (r != slots_size) {
        return os << "read file data failed, errno:" << errno << " read_size:" << r << std::endl;
    }

    os << "----sector_0:\n";
    DumpBlockSlots(sectors[0], os);
    os << "\n----sector_1:\n";
    DumpBlockSlots(sectors[1], os);
    return os << "\n";
}

std::ostream& CheckPointBlock::Dump(int fd, std::ostream& os) {
    ssize_t file_size = 0;
    if (!get_file_size(fd, &file_size)) {
        return os << "get file size failed, errno:" << errno << std::endl;
    }

    const ssize_t checkpoint_size = kCheckPointSize * 2;
    if (file_size < checkpoint_size) {
        return os << "file size < kCheckPointSize * 2" << std::endl;
    }

    CheckPoint sectors[2];
    ssize_t r = db::pread(fd, &sectors, sizeof(CheckPoint) * 2, 0);
    if (r != checkpoint_size) {
        return os << "read file data failed, errno:" << errno << " read_size:" << r << std::endl;
    }

    os << "----sector_0:\n";
    DumpCheckPoint(sectors[0], os);
    os << "\n";
    os << "----sector_1:\n";
    DumpCheckPoint(sectors[1], os);
    return os << "\n";
}

std::ostream& DumpLogHeader(const LogHeader& log, std::ostream& os) {
    os << "magic:0x" << std::hex << log.magic << std::dec
        << " proto_version:" << std::hex << log.proto_version << std::dec
        << " lsn:" << log.start_lsn << " - " << log.end_lsn
        << " key_crc:" << log.key_crc
        << " buf_crc:" << log.buf_crc
        << " records_count:" << log.records_count
        << " from:" << base::ip2str(base::int2ip(log.fetch_from_ip)).c_str() << ":" << log.fetch_from_port
        << " fold_size:" << log.fold_size
        << " key_size:" << log.key_size
        << " value_size:" << log.value_size
        << " checksum:" << log.checksum;
    if (log.magic != kLogHeaderMagic) {
        os << " expect_magic:0x" << std::hex << kLogHeaderMagic << std::dec;
    }
    const uint32_t calc_crc = db::get_crc(reinterpret_cast<const void*>(&log),
            kLogHeaderSize - sizeof(log.checksum));
    if (log.checksum != calc_crc) {
        os << " calc_checksum:" << calc_crc;
    }
    return os;
}

}
}
