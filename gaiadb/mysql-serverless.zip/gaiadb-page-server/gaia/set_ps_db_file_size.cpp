/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_ps_db_file_size.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <sys/ioctl.h>
#include <termios.h>
#include <filesystem>
#include "psvr/store_cfg.h"
#include "gaia/set_ps_db_file_size.h"

namespace psvr {
namespace gaia {

struct StoreCtx {
    std::string section;
    std::string path;
};

int SetPageServerDbFileSize::Run() {
    if (_cfg_file.empty()) {
        print_error("miss --store-cfg-file");
        return 1;
    }
    if (_size == 0) {
        _size = k_default_db_file_size;
    }
    if (_size > 0 && _size % gaia_apply::FLAGS_univ_page_size != 0) {
        print_error("--size is invalid value, align %lu", gaia_apply::FLAGS_univ_page_size);
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Reset all segments db data file size, stop Page Server first!");
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    std::map<std::string, StoreCtx> store_ctxs;

    StoreCfg::ParseFn fn = [&store_ctxs](int32_t, const std::string& section,
            const std::string& path, bool active, int64_t, int64_t ) -> bool {
        if (active) {
            store_ctxs.emplace(section, StoreCtx{section, path});
        }
        return true;
    };

    if (!StoreCfg::Parse(_cfg_file, fn)) {
        print_error("parse store cfg file failed, set log detail");
        return 1;
    }

    std::atomic<uint32_t> fail_num = 0;
    std::atomic<uint32_t> succ_num = 0;
    StoreCfg::IterSegFn iter_seg_fn = [this, &fail_num, &succ_num](const std::string& segment_dir) {
        std::string db_file = base::string_printf("%s/%s", segment_dir.c_str(), kDataFileName);
        int32_t fd = open(db_file.c_str(), O_RDWR, S_IRUSR | S_IWUSR);
        if (fd < 0) {
            if (errno != ENOENT) {
                fail_num.fetch_add(1, std::memory_order_relaxed);
            }
            return;
        }
        std::shared_ptr<nullptr_t> fd_guard(nullptr, [&fd](nullptr_t){ close(fd); });
        struct ::stat sbuf;
        if (fstat(fd, &sbuf) == 0) {
            uint64_t file_size = sbuf.st_size;
            if (file_size < _size) {
                if (ftruncate(fd, _size) != 0) {
                    LOG(NOTICE) << "resize file failed,"
                        << " name:[" << db_file
                        << "] size:[" << file_size
                        << "] " << strerror(errno);
                    fail_num.fetch_add(1, std::memory_order_relaxed);
                }
            } else {
                LOG(NOTICE) << "resize file ok,"
                    << " name:[" << db_file
                    << "] size:[" << file_size
                    << "]";
                succ_num.fetch_add(1, std::memory_order_relaxed);
            }
        } else {
            LOG(NOTICE) << "stat file failed,"
                << " name:[" << db_file
                << "] " << strerror(errno);
            fail_num.fetch_add(1, std::memory_order_relaxed);
        }
    };

    StoreCfg::IterClsFn iter_cluster_fn = [](const std::string& cluster_dir, uint32_t segment_count) {
        LOG(NOTICE) << "ignore dir:" << cluster_dir << ",count:" << segment_count;
        return;
    };

    auto iter_store_fn = [&iter_seg_fn, &iter_cluster_fn](StoreCtx ctx) {
        StoreCfg::IteratorSegments(ctx.path, iter_seg_fn, iter_cluster_fn);
    };

    std::vector<std::shared_ptr<std::thread>> threads;
    for (auto& it : store_ctxs) {
        auto thread = std::make_shared<std::thread>(iter_store_fn, it.second);
        threads.emplace_back(thread);
    }

    for (auto& thread : threads) {
        thread->join();
    }

    if (fail_num.load() > 0) {
        printf("fail num:%u\n", fail_num.load());
        return 0;
    } else {
        printf("ok, num:%u\n", succ_num.load());
        return 0;
    }
}

}
}
