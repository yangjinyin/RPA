/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/append_file.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/append_block.h"

namespace psvr {

db::Status validate_append_redo_block(
        const db::LogHeader& log_header,
        const base::Slice& key,
        const base::Slice& value);

// Read-ahead buffer for the append-file recover: one pread covers the log header
// and (for small blocks) the block data, cutting the number of syscalls.
class AppendReadBuf {
public:
    AppendReadBuf() = default;
    // Allocate the buffer with the given capacity.
    explicit AppendReadBuf(uint64_t size);

    // Allocate the buffer.
    void Init(uint64_t size);

    // Reset the read cursor.
    void Reset();

    void Skip(uint64_t size);

    // Serve `size` bytes at `off` of `rblock` into `dst`, returning the bytes served in
    // *buf: served from the read-ahead buffer when it covers the range, otherwise read
    // directly; a small remainder triggers a refill and is served from the buffer.
    // Same semantics as RandomAccessBlock::Read: a short read returns kOk with a shorter
    // slice, so the caller detects it on *buf.
    db::Status GetBufSize(const std::shared_ptr<db::RandomAccessBlock>& rblock,
            uint64_t off, size_t size, base::Slice* buf, char* dst, bool read_ahead = true);
    db::Status GetBufSizex(const std::shared_ptr<db::RandomAccessBlock>& rblock,
            uint64_t off, size_t size, base::Slice* buf, char* dst, bool read_ahead = true);

private:
    db::Status GetBufSizeImpl(const std::shared_ptr<db::RandomAccessBlock>& rblock,
            uint64_t off, size_t size, base::Slice* buf, char* dst, bool read_ahead, bool use_preadx);

private:
    std::unique_ptr<char[]> _read_buf;
    uint64_t _read_buf_size = 0;   // capacity (= gflag)
    uint64_t _read_buf_off = 0;    // read cursor within the buffer
    uint64_t _read_buf_len = 0;    // valid bytes in the buffer
    uint64_t _read_buf_fno = 0;    // which block file the buffer came from
    uint64_t _read_buf_foff = 0;   // file offset of the byte at _read_buf_off
};

class AppendDBEngine {
    using Status = db::Status;
    using Code = db::Code;
    using Slice = base::Slice;
    using BlockPtr = std::shared_ptr<db::Block>;
    using RandomAccessBlockPtr = std::shared_ptr<db::RandomAccessBlock>;
    using CheckPointBlockPtr = std::shared_ptr<db::CheckPointBlock>;
public:
    AppendDBEngine();
    FUNC_MOCK ~AppendDBEngine();

    FUNC_MOCK Status Open(const std::string& data_path,
            gaia_apply::lsn_t dblwr_checkpoint_lsn,
            gaia_apply::lsn_t* checkpoint_lsn, gaia_apply::lsn_t* max_apply_lsn);
    Status Close(bool reset = true);

    void Init(gaia_apply::lsn_t start_lsn);
    FUNC_MOCK Status SetCheckPointLsn(gaia_apply::lsn_t checkpoint_lsn,
            uint64_t seg_lowest_gc_lsn, bool cleanup_frozen);
    FUNC_MOCK gaia_apply::lsn_t GetCheckPointLsn() const;
    Status Clear();

    FUNC_MOCK Status Append(const db::LogHeader& log_header, const Slice& key, const Slice& value,
            uint64_t* fno, uint64_t* off, bool sync);

    FUNC_MOCK Status BatchAppend(const std::vector<db::LogHeader>& log_headers,
            const std::vector<Slice>& keys, const std::vector<Slice>& values,
            std::vector<uint64_t>* fnos, std::vector<uint64_t>* offs);

    FUNC_MOCK Status Read(uint64_t fno, uint64_t off, Slice* data, char* buf, uint32_t buf_size);

    Status GetSize(uint64_t* file_size);

    FUNC_MOCK Status RecoverStart(uint64_t* checkpoint_lsn, gaia_apply::lsn_t dblwr_checkpoint_lsn);
    FUNC_MOCK Status RecoverLog(db::LogHeader* log_header, Slice* key, Slice* value, char** data,
            uint64_t* fno, uint64_t* off);
    Status PreRecoverNextLog(uint64_t* next_lsn);
    Status RecoverFinish();

    Status DeleteObsoleteFiles(uint64_t seg_lowest_gc_lsn, bool cleanup_frozen);

public:
    // If data is assigned, the caller must free it regardless of the return status.
    // When read_buf is not null the reads go through the read-ahead buffer.
    FUNC_MOCK db::Status FetchRedoLog(uint64_t seek_lsn, db::LogHeader* log_header,
            Slice* key, Slice* value, char** data,
            uint64_t& fno, uint64_t& offset, AppendReadBuf* read_buf = nullptr);

private:
    RandomAccessBlockPtr FindRandomBLockAndCheck(uint64_t fno, uint64_t seek_lsn);
    RandomAccessBlockPtr FindRandomBLock(uint64_t seek_lsn);

private:
    Status Open2(const std::string& data_path,
            gaia_apply::lsn_t dblwr_checkpoint_lsn,
            gaia_apply::lsn_t* checkpoint_lsn, gaia_apply::lsn_t* max_apply_lsn);
    Status TryFixBlock(RandomAccessBlockPtr rblock, bool* fix_footer = nullptr);
    Status FindLastCompleteLog(const RandomAccessBlockPtr& rblock, uint64_t file_size,
            uint64_t file_start_lsn, bool* found, bool* safe, uint64_t* record_off,
            db::LogHeader* log_header);
    Status LocateSlotOffset(const RandomAccessBlockPtr& rblock, uint64_t file_size,
            const db::BlockFooterSlot* slots, bool* used, uint64_t* off,
            uint64_t* start_lsn, uint32_t* log_num);
    Status NewWriteBlock(uint64_t start_lsn);
    Status NewRandomAccessBlock(uint64_t fno, uint64_t start_lsn,
            RandomAccessBlockPtr* rblock = nullptr,
            const db::BlockFooterSlotsPtr& write_slots = nullptr);
    Status DoAppend(BlockPtr block,
            const Slice& header, const Slice& key, const Slice& value, size_t write_size,
            uint64_t start_lsn, uint64_t end_lsn,
            uint64_t* fno, uint64_t* off, bool sync);
    Status RemoveEmptyBlock(uint64_t fno);

    void FetchNextDataLog(const RandomAccessBlockPtr& rblock, uint64_t off,
            bool is_current_rblock, db::LogHeader* log_header, uint64_t* data_off,
            AppendReadBuf* read_buf);
    Status RecoverLogFromRBlock(RandomAccessBlockPtr rblock, uint64_t off,
            db::LogHeader* log_header, Slice* key, Slice* value, char** data,
            uint64_t* next_off);

    struct RecoverInfo {
        std::list<RandomAccessBlockPtr>::iterator iter;
        uint64_t lsn;
        uint64_t off;
        uint64_t seek_off;
        uint64_t random_block_size;
        uint64_t next_lsn;
        uint64_t next_off;
        int64_t start_time;

        uint64_t start_lsn;
        uint32_t read_num;

        // read-ahead buffer; shared so a reader can keep it alive across the lock
        std::shared_ptr<AppendReadBuf> read_buf;
    };

private:
    int32_t _disable;
    std::string _data_path;
    BlockPtr _write_block;
    RandomAccessBlockPtr _rblock;
    uint64_t _block_no;
    uint64_t _next_write_lsn;
    std::atomic<uint64_t> _db_size;
    CheckPointBlockPtr _checkpoint_block;
    std::shared_ptr<db::BlockSlotsBlock> _slots_block;
    mutable rwlock_t _shared_mutex;
    std::list<RandomAccessBlockPtr> _random_access_blocks;  // sort by fno desc, 9 8 7 6 5 4 3 2 1
    std::map<uint64_t, RandomAccessBlockPtr> _random_access_blocks_map;
    std::atomic<int32_t> _random_access_blocks_size;
    rwlock_t _random_access_shared_mutex;
    std::shared_ptr<RecoverInfo> _recover_info;
};

using AppendDBEnginePtr = std::shared_ptr<AppendDBEngine>;

}
