/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/parse_context.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/context_types.h"
#include "psvr/log_block.h"
#include "psvr/client.h"
#include "psvr/cluster.h"
#include "psvr/parse.h"

namespace psvr {

struct Parser::Context : thread::TaskContext {
    Action action;
    SegmentWeakPtr segment {};
    LogBlockPtr log_block {nullptr};

    ClusterPtr cluster {nullptr};
    PsmInfoPtr psm_info {nullptr};
    EventOp event {EventOp::kOther};
    bool has_quota {false};
    uint32_t client_id_rand {0};
    std::shared_ptr<SpaceMetaEventType> space_meta_event {nullptr};
    std::shared_ptr<SpaceExtentEventType> space_extent_event {nullptr};
    std::shared_ptr<PeerEventType> peer_event {nullptr};

    std::unique_ptr<RpcGetSpaceMetaCtx> rpc_get_space_meta_ctx {nullptr};
    std::unique_ptr<RpcGetSpaceExtentMapCtx> rpc_get_space_extent_ctx {nullptr};
    std::unique_ptr<RpcGetSegmentCtx> rpc_get_segment_ctx {nullptr};
    std::unique_ptr<RpcGetAllSpaceCtx> rpc_get_all_space_id_ctx {nullptr};

    uint32_t retry_times {0};
    uint32_t retry_quota {0};
    Timer stat_timer;

    Context(Action _action, SegmentPtr _segment, LogBlockPtr _log_block)
        : thread::TaskContext(CtxType::kParse),
        action(_action), segment(_segment), log_block(_log_block) {}
    Context(Action _action, ClusterPtr _cluster, EventOp _event)
        : thread::TaskContext(CtxType::kParse),
        action(_action), cluster(_cluster), event(_event) {}
    virtual ~Context() {}

    void SetForNextLogBlock(Action _action, LogBlockPtr _log_block) {
        action = _action;
        log_block = _log_block;
        retry_times = 0;
    }
};

}
