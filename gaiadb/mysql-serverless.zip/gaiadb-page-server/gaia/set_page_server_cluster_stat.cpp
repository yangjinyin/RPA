/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_page_server_cluster_stat.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/set_page_server_cluster_stat.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int SetPageServerClusterStat::Run() {
    RpcStatus status;
    if (_address.empty() || _port < 1) {
        print_error("miss --cluster-addr or (--address and --port)");
        return 1;
    }

    if (_cluster_id.empty()) {
        print_error("miss --cluster-id");
        return 1;
    }

    if (!_enable.has_val) {
        print_error("miss --enable");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("%s cluster unit statistic?", _enable.val ? "Enable" : "Disable");
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    if (_enable.val) {
        pspb::EnableClusterStatRequest request;
        pspb::EnableClusterStatResponse response;
        request.set_log_id(_log_id);
        request.set_cluster_id(_cluster_id);
        if (!_prefix.empty()) {
            request.set_prefix(_prefix);
        } else {
            request.set_prefix(_cluster_id);
        }

        _client.Call(_log_id, node, &pspb::ManagerService_Stub::EnableClusterStat, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }
        return Output(response);
    } else {
        pspb::DisableClusterStatRequest request;
        pspb::DisableClusterStatResponse response;
        request.set_log_id(_log_id);
        request.set_cluster_id(_cluster_id);

        _client.Call(_log_id, node, &pspb::ManagerService_Stub::DisableClusterStat, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }
        return Output(response);
    }
}

int SetPageServerClusterStat::Format(const pspb::EnableClusterStatResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

int SetPageServerClusterStat::Format(const pspb::DisableClusterStatResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
