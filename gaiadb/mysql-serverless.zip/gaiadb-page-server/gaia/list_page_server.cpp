/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_page_server.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ListPageServer::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (_addr.empty()) {
        if (_segment_id) {
            gaiapb::GetSegmentRequest request;
            gaiapb::GetSegmentResponse response;

            request.set_segment_id(_segment_id);

            for (auto& node : nodes) {
                _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_segment, &request, &response,
                        nullptr, &status, _timeout_ms);
                if (status.IsOk()
                        && !rsp_is_retry(response.status())) {
                    return Output(response);
                } else {
                    LOG(WARNING) << node << " list segment server failed, " << status << " " << response.status();
                }
            }
            response.mutable_status()->set_code(gaiadb::GIE_FAIL);
            response.mutable_status()->set_msg("list failed, all nodes failed");
            return Output(response);

        } else {
            gaiapb::ListPageServerRequest request;
            gaiapb::ListPageServerResponse response;

            request.set_log_id(_log_id);

            for (auto& node : nodes) {
                _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_page_server, &request, &response,
                        nullptr, &status, _timeout_ms);
                if (status.IsOk()
                        && !rsp_is_retry(response.status())) {
                    return Output(response);
                } else {
                    LOG(WARNING) << node << " list page server failed, " << status << " " << response.status();
                }
            }
            response.mutable_status()->set_code(gaiadb::GIE_FAIL);
            response.mutable_status()->set_msg("list failed, all nodes failed");
            return Output(response);
        }
    } else {
        gaiapb::GetPageServerRequest request;
        gaiapb::GetPageServerResponse response;

        request.set_addr(_addr);
        request.set_is_need_map(false);
        if (_segment_id > 0) {
            request.set_segment_id(_segment_id);
        }

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_page_server, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                return Output(response);
            } else {
                LOG(WARNING) << node << " list page server failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("list failed, all nodes failed");
        return Output(response);
    }
}

int ListPageServer::Format(const gaiapb::GetPageServerResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    const auto& page_server = rsp.page_server();
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"segment_id:", page_server.segment_id()});
    table.AddRowsValue({"replica_id:", page_server.replica_id()});
    table.AddRowsValue({"fetch_lsn:", page_server.fetch_lsn()});
    table.AddRowsValue({"apply_lsn:", page_server.apply_lsn()});
    table.AddRowsValue({"checkpoint_lsn:", page_server.checkpoint_lsn()});
    table.AddRowsValue({"max_extent_num:", page_server.max_extent_num()});
    table.AddRowsValue({"recovery_status:", gaiadb::RecoveryStatus_Name(page_server.recovery_status())});
    table.AddRowsValue({"slow:", page_server.is_slow()});
    table.AddRowsValue({"state:", gaiadb::NodeState_Name(page_server.state())});
    table.AddRowsValue({"version:", page_server.version()});
    table.AddRowsValue({"zone:", GetZoneStr(page_server)});
    table.Display();
    return 0;
}

int ListPageServer::Format(const gaiapb::GetSegmentResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.page_servers_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({
                "segment_id", "replica_id", "addr",
                "fetch_lsn", "apply_lsn", "checkpoint_lsn",
                "state", "max_extent_num", "recovery_status", "slow", "version", "zone"}, true);
        for (auto& ps : rsp.page_servers()) {
            table.AddRowsValue({
                    ps.segment_id(),
                    ps.replica_id(),
                    ps.addr(),
                    ps.fetch_lsn(),
                    ps.apply_lsn(),
                    ps.checkpoint_lsn(),
                    gaiadb::NodeState_Name(ps.state()),
                    ps.max_extent_num(),
                    gaiadb::RecoveryStatus_Name(ps.recovery_status()),
                    ps.is_slow(),
                    ps.version(),
                    GetZoneStr(ps)
                });

        }

        table.Display();
    }
    return 0;
}

struct AddressLsn {
    std::string addr;
    uint64_t lsn;
};

int ListPageServer::Format(const gaiapb::ListPageServerResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.page_servers_size()) {
        uint64_t min_fetch_lsn = -1;
        uint64_t max_fetch_lsn = 0;
        uint64_t min_parse_lsn = -1;
        uint64_t max_parse_lsn = 0;
        AddressLsn min_checkpoint_replica {"", std::numeric_limits<uint64_t>::max()};
        AddressLsn max_checkpoint_replica {"", 0};
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({
                "segment_id", "replica_id", "addr",
                "fetch_lsn", "apply_lsn", "checkpoint_lsn",
                "state", "max_extent_num", "recovery_status", "slow", "version", "zone"}, true);
        for (auto& ps : rsp.page_servers()) {
            table.AddRowsValue({
                    ps.segment_id(),
                    ps.replica_id(),
                    ps.addr(),
                    ps.fetch_lsn(),
                    ps.apply_lsn(),
                    ps.checkpoint_lsn(),
                    gaiadb::NodeState_Name(ps.state()),
                    ps.max_extent_num(),
                    gaiadb::RecoveryStatus_Name(ps.recovery_status()),
                    ps.is_slow(),
                    ps.version(),
                    GetZoneStr(ps)
                });

            if (ps.checkpoint_lsn() > 0) {
                min_fetch_lsn = std::min(min_fetch_lsn, ps.fetch_lsn());
                max_fetch_lsn = std::max(max_fetch_lsn, ps.fetch_lsn());
                min_parse_lsn = std::min(min_parse_lsn, ps.apply_lsn());
                max_parse_lsn = std::max(max_parse_lsn, ps.apply_lsn());

                if (min_checkpoint_replica.lsn > ps.checkpoint_lsn()) {
                    min_checkpoint_replica.lsn = ps.checkpoint_lsn();
                    min_checkpoint_replica.addr = ps.addr();
                }

                if (max_checkpoint_replica.lsn < ps.checkpoint_lsn()) {
                    max_checkpoint_replica.lsn = ps.checkpoint_lsn();
                    max_checkpoint_replica.addr = ps.addr();
                }
            }
        }
        if (_show_total && rsp.page_servers_size()) {
#define DIFF(a, b)  (a >= b ? (a - b) : 0)
            table.AddRowsValue({"cn_lowest_lsn:", rsp.cn_lowest_lsn()});
            table.AddRowsValue({"cn_lowest_gc_lsn:", rsp.cn_lowest_gc_lsn()});
            table.AddRowsValue({"ps_lowest_lsn:", rsp.ps_lowest_lsn()});
            table.AddRowsValue({"ps_lowest_gc_lsn:", rsp.ps_lowest_gc_lsn()});
            auto cn_lowest_lsn = std::max(rsp.cn_lowest_lsn(), rsp.cn_lowest_gc_lsn());
            if (rsp.has_ps_lowest_lsn()) {
                auto ps_lowest_lsn = std::max(rsp.ps_lowest_lsn(), rsp.ps_lowest_gc_lsn());
                table.AddRowsValue({"ps_diff_cn_lowest_lsn:", RowSize(DIFF(cn_lowest_lsn, ps_lowest_lsn), _human_readable)});
            }

            table.AddRowsValue({"min_fetch_lsn:", min_fetch_lsn, "diff_cn_lowest:", RowSize(DIFF(cn_lowest_lsn, min_fetch_lsn), _human_readable)});
            table.AddRowsValue({"max_fetch_lsn:", max_fetch_lsn, "diff_cn_lowest:", RowSize(DIFF(cn_lowest_lsn, max_fetch_lsn), _human_readable)});
            table.AddRowsValue({"min_parse_lsn:", min_parse_lsn, "diff_cn_lowest:", RowSize(DIFF(cn_lowest_lsn, min_parse_lsn), _human_readable)});
            table.AddRowsValue({"max_parse_lsn:", max_parse_lsn, "diff_cn_lowest:", RowSize(DIFF(cn_lowest_lsn, max_parse_lsn), _human_readable)});
            table.AddRowsValue({"min_checkpoint_lsn:", min_checkpoint_replica.lsn, "diff_cn_lowest:", RowSize(DIFF(cn_lowest_lsn, min_checkpoint_replica.lsn), _human_readable), min_checkpoint_replica.addr});
            table.AddRowsValue({"max_checkpoint_lsn:", max_checkpoint_replica.lsn, "diff_cn_lowest:", RowSize(DIFF(cn_lowest_lsn, max_checkpoint_replica.lsn), _human_readable), max_checkpoint_replica.addr});
        }

        table.Display();
    }
    return 0;
}

}
}
