/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_manager_addr_node.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/get_manager_addr_node.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int GetManagerAddrNode::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }
    page_server::GaiaBaseNode rsp;
    for (auto& ep : nodes) {
        rsp.add_addr(base::endpoint2str(ep).c_str());
    }
    return Output(rsp);
}

int GetManagerAddrNode::Format(const page_server::GaiaBaseNode& rsp) {
    printf("total size:%d\n", rsp.addr_size());
    for (auto& addr : rsp.addr()) {
        printf("%s\n", addr.c_str());
    }
    return 0;
}

}
}
