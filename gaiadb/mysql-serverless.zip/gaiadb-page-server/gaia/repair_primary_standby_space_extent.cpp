/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/repair_primary_standby_space_extent.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/repair_primary_standby_space_extent.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

bool RepairPrimaryStandbySpaceExtent::GetAllSpace(std::vector<base::EndPoint>& nodes,
        std::set<uint32_t>& ids) {
    RpcStatus status;
    gaiapb::EmptyMessage request;
    gaiapb::GetAllSpaceIdsResponse response;
    size_t size = nodes.size();
    for (size_t i = 0; i < size; ++i) {
        auto& node = nodes[i];
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_all_space_ids, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            for (auto& id : response.space_ids()) {
                ids.insert(id);
            }
            if (i > 0) {
                std::swap(nodes[0], nodes[i]);
            }
            return true;
        } else {
            LOG(WARNING) << node << " list space failed, " << status << " " << response.status();
        }
    }
    return false;
}

bool RepairPrimaryStandbySpaceExtent::GetSpaceExtentNum(std::vector<base::EndPoint>& nodes,
        uint32_t space_id, uint32_t& alloc_extent_num) {
    RpcStatus status;
    gaiapb::GetSpaceExtentMapRequest request;
    gaiapb::GetSpaceExtentMapResponse response;
    request.set_space_id(space_id);
    request.set_begin_extent_id(0);
    request.set_num(1);
    request.set_need_physical_extent_id(false);

    size_t size = nodes.size();
    for (size_t i = 0; i < size; ++i) {
        auto& node = nodes[i];
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_space_extent_map, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            if (response.has_total_extent_num()) {
                alloc_extent_num = response.total_extent_num();
            } else {
                alloc_extent_num = 1;
            }
            if (i > 0) {
                std::swap(nodes[0], nodes[i]);
            }
            return true;
        } else {
            LOG(WARNING) << node << " get space extent failed, " << status << " " << response.status();
        }
    }
    return false;
}

bool RepairPrimaryStandbySpaceExtent::CreateSpace(std::vector<base::EndPoint>& nodes,
        uint32_t space_id, uint32_t alloc_extent_num) {
    RpcStatus status;
    gaiapb::CreateSpaceRequest request;
    gaiapb::CreateSpaceResponse response;

    request.set_space_id(space_id);
    request.set_alloc_number(alloc_extent_num);
    auto meta = request.mutable_space_meta();
    meta->set_is_compressed(false);
    meta->set_is_encrypted(false);
    meta->set_logical_page_size(gaia_apply::FLAGS_univ_page_size);
    meta->set_physical_page_size(gaia_apply::FLAGS_univ_page_size);

    size_t size = nodes.size();
    for (size_t i = 0; i < size; ++i) {
        auto& node = nodes[i];
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::create_space, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            if (i > 0) {
                std::swap(nodes[0], nodes[i]);
            }
            return true;
        } else {
            LOG(WARNING) << node << " create space failed, " << status << " " << response.status();
        }
    }
    return false;
}

bool RepairPrimaryStandbySpaceExtent::GetSpace(std::vector<base::EndPoint>& nodes,
        uint32_t space_id, bool& exists) {
    RpcStatus status;
    gaiapb::GetSpaceMetaRequest request;
    gaiapb::GetSpaceMetaResponse response;
    request.set_space_id(space_id);
    request.set_need_encryption_info(false);

    size_t size = nodes.size();
    for (size_t i = 0; i < size; ++i) {
        auto& node = nodes[i];
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_space_meta, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            exists = response.status().code() != gaiadb::GIE_NOT_EXIST;
            if (i > 0) {
                std::swap(nodes[0], nodes[i]);
            }
            return true;
        } else {
            LOG(WARNING) << node << " get space failed, " << status << " " << response.status();
        }
    }
    return false;
}

bool RepairPrimaryStandbySpaceExtent::DropSpace(std::vector<base::EndPoint>& nodes,
        uint32_t space_id) {
    RpcStatus status;
    gaiapb::DeleteSpaceRequest request;
    gaiapb::AckResponse response;

    request.set_space_id(space_id);

    size_t size = nodes.size();
    for (size_t i = 0; i < size; ++i) {
        auto& node = nodes[i];
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::delete_space, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            if (i > 0) {
                std::swap(nodes[0], nodes[i]);
            }
            return true;
        } else {
            LOG(WARNING) << node << " drop space failed, " << status << " " << response.status();
        }
    }
    return false;
}

int RepairPrimaryStandbySpaceExtent::Run() {
    RpcStatus status;

    if (_primary_addr.empty()) {
        print_error("miss --primary-manager-address");
        return 1;
    }

    if (_standby_addr.empty()) {
        print_error("miss --standby-manager-address");
        return 1;
    }

    PsmInfo pri_psm_info(_primary_addr, _both);
    std::vector<base::EndPoint> pri_nodes;
    if (!pri_psm_info.GetOrRefreshNodes(&pri_nodes)) {
        print_error("--primary-manager-address parse failed, cant get server list from it");
        return 1;
    }

    PsmInfo std_psm_info(_standby_addr, _both);
    std::vector<base::EndPoint> std_nodes;
    if (!std_psm_info.GetOrRefreshNodes(&std_nodes)) {
        print_error("--standby-manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_force) {
        if (!execute_confirm("repair two cluster space data?")) {
            std::cout << "quit!" << std::endl;
            return -1;
        }
    }

    do {

        bool wait_epoch_changed = false;
        while (!_stopped) {
            uint64_t min_epoch = -1;
            gaiapb::ListReplicatorNodeRequest request;
            gaiapb::ListReplicatorNodeResponse response;
            size_t size = std_nodes.size();
            for (size_t i = 0; i < size; ++i) {
                auto& node = std_nodes[i];
                _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_replicator_node, &request, &response,
                        nullptr, &status, _timeout_ms);
                if (status.IsOk()
                        && !rsp_is_retry(response.status())) {

                    if (response.nodes_size() == 0) {
                        min_epoch = 0;
                        break;
                    }

                    for (auto& n_pb : response.nodes()) {
                        min_epoch = std::min(min_epoch, n_pb.epoch());
                    }

                    if (i > 0) {
                        std::swap(std_nodes[0], std_nodes[i]);
                    }
                    break;
                } else {
                    LOG(WARNING) << node << " list replicator node failed, " << status << " " << response.status();
                }
            }

            if (min_epoch != 0) {
                if (_standby_epoch == 0 || _standby_epoch != min_epoch) {
                    _standby_epoch = min_epoch;
                    break;
                } else {
                    if (!wait_epoch_changed) {
                        std::cout << "wait, standby rpl not changed, epoch:" << min_epoch << std::endl;
                        wait_epoch_changed = true;
                    }
                }
            } else {
                std::cout << "get rpl epoch failed, maybe is not standby or manager nodes changed?" << std::endl;
            }
            sleep_for(second2microseconds(1));
        }    // end of while

        std::set<uint32_t> pri_ids;
        std::set<uint32_t> std_ids;
        do {
            pri_ids.clear();
            std_ids.clear();

            if (_delete) {
                if (!GetAllSpace(std_nodes, std_ids)) {
                    std::cout << "get standby space ids failed, maybe manager nodes changed?" << std::endl;
                    std::vector<base::EndPoint> nodes;
                    if (std_psm_info.GetOrRefreshNodes(&nodes)) {
                        std_nodes = nodes;
                    }
                    sleep_for(second2microseconds(1));
                    continue;
                }
                std::cout << "get standby space count:" << std_ids.size() << std::endl;
            }

            if (!GetAllSpace(pri_nodes, pri_ids)) {
                std::cout << "get primary space ids failed, maybe manager nodes changed?" << std::endl;
                std::vector<base::EndPoint> nodes;
                if (pri_psm_info.GetOrRefreshNodes(&nodes)) {
                    pri_nodes = nodes;
                }
                sleep_for(second2microseconds(1));
                continue;
            }
            std::cout << "get primary space count:" << pri_ids.size() << std::endl;

            if (!_delete) {
                if (!GetAllSpace(std_nodes, std_ids)) {
                    std::cout << "get standby space ids failed, maybe manager nodes changed?" << std::endl;
                    std::vector<base::EndPoint> nodes;
                    if (std_psm_info.GetOrRefreshNodes(&nodes)) {
                        std_nodes = nodes;
                    }
                    sleep_for(second2microseconds(1));
                    continue;
                }
                std::cout << "get standby space count:" << std_ids.size() << std::endl;
            }

            size_t diff_n = 0;

            if (_delete) {
                std::cout << "Run with delete!" << std::endl;
                for (auto& src_id : pri_ids) {
                    if (std_ids.erase(src_id) == 0) {
                        ++diff_n;
                    }
                }

                if (diff_n > 0) {
                    std::cout << "standby miss primary space data, must repair it before" << std::endl;
                    for (auto& id : pri_ids) {
                        std::cout << id << std::endl;
                    }
                    std::cout << "total:" << pri_ids.size() << std::endl;
                    return 1;
                }

                if (diff_n == 0 && std_ids.size() == 0) {
                    std::cout << "primary and standby space data consistency, success" << std::endl;
                    return 0;
                }

                std::cout << "standby need drop space count:" << std_ids.size() << std::endl;
                size_t drop_n = 0;
                for (auto& dst_id : std_ids) {
                    bool exists = true;
                    if (!GetSpace(pri_nodes, dst_id, exists)) {
                        std::cout << "get primary space failed, maybe manager nodes changed?"
                            << " space=" << dst_id
                            << std::endl;
                        continue;
                    }
                    if (exists) {
                        std::cout << "primary space exists, error?"
                            << " space=" << dst_id
                            << std::endl;
                        return 1;
                    }
                    if (!DropSpace(std_nodes, dst_id)) {
                        std::cout << "drop standby space failed, maybe manager nodes changed?"
                            << " space=" << dst_id
                            << std::endl;
                        continue;
                    }
                    LOG(NOTICE) << "drop space:" << dst_id;
                    ++drop_n;
                    if (drop_n % 10) {
                        std::cout << "show standby drop space count:" << drop_n << std::endl;
                    }
                }

                std::cout << "standby drop space success total count:" << drop_n << std::endl;
                continue;
            }

            for (auto& src_id : pri_ids) {
                if (std_ids.erase(src_id) > 0) {
                    continue;
                }
                ++diff_n;
                uint32_t alloc_extent_num = 1;
                if (!GetSpaceExtentNum(pri_nodes, src_id, alloc_extent_num)) {
                    std::cout << "get primary space extent num failed, maybe manager nodes changed?"
                        << " space=" << src_id
                        << std::endl;
                    continue;
                }
                if (!CreateSpace(std_nodes, src_id, alloc_extent_num)) {
                    std::cout << "create standby space failed, maybe manager nodes changed?"
                        << " space=" << src_id
                        << std::endl;
                    continue;
                }
                LOG(NOTICE) << "create space:" << src_id << " num:" << alloc_extent_num;
                if (diff_n % 10 == 0) {
                    std::cout << "show standby create space count:" << diff_n << std::endl;
                }
            }

            if (diff_n == 0) {
                std::cout << "primary space all in standby, success" << std::endl;
                break;
            } else {
                std::cout << "standby create space success total count:" << diff_n << std::endl;
            }

        } while (!_stopped);

    } while (_daemonize && !_stopped);

    return 0;
}

}
}
