--psvr_rbio_server_port=%(port)s

--manager_address=%(manager_address)s
--cluster_id=%(cluster_id)s

--psvr_comlog_quota_size=10240
--psvr_comlog_cut_size_mb=1024
--min_log_level=1
--psvr_spd_log_max_items_num=4096
--psvr_spd_log_thread_num=1

--psvr_annotate_max_num=0
--psvr_enable_logblock_annotate=false
--psvr_enable_fetch_annotate=false
--psvr_enable_gc_annotate=false
--psvr_enable_recover_annotate=false
--psvr_enable_rbio_annotate=false
--psvr_logblock_long_query_time_us=0

--heartbeat_interval_second=0
--heartbeat_interval_ms=500
--segment_in_trash_second=30
--gc_trash_segment_interval_second=2
--monitor_store_statistic_interval_second=10

--psvr_is_multi_type=%(is_multi_type)s
--psvr_store_config_file=%(store_cfg_file)s
--psvr_topology_zone=%(psvr_topology_zone)s

#--psvr_zone_region=%(psvr_zone_region)s
#--psvr_zone_available_zone=%(psvr_zone_available_zone)s

--psvr_auto_enable_segment_statistic=false
--psvr_auto_enable_cluster_statistic=false
--psvr_query_metadata_quota_per_cluster=1024
--psvr_space_page_slice_count=1
--psvr_segment_page_lock_slice_count=4

--multi_psvr_control_thread_num=2
--multi_psvr_fetcher_thread_num_per_store=2
--multi_psvr_parser_thread_num_per_store=1
--multi_psvr_gc_thread_num_per_store=2
--multi_psvr_gc_prior_thread_num_per_store=0
--multi_psvr_rbio_thread_num_per_store=2
--multi_psvr_recover_thread_num=2
--multi_psvr_compress_thread_num=1
--multi_psvr_get_metadata_thread_num=2
--multi_psvr_gc_condition_thread_num=1
--multi_psvr_rbio_condition_thread_num=1
--psvr_fetch_max_buf_size=8589934592
--psvr_cluster_fetch_max_buf_size=1073741824
--psvr_segment_fetch_max_buf_size=67108864

--psvr_gc_enable_punch_hole=false
# compress type: snappy(8), zstd(9), lz4(10)
--psvr_gc_compress_type=9
--psvr_gc_compress_level=5
--psvr_gc_compress_lz4_level=6
--psvr_gc_compress_zstd_level=3

--psvr_enable_compression=false

--psvr_recover_src_max_speed=0
--psvr_recover_dst_max_speed=0
--psvr_recover_src_store_max_speed=104857600
--psvr_recover_dst_store_max_speed=104857600
--psvr_recover_max_inflight_task_size=64
--psvr_recover_task_parallel_num_per_store=4

--psvr_bthread_num=9
--psvr_rbio_thread_max_queue_size=0
--multi_psvr_rbio_max_tasks_size=10240

--bvar_dump=true
--bvar_dump_file=%(bvar_dump_file)s
--bvar_dump_interval=40
