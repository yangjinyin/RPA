/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/drop_segment_replica.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class DropSegmentReplica : public Command {
public:
    DropSegmentReplica() {
        SetName("drop-segment-replica");
        SetDesc("drop an existing replica in a specified segment from manager");
        SetDescCn("从管理服务中删除指定分片中的副本");

        AddPsmClusterOption();
        AddRequiredArgOption("segment-id", NULL, 's', "drop in the segment", kuint32_t);
        AddRequiredArgOption("replica-id", &_long_opt_val, kOptMax + 2, "will drop the replica id", kuint32_t);

        AddRequiredArgOption("replica-addr", &_long_opt_val, kOptMax + 3,
                "verify replica endpoint information", kip_port, kGroup2Scope);
        AddRequiredArgOption("replica-version", &_long_opt_val, kOptMax + 4,
                "verify replica version information", kuint64_t, kGroup2Scope);

        AddExample("--manager-address \"bns://xxx\" --segment-id xx --replica-id 1");
        AddExample("--manager-address \"bns://xxx\" --segment-id xx --replica-id 1 --replica-addr ip:port");
        AddExample("--manager-address \"bns://xxx\" --segment-id xx --replica-id 1"
                " --replica-addr ip:port --replica-version <version>");
    }
    virtual ~DropSegmentReplica() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 's':
            _segment_id = std::strtoul(opt, NULL, 10);
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 2:
                _replica_id.Set(std::strtoul(opt, NULL, 10));
                break;
            case kOptMax + 3:
                _replica_addr = opt;
                break;
            case kOptMax + 4:
                _replica_version.Set(std::strtoul(opt, NULL, 10));
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::AckResponse& rsp);

private:
    std::string _manager_address {};
    uint32_t _segment_id {0};
    VarOptional<uint32_t> _replica_id;
    std::string _replica_addr {};
    VarOptional<uint64_t> _replica_version;
};

}
}
