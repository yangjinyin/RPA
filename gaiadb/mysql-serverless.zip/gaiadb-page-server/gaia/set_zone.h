/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_zone.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class SetZone : public Command {
public:
    SetZone() {
        SetName("set-zone");
        SetDesc("set gaia server memory zone");
        SetDescCn("设置 Gaia 服务的内存可用区配置");

        AddRequiredArgOption("address", NULL, 'a', "service listening address of the server", kip_port);
        AddRequiredArgOption("port", NULL, 'p', "service listening port of the server", kint32_t);
        AddZoneOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "manager cluster id", kstring);
        AddRequiredArgOption("type", &_long_opt_val, kOptMax + 2, "gaia server type(ls/cmp/rpl/ps)", kenum);

        AddExample("-a <ip> -p <port> --region bjdd --available-zone test --type <type>");
    }
    virtual ~SetZone() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptRegion:
                _zone.region = opt;
                break;
            case kOptAvailableZone:
                _zone.available_zone = opt;
                break;
            case kOptMax + 2:
                _type = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const lspb::lsrv_set_zone_response& rsp);
    int Format(const computenode::set_zone_response& rsp);
    int Format(const replicate::pb::SetZoneResponse& rsp);
    int Format(const pspb::SetZoneResponse& rsp);

private:
    std::string _type {};
    std::string _address {};
    uint32_t _port {0};
    VarZone _zone;
    std::string _cluster_id {};
};

}
}
