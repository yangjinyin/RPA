/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_replicator_zone.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/set_replicator_zone.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int SetReplicatorZone::Run() {
    RpcStatus status;
    gaiapb::SetReplicatorZoneRequest request;
    gaiapb::AckResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_zone.Invalid() || _zone.region.empty()) {
        print_error("error, --region and --available-zone should always appear in pairs");
        return 1;
    }

    if (_addr.empty()) {
        print_error("miss --addr");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Set node: %s zone?", _addr.c_str());
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    request.set_log_id(_log_id);
    request.set_addr(_addr);
    request.mutable_zone()->set_region(_zone.region);
    request.mutable_zone()->set_available_zone(_zone.available_zone);
    if (!_cluster_id.empty()) {
        request.set_cluster_id(_cluster_id);
    }

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::set_replicator_zone, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " set node zone failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("add failed, all nodes failed");
    return Output(response);
}

int SetReplicatorZone::Format(const gaiapb::AckResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
