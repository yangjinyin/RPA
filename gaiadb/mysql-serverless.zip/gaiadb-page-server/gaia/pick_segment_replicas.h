/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/pick_segment_replicas.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class PickSegmentReplicas : public Command {
public:
    PickSegmentReplicas() {
        SetName("pick-ps-replicas");
        SetDesc("pick servers to create replicas of segment");
        SetDescCn("选择服务器以创建分片副本");

        AddClusterOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "cluster id of the will create segment", kstring);
        AddRequiredArgOption("replica-num", NULL, 'n', "pick the number of servers to store replicas", kint32_t);
        AddRequiredArgOption("segment-id", NULL, 's', "filter the segment existly replicas", kuint32_t);
        AddRequiredArgOption("size", &_long_opt_val, kOptMax + 1, "used size", kint64_t);
        AddRequiredArgOption("zone", &_long_opt_val, kOptMax + 2, "the pick scope, if specified", kint32_t);
        AddRequiredArgOption("pick-error-store", &_long_opt_val,
                kOptMax + 3,
                "if store has io error, pick it too",
                kbool, kGroup2Scope);
        AddRequiredArgOption("candidates-num", &_long_opt_val,
                kOptMax + 4, "candidates num, default 8",
                kint32_t, kGroup2Scope);
        AddNoArgOption("debug", &_long_opt_val, kOptMax + 5, "trace picking strategy", kGroup2Scope);
        AddRequiredArgOption("limit-recover-num", &_long_opt_val, kOptMax + 6,
                "Lower the priority if the number of recovery num exceeds this", kint32_t);

        AddExample("--cluster-addr <bns://> -c gaia-test-perf -n 3 --size 1024");
        AddExample("--cluster-addr <bns://> -c gaia-test-perf -n 1 -s 1 --size 1024");
        AddExample("--cluster-addr <bns://> -c gaia-test-perf -n 1 -s 1 --zone 2 --size 1024");
    }
    virtual ~PickSegmentReplicas() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtol(opt, NULL, 10));
            break;
        case 'n':
            _replica_num = std::strtoul(opt, NULL, 10);
            break;
        case 'C':
            _cluster_addr = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _segment_size = std::strtoll(opt, NULL, 10);
                break;
            case kOptMax + 2:
                _zone = std::strtol(opt, NULL, 10);
                break;
            case kOptMax + 3:
                _pick_error_store = true;
                break;
            case kOptMax + 4:
                _candidates_num = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 5:
                _debug = true;
                break;
            case kOptMax + 6:
                _limit_recovery_num = std::strtoul(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;
private:
    void Done(pspb::BatchMultiGetStatusResponse_ServerStatus* server_status,
            pspb::MultiGetStatusResponse* response, RpcStatus* status);
    int Execute(const base::EndPoint& node,
            pspb::MultiGetStatusResponse* response, RpcStatus* status, ggpb::Closure* closure);

    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::PickSegmentReplicaResponse& rsp);
private:
    std::string _cluster_addr {};
    std::string _cluster_id {};
    uint32_t _replica_num {0};
    VarOptional<uint32_t> _segment_id;
    int64_t _segment_size {0};
    bool _pick_error_store {false};
    int32_t _zone {0};
    uint32_t _candidates_num {8};
    uint32_t _limit_recovery_num {0};
    bool _debug {false};
    std::atomic<uint64_t> _task_count {0};
};

}
}
