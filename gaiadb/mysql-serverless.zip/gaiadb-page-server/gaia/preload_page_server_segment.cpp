/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/preload_page_server_segment.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/preload_page_server_segment.h"

namespace psvr {
namespace gaia {

int PreLoadPageServerSegment::Run() {
    RpcStatus status;
    pspb::PreLoadSegmentRequest request;
    pspb::PreLoadSegmentResponse response;

    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }
    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_cluster_id.empty()) {
        print_error("miss --cluster-id or -c");
        return 1;
    }

    if (_segment_id < 1) {
        print_error("miss --segment-id or -s");
        return 1;
    }

    if (_size <= 0) {
        print_error("miss or error --size");
        return 1;
    }

    //if (_is_load && _store_id < 0) {
        //print_error("--store-id in load mode");
        //return 1;
    //}

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    request.set_log_id(_log_id);
    request.set_manager_address(_manager_address);
    request.set_cluster_id(_cluster_id);
    request.set_segment_id(_segment_id);
    request.set_size(_size);
    if (_store_id >= 0) {
        request.set_store_id(_store_id);
    }
    //if (_is_load) {
        //request.set_only_load(true);
    //}

    _client.Call(_log_id++, node, &pspb::ManagerService_Stub::PreLoadSegment, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int PreLoadPageServerSegment::Format(const pspb::PreLoadSegmentResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
