/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/file_utils.h
* @author yukeyong@baidu.com
* @brief File operation wrappers and reliable file I/O helpers.
*/

#pragma once

#include <cerrno>
#include <cstdint>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <unistd.h>

#include "psvr/utils.h"
#include "psvr/status.h"
#include "psvr/config.h"

namespace psvr {

namespace db {

inline int NO_OPTIMIZE_MOCK stat(const char* path, struct ::stat* buf) {
    return ::stat(path, buf);
}

inline int NO_OPTIMIZE_MOCK fstat(int fd, struct ::stat* buf) {
    return ::fstat(fd, buf);
}

inline int NO_OPTIMIZE_MOCK fallocate(int fd, int mode, off_t off, off_t len) {
    return ::fallocate(fd, mode, off, len);
}

inline ssize_t NO_OPTIMIZE_MOCK pread(int fd, void* buf, size_t count, off_t off) {
    return ::pread(fd, buf, count, off);
}

inline ssize_t NO_OPTIMIZE_MOCK pwrite(int fd,
        const void* buf, size_t count, off_t off) {
    return ::pwrite(fd, buf, count, off);
}

inline ssize_t NO_OPTIMIZE_MOCK preadv(int fd, const struct iovec* iov,
        int iovcnt, off_t offset) {
    return ::preadv(fd, iov, iovcnt, offset);
}

inline ssize_t NO_OPTIMIZE_MOCK pwritev(int fd, const struct iovec* iov,
        int iovcnt, off_t offset) {
    return ::pwritev(fd, iov, iovcnt, offset);
}

inline int NO_OPTIMIZE_MOCK ftruncate(int fd, off_t length) {
    return ::ftruncate(fd, length);
}

inline int NO_OPTIMIZE_MOCK fsync(int fd) {
    return ::fsync(fd);
}

inline int NO_OPTIMIZE_MOCK fdatasync(int fd) {
    return ::fdatasync(fd);
}

inline bool get_file_size(int fd, ssize_t* size) {
    struct ::stat sbuf {};
    if (db::fstat(fd, &sbuf) == 0) {
        *size = sbuf.st_size;
        return *size >= 0;
    }
    return false;
}

inline Status preadx(int fd, void* data, size_t size, uint64_t offset) {
    auto* output = static_cast<uint8_t*>(data);
    size_t done = 0;
    while (done < size) {
        const ssize_t count = db::pread(fd, output + done, size - done,
                static_cast<off_t>(offset + done));
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            return GetErrStatus();
        }
        if (count == 0) {
            return Status(Code::kStatusError, "unexpected end of file");
        }
        done += static_cast<size_t>(count);
    }
    return Status();
}

inline Status pwritex(int fd,
        const void* data, size_t size, uint64_t offset) {
    const auto* input = static_cast<const uint8_t*>(data);
    size_t done = 0;
    while (done < size) {
        const ssize_t count = db::pwrite(fd, input + done, size - done,
                static_cast<off_t>(offset + done));
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            return GetErrStatus();
        }
        if (count == 0) {
            return Status(Code::kStatusError, "zero-byte file write");
        }
        done += static_cast<size_t>(count);
    }
    return Status();
}

// Read every byte of `iov` at `offset`, resuming after a short read or EINTR.
inline Status preadvx(int fd, const struct iovec* iov, int iovcnt, uint64_t offset) {
    size_t total = 0;
    for (int i = 0; i < iovcnt; ++i) {
        total += iov[i].iov_len;
    }

    size_t done = 0;
    while (done < total) {
        // Resume cursor: skip the fully read iovecs, then re-base the one the read stopped
        // in so only its tail is read again.
        size_t skip = done;
        int idx = 0;
        while (idx < iovcnt && skip >= iov[idx].iov_len) {
            skip -= iov[idx].iov_len;
            ++idx;
        }
        ssize_t count = 0;
        if (skip == 0) {
            count = db::preadv(fd, iov + idx, iovcnt - idx, static_cast<off_t>(offset + done));
        } else {
            const struct iovec head = {
                static_cast<char*>(iov[idx].iov_base) + skip, iov[idx].iov_len - skip
            };
            count = db::preadv(fd, &head, 1, static_cast<off_t>(offset + done));
        }
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            return GetErrStatus();
        }
        if (count == 0) {
            return Status(Code::kStatusError, "unexpected end of file");
        }
        done += static_cast<size_t>(count);
    }
    return Status();
}

// Write every byte of `iov` at `offset`, resuming after a short write or EINTR.
inline Status pwritevx(int fd, const struct iovec* iov, int iovcnt, uint64_t offset) {
    size_t total = 0;
    for (int i = 0; i < iovcnt; ++i) {
        total += iov[i].iov_len;
    }

    size_t done = 0;
    while (done < total) {
        // Resume cursor: skip the fully written iovecs, then re-base the one the write
        // stopped in so only its tail is written again.
        size_t skip = done;
        int idx = 0;
        while (idx < iovcnt && skip >= iov[idx].iov_len) {
            skip -= iov[idx].iov_len;
            ++idx;
        }
        ssize_t count = 0;
        if (skip == 0) {
            count = db::pwritev(fd, iov + idx, iovcnt - idx, static_cast<off_t>(offset + done));
        } else {
            const struct iovec head = {
                static_cast<char*>(iov[idx].iov_base) + skip, iov[idx].iov_len - skip
            };
            count = db::pwritev(fd, &head, 1, static_cast<off_t>(offset + done));
        }
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            return GetErrStatus();
        }
        if (count == 0) {
            return Status(Code::kStatusError, "zero-byte file write");
        }
        done += static_cast<size_t>(count);
    }
    return Status();
}

inline Status syncx(int fd, bool use_fdatasync) {
    while (use_fdatasync ? db::fdatasync(fd) : db::fsync(fd)) {
        if (errno != EINTR) {
            return GetErrStatus();
        }
    }
    return Status();
}

inline Status truncatex(int fd, uint64_t size) {
    while (db::ftruncate(fd, static_cast<off_t>(size)) != 0) {
        if (errno != EINTR) {
            return GetErrStatus();
        }
    }
    return Status();
}

inline Status sync_directoryx(const char* path) {
    if (!FLAGS_psvr_enable_sync_directory) {
        return Status();
    }
    const int fd = ::open(path, O_RDONLY | O_DIRECTORY);
    if (fd < 0) {
        return GetErrStatus();
    }
    Status status = syncx(fd, false);
    ::close(fd);
    return status;
}

}  // namespace db
}  // namespace psvr
