/*****************************************************************************
  @file include/bos0delete.cc
 fetch bos data
 *******************************************************/

#include "bos0bos.h"
#include <thread>
#include <chrono>

namespace bos {

bool BosDelete::delete_object(const std::string &filename) {
  if (!get_client()->delete_object(bos_info().bucket, filename)) {
    return true;
  }
  return false;
}

bool BosDelete::delete_multi_objects(
    const std::vector<std::string> &filenames) {

  std::vector<bir_bos::BceRequestContext> ctx(filenames.size());
  int i = 0;
  for (const std::string &objectKey : filenames) {
    ctx[i].request = new bir_bos::DeleteObjectRequest(
        bos_info().bucket, objectKey);
    ctx[i].response = new bir_bos::DeleteObjectResponse;
    ctx[i].is_own = true;
    ++i;
  }
  if (get_client()->send_request((int)ctx.size(), &ctx.front())) {
    return false;
  }

  bool ret = true;
  for (size_t i = 0; i < ctx.size(); ++i) {
    bir_bos::DeleteObjectRequest* request = (
        bir_bos::DeleteObjectRequest*)ctx[i].request;
    bir_bos::DeleteObjectResponse* response = (
        bir_bos::DeleteObjectResponse*)ctx[i].response;
    if (response->is_fail()) {
      ret = delete_object_retry(request->object_name()) || ret;
    }
  }
  return ret;
}

bool BosDelete::delete_object_retry(
    const std::string &filename, const uint64_t retry) {
  int index = retry;
  if (delete_object(filename)) {
    while (index > 0) {
      if (!delete_object(filename)) {
        return false;
      }
      --index;
      std::this_thread::sleep_for(std::chrono::microseconds(20));
    }
    return true;
  }
  return false;
}
  
} // end bos

