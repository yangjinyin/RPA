/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/compress_utils.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <mutex>
#include <cctype>
#include <algorithm>
#include <filesystem>
#include <snappy.h>
#include <lib_bk/lz4.h>
#include "psvr/utils.h"
#include "psvr/config.h"
#include "psvr/file_utils.h"
#include "psvr/compress_utils.h"

namespace psvr {

static std::mutex zstd_mutex;
#define ZSTD_CTX_INIT(ctx, fn)  \
    if (!ctx) {                 \
        std::unique_lock<std::mutex> locker(zstd_mutex);    \
        if (!ctx) {             \
            ctx = fn();         \
        }                       \
        if (!ctx) {             \
            LOG(ERROR) << "failed:" << #fn;  \
            return false;       \
        }                       \
    }

bool get_compress_type(const std::string& name, int32_t* type) {
    std::string type_name = name;
    std::transform(type_name.begin(), type_name.end(), type_name.begin(),
            [](unsigned char c) { return std::tolower(c); });
    if (type_name == "zstd") {
        *type = PSVR_COMPRESS_TYPE_ZSTD;
        return true;
    } else if (type_name == "lz4") {
        *type = PSVR_COMPRESS_TYPE_LZ4;
        return true;
    } else if (type_name == "snappy") {
        *type = PSVR_COMPRESS_TYPE_SNAPPY;
        return true;
    } else {
        *type = PSVR_COMPRESS_TYPE_NONE;
        return false;
    }
}

void get_compress_name(int32_t type, std::string* name) {
    if (type == PSVR_COMPRESS_TYPE_ZSTD) {
        *name = "zstd";
    } else if (type == PSVR_COMPRESS_TYPE_LZ4) {
        *name = "lz4";
    } else if (type == PSVR_COMPRESS_TYPE_SNAPPY) {
        *name = "snappy";
    } else {
        *name = "none";
    }
}

bool compress_data(int32_t compress_type, int32_t compress_level,
        gaia_apply::byte* buf, gaia_apply::ulint buf_size,
        gaia_apply::byte* compressed_buf, gaia_apply::ulint compressed_buf_size,
        gaia_apply::ulint* compressed_size) {
    if (compress_type == PSVR_COMPRESS_TYPE_SNAPPY) {
        if (snappy::MaxCompressedLength(buf_size) > compressed_buf_size) {
            // over size
            return false;
        }
        snappy::RawCompress(reinterpret_cast<const char*>(buf),
                static_cast<size_t>(buf_size),
                reinterpret_cast<char*>(compressed_buf),
                static_cast<size_t*>(compressed_size));
        return true;
    } else if (compress_type == PSVR_COMPRESS_TYPE_ZSTD) {
        thread_local ZSTD_CCtx* zstd_cctx = nullptr;        // donot use bthread sleep in process
        thread_local ThreadLocalGuard zstd_cctx_guard(&zstd_cctx, ZSTD_freeCCtx);
        ZSTD_CTX_INIT(zstd_cctx, ZSTD_createCCtx);
        if (ZSTD_compressBound(buf_size) > compressed_buf_size) {
            // over size
            return false;
        }
        size_t size = ZSTD_compressCCtx(zstd_cctx,
                reinterpret_cast<void*>(compressed_buf),
                static_cast<size_t>(compressed_buf_size),
                reinterpret_cast<const void*>(buf),
                static_cast<size_t>(buf_size),
                compress_level);
        if (ZSTD_isError(size)) {
            LOG(ERROR) << "zstd compress failed:[" << ZSTD_getErrorName(size) << "]";
            return false;
        }
        *compressed_size = size;
        return true;
    } else if (compress_type == PSVR_COMPRESS_TYPE_LZ4) {
        if (LZ4_compressBound(buf_size) > static_cast<int>(compressed_buf_size)) {
            // over size
            return false;
        }
        int size = LZ4_compress_fast(reinterpret_cast<const char*>(buf),
                reinterpret_cast<char*>(compressed_buf),
                static_cast<int>(buf_size),
                static_cast<int>(compressed_buf_size),
                compress_level);
        if (size <= 0) {
            LOG(ERROR) << "lz4 compress failed:[" << size << "]";
            return false;
        }
        *compressed_size = size;
        return true;
    } else {
        LOG(FATAL) << "not support compress type:[" << compress_type << "]";
        return false;
    }
}

bool decompress_data(uint32_t compress_type,
        gaia_apply::byte* compress_buf, gaia_apply::ulint compress_buf_size,
        gaia_apply::ulint decompress_buf_size, gaia_apply::byte* decompressed_buf) {
    if (compress_type == PSVR_COMPRESS_TYPE_SNAPPY) {
        return snappy::RawUncompress(reinterpret_cast<char*>(compress_buf),
                static_cast<size_t>(compress_buf_size),
                reinterpret_cast<char*>(decompressed_buf));
    } else if (compress_type == PSVR_COMPRESS_TYPE_ZSTD) {
        thread_local ZSTD_DCtx* zstd_dctx = nullptr;     // donot use bthread sleep in process
        thread_local ThreadLocalGuard zstd_dctx_guard(&zstd_dctx, ZSTD_freeDCtx);
        ZSTD_CTX_INIT(zstd_dctx, ZSTD_createDCtx);
        unsigned long long raw_size = ZSTD_getFrameContentSize(compress_buf, compress_buf_size);
        if (raw_size != 0
                && raw_size != ZSTD_CONTENTSIZE_ERROR
                && raw_size != ZSTD_CONTENTSIZE_UNKNOWN) {
            if (raw_size == ZSTD_decompressDCtx(zstd_dctx,
                        reinterpret_cast<void*>(decompressed_buf),
                        static_cast<size_t>(decompress_buf_size),
                        reinterpret_cast<const void*>(compress_buf),
                        static_cast<size_t>(compress_buf_size))) {
                return true;
            }
        }
        LOG(ERROR) << "zstd decompress data failed, raw_size:[" << raw_size << "]";
        return false;
    } else if (compress_type == PSVR_COMPRESS_TYPE_LZ4) {
        return LZ4_decompress_safe(reinterpret_cast<const char*>(compress_buf),
                reinterpret_cast<char*>(decompressed_buf),
                static_cast<size_t>(compress_buf_size),
                static_cast<size_t>(decompress_buf_size)) > 0;
    } else {
        LOG(FATAL) << "not support decompress type:[" << compress_type << "]";
        return false;
    }
}

bool page_is_compressed(const gaia_apply::byte* page) {
    return gaia_apply::fil_page_get_type(page) == gaia_apply::FIL_PAGE_COMPRESSED;
}

int64_t page_compress_data_size(const gaia_apply::byte* page,
        gaia_apply::ulint block_size) {
    gaia_apply::ulint size = gaia_apply::mach_read_from_2(page + gaia_apply::FIL_PAGE_COMPRESS_SIZE_V1)
        + gaia_apply::FIL_PAGE_DATA;
    return (size + (block_size - 1)) & ~(block_size - 1); // align block_size
}

bool decompress_page(gaia_apply::byte* src,
        gaia_apply::byte* decompress_buf, gaia_apply::ulint decompress_buf_size) {
    INIT_APPLY_RAW_ARG(false);
    gaia_apply::ulint page_type = gaia_apply::fil_page_get_type(src);
    if (page_type != gaia_apply::FIL_PAGE_COMPRESSED) {
        return true;
    }
    // get compress info
    gaia_apply::ulint compress_version = gaia_apply::mach_read_from_1(src + gaia_apply::FIL_PAGE_VERSION);
    gaia_apply::ulint compress_type = gaia_apply::mach_read_from_1(src + gaia_apply::FIL_PAGE_ALGORITHM_V1);
    gaia_apply::ulint original_type = gaia_apply::mach_read_from_2(src + gaia_apply::FIL_PAGE_ORIGINAL_TYPE_V1);
    gaia_apply::ulint original_size = gaia_apply::mach_read_from_2(src + gaia_apply::FIL_PAGE_ORIGINAL_SIZE_V1);
    gaia_apply::ulint compress_size = gaia_apply::mach_read_from_2(src + gaia_apply::FIL_PAGE_COMPRESS_SIZE_V1);
    if (compress_version != 1
            || original_size < gaia_apply::UNIV_PAGE_SIZE_MIN - (gaia_apply::FIL_PAGE_DATA + 8)
            || original_size > gaia_apply::UNIV_PAGE_SIZE_MAX - gaia_apply::FIL_PAGE_DATA
            || decompress_buf_size < original_size + gaia_apply::FIL_PAGE_DATA) {
        LOG(ERROR) << "check compress data failed,"
            << " compress_version:[" << compress_version
            << "] original_type:[" << original_type
            << "] original_size:[" << original_size
            << "] compress_size:[" << compress_size
            << "] compress_type:[" << compress_type
            << "] decompress_buf_size:[" << decompress_buf_size
            << "]";
        return false;
    }
    if (compress_type < PSVR_COMPRESS_TYPE_SNAPPY) {
        // mysql raw compress type
        LOG(ERROR) << "invalid compress type:[" << compress_type << "]";
        return false;
    }
    if (!decompress_data(compress_type,
                src + gaia_apply::FIL_PAGE_DATA,
                compress_size,
                decompress_buf_size,
                decompress_buf)) {
        LOG(ERROR) << "decompress page failed,"
            << " page_type:[" << page_type
            << "] compress_type:[" << compress_type
            << "] original_size:[" << original_size
            << "] compress_size:[" << compress_size
            << "] decompress_buf_size:[" << decompress_buf_size
            << "]";
        return false;
    }

    LOG(TRACE) << "decompress page ok,"
        << " type:[" << compress_type
        << "] compress_size:[" << compress_size
        << "] original_size:[" << original_size
        << "]";

    gaia_apply::mach_write_to_2(src + gaia_apply::FIL_PAGE_TYPE, original_type APPLY_RAW_ARG_NAME_CC);   // reset page type
    if (APPLY_RAW_IS_ERROR()) {
        LOG(ERROR) << "set type error, type:" << original_type;
        return false;
    }
    std::memmove(src + gaia_apply::FIL_PAGE_DATA, decompress_buf, original_size);    // Copy src header

    auto ret = memcmp(src + gaia_apply::FIL_PAGE_LSN + 4,
                src + (original_size + gaia_apply::FIL_PAGE_DATA) - gaia_apply::FIL_PAGE_END_LSN_OLD_CHKSUM + 4, 4);
    if (ret != 0) {
        LOG(ERROR) << "decompress page failed,"
            << " memcmp ret:[" << ret
            << "]";
        return false;
    }

    gaia_apply::mach_write_to_8(src + gaia_apply::FIL_PAGE_FILE_FLUSH_LSN, 0x0);
    return true;
}

bool compress_page(gaia_apply::space_id_t logical_space_id, gaia_apply::page_no_t logical_page_no,
        gaia_apply::ulint block_size, int32_t compress_type, int32_t compress_level,
        gaia_apply::byte* src, gaia_apply::ulint src_size,
        gaia_apply::byte* dst, gaia_apply::ulint dst_size,
        gaia_apply::ulint* compressed_size) {
    // See mysql compress
    gaia_apply::ulint placeholder = gaia_apply::mach_read_from_8(src + gaia_apply::FIL_PAGE_FILE_FLUSH_LSN);
    gaia_apply::ulint page_type = gaia_apply::fil_page_get_type(src);
    gaia_apply::space_id_t page_space = gaia_apply::page_get_space_id(src);
    gaia_apply::space_id_t page_no = gaia_apply::page_get_page_no(src);
    if (page_type == gaia_apply::FIL_PAGE_RTREE
            || placeholder
            || page_space != logical_space_id
            || page_no != logical_page_no
            || page_no < 2                                      // ignore page 0 and page 1
            || page_type == gaia_apply::FIL_PAGE_COMPRESSED     // if data compress by mysql
            || block_size == 0
            || block_size == gaia_apply::ULINT_UNDEFINED        // if file system disable it
            || src_size < block_size * 2) {                     // src size to small
        LOG(TRACE) << "write page data does not meet compression conditions,"
            << " page_type:[" << page_type
            << "] block_size:[" << block_size
            << "] len:[" << src_size
            << "] page_no:[" << page_no
            << "] placeholder:[" << placeholder
            << "]";
        return false;
    }

    // page body - page header
    gaia_apply::ulint real_src_size = src_size - gaia_apply::FIL_PAGE_DATA;
    gaia_apply::ulint real_dst_size = dst_size - gaia_apply::FIL_PAGE_DATA;
    gaia_apply::ulint real_compressed_size = 0;
    bool compress_ret = compress_data(compress_type, compress_level,
            src + gaia_apply::FIL_PAGE_DATA, real_src_size,
            dst + gaia_apply::FIL_PAGE_DATA, real_dst_size, &real_compressed_size);
    if (!compress_ret
            || real_compressed_size >= real_src_size
            || real_src_size - real_compressed_size < block_size) {
        LOG(TRACE) << "compress failed,"
            << " ret:[" << compress_ret
            << "] real_src_size:[" << real_src_size
            << "] real_compressed_size:[" << real_compressed_size
            << "]";
        return false;
    }

    LOG(TRACE) << "compress page ok,"
        << " type:[" << compress_type
        << "] real_src_size:[" << real_src_size
        << "] real_compressed_size:[" << real_compressed_size
        << "]";

    INIT_APPLY_RAW_ARG(false);
    // copy the header as it ( copy src to dst )
    std::memmove(dst, src, gaia_apply::FIL_PAGE_DATA);
    // reset page type to compress type
    gaia_apply::mach_write_to_2(dst + gaia_apply::FIL_PAGE_TYPE, gaia_apply::FIL_PAGE_COMPRESSED APPLY_RAW_ARG_NAME_CC);
    // replace gaia_apply::FIL_PAGE_FILE_FLUSH_LSN (8byte)
    if (!APPLY_RAW_IS_ERROR()) {
        gaia_apply::mach_write_to_1(dst + gaia_apply::FIL_PAGE_VERSION, 1 APPLY_RAW_ARG_NAME_CC);
    }
    if (!APPLY_RAW_IS_ERROR()) {
        gaia_apply::mach_write_to_1(dst + gaia_apply::FIL_PAGE_ALGORITHM_V1, compress_type APPLY_RAW_ARG_NAME_CC);
    }
    if (!APPLY_RAW_IS_ERROR()) {
        gaia_apply::mach_write_to_2(dst + gaia_apply::FIL_PAGE_ORIGINAL_TYPE_V1, page_type APPLY_RAW_ARG_NAME_CC);
    }
    if (!APPLY_RAW_IS_ERROR()) {
        gaia_apply::mach_write_to_2(dst + gaia_apply::FIL_PAGE_ORIGINAL_SIZE_V1, real_src_size APPLY_RAW_ARG_NAME_CC);
    }
    if (!APPLY_RAW_IS_ERROR()) {
        gaia_apply::mach_write_to_2(dst + gaia_apply::FIL_PAGE_COMPRESS_SIZE_V1, real_compressed_size APPLY_RAW_ARG_NAME_CC);
    }
    if (APPLY_RAW_IS_ERROR()) {
        LOG(ERROR) << "set dst error,"
            << " page_type:[" << gaia_apply::FIL_PAGE_COMPRESSED
            << "] version:[" << 1
            << "] compress_type:[" << compress_type
            << "] page_type:[" << page_type
            << "] real_src_size:[" << real_src_size
            << "] real_compressed_size:[" << real_compressed_size
            << "]";
        return false;
    }
    // return
    real_compressed_size += gaia_apply::FIL_PAGE_DATA;
    if (real_compressed_size % block_size) {
        // clear empty tail
        memset(dst + real_compressed_size, 0x0, block_size - (real_compressed_size % block_size));
    }

    *compressed_size = (real_compressed_size + (block_size - 1)) & ~(block_size - 1); // align block_size
    return true;
}

namespace dict {
namespace detail {

int64_t Base::GetFileSize(const std::string& filename) {
    struct stat sbuf;
    if (::stat(filename.c_str(), &sbuf) != 0) {
        return -1;
    }
    return static_cast<int64_t>(sbuf.st_size);
}

bool Base::LoadAndCreateDict(const std::string& dict_file) {
    const int64_t file_size = GetFileSize(dict_file);
    if (file_size <= 0) {
        LOG(WARNING) << "dict file size invalid,"
            << " dict:[" << dict_file
            << "] file_size:[" << file_size
            << "]";
        return false;
    }
    _buf_size = static_cast<size_t>(file_size);

    thread_local void* l_buf = nullptr;
    thread_local ThreadLocalGuard l_buf_guard(&l_buf, std::free);
    thread_local size_t l_buf_size = 0;
    if (l_buf_size < _buf_size) {
        _buf = std::realloc(l_buf, _buf_size);
        if (!_buf) {
            LOG(WARNING) << "malloc dict buf failed,"
                << " size:[" << _buf_size
                << "]";
            return false;
        }
        l_buf = _buf;
        l_buf_size = _buf_size;
        _buf = nullptr;
    }
    int fd = open(dict_file.c_str(), O_RDONLY, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        LOG(WARNING) << "open dict file failed,"
            << " dict:[" << dict_file
            << "] file_size:[" << file_size
            << "] err:[" << strerror(errno)
            << "]";
        return false;
    }
    ssize_t read_size = ::pread(fd, l_buf, _buf_size, 0/*offset*/);
    if (static_cast<size_t>(read_size) != _buf_size) {
        LOG(WARNING) << "load dict data failed,"
            << " dict:[" << dict_file
            << "] file_size:[" << file_size
            << "] read_size:[" << read_size
            << "]";
        close(fd);
        return false;
    }
    close(fd);
    if (!CreateDict(l_buf, _buf_size)) {
        LOG(WARNING) << "create dict ctx failed,"
            << " dict:[" << dict_file
            << "]";
        return false;
    }
    return true;
}

}   // end of ns detail

bool TrainDict::Train(std::string* dict_buf) {
    dict_buf->resize(_dict_max_buf_size, '\0');
    size_t dict_len = ZDICT_trainFromBuffer(&(*dict_buf)[0], _dict_max_buf_size,
            &_samples_buf[0], &_sample_size_vec[0], static_cast<uint32_t>(_sample_size_vec.size()));
    if (ZDICT_isError(dict_len)) {
        LOG(WARNING) << "train dict failed, " << ZDICT_getErrorName(dict_len);
        return false;
    }
    PSVR_ASSERT(dict_len <= _dict_max_buf_size);
    dict_buf->resize(dict_len);
    return true;
}

bool TrainDict::SaveToFile(const std::string& dict_file, const std::string& dict_buf) {
    return atomic_write_file(dict_file, dict_buf, true)
        && psvr::db::sync_directoryx(std::filesystem::path(dict_file).parent_path().c_str()).IsOk();
}

bool Compress::Execute(ZSTD_CCtx* const cctx, const void* buf, size_t buf_size,
        void* compressed_buf, size_t compressed_buf_size, size_t* compressed_size) {
    *compressed_size = ZSTD_compress_usingCDict(cctx, compressed_buf, compressed_buf_size,
            buf, buf_size, _dict);
    return !ZSTD_isError(*compressed_size);
}

bool Decompress::Execute(ZSTD_DCtx* const dctx, const void* compressed_buf, size_t compressed_buf_size,
        void* buf, size_t buf_size, size_t* original_size) {
    *original_size = ZSTD_getFrameContentSize(compressed_buf, compressed_buf_size);
    if (*original_size == ZSTD_CONTENTSIZE_ERROR
            || *original_size == ZSTD_CONTENTSIZE_UNKNOWN) {
        LOG(WARNING) << "get original size from compressed buf failed,"
            << " rc:[" << *original_size
            << "]";
        return false;
    }
    const auto dict_id = ZSTD_getDictID_fromDDict(_dict);
    const auto real_dict_id = ZSTD_getDictID_fromFrame(compressed_buf, compressed_buf_size);
    if (dict_id != real_dict_id) {
        LOG(WARNING) << "dict id mismatch,"
            << " id:[" << dict_id
            << "] real_id:[" << real_dict_id
            << "]";
        return false;
    }
    const size_t size = ZSTD_decompress_usingDDict(dctx, buf, buf_size,
            compressed_buf, compressed_buf_size, _dict);
    return !ZSTD_isError(size) && size == *original_size;
}


}
}
