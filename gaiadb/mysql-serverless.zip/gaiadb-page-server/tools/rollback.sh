#!/bin/bash

set -e

CHECK_WORK=1

# Get the script directory
PROJECT_DIR=$(cd "$(dirname "$0")" && pwd)

if [ ! -d "$PROJECT_DIR/upgrade" ]; then
    echo "not found $PROJECT_DIR/upgrade directory"
    exit 1
fi

if [ $CHECK_WORK -eq 1 ]; then
    if [ "`whoami`" != "work" ]; then
        echo "Need work account to execute, current is "`whoami`
        exit 1;
    fi
fi

backup_name=$1

if [ -z $backup_name ]; then
    echo "Usage: sh $0 <backup_name>"
    echo "Available backups:"
    ls -l "$PROJECT_DIR/upgrade/" 2>/dev/null | grep "^d" | awk '{print "  " $NF}'
    exit 1
fi

backup_dir="$PROJECT_DIR/upgrade/$backup_name"

if [ ! -d "$backup_dir" ]; then
    echo "Backup directory not found: $backup_dir"
    echo "Available backups:"
    ls -l "$PROJECT_DIR/upgrade/" 2>/dev/null | grep "^d" | awk '{print "  " $NF}'
    exit 1
fi

echo "=== Rollback Plan ==="
echo "Backup: $backup_name"
echo "Files to restore:"
echo "  $backup_dir/page_server -> $PROJECT_DIR/bin/page_server"
echo "  $backup_dir/gaia -> $PROJECT_DIR/bin/gaia"
echo "  $backup_dir/load.sh -> $PROJECT_DIR/load.sh"
echo ""
read -p "Confirm rollback? (y/N): " confirm
if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
    echo "Rollback cancelled"
    exit 0
fi

echo ""
echo "=== Stopping service ==="
sh "$PROJECT_DIR/load.sh" stop $CHECK_WORK

echo ""
echo "=== Restoring files ==="
cp "$backup_dir/page_server" "$PROJECT_DIR/bin/page_server"
cp "$backup_dir/gaia" "$PROJECT_DIR/bin/gaia"
cp "$backup_dir/load.sh" "$PROJECT_DIR/load.sh"

chmod +x "$PROJECT_DIR/bin/page_server"
chmod +x "$PROJECT_DIR/bin/gaia"
chmod +x "$PROJECT_DIR/load.sh"

echo ""
echo "=== Starting service ==="
sh "$PROJECT_DIR/load.sh" start $CHECK_WORK

echo ""
echo "=== Rollback completed ==="
