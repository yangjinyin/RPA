/*****************************************************************************
 @file include/bos0conductor.cc
 *******************************************************/

#include "bos0conductor.h"
#include "base/logging.h"
#include "bos0bos.h"
#include "gaiadb.h"
#include "sql/opt_costconstantcache.h"
extern Cost_constant_cache *cost_constant_cache;
namespace bos {

std::vector<BosInfo> BosConductor::build() {
  std::vector<BosInfo> tmp_infos;
  if (gaiadb_build_all_bos_infos(false, tmp_infos)) {
    LOG(WARNING) << "build bos info failed";
    return tmp_infos;
  }
  return tmp_infos;
}

bool BosConductor::init_use_sts(const std::string &ak, const std::string &sk, 
                        const std::string &account_id, const std::string &endpoint, 
                        const std::string &bucket, const bool current) {
  bos_config_.endpoint = endpoint;
  bos_config_.timeout = 120;
  bos_config_.retry = 2;
  bos_config_.max_parallel = 10;
  sts_client_ = std::make_shared<bir_bos::StsClient>(ak, sk);
  bir_bos::AssumeRoleRequest request(
      "3600", account_id, psmcli->get_cluster_id());
  bir_bos::AssumeRoleResponse response;
  sts_client_->AssumeRole(request, &response);
  bos_credential_.set_ak(ak);
  bos_credential_.set_sk(sk);
  bos_credential_.set_sts_token(response.session_token());
  bos_client_ = std::make_shared<bir_bos::Client>(
      bos_credential_, bos_config_);
  bos_info_.ak = ak;
  bos_info_.sk = sk;
  bos_info_.bucket = bucket;
  bos_info_.endpoint = endpoint;
  bos_info_.account_id = account_id;
  bos_info_.current = current;
  return false;
}

bool BosConductor::init(const std::string &ak, const std::string &sk, 
                        const std::string &account_id, const std::string &endpoint, 
                        const std::string &bucket, const bool current) {
  bos_config_.endpoint = endpoint;
  bos_config_.timeout = 120;
  bos_config_.retry = 2;
  bos_config_.max_parallel = 10;
  bos_config_.multi_part_size = BosWriter::partSize;
  bos_credential_.set_ak(ak);
  bos_credential_.set_sk(sk);
  bos_client_ = 
    std::make_shared<bir_bos::Client>(bos_credential_, bos_config_);
  bos_info_.ak = ak;
  bos_info_.sk = sk;
  bos_info_.bucket = bucket;
  bos_info_.endpoint = endpoint;
  bos_info_.account_id = account_id;
  bos_info_.current = current;
  return false;
}

void progress_callback(int64_t increment, int64_t transfered, 
                       int64_t total, void* user_data) {
  LOG(TRACE) << "progress_callback[" << user_data << "] => " <<
    increment << " ," << transfered << "," << total;
}

std::string normalize_filename(const std::string &filename) {
  std::string normal_filename = filename;
  if (normal_filename.find("./") == 0) {
    normal_filename.erase(0, 2);
  }
  return normal_filename;
}

bool write_to_bos(const std::string &filename, const uint64_t size) {
  std::string normal_filename = normalize_filename(filename);
  BosWriter g_bos_writer;
  while (cost_constant_cache == nullptr) {
    std::this_thread::sleep_for(srv_delay_send_request);
  }
  std::vector<BosInfo> bos_infos = g_bos_writer.build();
  if (bos_infos.empty()) {
    LOG(WARNING) << "bos_infos is empty";
    return true;
  }
  for (auto &bos_info : bos_infos) {
    if (bos_info.current) {
      g_bos_writer.init(bos_info.ak, bos_info.sk, 
        bos_info.account_id, bos_info.endpoint, 
        bos_info.bucket, bos_info.current);
      break;
    }
  }
  if (g_bos_writer.put_object(normal_filename, size)) {
    LOG(WARNING) << "put_object failed, filename: " << normal_filename;
    return true;
  }
  return false;
}

bool download_from_bos(const std::string &filename) {
  std::string normal_filename = normalize_filename(filename);
  BosReader g_bos_reader;
  std::vector<BosInfo> bos_infos = g_bos_reader.build();
  if (bos_infos.empty()) {
    LOG(WARNING) << "bos_infos is empty";
    return true;
  }
  bool ret = false;
  for (auto &bos_info : bos_infos) {
    g_bos_reader.init(bos_info.ak, bos_info.sk, 
      bos_info.account_id, bos_info.endpoint, 
      bos_info.bucket, bos_info.current);
    if (g_bos_reader.get_object(normal_filename)) {
      LOG(WARNING) << "get_object failed, filename: " << normal_filename
                   << ", bucket: " << bos_info.bucket
                   << ", endpoint: " << bos_info.endpoint;
      ret = true;
    } else {
      ret = false;
      break;
    }
  }
  
  return ret;
}

std::string add_cluster_id(const std::string &filename) {
  std::string new_filename = std::string(get_cluster_id()) + "/" + filename;
  return new_filename;
}
}// end bos
