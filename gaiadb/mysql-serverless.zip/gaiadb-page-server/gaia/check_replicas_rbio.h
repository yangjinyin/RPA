/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/check_replicas_rbio.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <iomanip>
#include <gaiadb/utils/ut.h>
#include "psvr/config.h"
#include "psvr/log.h"
#include "psvr/psminfo.h"
#include "psvr/thread_pool.hpp"
#include "psvr/buf.h"
#include "psvr/record_op.h"
#include "gaia/command.h"

namespace psvr {
namespace gaia {

struct RbioCtx {
    base::EndPoint node;
    psvr::RpcStatus status;
    pspb::RbioResponse response;
    bool rpc_ok;
    bool rsp_ok;
    bool corrupted;
    bool is_empty;
    uint32_t crc;
    uint32_t space_id;
    uint32_t page_no;
    uint64_t page_lsn;
};

inline void ResetRbioCtxRsp(std::shared_ptr<RbioCtx> ctx) {
    ctx->rpc_ok = false;
    ctx->rsp_ok = false;
    ctx->corrupted = true;
    ctx->is_empty = false;
    ctx->crc = 0;
    ctx->space_id = 0;
    ctx->page_no = 0;
    ctx->page_lsn = 0;
}

inline std::ostream& operator<<(std::ostream& os, const RbioCtx& ctx) {
    if (!ctx.rpc_ok) {
        return os << ctx.node
            << " rpc_fail";
    } else {
        return os << ctx.node
            << " rpc_ok"
            << " rsp_ok:" << (ctx.rsp_ok ? "y" : "n")
            << " corrupted:" << (ctx.corrupted ? "y" : "n")
            << " empty:" << (ctx.is_empty ? "y" : "n")
            << " crc:" << ctx.crc
            << " space_id:" << ctx.space_id
            << " page_no:" << ctx.page_no
            << " page_lsn:" << ctx.page_lsn;
    }
};

enum CheckSpacePageAction {
    kSend,
    kCheck
};

struct CheckSpacePageContext : public thread::TaskContext {
    CheckSpacePageAction action;
    uint32_t space_id;
    uint32_t extent_id;
    uint32_t extent_pos;
    uint32_t logical_page_no;
    uint32_t segment_id;
    uint64_t vlsn {LOG_START_LSN};
    uint64_t retry_num {0};
    std::atomic<uint32_t> task_count {0};
    std::vector<std::shared_ptr<RbioCtx>> rbio_ctxs;
    std::mutex mutex;
};

class ProgressBar {
public:
    ProgressBar(uint32_t space_width = 40, uint32_t extent_width = 60)
            : _silent(false), _space_width(space_width), _extent_width(extent_width),
            _space_total(0), _space_complete(0),
            _extent_total(0), _extent_complete(0), _retry_io(0),
            _iodepth(0), _prepare_extent(0), _last_show_time(0), _error_page_count(0) {
        _start_time = std::chrono::steady_clock::now();
    }
    virtual ~ProgressBar() {}

    void set_silent(bool s) { _silent = s; }
    void set_space_total(uint32_t total) {
        _space_total = total;
        _space_complete = 0;
    }
    void inc_space_complete() { ++_space_complete; }

    void set_extent_total(uint32_t total) {
        _extent_total = total;
        _extent_complete = 0;
    }
    void inc_extent_complete() { _extent_complete += 64; }

    void inc_retry_io() { ++_retry_io; }
    void set_iodepth(uint32_t n) { _iodepth.store(n); }
    void set_prepare_extent(uint32_t n) { _prepare_extent.store(n); }
    void inc_error_page_count() { ++_error_page_count; }

    void Display(bool force = false);

    void Done() {
        Display(true);
        std::cout << std::endl;
    }

private:
    bool _silent;
    uint32_t _space_width;
    uint32_t _extent_width;
    uint32_t _space_total;
    std::atomic<uint32_t> _space_complete;
    uint32_t _extent_total;
    std::atomic<uint32_t> _extent_complete;
    std::atomic<uint32_t> _retry_io;
    std::atomic<uint32_t> _iodepth;
    std::atomic<uint32_t> _prepare_extent;
    int64_t _last_show_time;
    std::atomic<uint32_t> _error_page_count;
    std::chrono::steady_clock::time_point _start_time;
};

class CheckReplicasRbio : public Command {
public:
    CheckReplicasRbio() : Command(true) {
        SetName("check-replicas-rbio");
        SetDesc("check replicas pages data consistency of segment by rbio");
        SetDescCn("通过 rbio 检查分片副本的页面数据一致性");

        AddPsmClusterOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "cluster id", kstring);
        AddRequiredArgOption("space-id", &_long_opt_val, kOptMax + 2,
                "only check this space id if specified, supports multiple",
                kuint32_t);
        AddRequiredArgOption("segment-id", NULL, 's',
                "only check this segment id if specified, supports multiple",
                kuint32_t);

        AddRequiredArgOption("io-depth", &_long_opt_val, kOptMax + 4, "io depth", kuint32_t, kGroup2Scope);
        AddRequiredArgOption("thread-num", &_long_opt_val, kOptMax + 5, "thread pool num", kuint32_t, kGroup2Scope);
        AddNoArgOption("silent", &_long_opt_val, kOptMax + 6, "silent", kGroup2Scope);
        AddRequiredArgOption("replica-num", &_long_opt_val, kOptMax + 7,
                "mismatch num will print warning logs, default 3",
                kuint64_t);
        AddNoArgOption("debug", &_long_opt_val, kOptMax + 8, "trace logs", kGroup2Scope);
        AddNoArgOption("max-page-lsn", &_long_opt_val, kOptMax + 9, "check all pages lsn lower than it", kGroup2Scope);

        AddExample("--manager-address bns://xxx --cluster-id id");
        AddExample("--manager-address bns://xxx --cluster-id id --space-id <id>");
        AddExample("--manager-address bns://xxx --cluster-id id --segment-id <id>");
        AddExample("--manager-address bns://xxx --cluster-id id --space-id <id> --segment-id <id>");
        AddExample("--manager-address bns://xxx --cluster-id id --max-page-lsn <lsn>");
    }
    virtual ~CheckReplicasRbio() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'c':
            _cluster_id = opt;
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 's':
            _specify_segment_id = true;
            _segment_id_set.emplace(std::strtoul(opt, nullptr, 10));
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 2:
                _specify_space = true;
                _space_id_vec.emplace_back(std::strtoul(opt, nullptr, 10));
                break;
            case kOptMax + 4:
                _io_depth = std::strtol(opt, nullptr, 10);
                break;
            case kOptMax + 5:
                _thread_num = std::strtoul(opt, nullptr, 10);
                break;
            case kOptMax + 6:
                _silent = true;
                break;
            case kOptMax + 7:
                _replica_num = std::strtoul(opt, nullptr, 10);
                break;
            case kOptMax + 8:
                _debug = true;
                break;
            case kOptMax + 9:
                _max_page_lsn = std::strtoull(opt, nullptr, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual const std::string& log_file_name() override {
        return _cluster_id;
    }

    virtual int Run() override;

    virtual void Stop() override {
        _stopped = true;
        if (_thread_pool) {
            _thread_pool->Stop(true);
        }
    }

private:
    void OnCompletion(CheckSpacePageContext* ctx);
    bool GetSpaces(std::vector<uint32_t>* ids);
    bool GetSpaceExtents(uint32_t space_id, std::list<uint32_t>* extent_segments);
    bool CheckSpace(uint32_t space_id);
    bool GetSegmentNodes(uint32_t segment_id, std::vector<base::EndPoint>* seg_nodes);
    void CheckSpacePage(CheckSpacePageContext* ctx);
    void OnCheckSpacePage(CheckSpacePageContext* check_ctx, std::shared_ptr<RbioCtx> rbio_ctx);
    void OnCheck(CheckSpacePageContext* check_ctx);
    bool ExistSpaceId(uint32_t id);

private:
    std::string _manager_address {};
    std::string _cluster_id {};
    bool _specify_space {false};
    std::vector<uint32_t> _space_id_vec {};
    bool _specify_segment_id {false};
    std::set<uint32_t> _segment_id_set {};
    int32_t _io_depth {2048};
    uint32_t _thread_num {16};
    bool _silent {false};
    size_t _replica_num {3};
    bool _debug {false};
    uint64_t _max_page_lsn {0};

    PsmInfoPtr _psm_info {nullptr};
    BufPoolPtr _buf_pool {nullptr};
    std::atomic<uint64_t> _fail_num {0};
    std::vector<uint32_t> _space_ids;
    std::set<uint32_t> _space_ids_set;
    std::atomic<int32_t> _io_inflight {0};
    std::map<uint32_t, std::vector<base::EndPoint>> _cache_segments;
    std::shared_ptr<ThreadPoolExecutor<CheckSpacePageContext>> _thread_pool;
    ProgressBar _show_bar;
    std::shared_mutex _shared_mutex;
};

}
}
