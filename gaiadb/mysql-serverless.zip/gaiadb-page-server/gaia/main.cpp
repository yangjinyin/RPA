/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/main.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/log.h"
#include "psvr/version.h"
#include "gaia/command.h"
#include <algorithm>

// ps
#include "gaia/list_page_server_status.h"
#include "gaia/list_page_server_recovery.h"
#include "gaia/create_page_server_segment.h"
#include "gaia/drop_page_server_segment.h"
#include "gaia/reopen_page_server_segment.h"
#include "gaia/list_page_server_store.h"
#include "gaia/disable_page_server_store.h"
#include "gaia/update_page_server_store.h"
#include "gaia/update_page_server_manager.h"
#include "gaia/update_page_server_recovery.h"
#include "gaia/set_page_server_recovery_prior.h"
#include "gaia/pick_segment_replicas.h"
#include "gaia/rebalance_segment_replicas.h"
#include "gaia/preload_page_server_segment.h"
#include "gaia/load_page_server_segment.h"
#include "gaia/read_page_server_page.h"
#include "gaia/repair_page_server_page.h"
#include "gaia/list_page_server_psminfo.h"
#include "gaia/get_page_server_compress_config.h"
#include "gaia/set_page_server_compress_config.h"
#include "gaia/list_page_server_compression.h"
#include "gaia/compress_page_server_segment.h"
#include "gaia/set_page_server_cluster_stat.h"
#include "gaia/list_page_server_cluster_stauts.h"
#include "gaia/ignore_page_server_gc_space.h"
// ls
#include "gaia/update_log_service_manager.h"
#include "gaia/get_log_service_segment_log.h"
// cmp
#include "gaia/update_compute_node_manager.h"
#include "gaia/get_takeover_compute_node.h"
#include "gaia/do_takeover_compute_node.h"
#include "gaia/read_buf_pool_page.h"
// psm
#include "gaia/add_segment.h"
#include "gaia/enable_segment.h"
#include "gaia/list_segment.h"
#include "gaia/get_space_extent_segment.h"
#include "gaia/drop_segment.h"
#include "gaia/add_segment_replica.h"
#include "gaia/drop_segment_replica.h"
#include "gaia/update_segment_replica.h"
#include "gaia/get_lowest_replica.h"
#include "gaia/list_page_server.h"
#include "gaia/drop_page_server.h"
#include "gaia/add_log_service.h"
#include "gaia/drop_log_service.h"
#include "gaia/list_log_service.h"
#include "gaia/add_compute_node.h"
#include "gaia/drop_compute_node.h"
#include "gaia/update_compute_node.h"
#include "gaia/list_compute_node.h"
#include "gaia/list_space.h"
#include "gaia/create_space.h"
#include "gaia/drop_space.h"
#include "gaia/extend_space.h"
#include "gaia/repair_primary_standby_space_extent.h"
#include "gaia/get_statistic.h"
#include "gaia/get_topology.h"
#include "gaia/get_lowest_point.h"
#include "gaia/list_replicator.h"
#include "gaia/add_replicator.h"
#include "gaia/drop_replicator.h"
#include "gaia/list_replicator_node.h"
#include "gaia/register_replicator_node.h"
#include "gaia/cancel_replicator_node.h"
#include "gaia/set_replication_lsn.h"
#include "gaia/get_cluster_role.h"
#include "gaia/set_cluster_role.h"
#include "gaia/get_tde_enable_status.h"
#include "gaia/open_tde.h"
#include "gaia/list_standby_cluster.h"
#include "gaia/add_standby_cluster.h"
#include "gaia/drop_standby_cluster.h"
#include "gaia/update_replica_recovery_status.h"
#include "gaia/get_segment_compress_config.h"
#include "gaia/set_segment_compress_config.h"
#include "gaia/set_lowest_gc_lsn_config.h"
#include "gaia/set_binlog_in_redo_config.h"
// replication
#include "gaia/list_replication_status.h"
#include "gaia/update_replication_manager.h"
// tools
#include "gaia/get_manager_addr_node.h"
#include "gaia/append_file_utils.h"
#include "gaia/check_ibd_file.h"
#include "gaia/parse_page.h"
#include "gaia/write_ibd_page_data.h"
#include "gaia/build_checkpoint_file.h"
#include "gaia/check_replicas_rbio.h"
#include "gaia/parse_log_block_buf.h"
#include "gaia/set_ps_db_file_size.h"
#include "gaia/add_raft_peer.h"
#include "gaia/drop_raft_peer.h"
#include "gaia/transfer_raft_leader.h"
#include "gaia/read_raft_snapshot_meta.h"

#include "gaia/get_zone.h"
#include "gaia/set_zone.h"
#include "gaia/clear_zone.h"
#include "gaia/set_compute_node_zone.h"
#include "gaia/set_log_service_zone.h"
#include "gaia/set_replicator_zone.h"
#include "gaia/set_segment_replica_zone.h"
#include "gaia/clear_compute_node_zone.h"
#include "gaia/clear_log_service_zone.h"
#include "gaia/clear_replicator_zone.h"
#include "gaia/clear_segment_replica_zone.h"

std::map<std::string, psvr::gaia::CommandPtr(*)()> g_commands;
std::vector<std::pair<std::string, psvr::gaia::CommandPtr(*)()>> g_order_commands;

// Calculate the edit distance between two strings (Levenshtein distance)
static int levenshtein_distance(const std::string& s1, const std::string& s2) {
    int m = s1.length();
    int n = s2.length();
    std::vector<std::vector<int>> dp(m + 1, std::vector<int>(n + 1));

    for (int i = 0; i <= m; ++i) {
        dp[i][0] = i;
    }
    for (int j = 0; j <= n; ++j) {
        dp[0][j] = j;
    }

    for (int i = 1; i <= m; ++i) {
        for (int j = 1; j <= n; ++j) {
            if (s1[i - 1] == s2[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1];
            } else {
                dp[i][j] = std::min({dp[i - 1][j] + 1,      // deletion
                                     dp[i][j - 1] + 1,      // insertion
                                     dp[i - 1][j - 1] + 1});  // substitution
            }
        }
    }

    return dp[m][n];
}

// Find the most similar command name to the input string
static std::string find_similar_command(const std::string& input) {
    std::string best_match;
    int min_distance = INT_MAX;

    for (const auto& cmd_pair : g_commands) {
        // Skip EmptyCommand (used as separators, not real commands)
        if (!cmd_pair.second()->is_cmd()) {
            continue;
        }
        int dist = levenshtein_distance(input, cmd_pair.first);
        if (dist < min_distance) {
            min_distance = dist;
            best_match = cmd_pair.first;
        }
    }

    // Only return suggestion when edit distance is small enough (threshold: 3)
    if (min_distance <= 3 && !best_match.empty()) {
        return best_match;
    }
    return "";
}

template<typename T>
void register_command() {
    auto factory = &psvr::gaia::create_command_instance<T>;
    auto cmd = factory();
    g_order_commands.push_back(std::make_pair(cmd->name(), factory));
}

void register_separator(const char* name) {
    g_order_commands.push_back(std::make_pair(name,
                &psvr::gaia::create_command_instance<psvr::gaia::EmptyCommand>));
}

void help() {
    printf("Usage:  gaia [COMMAND] [OPTION]...\n");
    for (auto& it : g_order_commands) {
        if (it.second()->is_cmd()) {
            printf("  %-40s%s\n", it.first.c_str(), it.second()->description());
        } else {
            printf("\n%s [COMMAND] list:\n", it.first.c_str());
        }
    }
    printf("\n");
    printf("See 'gaia [COMMAND] -h or --help' for more information on a specific command\n");
    printf("\n");
    printf("%s\n", psvr::get_version().c_str());
}

void init() {
    register_separator("PageServer");
    register_command<psvr::gaia::CompressPageServerSegment>();    // compress-ps-segment
    register_command<psvr::gaia::CreatePageServerSegment>();      // create-ps-segment
    register_command<psvr::gaia::DisablePageServerStore>();       // disable-ps-store
    register_command<psvr::gaia::DropPageServerSegment>();        // drop-ps-segment
    register_command<psvr::gaia::GetPageServerCompressConfig>();  // get-ps-compress-config
    register_command<psvr::gaia::IgnorePageServerGcSpace>();      // ignore-ps-gc-space
    register_command<psvr::gaia::ListPageServerClusterStatus>();  // list-ps-cluster-status
    register_command<psvr::gaia::ListPageServerCompression>();    // list-ps-compression
    register_command<psvr::gaia::ListPageServerPsmInfo>();        // list-ps-psminfo
    register_command<psvr::gaia::ListPageServerRecovery>();       // list-ps-recovery
    register_command<psvr::gaia::ListPageServerStatus>();         // list-ps-status
    register_command<psvr::gaia::ListPageServerStore>();          // list-ps-store
    register_command<psvr::gaia::LoadPageServerSegment>();        // load-ps-segment
    register_command<psvr::gaia::PickSegmentReplicas>();          // pick-ps-replicas
    register_command<psvr::gaia::PreLoadPageServerSegment>();     // preload-ps-segment
    register_command<psvr::gaia::ReadPageServerPage>();           // read-ps-page
    register_command<psvr::gaia::RebalanceSegmentReplicas>();     // rebalance-ps-replicas
    register_command<psvr::gaia::ReopenPageServerSegment>();      // reopen-ps-segment
    register_command<psvr::gaia::RepairPageServerPage>();         // repair-ps-page
    register_command<psvr::gaia::SetPageServerClusterStat>();     // set-ps-cluster-stat
    register_command<psvr::gaia::SetPageServerCompressConfig>();  // set-ps-compress-config
    register_command<psvr::gaia::SetPageServerRecoveryPrior>();   // set-ps-recovery-prior
    register_command<psvr::gaia::UpdatePageServerManager>();      // update-ps-manager
    register_command<psvr::gaia::UpdatePageServerRecovery>();     // update-ps-recovery
    register_command<psvr::gaia::UpdatePageServerStore>();        // update-ps-store

    register_separator("Compute");
    register_command<psvr::gaia::DoTakeOverComputeNode>();        // do-takeover-compute-node
    register_command<psvr::gaia::GetTakeOverComputeNode>();       // get-takeover-compute-node
    register_command<psvr::gaia::ReadBufPoolPage>();              // read-bp-page
    register_command<psvr::gaia::UpdateComputeNodeManager>();     // update-cmp-manager

    register_separator("LogService");
    register_command<psvr::gaia::GetLogServiceSegmentLog>();      // get-ls-seg-log
    register_command<psvr::gaia::UpdateLogServiceManager>();      // update-ls-manager

    register_separator("Manager");
    register_command<psvr::gaia::AddComputeNode>();               // add-compute-node
    register_command<psvr::gaia::AddLogService>();                // add-log-service
    register_command<psvr::gaia::AddReplicator>();                // add-replicator
    register_command<psvr::gaia::AddSegment>();                   // add-segment
    register_command<psvr::gaia::AddSegmentReplica>();            // add-segment-replica
    register_command<psvr::gaia::AddStandbyCluster>();            // add-standby-cluster
    register_command<psvr::gaia::CancelReplicatorNode>();         // cancel-replicator-node
    register_command<psvr::gaia::CreateSpace>();                  // create-space
    register_command<psvr::gaia::DropComputeNode>();              // drop-compute-node
    register_command<psvr::gaia::DropLogService>();               // drop-log-service
    register_command<psvr::gaia::DropPageServer>();               // drop-page-server
    register_command<psvr::gaia::DropReplicator>();               // drop-replicator
    register_command<psvr::gaia::DropSegment>();                  // drop-segment
    register_command<psvr::gaia::DropSegmentReplica>();           // drop-segment-replica
    register_command<psvr::gaia::DropSpace>();                    // drop-space
    register_command<psvr::gaia::DropStandbyCluster>();           // drop-standby-cluster
    register_command<psvr::gaia::EnableSegment>();                // enable-segment
    register_command<psvr::gaia::ExtendSpace>();                  // extend-space
    register_command<psvr::gaia::GetClusterRole>();               // get-cluster-role
    register_command<psvr::gaia::GetLowestPoint>();               // get-lowest-point
    register_command<psvr::gaia::GetLowestReplica>();             // get-lowest-replica
    register_command<psvr::gaia::GetSegmentCompressConfig>();     // get-segment-compress-config
    register_command<psvr::gaia::GetSpaceExtentSegment>();        // get-space-extent-segment
    register_command<psvr::gaia::GetStatistic>();                 // get-statistic
    register_command<psvr::gaia::GetTDEEnableStatus>();           // get-tde-enable-status
    register_command<psvr::gaia::GetTopology>();                  // get-topology
    register_command<psvr::gaia::ListComputeNode>();              // list-compute-node
    register_command<psvr::gaia::ListLogService>();               // list-log-service
    register_command<psvr::gaia::ListPageServer>();               // list-page-server
    register_command<psvr::gaia::ListReplicationStatus>();        // list-replication-status
    register_command<psvr::gaia::ListReplicator>();               // list-replicator
    register_command<psvr::gaia::ListReplicatorNode>();           // list-replicator-node
    register_command<psvr::gaia::ListSegment>();                  // list-segment
    register_command<psvr::gaia::ListSpace>();                    // list-space
    register_command<psvr::gaia::ListStandbyCluster>();           // list-standby-cluster
    register_command<psvr::gaia::OpenTDE>();                      // open-tde
    register_command<psvr::gaia::RegisterReplicatorNode>();       // register-replicator-node
    register_command<psvr::gaia::RepairPrimaryStandbySpaceExtent>(); // repair-primary-standby-space-extent
    register_command<psvr::gaia::SetBinlogInRedoConfig>();        // set-binlog-in-redo-config
    register_command<psvr::gaia::SetClusterRole>();               // set-cluster-role
    register_command<psvr::gaia::SetLowestGcLsnConfig>();         // set-lowest-gc-lsn-config
    register_command<psvr::gaia::SetReplicationLsn>();            // set-replication-lsn
    register_command<psvr::gaia::SetSegmentCompressConfig>();     // set-segment-compress-config
    register_command<psvr::gaia::UpdateComputeNode>();            // update-compute-node
    register_command<psvr::gaia::UpdateReplicaRecoveryStatus>();  // update-replica-recovery-status
    register_command<psvr::gaia::UpdateReplicationManager>();     // update-replication-manager
    register_command<psvr::gaia::UpdateSegmentReplica>();         // update-segment-replica

    register_separator("Zone");
    register_command<psvr::gaia::ClearComputeNodeZone>();         // clear-compute-node-zone
    register_command<psvr::gaia::ClearLogServiceZone>();          // clear-log-service-zone
    register_command<psvr::gaia::ClearReplicatorZone>();          // clear-replicator-zone
    register_command<psvr::gaia::ClearSegmentReplicaZone>();      // clear-segment-replica-zone
    register_command<psvr::gaia::ClearZone>();                    // clear-zone
    register_command<psvr::gaia::GetZone>();                      // get-zone
    register_command<psvr::gaia::SetComputeNodeZone>();           // set-compute-node-zone
    register_command<psvr::gaia::SetLogServiceZone>();            // set-log-service-zone
    register_command<psvr::gaia::SetReplicatorZone>();            // set-replicator-zone
    register_command<psvr::gaia::SetSegmentReplicaZone>();        // set-segment-replica-zone
    register_command<psvr::gaia::SetZone>();                      // set-zone

    register_separator("Tools");
    register_command<psvr::gaia::AppendFileUtils>();              // append-file-utils
    register_command<psvr::gaia::BuildCheckpointFile>();          // build-ckp-file
    register_command<psvr::gaia::CheckIbdFile>();                 // check-ibd-file
    register_command<psvr::gaia::CheckReplicasRbio>();            // check-replicas-rbio
    register_command<psvr::gaia::GetManagerAddrNode>();           // get-manager-address-node
    register_command<psvr::gaia::ParseLogBlockBuf>();             // parse-log-block-buf
    register_command<psvr::gaia::ParsePage>();                    // parse-page
    register_command<psvr::gaia::SetPageServerDbFileSize>();      // set-ps-db-file-size
    register_command<psvr::gaia::WriteIbdPageData>();             // write-ibd-page-data

    register_separator("Raft");
    register_command<psvr::gaia::AddRaftPeer>();                  // add-raft-peer
    register_command<psvr::gaia::DropRaftPeer>();                 // drop-raft-peer
    register_command<psvr::gaia::ReadRaftSnapshotMeta>();         // read-raft-snapshot-meta
    register_command<psvr::gaia::TransferRaftLeader>();           // transfer-raft-leader
}

int main (int argc, char** argv) {
    init();
    gaiadb::common::ut_crc32_init();

    if (argc < 2) {
        fprintf(stderr, "Error: miss command in gaia, see help\n");
        help();
        return -1;
    }

    for (auto& it : g_order_commands) {
        if (it.first.size()) {
            g_commands[it.first] = it.second;
        }
    }

    const std::string cmd_name(argv[1]);
    auto it = g_commands.find(cmd_name);
    if (it == g_commands.end()) {
        if (cmd_name == "-h" || cmd_name == "--help" || cmd_name == "help") {
            help();
            return -1;
        }
        fprintf(stderr, "Error: not found command in gaia, see help\n");
        std::string similar = find_similar_command(cmd_name);
        if (!similar.empty()) {
            fprintf(stderr, "Did you mean: %s %s?\n", argv[0], similar.c_str());
        }
        return -1;
    }

    auto cmd = it->second();
    optind = 2;
    const struct option* opts = cmd->options();
    const char* stopts = psvr::build_short_options(opts);

    bool enable_log = false;
    int option = 0;
    bool parsed_long_opt = true;
    while ((option = getopt_long_only(argc, argv, stopts, opts, NULL)) != -1) {
        switch (option) {
        case 'h':
            cmd->help();
            return 0;
        case 'o':
            cmd->set_format(optarg);
            break;
        case 'm':
            cmd->set_multi_type();
            break;
        case 'b':
            cmd->set_both();
            break;
        case 't':
            cmd->set_timeout_ms(std::strtol(optarg, NULL, 10));
            break;
        case 'f':
            cmd->set_force();
            break;
        case 'T':
            cmd->set_show_total();
            break;
        case 'H':
            cmd->set_human_readable();
            break;
        case 0:
            parsed_long_opt = true;
            switch(cmd->long_opt_val()) {
            case psvr::gaia::kOptLogId:
                cmd->set_log_id(std::strtoll(optarg, NULL, 10));
                break;
            case psvr::gaia::kOptEnableLog:
                enable_log = true;
                break;
            case psvr::gaia::kOptConnectTimeout:
                gaiadb::common::FLAGS_gaia_connect_timeout_ms = std::strtoll(optarg, NULL, 10);
                break;
            case psvr::gaia::kOptRawWithTable:
                cmd->set_raw_with_table(optarg ? !!optarg : true);
                break;
            case psvr::gaia::kOptSortBy:
                psvr::gaia::SetTableSortBy(optarg);
                break;
            case psvr::gaia::kOptSortOrder:
                psvr::gaia::SetTableSortAscending(std::string(optarg) != "desc");
                break;
            default:
                parsed_long_opt = false;
                break;
            }
            if (parsed_long_opt) {
                break;
            }
            /*fallthrough*/
        default:
            int ret = cmd->Parser(option, optarg);
            if (ret == 0) {
                break;
            } else {
                fprintf(stderr, "gaia %s parse args failed, option:%d, optarg:%s, long_opt:%d\n",
                        cmd_name.c_str(), option, optarg, cmd->long_opt_val());
            }
            return 1;
        }
    }
    cmd->SignalRegister();
    if (cmd->enable_log()) {
        enable_log = true;  // some cmd enable log default
    }

    logging::SetMinLogLevel(1);
    logging::ComlogSinkOptions options;
    options.async = false;
    options.shorter_log_level = false;
    options.log_dir = psvr::FLAGS_psvr_comlog_path;
    if (cmd->log_file_name().empty()) {
        options.process_name = "gaia";
    } else {
        options.process_name = cmd->log_file_name().c_str();
    }
    options.print_vlog_as_warning = false;
    options.split_type = static_cast<logging::ComlogSplitType>(1);
    options.quota_size = 102400;
    options.cut_size_megabytes = 1024;
    options.quota_day = 10;
    options.enable_wf_device = true;
    if (enable_log) {
        if (psvr::LogSink::GetInstance()->Setup(&options) != 0) {
            fprintf(stderr, "Error: init log failed\n");
            return -1;
        }
    }
    // disable logging
    logging::SetLogSink(psvr::LogSink::GetInstance());
    if (!enable_log) {
        psvr::LogSink::GetInstance()->set_disable(true);
    }
    LOG(NOTICE) << "Run log id:" << cmd->log_id();
    return cmd->Run();
}
