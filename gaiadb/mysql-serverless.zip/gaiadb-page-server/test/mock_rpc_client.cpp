/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file /data/yukeyong/baidu/dba/gaiadb-page-server/test/mock_rpc_client.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/mock_rpc_client.h"

namespace psvr {
namespace test {

// Initialize to nullptr; each test fixture creates and resets this in
// SetUp/TearDown to avoid static-initialization-order destruction issues
// with the Google Mock registry.
std::shared_ptr<MockRpcChannel> g_mock_channel;

}
}
