/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server_psminfo.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_page_server_psminfo.h"

namespace psvr {
namespace gaia {

int ListPageServerPsmInfo::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address and --port");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }
    RpcStatus status;
    pspb::ListPsmInfoRequest request;
    pspb::ListPsmInfoResponse response;

    request.set_log_id(_log_id);
    if (_manager_address.size()) {
        request.set_addr(_manager_address);
    }
    _client.Call(_log_id++, node, &pspb::QueryService_Stub::ListPsmInfo, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int ListPageServerPsmInfo::Format(const pspb::ListPsmInfoResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 0);
    table.AddRowsWithName({"manager_address", "nodes"}, true);
    for (auto& psm_info : rsp.psm_infos()) {
        std::string nodes_str(std::to_string(psm_info.nodes_size()));
        for (int32_t i = 0; i < psm_info.nodes_size(); ++i) {
            nodes_str.append(base::string_printf(" %s", psm_info.nodes(i).c_str()));
        }
        table.AddRowsValue({psm_info.addr(), nodes_str});
    }
    table.Display();
    return 0;
}

}
}
