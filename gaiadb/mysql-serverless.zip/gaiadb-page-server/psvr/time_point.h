/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/time_point.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <base/macros.h>
#include <base/object_pool.h>
#include <base/strings/string_piece.h>
#include "psvr/common.h"
#include "psvr/config.h"

namespace psvr {

static inline bvar::Adder<int64_t> stat_tp_used_count("psvr_tp_used_count");

class TimePoint {
public:
    TimePoint() : _start_time(0), _useless_cost(0), _last_anno_time(0), _annotate_nr(0) {}
    ~TimePoint() {}

    static TimePoint* CreateTimePoint(int64_t st) {
        TimePoint* tp = base::get_object<TimePoint>();
        if (__builtin_expect(tp == nullptr, 0)) {
            return nullptr;
        }
        stat_tp_used_count << 1;
        tp->_start_time = st;
        tp->_useless_cost = 0;
        tp->_last_anno_time = st;
        tp->_info.clear();
        tp->_annotate_nr = 0;
        tp->Annotate(true, "tp_init");
        return tp;
    }

    const std::string& info() { return _info; }

    bool Elapsed(int64_t max_t) const {
        return base::cpuwide_time_us() - _start_time - _useless_cost >= max_t;
    }

    void destroy() {
        _info.clear();
        stat_tp_used_count << -1;
        base::return_object(this);
    }

    void Annotate(bool add_to_total, const char* fmt, ...) {
        if (FLAGS_psvr_annotate_max_num == 0
                || _annotate_nr >= FLAGS_psvr_annotate_max_num) {
            return;
        }
        const int64_t cur_time = base::cpuwide_time_us();
        const int64_t anno_time = base::cpuwide_time_us() - _last_anno_time;
        // add delimiter
        if (add_to_total) {
            base::string_appendf(&_info, ", ");
        } else {
            base::string_appendf(&_info, ", #");
        }
        // add annotate
        va_list ap;
        va_start(ap, fmt);
        base::string_vappendf(&_info, fmt, ap);
        va_end(ap);
        // add cost time
        base::string_appendf(&_info, ":%ldus", anno_time);
        // next annotate
        _last_anno_time = cur_time;
        ++_annotate_nr;
        if (!add_to_total) {
            _useless_cost += anno_time;
        }
    }

    void ToString(std::ostream& os) {
        const int64_t total = base::cpuwide_time_us() - _start_time;
        if (_useless_cost == 0) {
            os << " trace:[total:" << total << _info << "]";
        } else {
            os << " trace:[total:" << (total - _useless_cost) << _info << "]";
        }
    }

private:
    int64_t _start_time;
    int64_t _useless_cost;
    int64_t _last_anno_time;
    int32_t _annotate_nr;
    std::string _info;
};

inline std::ostream& operator<<(std::ostream& os, TimePoint* tp) {
    if (tp) {
        tp->ToString(os);
    }
    return os;
}

#define TP_INIT_ST_IF(tp, st, condition)  \
    do {  \
        if (condition && !tp) { \
            tp = TimePoint::CreateTimePoint(st); \
        } else { \
            tp = nullptr; \
        } \
    } while (0)

#define TP_INIT_IF(tp, condition)  \
    TP_INIT_ST_IF(tp, base::cpuwide_time_us(), condition)

#define TP_INIT(tp) TP_INIT_IF(tp, true)
#define TP_INIT_ST(tp, st) TP_INIT_ST_IF(tp, st, true)
#define TP_DESTROY(tp) do { if (tp) { (tp)->destroy(); (tp) = nullptr; } } while (0)

#define TP_ELAPSED(tp, max_st) ((tp) && ((tp)->Elapsed(max_st)))

#define ADD_TRACE_TP_EXTRA(tp, add_to_total, fmt, ...)      \
do {                                        \
    if (tp) {                               \
        (tp)->Annotate(add_to_total, fmt, ##__VA_ARGS__);        \
    }                                       \
} while (0)

#define ADD_TRACE_TP(tp, fmt, ...)  ADD_TRACE_TP_EXTRA(tp, true, fmt,  ##__VA_ARGS__)

struct TimePointGuard {
    TimePointGuard() : _tp(nullptr) {
        TP_INIT(_tp);
    }
    TimePointGuard(bool cond) : _tp(nullptr) {
        TP_INIT_IF(_tp, cond);
    }
    TimePointGuard(int64_t st, bool cond) : _tp(nullptr) {
        TP_INIT_ST_IF(_tp, st, cond);
    }
    ~TimePointGuard() {
        TP_DESTROY(_tp);
    }

    TimePoint* tp() { return _tp; }

private:
    TimePoint* _tp;
};

}
