/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/cluster.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <baidu/rpc/closure_guard.h>
#include "psvr/utils.h"
#include "psvr/cluster.h"
#include "psvr/control.h"

namespace psvr {

RpcQuota::RpcQuota(const std::string& name) {
    _flow_quota.reset(new FlowQuota(&FLAGS_psvr_query_metadata_quota_per_cluster, true));
    _flow_quota->expose_as(name, "cluster_status_psm_quota_total_used");
}

RpcQuota::~RpcQuota() {
    _flow_quota->hide();
}

std::shared_ptr<SpaceMetaEventType> RpcQuota::CreateSpaceMetaEvent(SegmentPtr segment,
        gaia_apply::space_id_t space_id,
        ggpb::Closure* closure,
        pspb::Status* status) {
    return _space_event_ops.Add(space_id, segment, closure, status);
}

std::shared_ptr<SpaceExtentEventType> RpcQuota::CreateSpaceExtentEvent(SegmentPtr segment,
        gaia_apply::space_id_t space_id,
        uint32_t begin_extent_id,
        uint32_t search_extent_id,
        gaia_apply::page_no_t logical_page_no,
        ggpb::Closure* closure,
        pspb::Status* status) {
    const event_space_extent_t fold(space_id, begin_extent_id);
    ExtentArg extent_arg {search_extent_id, logical_page_no};
    return _offset_event_ops.Add(fold, segment, closure, status, extent_arg);
}

std::shared_ptr<PeerEventType> RpcQuota::CreatePeerEvent(SegmentPtr segment,
        ggpb::Closure* closure,
        pspb::Status* status) {
    return _peer_event_ops.Add(segment->segment_id(), segment, closure, status);
}

bool LogServices::GetRefreshLock(std::shared_ptr<Segment> locker) {
    {
        std::shared_lock slk(_shared_mutex);
        if (auto owner = _locker.lock(); segment_is_valid(owner) && owner != locker) {
            LOG(TRACE) << "owner:" << owner
                << ", locker:" << locker;
            return false;
        }
    }
    {
        std::unique_lock lk(_shared_mutex);
        if (auto owner = _locker.lock(); segment_is_valid(owner) && owner != locker) {
            LOG(TRACE) << "owner:" << owner
                << ", locker:" << locker;
            return false;
        }
        _locker = locker;
        return true;
    }
}

void LogServices::PutRefreshLock() {
    std::unique_lock lk(_shared_mutex);
    _locker.reset();
}

void InBackup::Update(bool s) {
    const int32_t val = s ? 1 : -1;
    const int32_t old = _in_backup.exchange(val);
    if (old != val) {
        _change_time.store(base::cpuwide_time_us());
        LOG(NOTICE) << _name << " backup status:[" << val << "]";
    }
    _lease.store(base::cpuwide_time_us());
}

InBackup::operator bool() const noexcept {
    const int64_t interval_us = get_heartbeat_interval_us();
    const int64_t cur_us = base::cpuwide_time_us();
    return _in_backup.load() >= 0
        || _change_time.load() + interval_us * 10 >= cur_us
        || _lease.load() + interval_us * 3 <= cur_us;
}

bool EncryptHelper::InitCipherStream(const gaiapb::EncryptionInfo& encryption_info_pb) {
    std::unique_lock lk(_shared_mutex);

    // init already
    if (_cipher_stream) {
        return true;
    }

    bool ret = _encryption_info.Init(encryption_info_pb);
    if (!ret) {
        LOG(WARNING) << "encryption info init faild, key_size:[" << _encryption_info.encryption_key.size()
                     << "], iv_size:[" << _encryption_info.encryption_iv.size() << "], alg:["
                     << _encryption_info.encryption_alg << "]";
        return false;
    }
    if (!_encryption_info.is_valid() || !_encryption_info.check_alg_supported()) {
        LOG(WARNING) << "encryption info is invalid, key_size:[" << _encryption_info.encryption_key.size()
                     << "], iv_size:[" << _encryption_info.encryption_iv.size() << "], alg:["
                     << _encryption_info.encryption_alg << "]";
        return false;
    }

    _cipher_stream.reset(new BlockAccessCipherStream(_encryption_info));
    return true;
}

const BlockAccessCipherStreamPtr EncryptHelper::cipher_stream() {
    std::shared_lock slk(_shared_mutex);
    return _cipher_stream;
}

const EncryptionInfo &EncryptHelper::encryption_info() {
    std::shared_lock slk(_shared_mutex);
    return _encryption_info;
}

Cluster::Cluster(const std::string& name)
    : _name(name),
    _hash_val(Get32bitHash(name)),
    _use_batch_fetch(0),
    _cn_lowest_lsn(0), _ps_lowest_lsn(0),
    _cn_lowest_gc_lsn(0), _ps_lowest_gc_lsn(0),
    _max_get_log_lsn(0),
    _last_lsn_update_time(0),
    _in_backup(_name.c_str()),
    _enable_encrypt(0) {
    _rpc_quota.reset(new RpcQuota(name));
    _log_services.reset(new LogServices);
    _statistic.reset(new ClusterStatistic(name));
    _fetch_quota.reset(new Quota(name, "cluster_fetch_quota_total_remain", &FLAGS_psvr_cluster_fetch_max_buf_size));
    _recover_redo_quota.reset(new Quota(name, "cluster_recover_redo_quota_total_remain", &FLAGS_psvr_cluster_recover_redo_max_buf_size));
    _ignore_corrupt_info.reset(new IgnoreCorruptInfo());
    _encrypt_helper.reset(new EncryptHelper());
}

}
