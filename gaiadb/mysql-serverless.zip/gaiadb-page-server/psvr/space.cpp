/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/space.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/config.h"
#include "psvr/space.h"

namespace psvr {

static bvar::Adder<int64_t> stat_page_count("psvr_page_count");
static bvar::Adder<int64_t> stat_space_status_count("psvr_space_status_count");

gaia_apply::page_size_t l_page_size(gaia_apply::FLAGS_univ_page_size,
        gaia_apply::FLAGS_univ_page_size, false);

const gaia_apply::page_size_t& gaia_page_size() { return l_page_size; }
gaia_apply::ulint gaia_physical_page_size() { return l_page_size.physical(); }
gaia_apply::ulint gaia_logical_page_size() { return l_page_size.logical(); }
bool gaia_page_is_compressed() { return l_page_size.is_compressed(); }

SpaceStatusManager::~SpaceStatusManager() {
    stat_space_status_count << -_space_status_size;
}

size_t SpaceStatusManager::GetSpaceStatusCount() const {
    std::shared_lock slk(_shared_mutex);
    return _space_status_size;
}

bool SpaceStatusManager::SetSpaceStatus(gaia_apply::space_id_t space_id, uint32_t s) {
    {
        std::shared_lock slk(_shared_mutex);
        auto it = _space_status.find(space_id);
        auto cur_s = kSpaceStatusUnknown;
        if (it != _space_status.end()) {
            cur_s = it->second.status;
        }
        if (cur_s == s) {
            return true;
        }
        if (space_status_with_psm(s)) {
            if (space_status_is_deleted(s)) {
                /* Set to deleted:
                 * if current status is ok and was set by the parser, do not update it */
                if (space_status_is_work(cur_s) && !space_status_with_psm(cur_s)) {
                    return false;
                }
            } else {
                /* Set to ok:
                 * if space status is not unknown or not set by psm, do not update it */
                if (!space_status_is_unknown(cur_s) && !space_status_with_psm(cur_s)) {
                    return false;
                }
            }
        }
    }
    if (!space_status_is_unknown(s)){
        std::unique_lock lk(_shared_mutex);
        auto it = _space_status.emplace(space_id, SpaceStatus(s, kSpaceEncryptStatusUnknown, 0));
        if (it.second) {
            ++_space_status_size;
            stat_space_status_count << 1;
        } else {
            it.first->second.status = s;
        }
        return true;
    }
    return false;
}

uint32_t SpaceStatusManager::GetSpaceStatus(gaia_apply::space_id_t space_id) const {
    std::shared_lock slk(_shared_mutex);
    auto it = _space_status.find(space_id);
    if (it != _space_status.end()) {
        return it->second.status;
    }
    return kSpaceStatusUnknown;
}

bool SpaceStatusManager::SetSpaceEncryptStatus(gaia_apply::space_id_t space_id, uint32_t s) {
    {
        std::shared_lock slk(_shared_mutex);
        auto it = _space_status.find(space_id);
        auto cur_es = kSpaceEncryptStatusUnknown;
        if (it != _space_status.end()) {
            cur_es = it->second.encrypt_status;
        }
        if (cur_es == s) {
            return true;
        }
        // once encrypt is setted, can not set again
        if (!space_encrypt_status_is_unknown(cur_es)) {
            return false;
        }
    }

    {
        std::unique_lock lk(_shared_mutex);
        auto it = _space_status.emplace(space_id, SpaceStatus(kSpaceStatusUnknown, s, 0));
        if (it.second) {
            ++_space_status_size;
            stat_space_status_count << 1;
        } else {
            it.first->second.encrypt_status = s;
        }
        return true;
    }
    return false;
}

uint32_t SpaceStatusManager::GetEncryptSpaceStatus(gaia_apply::space_id_t space_id) const {
    std::shared_lock slk(_shared_mutex);
    auto it = _space_status.find(space_id);
    if (it != _space_status.end()) {
        return it->second.encrypt_status;
    }
    return kSpaceEncryptStatusUnknown;
}

bool SpaceStatusManager::SetSafeTrimLsn(gaia_apply::space_id_t space_id, gaia_apply::lsn_t lsn) {
    {
        std::shared_lock slk(_shared_mutex);
        auto it = _space_status.find(space_id);
        gaia_apply::lsn_t cur_lsn = 0;
        if (it != _space_status.end()) {
            cur_lsn = it->second.safe_trim_lsn;
        }
        if (cur_lsn == lsn) {
            return true;
        }
    }

    {
        std::unique_lock lk(_shared_mutex);
        auto it = _space_status.emplace(space_id, SpaceStatus(kSpaceStatusUnknown, kSpaceEncryptStatusUnknown, lsn));
        if (it.second) {
            ++_space_status_size;
            stat_space_status_count << 1;
        } else {
            it.first->second.safe_trim_lsn = lsn;
        }
        return true;
    }
    return false;
}

gaia_apply::lsn_t SpaceStatusManager::GetSafeTrimLsn(gaia_apply::space_id_t space_id) const {
    std::shared_lock slk(_shared_mutex);
    auto it = _space_status.find(space_id);
    if (it != _space_status.end()) {
        return it->second.safe_trim_lsn;
    }
    return 0;
}

int32_t SpaceStatusManager::ClearUseLessSpaceStatus() {
    std::unique_lock lk(_shared_mutex);
    int32_t drop_num = 0;
    const int64_t cur_time = base::cpuwide_time_ms();
    auto it = _space_status.begin();
    while (it != _space_status.end() && drop_num <= 128) {
        const auto& st = it->second;
        if (space_status_with_psm(st.status)
                && st.time + FLAGS_psvr_clear_space_status_interval_ms < cur_time) {
            it = _space_status.erase(it);
            ++drop_num;
        } else if (space_status_is_deleted(st.status)
                && st.time + FLAGS_psvr_clear_space_status_interval_ms < cur_time) {
            it = _space_status.erase(it);
            ++drop_num;
        } else {
            ++it;
        }
    }
    _space_status_size -= drop_num;
    stat_space_status_count << -drop_num;
    return drop_num;
}

void ExtentMetaManager::Set(gaia_apply::space_id_t space_id,
        uint32_t logic_extent_id, uint32_t physical_extent_id) {
    std::unique_lock lk(_shared_mutex);
    return SetNoLock(space_id, logic_extent_id, physical_extent_id);
}

bool ExtentMetaManager::Get(gaia_apply::space_id_t space_id,
        uint32_t logic_extent_id, uint32_t* physical_extent_id) const {
    std::shared_lock slk(_shared_mutex);
    return GetNoLock(space_id, logic_extent_id, physical_extent_id);
}

#define fold_space(space, extent_or_page) u32tou64(space, extent_or_page)
/* set extent logic link physical,
 * and set extent physical link logic */
void ExtentMetaManager::SetNoLock(gaia_apply::space_id_t space_id,
        uint32_t logic_extent_id, uint32_t physical_extent_id) {
    const auto fold = fold_space(space_id, logic_extent_id);
    _space_extent_to_physical_extent[space_id][logic_extent_id] = physical_extent_id;
    _physical_extent_to_space_extent[physical_extent_id] = std::make_pair(fold, true);
}

bool ExtentMetaManager::GetNoLock(gaia_apply::space_id_t space_id,
        uint32_t logic_extent_id, uint32_t* physical_extent_id) const {
    if (auto it = _space_extent_to_physical_extent.find(space_id);
            it != _space_extent_to_physical_extent.end()) {
        if (auto it2 = it->second.find(logic_extent_id);
                it2 != it->second.end()) {
            if (physical_extent_id) {
                *physical_extent_id = it2->second;
            }
            return true;
        }
    }
    return false;
}

/* clean the space logic to physical extent links,
 * and clean physical to logic extent links */
bool ExtentMetaManager::CleanSpaceExtent(gaia_apply::space_id_t space_id) {
    std::unique_lock lk(_shared_mutex);
    if (_space_extent_to_physical_extent.count(space_id) > 0) {
        for (auto& it : _space_extent_to_physical_extent[space_id]) {
            _physical_extent_to_space_extent.erase(it.second);
        }
    }
    return _space_extent_to_physical_extent.erase(space_id) > 0;
}

bool ExtentMetaManager::SetPhysicalExtent(uint32_t physical_extent_id,
        gaia_apply::space_id_t space_id, uint32_t logic_extent_id) {
    std::unique_lock lk(_shared_mutex);
    return SetPhysicalExtentNoLock(physical_extent_id, space_id, logic_extent_id);
}

/* Only to set mismatch segment id or not allocate extent.
 * if logic extent in cache, then physical extent it must exists. */
bool ExtentMetaManager::SetPhysicalExtentNoLock(uint32_t physical_extent_id,
        gaia_apply::space_id_t space_id, uint32_t logic_extent_id) {
    const auto fold = fold_space(space_id, logic_extent_id);
    if (!GetNoLock(space_id, logic_extent_id, nullptr)) {
        _physical_extent_to_space_extent[physical_extent_id] = std::make_pair(fold, false);
        return true;
    }
    return false;
}

bool ExtentMetaManager::ExistPhysicalExtentNoLock(uint32_t physical_extent_id) const {
    auto it = _physical_extent_to_space_extent.find(physical_extent_id);
    return it != _physical_extent_to_space_extent.end();
}

bool ExtentMetaManager::GetPhysicalExtent(uint32_t physical_extent_id,
        gaia_apply::space_id_t* space_id, uint32_t* logic_extent_id, bool* match) const {
    std::shared_lock slk(_shared_mutex);
    return GetPhysicalExtentNoLock(physical_extent_id, space_id, logic_extent_id, match);
}

bool ExtentMetaManager::GetPhysicalExtentNoLock(uint32_t physical_extent_id,
        gaia_apply::space_id_t* space_id, uint32_t* logic_extent_id, bool* match) const {
    if (auto it = _physical_extent_to_space_extent.find(physical_extent_id);
            it != _physical_extent_to_space_extent.end()) {
        const auto fold = it->second.first;
        unfold_u64(fold, space_id, logic_extent_id);
        *match = it->second.second;
        return true;
    }
    return false;
}

SpacePageManager::SpacePageManager() {
    _slice_res_page_manager.reserve(FLAGS_psvr_space_page_slice_count);
    for (int32_t i = 0; i < FLAGS_psvr_space_page_slice_count; ++i) {
        _slice_res_page_manager.emplace_back(std::make_shared<PageManager>(stat_page_count));
    }
}

PagePtr SpacePageManager::GetPage(gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no, bool create_if_not_exists) {
    const auto fold = fold_space(space_id, page_no);
    const auto slice_idx = fold % FLAGS_psvr_space_page_slice_count;
    if (create_if_not_exists) {
        return _slice_res_page_manager[slice_idx]->GetOrCreate(fold, page_no, space_id);
    } else {
        return _slice_res_page_manager[slice_idx]->Get(fold);
    }
}

PagePtr SpacePageManager::GetOrCreatePage(gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no) {
    return GetPage(space_id, page_no, true);
}

#undef fold_space

}   // end of ns
