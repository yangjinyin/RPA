/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_compute_node_manager.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/update_compute_node_manager.h"

namespace psvr {
namespace gaia {

int UpdateComputeNodeManager::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    RpcStatus status;
    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    computenode::modify_manager_request request;
    computenode::modify_manager_response response;
    request.set_manager_address(_manager_address);

    if (!_force) {
        bool cf_ret = execute_confirm("Update compute node[%s:%d] manager?", _address.c_str(), _port);
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    _client.Call(_log_id++, node, &computenode::StatusQueryService_Stub::modify_manager, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(1);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int UpdateComputeNodeManager::Format(const computenode::modify_manager_response& rsp) {
    SHOW_CMP_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
