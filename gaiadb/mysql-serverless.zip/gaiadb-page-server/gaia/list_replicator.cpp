/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_replicator.cpp * @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_replicator.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ListReplicator::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (_addr.empty()) {
        gaiapb::ListReplicatorRequest request;
        gaiapb::ListReplicatorResponse response;

        request.set_log_id(_log_id);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_replicator, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                return Output(response);
            } else {
                LOG(WARNING) << node << " list replicator failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("list failed, all nodes failed");
        return Output(response);
    } else {
        gaiapb::GetReplicatorRequest request;
        gaiapb::GetReplicatorResponse response;

        request.set_log_id(_log_id);
        request.set_addr(_addr);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_replicator, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                return Output(response);
            } else {
                LOG(WARNING) << node << " list replicator failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("list failed, all nodes failed");
        return Output(response);
    }
}

int ListReplicator::Format(const gaiapb::GetReplicatorResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.status().code() == gaiadb::GIE_OK) {
        Table table(_raw_with_table, 2);
        table.AddRowsValue({"token:", rsp.token()});
        table.AddRowsValue({"epoch:", rsp.epoch()});
        table.AddRowsValue({"write_lsn:", rsp.write_lsn()});
        table.AddRowsValue({"apply_lsn:", rsp.apply_lsn()});
        table.AddRowsValue({"trx_id:", rsp.trx_id()});
        table.AddRowsValue({"state:", gaiadb::NodeState_Name(rsp.state())});
        table.AddRowsValue({"replication_apply_lsn:", rsp.replication_apply_lsn()});
        table.AddRowsValue({"replication_write_lsn:", rsp.replication_write_lsn()});
        table.AddRowsValue({"replication_trx_id:", rsp.replication_trx_id()});
        table.AddRowsValue({"cn_lowest_lsn:", rsp.cn_lowest_lsn()});
        table.AddRowsValue({"ps_lowest_lsn:", rsp.ps_lowest_lsn()});
        table.Display();
    }
    return 0;
}

int ListReplicator::Format(const gaiapb::ListReplicatorResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    {
        Table table(_raw_with_table, 2);
        table.AddRowsValue({"replication_apply_lsn", rsp.replication_apply_lsn()});
        table.AddRowsValue({"replication_write_lsn", rsp.replication_write_lsn()});
        table.AddRowsValue({"replication_trx_id", rsp.replication_trx_id()});
        table.AddRowsValue({"replication_recovery_is_finish", rsp.recovery_is_finish() ? "yes" : "no"});
        table.AddRowsValue({"replication_latest_pit", rsp.latest_pit()});
        table.Display();
    }
    if (rsp.replicators_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({"node", "epoch", "token", "apply_lsn", "write_lsn", "trx_id", "state", "zone"}, true);
        for (auto& pb : rsp.replicators()) {
            table.AddRowsValue({
                    pb.addr(),
                    pb.epoch(),
                    pb.token(),
                    pb.apply_lsn(),
                    pb.write_lsn(),
                    pb.trx_id(),
                    gaiadb::NodeState_Name(pb.state()),
                    GetZoneStr(pb)
                    });
        }
        table.Display();
    }
    return 0;
}

}
}
