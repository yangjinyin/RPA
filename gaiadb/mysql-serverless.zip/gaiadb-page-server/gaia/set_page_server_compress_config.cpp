/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_page_server_compress_config.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/set_page_server_compress_config.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int SetPageServerCompressConfig::Run() {
    RpcStatus status;
    pspb::SetCompressConfigRequest request;
    pspb::SetCompressConfigResponse response;

    if (_address.empty() || _port < 1) {
        print_error("miss --cluster-addr or (--address and --port)");
        return 1;
    }

    if (_cluster_id.empty()) {
        print_error("miss --cluster-id");
        return 1;
    }

    if (!_enable.has_val) {
        print_error("miss --cfg-enable");
        return 1;
    }

    if (_enable.val && _type.empty()) {
        print_error("miss --cfg-type");
        return 1;
    }

    request.set_log_id(_log_id);
    request.set_cluster_id(_cluster_id);
    if (_segment_id.has_val) {
        request.set_segment_id(_segment_id.val);
    }
    request.mutable_compress_cfg()->set_enable(_enable.val);
    request.mutable_compress_cfg()->set_type(_type);
    request.mutable_compress_cfg()->set_level(_level);

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("%s compression ?", _enable.val ? "Enable" : "Disable");
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    _client.Call(_log_id, node, &pspb::ManagerService_Stub::SetCompressConfig, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int SetPageServerCompressConfig::Format(const pspb::SetCompressConfigResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"succ_count:", rsp.succ_cnt()});
    table.Display();
    return 0;
}

}
}
