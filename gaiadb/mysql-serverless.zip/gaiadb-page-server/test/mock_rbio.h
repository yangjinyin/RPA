/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_rbio.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/rbio_context.h"
#include "test/test_util.h"

namespace psvr {
namespace test {

class MockRbioManager : public RbioManager {
public:
    MockRbioManager(ClientPtr client, ControlWeakPtr control) : RbioManager(client, control) {}
    virtual ~MockRbioManager() {}

    void MockDispatchRbio(SegmentPtr, ggpb::RpcController*, const page_server::RbioRequest*,
            page_server::RbioResponse* response, google::protobuf::Closure* closure, int64_t) {
        response->set_errcode(pspb::RbioResponse_Error_RBIO_SUCCESS);
        if (closure) {
            closure->Run();
        }
    }

    void MockDispatchWrite(SegmentPtr, page_server::WritePageRequest*,
            page_server::WritePageResponse* response, google::protobuf::Closure* closure, int64_t) {
        response->mutable_status()->set_code(pspb::WritePageResponse_Error_SUCCESS);
        if (closure) {
            closure->Run();
        }
    }

    MOCK_METHOD1(Start, bool(uint32_t));
    MOCK_METHOD6(Dispatch, void(SegmentPtr, ggpb::RpcController*, const page_server::RbioRequest*,
                page_server::RbioResponse*, google::protobuf::Closure*, int64_t));
    MOCK_METHOD5(Dispatch, void(SegmentPtr, const page_server::WritePageRequest*,
                page_server::WritePageResponse*, google::protobuf::Closure*, int64_t));
    MOCK_METHOD1(Execute, bool(RbioManager::Context*));
};

}
}
