#!/bin/bash


bcloud local --update --set-bcloud-macro="WITH_POLAR" --no-release.bcloud
