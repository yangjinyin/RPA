#include "bir0async_binlog.h"
#include <ctype.h>
#include <base/base64.h>
#include <openssl/hmac.h>
#include <baidu/rpc/uri.h>
#include <baidu/rpc/details/http_message.h>
#include <openssl/aes.h>
#include "gaiadb/common/global_flags.h"
#include "rpl0rpl.h"
#include "rpl0parse.h"
#include "gaiadb/redo_fetch/fetch_mdc_object.h"
#include "gaiadb/redo_fetch/fetch_mdc_utils.h"

namespace bir {

lsn_t BirAsyncBinlog::copy_fetch_buf(bool move) {
  if (copy_lsn_ >= fetch_lsn_) {
    return 0;
  }

  if (move && parse_data_pos_ > 0) {
    ut_a(parse_data_len_ >= parse_data_pos_);
    std::memmove(parse_log_buf_, parse_log_buf_ + parse_data_pos_,
        parse_data_len_ - parse_data_pos_);
    parse_data_len_ -= parse_data_pos_;
    parse_data_pos_ = 0;
  }
  std::unique_lock lk(log_buf_mutex());

  byte *log_buf_end = log_buf() + log_buf_size();

  sn_t start_sn = log_translate_lsn_to_sn(copy_lsn_);
  sn_t fetch_sn = log_translate_lsn_to_sn(fetch_lsn_);

  auto copy_size = fetch_sn - start_sn;
  auto remain_size = parse_log_buf_size_ - parse_data_len_;
  if (copy_size > remain_size) {
    copy_size = remain_size;
  }

  byte *ptr = log_buf() + (start_sn % log_buf_size());
  byte *end_ptr = ptr + copy_size;

  if (end_ptr <= log_buf_end) {
    std::memcpy(parse_log_buf_ + parse_data_len_, ptr, copy_size);
  } else {
    auto part_size = log_buf_end - ptr;
    std::memcpy(parse_log_buf_ + parse_data_len_, ptr, part_size);
    std::memcpy(
      parse_log_buf_ + parse_data_len_ + part_size,
      log_buf(), copy_size - part_size);
  }
  parse_data_len_ += copy_size;

  copy_lsn_ = recv_calc_lsn_on_data_add(copy_lsn_, copy_size);
  LOG(TRACE) << "copy buf size:" << copy_size
    << ", fetch_lsn_:" << fetch_lsn_ << ", copy_lsn_:" << copy_lsn_;
  return copy_size;
}

bool BirAsyncBinlog::parse_log() {
  uint64_t expect_parse_len = (8<<20);
  sn_t fetch_sn = log_translate_lsn_to_sn(fetch_lsn_);
  sn_t start_sn = log_translate_lsn_to_sn(parse_lsn_);

  copy_fetch_buf(true);

  byte *ptr = parse_log_buf_ + parse_data_pos_;
  byte *buf_end = parse_log_buf_ + parse_data_len_;

  if (fetch_sn - start_sn < expect_parse_len) {
    expect_parse_len = fetch_sn - start_sn;
  }
  byte *end_ptr = ptr + expect_parse_len;
  if (end_ptr > buf_end) {
    end_ptr = buf_end;
  }

  auto record_start_lsn = parse_lsn_;
  auto cur_ptr = ptr;
  for (; cur_ptr <= end_ptr; ) {
    mlog_id_t type;
    page_no_t page_no;
    space_id_t space_id;
    byte *body;
    uint32_t check_bits_len = 0;
    uint64_t len = rpl::parse_one_log_rec(cur_ptr, end_ptr, &type, &space_id,
        &page_no, &body, &check_bits_len);
    if (len == 0) {
      if (static_cast<ulong>(end_ptr - ptr) >= parse_log_buf_size_ - 0x8000) {
        limit_by_parse_buffer_ = true;
        LOG_EVERY_SECOND(WARNING) 
          << "parse recod error, limit by parse buf size, parsed_len:" <<  len
          << " buf_size:" << parse_log_buf_size_;
      }
      break;
    }
    switch (type) {
      case MLOG_GAIA_BINLOG_DATA: {
        uint32_t index_num;
        uint64_t pos;
        innodb::binlog_redo_op_t binlog_redo_op_type;
        uint64_t body_len;
        uint32_t check_bits_len;
        byte *body_ptr = mlog_parse_initial_binlog_log_record(
            cur_ptr, end_ptr, &type, &binlog_redo_op_type, 
            &index_num, &pos, &body_len,
            &check_bits_len);
        ut_a(body_ptr);
        mutex_enter(binlog_mutex());
        binlog_recover()->apply(binlog_redo_op_type, index_num, pos, body_ptr,
            body_len, check_bits_len);
        mutex_exit(binlog_mutex());
        break;
      }
      default:
        break;
    }

    // check record start lsn
    lsn_t real_rec_start_lsn = 0;
    switch (check_bits_len) {
    case 0:
      /* don't has check bits */
      break;
    case (innodb::RECORD_CHECK_BITS_LEN + innodb::PAGE_CHECK_BITS_LEN):
      [[fallthrough]];
    case innodb::RECORD_CHECK_BITS_LEN:
      real_rec_start_lsn = mach_read_from_8(cur_ptr + len - check_bits_len);
      break;
    default:
      LOG(ERROR) << "invalid check bits len: " << check_bits_len;
      ut_error;
    }

    if (real_rec_start_lsn != 0 && real_rec_start_lsn != record_start_lsn) {
      LOG(ERROR) << "record start lsn mismatch"
                 << ", real_rec_start_lsn: " << real_rec_start_lsn
                 << ", record_start_lsn: " << record_start_lsn;
      ut_error;
    }
    record_start_lsn = recv_calc_lsn_on_data_add(record_start_lsn, len);

    cur_ptr += len;
  }
  size_t total_len = cur_ptr - ptr;
  ut_a(total_len <= parse_data_len_ - parse_data_pos_);
  parse_data_pos_ += total_len;
  parse_lsn_ = recv_calc_lsn_on_data_add(parse_lsn_, total_len);
  return total_len > 0;
}

void BirAsyncBinlog::resize_buf() {
  const auto cur_size = parse_log_buf_size_;
  byte *tmp_buf = ut::new_arr_withkey<byte>(UT_NEW_THIS_FILE_PSI_KEY,
      ut::Count(parse_log_buf_size_));
  std::memcpy(tmp_buf, parse_log_buf_, parse_log_buf_size_);
  parse_log_buf_.dealloc();

  parse_log_buf_size_ = log_translate_sn_to_lsn(
      static_cast<sn_t>(1.382 * parse_log_buf_size_ + OS_FILE_LOG_BLOCK_SIZE));
  parse_log_buf_size_ = ut_uint64_align_up(
      parse_log_buf_size_, OS_FILE_LOG_BLOCK_SIZE);

  parse_log_buf_.alloc_withkey(
      UT_NEW_THIS_FILE_PSI_KEY, ut::Count{parse_log_buf_size_});
  std::memcpy(parse_log_buf_, tmp_buf, cur_size);

  ut::delete_arr(tmp_buf);
  LOG(NOTICE) << "resize rpl parser buf size to " << parse_log_buf_size_;
}

void BirAsyncBinlog::parse_routine() {
  while (!is_stop()) {

    lsn_t start_lsn = parse_lsn_;
    if (fetch_lsn_ <= start_lsn) {
      std::this_thread::sleep_for(std::chrono::microseconds(1000));
      continue;
    }

    LOG(TRACE) << "parse start_lsn: " << start_lsn
               << ", fetch_lsn_: " << fetch_lsn_;

    lsn_t batch_start_lsn = parse_lsn_;
    auto batch_finished = false;

    do {
      {
        batch_finished = parse_log();
        LOG(TRACE) << "parse, finished: " << batch_finished 
                   << ", limit_by_parse_buffer_: " << limit_by_parse_buffer_;
        if (limit_by_parse_buffer_) {
          ut_a(batch_finished);
          /** a lager mtr, its size exceeds buf max size */
          resize_buf();
          copy_fetch_buf(false);
          limit_by_parse_buffer_ = false;
          continue;
        }
      }

      if (!batch_finished) {
        copy_fetch_buf(false);
      }

    } while (!is_stop() && !batch_finished);
    
    lsn_t batch_end_lsn = parse_lsn_;
    if (parse_lsn_ > apply_lsn_ && !srv_gaia_binlog_in_redo_log_for_primary) {
      if (!srv_thread_is_active(srv_threads.m_stop_async_binlog)) {
        srv_threads.m_stop_async_binlog =
            os_thread_create(bir_stop_async_binlog_thread_key, 0, stop_async_binlog);
        srv_threads.m_stop_async_binlog.start();
      }
    }
    LOG(TRACE) << "parse batch start_lsn: " << batch_start_lsn
               << ", end_lsn: " << batch_end_lsn;
    if (batch_end_lsn == batch_start_lsn) {
      std::this_thread::sleep_for(std::chrono::microseconds(1000));
      continue;
    }
  }
}

void stop_async_binlog() {
  stop_binlog_async_background_thread();
}

}
