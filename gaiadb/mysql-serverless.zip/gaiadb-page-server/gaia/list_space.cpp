/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_space.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_space.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ListSpace::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_specify_space_id){
        gaiapb::EmptyMessage request;
        gaiapb::GetAllSpaceIdsResponse response;
        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_all_space_ids, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                return Output(response);
            } else {
                LOG(WARNING) << node << " list space failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("list failed, all nodes failed");
        return Output(response);
    } else {
        gaiapb::GetSpaceMetaRequest request;
        gaiapb::GetSpaceMetaResponse response;
        request.set_space_id(_space_id);
        request.set_need_encryption_info(false);
        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_space_meta, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                return Output(response);
            } else {
                LOG(WARNING) << node << " get space failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("get failed, all nodes failed");
        return Output(response);
    }
}

int ListSpace::Format(const gaiapb::GetSpaceMetaResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.status().code() == gaiadb::GIE_OK) {
        const auto& space_meta = rsp.space_meta();
        printf("%-15s %s\n", "is_compressed:", space_meta.is_compressed() ? "yes" : "no");
        printf("%-15s %s\n", "is_encrypted:", space_meta.is_encrypted() ? "yes" : "no");
        printf("%-15s %u\n", "logical_page_size:", space_meta.logical_page_size());
        printf("%-15s %u\n", "physical_page_size:", space_meta.physical_page_size());
    }
    return 0;
}

int ListSpace::Format(const gaiapb::GetAllSpaceIdsResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.space_ids_size()) {
        printf("%s %d\n", "count:", rsp.space_ids_size());
        printf("%s\n", "id");
        for (auto& id : rsp.space_ids()) {
            printf("%u\n", id);
        }
    }
    if (rsp.encrypt_space_ids_size()) {
        printf("%s %d\n", "encrypt count:", rsp.encrypt_space_ids_size());
        printf("%s\n", "id");
        for (auto& id : rsp.encrypt_space_ids()) {
            printf("%u\n", id);
        }
    }
    return 0;
}

}
}
