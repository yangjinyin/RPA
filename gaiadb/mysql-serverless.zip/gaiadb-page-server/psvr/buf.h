/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/buf.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <map>
#include <memory>
#include <psvr0page.h>
#include <gaiadb/utils/queue.hpp>
#include "psvr/common.h"
#include "psvr/utils.h"

namespace psvr {

#ifdef _UNIT_TEST
struct debug_buf_block_t : public gaia_apply::buf_block_t {
    bool flag_used;
};
using psvr_buf_block_t = debug_buf_block_t;
#else
using psvr_buf_block_t = gaia_apply::buf_block_t;
#endif
// 16KB buf
using BufBlockPtr = std::shared_ptr<psvr_buf_block_t>;

class BufPool;
using BufPoolPtr = std::shared_ptr<BufPool>;

bvar::Vector<uint32_t, 2> get_buf_blocks_info(void* arg);

class BufPool {
friend bvar::Vector<uint32_t, 2> get_buf_blocks_info(void* arg);
public:
    BufPool();
    FUNC_MOCK ~BufPool();

    FUNC_MOCK bool Init(bool multi_type = false);

    FUNC_MOCK BufBlockPtr AllocBufBlock(gaia_apply::ulint block_size, gaia_apply::byte* frame = nullptr);
    FUNC_MOCK BufBlockPtr GetOrAllocBufBlock(gaia_apply::ulint block_size);

private:
    void Expose();
    bool InitSlices(int64_t buf_size);

    uint32_t GetBufBlockFromPool(BufBlockPtr* buf_block);

private:
    gaiadb::common::RetRing<psvr_buf_block_t*> _slices;
    uint64_t _slice_size {0};
    void* _buf {nullptr};
    uint32_t _slices_count {0};
    std::atomic<uint32_t> _used_buf_block_count {0};
    // Statistic
    bvar::PassiveStatus<bvar::Vector<uint32_t, 2>> _stat_buf_blocks;
};

}
