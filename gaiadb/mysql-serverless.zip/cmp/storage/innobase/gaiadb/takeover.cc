/***********************************************************************

Copyright (c) 2022, Baidu and/or its affiliates.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2.0,
as published by the Free Software Foundation.

This program is also distributed with certain software (including
but not limited to OpenSSL) that is licensed under separate terms,
as designated in a particular file or component or in included license
documentation.  The authors of MySQL hereby grant you an additional
permission to link the program and your derivative works with the
separately licensed software that they have included with MySQL.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License, version 2.0, for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

***********************************************************************/

/** @file gaiadb/takeover.cc
 The interface to the gaiadb storage

 Created 1/9/2024 LingJie Guo
 *******************************************************/

#include "takeover.h"
#include "sql/xa.h"
#include "sql/tc_log.h"
#include "sql/mysqld.h"
#include "ut0dbg.h"
#include "clone0clone.h"
#include "srv0start.h"
#include "rpl0rpl.h"
#include "dict0stats_bg.h"
#include "landing_zone_client.h"
#include "gaiadb.h"
#include "sql/dd/dictionary.h"
#include "trx0roll.h"
#include <sys/prctl.h>
#include "mysqld.h"
#include "bir0async_binlog.h"

namespace hotbackup {

bvar::IntRecorder stat_cost_time_us("takeover_cost_time_us");

Task task;
static std::atomic<Stage> srv_state = Stage::None;
static int64_t cost_time_us = 0;

Stage get_stage() {
  return srv_state.load(std::memory_order_acquire);
}

bool stage_is(Stage s) {
  return get_stage() == s;
}

void set_stage(Stage s) {
  srv_state.store(s, std::memory_order_release);
}

ScopedCoster::ScopedCoster(uint64_t *cost_, int64_t start)
  : cost(cost_), start_us(start) {
  if (start_us == 0) {
    start_us = my_micro_time();
  }
}

ScopedCoster::~ScopedCoster() {
  *cost = my_micro_time() - start_us;
}

static const char* stage2str(Stage s) {
  switch(s) {
  case Stage::None:
    return "None";
  case Stage::Failed:
    return "Failed";
  case Stage::Success:
    return "Success";
  case Stage::Prepare:
    return "Prepare";
  case Stage::WriteFence:
    return "WriteFence";
  case Stage::PurgeSysShutdown:
    return "PurgeSysShutdown";
  case Stage::LogSysRecv:
    return "LogSysRecv";
  case Stage::BinLogInRedoRecv:
    return "BinLogInRedoRecv";
  case Stage::TrxSysShutdown:
    return "TrxSysShutdown";
  case Stage::LogSysStart:
    return "LogSysStart";
  case Stage::TrxSysRecv:
    return "TrxSysRecv";
  case Stage::DictSysRecv:
    return "DictSysRecv";
  case Stage::BinLogRecv:
    return "BinLogRecv";
  case Stage::TrxRecoveryRollbackRecv:
    return "TrxRecoveryRollbackRecv";
  case Stage::RpcSysRecv:
    return "RpcSysRecv";
  case Stage::FixStatus:
    return "FixStatus";
  case Stage::FixSysTables:
    return "FixSysTables";
  case Stage::CompressGtid:
    return "CompressGtid";
  case Stage::BosInfo:
    return "BosInfo";
  case Stage::EndStep:
  default:
    return "EndStep";
  };
};


static dberr_t modify_process_command_and_unset_readonly(THD *thd) {
  auto expect_role = "PRIMARY";
  std::string role_str = "--rpl_role=";
  std::string super_read_only_str = "--super-read-only=ON";
  bool advance_next_argc = false;
  auto end_ptr = static_cast<const char *>(orig_argv[orig_argc - 1]) +
                 strlen(orig_argv[orig_argc - 1]);
  for(int i = 0; i < orig_argc; ++i) {
    if (0 == strncmp(orig_argv[i], super_read_only_str.c_str(),
                     super_read_only_str.size())) {
      if (i == orig_argc - 1) {
        memset(orig_argv[i], '\0', strlen(orig_argv[i]) + 1);
        orig_argc--;
        orig_argv[orig_argc - 1] = nullptr;
      } else {
        advance_next_argc = true;
        continue;
      }
    }

    // modify --rpl_role
    if (0 == strncmp(orig_argv[i], role_str.c_str(), role_str.size())) {
      std::string new_role = role_str + expect_role;
      memset(orig_argv[i], '\0', strlen(orig_argv[i]) + 1);
      memcpy(orig_argv[i], new_role.c_str(), new_role.size());
    }

    if (advance_next_argc) {
      memmove(orig_argv[i - 1], orig_argv[i], strlen(orig_argv[i]) + 1);
      if (i == orig_argc - 1) {
        orig_argc--;
        auto start_ptr = static_cast<char *>(orig_argv[i - 1]) +
                         strlen(orig_argv[i - 1]) + 1;
        memset(start_ptr, '\0', end_ptr - start_ptr + 1);
      } else {
        orig_argv[i] = orig_argv[i - 1] + strlen(orig_argv[i - 1]) + 1;
      }
    }
  }

  // set [super_]read_only to false
  update_readonly_in_takeover(thd, false);
  return DB_SUCCESS;
}

static void ddl_recover_in_takeover() {
  log_ddl->reset_tasks();
  auto err = log_ddl->recover();
  ut_a(err == DB_SUCCESS);
  LOG(NOTICE) << "[TakeOver] ddl recover success";
}

static dberr_t binlog_recover_in_takeover(THD *) {
  ut_a(srv_rpl_primary);
  { // deinit binlog
    if (tc_log) {
      tc_log->close();
      tc_log = nullptr;
    }

    Recovered_xa_transactions::destroy();
    LOG(NOTICE) << "[TakeOver] deinit binlog success";
  }

  tc_log = &tc_log_dummy;
  if (total_ha_2pc > 1 || (1 == total_ha_2pc && opt_bin_log)) {
    if (opt_bin_log) {
      tc_log = &mysql_bin_log;
    } else {
      tc_log = &tc_log_mmap;
    }
  }

  if (Recovered_xa_transactions::init()) {
    ut_error;
  }

  if (tc_log->open(opt_bin_log ? opt_bin_logname : opt_tc_log_file, true/*is_takeover*/)) {
    ut_error;
  }

  ddl_recover_in_takeover();

  if (Recovered_xa_transactions::instance()
          .recover_prepared_xa_transactions()) {
    ut_error;
  }

  if (opt_bin_log) {
    uint32_t new_index_id = 0;
    if (srv_gaia_binlog_in_redo_log_for_primary) {
      new_index_id = gaiadb_get_new_index_id();
    }

    assert(!mysql_bin_log.is_relay_log);
    mysql_mutex_t *log_lock = mysql_bin_log.get_log_lock();
    mysql_mutex_lock(log_lock);

    if (mysql_bin_log.open_binlog(opt_bin_logname, nullptr, max_binlog_size,
          false, true /*need_lock_index=true*/,
          true /*need_sid_lock=true*/, nullptr, new_index_id)) {
      mysql_mutex_unlock(log_lock);
      ut_error;
    } else {
      mysql_mutex_unlock(log_lock);
    }
  }

  if (srv_gaia_binlog_in_redo_log_for_primary) {
    bir::start_binlog_async_background_thread();
  }
  return DB_SUCCESS;
}

static dberr_t null_fn(THD *) {
  return DB_SUCCESS;
}

static dberr_t lift_logservice_epoch(THD *) {
  for (auto try_count = 0; try_count < 10; ++try_count) {
    auto ret = landing_zone::g_landing_zone_client.increase_epoch();
    if (ret == 0) {
      return DB_SUCCESS;
    }
    std::this_thread::sleep_for(srv_delay_send_request);
  }
  LOG(ERROR) << "[TakeOver] Log Service: increase epoch failed";
  return DB_INTERRUPTED;
}

static dberr_t flush_binlog_in_redo(THD *) {
  opt_bin_log = opt_secondary_bin_log;
  if (opt_bin_log) {
    if (binlog_in_redo_flusher_in_takevoer(srv_gaia_binlog_in_redo_log)) {
      return DB_ERROR;
    }
    if (srv_gaia_binlog_in_redo_log_for_primary) {
      gaiadb_get_block_write_switch(&srv_gaia_block_write_switch);
    }
  }
  return DB_SUCCESS;
}

typedef dberr_t (* stage_fn)(THD *);

struct StageFn {
  Stage name;
  stage_fn fn;
  int64_t start_us;

  StageFn(Stage n, stage_fn f)
    : StageFn(n, f, 0) {}
  StageFn(Stage n, stage_fn f, int64_t s)
    : name(n), fn(f), start_us(s) {}

  dberr_t operator()(THD *thd) {
    ScopedCoster sct(&task.stages_cost[name], start_us);
    set_stage(name);
    return fn(thd);
  }
};

void do_takeover_primary() {
  pthread_setname_np(pthread_self(), "takeover");
  // init thd object for mdl lock
  THD *thd = create_thd(false, true, true, 0, 0);
  dberr_t err = DB_ERROR;

  LOG(NOTICE) << "[TakeOver] start takeover primary";

  std::shared_ptr<void> defer_op(nullptr, [&err, &thd](...) {
    std::lock_guard<std::mutex> guard_lck(task.lock);
    destroy_thd(thd);
    task.end_time = my_micro_time();
    task.finish(err == DB_SUCCESS);
  });

  if (srv_rpl_primary) {
    err = DB_SUCCESS;
    return;
  }

  std::vector<StageFn> takeover_stages;
  takeover_stages.push_back(StageFn(Stage::Prepare, null_fn, task.start_time));
  takeover_stages.push_back(StageFn(Stage::WriteFence, lift_logservice_epoch));
  takeover_stages.push_back(StageFn(Stage::PurgeSysShutdown, purge_sys_shutdown_in_takeover));
  takeover_stages.push_back(StageFn(Stage::LogSysRecv, log_sys_recover_in_takeover));
  takeover_stages.push_back(StageFn(Stage::BinLogInRedoRecv, flush_binlog_in_redo));
  takeover_stages.push_back(StageFn(Stage::TrxSysShutdown, trx_sys_shutdown_in_takeover));
  takeover_stages.push_back(StageFn(Stage::LogSysStart, log_sys_start_in_takeover));
  takeover_stages.push_back(StageFn(Stage::TrxSysRecv, trx_sys_recover_in_takeover));
  takeover_stages.push_back(StageFn(Stage::DictSysRecv, dict_sys_recover_in_takeover));
  takeover_stages.push_back(StageFn(Stage::BinLogRecv, binlog_recover_in_takeover));
  takeover_stages.push_back(StageFn(Stage::TrxRecoveryRollbackRecv, trx_recovery_rollback_in_takeover));
  takeover_stages.push_back(StageFn(Stage::RpcSysRecv, rpc_sys_recover_in_takeover));
  takeover_stages.push_back(StageFn(Stage::FixStatus, modify_process_command_and_unset_readonly));
  takeover_stages.push_back(StageFn(Stage::FixSysTables, fix_sys_tables_in_takeover));
  takeover_stages.push_back(StageFn(Stage::BosInfo, update_bos_info_to_psm_in_takeover));
  takeover_stages.push_back(StageFn(Stage::CompressGtid, create_compress_gtid_thread_in_takeover));

  for (auto &stage_fn : takeover_stages) {
    err = stage_fn(thd);
    if (err != DB_SUCCESS) {
      task.fail_stage = stage_fn.name;
      task.fail_ret = err;
      set_stage(Stage::Failed);
      return;
    }
  }

  ut_a(err == DB_SUCCESS);
  allow_new_connections_in_takevoer();
  set_stage(Stage::Success);
}

void takeover_primary_async() {
  srv_threads.m_takeover_handler =
    os_thread_create(handle_takeover_thread_key, 0, do_takeover_primary);
  srv_threads.m_takeover_handler.start();
}

void Task::reset(const std::string& id, uint64_t start) {
  task_id = id;
  start_time = start;
  end_time = 0;
  stages_cost.clear();
}

void Task::finish(bool success) {
  std::stringstream ss;
  for (auto it : stages_cost) {
    ss << ", " <<  stage2str(it.first) << ":" << it.second << "us";
  }

  cost_time_us = (end_time - start_time);
  if (success) {
    ib_system() << "[TakeOver] task_id:" << task_id
      << ", task_status:success"
      << ", total_cost:" << cost_time_us << "us"
      << ss.str();
  } else {
    ib_error() << "[TakeOver] task_id:" << task_id
      << ", task_status:failed"
      << ", fail_stage:" << stage2str(fail_stage)
      << ", fail_err:" << fail_ret
      << ", total_cost:" << cost_time_us << "us"
      << ss.str();
  }
  stat_cost_time_us << cost_time_us;
}

} // namespace hotbackup
