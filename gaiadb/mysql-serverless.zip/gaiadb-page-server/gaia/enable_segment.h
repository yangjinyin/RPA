/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/enable_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class EnableSegment : public Command {
public:
    EnableSegment() {
        SetName("enable-segment");
        SetDesc("set segment status to enable (allow to alloc extent) to manager");
        SetDescCn("启用管理服务中的分片 (允许分片开始分配存储区)");

        AddPsmClusterOption();
        AddRequiredArgOption("segment-id", NULL, 's', "the segment id", kuint32_t);

        AddExample("--manager-address \"bns://xxx\" --segment-id xx");
    }
    virtual ~EnableSegment() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 's':
            _segment_id = std::strtoul(opt, NULL, 10);
            break;
        case 0:
            switch (_long_opt_val) {
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::AckResponse& rsp);

private:
    std::string _manager_address {};
    uint32_t _segment_id {0};
};

}
}
