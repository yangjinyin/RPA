#include "formula_client.h"
#include "bvar/bvar.h"
#include "db0err.h"
#include "gaiadb/utils/rpc_client.hpp"
#include "gaiadb.h"

DEFINE_int64(formula_query_timeout_ms, 20 * 1000, "formula query timeout");
BAIDU_RPC_VALIDATE_GFLAG(formula_query_timeout_ms, baidu::rpc::PositiveInteger);

static bvar::LatencyRecorder formula_query_total(
    "gaia_cmp_formula_query_total");
static bvar::LatencyRecorder formula_query_real("gaia_cmp_formula_query_real");
static bvar::LatencyRecorder formula_query_rpc("gaia_cmp_formula_query_rpc");

namespace formula {

ResultReceiver *ResultReceiver::make(std::shared_ptr<QueryContext> &ctx) {
  return new ResultReceiver(ctx->results, ctx->is_eos, ctx->is_err);
}

int ResultReceiver::on_received_messages(StreamId id,
                                         base::IOBuf *const messages[],
                                         size_t size) {
  for (size_t i = 0; i < size; ++i) {
    StreamResultSet res;
    res.ParseFromString(messages[i]->to_string());

    auto err = res.status().code();
    if (err != ::formula_pb::Ok) {
      LOG(ERROR) << "met error when receiving messages, errcode=" << err
                 << ", errmsg=" << res.status().msg()
                 << ", id=" << id;
      err_.store(true);
      return brpc::StreamClose(id);
    }

    if (!res.has_result_set()) {
      // end of source
      eos_.store(true);
      return brpc::StreamClose(id);
    }

    sink_.push_back(
        std::shared_ptr<::ResultSet>(res.release_result_set()));
  }
  return 0;
}

void ResultReceiver::on_idle_timeout(StreamId id) {
  LOG(WARNING) << "closing stream on idle timeout, id=" << id;

  err_.store(true);
  brpc::StreamClose(id);
}

void ResultReceiver::on_closed(StreamId id) {
  LOG(NOTICE) << "stream is closed, id=" << id;

  // FIXME(yl): a temporary solution to avoid bug of stream rpc
  delete this;
}

bool FormulaClient::init(gaiadb::psm_client::Psmgr_client *psm_client) {
  psm_client_ = psm_client;
  return true;
}

int FormulaClient::get_column_stores(
    uint32_t space_id, uint64_t index_id,
    std::vector<gaiadb::common::PeerZone> &column_stores, bool force_sync) {
  uint32_t group_id = std::numeric_limits<uint32_t>::max();
  if (!psm_client_->get_group_id_by_space_index(space_id, index_id, group_id)) {
    LOG(ERROR) << "get_group_id_by_space_index failed, space: " << space_id
               << " index: " << index_id;
    ut_error;
  }
  bool sync_mode = force_sync ? true : false;
  int ret = 0;
  const uint32_t zone_version = psm_client_->zone_version();
  if (last_zone_version_ != zone_version) {
    last_zone_version_ = zone_version;
    sync_mode = true;
  }
  do {
    column_stores.clear();
    ret = psm_client_->get_columnar_group_replicas(group_id, &column_stores,
                                                   sync_mode);
    if (ret == 0 && column_stores.size() > 0) {
      std::random_shuffle(column_stores.begin(), column_stores.end(),
                          base::fast_rand_less_than);
      if (psm_client_->has_zone()) {
        std::string region;
        std::string available_zone;
        if (psm_client_->get_zone(&region, &available_zone) &&
            !region.empty() && !available_zone.empty()) {
          gaiadb::common::sort_peer_zone_vector(column_stores, region,
                                                available_zone);
        }
      }
      break;
    }

    if (sync_mode && ret == gaiadb::GIE_NOT_EXIST) {
      ut_a(false);  // unexpected error
    }

    LOG_IF_EVERY_N(WARNING, sync_mode && (ret != 0 || column_stores.size() == 0), 100)
        << "get_column_stores failed, ret: " << ret;

    sync_mode = true;
    std::this_thread::sleep_for(srv_delay_send_request);
  } while (ret != 0 || column_stores.size() == 0);

  return DB_SUCCESS;
}

void FormulaClient::do_query(QueryContextPtr ctx) {
  //auto &peer = ctx->server_addr;
  auto *closure = brpc::NewCallback(this, &FormulaClient::on_query, ctx);
  query_client_.Call(ctx->cntl, ctx->server_addr,
                     &formula_pb::QueryService_Stub::query, ctx->request,
                     ctx->response, closure);
}

void FormulaClient::on_query(QueryContextPtr context) {
  std::shared_ptr<void> guard(
      nullptr, [&context](...) { context->is_done.store(true); });

  //uint64_t begin_time = base::monotonic_time_us();
  base::EndPoint remote_server = context->server_addr.addr;

  do {
    if (context->cntl->Failed()) {
      context->err_code = context->cntl->ErrorCode();
      context->err_msg = context->cntl->ErrorText();
      LOG_IF(WARNING, !context->canceled.load())
          << "[log_id: " << context->log_id
          << "] [msg: execute by formula failed, controller failed"
          << "] [column store: " << remote_server
          << "] [errno: " << context->cntl->ErrorCode()
          << "] [emsg: " << context->cntl->ErrorText() << "]";
      break;
    }
    auto response = context->response;

    if (response->status().code() != formula_pb::Ok) {
      context->err_code = response->status().code();
      context->err_msg = response->status().msg();
      LOG(WARNING) << "[log_id: " << context->log_id
                   << "] [msg: execute by formula failed"
                   << "] [column store: " << remote_server << "] [error_no: "
                   << formula_pb::Errno_Name(static_cast<formula_pb::Errno>(
                          response->status().code()))
                   << "] [emsg: " << response->status().msg()
                   << "] [LSN: " << context->vlsn << "]";
      break;
    }

    // on success
    context->err_code = 0;
    context->err_msg.clear();
  } while (0);

  // bvar
  uint64_t now = base::monotonic_time_us();
  formula_query_real << now - context->real_start_us;
  formula_query_rpc << context->cntl->latency_us();
  formula_query_total << now - context->start_us;

  LOG(TRACE) << "Formula sync_mode=sync"
             << " on session=" << context->request->session_id()
             << ", log_id: " << context->log_id
             << ", LSN:" << context->vlsn << ", column store:" << remote_server
             << ", rc:" << (context->err_code == 0 ? " success" : " failed");
}

int FormulaClient::query(QueryContextPtr ctx) {
  assert(ctx->request);
  ctx->retry_count = 0;
  ctx->start_us = base::monotonic_time_us();
  std::vector<gaiadb::common::PeerZone> column_stores;
  bool force_sync_replicas = false;
  uint32_t max_retry_count = 10;
  uint32_t local_retry_count = 0;
  do {
    auto err = get_column_stores(ctx->space_id, ctx->index_id, column_stores,
                                 force_sync_replicas);

    ut_a(err == DB_SUCCESS);
    if (force_sync_replicas) {
      force_sync_replicas = false;
    }
    baidu::rpc::Controller cntl;
    formula_pb::SelectQueryResponse response;
    ctx->response = &response;
    ctx->cntl = &cntl;
    for (size_t i = 0; i < column_stores.size(); ++i) {
      response.Clear();
      cntl.Reset();
      cntl.set_timeout_ms(FLAGS_formula_query_timeout_ms);
      cntl.set_max_retry(gaiadb::common::FLAGS_gaia_rpc_try_times);

      ctx->server_addr = column_stores[i];
      ctx->real_start_us = base::monotonic_time_us();
      ctx->is_done = false;
      ctx->results.clear();
      ctx->is_eos = false;
      ctx->is_err = false;
      const auto cid = cntl.call_id();

      auto receiver = ResultReceiver::make(ctx);

      brpc::StreamId stream;
      brpc::StreamOptions options;
      options.idle_timeout_ms = FLAGS_formula_query_timeout_ms;
      options.handler = receiver;
      if (brpc::StreamCreate(&stream, cntl, &options) != 0) {
        std::string errmsg = 
            "failed to create stream, session: " +
            std::to_string(ctx->request->session_id()) + ", log_id: " +
            std::to_string(ctx->log_id);
        LOG(ERROR) << errmsg;

        cntl.SetFailed(errmsg);
        ctx->err_code = cntl.ErrorCode();
        ctx->err_msg = cntl.ErrorText();
        return DB_ERROR;
      }

      // send async formula query
      do_query(ctx);

      while (true) {
        if (ctx->canceled.load() || ctx->killed.load()) {
          brpc::StartCancel(cid);
          brpc::StreamClose(stream);
          while (!ctx->is_done.load()) {
            std::this_thread::sleep_for(std::chrono::microseconds(10));
          }
          LOG(WARNING) << "query on formula is killed or canceled"
                       << ", session: " << ctx->request->session_id()
                       << ", log_id: " << ctx->log_id;
          return DB_ERROR;
        }
        if (ctx->is_eos.load()) {
          // normal case
          break;
        }
        if (ctx->is_done.load() && ctx->err_code != 0) {
          // met error when do rpc
          break;
        }
        if (ctx->is_err.load()) {
          // met error when receiving result
          std::string errmsg = 
              "met error when receiving result, session: " +
              std::to_string(ctx->request->session_id()) + ", log_id: " +
              std::to_string(ctx->log_id) + ", stream id: " +
              std::to_string(stream);
          LOG(WARNING) << errmsg;

          cntl.SetFailed(errmsg);
          ctx->err_code = cntl.ErrorCode();
          ctx->err_msg = cntl.ErrorText();
          break;
        }
        std::this_thread::sleep_for(std::chrono::microseconds(100));
      }

      if (ctx->err_code == 0) {
        return DB_SUCCESS;
      }

      brpc::StreamClose(stream);

      bool mismatch_zone = false;
      if (psm_client_->has_zone() && response.has_refresh_zone() &&
          response.refresh_zone() && response.has_zone()) {
        mismatch_zone = true;
      }
      if (cntl.Failed() || mismatch_zone) {
        // if controller failed, replica may be broken, refresh replica list
        ++ctx->retry_count;
        ++local_retry_count;
        if (ctx->retry_count >= static_cast<int>(column_stores.size())) {
          force_sync_replicas = true;
          ctx->retry_count = 0;
        }
      }
    }
  } while (force_sync_replicas && local_retry_count < max_retry_count);

  return DB_ERROR;
}

}  // namespace formula
