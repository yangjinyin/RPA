/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_replication_manager.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gaiadb/proto/replication/replication.pb.h>
#include "gaia/command.h"

namespace psvr {
namespace gaia {

class UpdateReplicationManager : public Command {
public:
    UpdateReplicationManager() {
        SetName("update-replication-manager");
        SetDesc("reset manager address of replication server");
        SetDescCn("重置复制服务的管理地址");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "which standby cluster to update?", kstring);
        AddRequiredArgOption("primary-manager-address", &_long_opt_val,
                kOptMax + 2,
                "set new primary manager address to replicator",
                kstring);
        AddRequiredArgOption("standby-manager-address", &_long_opt_val,
                kOptMax + 3,
                "set new standby manager address to replicator",
                kstring);
        
        AddExample("-a <ip> -p <port> --primary-manager-address bns://xxx --cluster-id xxx");
        AddExample("-a <ip> -p <port> --standby-manager-address bns://xxx --cluster-id xxx");
        AddExample("-a <ip> -p <port> --cluster-id xxx"
                " --primary-manager-address bns://xx1"
                " --standby-manager-address bns://xx2");
    }
    virtual ~UpdateReplicationManager() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 2:
                _primary_manager_address = opt;
                break;
            case kOptMax + 3:
                _standby_manager_address = opt;
                break;
            default:
                return 1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const replicate::pb::ModifyManagerResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    std::string _primary_manager_address {};
    std::string _standby_manager_address {};
};

}
}
