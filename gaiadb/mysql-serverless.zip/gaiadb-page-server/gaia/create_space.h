/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/create_space.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class CreateSpace : public Command {
public:
    CreateSpace() {
        SetName("create-space");
        SetDesc("create a space in manager");
        SetDescCn("在管理服务中创建表空间");

        AddPsmClusterOption();
        AddRequiredArgOption("space-id", &_long_opt_val, kOptMax + 1, "create space id", kuint32_t);
        AddRequiredArgOption("alloc-extent", &_long_opt_val, kOptMax + 2,
                "create space alloc extent num, default 1", kuint32_t, kGroup2Scope);

        AddExample("--manager-address \"bns://xxx\" --space-id 1");
        AddExample("--manager-address \"bns://xxx\" --space-id 1 --alloc-extent x");
    }
    virtual ~CreateSpace() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _space_id.Set(std::strtoul(opt, NULL, 10));
                break;
            case kOptMax + 2:
                _alloc_extent_num = std::strtoul(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::CreateSpaceResponse& rsp);

private:
    std::string _manager_address {};
    VarOptional<uint32_t> _space_id;
    uint32_t _alloc_extent_num {1};
};

}
}
