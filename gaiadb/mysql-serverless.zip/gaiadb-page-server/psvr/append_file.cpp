/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file /ssd3/yukeyong/baidu/dba/gaiadb-page-server/psvr/append_file.cc
* @author yukeyong@baidu.com
* @brief
*/

#include <limits.h>
#include <cstring>
#include <filesystem>
#include <memory>
#include "psvr/append_file.h"
#include "psvr/store_cfg.h"
#include "psvr/config.h"

namespace psvr {

static constexpr uint64_t kBlockMinSize = 8388608; // 8MB
static constexpr uint64_t kAppendSeekProbeMinWindowSize = 4 * 1024;
static const char* db_path = "db";
static const char* db_ext_name = ".db";
static const char* append_slots_name = "append_slots";

static char log_magic_first_byte() {
    const uint32_t magic = db::kLogHeaderMagic;
    return reinterpret_cast<const char*>(&magic)[0];
}

static bool is_log_magic(const char* p, const char* buf_end) {
    if (static_cast<size_t>(buf_end - p) < sizeof(uint32_t)) {
        return true;
    }
    uint32_t magic = 0;
    std::memcpy(&magic, p, sizeof(magic));
    return magic == db::kLogHeaderMagic;
}

static bool is_valid_log_header(const db::LogHeader& header, uint64_t file_start_lsn) {
    return header.magic == db::kLogHeaderMagic &&
            !db::check_is_corrupt(header, db::kLogHeaderSize) &&
            header.start_lsn >= file_start_lsn &&
            header.end_lsn >= header.start_lsn;
}

db::Status validate_append_redo_block(
        const db::LogHeader& log_header,
        const base::Slice& key,
        const base::Slice& value) {
    db::Status st;
    if (db::check_is_corrupt(log_header, db::kLogHeaderSize)) {
        st.Reset(db::Code::kCorrupted,
                "append redo log header checksum mismatch, range:%lu-%lu",
                log_header.start_lsn, log_header.end_lsn);
        return st;
    }

    const uint32_t real_key_crc = db::get_crc(
            reinterpret_cast<const void*>(key.data()), key.size());
    if (real_key_crc != log_header.key_crc) {
        st.Reset(db::Code::kCorrupted,
                "append redo offset cache checksum mismatch, "
                "range:%lu-%lu expected:%u actual:%u",
                log_header.start_lsn, log_header.end_lsn,
                log_header.key_crc, real_key_crc);
        return st;
    }

    const uint32_t real_value_crc = db::get_crc(
            reinterpret_cast<const void*>(value.data()), value.size());
    if (real_value_crc != log_header.buf_crc) {
        st.Reset(db::Code::kCorrupted,
                "append redo data checksum mismatch, "
                "range:%lu-%lu expected:%u actual:%u",
                log_header.start_lsn, log_header.end_lsn,
                log_header.buf_crc, real_value_crc);
        return st;
    }

    return st;
}

struct AppendDBEngineStatistic {
    // statistic
    StatLatency stat_db_read_lat;
    StatLatency stat_db_write_lat;
    StatBw stat_db_read_bw;
    StatBw stat_db_write_bw;
    StatCount stat_db_read_io_err_count;
    StatCount stat_db_write_io_err_count;
    StatQps stat_fetch_redo_log_count;
    StatQps stat_fetch_redo_log_off_miss_count;
    StatLatency stat_fetch_redo_log_lat;
    StatLatency stat_recover_log_lat;

    AppendDBEngineStatistic()
        : stat_db_read_lat("psvr", "append_read", kSlaWindowSize),
        stat_db_write_lat("psvr", "append_write", kSlaWindowSize),
        stat_db_read_bw("psvr_append_read_bw", kSlaWindowSize),
        stat_db_write_bw("psvr_append_write_bw", kSlaWindowSize),
        stat_db_read_io_err_count("psvr_append_read_io_err_count", kSlaWindowSize),
        stat_db_write_io_err_count("psvr_append_write_io_err_count", kSlaWindowSize),
        stat_fetch_redo_log_count("psvr_append_fetch_redo_log_count", kSlaWindowSize),
        stat_fetch_redo_log_off_miss_count(
                "psvr_append_fetch_redo_log_off_miss_count", kSlaWindowSize),
        stat_fetch_redo_log_lat("psvr_append_fetch_redo_log_lat", kSlaWindowSize),
        stat_recover_log_lat("psvr_append_recover_log_lat", kSlaWindowSize) {}
};

static std::unique_ptr<AppendDBEngineStatistic> l_append_dbengine_stat {nullptr};

static void PSVR_FUNC_CTOR init_append_dbengine_statistic() {
    l_append_dbengine_stat.reset(new AppendDBEngineStatistic);
}

#define stat_append_value(n, v)             \
do {                                        \
    if (l_append_dbengine_stat) {           \
        (l_append_dbengine_stat->n) << (v); \
    }                                       \
} while(0)                                  \

static void stat_fetch_off_miss(bool* off_miss) {
    if (*off_miss) {
        return;
    }
    *off_miss = true;
    stat_append_value(stat_fetch_redo_log_off_miss_count, 1);
}

class AppendFixReader {
public:
    using RandomAccessBlockPtr = std::shared_ptr<db::RandomAccessBlock>;

    AppendFixReader(const RandomAccessBlockPtr& rblock, uint64_t file_size,
            uint64_t file_start_lsn, uint64_t scan_buf_size)
        : _rblock(rblock), _file_size(file_size), _file_start_lsn(file_start_lsn),
          _scan_buf_size(scan_buf_size), _scan_buf(new char[scan_buf_size]) {}

    db::Status ValidateHeader(uint64_t pos, db::LogHeader* header, bool* valid);
    db::Status ValidatePayload(uint64_t pos, const db::LogHeader& header, bool* valid);
    db::Status ValidateRecord(uint64_t pos, db::LogHeader* header, bool* valid);
    db::Status FindNextRecord(uint64_t search_begin, uint64_t* record_off,
            db::LogHeader* header, bool* found);
    db::Status FindPrevRecord(uint64_t cur_off, const db::LogHeader& cur_header,
            uint64_t* prev_off, db::LogHeader* prev_header, bool* found);
    db::Status FindLastRecord(uint64_t anchor_off, const db::LogHeader& anchor_header,
            uint64_t* last_off, db::LogHeader* last_header, uint64_t* chain_sum);
    db::Status CheckTailSafe(uint64_t anchor_off, const db::LogHeader& anchor_header,
            uint64_t sum, bool* safe);

private:
    bool InBackBuf(uint64_t pos, uint64_t size) const;
    void EnsureDataBuf(uint64_t size);
    db::Status ReadBackBuf(uint64_t search_end);

private:
    RandomAccessBlockPtr _rblock;
    uint64_t _file_size;
    uint64_t _file_start_lsn;
    uint64_t _scan_buf_size;
    std::unique_ptr<char[]> _scan_buf;
    std::unique_ptr<char[]> _data_buf;
    uint64_t _data_buf_size = 0;
    uint64_t _back_buf_off = 0;
    uint64_t _back_buf_len = 0;
};

bool AppendFixReader::InBackBuf(uint64_t pos, uint64_t size) const {
    return _back_buf_len > 0 && pos >= _back_buf_off &&
            pos + size <= _back_buf_off + _back_buf_len;
}

void AppendFixReader::EnsureDataBuf(uint64_t size) {
    if (size > _data_buf_size) {
        _data_buf.reset(new char[size]);
        _data_buf_size = size;
    }
}

db::Status AppendFixReader::ValidateHeader(uint64_t pos, db::LogHeader* header, bool* valid) {
    db::Status st;
    *valid = false;
    if (pos + db::kLogHeaderSize > _file_size) {
        return st;
    }

    if (InBackBuf(pos, db::kLogHeaderSize)) {
        std::memcpy(header, _scan_buf.get() + (pos - _back_buf_off), db::kLogHeaderSize);
    } else {
        base::Slice hbuf;
        st = _rblock->Read(pos, db::kLogHeaderSize, &hbuf, reinterpret_cast<char*>(header));
        if (!st.IsOk()) {
            return st;
        }
        if (hbuf.size() < db::kLogHeaderSize) {
            return st;
        }
    }
    if (!is_valid_log_header(*header, _file_start_lsn)) {
        return st;
    }
    *valid = true;
    return st;
}

db::Status AppendFixReader::ValidatePayload(uint64_t pos, const db::LogHeader& header,
        bool* valid) {
    db::Status st;
    *valid = false;
    const uint64_t data_size = static_cast<uint64_t>(header.key_size) + header.value_size;
    if (data_size + pos + db::kLogHeaderSize > _file_size) {
        return st;
    }

    base::Slice key;
    base::Slice value;
    if (data_size > 0) {
        const uint64_t data_off = pos + db::kLogHeaderSize;
        const char* data = nullptr;
        if (InBackBuf(data_off, data_size)) {
            data = _scan_buf.get() + (data_off - _back_buf_off);
        } else {
            EnsureDataBuf(data_size);
            base::Slice dbuf;
            st = _rblock->Readx(data_off, data_size, &dbuf, _data_buf.get());
            if (!st.IsOk()) {
                return st;
            }
            if (dbuf.size() != data_size) {
                return st;
            }
            data = _data_buf.get();
        }
        key = base::Slice(data, header.key_size);
        value = base::Slice(data + header.key_size, header.value_size);
    }

    if (!validate_append_redo_block(header, key, value).IsOk()) {
        return st;
    }
    *valid = true;
    return st;
}

db::Status AppendFixReader::ValidateRecord(uint64_t pos, db::LogHeader* header, bool* valid) {
    db::Status st;
    *valid = false;
    st = ValidateHeader(pos, header, valid);
    if (!st.IsOk() || !*valid) {
        return st;
    }
    return ValidatePayload(pos, *header, valid);
}

db::Status AppendFixReader::ReadBackBuf(uint64_t search_end) {
    db::Status st;
    if (_back_buf_len > 0 && search_end > _back_buf_off &&
            search_end <= _back_buf_off + _back_buf_len) {
        return st;
    }

    const uint64_t start = search_end > _scan_buf_size
            ? search_end - _scan_buf_size : db::kBlockHeaderSize;
    const uint64_t len = search_end - start;
    base::Slice chunk;
    st = _rblock->Readx(start, len, &chunk, _scan_buf.get());
    if (!st.IsOk()) {
        return st;
    }
    if (chunk.size() == 0) {
        _back_buf_len = 0;
        return st;
    }
    _back_buf_off = start;
    _back_buf_len = chunk.size();
    return st;
}

db::Status AppendFixReader::FindNextRecord(uint64_t search_begin, uint64_t* record_off,
        db::LogHeader* header, bool* found) {
    db::Status st;
    *found = false;
    _back_buf_len = 0;
    uint64_t off = search_begin;
    while (off < _file_size) {
        const uint64_t left = _file_size - off;
        const uint64_t read_size = left > _scan_buf_size ? _scan_buf_size : left;
        base::Slice chunk;
        st = _rblock->Readx(off, read_size, &chunk, _scan_buf.get());
        if (!st.IsOk()) {
            return st;
        }
        if (chunk.size() == 0) {
            break;
        }

        const char* buf_end = _scan_buf.get() + chunk.size();
        base::Slice view(_scan_buf.get(), chunk.size());
        const char* p = view.find_first_of(log_magic_first_byte());
        while (p != nullptr) {
            const uint64_t pos = off + static_cast<uint64_t>(p - _scan_buf.get());
            if (is_log_magic(p, buf_end)) {
                bool valid = false;
                st = ValidateRecord(pos, header, &valid);
                if (!st.IsOk()) {
                    return st;
                }
                if (valid) {
                    *record_off = pos;
                    *found = true;
                    return st;
                }
            }

            const char* next = p + 1;
            if (next >= buf_end) {
                break;
            }
            view = base::Slice(next, static_cast<size_t>(buf_end - next));
            p = view.find_first_of(log_magic_first_byte());
        }

        off += chunk.size();
    }
    return st;
}

db::Status AppendFixReader::FindPrevRecord(uint64_t cur_off, const db::LogHeader& cur_header,
        uint64_t* prev_off, db::LogHeader* prev_header, bool* found) {
    db::Status st;
    *found = false;
    uint64_t search_end = cur_off;
    while (search_end > db::kBlockHeaderSize) {
        st = ReadBackBuf(search_end);
        if (!st.IsOk()) {
            return st;
        }
        if (_back_buf_len == 0) {
            break;
        }

        const uint64_t view_len = (search_end - _back_buf_off) < _back_buf_len
                ? (search_end - _back_buf_off) : _back_buf_len;
        base::Slice view(_scan_buf.get(), view_len);
        const char* buf_end = _scan_buf.get() + view_len;
        const char* p = view.find_last_of(log_magic_first_byte());
        while (p != nullptr) {
            const uint64_t pos = _back_buf_off + static_cast<uint64_t>(p - view.data());
            if (is_log_magic(p, buf_end)) {
                db::LogHeader header;
                bool valid = false;
                st = ValidateHeader(pos, &header, &valid);
                if (!st.IsOk()) {
                    return st;
                }
                if (valid) {
                    const uint64_t data_size = static_cast<uint64_t>(header.key_size) +
                            header.value_size;
                    if (pos + db::kLogHeaderSize + data_size == cur_off &&
                            header.end_lsn == cur_header.start_lsn) {
                        *prev_off = pos;
                        *prev_header = header;
                        *found = true;
                        return st;
                    }
                }
            }

            if (p == view.data()) {
                break;
            }
            view = base::Slice(view.data(), static_cast<size_t>(p - view.data()));
            p = view.find_last_of(log_magic_first_byte());
        }

        if (_back_buf_off <= db::kBlockHeaderSize) {
            break;
        }
        search_end = _back_buf_off;
    }
    return st;
}

db::Status AppendFixReader::FindLastRecord(uint64_t anchor_off,
        const db::LogHeader& anchor_header, uint64_t* last_off,
        db::LogHeader* last_header, uint64_t* chain_sum) {
    db::Status st;
    *last_off = anchor_off;
    *last_header = anchor_header;
    *chain_sum = anchor_header.value_size;
    uint64_t next_lsn = anchor_header.end_lsn;
    uint64_t next_off = anchor_off + db::kLogHeaderSize +
            static_cast<uint64_t>(anchor_header.key_size) + anchor_header.value_size;
    while (next_off < _file_size) {
        db::LogHeader header;
        bool valid = false;
        st = ValidateHeader(next_off, &header, &valid);
        if (!st.IsOk()) {
            return st;
        }
        if (!valid) {
            break;
        }
        if (header.start_lsn != next_lsn) {
            st.Reset(db::Code::kCorrupted, "fix footer, file:%s log header start lsn:%lu != %lu discontinuous, off:%lu",
                    _rblock->file_name().c_str(), header.start_lsn, next_lsn, next_off);
            return st;
        }
        st = ValidatePayload(next_off, header, &valid);
        if (!st.IsOk()) {
            return st;
        }
        if (!valid) {
            break;
        }
        *last_off = next_off;
        *last_header = header;
        *chain_sum += header.value_size;
        next_lsn = header.end_lsn;
        next_off += db::kLogHeaderSize +
                static_cast<uint64_t>(header.key_size) + header.value_size;
    }
    return st;
}

db::Status AppendFixReader::CheckTailSafe(uint64_t anchor_off,
        const db::LogHeader& anchor_header, uint64_t sum, bool* safe) {
    // Bound the backward scan: once the validated tail chain exceeds
    // merge_max_buf_size, the earlier records are trusted instead of being
    // re-validated, trading startup IO for recovery speed.
    db::Status st;
    uint64_t cur_off = anchor_off;
    db::LogHeader cur_header = anchor_header;
    *safe = sum > FLAGS_psvr_append_merge_max_buf_size;
    while (!*safe) {
        if (cur_off <= db::kBlockHeaderSize) {
            *safe = true;
            break;
        }

        uint64_t prev_off = 0;
        db::LogHeader prev_header;
        bool prev_found = false;
        st = FindPrevRecord(cur_off, cur_header, &prev_off, &prev_header, &prev_found);
        if (!st.IsOk()) {
            return st;
        }
        if (!prev_found) {
            break;
        }

        sum += prev_header.value_size;
        if (sum > FLAGS_psvr_append_merge_max_buf_size) {
            *safe = true;
            break;
        }

        bool valid = false;
        st = ValidatePayload(prev_off, prev_header, &valid);
        if (!st.IsOk()) {
            return st;
        }
        if (!valid) {
            break;
        }

        cur_off = prev_off;
        cur_header = prev_header;
    }
    return st;
}

class AppendSeekLocator {
public:
    using RandomAccessBlockPtr = std::shared_ptr<db::RandomAccessBlock>;

    AppendSeekLocator(const RandomAccessBlockPtr& rblock, uint64_t file_size,
            uint64_t start_lsn, uint64_t chunk_size);

    bool Locate(uint64_t seek_lsn, uint64_t* off);
    bool LocateFrom(uint64_t base_off, uint64_t base_lsn, uint64_t seek_lsn, uint64_t* off);

private:
    struct Anchor {
        uint64_t off = 0;
        uint64_t start_lsn = 0;
    };

    db::Status Probe(uint64_t base_off, Anchor* anchor, bool* found);
    bool ValidateAnchor(uint64_t pos, Anchor* anchor) const;

private:
    RandomAccessBlockPtr _rblock;
    const uint64_t _file_size;
    const uint64_t _start_lsn;
    const uint64_t _chunk_size;
};

AppendSeekLocator::AppendSeekLocator(const RandomAccessBlockPtr& rblock,
        uint64_t file_size, uint64_t start_lsn, uint64_t chunk_size)
    : _rblock(rblock), _file_size(file_size), _start_lsn(start_lsn),
    _chunk_size(chunk_size) {}

bool AppendSeekLocator::ValidateAnchor(uint64_t pos, Anchor* anchor) const {
    db::LogHeader header;
    base::Slice buf;
    db::Status st = _rblock->Read(pos, db::kLogHeaderSize, &buf,
            reinterpret_cast<char*>(&header));
    if (!st.IsOk() || buf.size() != db::kLogHeaderSize) {
        return false;
    }
    if (!is_valid_log_header(header, _start_lsn)) {
        return false;
    }

    const uint64_t next_off = pos + db::kLogHeaderSize +
            static_cast<uint64_t>(header.key_size) + header.value_size;
    if (next_off > _file_size) {
        return false;
    }
    if (next_off < _file_size) {
        db::LogHeader next_header;
        base::Slice next_buf;
        st = _rblock->Read(next_off, db::kLogHeaderSize, &next_buf,
                reinterpret_cast<char*>(&next_header));
        if (!st.IsOk() || next_buf.size() != db::kLogHeaderSize) {
            return false;
        }
        if (!is_valid_log_header(next_header, _start_lsn) ||
                next_header.start_lsn != header.end_lsn) {
            return false;
        }
    }

    anchor->off = pos;
    anchor->start_lsn = header.start_lsn;
    return true;
}

db::Status AppendSeekLocator::Probe(uint64_t base_off, Anchor* anchor, bool* found) {
    db::Status st;
    *found = false;
    const char magic_first = log_magic_first_byte();
    std::unique_ptr<char[]> buf;
    uint64_t buf_size = 0;
    uint64_t window = kAppendSeekProbeMinWindowSize;
    while (base_off < _file_size) {
        const uint64_t len = std::min(window, _file_size - base_off);
        if (len > buf_size) {
            buf.reset(new char[len]);
            buf_size = len;
        }
        base::Slice view;
        st = _rblock->Readx(base_off, len, &view, buf.get());
        if (!st.IsOk()) {
            return st;
        }

        const char* const begin = view.data();
        const char* const end = begin + view.size();
        const char* p = begin;
        while (p < end) {
            const char* cur = static_cast<const char*>(
                    std::memchr(p, magic_first, static_cast<size_t>(end - p)));
            if (cur == nullptr) {
                break;
            }
            if (static_cast<size_t>(end - cur) >= sizeof(uint32_t)) {
                uint32_t magic = 0;
                std::memcpy(&magic, cur, sizeof(magic));
                if (magic == db::kLogHeaderMagic &&
                        ValidateAnchor(base_off + static_cast<uint64_t>(cur - begin), anchor)) {
                    *found = true;
                    return st;
                }
            }
            p = cur + 1;
        }

        if (window >= _chunk_size || base_off + len >= _file_size) {
            break;
        }
        window = std::min(window * 4, _chunk_size);
    }
    return st;
}

bool AppendSeekLocator::Locate(uint64_t seek_lsn, uint64_t* off) {
    *off = db::kBlockHeaderSize;
    if (_chunk_size == 0 || seek_lsn <= _start_lsn ||
            _file_size <= db::kBlockHeaderSize) {
        return false;
    }

    const uint64_t chunk_num =
            (_file_size - db::kBlockHeaderSize + _chunk_size - 1) / _chunk_size;
    int64_t lo = 0;
    int64_t hi = static_cast<int64_t>(chunk_num) - 1;
    bool located = false;
    while (lo <= hi) {
        const int64_t mid = lo + (hi - lo) / 2;
        Anchor anchor;
        bool found = false;
        db::Status st = Probe(db::kBlockHeaderSize +
                static_cast<uint64_t>(mid) * _chunk_size, &anchor, &found);
        if (!st.IsOk() || !found) {
            if (!located) {
                *off = db::kBlockHeaderSize;
                return false;
            }
            return true;
        }
        if (anchor.start_lsn <= seek_lsn) {
            *off = anchor.off;
            located = true;
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return located;
}

bool AppendSeekLocator::LocateFrom(uint64_t base_off, uint64_t base_lsn,
        uint64_t seek_lsn, uint64_t* off) {
    *off = base_off;
    if (_chunk_size == 0 || seek_lsn <= base_lsn || base_off >= _file_size) {
        return false;
    }
    const uint64_t span = _file_size - base_off;
    if (span <= _chunk_size) {
        return false;
    }

    Anchor first;
    bool found = false;
    db::Status st = Probe(base_off + _chunk_size, &first, &found);
    if (!st.IsOk() || !found || first.start_lsn > seek_lsn) {
        return false;
    }

    *off = first.off;
    const uint64_t chunk_num = (span + _chunk_size - 1) / _chunk_size;
    int64_t lo = 2;
    int64_t hi = static_cast<int64_t>(chunk_num) - 1;
    while (lo <= hi) {
        const int64_t mid = lo + (hi - lo) / 2;
        Anchor anchor;
        found = false;
        st = Probe(base_off + static_cast<uint64_t>(mid) * _chunk_size, &anchor, &found);
        if (!st.IsOk() || !found) {
            return true;
        }
        if (anchor.start_lsn <= seek_lsn) {
            *off = anchor.off;
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return true;
}

AppendReadBuf::AppendReadBuf(uint64_t size) {
    Init(size);
}

void AppendReadBuf::Init(uint64_t size) {
    if (size < db::kReadBufMinSize) {
        size = db::kReadBufMinSize;
    }
    _read_buf_size = size;
    _read_buf.reset(new char[size]);
    _read_buf_off = 0;
    _read_buf_len = 0;
    _read_buf_fno = 0;
    _read_buf_foff = 0;
}

void AppendReadBuf::Reset() {
    _read_buf_off = 0;
    _read_buf_len = 0;
    _read_buf_fno = 0;
    _read_buf_foff = 0;
}

void AppendReadBuf::Skip(uint64_t size) {
    if (size == 0) {
        return;
    }
    const uint64_t left = _read_buf_len - _read_buf_off;
    if (size <= left) {
        _read_buf_off += size;
        _read_buf_foff += size;
        return;
    }
    _read_buf_off = 0;
    _read_buf_len = 0;
    _read_buf_foff += size;
}

db::Status AppendReadBuf::GetBufSize(const std::shared_ptr<db::RandomAccessBlock>& rblock,
        uint64_t off, size_t size, base::Slice* buf, char* dst, bool read_ahead) {
    return GetBufSizeImpl(rblock, off, size, buf, dst, read_ahead, false);
}

db::Status AppendReadBuf::GetBufSizex(const std::shared_ptr<db::RandomAccessBlock>& rblock,
        uint64_t off, size_t size, base::Slice* buf, char* dst, bool read_ahead) {
    return GetBufSizeImpl(rblock, off, size, buf, dst, read_ahead, true);
}

db::Status AppendReadBuf::GetBufSizeImpl(const std::shared_ptr<db::RandomAccessBlock>& rblock,
        uint64_t off, size_t size, base::Slice* buf, char* dst, bool read_ahead, bool use_preadx) {
    db::Status st;

    size_t read_size = 0;
    auto read_fn = [use_preadx, rblock, size, &read_size](uint64_t offset_, size_t n_, base::Slice* result_, char* buf_) {
        auto st_ = rblock->Read(offset_, n_, result_, buf_);
        if (!st_.IsOk()) {
            return st_;
        }
        if (use_preadx && read_size + result_->size() < size) {
            size_t got = result_->size();
            size_t n = size - read_size - got;
            st_ = rblock->Readx(offset_ + got, n, result_, buf_ + got);
            if (!st_.IsOk()) {
                return st_;
            }
            *result_ = base::Slice(buf_, got + result_->size());
        }
        return st_;
    };

    const bool hit = _read_buf_fno == rblock->file_no() && _read_buf_foff == off;
    // 1) hit: the buffer sits exactly at off and holds enough bytes
    if (hit) {
        if (_read_buf_len - _read_buf_off >= size) {
            std::memcpy(dst, _read_buf.get() + _read_buf_off, size);
            _read_buf_off += size;
            _read_buf_foff += size;
            *buf = base::Slice(dst, size);
            return st;
        } else {
            const uint64_t left = _read_buf_len - _read_buf_off;
            if (left > 0) {
                std::memmove(_read_buf.get(), _read_buf.get() + _read_buf_off, left);
            }
            _read_buf_off = 0;
            _read_buf_len = left;
        }
    }
    const uint64_t read_max_len = read_ahead ? _read_buf_size : size;
    // 2) reading a log header at the buffer position but not enough bytes left:
    //    move the remainder to the buffer start, then read ahead a full buffer
    if (hit && size == db::kLogHeaderSize) {
        base::Slice b;
        const uint64_t left = _read_buf_len - _read_buf_off;
        read_size += left;
        st = read_fn(_read_buf_foff + left, read_max_len - left, &b,
                _read_buf.get() + left);
        if (!st.IsOk()) {
            return st;
        }
        _read_buf_len += b.size();

        const uint64_t copy_size = std::min<uint64_t>(_read_buf_len - _read_buf_off, size);
        std::memcpy(dst, _read_buf.get() + _read_buf_off, copy_size);
        // A short read keeps the read position, the caller retries the same off.
        if (copy_size == size) {
            _read_buf_off += size;
            _read_buf_foff += size;
        }
        *buf = base::Slice(dst, copy_size);
        return st;
    }

    // 3) flush the buffer remainder into dst, then decide by 2/3 of the free space
    size_t copied = 0;
    if (hit && _read_buf_len > _read_buf_off) {
        copied = _read_buf_len - _read_buf_off;
        std::memcpy(dst, _read_buf.get() + _read_buf_off, copied);
        read_size += copied;
    }

    const size_t remain = size - copied;
    base::Slice b;
    if (remain >= (_read_buf_size - copied) * 2 / 3 || !read_ahead) {
        st = read_fn(off + copied, remain, &b, dst + copied);
        if (!st.IsOk()) {
            return st;
        }
        // A short read keeps the read position, the caller retries the same off.
        if (copied + b.size() == size) {
            _read_buf_off = _read_buf_len = 0;
            _read_buf_foff += copied;
            _read_buf_fno = rblock->file_no();
        }
        *buf = base::Slice(dst, copied + b.size());
        return st;
    }

    st = read_fn(off + copied, read_max_len - copied, &b, _read_buf.get() + copied);
    if (!st.IsOk()) {
        return st;
    }
    if (hit) {
        _read_buf_len += b.size();
    } else {
        _read_buf_len = copied + b.size();
        _read_buf_off = copied;
        _read_buf_fno = rblock->file_no();
        _read_buf_foff = off;
    }
    const uint64_t copy_size = std::min<uint64_t>(_read_buf_len - copied, remain);
    std::memcpy(dst + copied, _read_buf.get() + copied, copy_size);
    // A short read keeps the read position, the caller retries the same off.
    if (copy_size == remain) {
        if (hit && copied > 0) {
            _read_buf_off += copied;
            _read_buf_foff += copied;
        }
        _read_buf_off += copy_size;
        _read_buf_foff += copy_size;
    }
    *buf = base::Slice(dst, copied + copy_size);
    return st;
}

AppendDBEngine::AppendDBEngine()
    : _disable(1),
    _data_path(),
    _write_block(nullptr),
    _rblock(nullptr),
    _block_no(0),
    _next_write_lsn(0),
    _db_size(0),
    _checkpoint_block(nullptr),
    _random_access_blocks_size(0),
    _recover_info(nullptr) {
}

AppendDBEngine::~AppendDBEngine() {
    Close();
}

db::Status AppendDBEngine::Open(const std::string& data_path,
        gaia_apply::lsn_t dblwr_checkpoint_lsn,
        gaia_apply::lsn_t* checkpoint_lsn, gaia_apply::lsn_t* max_apply_lsn) {
    *checkpoint_lsn = 0;
    *max_apply_lsn = 0;
    Status st = Open2(data_path, dblwr_checkpoint_lsn, checkpoint_lsn, max_apply_lsn);
    if (!st.IsOk()) {
        Close();
    }
    return st;
}

db::Status AppendDBEngine::Open2(const std::string& data_path,
        gaia_apply::lsn_t dblwr_checkpoint_lsn,
        gaia_apply::lsn_t* checkpoint_lsn, gaia_apply::lsn_t* max_apply_lsn) {
    Status st;
    Timer timer(base::Timer::STARTED);
    std::unique_lock lk(_shared_mutex);
    if (_block_no > 0) {
        LOG(NOTICE) << "append db is already open,"
            << " path:[" << data_path
            << " block_no:[" << _block_no
            << "]";
        st.Reset(Code::kOk, "append db is already open");
        return st;
    }

    _data_path = base::string_printf("%s/%s", data_path.c_str(), db_path);

    std::error_code ec;
    if (!std::filesystem::exists(_data_path, ec)) {
        if (!std::filesystem::create_directories(_data_path, ec)) {
            st.Reset(db::GetErrCode(), "create path:%s failed, %m", _data_path.c_str());
            return st;
        }
        st = db::sync_directoryx(std::filesystem::path(_data_path).parent_path().c_str());
        if (!st.IsOk()) {
            return st;
        }
    }
    if (ec) {
        st.Reset(Code::kIOError, "create path:%s failed, %m", _data_path.c_str());
        return st;
    }

    std::string slots_fname = base::string_printf("%s/%s", data_path.c_str(), append_slots_name);
    _slots_block = std::make_shared<db::BlockSlotsBlock>(slots_fname);
    st = _slots_block->Open();
    if (!st.IsOk()) {
        return st;
    }

    std::vector<uint64_t> fno_vec;
    for (auto& block_fname : std::filesystem::directory_iterator(_data_path, ec)) {
        if (block_fname.is_directory()) {
            LOG(WARNING) << "found a not block file,"
                << " path:[" << _data_path
                << "] name:[" << block_fname.path()
                << "] " << ec.message();
            continue;
        }
        const std::filesystem::path& fpath = block_fname.path();
        if (fpath.extension() != db_ext_name) {
            LOG(WARNING) << "found a tmp block file,"
                << " name:[" << fpath
                << "]";
            continue;
        }
        const std::filesystem::path& fname = fpath.filename();
        uint64_t fno = std::strtoull(fname.c_str(), nullptr, 10);
        if (std::to_string(fno).append(db_ext_name) != fname.native()) {
            LOG(WARNING) << "unknown file,"
                << " path:[" << _data_path
                << "] fno:[" << fno
                << "] fname:[" << fname
                << "]";
            st.Reset(Code::kInvalid, "unknown file:%s", fpath.c_str());
            return st;
        }

        fno_vec.push_back(fno);
    }

    if (ec) {
        st.Reset(Code::kIOError, "iterator path:%s failed, %m", _data_path.c_str());
        return st;
    }

    uint64_t block_min_lsn = 0;
    bool fix_footer = false;
    if (!fno_vec.empty()) {
        std::sort(fno_vec.begin(), fno_vec.end());  // sort by fno asc, 0 1 2 3 4 5 6 7 8 9
        const uint64_t min_block_no = fno_vec.front();
        const uint64_t max_block_no = fno_vec.back();
        for (const auto& fno : fno_vec) {
            RandomAccessBlockPtr rblock = nullptr;
            st = NewRandomAccessBlock(fno, 0, &rblock);
            if (!st.IsOk()) {
                if (st.IsEmpty() && fno == max_block_no) {
                    st = RemoveEmptyBlock(fno);
                    if (st.IsOk()) {
                        break;
                    }
                }
                return st;
            }

            if (fno == max_block_no) {
                st = TryFixBlock(rblock, &fix_footer);
                if (st.IsEmpty()) {
                    st = RemoveEmptyBlock(fno);
                    if (st.IsOk()) {
                        break;
                    }
                }
                if (!st.IsOk()) {
                    return st;
                }
            }

            if (rblock->end_lsn() == 0) {
                st.Reset(Code::kMissData, "block file:%s miss footer, max block no:%lu",
                        rblock->file_name().c_str(), max_block_no);
                return st;
            }

            if (fno > min_block_no) {
                if (_next_write_lsn != rblock->start_lsn()) {
                    st.Reset(Code::kMisMacth, "block file:%s lsn discontinuous, start:%lu, last:%lu",
                            rblock->file_name().c_str(), rblock->start_lsn(), _next_write_lsn);
                    return st;
                }
            } else {
                block_min_lsn = rblock->start_lsn();
            }
            _next_write_lsn = rblock->end_lsn();
        }

        _block_no = max_block_no;
    }

    std::string ckp_fname = base::string_printf("%s/%s",
            data_path.c_str(), kAppendCheckPointName.c_str());
    _checkpoint_block = std::make_shared<db::CheckPointBlock>(ckp_fname);
    st = _checkpoint_block->Open();
    if (!st.IsOk()) {
        return st;
    }

    *max_apply_lsn = _next_write_lsn;
    *checkpoint_lsn = _checkpoint_block->lsn();
    if (*checkpoint_lsn == 0 && *checkpoint_lsn < *max_apply_lsn) {
        /* append data but not start gc it */
        std::unique_lock lk2(_random_access_shared_mutex);
        PSVR_ASSERT(!_random_access_blocks.empty());
        *checkpoint_lsn = _random_access_blocks.back()->start_lsn();
    }

    ++_block_no;

    if (*checkpoint_lsn > 0) {
        if (block_min_lsn > *checkpoint_lsn || *checkpoint_lsn > _next_write_lsn) {
            st.Reset(Code::kMisMacth, "checkpoint:%lu not in range:%lu-%lu",
                    *checkpoint_lsn, block_min_lsn, _next_write_lsn);
            return st;
        }

        st = RecoverStart(checkpoint_lsn, dblwr_checkpoint_lsn);
        if (!st.IsOk()) {
            return st;
        }
    }

    uint64_t db_size = 0;
    {
        std::unique_lock lk2(_random_access_shared_mutex);
        for (auto& rblock : _random_access_blocks) {
            db_size += rblock->file_size();
        }
    }

    _disable = 0;
    _db_size.store(db_size);
    LOG(NOTICE) << "open append db ok,"
        << " db_path:[" << _data_path
        << "] block_no:[" << _block_no
        << "] checkpoint_lsn:[" << *checkpoint_lsn
        << "] db_size:[" << db_size
        << "] fix_footer:[" << (fix_footer ? "true" : "false")
        << "] cost_time:[" << timer.u_elapsed()
        << "]";
    return st;
}

db::Status AppendDBEngine::Close(bool reset) {
    Status st;
    {
        std::unique_lock lk(_shared_mutex);
        _disable = 1;
        if (_write_block) {
            _write_block->Close();
            _write_block = nullptr;
            _rblock = nullptr;
        }
        if (_checkpoint_block) {
            _checkpoint_block->Close();
            _checkpoint_block = nullptr;
        }
        if (_slots_block) {
            _slots_block->Close();
            _slots_block = nullptr;
        }
    }
    {
        std::unique_lock lk(_random_access_shared_mutex);
        _random_access_blocks.clear();
        _random_access_blocks_map.clear();
        if (_recover_info) {
            _recover_info = nullptr;
        }
    }
    if (reset) {
        _disable = 1;
        _data_path.clear();
        _block_no = 0;
        _next_write_lsn = 0;
        _db_size.store(0);
        _random_access_blocks_size.store(0);
    }
    return st;
}

db::Status AppendDBEngine::FindLastCompleteLog(const RandomAccessBlockPtr& rblock,
        uint64_t file_size, uint64_t file_start_lsn, bool* found, bool* safe,
        uint64_t* record_off, db::LogHeader* log_header) {
    Status st;
    *found = false;
    *safe = false;
    if (file_size < db::kBlockHeaderSize + db::kLogHeaderSize) {
        return st;
    }

    const uint64_t max_window = file_size - db::kBlockHeaderSize;
    uint64_t initial_window = FLAGS_psvr_append_merge_max_buf_size > max_window / 2
            ? max_window : FLAGS_psvr_append_merge_max_buf_size * 2;
    if (initial_window < db::kReadBufMinSize) {
        initial_window = db::kReadBufMinSize;
    }
    if (initial_window > max_window) {
        initial_window = max_window;
    }

    AppendFixReader reader(rblock, file_size, file_start_lsn, initial_window);

    uint64_t window = initial_window;
    while (true) {
        const uint64_t window_start = window < max_window
                ? file_size - window : db::kBlockHeaderSize;
        uint64_t anchor_off = 0;
        db::LogHeader anchor_header;
        bool anchor_found = false;
        st = reader.FindNextRecord(window_start, &anchor_off, &anchor_header, &anchor_found);
        if (!st.IsOk()) {
            return st;
        }

        if (anchor_found) {
            uint64_t last_off = 0;
            db::LogHeader last_header;
            uint64_t chain_sum = 0;
            st = reader.FindLastRecord(anchor_off, anchor_header,
                    &last_off, &last_header, &chain_sum);
            if (!st.IsOk()) {
                return st;
            }

            const uint64_t sum = chain_sum - last_header.value_size;
            st = reader.CheckTailSafe(anchor_off, anchor_header, sum, safe);
            if (!st.IsOk()) {
                return st;
            }

            *found = true;
            *record_off = last_off;
            *log_header = last_header;
            return st;
        }

        if (window_start == db::kBlockHeaderSize) {
            break;
        }
        window = window > max_window / 2 ? max_window : window * 2;
    }
    return st;
}

db::Status AppendDBEngine::LocateSlotOffset(const RandomAccessBlockPtr& rblock,
        uint64_t file_size, const db::BlockFooterSlot* slots, bool* used,
        uint64_t* off, uint64_t* start_lsn, uint32_t* log_num) {
    Status st;
    *used = false;

    int32_t slot_idx = -1;
    for (int32_t i = static_cast<int32_t>(db::kBlockFooterSlotNum) - 1; i >= 0; --i) {
        if (slots[i].start_lsn != 0 || slots[i].offset != 0) {
            slot_idx = i;
            break;
        }
    }
    if (slot_idx < 0) {
        return st;
    }

    const db::BlockFooterSlot& slot = slots[slot_idx];
    if (slot.offset < db::kBlockHeaderSize ||
            slot.offset + db::kLogHeaderSize > file_size) {
        return st;
    }

    db::LogHeader header;
    Slice buf;
    st = rblock->Readx(slot.offset, db::kLogHeaderSize, &buf,
            reinterpret_cast<char*>(&header));
    if (!st.IsOk()) {
        return st;
    }
    if (buf.size() < db::kLogHeaderSize ||
            header.magic != db::kLogHeaderMagic ||
            db::check_is_corrupt(header, db::kLogHeaderSize) ||
            header.start_lsn != slot.start_lsn) {
        return st;
    }

    const uint64_t data_size = static_cast<uint64_t>(header.key_size) + header.value_size;
    if (slot.offset + db::kLogHeaderSize + data_size > file_size) {
        return st;
    }

    Slice key;
    Slice value;
    if (data_size > 0) {
        std::unique_ptr<char[]> data_buf(new char[data_size]);
        st = rblock->Readx(slot.offset + db::kLogHeaderSize, data_size, &buf,
                data_buf.get());
        if (!st.IsOk()) {
            return st;
        }
        if (buf.size() != data_size) {
            return st;
        }
        key = Slice(data_buf.get(), header.key_size);
        value = Slice(data_buf.get() + header.key_size, header.value_size);
    }
    if (!validate_append_redo_block(header, key, value).IsOk()) {
        return st;
    }

    *used = true;
    *off = slot.offset;
    *start_lsn = header.start_lsn;
    *log_num = slot.log_num;
    return st;
}

db::Status AppendDBEngine::TryFixBlock(RandomAccessBlockPtr rblock, bool* fix_footer) {
    Status st;
    Timer timer(base::Timer::STARTED);
    if (rblock->end_lsn() > 0) {
        return st;
    }
    if (fix_footer) {
        *fix_footer = true;
    }

    const char* file_name = rblock->file_name().c_str();
    int fd = open(file_name, O_RDWR, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        st.Reset(db::GetErrCode(), "open file:%s failed, %m", file_name);
        return st;
    }

    GuardFd guard_fd(fd);
    const uint64_t file_size = rblock->file_size();
    db::BlockFooterSlot slots[db::kBlockFooterSlotNum] = {};
    bool slots_found = false;
    if (_slots_block) {
        auto slots_st = _slots_block->Load(rblock->file_no(), rblock->start_lsn(),
                slots, &slots_found);
        LOG_IF(WARNING, !slots_st.IsOk()) << "load block slots failed, " << slots_st;
        if (!slots_st.IsOk()) {
            slots_found = false;
        }
    }
    bool found = false;
    uint64_t record_off = 0;
    db::LogHeader log_header;
    uint32_t log_num = 0;
    bool slots_used = false;
    uint64_t scan_off = db::kBlockHeaderSize;
    uint64_t scan_lsn = rblock->start_lsn();
    uint32_t base_log_num = 0;
    if (slots_found) {
        st = LocateSlotOffset(rblock, file_size, slots, &slots_used,
                &scan_off, &scan_lsn, &base_log_num);
        if (!st.IsOk()) {
            LOG(TRACE) << st;
            return st;
        }
    }

    bool use_iterate = slots_used;
    if (!slots_used) {
        use_iterate = !FLAGS_psvr_append_fix_footer_backward_scan ||
                file_size < FLAGS_psvr_append_fix_footer_backward_scan_min_file_size;
        if (!use_iterate) {
            bool safe = false;
            st = FindLastCompleteLog(rblock, file_size, rblock->start_lsn(),
                    &found, &safe, &record_off, &log_header);
            if (!st.IsOk()) {
                LOG(TRACE) << st;
                return st;
            }
            if (found && !safe) {
                use_iterate = true;
            }
        }
    }

    // log_num stays 0 in the backward-scan path; only the iterate path counts records.
    if (use_iterate) {
        found = false;
        record_off = 0;
        log_num = base_log_num;

        AppendReadBuf read_buf(FLAGS_psvr_append_open_read_buf_size);
        Slice buf;
        std::unique_ptr<char[]> data_buf;
        uint64_t data_buf_size = 0;
        db::LogHeader last_header;
        uint64_t next_lsn = scan_lsn;
        uint64_t off = scan_off;
        while (off < file_size) {
            st = read_buf.GetBufSize(rblock, off, db::kLogHeaderSize, &buf,
                    reinterpret_cast<char*>(&log_header));
            if (!st.IsOk()) {
                LOG(TRACE) << st;
                return st;
            }
            if (buf.size() < db::kLogHeaderSize) {
                break;
            }
            // A torn or corrupted record only ends the valid range and is truncated
            // below; an LSN discontinuity is the only hard error (see below).
            if (log_header.magic != db::kLogHeaderMagic) {
                break;
            }
            if (db::check_is_corrupt(log_header, db::kLogHeaderSize)) {
                break;
            }
            if (log_header.start_lsn != next_lsn) {
                st.Reset(Code::kCorrupted, "fix footer, file:%s log header start lsn:%lu != %lu discontinuous, off:%lu",
                        file_name, log_header.start_lsn, next_lsn, off);
                LOG(TRACE) << st;
                return st;
            }

            const uint64_t data_size = static_cast<uint64_t>(log_header.key_size) + log_header.value_size;
            const uint64_t next_off = off + db::kLogHeaderSize + data_size;
            if (next_off > file_size) {
                break;
            }
            Slice key;
            Slice value;
            if (data_size > 0) {
                if (data_size > data_buf_size) {
                    data_buf.reset(new char[data_size]);
                    data_buf_size = data_size;
                }
                st = read_buf.GetBufSizex(rblock, off + db::kLogHeaderSize, data_size, &buf,
                        data_buf.get());
                if (!st.IsOk()) {
                    LOG(TRACE) << st;
                    return st;
                }
                if (buf.size() != data_size) {
                    break;
                }
                key = Slice(data_buf.get(), log_header.key_size);
                value = Slice(data_buf.get() + log_header.key_size, log_header.value_size);
            }
            if (!validate_append_redo_block(log_header, key, value).IsOk()) {
                break;
            }

            ++log_num;
            record_off = off;
            last_header = log_header;
            next_lsn = log_header.end_lsn;
            off = next_off;
        }
        if (log_num > base_log_num) {
            log_header = last_header;
        }
        found = log_num > base_log_num;
    }
    if (!st.IsOk()) {
        LOG(TRACE) << st;
        return st;
    }

    uint64_t valid_size = db::kBlockHeaderSize;
    uint64_t truncate_size = file_size;
    if (found) {
        valid_size = record_off + db::kLogHeaderSize +
                static_cast<uint64_t>(log_header.key_size) + log_header.value_size;
        truncate_size = file_size > valid_size ? file_size - valid_size : 0;
    }
    if (found && slots_found) {
        uint32_t slot_num = 0;
        uint64_t last_start_lsn = rblock->start_lsn();
        uint64_t last_off = 0;
        for (uint32_t i = 0; i < db::kBlockFooterSlotNum; ++i) {
            const db::BlockFooterSlot& slot = slots[i];
            if (slot.start_lsn == 0 && slot.offset == 0) {
                continue;
            }
            if (slot.start_lsn < last_start_lsn || slot.start_lsn > log_header.end_lsn ||
                    slot.offset < db::kBlockHeaderSize ||
                    slot.offset + db::kLogHeaderSize > valid_size ||
                    slot.offset <= last_off) {
                break;
            }
            slots[slot_num++] = slot;
            last_start_lsn = slot.start_lsn;
            last_off = slot.offset;
        }
        for (uint32_t i = slot_num; i < db::kBlockFooterSlotNum; ++i) {
            slots[i] = db::BlockFooterSlot();
        }
        slots_found = slot_num > 0;
    }
    // Truncation is capped by psvr_append_fix_footer_max_truncate_size; beyond it the
    // block is reported as corrupted instead of silently losing too much data.
    if (truncate_size > FLAGS_psvr_append_fix_footer_max_truncate_size) {
        st.Reset(Code::kCorrupted, "fix footer, file:%s truncate size:%lu exceeds max:%lu, file_size:%lu valid_size:%lu",
                file_name, truncate_size, FLAGS_psvr_append_fix_footer_max_truncate_size,
                file_size, valid_size);
        LOG(ERROR) << st;
        return st;
    }

    // No valid record: treat the whole block as empty; Open2 removes it afterwards.
    if (!found) {
        if (file_size > 0) {
            int rc = db::ftruncate(fd, 0);
            if (rc) {
                st.Reset(db::GetErrCode(), "fix footer, truncate file:%s to zero failed, %m", file_name);
                LOG(TRACE) << st;
                return st;
            }
        }
        LOG(NOTICE) << "fix footer, truncate file size to zero,"
            << " file_name:[" << rblock->file_name()
            << "] file_size:[" << file_size
            << "] start_lsn:[" << rblock->start_lsn()
            << "] mode:[" << (slots_used ? "slots" : (use_iterate ? "iterate" : "backward"))
            << "] cost_time:[" << timer.u_elapsed()
            << "]";
        rblock->set_end_lsn(rblock->start_lsn());
        rblock->set_file_size(0);
        st.Reset(Code::kEmpty, "empty block file:%s", file_name);
        return st;
    }

    const uint64_t new_file_size = valid_size;
    int rc = db::ftruncate(fd, new_file_size);
    if (rc) {
        st.Reset(db::GetErrCode(), "fix footer, truncate file:%s to %lu failed, %m", file_name, new_file_size);
        LOG(TRACE) << st;
        return st;
    }

    LOG(NOTICE) << "fix footer, truncate file size,"
        << " file_name:[" << rblock->file_name()
        << "] file_size:[" << file_size
        << "] new_file_size:[" << new_file_size
        << "] record_off:[" << record_off
        << "] log_num:[" << log_num
        << "] start_lsn:[" << log_header.start_lsn
        << "] end_lsn:[" << log_header.end_lsn
        << "] mode:[" << (slots_used ? "slots" : (use_iterate ? "iterate" : "backward"))
        << "] cost_time:[" << timer.u_elapsed()
        << "]";

    st = db::Block::AppendFooter(true, fd, new_file_size,
            log_num, rblock->start_lsn(), log_header.end_lsn, log_header.start_lsn,
            (FLAGS_psvr_append_enable_slots && slots_found) ? slots : nullptr);
    if (!st.IsOk()) {
        st.ResetMsg("fix footer, append file:%s footer failed, off:%lu, usize:%u %m",
                file_name, new_file_size, db::kBlockFooterSize);
        LOG(TRACE) << st;
        return st;
    }

    rblock->set_end_lsn(log_header.end_lsn);
    rblock->set_file_size(new_file_size + db::kBlockFooterSize);
    if (slots_found) {
        auto rblock_slots = std::make_shared<db::BlockFooterSlots>();
        rblock_slots->Reset(slots);
        rblock->set_slots(rblock_slots);
    }
    return st;
}

db::Status AppendDBEngine::NewRandomAccessBlock(uint64_t fno, uint64_t start_lsn,
        RandomAccessBlockPtr* rblock, const db::BlockFooterSlotsPtr& write_slots) {
    Status st;
    std::string block_file_name = base::string_printf("%s/%lu%s",
            _data_path.c_str(), fno, db_ext_name);
    int fd = open(block_file_name.c_str(), O_RDONLY);
    if (fd < 0) {
        st.Reset(db::GetErrCode(), "open random block file:%s failed, %m", block_file_name.c_str());
        return st;
    }

    ssize_t file_size = 0;
    uint64_t end_lsn = 0;
    db::BlockFooterSlotsPtr slots = write_slots;
    while (start_lsn == 0) {
        GuardFdPtr guard_fd(&fd);
        if (!db::get_file_size(fd, &file_size)) {
            st.Reset(db::GetErrCode(), "get random block file:%s size failed, %m", block_file_name.c_str());
            return st;
        }

        if (file_size < db::kBlockFooterSize) {
            LOG(WARNING) << "random block file size to small,"
                << " file:[" << block_file_name
                << "] file_size:[" << file_size
                << "]";
            st.Reset(Code::kEmpty, "random block file:%s size:%ld maybe empty", block_file_name.c_str(), file_size);
            return st;
        }

        db::BlockFooter footer;
        st = db::preadx(fd, &footer, db::kBlockFooterSize, file_size - db::kBlockFooterSize);
        if (!st.IsOk()) {
            st.ResetMsg("read random block file:%s footer failed, fd:%d %m",
                    block_file_name.c_str(), fd);
            return st;
        }

        if (footer.magic == db::kBlockFooterMagic && !db::check_is_corrupt(footer, db::kBlockFooterSize)) {
            start_lsn = footer.start_lsn;
            end_lsn = footer.end_lsn;
            const uint64_t data_end = file_size - db::kBlockFooterSize;
            bool slots_valid = true;
            uint64_t last_start_lsn = footer.start_lsn;
            uint64_t last_off = 0;
            for (const auto& slot : footer.slots) {
                if (slot.start_lsn == 0 && slot.offset == 0) {
                    continue;
                }
                if (slot.start_lsn == 0 || slot.offset == 0 ||
                        slot.start_lsn < last_start_lsn || slot.start_lsn > footer.end_lsn ||
                        slot.offset < db::kBlockHeaderSize ||
                        slot.offset + db::kLogHeaderSize > data_end ||
                        slot.offset <= last_off) {
                    slots_valid = false;
                    break;
                }
                last_start_lsn = slot.start_lsn;
                last_off = slot.offset;
            }
            if (slots_valid) {
                slots = std::make_shared<db::BlockFooterSlots>();
                slots->Reset(footer.slots);
            } else {
                LOG(WARNING) << "random block footer slots invalid, ignore them,"
                    << " file:[" << block_file_name
                    << "]";
            }
            LOG(NOTICE) << "random block footer ok,"
                << " file:[" << block_file_name
                << "] file_size:[" << file_size
                << "] start_lsn:[" << start_lsn
                << "] end_lsn:[" << end_lsn
                << "]";
        } else {
            if (file_size <= db::kBlockHeaderSize) {
                LOG(WARNING) << "random block file size to small,"
                    << " file:[" << block_file_name
                    << "] file_size:[" << file_size
                    << "]";
                st.Reset(Code::kEmpty, "random block file:%s size:%ld maybe empty, %m", block_file_name.c_str(), file_size);
                return st;
            }
            db::BlockHeader header(0);
            st = db::preadx(fd, &header, db::kBlockHeaderSize, 0);
            if (!st.IsOk()) {
                st.ResetMsg("read random block file:%s header failed, fd:%d %m",
                        block_file_name.c_str(), fd);
                return st;
            }
            if (header.magic != db::kBlockHeaderMagic || db::check_is_corrupt(header, db::kBlockHeaderSize)) {
                st.Reset(Code::kMisMacth, "random block file:%s header check failed",
                        block_file_name.c_str());
                return st;
            }
            start_lsn = header.start_lsn;
            LOG(NOTICE) << "random block miss footer,"
                << " file:[" << block_file_name
                << "] file_size:[" << file_size
                << "] start_lsn:[" << start_lsn
                << "]";
        }
        fd = guard_fd.release();
        PSVR_ASSERT(fd > -1);
    }
    PSVR_ASSERT(start_lsn > 0);
    auto random_access_block = std::make_shared<db::RandomAccessBlock>(block_file_name, fno, fd, start_lsn);
    if (slots) {
        random_access_block->set_slots(slots);
    }
    if (end_lsn > 0) {
        random_access_block->set_end_lsn(end_lsn);
    }
    if (file_size > 0) {
        random_access_block->set_file_size(file_size);
    }
    {
        std::unique_lock lk(_random_access_shared_mutex);
        PSVR_ASSERT(_random_access_blocks.empty() || fno > _random_access_blocks.front()->file_no());
        _random_access_blocks.emplace_front(random_access_block);
        _random_access_blocks_map.emplace(fno, random_access_block);
    }
    if (rblock) {
        *rblock = random_access_block;
    }
    _random_access_blocks_size.fetch_add(1, std::memory_order_relaxed);
    LOG(TRACE) << "open random block ok,"
        << " fno:[" << fno
        << "] file_size:[" << file_size
        << "] start_lsn:[" << start_lsn
        << "] end_lsn:[" << end_lsn
        << "]";
    return st;
}

/* disable append db */
db::Status AppendDBEngine::Clear() {
    std::unique_lock lk(_shared_mutex);
    Status st;
    if (_disable == 2) {
        return st;
    }
    _disable = 1;
    _write_block = nullptr;
    _rblock = nullptr;
    {
        std::unique_lock slk(_random_access_shared_mutex);
        for (auto& rblock : _random_access_blocks) {
            st = rblock->Delete();
            if (!st.IsOk()) {
                return st;
            }
        }
        _random_access_blocks.clear();
        _random_access_blocks_map.clear();
        _recover_info = nullptr;
    }
    if (_checkpoint_block) {
        st = _checkpoint_block->Reset();
        if (st.IsOk()) {
            _checkpoint_block = nullptr;
        }
    }
    if (_slots_block) {
        st = _slots_block->Reset();
        if (!st.IsOk()) {
            return st;
        }
    }
    if (st.IsOk()) {
        _block_no = 0;
        _next_write_lsn = 0;
        _db_size.store(0);
        _random_access_blocks_size.store(0);
        _disable = 2;
    }
    return st;
}

void AppendDBEngine::Init(gaia_apply::lsn_t start_lsn) {
    PSVR_ASSERT(_next_write_lsn == 0);
    _next_write_lsn = start_lsn;
}

db::Status AppendDBEngine::SetCheckPointLsn(gaia_apply::lsn_t checkpoint_lsn,
        uint64_t seg_lowest_gc_lsn, bool cleanup_frozen) {
    Status st = _checkpoint_block->Update(checkpoint_lsn);
    if (st.IsAhead()) {
        st.Reset(Code::kOk, "set lower lsn to checkpoint");
    }
    if (st.IsOk()) {
        const size_t max_size = std::max(FLAGS_psvr_append_file_block_size, kBlockMinSize);
        if (_db_size.load() > max_size) {
            auto st2 = DeleteObsoleteFiles(seg_lowest_gc_lsn, cleanup_frozen);
            if (!st2.IsOk()) {
                LOG(WARNING) << "delete obsolete files failed,"
                    << " path:[" << _data_path
                    << "] " << st;
            }
        }
    } else {
        LOG(WARNING) << "set lsn to checkpoint failed," << st;
    }
    return st;
}

gaia_apply::lsn_t AppendDBEngine::GetCheckPointLsn() const {
    std::shared_lock slk(_shared_mutex);
    return _disable ? 0 : _checkpoint_block->lsn();
}

// in unique_lock with _shared_mutex
db::Status AppendDBEngine::NewWriteBlock(uint64_t start_lsn) {
    std::string block_file_name = base::string_printf("%s/%lu%s",
            _data_path.c_str(), _block_no, db_ext_name);
    Status st;
    if (_write_block) {
        st = _write_block->Close();
        if (!st.IsOk()) {
            return st;
        }
        {
            std::shared_lock slk(_random_access_shared_mutex);
            auto& last_rblock = _random_access_blocks.front();
            PSVR_ASSERT(last_rblock->start_lsn() == _write_block->start_lsn());
            PSVR_ASSERT_U(last_rblock == _rblock);
            last_rblock->set_file_size(_write_block->file_size());
            last_rblock->set_end_lsn(_write_block->write_end_lsn());
        }
        _write_block = nullptr;
        _rblock = nullptr;
        _db_size.fetch_add(db::kBlockFooterSize);
    }
    BlockPtr block = std::make_shared<db::Block>(block_file_name, _block_no);
    st = block->Open(start_lsn);
    if (st.IsOk()) {
        RandomAccessBlockPtr rblock = nullptr;
        auto slots = _slots_block->NewSlots();
        st = NewRandomAccessBlock(block->file_no(), start_lsn, &rblock, slots);
        if (!st.IsOk()) {
            return st;
        }
        block->set_slots(slots);
        if (FLAGS_psvr_append_enable_slots) {
            auto slots_st = _slots_block->Update(block->file_no(), start_lsn);
            LOG_IF(WARNING, !slots_st.IsOk()) << "update block slots failed, " << slots_st;
        }
        _write_block = block;
        _rblock = rblock;
        ++_block_no;
        _db_size.fetch_add(db::kBlockHeaderSize);
    }
    return st;
}

// in unique_lock with _shared_mutex
db::Status AppendDBEngine::DoAppend(BlockPtr block,
        const Slice& header, const Slice& key, const Slice& value, size_t write_size,
        uint64_t start_lsn, uint64_t end_lsn,
        uint64_t* fno, uint64_t* off, bool sync) {
    Timer timer(base::Timer::STARTED);
    struct iovec iov[3];
    iov[0].iov_base = const_cast<void*>(reinterpret_cast<const void*>(header.data()));
    iov[0].iov_len = header.size();
    iov[1].iov_base = const_cast<void*>(reinterpret_cast<const void*>(key.data()));
    iov[1].iov_len = key.size();
    iov[2].iov_base = const_cast<void*>(reinterpret_cast<const void*>(value.data()));
    iov[2].iov_len = value.size();
    auto st = block->Append(iov, 3, write_size, start_lsn, end_lsn, fno, off, sync);
    if (st.IsOk()) {
        stat_append_value(stat_db_write_lat, timer.u_elapsed());
        stat_append_value(stat_db_write_bw, write_size);
    } else {
        stat_append_value(stat_db_write_io_err_count, 1);
    }
    return st;
}

db::Status AppendDBEngine::Append(const db::LogHeader& log_header,
        const Slice& key, const Slice& value,
        uint64_t* fno, uint64_t* off, bool sync) {
    Status st;
    const size_t max_size = std::max(FLAGS_psvr_append_file_block_size, kBlockMinSize);
    base::Slice header(reinterpret_cast<const char*>(&log_header), db::kLogHeaderSize);
    size_t write_size = header.size() + key.size() + value.size();
    std::unique_lock lk(_shared_mutex);
    if (_disable) {
        st.Reset(Code::kInvalid, "db is disabled");
        return st;
    }
    if (!_write_block ||
            _write_block->file_size() + write_size + db::kBlockFooterSize > max_size) {
        st = NewWriteBlock(log_header.start_lsn);
        if (!st.IsOk()) {
            return st;
        }
    }
    if (log_header.start_lsn != _next_write_lsn) {
        st.Reset(Code::kMisMacth, "append lsn mismatch, last:%lu, write:%ld",
                _next_write_lsn, log_header.start_lsn);
        return st;
    }
    st = DoAppend(_write_block, header, key, value, write_size,
            log_header.start_lsn, log_header.end_lsn, fno, off, sync);
    if (st.IsOk()) {
        _db_size.fetch_add(write_size);
        _next_write_lsn = log_header.end_lsn;
        _rblock->set_end_lsn(_next_write_lsn);
        _rblock->set_file_size(_write_block->file_size());
        const uint64_t slot_size = max_size / db::kBlockFooterSlotNum;
        const uint64_t slot = *off / slot_size;
        if (FLAGS_psvr_append_enable_slots && *off > slot_size &&
                slot < db::kBlockFooterSlotNum &&
                _slots_block->AddSlot(static_cast<uint32_t>(slot), log_header.start_lsn, *off,
                        _write_block->log_num() - 1)) {
            auto slots_st = _slots_block->Update(_write_block->file_no(),
                    _write_block->start_lsn());
            LOG_IF(WARNING, !slots_st.IsOk()) << "update block slots failed, " << slots_st;
        }
    }
    return st;
}

db::Status AppendDBEngine::BatchAppend(const std::vector<db::LogHeader>& log_headers,
        const std::vector<Slice>& keys, const std::vector<Slice>& values,
        std::vector<uint64_t>* fnos, std::vector<uint64_t>* offs) {
    Status st;
    const size_t size = log_headers.size();
    if (size == 0) {
        return st;
    }

    PSVR_ASSERT(keys.size() == size);
    PSVR_ASSERT(values.size() == size);
    PSVR_ASSERT(fnos->size() == size);
    PSVR_ASSERT(offs->size() == size);

    PSVR_ASSERT(size <= IOV_MAX / 3);

    size_t write_size = 0;
    std::vector<size_t> relative_offs(size);
    std::vector<struct iovec> iovs;
    iovs.reserve(size * 3);
    for (size_t i = 0; i < size; ++i) {
        relative_offs[i] = write_size;
        write_size += db::kLogHeaderSize + keys[i].size() + values[i].size();

        iovs.push_back({const_cast<db::LogHeader*>(&log_headers[i]), db::kLogHeaderSize});
        iovs.push_back({const_cast<char*>(keys[i].data()), keys[i].size()});
        iovs.push_back({const_cast<char*>(values[i].data()), values[i].size()});
    }

    Timer timer(base::Timer::STARTED);
    std::unique_lock lk(_shared_mutex);
    if (_disable) {
        st.Reset(Code::kInvalid, "db is disabled");
        return st;
    }

    uint64_t next_lsn = _next_write_lsn;
    for (size_t i = 0; i < size; ++i) {
        if (log_headers[i].start_lsn != next_lsn) {
            st.Reset(Code::kMisMacth, "append lsn mismatch, idx:%lu, last:%lu, write:%lu",
                    i, next_lsn, log_headers[i].start_lsn);
            return st;
        }
        next_lsn = log_headers[i].end_lsn;
    }

    const size_t max_size = std::max(FLAGS_psvr_append_file_block_size, kBlockMinSize);
    if (!_write_block ||
            _write_block->file_size() + write_size + db::kBlockFooterSize > max_size) {
        st = NewWriteBlock(log_headers.front().start_lsn);
        if (!st.IsOk()) {
            return st;
        }
    }

    uint64_t fno = 0;
    uint64_t off = 0;
    st = _write_block->Append(iovs.data(), static_cast<int>(iovs.size()), write_size,
            log_headers.front().start_lsn, log_headers.back().end_lsn,
            &fno, &off, true, static_cast<uint32_t>(size), log_headers.back().start_lsn);
    if (!st.IsOk()) {
        stat_append_value(stat_db_write_io_err_count, 1);
        return st;
    }

    stat_append_value(stat_db_write_lat, timer.u_elapsed());
    stat_append_value(stat_db_write_bw, write_size);
    const uint64_t slot_size = max_size / db::kBlockFooterSlotNum;
    bool slots_changed = false;
    const uint32_t base_log_num = _write_block->log_num() - static_cast<uint32_t>(size);
    for (size_t i = 0; i < size; ++i) {
        (*fnos)[i] = fno;
        (*offs)[i] = off + relative_offs[i];
        const uint64_t slot = (*offs)[i] / slot_size;
        if (FLAGS_psvr_append_enable_slots && (*offs)[i] > slot_size &&
                slot < db::kBlockFooterSlotNum) {
            slots_changed |= _slots_block->AddSlot(static_cast<uint32_t>(slot),
                    log_headers[i].start_lsn, (*offs)[i],
                    base_log_num + static_cast<uint32_t>(i));
        }
    }
    if (slots_changed) {
        auto slots_st = _slots_block->Update(_write_block->file_no(),
                _write_block->start_lsn());
        LOG_IF(WARNING, !slots_st.IsOk()) << "update block slots failed, " << slots_st;
    }

    _db_size.fetch_add(write_size);
    _next_write_lsn = log_headers.back().end_lsn;
    _rblock->set_end_lsn(_next_write_lsn);
    _rblock->set_file_size(_write_block->file_size());
    return st;
}

db::Status AppendDBEngine::Read(uint64_t fno, uint64_t off,
        Slice* data, char* buf, uint32_t buf_size) {
    Status st;
    RandomAccessBlockPtr rblock = nullptr;
    {
        std::shared_lock slk(_random_access_shared_mutex);
        for (auto& rb : _random_access_blocks) {
            if (rb->file_no() == fno) {
                rblock = rb;
                break;
            }
        }
    }
    if (!rblock) {
        st.Reset(Code::kMisMacth, "not found random block, fno:%lu", fno);
        return st;
    }

    Timer timer(base::Timer::STARTED);
    st = rblock->Read(off, buf_size, data, buf);
    if (st.IsOk()) {
        stat_append_value(stat_db_read_lat, timer.u_elapsed());
        stat_append_value(stat_db_read_bw, buf_size);
    } else {
        stat_append_value(stat_db_read_io_err_count, 1);
    }
    return st;
}

db::Status AppendDBEngine::RemoveEmptyBlock(uint64_t fno) {
    Status st;
    std::string block_file_name = base::string_printf("%s/%lu%s",
            _data_path.c_str(), fno, db_ext_name);
    std::error_code ec;
    bool ret = std::filesystem::remove(block_file_name, ec);
    if (ec) {
        st.Reset(db::GetErrCode(), "remove empty block file:%s failed, %s",
                block_file_name.c_str(), ec.message().c_str());
        return st;
    }
    LOG(NOTICE) << "remove empty block file ok,"
        << " file:[" << block_file_name
        << "] file_exists:[" << ret
        << "]";
    st = db::sync_directoryx(_data_path.c_str());
    return st;
}

db::Status AppendDBEngine::DeleteObsoleteFiles(uint64_t seg_lowest_gc_lsn,
        bool cleanup_frozen) {
    Status st;
    if (cleanup_frozen) {
        return st;
    }
    if (const auto num = _random_access_blocks_size.load(std::memory_order_relaxed);
            num < 2) {
        st.ResetMsg("random block file num:%lu too few", num);
        return st;
    }
    const uint64_t delete_obsolete_lsn = std::min(_checkpoint_block->delete_obsolete_lsn(), seg_lowest_gc_lsn);
    LOG(INFO) << "delete obsolte files,"
        << " delete_obsolete_lsn:[" << _checkpoint_block->delete_obsolete_lsn()
        << "] seg_lowest_gc_lsn:[" << seg_lowest_gc_lsn
        << "]";
    std::list<RandomAccessBlockPtr> to_delete;
    size_t to_delete_n = 0;
    {
        std::unique_lock lk(_random_access_shared_mutex);
        if (_recover_info || _random_access_blocks.empty()) {
            st.ResetMsg("in recover or empty random block file");
            return st;
        }

        auto front = _random_access_blocks.front();
        while (!_random_access_blocks.empty()) {
            auto back = _random_access_blocks.back();
            if (back == front) {
                break;
            }
            PSVR_ASSERT(back->end_lsn() > 0);
            if (delete_obsolete_lsn <= back->end_lsn()) {
                break;
            }

            to_delete.push_front(back);
            ++to_delete_n;
            _random_access_blocks.pop_back();
            _random_access_blocks_map.erase(back->file_no());
        }

        if (to_delete_n == 0) {
            st.ResetMsg("can not get to delete random block");
            return st;
        }
    }

    while (to_delete_n > 0) {
        auto rblock = to_delete.back();
        st = rblock->Delete();
        if (!st.IsOk()) {
            std::unique_lock lk(_random_access_shared_mutex);
            for (auto& roll : to_delete) {
                _random_access_blocks_map.emplace(roll->file_no(), roll);
            }
            _random_access_blocks.splice(_random_access_blocks.end(), to_delete);
            return st;
        }
        to_delete.pop_back();
        --to_delete_n;
        _db_size.fetch_sub(rblock->file_size());
        _random_access_blocks_size.fetch_sub(1, std::memory_order_relaxed);
    }
    return st;
}

AppendDBEngine::RandomAccessBlockPtr AppendDBEngine::FindRandomBLockAndCheck(uint64_t fno, uint64_t seek_lsn) {
    RandomAccessBlockPtr rblock = nullptr;
    auto it = _random_access_blocks_map.find(fno);
    if (it != _random_access_blocks_map.end()) {
        rblock = it->second;
        if (seek_lsn >= rblock->start_lsn() && seek_lsn <  rblock->end_lsn()) {
            return rblock;
        }
    }
    return nullptr;
}

AppendDBEngine::RandomAccessBlockPtr AppendDBEngine::FindRandomBLock(uint64_t seek_lsn) {
    RandomAccessBlockPtr rblock = nullptr;
    auto it = _random_access_blocks.begin();
    while (it != _random_access_blocks.end()) {
        rblock = *it;
        if (seek_lsn >= rblock->start_lsn()) {
            return rblock;
        }
        ++it;
    }
    return nullptr;
}

void AppendDBEngine::FetchNextDataLog(const RandomAccessBlockPtr& rblock, uint64_t off,
        bool is_current_rblock, db::LogHeader* log_header, uint64_t* data_off,
        AppendReadBuf* read_buf) {
    Status st;
    int32_t empty_num = 0;
    const int32_t max_empty_num = FLAGS_psvr_append_recover_max_empty_block_num;
    // A sealed block ends with a footer, the current write block has none yet.
    const uint64_t footer_size = is_current_rblock ? 0 : db::kBlockFooterSize;
    *data_off = off;
    // Merge the empty log blocks that follow the block the caller already read, so the
    // returned LSN range stays contiguous. The caller has already read a valid log
    // header, so a read error here only loses the merge and does not affect the current
    // read: it is ignored and just stops the skipping.
    while (empty_num++ < max_empty_num) {
        if (off + footer_size >= rblock->file_size()) {
            break;
        }
        db::LogHeader h;
        Slice buf;
        if (read_buf) {
            st = read_buf->GetBufSize(rblock, off, db::kLogHeaderSize, &buf,
                    reinterpret_cast<char*>(&h));
            if (!st.IsOk()) {
                break;
            }
        } else {
            st = rblock->Read(off, db::kLogHeaderSize, &buf, reinterpret_cast<char*>(&h));
            if (!st.IsOk()) {
                break;
            }
        }
        if (buf.size() < db::kLogHeaderSize) {
            break;
        }
        if (h.magic != db::kLogHeaderMagic) {
            break;
        }
        off += db::kLogHeaderSize;
        *log_header = h;
        *data_off = off;
        // Return the block when it carries data, or when the empty-block skip limit is
        // reached: hand the empty block back so the caller advances past the skipped
        // range instead of re-reading it.
        if (h.key_size + h.value_size > 0) {
            break;
        }
    }
}

db::Status AppendDBEngine::FetchRedoLog(uint64_t seek_lsn, db::LogHeader* log_header,
        Slice* key, Slice* value, char** data,
        uint64_t& fno, uint64_t& offset, AppendReadBuf* read_buf) {
    Status st;
    Timer timer(base::Timer::STARTED);
    stat_append_value(stat_fetch_redo_log_count, 1);
    RandomAccessBlockPtr rblock = nullptr;
    bool is_current_rblock = false;
#ifdef GTEST
    LOG(NOTICE) << "fetch redo log, seek_lsn:" << seek_lsn
        << ", fno:" << fno << ", offset:" << offset;
#endif
    *data = nullptr;
    {
        std::shared_lock slk(_random_access_shared_mutex);
        if (fno > 0) {
            rblock = FindRandomBLockAndCheck(fno, seek_lsn);
        }
        if (!rblock) {
            rblock = FindRandomBLock(seek_lsn);
        }
        is_current_rblock = (rblock != nullptr && rblock == _rblock);
    }
    if (!rblock) {
        st.Reset(Code::kNotFound, "fetch log, not found random block, seek_lsn:%lu, fno:%lu, offset:%lu",
                seek_lsn, fno, offset);
        return st;
    }

    PSVR_ASSERT(seek_lsn >= rblock->start_lsn());

    if (rblock->file_no() != fno && offset) {
        offset = 0;
    }

    const uint64_t footer_size = is_current_rblock ? 0 : db::kBlockFooterSize;
    const uint64_t data_end = rblock->file_size() > footer_size
            ? rblock->file_size() - footer_size : 0;
    AppendSeekLocator locator(rblock, data_end, rblock->start_lsn(),
            FLAGS_psvr_append_seek_anchor_chunk_size);

    bool is_reseek = false;
    bool from_slot = false;
    bool tried_anchor = false;
    bool off_miss = false;
    uint64_t slot_lsn = 0;
    if (offset == 0) {
        if (seek_lsn == rblock->start_lsn()) {
            offset = db::kBlockHeaderSize;
            is_reseek = true;
        } else {
            stat_fetch_off_miss(&off_miss);
            from_slot = rblock->FindSlotOffset(seek_lsn, &offset, &slot_lsn);
            if (from_slot) {
                locator.LocateFrom(offset, slot_lsn, seek_lsn, &offset);
            } else {
                tried_anchor = locator.Locate(seek_lsn, &offset);
                if (!tried_anchor || offset == db::kBlockHeaderSize) {
                    offset = db::kBlockHeaderSize;
                    is_reseek = true;
                }
            }
        }
    }

    auto reposition_fn = [&]() {
        stat_fetch_off_miss(&off_miss);
        if (!from_slot && rblock->FindSlotOffset(seek_lsn, &offset, &slot_lsn)) {
            from_slot = true;
            locator.LocateFrom(offset, slot_lsn, seek_lsn, &offset);
        } else if (!tried_anchor && locator.Locate(seek_lsn, &offset)) {
            tried_anchor = true;
        } else {
            offset = db::kBlockHeaderSize;
            is_reseek = true;
        }
    };

    Slice buf;
    while (true) {
        if (read_buf) {
            st = read_buf->GetBufSize(rblock, offset, db::kLogHeaderSize, &buf,
                    reinterpret_cast<char*>(log_header), false);
        } else {
            st = rblock->Read(offset, db::kLogHeaderSize, &buf, reinterpret_cast<char*>(log_header));
        }
        if (!st.IsOk()) {
            return st;
        }
        if (buf.size() < db::kLogHeaderSize) {
            if (is_reseek) {
                st.Reset(Code::kMissData, "fetch log, read size:%u lower than log header size:%u, seek_lsn:%lu",
                        buf.size(), db::kLogHeaderSize, seek_lsn);
                return st;
            }
            reposition_fn();
            continue;
        }
        if (log_header->magic != db::kLogHeaderMagic) {
            if (is_reseek) {
                st.Reset(Code::kCorrupted, "fetch log, log header magic:%x not right, db:%lu off:%lu, seek_lsn:%lu",
                        log_header->magic, rblock->file_no(), offset, seek_lsn);
                return st;
            }
            LOG(WARNING) << "fetch log, log header magic mismatch,"
                << " db:[" << rblock->file_name()
                << "] off:[" << offset
                << "] seek_lsn:[" << seek_lsn
                << "] " << (*log_header);
            reposition_fn();
            continue;
        }
        if (log_header->start_lsn > seek_lsn) {
            if (is_reseek) {
                st.Reset(Code::kEmpty, "fetch log, seek lsn:%lu not in db:%lu",
                        seek_lsn, rblock->file_no());
                return st;
            }
            reposition_fn();
            continue;
        } else if (log_header->end_lsn <= seek_lsn) {
            offset += db::kLogHeaderSize + log_header->key_size + log_header->value_size;
            continue;
        } else {
            PSVR_ASSERT(log_header->start_lsn <= seek_lsn && seek_lsn < log_header->end_lsn);

            const uint64_t first_start_lsn = log_header->start_lsn;

            offset += db::kLogHeaderSize;
            if (log_header->key_size + log_header->value_size == 0) {
                uint64_t data_off = 0;
                FetchNextDataLog(rblock, offset, is_current_rblock,
                        log_header, &data_off, read_buf);
                offset = data_off;
            }

            const auto key_size = log_header->key_size;
            const auto value_size = log_header->value_size;
            const auto data_size = key_size + value_size;
            if (data_size > 0) {
                *data = static_cast<char*>(std::malloc(data_size * sizeof(char)));
                if (!*data) {
                    st.Reset(Code::kSysError, "fetch log to malloc size:%u failed", data_size);
                    return st;
                }

                if (read_buf) {
                    st = read_buf->GetBufSizex(rblock, offset, data_size, &buf, *data);
                } else {
                    st = rblock->Readx(offset, data_size, &buf, *data);
                }
                if (!st.IsOk()) {
                    return st;
                }
                if (buf.size() < data_size) {
                    st.Reset(db::GetErrCode(), "recover to read data size:%d small, expected:%d, fno:%lu, off:%lu",
                            buf.size(), data_size, rblock->file_no(), offset);
                    return st;
                }

                *key = Slice(buf.data(), key_size);
                *value = Slice(buf.data() + key_size, value_size);
            } else {
                key->clear();
                value->clear();
            }

            offset += data_size;
            fno = rblock->file_no();

            if (!is_current_rblock && offset + db::kBlockFooterSize >= rblock->file_size()) {
                offset = 0;
                ++fno;
            }

            // Cover the skipped empty range so the returned LSN range stays contiguous.
            if (log_header->start_lsn != first_start_lsn) {
                log_header->start_lsn = first_start_lsn;
                db::make_checksum(log_header, db::kLogHeaderSize);
            }

            stat_append_value(stat_fetch_redo_log_lat, timer.u_elapsed());
            return st;
        }
    }
}

db::Status AppendDBEngine::RecoverStart(uint64_t* checkpoint_lsn, gaia_apply::lsn_t dblwr_checkpoint_lsn) {
    Status st;
    Timer timer(base::Timer::STARTED);
    const auto seek_lsn = std::max(*checkpoint_lsn, dblwr_checkpoint_lsn);
    std::unique_lock lk(_random_access_shared_mutex);
    _recover_info.reset(new RecoverInfo);
    _recover_info->iter = _random_access_blocks.begin();
    _recover_info->lsn = seek_lsn;
    _recover_info->off = db::kBlockHeaderSize;
    _recover_info->seek_off = 0;
    _recover_info->random_block_size = 0;
    _recover_info->next_lsn = 0;
    _recover_info->next_off = 0;
    _recover_info->start_time = base::cpuwide_time_us();
    _recover_info->start_lsn = seek_lsn;
    _recover_info->read_num = 0;

    _recover_info->read_buf =
            std::make_shared<AppendReadBuf>(FLAGS_psvr_append_recover_read_buf_size);

    while (_recover_info->iter != _random_access_blocks.end()) {
        auto rblock = *_recover_info->iter;
        if (rblock->start_lsn() <= seek_lsn) {
            ++_recover_info->random_block_size;
            break;
        }
        ++_recover_info->iter;
        ++_recover_info->random_block_size;
    }

    if (_recover_info->iter == _random_access_blocks.end()) {
        st.Reset(Code::kMisMacth, "recover seek:%lu fail, not found", seek_lsn);
        return st;
    }

    auto rblock = *_recover_info->iter;
    if (seek_lsn < rblock->start_lsn() || rblock->end_lsn() < seek_lsn) {
        st.Reset(Code::kMisMacth, "recover seek:%lu random block:%lu-%lu fail",
                seek_lsn, rblock->start_lsn(), rblock->end_lsn());
        return st;
    }

    if (rblock->file_size() < db::kBlockFooterSize + db::kBlockHeaderSize) {
        st.Reset(Code::kInvalid, "recover seet random block:%lu size:%lu invalid",
                rblock->file_no(), rblock->file_size());
        return st;
    }

    const uint64_t rblock_size = rblock->file_size() - db::kBlockFooterSize;
    bool use_slot = false;
    uint64_t slot_off = 0;
    uint64_t anchor_off = 0;
    if (seek_lsn == rblock->end_lsn()) {
        *checkpoint_lsn = rblock->end_lsn();
        _recover_info->seek_off = rblock_size;
    } else if (seek_lsn == rblock->start_lsn()) {
        _recover_info->off = db::kBlockHeaderSize;
    } else {
        AppendSeekLocator locator(rblock, rblock_size, rblock->start_lsn(),
                FLAGS_psvr_append_seek_anchor_chunk_size);
        uint64_t slot_lsn = 0;
        if (rblock->FindSlotOffset(seek_lsn, &slot_off, &slot_lsn)) {
            use_slot = true;
            _recover_info->off = slot_off;
            locator.LocateFrom(slot_off, slot_lsn, seek_lsn, &_recover_info->off);
        } else if (locator.Locate(seek_lsn, &anchor_off)) {
            _recover_info->off = anchor_off;
        }
    }

    db::LogHeader log_header;
    Slice buf;
    while (_recover_info->off < rblock_size) {
        st = _recover_info->read_buf->GetBufSize(rblock, _recover_info->off, db::kLogHeaderSize,
                &buf, reinterpret_cast<char*>(&log_header), true);
        if (!st.IsOk()) {
            return st;
        }
        if (buf.size() < db::kLogHeaderSize) {
            st.Reset(Code::kMissData, "recover, read size:%u lower than log header size:%u",
                    buf.size(), db::kLogHeaderSize);
            return st;
        }
        if (log_header.magic != db::kLogHeaderMagic) {
            st.Reset(Code::kCorrupted, "recover, log header magic:%x not right, db:%lu off:%lu",
                    log_header.magic, rblock->file_no(), _recover_info->off);
            return st;
        }
        if (seek_lsn < log_header.end_lsn) {
            // align checkpoint_lsn to log block start lsn
            *checkpoint_lsn = log_header.start_lsn;
            _recover_info->seek_off = _recover_info->off;
            break;
        }

        const uint64_t data_size = static_cast<uint64_t>(log_header.key_size) +
                log_header.value_size;
        _recover_info->read_buf->Skip(data_size);
        _recover_info->off += db::kLogHeaderSize + data_size;
    }
    _recover_info->read_buf->Reset();

    if (_recover_info->seek_off == 0) {
        LOG(WARNING) << "recover to seek failed,"
            << " path:[" << _data_path
            << "] fno:[" << rblock->file_no()
            << "] start_lsn:[" << rblock->start_lsn()
            << "] end_lsn:[" << rblock->end_lsn()
            << "] seek_lsn:[" << seek_lsn
            << "] file_size:[" << rblock->file_size()
            << "] seek_off:[" << _recover_info->off
            << "]";
        st.Reset(Code::kMissData, "recover to seek failed, not found lsn:%lu in random block:%lu",
                seek_lsn, rblock->file_no());
        return st;
    }

    LOG(NOTICE) << "recover to seek ok,"
        << " path:[" << _data_path
        << "] fno:[" << rblock->file_no()
        << "] start_lsn:[" << rblock->start_lsn()
        << "] seek_lsn:[" << seek_lsn
        << "] seek_off:[" << _recover_info->off
        << "] use_slot:[" << (use_slot ? 1 : 0)
        << "] slot_off:[" << slot_off
        << "] use_anchor:[" << (anchor_off > db::kBlockHeaderSize ? 1 : 0)
        << "] anchor_off:[" << anchor_off
        << "] cost_time:[" << timer.u_elapsed()
        << "] random_block_size:[" << _recover_info->random_block_size
        << "]";
    return st;
}

db::Status AppendDBEngine::RecoverFinish() {
    Status st;
    std::unique_lock lk(_random_access_shared_mutex);
    if (_recover_info) {
        int64_t cost = base::cpuwide_time_us() - _recover_info->start_time;
        LOG(NOTICE) << "finish recovery,"
            << " path:[" << _data_path
            << "] start_lsn:[" << _recover_info->start_lsn
            << "] read_num:[" << _recover_info->read_num
            << "] cost_us:[" << cost
            << "]";
        _recover_info = nullptr;
    }
    return st;
}

db::Status AppendDBEngine::PreRecoverNextLog(uint64_t* next_lsn) {
    std::unique_lock lk(_random_access_shared_mutex);
    Status st;
    if (!_recover_info) {
        st.Reset(Code::kInvalid, "recover not start on prepare recover next log");
        return st;
    }
    if (_recover_info->next_lsn == 0) {
        st.Reset(Code::kInvalid, "last recover log status not ok");
        return st;
    }

    *next_lsn = _recover_info->next_lsn;

    _recover_info->off = _recover_info->next_off;
    _recover_info->next_lsn = 0;

    return st;
}

db::Status AppendDBEngine::RecoverLog(db::LogHeader* log_header,
        Slice* key, Slice* value, char** data,
        uint64_t* fno, uint64_t* off) {
    Status st;
    Timer timer(base::Timer::STARTED);
    *data = nullptr;

    // Only the recover thread advances _recover_info, but _random_access_blocks
    // may be touched by other paths. Snapshot the read position and hold a ref to
    // the block under the lock, then do the disk read with the lock released so
    // that other engine operations are not blocked behind the I/O.
    RandomAccessBlockPtr rblock;
    uint64_t read_off = 0;
    {
        std::unique_lock lk(_random_access_shared_mutex);
        if (!_recover_info) {
            st.Reset(Code::kInvalid, "recover not start on recover log");
            return st;
        }

        if (_recover_info->random_block_size == 0) {
            st.Reset(Code::kEof, "not more random block files to recover");
            return st;
        }

        rblock = *_recover_info->iter;
        if (rblock->end_lsn() < rblock->start_lsn()) {
            st.Reset(Code::kInvalid, "rblock:%lu lsn range:[%lu,%lu] invalid",
                    rblock->file_no(), rblock->start_lsn(), rblock->end_lsn());
            return st;
        }

        read_off = _recover_info->off;

        ++_recover_info->read_num;
    }

    uint32_t log_block_n = 0;
    uint64_t first_start_lsn = 0;
    const uint32_t max_empty_num = std::max(1, FLAGS_psvr_append_recover_max_empty_block_num);
    while (log_block_n < max_empty_num) {
        *fno = rblock->file_no();
        *off = read_off;
        // Read into a local header: only the block finally returned is written back to
        // *log_header / *fno / *off.
        uint64_t next_off = 0;
        st = RecoverLogFromRBlock(rblock, read_off, log_header, key, value, data, &next_off);
        if (!st.IsEof()) {
            if (st.IsOk()) {
                if (log_block_n == 0) {
                    first_start_lsn = log_header->start_lsn;
                }
                ++log_block_n;

                read_off = next_off;
                if (log_header->key_size + log_header->value_size == 0) {
                    // A block without data: skip it (within the limit) and read the next.
                    if (*data) {
                        std::free(*data);
                        *data = nullptr;
                    }
                    key->clear();
                    value->clear();
                    continue;
                }
            }
            // read error Or is not empty log_header
            break;
        } else {
            // Reach the end of current block file, move to the next one if any.
            std::unique_lock lk(_random_access_shared_mutex);
            --_recover_info->random_block_size;
            if (_recover_info->random_block_size == 0) {
                break;
            }
            --_recover_info->iter;
            rblock = *_recover_info->iter;
            read_off = db::kBlockHeaderSize;
        }
    }

    if (log_block_n > 0) {
        PSVR_ASSERT(first_start_lsn > 0);
        // Cover the skipped empty range so the returned LSN range stays contiguous.
        if (log_header->start_lsn != first_start_lsn) {
            log_header->start_lsn = first_start_lsn;
            db::make_checksum(log_header, db::kLogHeaderSize);
        }

        {
            std::unique_lock lk(_random_access_shared_mutex);
            _recover_info->next_lsn = log_header->end_lsn;
            _recover_info->next_off = read_off;
        }

        if (!st.IsOk()) {
            st.Reset(Code::kOk);
        }
        stat_append_value(stat_recover_log_lat, timer.u_elapsed());
    }
    return st;
}

db::Status AppendDBEngine::RecoverLogFromRBlock(RandomAccessBlockPtr rblock, uint64_t off,
        db::LogHeader* log_header, Slice* key, Slice* value, char** data,
        uint64_t* next_off) {
    Status st;

    // The read-ahead buffer lives in _recover_info, which Close/Clear/RecoverFinish may
    // reset at any time. Grab a local ref under the lock, then use it with the lock
    // released so the buffer cannot be destroyed under the ongoing read.
    std::shared_ptr<AppendReadBuf> read_buf;
    {
        std::shared_lock lk(_random_access_shared_mutex);
        if (_recover_info) {
            read_buf = _recover_info->read_buf;
        }
    }
    if (!read_buf) {
        st.Reset(Code::kInvalid, "recover read buf is not ready");
        return st;
    }

    if (off + db::kBlockFooterSize == rblock->file_size()) {
        st.Reset(Code::kEof, "recover reach eof, off:%lu, file size:%lu, fno:%lu",
                off, rblock->file_size(), rblock->file_no());
        return st;
    }

    // log header
    Slice hbuf;
    st = read_buf->GetBufSizex(rblock, off, db::kLogHeaderSize, &hbuf,
            reinterpret_cast<char*>(log_header));
    if (!st.IsOk()) {
        return st;
    }
    if (hbuf.size() < db::kLogHeaderSize) {
        st.Reset(db::GetErrCode(), "recover read log header short, size:%lu, off:%lu, fno:%lu",
                hbuf.size(), off, rblock->file_no());
        return st;
    }
    off += db::kLogHeaderSize;

    if (log_header->magic != db::kLogHeaderMagic) {
        st.Reset(Code::kCorrupted, "recover log header magic:%x not right, fno:%lu, off:%lu",
                log_header->magic, rblock->file_no(), off);
        return st;
    }

    const auto key_size = log_header->key_size;
    const auto value_size = log_header->value_size;
    const auto data_size = key_size + value_size;
    if (data_size > 0) {
        *data = static_cast<char*>(std::malloc(data_size * sizeof(char)));
        if (!*data) {
            st.Reset(Code::kSysError, "recover to malloc size:%u failed", data_size);
            return st;
        }
        Slice dbuf;
        st = read_buf->GetBufSizex(rblock, off, data_size, &dbuf, *data);
        if (!st.IsOk()) {
            return st;
        }
        if (dbuf.size() < data_size) {
            st.Reset(db::GetErrCode(), "recover read log data short, size:%lu, expected:%u, off:%lu, fno:%lu",
                    dbuf.size(), data_size, off, rblock->file_no());
            return st;
        }
        *key = Slice(*data, key_size);
        *value = Slice(*data + key_size, value_size);
    } else {
        key->clear();
        value->clear();
    }

    *next_off = off + key_size + value_size;
    return st;
}

db::Status AppendDBEngine::GetSize(uint64_t* file_size) {
    Status st;
    *file_size = _db_size.load(std::memory_order_relaxed);
    return st;
}

}
