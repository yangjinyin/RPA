/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server_store.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ListPageServerStore : public Command {
public:
    ListPageServerStore() {
        SetName("list-ps-store");
        SetDesc("list store statistic in page server");
        SetDescCn("列出存储服务器的磁盘统计信息");

        AddClusterAndNodeOptions();
        
        AddExample("-a <ip> -p <port>");
        AddExample("--cluster-addr <bns://xx>");
    }
    virtual ~ListPageServerStore() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'C':
            _cluster_addr = opt;
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;
private:
    int Run2();
    void Done2(pspb::MultiGetStatusResponse* response, RpcStatus* status);

    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }
    int Format(const pspb::MultiGetStatusResponse& rsp);
    int Format(const pspb::BatchMultiGetStatusResponse& rsp);
private:
    std::string _cluster_addr {};
    std::string _address {};
    int32_t _port {0};
    std::atomic<uint64_t> _task_count {0};
};

}
}
