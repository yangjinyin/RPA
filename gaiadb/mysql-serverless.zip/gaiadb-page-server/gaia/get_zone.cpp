/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_zone.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/get_zone.h"

namespace psvr {
namespace gaia {

int GetZone::Run() {
    RpcStatus status;

    if (_address.empty() || _port < 1) {
        print_error("miss --address and --port");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    if (_type.empty()) {
        print_error("miss --type");
        return 1;
    }

    if (_type == "ls") {
        lspb::lsrv_empty_message request;
        lspb::lsrv_status_response response;

        _client.Call(_log_id, node, &lspb::LogServiceService_Stub::query_status, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        }
        response.mutable_status()->set_code(lspb::GIE_FAIL);
        response.mutable_status()->set_msg("get failed");
        return Output(response);
    } else if (_type == "cmp") {
        computenode::get_zone_request request;
        computenode::get_zone_response response;

        _client.Call(_log_id, node, &computenode::StatusQueryService_Stub::get_zone, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        }
        response.mutable_status()->set_code(1);
        response.mutable_status()->set_msg("get failed");
        return Output(response);
    } else if (_type == "rpl") {
        replicate::pb::GetZoneRequest request;
        replicate::pb::GetZoneResponse response;

        request.set_log_id(_log_id);

        _client.Call(_log_id, node, &replicate::pb::ReplicationService_Stub::GetZone, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        }
        response.mutable_status()->set_code(replicate::pb::RPC_ERROR);
        response.mutable_status()->set_msg("get failed");
        return Output(response);
    } else if (_type == "ps") {
        pspb::GetZoneRequest request;
        pspb::GetZoneResponse response;

        request.set_log_id(_log_id);

        _client.Call(_log_id, node, &pspb::QueryService_Stub::GetZone, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()) {
            return Output(response);
        }
        response.mutable_status()->set_code(pspb::Status::RPC_ERROR);
        response.mutable_status()->set_msg("get failed");
        return Output(response);
    } else {
        print_error("invalid --type)");
        return 1;
    }
}

int GetZone::Format(const lspb::lsrv_status_response& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.status().code() == 0) {
        printf("%s %lu\n", "write_lsn:", rsp.write_lsn());
        printf("%s %lu\n", "vdl:", rsp.vdl());
        printf("%s %lu\n", "parse_lsn:", rsp.parse_lsn());
        printf("%s %lu\n", "dispatch_lsn:", rsp.dispatch_lsn());
        printf("%s %lu\n", "archive_lsn:", rsp.archive_lsn());
        printf("%s %lu\n", "gc_lsn:", rsp.gc_lsn());
        printf("%s %lu\n", "cn_lowest_lsn:", rsp.cn_lowest_lsn());
        printf("%s %lu\n", "ps_lowest_lsn:", rsp.ps_lowest_lsn());
        printf("%s %lu\n", "link_buf_tail:", rsp.link_buf_tail());
        printf("%s %lu\n", "epoch:", rsp.epoch());
        printf("%s %s\n", "in_increase_epoch:", rsp.in_increase_epoch() ? "yes" : "no");
        printf("%s %lu\n", "checkpoint_lsn:", rsp.checkpoint_lsn());
        printf("%s %s\n", "quorum_enabled:", rsp.quorum_enabled() ? "yes" : "no");
        printf("%s %s\n", "in_gossip:", rsp.in_gossip() ? "yes" : "no");
        printf("%s %s\n", "zone:", GetZoneStr(rsp).c_str());
    }
    return 0;
}

int GetZone::Format(const computenode::get_zone_response& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.status().code() == 0) {
        printf("%s %s\n", "zone:", GetZoneStr(rsp).c_str());
    }
    return 0;
}

int GetZone::Format(const replicate::pb::GetZoneResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.status().code() == replicate::pb::SUCCESS) {
        printf("%s %s\n", "zone:", GetZoneStr(rsp).c_str());
    }
    return 0;
}

int GetZone::Format(const pspb::GetZoneResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.status().code() == pspb::Status::SUCCESS) {
        printf("%s %s\n", "zone:", GetZoneStr(rsp).c_str());
    }
    return 0;
}

}
}
