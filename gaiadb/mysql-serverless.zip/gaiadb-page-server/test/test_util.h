/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_util.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "fault.h"

namespace psvr {
namespace test {

using ::testing::_;
using ::testing::DoAll;
using ::testing::Invoke;
using ::testing::SetArgReferee;
using ::testing::SetArgPointee;
using ::testing::SetArrayArgument;
using ::testing::WithArg;
using ::testing::Return;
using ::testing::ExitedWithCode;
using ::testing::AtLeast;
using ::testing::Matcher;
using ::testing::AnyNumber;


#ifdef ENABLE_TRACE_POINIT

#define TRACE_MOCK_METHOD0(m, ...) MOCK_METHOD3(m, __VA_ARGS__)
#define TRACE_MOCK_METHOD1(m, ...) MOCK_METHOD4(m, __VA_ARGS__)
#define TRACE_MOCK_METHOD2(m, ...) MOCK_METHOD5(m, __VA_ARGS__)
#define TRACE_MOCK_METHOD3(m, ...) MOCK_METHOD6(m, __VA_ARGS__)
#define TRACE_MOCK_METHOD4(m, ...) MOCK_METHOD7(m, __VA_ARGS__)
#define TRACE_MOCK_METHOD5(m, ...) MOCK_METHOD8(m, __VA_ARGS__)
#define TRACE_MOCK_METHOD6(m, ...) MOCK_METHOD9(m, __VA_ARGS__)

#define TRACE_MOCK_ARG_C    _,_,_
#define TRACE_MOCK_ARG_CC   , TRACE_MOCK_ARG_C

#else

#define TRACE_MOCK_METHOD0(m, ...) MOCK_METHOD0(m, __VA_ARGS__)
#define TRACE_MOCK_METHOD1(m, ...) MOCK_METHOD1(m, __VA_ARGS__)
#define TRACE_MOCK_METHOD2(m, ...) MOCK_METHOD2(m, __VA_ARGS__)
#define TRACE_MOCK_METHOD3(m, ...) MOCK_METHOD3(m, __VA_ARGS__)
#define TRACE_MOCK_METHOD4(m, ...) MOCK_METHOD4(m, __VA_ARGS__)
#define TRACE_MOCK_METHOD5(m, ...) MOCK_METHOD5(m, __VA_ARGS__)
#define TRACE_MOCK_METHOD6(m, ...) MOCK_METHOD6(m, __VA_ARGS__)

#define TRACE_MOCK_ARG_C
#define TRACE_MOCK_ARG_CC

#endif

}
}
