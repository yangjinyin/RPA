/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test_segment.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/segment.h"
#include "psvr/compress_utils.h"
#include "test/mock_dbengine.h"
#include "test/mock_dblwr.h"
#include "test/mock_store.h"
#include "test/mock_encrypt.h"
#include "psvr0recv.h"
#include "bmock.h"

namespace psvr {
namespace test {

class SegmentDataTests : public PsvrTest {
 public:
    SegmentDataTests() {

    }
    virtual ~SegmentDataTests() {}

    void SetUp() {
        _segment = create_segment();

        _mock_db_engine = new MockDBEngine();
        _mock_db_engine->_page_size = (16<<10);
        _segment->_db_engine.reset(_mock_db_engine);

        _mock_append_db_engine = new ::testing::NiceMock<MockAppendDBEngine>();
        _segment->_append_db_engine.reset(_mock_append_db_engine);

        _mock_store_manager = new MockStoreManager();
        _mock_control->_store_manager.reset(_mock_store_manager);

        _mock_dblwr = new ::testing::NiceMock<MockDblwr>();
        _segment->_dblwr.reset(_mock_dblwr);
        // Default: dblwr read returns kNotFound so tests fall through to db engine;
        // disable dblwr write by default (tests needing it set FLAGS_psvr_dblwr_max_page_num explicitly)
        ON_CALL(*_mock_dblwr, Read(_, _, _, _))
            .WillByDefault(Return(db::Status(db::Code::kNotFound)));
        // Default: Read(offset) returns kNotFound.
        ON_CALL(*_mock_dblwr, Read(testing::An<uint64_t>(), _))
            .WillByDefault(Return(db::Status(db::Code::kNotFound)));
        FLAGS_psvr_dblwr_max_page_num = 0;

        gaia_apply::page_size_t page_size(16<<10, 16<<10, false);

        // The mock objects created by BMOCK_NS_METHOD attach their hooks at static-init
        // time, so they would stay in effect for the whole binary. Stop them all here and
        // let each test enable only the ones it injects with BMOCK_NS_RESUME.
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        BMOCK_NS_STOP(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        BMOCK_NS_STOP(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
    }

    void TearDown() {
    }

private:
    SegmentPtr _segment;
    MockDBEngine* _mock_db_engine;
    ::testing::NiceMock<MockAppendDBEngine>* _mock_append_db_engine;
    MockStoreManager* _mock_store_manager;
    ::testing::NiceMock<MockDblwr>* _mock_dblwr;
};

BMOCK_NS_METHOD3(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
BMOCK_NS_METHOD2(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));

void set_buf_block(BufBlockPtr buf_block, gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no, const gaia_apply::page_size_t& page_size) {
    init_buf_block(buf_block, space_id, page_no, page_size);
    gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, space_id);
    gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_OFFSET, page_no);
}

TEST_F(SegmentDataTests, test_GetPageLock) {
    auto l1 = _segment->GetPageLock(0);
    auto l2 = _segment->GetPageLock(2);
    auto l3 = _segment->GetPageLock(3);
    auto n2 = _segment->GetPageLock(2);

    ASSERT_EQ(l2, n2);
    ASSERT_NE(l1, l2);
    ASSERT_NE(l1, l3);
    ASSERT_NE(l2, l3);
}

TEST_F(SegmentDataTests, test_ReadPageDataNoLock_ReadPhysicalPageData) {
    int64_t log_id = 1;
    uint64_t physical_offset = 0;
    uint64_t size = 0;
    void* buf = nullptr;

    EXPECT_CALL(*_mock_store_manager, GetStore(_))
        .WillRepeatedly(Return(g_mock_store));

    {
        // invalid offset or size
        physical_offset = 1;
        auto s = _segment->ReadPhysicalPageData(log_id, physical_offset, size, buf);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kInvalid);

        physical_offset = 0;
        s = _segment->ReadPhysicalPageData(log_id, physical_offset, size, buf);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kInvalid);
        size = _segment->_db_engine->page_size();
    }

    {
        g_mock_store->_active = false;
        auto s = _segment->ReadPhysicalPageData(log_id, physical_offset, size, buf);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kIOError);
        g_mock_store->_active = true;

        // read error
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kStatusError)))
            .WillOnce(Return(db::Status(db::Code::kIOError)));

        s = _segment->ReadPhysicalPageData(log_id, physical_offset, size, buf);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kStatusError);

        bool is_compressed = false;
        uint64_t real_write_size = 0;
        s = _segment->ReadPhysicalPageData(log_id, physical_offset, size, buf, &is_compressed, &real_write_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kIOError);
    }

    {
        // read no lock
        gaia_apply::page_no_t logical_page_no = 1;
        BufBlockPtr buf_block = _buf_block;
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kStatusError)))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        auto s = _segment->ReadPageDataNoLock(log_id, 1, logical_page_no, physical_offset, buf_block);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kStatusError);


        s = _segment->ReadPageDataNoLock(log_id, 1, logical_page_no, physical_offset, buf_block);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
    }
}

TEST_F(SegmentDataTests, test_ReadPhysicalPageDataDecrypt) {
    int64_t log_id = 1;
    uint64_t physical_offset = 0;
    uint64_t size = _segment->_db_engine->page_size();
    void* buf = (void*)malloc(size);
    EXPECT_TRUE(buf != nullptr);

    INIT_APPLY_RAW_ARG(false);
    gaia_apply::mach_write_to_2(static_cast<gaia_apply::byte*>(buf) + gaia_apply::FIL_PAGE_TYPE,
                                gaia_apply::FIL_PAGE_ENCRYPTED APPLY_RAW_ARG_NAME_CC);

    EXPECT_CALL(*_mock_store_manager, GetStore(_))
        .WillRepeatedly(Return(g_mock_store));

    EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
        .WillRepeatedly(Return(db::Status(db::Code::kOk)));

    {
        // cipher is not inited
        bool is_compressed = false;
        uint64_t real_write_size = 0;
        auto s = _segment->ReadPhysicalPageData(log_id, physical_offset, size, buf, &is_compressed, &real_write_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kInvalid);
    }

    BlockAccessCipherStreamPtr mock_cipher_stream_ref;
    MockBlockAccessCipherStream *mock_cipher_stream = new MockBlockAccessCipherStream();
    mock_cipher_stream_ref.reset(mock_cipher_stream);
    EncryptHelperPtr encrypt_helper = _segment->cluster()->encrypt_helper();
    encrypt_helper->set_cipher_stream_for_test(mock_cipher_stream_ref);

    {
        // decrypt failed
        EXPECT_CALL(*mock_cipher_stream, decrypt_page(_,_)).WillOnce(Return(false));
        bool is_compressed = false;
        uint64_t real_write_size = 0;
        auto s = _segment->ReadPhysicalPageData(log_id, physical_offset, size, buf, &is_compressed, &real_write_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kCorrupted);
    }

    {
        // decrypt ok
        EXPECT_CALL(*mock_cipher_stream, decrypt_page(_,_)).WillOnce(Return(true));
        bool is_compressed = false;
        uint64_t real_write_size = 0;
        auto s = _segment->ReadPhysicalPageData(log_id, physical_offset, size, buf, &is_compressed, &real_write_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
    }
}

TEST_F(SegmentDataTests, test_WritePhysicalPageData) {
    int64_t log_id = 1;
    gaia_apply::space_id_t space_id = 1;
    gaia_apply::page_no_t logical_page_no = 0;
    uint64_t physical_offset = 0;
    uint64_t size = 0;
    void* buf = nullptr;
    {
        // invalid offset or size
        physical_offset = 1;
        auto s = _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kInvalid);

        physical_offset = 0;
        s = _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kInvalid);
        size = _segment->_db_engine->page_size();
    } END_OF_CASE;

    {
        // FLAGS_multi_psvr_store_reserve_size fail
        g_mock_store->_active = false;
        EXPECT_CALL(*_mock_store_manager, GetStore(_))
            .WillOnce(Return(g_mock_store))
            .WillOnce(Return(g_mock_store));
        auto s = _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kIOError);

        g_mock_store->_active = true;
        g_mock_store->_physical_free_size = FLAGS_multi_psvr_store_reserve_size - 1;
        s = _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kIOError);
        g_mock_store->_physical_free_size = FLAGS_multi_psvr_store_reserve_size + 1;
    } END_OF_CASE;

    {
        // write error
        EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kStatusError)))
            .WillOnce(Return(db::Status(db::Code::kIOError)));

        EXPECT_CALL(*_mock_store_manager, GetStore(_))
            .WillOnce(Return(g_mock_store))
            .WillOnce(Return(g_mock_store));

        auto s = _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kStatusError);

        s = _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kIOError);
    }

    {
        EXPECT_CALL(*_mock_store_manager, GetStore(_))
            .WillRepeatedly(Return(g_mock_store));
        // with FLAGS_psvr_gc_enable_punch_hole
        FLAGS_psvr_gc_enable_punch_hole = true;
        EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _))
            .WillRepeatedly(Return(db::Status(db::Code::kOk)));
        FLAGS_psvr_gc_compress_type = PSVR_COMPRESS_TYPE_ZSTD;
        _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);
        FLAGS_psvr_gc_compress_type = PSVR_COMPRESS_TYPE_LZ4;
        _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);
        FLAGS_psvr_gc_compress_type = PSVR_COMPRESS_TYPE_SNAPPY;
        _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);

        FLAGS_psvr_gc_enable_punch_hole = true;
        _segment->_compress_cfg.enable = true;

        _segment->_compress_cfg.type = PSVR_COMPRESS_TYPE_ZSTD;
        _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);

        _segment->_compress_cfg.type = PSVR_COMPRESS_TYPE_LZ4;
        _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);

        _segment->_compress_cfg.type = PSVR_COMPRESS_TYPE_SNAPPY;
        _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);

        _segment->_compress_cfg.type = PSVR_COMPRESS_TYPE_ZSTD;
        _segment->_compress_cfg.level = 1;
        _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);

        _segment->_compress_cfg.enable = false;
        uint64_t real_write_size = 0;
        _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf, true, &real_write_size);
    }
}

TEST_F(SegmentDataTests, test_WritePhysicalPageDataEncrypt) {
    int64_t log_id = 1;
    gaia_apply::space_id_t space_id = 1;
    gaia_apply::page_no_t logical_page_no = 0;
    uint64_t physical_offset = 0;
    uint64_t size = _segment->_db_engine->page_size();
    void* buf = nullptr;

    FLAGS_psvr_enable_encrypt = true;

    EXPECT_CALL(*_mock_store_manager, GetStore(_))
        .WillRepeatedly(Return(g_mock_store));
    EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _))
        .WillRepeatedly(Return(db::Status(db::Code::kOk)));

    BlockAccessCipherStreamPtr mock_cipher_stream_ref;
    MockBlockAccessCipherStream *mock_cipher_stream = new MockBlockAccessCipherStream();
    mock_cipher_stream_ref.reset(mock_cipher_stream);
    EncryptHelperPtr encrypt_helper = _segment->cluster()->encrypt_helper();
    encrypt_helper->set_cipher_stream_for_test(mock_cipher_stream_ref);

    _segment->SetSpaceEncryptStatus(space_id, kSpaceEncryptStatusWithPSM | kSpaceEncryptStatusEnable);

    {
        // encrypt failed
        EXPECT_CALL(*mock_cipher_stream, encrypt_page(_, _, _)).WillOnce(Return(false));
        uint64_t real_write_size = 0;
        db::Status status =
            _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset,
                                            size, buf, false, &real_write_size);
        EXPECT_EQ(status.code, db::Code::kInvalid);
    }

    {
        // encrypt ok
        EXPECT_CALL(*mock_cipher_stream, encrypt_page(_, _, _)).WillOnce(Return(true));
        uint64_t real_write_size = 0;
        db::Status status =
            _segment->WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset,
                                            size, buf, false, &real_write_size);
        EXPECT_EQ(status.code, db::Code::kOk);
    }
}

#ifndef WITH_GAIA_APPLY_BAN_ASSERT
BMOCK_NS_METHOD6(gaia_apply, recv_parse_or_apply_log_rec_body,
        gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr,
            gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block));
#define TEST_ARG_C
#define TEST_ARG_CC
#else
BMOCK_NS_METHOD7(gaia_apply, recv_parse_or_apply_log_rec_body,
        gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr,
            gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
#define TEST_ARG_C _
#define TEST_ARG_CC , TEST_ARG_C
#endif

TEST_F(SegmentDataTests, test_ApplyPageLogRecordsNoLock) {
    int64_t log_id = 1;
    gaia_apply::page_no_t logical_page_no = 0;
    uint64_t physical_offset = 0;
    gaia_apply::lsn_t max_apply_lsn = 0;
    BufBlockPtr buf_block = _buf_block;
    uint32_t apply_size = 0;

    {
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        //not apply
        max_apply_lsn = 100000;
        buf_block_set_page_lsn(buf_block, max_apply_lsn + 100);
        PageLogRecordIterator iter(page);
        auto s = _segment->ApplyPageLogRecordsNoLock(log_id, physical_offset,
                max_apply_lsn, buf_block, iter, &apply_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kAhead);

        PageLogRecordIterator iter2(page);
        buf_block_set_page_lsn(buf_block, max_apply_lsn);
        s = _segment->ApplyPageLogRecordsNoLock(log_id, physical_offset,
                max_apply_lsn, buf_block, iter2, &apply_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
    } END_OF_CASE;

    {
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        // check_buf_block_page_space failed
        set_buf_block(buf_block, 1 + 1, logical_page_no, gaia_page_size());
        max_apply_lsn = 100000;
        buf_block_set_page_lsn(buf_block, max_apply_lsn - 100);
        LogRecord record(gaia_apply::MLOG_PAGE_CREATE_RTREE, nullptr, 0,
                max_apply_lsn - 90, max_apply_lsn, 2, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));
        PageLogRecordIterator iter(page);
        ASSERT_TRUE(iter.Valid());

        auto s = _segment->ApplyPageLogRecordsNoLock(log_id, physical_offset,
                max_apply_lsn, buf_block, iter, &apply_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kApplyError);
    } END_OF_CASE;
    {
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        // apply with record lsn > max_apply_lsn
        set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        max_apply_lsn = 100000;
        buf_block_set_page_lsn(buf_block, 0);

        LogRecord record(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0,
                max_apply_lsn, max_apply_lsn + 1, 1, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        PageLogRecordIterator iter(page);
        auto s = _segment->ApplyPageLogRecordsNoLock(log_id, physical_offset,
                max_apply_lsn, buf_block, iter, &apply_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
        page->PurgeLogRecords(max_apply_lsn + 1);
    } END_OF_CASE;

    {
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        // apply with record lsn < page_lsn
        set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        max_apply_lsn = 200000;
        buf_block_set_page_lsn(buf_block, 100000 + 3);

        LogRecord record(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0,
                100000, 100000 + 2, 1, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        PageLogRecordIterator iter(page);
        auto s = _segment->ApplyPageLogRecordsNoLock(log_id, physical_offset,
                max_apply_lsn, buf_block, iter, &apply_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
        page->PurgeLogRecords(100000 + 2);
    } END_OF_CASE;

    {
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        // apply with local data error
        set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_OFFSET, logical_page_no + 1);
        max_apply_lsn = 200000;
        buf_block_set_page_lsn(buf_block, 100000 + 2);

        LogRecord record(gaia_apply::MLOG_PAGE_CREATE_RTREE, nullptr, 0,
                100000, 100000 + 3, 1, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        PageLogRecordIterator iter(page);
        auto s = _segment->ApplyPageLogRecordsNoLock(log_id, physical_offset,
                max_apply_lsn, buf_block, iter, &apply_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kCorrupted);
        ASSERT_EQ(apply_size, 0);
        page->PurgeLogRecords(record.end_lsn);
    } END_OF_CASE;

    {
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        // check page lsn failed
        set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_OFFSET, logical_page_no);
        max_apply_lsn = 200000;
        buf_block_set_page_lsn(buf_block, 100000 + 2);

        LogRecord record(gaia_apply::MLOG_PAGE_CREATE_RTREE, nullptr, 0,
                100000, 100000 + 4, 1, logical_page_no, true, 100000);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        PageLogRecordIterator iter(page);
        auto s = _segment->ApplyPageLogRecordsNoLock(log_id, physical_offset,
                max_apply_lsn, buf_block, iter, &apply_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kCorrupted);
        ASSERT_EQ(apply_size, 0);
        page->PurgeLogRecords(record.end_lsn);
    } END_OF_CASE;

    {
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        // apply with recv_parse_or_apply_log_rec_body failed
        set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_OFFSET, logical_page_no + 1);
        max_apply_lsn = 200000;
        buf_block_set_page_lsn(buf_block, 100000 + 2);

        LogRecord record(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0,
                100000, 100000 + 5, 1, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        BMOCK_NS_RESUME(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaia_apply, recv_parse_or_apply_log_rec_body), recv_parse_or_apply_log_rec_body(_, _, _, _, _, _ TEST_ARG_CC))
            .WillOnce(Return(nullptr));

        PageLogRecordIterator iter(page);
        auto s = _segment->ApplyPageLogRecordsNoLock(log_id, physical_offset,
                max_apply_lsn, buf_block, iter, &apply_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kApplyError);
        ASSERT_EQ(apply_size, 1);
        page->PurgeLogRecords(record.end_lsn);
    }

    {
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        // buf_block_reset_checksum failed
        set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        max_apply_lsn = 200000;
        buf_block_set_page_lsn(buf_block, 100000 + 2);

        LogRecord record(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0,
                100000, 100000 + 6, 1, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        gaia_apply::byte result;
        BMOCK_NS_RESUME(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaia_apply, recv_parse_or_apply_log_rec_body), recv_parse_or_apply_log_rec_body(_, _, _, _, _, _ TEST_ARG_CC))
            .WillOnce(Return(&result));
        BMOCK_NS_RESUME(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, buf_block_reset_checksum), buf_block_reset_checksum(_, _)).WillOnce(Return(false));

        PageLogRecordIterator iter(page);
        auto s = _segment->ApplyPageLogRecordsNoLock(log_id, physical_offset,
                max_apply_lsn, buf_block, iter, &apply_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kApplyError);
        page->PurgeLogRecords(record.end_lsn);
    }

    {
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        // apply with recv_parse_or_apply_log_rec_body ok
        set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        max_apply_lsn = 200000;
        buf_block_set_page_lsn(buf_block, 100000 + 2);

        LogRecord record(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0,
                100000, 100000 + 7, 1, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        gaia_apply::byte result;
        BMOCK_NS_RESUME(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaia_apply, recv_parse_or_apply_log_rec_body), recv_parse_or_apply_log_rec_body(_, _, _, _, _, _ TEST_ARG_CC))
            .WillOnce(Return(&result));
        BMOCK_NS_RESUME(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, buf_block_reset_checksum), buf_block_reset_checksum(_, _)).WillOnce(Return(true));

        PageLogRecordIterator iter(page);
        auto s = _segment->ApplyPageLogRecordsNoLock(log_id, physical_offset,
                max_apply_lsn, buf_block, iter, &apply_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
        ASSERT_EQ(apply_size, 1);
        page->PurgeLogRecords(record.end_lsn);
    } END_OF_CASE;

    {
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        // apply with recv_parse_or_apply_log_rec_body for  page zip ok
        set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        auto data = (unsigned char *)malloc(gaia_apply::FLAGS_univ_page_size);
        buf_block->page.zip.data = data;
        max_apply_lsn = 200000;
        buf_block_set_page_lsn(buf_block, 100000 + 2);

        LogRecord record(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0,
                100000, 100000 + 8, 1, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        gaia_apply::byte result;
        BMOCK_NS_RESUME(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaia_apply, recv_parse_or_apply_log_rec_body), recv_parse_or_apply_log_rec_body(_, _, _, _, _, _ TEST_ARG_CC))
            .WillOnce(Return(&result));
        BMOCK_NS_RESUME(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, buf_block_reset_checksum), buf_block_reset_checksum(_, _)).WillOnce(Return(true));

        PageLogRecordIterator iter(page);
        auto s = _segment->ApplyPageLogRecordsNoLock(log_id, physical_offset,
                max_apply_lsn, buf_block, iter, &apply_size);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
        ASSERT_EQ(apply_size, 1);
        page->PurgeLogRecords(record.end_lsn);

        free(data);
        BMOCK_NS_STOP(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        BMOCK_NS_STOP(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
    } END_OF_CASE;
}


TEST_F(SegmentDataTests, test_ReadPageData) {
    int64_t log_id = 0;
    gaia_apply::page_no_t logical_page_no = 0;
    uint64_t physical_offset = 0;
    gaia_apply::lsn_t max_apply_lsn = 10000;
    BufBlockPtr buf_block = _buf_block;
    bool page_is_empty = false;
    gaia_apply::lsn_t real_apply_lsn = 0;

    EXPECT_CALL(*_mock_store_manager, GetStore(_))
        .WillRepeatedly(Return(g_mock_store));
    g_mock_store->_active = true;
    {
        // lock failed
        auto physical_page_no = physical_offset / gaia_physical_page_size();
        db::PageLockPtr page_lock = _mock_db_engine->GetPageLock(physical_page_no);
        ASSERT_TRUE(page_lock->try_lock());

        auto s = _segment->ReadPageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, buf_block, &page_is_empty, &real_apply_lsn);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kBusy);
        page_lock->unlock();
    } END_OF_CASE;
    {
        // ReadPageDataNoLock failed
        physical_offset = 1;
        auto s = _segment->ReadPageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, buf_block, &page_is_empty, &real_apply_lsn);
        LOG(INFO) << s;
        ASSERT_NE(s.code, db::Code::kOk);
        physical_offset = 0;
    } END_OF_CASE;
    {
        // read buf crc failed
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(Return(true));

        auto s = _segment->ReadPageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, buf_block, &page_is_empty, &real_apply_lsn);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kCorrupted);
    } END_OF_CASE;
    {
        // GetPage fail ok
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(Return(false));

        _segment->_parse_lsn(max_apply_lsn - 1);

        auto s = _segment->ReadPageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, buf_block, &page_is_empty, &real_apply_lsn);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
    } END_OF_CASE;
    {
        // GetPage fail ahead
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(Return(false));

        _segment->_parse_lsn(max_apply_lsn - 1);
        page_set_page_lsn(buf_block->frame, gaia_physical_page_size(), max_apply_lsn + 1);
        gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, 1);
        gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_OFFSET, logical_page_no);

        auto s = _segment->ReadPageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, buf_block, &page_is_empty, &real_apply_lsn);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kAhead);
    } END_OF_CASE;
    {
        // LogRecordIsEmptyNoLock ahead
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        PagePtr page = _segment->GetPage(1, logical_page_no + 1, true);
        memset(buf_block->frame, 0, 16<<10);
        _segment->_parse_lsn(max_apply_lsn);
        page_set_page_lsn(buf_block->frame, gaia_physical_page_size(), max_apply_lsn + 1);
        gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, 1);
        gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_OFFSET, logical_page_no + 1);

        auto s = _segment->ReadPageData(log_id, nullptr, 1, logical_page_no + 1, physical_offset, max_apply_lsn, buf_block, &page_is_empty, &real_apply_lsn);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kAhead);
    } END_OF_CASE;
    {
        // LogRecordIsEmptyNoLock ok
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        PagePtr page = _segment->GetPage(1, logical_page_no + 1, true);
        memset(buf_block->frame, 0, 16<<10);
        _segment->_parse_lsn(max_apply_lsn);
        page_set_page_lsn(buf_block->frame, gaia_physical_page_size(), 0);
        gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, 1);
        gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_OFFSET, logical_page_no);

        auto s = _segment->ReadPageData(log_id, nullptr, 1, logical_page_no + 1, physical_offset, max_apply_lsn, buf_block, &page_is_empty, &real_apply_lsn);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
    } END_OF_CASE;
    {
        // do ApplyPageLogRecordsNoLock ok
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        LogRecord record(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0,
                max_apply_lsn - 80, max_apply_lsn - 70, 1, logical_page_no, false, 0);
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        ASSERT_TRUE(page->AppendLogRecord(&record));
        memset(buf_block->frame, 0, 16<<10);
        _segment->_parse_lsn(max_apply_lsn);

        gaia_apply::byte result;
        BMOCK_NS_RESUME(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaia_apply, recv_parse_or_apply_log_rec_body), recv_parse_or_apply_log_rec_body(_, _, _, _, _, _ TEST_ARG_CC))
            .WillOnce(Return(&result));
        BMOCK_NS_RESUME(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, buf_block_reset_checksum), buf_block_reset_checksum(_, _)).WillOnce(Return(true));

        auto s = _segment->ReadPageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, buf_block, &page_is_empty, &real_apply_lsn);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
        page->PurgeLogRecords(max_apply_lsn);
        page->_last_record_lsn = page->_purge_record_lsn.load();
    } END_OF_CASE;
    {
        // do ApplyPageLogRecordsNoLock ok2
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));

        LogRecord record(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0,
                max_apply_lsn - 70, max_apply_lsn - 60, 1, logical_page_no, false, 0);
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        ASSERT_TRUE(page->AppendLogRecord(&record));
        memset(buf_block->frame, 0, 16<<10);
        _segment->_parse_lsn(max_apply_lsn);

        gaia_apply::byte result;
        BMOCK_NS_RESUME(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaia_apply, recv_parse_or_apply_log_rec_body), recv_parse_or_apply_log_rec_body(_, _, _, _, _, _ TEST_ARG_CC))
            .WillOnce(Return(&result));
        BMOCK_NS_RESUME(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, buf_block_reset_checksum), buf_block_reset_checksum(_, _)).WillOnce(Return(true));

        auto s = _segment->ReadPageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, buf_block, &page_is_empty, &real_apply_lsn);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
        page->PurgeLogRecords(max_apply_lsn);
        page->_last_record_lsn = page->_purge_record_lsn.load();
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        BMOCK_NS_STOP(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        BMOCK_NS_STOP(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
    }
}

TEST_F(SegmentDataTests, test_WritePageData) {
    int64_t log_id = 0;
    gaia_apply::page_no_t logical_page_no = 0;
    uint64_t physical_offset = 0;
    gaia_apply::lsn_t max_apply_lsn = 10000;
    gaia_apply::lsn_t record_end_lsn = 8888;
    BufBlockPtr buf_block = _buf_block;
    bool page_is_empty = false;

    EXPECT_CALL(*_mock_store_manager, GetStore(_))
        .WillRepeatedly(Return(g_mock_store));
    g_mock_store->_active = true;
    g_mock_store->_physical_free_size = FLAGS_multi_psvr_store_reserve_size + 1;
    {
        // not found page
        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, 0);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kStatusError);
    }
    {
        // page last_gc_lsn >= record_end_lsn
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        page->_last_gc_lsn = record_end_lsn;
        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, 0);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kAhead);
    } END_OF_CASE;
    {
        // GetOrAllocBufBlock failed
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        ++record_end_lsn;

        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(nullptr)).WillOnce(Return(_buf_block2));

        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, 0);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kSysError);
    } END_OF_CASE;
    {
        // ReadPageDataNoLock failed
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kStatusError)));

        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, 0);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kStatusError);
    } END_OF_CASE;
    {
        // buf_block_is_corrupted failed
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(true)));

        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, 0);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kCorrupted);
    } END_OF_CASE;
    {
        // page LogRecordIsEmpty
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, 0);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kStatusError);
    } END_OF_CASE;
    {
        // apply error
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));

        record_end_lsn = max_apply_lsn - 90;
        memset(buf_block->frame, 0, 16<<10);
        //set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        LogRecord record(gaia_apply::MLOG_LSN, nullptr, 0,
                max_apply_lsn - 90, max_apply_lsn - 80, 1, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, 0);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kCorrupted);

        page->_last_record_lsn = page->_purge_record_lsn.load();
    } END_OF_CASE;
    {
        // apply
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        //EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(nullptr));
        //EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)))
            .WillOnce(Return(db::Status(db::Code::kIOError)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        record_end_lsn = max_apply_lsn - 90;
        memset(buf_block->frame, 0, 16<<10);
        set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        LogRecord record(gaia_apply::MLOG_LSN, nullptr, 0,
                max_apply_lsn - 90, max_apply_lsn - 80, 1, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        gaia_apply::byte result;
        BMOCK_NS_RESUME(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaia_apply, recv_parse_or_apply_log_rec_body), recv_parse_or_apply_log_rec_body(_, _, _, _, _, _ TEST_ARG_CC))
            .WillOnce(Return(&result));
        BMOCK_NS_RESUME(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, buf_block_reset_checksum), buf_block_reset_checksum(_, _)).WillOnce(Return(true));

        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, 0);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kIOError);
        page->_last_record_lsn = page->_purge_record_lsn.load();
    } END_OF_CASE;

    {
        // apply
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        //EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(nullptr));
        //EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(true)));

        record_end_lsn = max_apply_lsn - 90;
        memset(buf_block->frame, 0, 16<<10);
        set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        LogRecord record(gaia_apply::MLOG_LSN, nullptr, 0,
                max_apply_lsn - 90, max_apply_lsn - 80, 1, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        gaia_apply::byte result;
        BMOCK_NS_RESUME(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaia_apply, recv_parse_or_apply_log_rec_body), recv_parse_or_apply_log_rec_body(_, _, _, _, _, _ TEST_ARG_CC))
            .WillOnce(Return(&result));
        BMOCK_NS_RESUME(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, buf_block_reset_checksum), buf_block_reset_checksum(_, _)).WillOnce(Return(true));

        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, 0);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kCorrupted);
        page->_last_record_lsn = page->_purge_record_lsn.load();
    } END_OF_CASE;

    {
        // apply
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        //EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(nullptr));
        //EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        record_end_lsn = max_apply_lsn - 90;
        memset(buf_block->frame, 0, 16<<10);
        //set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        LogRecord record(gaia_apply::MLOG_LSN, nullptr, 0,
                max_apply_lsn - 90, max_apply_lsn - 80, 1, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        gaia_apply::byte result;
        BMOCK_NS_RESUME(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaia_apply, recv_parse_or_apply_log_rec_body), recv_parse_or_apply_log_rec_body(_, _, _, _, _, _ TEST_ARG_CC))
            .WillOnce(Return(&result));
        BMOCK_NS_RESUME(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, buf_block_reset_checksum), buf_block_reset_checksum(_, _)).WillOnce(Return(true));

        set_buf_block(_buf_block, 1, logical_page_no, gaia_page_size());
        set_buf_block(_buf_block2, 1, logical_page_no + 1, gaia_page_size());

        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, 0);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kRetry);
        page->_last_record_lsn = page->_purge_record_lsn.load();
    } END_OF_CASE;

    {
        // apply
        PagePtr page = _segment->GetPage(1, logical_page_no, true);
        //EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(nullptr));
        //EXPECT_CALL(*_mock_bufpool, GetOrAllocBufBlock(_)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        record_end_lsn = max_apply_lsn - 90;
        memset(buf_block->frame, 0, 16<<10);
        //set_buf_block(buf_block, 1, logical_page_no, gaia_page_size());
        LogRecord record(gaia_apply::MLOG_LSN, nullptr, 0,
                max_apply_lsn - 90, max_apply_lsn - 80, 1, logical_page_no, false, 0);
        ASSERT_TRUE(page->AppendLogRecord(&record));

        gaia_apply::byte result;
        BMOCK_NS_RESUME(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaia_apply, recv_parse_or_apply_log_rec_body), recv_parse_or_apply_log_rec_body(_, _, _, _, _, _ TEST_ARG_CC))
            .WillOnce(Return(&result));
        BMOCK_NS_RESUME(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, buf_block_reset_checksum), buf_block_reset_checksum(_, _)).WillOnce(Return(true));

        EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk)));

        set_buf_block(_buf_block, 1, logical_page_no, gaia_page_size());
        set_buf_block(_buf_block2, 1, logical_page_no, gaia_page_size());

        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, 0);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
        page->_last_record_lsn = page->_purge_record_lsn.load();
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        BMOCK_NS_STOP(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        BMOCK_NS_STOP(gaia_apply, recv_parse_or_apply_log_rec_body, gaia_apply::byte*(gaia_apply::mlog_id_t type, gaia_apply::byte *ptr, gaia_apply::byte *end_ptr, gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no, gaia_apply::buf_block_t *block, bool*));
    } END_OF_CASE;
}

TEST_F(SegmentDataTests, test_WritePageData2) {
    int64_t log_id = 0;
    gaia_apply::page_no_t logical_page_no = 0;
    uint64_t physical_offset = 0;
    gaia_apply::lsn_t max_apply_lsn = 10000;
    gaia_apply::lsn_t record_end_lsn = 8888;
    BufBlockPtr buf_block = _buf_block;
    bool page_is_empty = false;

    PagePtr page = _segment->GetPage(1, logical_page_no, true);
    {
        // incomplete_lift_lsn && empty
        ASSERT_TRUE(page->LogRecordIsEmpty(max_apply_lsn, nullptr));
        page->_last_gc_lsn = record_end_lsn - 1;
        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, record_end_lsn);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kStatusError);
    }

    {
        // incomplete_lift_lsn & non-empty
        page->_last_gc_lsn = record_end_lsn - 1;

        LogRecord record(gaia_apply::MLOG_INIT_FILE_PAGE2, nullptr, 0,
                max_apply_lsn + 1, max_apply_lsn + 2,  1, logical_page_no, false, 0);
        page->AppendLogRecord(&record);
        ASSERT_TRUE(page->LogRecordIsEmpty(max_apply_lsn, nullptr));

        auto s = _segment->WritePageData(log_id, nullptr, 1, logical_page_no, physical_offset, max_apply_lsn, record_end_lsn, record_end_lsn);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kAhead);
        page->PurgeLogRecords(max_apply_lsn + 100);
        ASSERT_TRUE(page->LogRecordIsEmpty(max_apply_lsn + 100, nullptr));
    }

    page = nullptr;
}

TEST_F(SegmentDataTests, test_TrimPhysicalPageData) {
    int64_t log_id = 1;
    gaia_apply::space_id_t space_id = 1;
    gaia_apply::page_no_t logical_page_no = 0;
    uint64_t physical_offset = 0;
    uint64_t size = 0;
    void* buf = nullptr;
    const bool old_enable_append_file = FLAGS_psvr_enable_append_file;
    FLAGS_psvr_enable_append_file = false;
    {
        // invalid offset or size
        physical_offset = 1;
        auto s = _segment->TrimPhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, false);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kInvalid);

        physical_offset = 0;
        s = _segment->TrimPhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, false);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kInvalid);
        size = _segment->_db_engine->page_size();
    }

    {
        // ok
        EXPECT_CALL(*_mock_db_engine, Trim(_, _, _))
            .WillOnce(Return(db::Status(db::Code::kStatusError)))
            .WillOnce(Return(db::Status(db::Code::kIOError)));

        EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillOnce(Return(g_mock_store));

        auto s = _segment->TrimPhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, false);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kStatusError);

        s = _segment->TrimPhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, false);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kIOError);
    }
    FLAGS_psvr_enable_append_file = true;
    {
        _segment->_gc_lsn(1, true);
        _segment->SetSpaceSafeTrimLsn(space_id, 0);
        auto s = _segment->TrimPhysicalPageData(log_id, space_id, logical_page_no,
                physical_offset, size, false);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kRetry);

        EXPECT_CALL(*_mock_db_engine, Trim(_, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        s = _segment->TrimPhysicalPageData(log_id, space_id, logical_page_no,
                physical_offset, size, true);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);

        // safe_trim_lsn=2: first GetCheckPointLsn()=1 (<2 → kRetry), then =2 (>=2 → Ok)
        EXPECT_CALL(*_mock_append_db_engine, GetCheckPointLsn())
            .WillOnce(Return(1))
            .WillOnce(Return(2));

        _segment->SetSpaceSafeTrimLsn(space_id, 2);
        s = _segment->TrimPhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, false);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kRetry);

        _segment->_gc_lsn(2, true);
        EXPECT_CALL(*_mock_db_engine, Trim(_, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        s = _segment->TrimPhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, false);
        LOG(INFO) << s;
        ASSERT_EQ(s.code, db::Code::kOk);
    }
    FLAGS_psvr_enable_append_file = old_enable_append_file;
}

static void ReadPeerPageFail(ReadPeerPageContext* ctx) {
    ASSERT_FALSE(ctx->response.success);
}

TEST_F(SegmentDataTests, test_ReadPeerPage) {
    gaia_apply::page_no_t logical_page_no = 0;
    gaia_apply::lsn_t max_apply_lsn = 10000;
    ReadPeerPageContext ctx(1, logical_page_no, max_apply_lsn, _buf_block);
    FillServers(&ctx.request.peers, 2);

    {
        // call fail
        auto fun1 = [](ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* rpc_closure) {
            brpc::ClosureGuard closure_guard(rpc_closure);
            rpc_ctx->status.code = RpcCode::kCntlFailed;
        };

        auto fun2 = [](ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* rpc_closure) {
            brpc::ClosureGuard closure_guard(rpc_closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_INVALID);
        };

        EXPECT_CALL(*_mock_client, Rbio(_, _)).WillOnce(Invoke(fun1)).WillOnce(Invoke(fun2));
        _segment->ReadPeerPage(&ctx, nullptr);
        ASSERT_FALSE(ctx.response.success);
    }
    {
        // call fail 2
        auto fun1 = [](ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* rpc_closure) {
            brpc::ClosureGuard closure_guard(rpc_closure);
            rpc_ctx->status.code = RpcCode::kCntlFailed;
        };

        auto fun2 = [](ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>* rpc_ctx, ggpb::Closure* rpc_closure) {
            brpc::ClosureGuard closure_guard(rpc_closure);
            rpc_ctx->status.code = RpcCode::kSuccess;
            rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_INVALID);
        };

        EXPECT_CALL(*_mock_client, Rbio(_, _)).WillOnce(Invoke(fun1)).WillOnce(Invoke(fun2));

        auto closure = brpc::NewCallback(ReadPeerPageFail, &ctx);
        _segment->ReadPeerPage(&ctx, closure);
    }

    {
        // rpc ok & mismatch space id
        auto rpc_ctx = new ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.code = RpcCode::kSuccess;
        rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_SUCCESS);

        auto reqvec = rpc_ctx->request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(logical_page_no);
        reqvec->set_vlsn(max_apply_lsn);
        reqvec->set_ziplen(gaia_logical_page_size());

        auto rspvec = rpc_ctx->response.add_resvec();
        rspvec->set_tablespaceid(1 + 1);
        rspvec->set_logicalpageno(logical_page_no);
        rspvec->set_pageframe(std::string(gaia_logical_page_size(), 'a'));

        _segment->OnReadPeerPage(&ctx, nullptr, rpc_ctx);
        ASSERT_FALSE(ctx.response.success);
    }

    {
        // rpc ok & mismatch page no
        auto rpc_ctx = new ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.code = RpcCode::kSuccess;
        rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_SUCCESS);

        auto reqvec = rpc_ctx->request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(logical_page_no);
        reqvec->set_vlsn(max_apply_lsn);
        reqvec->set_ziplen(gaia_logical_page_size());

        auto rspvec = rpc_ctx->response.add_resvec();
        rspvec->set_tablespaceid(1);
        rspvec->set_logicalpageno(logical_page_no + 1);
        rspvec->set_pageframe(std::string(gaia_logical_page_size(), 'a'));

        _segment->OnReadPeerPage(&ctx, nullptr, rpc_ctx);
        ASSERT_FALSE(ctx.response.success);
    }

    {
        // rpc ok & mismatch size
        ctx.response.empty_page_count = 0;
        auto rpc_ctx = new ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.code = RpcCode::kSuccess;
        rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_SUCCESS);

        auto reqvec = rpc_ctx->request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(logical_page_no);
        reqvec->set_vlsn(max_apply_lsn);
        reqvec->set_ziplen(gaia_logical_page_size());

        auto rspvec = rpc_ctx->response.add_resvec();
        rspvec->set_tablespaceid(1);
        rspvec->set_logicalpageno(logical_page_no);
        rspvec->set_pageframe(std::string(gaia_logical_page_size() + 1, 'a'));

        _segment->OnReadPeerPage(&ctx, nullptr, rpc_ctx);
        ASSERT_FALSE(ctx.response.success);
    }

    {
        // rpc ok & buf_block_is_corrupted
        ctx.response.empty_page_count = 0;
        auto rpc_ctx = new ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.code = RpcCode::kSuccess;
        rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_SUCCESS);

        auto reqvec = rpc_ctx->request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(logical_page_no);
        reqvec->set_vlsn(max_apply_lsn);
        reqvec->set_ziplen(gaia_logical_page_size());

        auto rspvec = rpc_ctx->response.add_resvec();
        rspvec->set_tablespaceid(1);
        rspvec->set_logicalpageno(logical_page_no);
        rspvec->set_pageframe(std::string(gaia_logical_page_size(), 'a'));
        rspvec->set_checkcrc(true);


        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(true)));
        _segment->OnReadPeerPage(&ctx, nullptr, rpc_ctx);
        ASSERT_FALSE(ctx.response.success);
    }

    {
        // rpc ok & buf_block_is_corrupted & reset crc fail
        ctx.response.empty_page_count = 0;
        auto rpc_ctx = new ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.code = RpcCode::kSuccess;
        rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_SUCCESS);

        auto reqvec = rpc_ctx->request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(logical_page_no);
        reqvec->set_vlsn(max_apply_lsn);
        reqvec->set_ziplen(gaia_logical_page_size());

        auto rspvec = rpc_ctx->response.add_resvec();
        rspvec->set_tablespaceid(1);
        rspvec->set_logicalpageno(logical_page_no);
        rspvec->set_pageframe(std::string(gaia_logical_page_size(), 'a'));

        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(true)));
        BMOCK_NS_RESUME(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, buf_block_reset_checksum), buf_block_reset_checksum(_, _)).WillOnce(Return(false));
        _segment->OnReadPeerPage(&ctx, nullptr, rpc_ctx);
        ASSERT_FALSE(ctx.response.success);
    }
    {
        // rpc ok & buf_block_is_corrupted & reset crc ok
        ctx.response.empty_page_count = 0;
        auto rpc_ctx = new ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.code = RpcCode::kSuccess;
        rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_SUCCESS);

        auto reqvec = rpc_ctx->request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(logical_page_no);
        reqvec->set_vlsn(max_apply_lsn);
        reqvec->set_ziplen(gaia_logical_page_size());

        auto rspvec = rpc_ctx->response.add_resvec();
        rspvec->set_tablespaceid(1);
        rspvec->set_logicalpageno(logical_page_no);
        rspvec->set_pageframe(std::string(gaia_logical_page_size(), 'a'));

        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(true)));
        BMOCK_NS_RESUME(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, buf_block_reset_checksum), buf_block_reset_checksum(_, _)).WillOnce(Return(true));
        _segment->OnReadPeerPage(&ctx, nullptr, rpc_ctx);
        ASSERT_TRUE(ctx.response.success);
    }

    {
        // rpc ok & buf_block_is_corrupted & empty < major
        ctx.response.success = false;
        ctx.response.empty_page_count = 0;
        auto rpc_ctx = new ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.code = RpcCode::kSuccess;
        rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_SUCCESS);

        auto reqvec = rpc_ctx->request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(logical_page_no);
        reqvec->set_vlsn(max_apply_lsn);
        reqvec->set_ziplen(gaia_logical_page_size());

        auto rspvec = rpc_ctx->response.add_resvec();
        rspvec->set_tablespaceid(1);
        rspvec->set_logicalpageno(logical_page_no);
        rspvec->set_pageframe(std::string(gaia_logical_page_size(), 'a'));
        rspvec->set_checkcrc(true);

        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        _segment->OnReadPeerPage(&ctx, nullptr, rpc_ctx);
        ASSERT_FALSE(ctx.response.success);
    }

    {
        // rpc ok & buf_block_is_corrupted & empty < major
        ctx.response.empty_page_count = 0;
        auto rpc_ctx = new ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.code = RpcCode::kSuccess;
        rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_SUCCESS);

        auto reqvec = rpc_ctx->request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(logical_page_no);
        reqvec->set_vlsn(max_apply_lsn);
        reqvec->set_ziplen(gaia_logical_page_size());

        auto rspvec = rpc_ctx->response.add_resvec();
        rspvec->set_tablespaceid(1);
        rspvec->set_logicalpageno(logical_page_no);
        rspvec->set_pageframe(std::string(gaia_logical_page_size(), 'a'));
        rspvec->set_checkcrc(true);
        rpc_ctx->response.set_valid_empty(false);

        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        _segment->OnReadPeerPage(&ctx, nullptr, rpc_ctx);
        ASSERT_FALSE(ctx.response.success);
    }

    {
        // rpc ok & buf_block_is_corrupted & valid empty
        ctx.response.empty_page_count = 0;
        auto rpc_ctx = new ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.code = RpcCode::kSuccess;
        rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_SUCCESS);

        auto reqvec = rpc_ctx->request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(logical_page_no);
        reqvec->set_vlsn(max_apply_lsn);
        reqvec->set_ziplen(gaia_logical_page_size());

        auto rspvec = rpc_ctx->response.add_resvec();
        rspvec->set_tablespaceid(1);
        rspvec->set_logicalpageno(logical_page_no);
        rspvec->set_pageframe(std::string(gaia_logical_page_size(), 'a'));
        rspvec->set_checkcrc(true);
        rpc_ctx->response.set_valid_empty(true);

        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        _segment->OnReadPeerPage(&ctx, nullptr, rpc_ctx);
        ASSERT_TRUE(ctx.response.success);
    }

    {
        // rpc ok & buf_block_is_corrupted & empty >= major
        ctx.response.empty_page_count = 1;
        auto rpc_ctx = new ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.code = RpcCode::kSuccess;
        rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_SUCCESS);

        auto reqvec = rpc_ctx->request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(logical_page_no);
        reqvec->set_vlsn(max_apply_lsn);
        reqvec->set_ziplen(gaia_logical_page_size());

        auto rspvec = rpc_ctx->response.add_resvec();
        rspvec->set_tablespaceid(1);
        rspvec->set_logicalpageno(logical_page_no);
        rspvec->set_pageframe(std::string(gaia_logical_page_size(), 'a'));
        rspvec->set_checkcrc(true);
        rpc_ctx->response.set_valid_empty(false);

        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        _segment->OnReadPeerPage(&ctx, nullptr, rpc_ctx);
        ASSERT_TRUE(ctx.response.success);
    }

    {
        // rpc ok & buf_block_is_corrupted & not empty
        ctx.response.empty_page_count = 1;
        auto rpc_ctx = new ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
        FillServers(&rpc_ctx->servers, 1);
        rpc_ctx->status.code = RpcCode::kSuccess;
        rpc_ctx->response.set_errcode(pspb::RbioResponse_Error_RBIO_SUCCESS);

        auto reqvec = rpc_ctx->request.add_reqvec();
        reqvec->set_tablespaceid(1);
        reqvec->set_logicalpageno(logical_page_no);
        reqvec->set_vlsn(max_apply_lsn);
        reqvec->set_ziplen(gaia_logical_page_size());

        auto rspvec = rpc_ctx->response.add_resvec();
        rspvec->set_tablespaceid(1);
        rspvec->set_logicalpageno(logical_page_no);
        rspvec->set_pageframe(std::string(gaia_logical_page_size(), 'a'));
        rspvec->set_checkcrc(true);
        rpc_ctx->response.set_valid_empty(true);

        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
            .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        _segment->OnReadPeerPage(&ctx, nullptr, rpc_ctx);
        ASSERT_TRUE(ctx.response.success);
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        BMOCK_NS_STOP(psvr, buf_block_reset_checksum, bool(BufBlockPtr, const gaia_apply::lsn_t));
    }
}

// --- ReadPhysicalPageDataWithDblwr ---

TEST_F(SegmentDataTests, test_ReadPhysicalPageDataWithDblwr_dblwr_hit) {
    int64_t log_id = 1;
    uint64_t physical_offset = 0;
    uint64_t size = _segment->_db_engine->page_size();

    EXPECT_CALL(*_mock_store_manager, GetStore(_))
        .WillRepeatedly(Return(g_mock_store));

    {
        // dblwr Read returns Ok: should NOT call db_engine->Read, return Ok
        // is_compressed should be set to false, real_write_size should be set to size
        EXPECT_CALL(*_mock_dblwr, Read(static_cast<uint32_t>(physical_offset), _))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).Times(0);

        bool is_compressed = true;
        uint64_t real_write_size = 0;
        auto s = _segment->ReadPhysicalPageDataWithDblwr(log_id, physical_offset, size,
                _buf_block->frame, &is_compressed, &real_write_size);
        ASSERT_TRUE(s.IsOk()) << s;
        ASSERT_FALSE(is_compressed);
        ASSERT_EQ(real_write_size, size);
    }
    END_OF_CASE;

    {
        // dblwr Read returns Ok; no optional out-args passed (simple overload)
        EXPECT_CALL(*_mock_dblwr, Read(static_cast<uint32_t>(physical_offset), _))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).Times(0);

        auto s = _segment->ReadPhysicalPageDataWithDblwr(log_id, physical_offset, size, _buf_block->frame);
        ASSERT_TRUE(s.IsOk()) << s;
    }
    END_OF_CASE;
}

TEST_F(SegmentDataTests, test_ReadPhysicalPageDataWithDblwr_dblwr_miss_fallback) {
    int64_t log_id = 1;
    uint64_t physical_offset = 0;
    uint64_t size = _segment->_db_engine->page_size();

    EXPECT_CALL(*_mock_store_manager, GetStore(_))
        .WillRepeatedly(Return(g_mock_store));

    {
        // dblwr Read returns NotFound: must fall back to ReadPhysicalPageData
        EXPECT_CALL(*_mock_dblwr, Read(static_cast<uint32_t>(physical_offset), _))
            .WillOnce(Return(db::Status(db::Code::kNotFound)));
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));

        auto s = _segment->ReadPhysicalPageDataWithDblwr(log_id, physical_offset, size, _buf_block->frame);
        ASSERT_TRUE(s.IsOk()) << s;
    }
    END_OF_CASE;

    {
        // dblwr Miss + db_engine Read fails
        EXPECT_CALL(*_mock_dblwr, Read(static_cast<uint32_t>(physical_offset), _))
            .WillOnce(Return(db::Status(db::Code::kNotFound)));
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kIOError)));

        auto s = _segment->ReadPhysicalPageDataWithDblwr(log_id, physical_offset, size, _buf_block->frame);
        ASSERT_EQ(s.code, db::Code::kIOError);
    }
    END_OF_CASE;
}

// --- ReadPageDataNoLock with dblwr ---

TEST_F(SegmentDataTests, test_ReadPageDataNoLock_dblwr_hit) {
    int64_t log_id = 1;
    gaia_apply::space_id_t space_id = 1;
    gaia_apply::page_no_t page_no = 1;
    uint64_t physical_offset = 0;

    EXPECT_CALL(*_mock_store_manager, GetStore(_))
        .WillRepeatedly(Return(g_mock_store));

    {
        // dblwr Read(space_id, page_no, offset) hits: db_engine must NOT be called
        EXPECT_CALL(*_mock_dblwr, Read(space_id, page_no, static_cast<uint64_t>(physical_offset), _))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).Times(0);

        auto s = _segment->ReadPageDataNoLock(log_id, space_id, page_no, physical_offset, _buf_block);
        ASSERT_TRUE(s.IsOk()) << s;
    }
    END_OF_CASE;

    {
        // dblwr Read returns NotFound: must fall back to ReadPhysicalPageData
        EXPECT_CALL(*_mock_dblwr, Read(space_id, page_no, static_cast<uint64_t>(physical_offset), _))
            .WillOnce(Return(db::Status(db::Code::kNotFound)));
        EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));

        auto s = _segment->ReadPageDataNoLock(log_id, space_id, page_no, physical_offset, _buf_block);
        ASSERT_TRUE(s.IsOk()) << s;
    }
    END_OF_CASE;
}

// --- WritePageDataNoLock with dblwr ---

TEST_F(SegmentDataTests, test_WritePageDataNoLock_dblwr_enabled) {
    int64_t log_id = 1;
    gaia_apply::space_id_t space_id = 1;
    gaia_apply::page_no_t page_no = 2;
    uint64_t physical_offset = 0;
    uint64_t size = _segment->_db_engine->page_size();

    FLAGS_psvr_enable_append_file = true;
    FLAGS_psvr_dblwr_max_page_num = 128;

    {
        // dblwr enabled: WritePageDataNoLock should call _dblwr->Write, not db_engine
        EXPECT_CALL(*_mock_dblwr, Write(space_id, page_no, _, physical_offset, kDblwrFlagsNone))
            .WillOnce(Return(db::Status(db::Code::kOk)));
        EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _)).Times(0);

        auto s = _segment->WritePageDataNoLock(log_id, space_id, page_no,
                physical_offset, size, _buf_block->frame);
        ASSERT_TRUE(s.IsOk()) << s;
    }
    END_OF_CASE;

    {
        // dblwr Write fails: error propagated
        EXPECT_CALL(*_mock_dblwr, Write(space_id, page_no, _, physical_offset, kDblwrFlagsNone))
            .WillOnce(Return(db::Status(db::Code::kIOError)));

        auto s = _segment->WritePageDataNoLock(log_id, space_id, page_no,
                physical_offset, size, _buf_block->frame);
        ASSERT_EQ(s.code, db::Code::kIOError);
    }
    END_OF_CASE;

    FLAGS_psvr_enable_append_file = false;
    FLAGS_psvr_dblwr_max_page_num = 0;
}

TEST_F(SegmentDataTests, test_WritePageDataNoLock_dblwr_disabled) {
    int64_t log_id = 1;
    gaia_apply::space_id_t space_id = 1;
    gaia_apply::page_no_t page_no = 2;
    uint64_t physical_offset = 0;
    uint64_t size = _segment->_db_engine->page_size();

    EXPECT_CALL(*_mock_store_manager, GetStore(_))
        .WillRepeatedly(Return(g_mock_store));

    FLAGS_psvr_enable_append_file = false;
    FLAGS_psvr_dblwr_max_page_num = 0;

    {
        // dblwr disabled: must call db_engine->Write directly, NOT _dblwr->Write
        EXPECT_CALL(*_mock_dblwr, Write(_, _, _, _, _)).Times(0);
        EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));

        auto s = _segment->WritePageDataNoLock(log_id, space_id, page_no,
                physical_offset, size, _buf_block->frame);
        ASSERT_TRUE(s.IsOk()) << s;
    }
    END_OF_CASE;

    {
        // append_file enabled but dblwr_max_page_num == 0: falls through to db_engine
        FLAGS_psvr_enable_append_file = true;
        FLAGS_psvr_dblwr_max_page_num = 0;

        EXPECT_CALL(*_mock_dblwr, Write(_, _, _, _, _)).Times(0);
        EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk)));

        auto s = _segment->WritePageDataNoLock(log_id, space_id, page_no,
                physical_offset, size, _buf_block->frame);
        ASSERT_TRUE(s.IsOk()) << s;

        FLAGS_psvr_enable_append_file = false;
    }
    END_OF_CASE;
}

// --- DumpDblwrBuf ---

TEST_F(SegmentDataTests, test_DumpDblwrBuf_no_buf) {
    {
        // DumpBuf returns nullptr: DumpDblwrBuf returns Ok immediately
        EXPECT_CALL(*_mock_dblwr, DumpBuf())
            .WillOnce(Return(nullptr));

        auto s = _segment->DumpDblwrBuf(1);
        ASSERT_TRUE(s.IsOk()) << s;
    }
    END_OF_CASE;
}

TEST_F(SegmentDataTests, test_DumpDblwrBuf_in_dump_concurrent) {
    {
        // DumpBuf returns a valid buf, but _in_dump is already held → DumpDblwrBuf returns kStatusError
        auto dblwr_buf = std::make_shared<DblwrBuf>();
        dblwr_buf->footer.page_num = 0;
        dblwr_buf->footer.ckp_lsn[1] = 0;

        EXPECT_CALL(*_mock_dblwr, DumpBuf())
            .WillOnce(Return(dblwr_buf));

        // Pre-acquire the lock so DumpDblwrBuf fails at acquire_in_dump()
        bool acquired = _mock_dblwr->Dblwr::acquire_in_dump();
        ASSERT_TRUE(acquired);

        db::Status s = _segment->DumpDblwrBuf(0);
        ASSERT_EQ(s.code, db::Code::kStatusError);

        _mock_dblwr->Dblwr::release_in_dump();
    }
    END_OF_CASE;
}

// --- SealDblwrTimeout ---

// Branch: append file disabled → returns Ok without calling SealBufByTime
TEST_F(SegmentDataTests, test_SealDblwrTimeout_append_disabled) {
    const bool old_append_file = FLAGS_psvr_enable_append_file;
    const int32_t old_max_page_num = FLAGS_psvr_dblwr_max_page_num;
    FLAGS_psvr_enable_append_file = false;
    FLAGS_psvr_dblwr_max_page_num = 128;
    {
        EXPECT_CALL(*_mock_dblwr, SealBufByTime(_)).Times(0);
        auto st = _segment->SealDblwrTimeout(1000);
        ASSERT_TRUE(st.IsOk()) << st;
    }
    FLAGS_psvr_enable_append_file = old_append_file;
    FLAGS_psvr_dblwr_max_page_num = old_max_page_num;
    END_OF_CASE;
}

// Branch: dblwr disabled (max_page_num == 0) → returns Ok without calling SealBufByTime
TEST_F(SegmentDataTests, test_SealDblwrTimeout_dblwr_disabled) {
    const bool old_append_file = FLAGS_psvr_enable_append_file;
    const int32_t old_max_page_num = FLAGS_psvr_dblwr_max_page_num;
    FLAGS_psvr_enable_append_file = true;
    FLAGS_psvr_dblwr_max_page_num = 0;
    {
        EXPECT_CALL(*_mock_dblwr, SealBufByTime(_)).Times(0);
        auto st = _segment->SealDblwrTimeout(1000);
        ASSERT_TRUE(st.IsOk()) << st;
    }
    FLAGS_psvr_enable_append_file = old_append_file;
    FLAGS_psvr_dblwr_max_page_num = old_max_page_num;
    END_OF_CASE;
}

// Branch: enabled and SealBufByTime succeeds → returns Ok
TEST_F(SegmentDataTests, test_SealDblwrTimeout_success) {
    const bool old_append_file = FLAGS_psvr_enable_append_file;
    const int32_t old_max_page_num = FLAGS_psvr_dblwr_max_page_num;
    FLAGS_psvr_enable_append_file = true;
    FLAGS_psvr_dblwr_max_page_num = 128;
    {
        EXPECT_CALL(*_mock_dblwr, SealBufByTime(1000))
            .WillOnce(Return(db::Status()));
        auto st = _segment->SealDblwrTimeout(1000);
        ASSERT_TRUE(st.IsOk()) << st;
    }
    FLAGS_psvr_enable_append_file = old_append_file;
    FLAGS_psvr_dblwr_max_page_num = old_max_page_num;
    END_OF_CASE;
}

// Branch: enabled and SealBufByTime fails → returns error
TEST_F(SegmentDataTests, test_SealDblwrTimeout_fails) {
    const bool old_append_file = FLAGS_psvr_enable_append_file;
    const int32_t old_max_page_num = FLAGS_psvr_dblwr_max_page_num;
    FLAGS_psvr_enable_append_file = true;
    FLAGS_psvr_dblwr_max_page_num = 128;
    {
        EXPECT_CALL(*_mock_dblwr, SealBufByTime(1000))
            .WillOnce(Return(db::Status(db::Code::kStatusError)));
        auto st = _segment->SealDblwrTimeout(1000);
        ASSERT_FALSE(st.IsOk());
        ASSERT_EQ(st.code, db::Code::kStatusError);
    }
    FLAGS_psvr_enable_append_file = old_append_file;
    FLAGS_psvr_dblwr_max_page_num = old_max_page_num;
    END_OF_CASE;
}

// --- Additional dblwr branch coverage ---

// Partial mock: inherits real Segment but mocks UpdateAppendDBCheckPoint and Sync
// so that DumpDblwrBuf can run without an initialised _append_db_engine.
class PartialMockSegment : public Segment {
public:
    using Segment::Segment;
    MOCK_METHOD2(UpdateAppendDBCheckPoint, db::Status(gaia_apply::lsn_t, bool));
    MOCK_METHOD0(Sync, void());
};

// Helper: build a DblwrBuf containing one page (space_id=1, page_no=1, slot=0,
// physical_offset=0). page_lsn is written into the dblwr frame; ckp_lsn is set
// in the footer.
static DblwrBufPtr MakeDblwrBufWithPage(gaia_apply::lsn_t page_lsn = 0,
                                        uint64_t ckp_lsn = 0) {
    auto buf = std::make_shared<DblwrBuf>();
    const uint32_t page_size = gaia_apply::FLAGS_univ_page_size;
    buf->frames = static_cast<gaia_apply::byte*>(std::aligned_alloc(page_size, page_size));
    buf->frames_len = static_cast<ssize_t>(page_size);
    memset(buf->frames, 0, page_size);
    buf->footer.page_num = 1;
    buf->footer.offs[0] = 0;   // physical_offset = 0 (slot 0)
    gaia_apply::mach_write_to_8(buf->frames + gaia_apply::FIL_PAGE_LSN, page_lsn);
    // offs_to_slot: physical_offset=0 → slot=0 (used by DumpDblwrBuf)
    buf->offs_to_slot[0] = 0;
    buf->footer.ckp_lsn[1] = ckp_lsn;
    return buf;
}

// ReadPhysicalPageDataWithDblwr: dblwr Read returns non-NotFound error →
// propagate immediately, do NOT fall back to db_engine
TEST_F(SegmentDataTests, test_ReadPhysicalPageDataWithDblwr_dblwr_io_error) {
    int64_t log_id = 1;
    uint64_t physical_offset = 0;
    uint64_t size = _segment->_db_engine->page_size();

    EXPECT_CALL(*_mock_dblwr, Read(static_cast<uint32_t>(physical_offset), _))
        .WillOnce(Return(db::Status(db::Code::kIOError)));
    EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).Times(0);

    auto s = _segment->ReadPhysicalPageDataWithDblwr(log_id, physical_offset, size,
            _buf_block->frame);
    ASSERT_EQ(s.code, db::Code::kIOError);
    END_OF_CASE;
}

// ReadPageDataNoLock: dblwr Read(space, page) returns non-NotFound error →
// propagate immediately, do NOT call db_engine
TEST_F(SegmentDataTests, test_ReadPageDataNoLock_dblwr_io_error) {
    int64_t log_id = 1;
    gaia_apply::space_id_t space_id = 1;
    gaia_apply::page_no_t page_no = 1;
    uint64_t physical_offset = 0;

    EXPECT_CALL(*_mock_dblwr, Read(space_id, page_no, static_cast<uint64_t>(physical_offset), _))
        .WillOnce(Return(db::Status(db::Code::kIOError)));
    EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).Times(0);

    auto s = _segment->ReadPageDataNoLock(log_id, space_id, page_no, physical_offset,
            _buf_block);
    ASSERT_EQ(s.code, db::Code::kIOError);
    END_OF_CASE;
}

// DumpDblwrBuf: AllocBufBlock returns nullptr → kBusy
// This test must run before any successful DumpDblwrBuf call so that
// the thread_local tl_buf_block and tl_buf_block2 are still nullptr.
TEST_F(SegmentDataTests, test_DumpDblwrBuf_alloc_buf_fails) {
    auto dblwr_buf = MakeDblwrBufWithPage();
    EXPECT_CALL(*_mock_dblwr, DumpBuf()).WillOnce(Return(dblwr_buf));
    // Both tl_buf_block and tl_buf_block2 are allocated unconditionally; both return nullptr.
    EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
        .WillOnce(Return(nullptr)).WillOnce(Return(nullptr));

    db::Status s = _segment->DumpDblwrBuf(1);
    ASSERT_EQ(s.code, db::Code::kBusy);
    END_OF_CASE;
}

// DumpDblwrBuf: ReadPhysicalPageData fails inside page loop → propagate error.
// This is also the first test to successfully allocate tl_buf_block and tl_buf_block2.
// Two *distinct* blocks are required: subsequent tests write page_lsn into
// tl_buf_block2->frame via Read(offset) and read local_page_lsn from tl_buf_block->frame.
// Sharing the same block would make the two LSNs equal and skip the write path.
TEST_F(SegmentDataTests, test_DumpDblwrBuf_read_physical_fails) {
    auto dblwr_buf = MakeDblwrBufWithPage();
    BufBlockPtr loop_block = _mock_bufpool->RealAllocBufBlock(
            gaia_apply::FLAGS_univ_page_size, nullptr);
    BufBlockPtr loop_block2 = _mock_bufpool->RealAllocBufBlock(
            gaia_apply::FLAGS_univ_page_size, nullptr);

    EXPECT_CALL(*_mock_dblwr, DumpBuf()).WillOnce(Return(dblwr_buf));
    // First AllocBufBlock → tl_buf_block; second → tl_buf_block2 (must be distinct).
    EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
        .WillOnce(Return(loop_block)).WillOnce(Return(loop_block2));
    EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillRepeatedly(Return(g_mock_store));
    // Read(physical_offset) must succeed so the code reaches ReadPhysicalPageData.
    EXPECT_CALL(*_mock_dblwr, Read(static_cast<uint64_t>(0), _))
        .WillOnce(Return(db::Status(db::Code::kOk)));
    EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
        .WillOnce(Return(db::Status(db::Code::kIOError)));
    EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _)).Times(0);

    db::Status s = _segment->DumpDblwrBuf(1);
    ASSERT_EQ(s.code, db::Code::kIOError);
    END_OF_CASE;
}

// DumpDblwrBuf: page not corrupted, local_page_lsn(0) >= dblwr page_lsn(0)
// → skip write, proceed to Sync + RemoveBuf
TEST_F(SegmentDataTests, test_DumpDblwrBuf_local_page_up_to_date) {
    // page_lsn=0 in dblwr frame; buf_block->frame will also have lsn=0 after Read
    auto dblwr_buf = MakeDblwrBufWithPage(/*page_lsn=*/0);
    EXPECT_CALL(*_mock_dblwr, DumpBuf()).WillOnce(Return(dblwr_buf));
    EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillRepeatedly(Return(g_mock_store));
    // Read(physical_offset) succeeds; frame has page_lsn=0 (from MakeDblwrBufWithPage).
    EXPECT_CALL(*_mock_dblwr, Read(static_cast<uint64_t>(0), _))
        .WillOnce(Return(db::Status(db::Code::kOk)));
    EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
        .WillOnce(Return(db::Status(db::Code::kOk)));
    BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
        .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
    // local_lsn(0) >= page_lsn(0): skip write
    EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _)).Times(0);
    FLAGS_psvr_disable_sync = true;
    EXPECT_CALL(*_mock_dblwr, RemoveBuf(_)).WillOnce(Return(db::Status(db::Code::kOk)));

    db::Status s = _segment->DumpDblwrBuf(1);
    ASSERT_TRUE(s.IsOk()) << s;

    BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    FLAGS_psvr_disable_sync = false;
    END_OF_CASE;
}

// DumpDblwrBuf: page is corrupted → log warning, write dblwr frame (else branch)
TEST_F(SegmentDataTests, test_DumpDblwrBuf_page_corrupted_write) {
    auto dblwr_buf = MakeDblwrBufWithPage(/*page_lsn=*/0);
    EXPECT_CALL(*_mock_dblwr, DumpBuf()).WillOnce(Return(dblwr_buf));
    EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillRepeatedly(Return(g_mock_store));
    EXPECT_CALL(*_mock_dblwr, Read(static_cast<uint64_t>(0), _))
        .WillOnce(Return(db::Status(db::Code::kOk)));
    EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
        .WillOnce(Return(db::Status(db::Code::kOk)));
    // page corrupted: skip LSN comparison, always write
    BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
        .WillOnce(DoAll(SetArgPointee<2>(false), Return(true)));
    EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _))
        .WillOnce(Return(db::Status(db::Code::kOk)));
    FLAGS_psvr_disable_sync = true;
    EXPECT_CALL(*_mock_dblwr, RemoveBuf(_)).WillOnce(Return(db::Status(db::Code::kOk)));

    db::Status s = _segment->DumpDblwrBuf(1);
    ASSERT_TRUE(s.IsOk()) << s;

    BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    FLAGS_psvr_disable_sync = false;
    END_OF_CASE;
}

// DumpDblwrBuf: WritePhysicalPageData fails → propagate error
// page_lsn=100 so local_lsn(0) < page_lsn(100) → write path is taken
TEST_F(SegmentDataTests, test_DumpDblwrBuf_write_fails) {
    auto dblwr_buf = MakeDblwrBufWithPage(/*page_lsn=*/100);
    EXPECT_CALL(*_mock_dblwr, DumpBuf()).WillOnce(Return(dblwr_buf));
    EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillRepeatedly(Return(g_mock_store));
    // Read(physical_offset) writes page_lsn=100 into the frame.
    EXPECT_CALL(*_mock_dblwr, Read(static_cast<uint64_t>(0), _))
        .WillOnce(DoAll(
            Invoke([](uint64_t, gaia_apply::byte* f) {
                gaia_apply::mach_write_to_8(f + gaia_apply::FIL_PAGE_LSN, uint64_t(100));
            }),
            Return(db::Status(db::Code::kOk))));
    EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
        .WillOnce(Return(db::Status(db::Code::kOk)));
    BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
        .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
    EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _))
        .WillOnce(Return(db::Status(db::Code::kIOError)));

    db::Status s = _segment->DumpDblwrBuf(1);
    ASSERT_EQ(s.code, db::Code::kIOError);
    BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    END_OF_CASE;
}

// DumpDblwrBuf: full success path, page_lsn(100) > local_lsn(0) → write page
TEST_F(SegmentDataTests, test_DumpDblwrBuf_success_write_page) {
    auto dblwr_buf = MakeDblwrBufWithPage(/*page_lsn=*/100);
    EXPECT_CALL(*_mock_dblwr, DumpBuf()).WillOnce(Return(dblwr_buf));
    EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillRepeatedly(Return(g_mock_store));
    EXPECT_CALL(*_mock_dblwr, Read(static_cast<uint64_t>(0), _))
        .WillOnce(DoAll(
            Invoke([](uint64_t, gaia_apply::byte* f) {
                gaia_apply::mach_write_to_8(f + gaia_apply::FIL_PAGE_LSN, uint64_t(100));
            }),
            Return(db::Status(db::Code::kOk))));
    EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
        .WillOnce(Return(db::Status(db::Code::kOk)));
    BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
        .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
    EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _))
        .WillOnce(Return(db::Status(db::Code::kOk)));
    FLAGS_psvr_disable_sync = true;
    EXPECT_CALL(*_mock_dblwr, RemoveBuf(_)).WillOnce(Return(db::Status(db::Code::kOk)));

    db::Status s = _segment->DumpDblwrBuf(1);
    ASSERT_TRUE(s.IsOk()) << s;

    BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    FLAGS_psvr_disable_sync = false;
    END_OF_CASE;
}

// DumpDblwrBuf: Read(physical_offset) returns kIOError → propagate error and increment IO error count.
TEST_F(SegmentDataTests, test_DumpDblwrBuf_readseal_io_error) {
    auto dblwr_buf = MakeDblwrBufWithPage();
    EXPECT_CALL(*_mock_dblwr, DumpBuf()).WillOnce(Return(dblwr_buf));
    EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillRepeatedly(Return(g_mock_store));
    // Read(physical_offset) returns IO error → DumpDblwrBuf propagates it
    EXPECT_CALL(*_mock_dblwr, Read(static_cast<uint64_t>(0), _))
        .WillOnce(Return(db::Status(db::Code::kIOError)));
    // IO error is returned immediately; Read/Write must not be called.
    EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _)).Times(0);
    EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _)).Times(0);

    db::Status s = _segment->DumpDblwrBuf(1);
    ASSERT_EQ(s.code, db::Code::kIOError);
    END_OF_CASE;
}

// DumpDblwrBuf: Read(physical_offset) returns ok with page_lsn=100; the frame is read
// directly from dblwr mmap memory. local_lsn(0) < page_lsn(100) normally triggers a
// write, but here Read returns lsn=0 (simulating a sealed buf hit with an older page),
// so local_lsn(0) >= page_lsn(0) → write is skipped.
TEST_F(SegmentDataTests, test_DumpDblwrBuf_seal_buf_hit_skips_write) {
    // dblwr buf has page_lsn=100; Read overrides the frame with lsn=0 (sealed hit).
    auto dblwr_buf = MakeDblwrBufWithPage(/*page_lsn=*/100);
    EXPECT_CALL(*_mock_dblwr, DumpBuf()).WillOnce(Return(dblwr_buf));
    EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillRepeatedly(Return(g_mock_store));
    // Read(physical_offset) fills frame with lsn=0 (sealed buf hit, lsn overridden to 0).
    EXPECT_CALL(*_mock_dblwr, Read(static_cast<uint64_t>(0), _))
        .WillOnce(DoAll(
            Invoke([](uint64_t, gaia_apply::byte* f) {
                gaia_apply::mach_write_to_8(f + gaia_apply::FIL_PAGE_LSN, uint64_t(0));
            }),
            Return(db::Status(db::Code::kOk))));
    EXPECT_CALL(*_mock_db_engine, Read(_, _, _, _, _))
        .WillOnce(Return(db::Status(db::Code::kOk)));
    BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
        .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
    // local_lsn(0) >= sealed page_lsn(0): write must NOT be called.
    EXPECT_CALL(*_mock_db_engine, Write(_, _, _, _, _)).Times(0);
    FLAGS_psvr_disable_sync = true;
    EXPECT_CALL(*_mock_dblwr, RemoveBuf(_)).WillOnce(Return(db::Status(db::Code::kOk)));

    db::Status s = _segment->DumpDblwrBuf(1);
    ASSERT_TRUE(s.IsOk()) << s;

    BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    FLAGS_psvr_disable_sync = false;
    END_OF_CASE;
}

// DumpDblwrBuf: footer.ckp_lsn[1] > 0 → UpdateAppendDBCheckPoint is invoked.
// Uses PartialMockSegment to mock UpdateAppendDBCheckPoint so that the
// uninitialised _append_db_engine is never reached.
TEST_F(SegmentDataTests, test_DumpDblwrBuf_with_ckp_lsn) {
    // Build a segment whose UpdateAppendDBCheckPoint and Sync are mocked.
    auto partial_seg = std::shared_ptr<PartialMockSegment>(
        new PartialMockSegment(_control, "c1", 1,
                Segment::kUnknownReplicaID, Segment::kUnknownVersion,
                32ul << 30, true, Segment::Status::kCreating,
                "./data/c1/1", Segment::kUnknownStoreID, _cluster));
    partial_seg->_psm_info = _psm_info;

    // Wire up the same mocks as the rest of SegmentDataTests
    partial_seg->_db_engine.reset(new MockDBEngine());
    static_cast<MockDBEngine*>(partial_seg->_db_engine.get())->_page_size = (16 << 10);
    MockDBEngine* mock_eng = static_cast<MockDBEngine*>(partial_seg->_db_engine.get());

    MockDblwr* mock_dbl = new MockDblwr();
    partial_seg->_dblwr.reset(mock_dbl);
    EXPECT_CALL(*mock_dbl, Read(static_cast<uint64_t>(0), _))
        .WillRepeatedly(Return(db::Status(db::Code::kOk)));

    // page up-to-date (page_lsn=0); ckp_lsn=500 triggers the checkpoint branch
    auto dblwr_buf = MakeDblwrBufWithPage(/*page_lsn=*/0, /*ckp_lsn=*/500);
    EXPECT_CALL(*mock_dbl, DumpBuf()).WillOnce(Return(dblwr_buf));
    EXPECT_CALL(*_mock_store_manager, GetStore(_)).WillRepeatedly(Return(g_mock_store));
    EXPECT_CALL(*mock_eng, Read(_, _, _, _, _))
        .WillOnce(Return(db::Status(db::Code::kOk)));
    BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _))
        .WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
    EXPECT_CALL(*mock_eng, Write(_, _, _, _, _)).Times(0);
    // UpdateAppendDBCheckPoint is mocked: verify it IS called with lsn=500
    EXPECT_CALL(*partial_seg, UpdateAppendDBCheckPoint(500, true))
        .WillOnce(Return(db::Status(db::Code::kOk)));
    EXPECT_CALL(*partial_seg, Sync()).Times(1);
    EXPECT_CALL(*mock_dbl, RemoveBuf(_)).WillOnce(Return(db::Status(db::Code::kOk)));

    db::Status s = partial_seg->DumpDblwrBuf(1);
    ASSERT_TRUE(s.IsOk()) << s;
    BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    END_OF_CASE;
}

}
}
