/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/redo_record.cpp
* @author yukeyong@baidu.com
* @brief Common append redo record parser.
*/

#include "psvr/redo_record.h"

#include <cstdint>
#include <new>

#include "psvr/page_op.h"
#include "psvr/record_op.h"

namespace psvr {

db::Status parse_append_redo_record(
        gaia_apply::byte* record_start,
        gaia_apply::byte* record_end,
        gaia_apply::lsn_t record_end_lsn,
        void* record_storage,
        LogRecord** record,
        gaia_apply::ulint* record_len) {
    db::Status st;
    if (!record_start || !record_end || record_start >= record_end
            || !record_storage || !record || !record_len) {
        st.Reset(db::Code::kInvalid,
                "invalid append redo record parser argument");
        return st;
    }

    *record = nullptr;
    *record_len = 0;

    gaia_apply::mlog_id_t type =
            static_cast<gaia_apply::mlog_id_t>(0);
    gaia_apply::byte* body = nullptr;
    gaia_apply::ulint parsed_record_len = 0;
    gaia_apply::page_no_t page_no = 0;
    gaia_apply::space_id_t space_id = 0;
    uint32_t check_bits_len = 0;
    bool is_corrupt = false;
    INIT_APPLY_RAW_ARG(false);

    parsed_record_len = psvr_recv_parse_log_rec(
            &type,
            record_start,
            record_end,
            &space_id,
            &page_no,
            &body,
            &check_bits_len APPLY_RAW_ARG_NAME_CC,
            &is_corrupt);
    if (parsed_record_len == 0) {
        st.Reset(db::Code::kMissData,
                "append redo record is incomplete");
        return st;
    }
    if (is_corrupt || APPLY_RAW_IS_ERROR() || type == 0) {
        st.Reset(db::Code::kCorrupted,
                "append redo record parse failed, "
                "space_id:%u page_no:%u type:%u",
                space_id,
                page_no,
                static_cast<uint32_t>(type));
        return st;
    }

    const auto input_len = static_cast<size_t>(record_end - record_start);
    if (parsed_record_len > input_len
            || check_bits_len > parsed_record_len
            || !body) {
        st.Reset(db::Code::kCorrupted,
                "append redo record parse result is out of range, "
                "record_len:%u input_len:%lu check_bits_len:%u",
                parsed_record_len,
                input_len,
                check_bits_len);
        return st;
    }
    const auto record_begin = reinterpret_cast<uintptr_t>(record_start);
    const auto body_addr = reinterpret_cast<uintptr_t>(body);
    if (body_addr < record_begin
            || body_addr - record_begin > parsed_record_len) {
        st.Reset(db::Code::kCorrupted,
                "append redo record body pointer is out of range");
        return st;
    }

    const auto end_sn = log_translate_lsn_to_sn(record_end_lsn);
    if (end_sn == 0 || end_sn <= parsed_record_len) {
        st.Reset(db::Code::kCorrupted,
                "append redo record end lsn is invalid, "
                "end_lsn:%lu record_len:%u",
                record_end_lsn,
                parsed_record_len);
        return st;
    }

    const auto start_sn = end_sn - parsed_record_len;
    const auto start_lsn = log_translate_sn_to_lsn(start_sn);
    if (!log_lsn_validate(start_lsn)
            || record_end_lsn < start_lsn) {
        st.Reset(db::Code::kCorrupted,
                "append redo record lsn range is invalid, "
                "start_lsn:%lu end_lsn:%lu",
                start_lsn,
                record_end_lsn);
        return st;
    }

    gaia_apply::lsn_t real_record_start_lsn = 0;
    gaia_apply::lsn_t last_page_lsn = 0;
    bool has_page_check_bits = false;
    switch (check_bits_len) {
    case 0:
        break;
    case gaia_apply::RECORD_CHECK_BITS_LEN:
        real_record_start_lsn = gaia_apply::mach_read_from_8(
                record_start + parsed_record_len - check_bits_len);
        break;
    case gaia_apply::RECORD_CHECK_BITS_LEN
            + gaia_apply::PAGE_CHECK_BITS_LEN:
        last_page_lsn = gaia_apply::mach_read_from_8(
                record_start + parsed_record_len
                - gaia_apply::PAGE_CHECK_BITS_LEN);
        real_record_start_lsn = gaia_apply::mach_read_from_8(
                record_start + parsed_record_len - check_bits_len);
        has_page_check_bits = true;
        break;
    default:
        st.Reset(db::Code::kCorrupted,
                "invalid append redo check bits length:%u",
                check_bits_len);
        return st;
    }

    if (check_bits_len > 0
            && real_record_start_lsn != start_lsn) {
        st.Reset(db::Code::kCorrupted,
                "append redo record check bits mismatch, "
                "start_lsn:%lu real_start_lsn:%lu",
                start_lsn,
                real_record_start_lsn);
        return st;
    }

    const auto body_offset = body_addr - record_begin;
    if (body_offset > parsed_record_len - check_bits_len) {
        st.Reset(db::Code::kCorrupted,
                "append redo record body range is invalid");
        return st;
    }

    const auto body_len = parsed_record_len
            - static_cast<gaia_apply::ulint>(body_offset)
            - check_bits_len;
    new (record_storage) LogRecord(
            type,
            body,
            body_len,
            start_lsn,
            record_end_lsn,
            space_id,
            page_no,
            has_page_check_bits,
            last_page_lsn);

    *record = reinterpret_cast<LogRecord*>(record_storage);
    *record_len = parsed_record_len;
    return st;
}

}  // namespace psvr
