/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/store.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <filesystem>
#include "psvr/control_context.h"
#include "psvr/config.h"
#include "psvr/store_cfg.h"
#include "psvr/store.h"

namespace psvr {

void Store::Expose() {
#ifndef GTEST
    _stat_read_lat.expose(base::string_printf("psvr_store_%d_read", _id));
    _stat_write_lat.expose(base::string_printf("psvr_store_%d_write", _id));
    _stat_sync_lat.expose(base::string_printf("psvr_store_%d_sync", _id));
    _stat_gc_log_block_buf_bw.expose(base::string_printf("psvr_store_%d_gc_log_block_buf_bw", _id));
    _stat_gc_log_block_page_bw.expose(base::string_printf("psvr_store_%d_gc_log_block_page_bw", _id));
#endif
}

bool Store::LoadSegments(std::shared_ptr<LoadContext> load_ctx) {
    ControlPtr control = load_ctx->control;

    StoreCfg::IterSegFn iter_seg_fn = [this, &load_ctx, &control](const std::string& segment_dir) {
        load_ctx->segment_count.fetch_add(1);
        bool is_trash = false;
        SegmentPtr segment = OpenSegment(control, segment_dir, &is_trash);
        if (!segment && !is_trash) {
            load_ctx->load_failed_count.fetch_add(1, std::memory_order_relaxed);
            load_ctx->load_stat->failed_num.fetch_add(1, std::memory_order_relaxed);
            return;
        }
        load_ctx->load_finish_count.fetch_add(1, std::memory_order_relaxed);
        if (segment) {
            if (!control->segment_manager()->AddSegment(segment)) {
                LOG(ERROR) << segment << " add failed";
                load_ctx->load_stat->failed_num.fetch_add(1, std::memory_order_relaxed);
                return;
            }

            IncStatistic(segment, true);
            load_ctx->PushSegment(segment);
            LOG(NOTICE) << segment << " add ok";

            if (!segment->is_prepare()) {
                load_ctx->load_stat->load_num.fetch_add(1, std::memory_order_relaxed);
                auto* ctx = new Control::Context(Control::Action::kLoadSegmentMeta, segment);
                ctx->log_id = get_log_id();
                control->Dispatch(ctx);
            } else {
                load_ctx->load_stat->prepared_num.fetch_add(1, std::memory_order_relaxed);
            }
        }
    };

    bool empty_cluster_removed = false;
    StoreCfg::IterClsFn iter_cluster_fn = [this, &empty_cluster_removed](
            const std::string& cluster_dir, uint32_t segment_count) {
        // if cluster path have not segments, remove it
        if (segment_count == 0) {
            std::error_code rm_ec;
            bool tmp = std::filesystem::remove(cluster_dir, rm_ec);
            if (!tmp || rm_ec) {
                LOG(WARNING) << this << " delete empty dir failed, dir:[" << cluster_dir << "], " << rm_ec.message();
            } else {
                LOG(NOTICE) << this << " delete empty dir ok, dir:[" << cluster_dir << "]";
                empty_cluster_removed = true;
            }
        }
        return true;
    };

    bool rc = true;
    if (!_active) {
        LOG(WARNING) << this << " is inactive, ignore to load segments";
    } else {
        // check punch-hole supported before load segments
        const std::string punch_hole_file_name = base::string_printf("%s/%s", _trash_path.c_str(), kPunchHoleFile.c_str());
        db::check_punch_hole_feature(punch_hole_file_name, &_enable_punch_hole);
        LOG(NOTICE) << "check store punch hole,"
            << " id:[" << _id
            << "] path:[" << _path
            << "] enable_punch_hole:[" << _enable_punch_hole
            << "]";
        rc = StoreCfg::IteratorSegments(_path, iter_seg_fn, iter_cluster_fn);
    }
    if (empty_cluster_removed) {
        db::Status status = db::sync_directoryx(_path.c_str());
        if (!status.IsOk()) {
            LOG(ERROR) << this << " sync store directory after removing empty cluster failed,"
                << " dir:[" << _path << "], " << status;
            rc = false;
        }
    }

    LOG(NOTICE) << this << " load segment num:[" << _used_capacity << "]";
    return rc;
}

std::string Store::GetSegmentDBPath(const std::string& cluster_id, uint32_t segment_id) {
    std::string db_path = base::string_printf("%s/%s/%u",
            _path.c_str(), cluster_id.c_str(), segment_id);
    return db_path;
}

SegmentPtr Store::OpenSegment(ControlPtr control,
        const std::string& segment_dir, bool* is_trash, bool delete_inactive) {
    *is_trash = false;
    std::string meta_file = base::string_printf("%s/%s", segment_dir.c_str(), kMetaFileName);
    gaiadb::common::Config config;
    if (!config.Load(meta_file)) {
        LOG(ERROR) << this << " load segment meta file failed, file:[" << meta_file << "]";
        if (FLAGS_multi_psvr_enable_cleanup_store_incomplete_segment
                && !std::filesystem::exists(meta_file)) {
            std::filesystem::path segment_path(segment_dir);
            if (!DeleteSegmentPath(segment_dir,
                        segment_path.parent_path().filename(),
                        std::strtoul(segment_path.filename().c_str(), nullptr, 10))) {
                LOG(ERROR) << this << " delete incomplete segment failed, file:[" << meta_file << "]";
            }
        }
        return nullptr;
    }

    const std::string cluster_id = config.GetString("segment", "cluster_id", "");
    const std::string manager_address = config.GetString("segment", "manager_address", "");
    const int64_t segment_id = config.GetInt("segment", "segment_id", -1);
    const int64_t segment_size = config.GetInt("segment", "segment_size", -1);
    const int64_t replica_id = config.GetInt("segment", "replica_id", -1);
    const int64_t version = config.GetInt("segment", "version", 0);
    const int64_t meta_version = config.GetInt("segment", "meta_version", 0);
    if (cluster_id.empty()
            || manager_address.empty()
            || segment_id <= 0
            || segment_size <= 0
            || replica_id < 0
            || version < 0) {
        LOG(ERROR) << this << " get segment item value from meta file failed,"
            << " file:[" << meta_file
            << "] cluster_id:[" << cluster_id
            << "] manager_address:[" << manager_address
            << "] segment_id:[" << segment_id
            << "] segment_size:[" << segment_size
            << "] replica_id:[" << replica_id
            << "] version:[" << version
            << "] meta_version:[" << meta_version
            << "]";
        return nullptr;
    }

    LOG(TRACE) << this << " show segment item value from meta file,"
        << " file:[" << meta_file
        << "] cluster_id:[" << cluster_id
        << "] manager_address:[" << manager_address
        << "] segment_id:[" << segment_id
        << "] segment_size:[" << segment_size
        << "] replica_id:[" << replica_id
        << "] version:[" << version
        << "] meta_version:[" << meta_version
        << "]";

    const std::string status_str = config.GetString("segment", "status", "");
    Segment::Status status = Segment::str2status(status_str);
    if (status == Segment::Status::kUnknown) {
        LOG(ERROR) << this << " get status in meta file failed, file:[" << meta_file << "]";
        return nullptr;
    }

    std::filesystem::path segment_path(segment_dir);
    if (segment_path.filename() != std::to_string(segment_id)
            || segment_path.parent_path().filename() != cluster_id) {
        LOG(ERROR) << this << " mismatch,"
            << " path:[" << segment_dir
            << "] cluster_id:[" << cluster_id
            << "] segment_id:[" << segment_id
            << "]";
        return nullptr;
    }

    if (status == Segment::Status::kDelete
            || status == Segment::Status::kCreating) {
        *is_trash = true;
        if (delete_inactive) {
            LOG(NOTICE) << this << " move inactive segment to trash, path:[" << segment_dir << "]";
            if (!DeleteSegmentPath(segment_dir, cluster_id, segment_id)) {
                LOG(ERROR) << this << " delete close/creating segment failed, file:[" << meta_file << "]";
            }
        }
        return nullptr;
    }

    const std::string rebalance_from = config.GetString("rebalance", "from", "");
    const uint64_t rebalance_version = config.GetInt("rebalance", "version", 0);

    ClusterPtr cluster = control->segment_manager()->GetOrCreateCluster(cluster_id);
    PsmInfoPtr psm_info = control->segment_manager()->GetOrCreatePsmInfo(manager_address);
    SegmentPtr segment(new Segment(control, cluster_id, segment_id, replica_id, version,
                segment_size, _enable_punch_hole, status, segment_dir, _id, cluster));
    segment->InitPsmInfo(psm_info);
    if (!rebalance_from.empty()) {
        segment->SetRebalanceNode(rebalance_from, rebalance_version);
    }
    segment->set_meta_version(meta_version);
    LOG(TRACE) << segment << " load ok, " << psm_info;
    return segment;
}

bool Store::EnableAddSegment(int64_t size) {
    std::shared_lock lm(_mutex);
    if (!_active) {
        return false;
    }
    if (_capacity >= 0
            && _used_capacity >= _capacity) {
        LOG(WARNING) << this << " capacity used up";
        return false;
    }
    if (_free_size < size) {
        LOG(WARNING) << this << " not free size";
        return false;
    }
    return true;
}

bool Store::IncStatistic(SegmentPtr segment, bool is_load) {
    std::unique_lock lm(_mutex);
    if (!_active) {
        return false;
    }
    if (_capacity >= 0
            && _used_capacity + 1 > _capacity) {
        if (!is_load) {
            return false;
        }
    }
    _logic_used_size += segment->segment_size();
    ++_used_capacity;
    return true;
}

void Store::DecStatistic(SegmentPtr segment) {
    std::unique_lock lm(_mutex);
    _logic_used_size -= segment->segment_size();
    --_used_capacity;
}

bool Store::DeleteSegment(SegmentPtr segment) {
    return DeleteSegmentPath(segment->db_path(),
            segment->cluster_id(), segment->segment_id());
}

bool Store::DeleteSegmentPath(const std::string& path,
        const std::string& cluster_id, uint32_t segment_id) {
    std::unique_lock lm(_mutex);
    if (!_active) {
        return true;
    }

    std::filesystem::path segment_path(path);
    if (segment_path.filename() != std::to_string(segment_id)
            || segment_path.parent_path().filename() != cluster_id) {
        LOG(ERROR) << this << " mismatch,"
            << " path:[" << path
            << "] cluster_id:[" << cluster_id
            << "] segment_id:[" << segment_id
            << "]";
        return false;
    }

    if (!std::filesystem::exists(path)) {
        LOG(WARNING) << this << " not found delete path, " << path;
        return true;
    }
    std::error_code ec;
    if (!std::filesystem::exists(_trash_path, ec)) {
        if (!std::filesystem::create_directory(_trash_path, ec)) {
            LOG(WARNING) << this << " init trash dir failed, " << ec.message();
            return false;
        }
        const auto trash_parent_path = std::filesystem::path(_trash_path).parent_path();
        db::Status status = db::sync_directoryx(trash_parent_path.c_str());
        if (!status.IsOk()) {
            LOG(ERROR) << this << " sync trash parent directory failed, dir:["
                << trash_parent_path << "], " << status;
            return false;
        }
    }
    std::string trash = base::string_printf("%s/%s_%s_%u_%ld", _trash_path.c_str(),
            kTrashSegmentPrefixName.c_str(), cluster_id.c_str(), segment_id, base::gettimeofday_s());
    uint32_t i = 0;
    while (std::filesystem::exists(trash)) {
        trash = base::string_printf("%s/%s_%s_%u_%ld_%u", _trash_path.c_str(),
                kTrashSegmentPrefixName.c_str(), cluster_id.c_str(), segment_id, base::gettimeofday_s(), ++i);
    }
    std::filesystem::rename(path, trash, ec);
    if (ec) {
        LOG(WARNING) << "rename file:[" << path << "] to tmp failed, dst:[" << trash << "] " << ec.message();
        return false;
    }
    db::Status source_status = db::sync_directoryx(segment_path.parent_path().c_str());
    db::Status target_status = db::sync_directoryx(_trash_path.c_str());
    if (!source_status.IsOk() || !target_status.IsOk()) {
        LOG(ERROR) << this << " sync segment rename directories failed, source:["
            << segment_path.parent_path() << "], source_status:[" << source_status
            << "], target:[" << _trash_path << "], target_status:[" << target_status << "]";
        return false;
    }
    return true;
}

void Store::UpdateFreeSize(volatile const bool& stopped) {
    std::unique_lock lm(_mutex);
    UpdateFreeSizeNoLock(stopped);
}

void Store::UpdateFreeSizeNoLock(volatile const bool& stopped) {
    if (!_active || stopped) {
        return;
    }
    std::error_code err;
    std::filesystem::space_info store_info = std::filesystem::space(_path, err);
    if (err) {
        LOG(ERROR) << "get store:[" << this << "] info failed, " << err;
        return;
    }

    int64_t free_size = static_cast<int64_t>(store_info.free);
    _physical_size = store_info.capacity;
    _physical_free_size.store(free_size);
    _physical_used_size = store_info.capacity - store_info.free;
    if (!_specify_size) {
        _size = static_cast<int64_t>(store_info.capacity);
        _free_size.store(free_size, std::memory_order_relaxed);
    } else {
        _free_size.store(_size - _physical_used_size);
    }
}

void Store::IncIOErrorCount(TRACE_FILE_LINE_D) {
    int64_t n = _io_error_count.fetch_add(1, std::memory_order_relaxed);
    if (n == 0 || n == 9 || n == 19 || n == 29) { // avoid flood
        LOG(ERROR) << this << " io error many times" << TRACE_FILE_LINE_LOG_STR;
    }
}

void Store::ClearIOError() {
    int64_t n = _io_error_count.exchange(0);
    if (n > 0) {
        LOG(NOTICE) << this << " clear io error number";
    }
}

void Store::GetStoreInfo(pspb::MultiGetStatusResponse::Store* info) {
    std::shared_lock lm(_mutex);
    info->set_store_id(_id);
    info->set_active(_active);
    info->set_physical_store_size(_physical_size);
    info->set_store_size(_size);
    info->set_specify_store_size(_specify_size);
    info->set_free_size(free_size());
    info->set_logic_used_size(_logic_used_size);
    info->set_physical_used_size(_physical_used_size);
    info->set_capacity(_capacity);
    info->set_used_capacity(_used_capacity);
    info->set_store_path(_path);
    info->set_io_error_count(_io_error_count.load(std::memory_order_relaxed));
}

// run single thread
void Store::GcTrash(volatile const bool& stopped) {
    if (!_active || stopped) {
        return;
    }
    std::error_code ec;
    if (!std::filesystem::exists(_trash_path, ec)) {
        LOG(TRACE) << this << " trash path not exists, trash_path:[" << _trash_path << "]";
        return;
    }
    int32_t remove_num = FLAGS_multi_psvr_gc_trash_segment_num;
    bool removed = false;
    for (auto& trash_file : std::filesystem::directory_iterator(_trash_path, ec)) {
        std::string file_name = trash_file.path().filename().string();
        if (file_name.compare(0, kTrashSegmentPrefixName.size(), kTrashSegmentPrefixName) == 0) {
            if (remove_num < 1) {
                if (removed) {
                    db::Status status = db::sync_directoryx(_trash_path.c_str());
                    if (!status.IsOk()) {
                        LOG(ERROR) << this << " sync trash dir failed, dir:["
                            << _trash_path << "], " << status;
                    }
                }
                return;
            }
            struct stat file_status;
            if (lstat(trash_file.path().c_str(), &file_status) != 0) {
                LOG(WARNING) << this << " fail to lsstat file:" << trash_file.path();
                continue;
            }

            int64_t ctime = file_status.st_ctime;   // change time
            int64_t max_in_trash_time = FLAGS_multi_psvr_segment_in_trash_second;
            if (ctime + max_in_trash_time >= base::gettimeofday_s()) {
                continue;
            }

            Timer timer(base::Timer::STARTED);
            std::error_code ec2;
            std::filesystem::remove_all(trash_file.path(), ec2);
            if (ec2) {
                LOG(ERROR) << this << " remove trash dir:[" << trash_file.path()
                    << "] failed:[" << ec2.message() << "]";
                if (removed) {
                    db::Status status = db::sync_directoryx(_trash_path.c_str());
                    if (!status.IsOk()) {
                        LOG(ERROR) << this << " sync trash dir failed, dir:["
                            << _trash_path << "], " << status;
                    }
                }
                return;
            } else {
                LOG(NOTICE) << this << " remove trash file ok,"
                    << " name:[" << trash_file.path()
                    << "] used_time:[" << timer.u_elapsed()
                    << "]";
                removed = true;
                --remove_num;
            }
        }
        if (stopped) {
            if (removed) {
                db::Status status = db::sync_directoryx(_trash_path.c_str());
                if (!status.IsOk()) {
                    LOG(ERROR) << this << " sync trash dir failed, dir:["
                        << _trash_path << "], " << status;
                }
            }
            return;
        }
    }
    if (ec) {
        LOG(ERROR) << this << " fail to gc trash dir:[" << _path << "] " << ec.message();
    }
    if (removed) {
        db::Status status = db::sync_directoryx(_trash_path.c_str());
        if (!status.IsOk()) {
            LOG(ERROR) << this << " sync trash dir failed, dir:["
                << _trash_path << "], " << status;
        }
    }
}

bool Store::IsActive() {
    std::shared_lock slk(_mutex);
    return _active;
}

bool Store::Disable() {
    std::unique_lock lm(_mutex);
    if (_active) {
        LOG(WARNING) << "disable " << this << ", active:[" << _active << "]";
        _active = false;
        return true;
    }
    return false;
}

bool Store::Enable() {
    std::unique_lock lm(_mutex);
    if (!_active) {
        LOG(WARNING) << "enable " << this << ", active:[" << _active << "]";
        _active = true;
        return true;
    }
    return false;
}

int64_t Store::UpdateCapacity(int64_t capacity) {
    std::unique_lock lm(_mutex);
    int64_t original_val = _capacity;
    _capacity = capacity >= 0 ? capacity : -1;
    return original_val;
}

int64_t Store::UpdateSize(int64_t size) {
    std::unique_lock lm(_mutex);
    int64_t original_val = _specify_size ? _size : -1;
    if (size >= 0) {
        _size = size;
        _specify_size = true;
    } else {
        _size = -1;
        volatile bool stopped = false;
        UpdateFreeSizeNoLock(stopped);
        _specify_size = false;
    }
    return original_val;
}

void Store::GetConfigItems(gaiadb::common::Config* config) {
    std::shared_lock lm(_mutex);
    std::string section = base::string_printf("store%u", _id);
    config->SetString(section, "path", _path);
    config->SetInt(section, "active", _active ? 1 : 0);
    if (_specify_size) {
        config->SetInt(section, "size", _size);
    }
    if (_capacity >= 0) {
        config->SetInt(section, "capacity", _capacity);
    }
}

bool StoreManager::ParseStoreCfgFile(const std::string& store_cfg,
        bool is_absolute_path, std::map<int32_t, StorePtr>* stores) {

    stores->clear();
    StoreCfg::ParseFn check_and_create_store_fn = [&stores, &is_absolute_path](int32_t id,
            const std::string& section, const std::string& path,
            bool active, int64_t size, int64_t capacity) -> bool {

        int64_t physical_size = 0;
        int64_t free_size = 0;
        bool specify_size = true;
        std::string trash_dir = "";
        // only check active store.
        // if store error, maybe some checks return error, let server start failed.
        if (active) {
            if (path.size() < 1) {
                LOG(ERROR) << "not found store:[" << section << "] path or invalid";
                return false;
            }
            std::error_code err;
            std::filesystem::path store_path(path);
            if (!store_path.is_absolute() && is_absolute_path) {
                LOG(ERROR) << "store path:[" << path << "] is not absolute";
                return false;
            }
            const auto& store_path_filename = store_path.filename();
            if (store_path_filename == "."
                    || store_path_filename == ".."
                    || store_path_filename == "") {
                LOG(ERROR) << "store path:[" << path << "] is error, the end of path is . or .. or /";
                return false;
            }
            if (!std::filesystem::exists(store_path, err) || err) {
                LOG(ERROR) << "store path:[" << path << "] not exists or error:" << err.message();
                return false;
            }

            std::filesystem::space_info store_info = std::filesystem::space(path, err);
            if (err) {
                LOG(ERROR) << "get store:[" << std::filesystem::absolute(path) << "] info failed, " << err.message();
                return false;
            }

            physical_size = static_cast<int64_t>(store_info.capacity);
            free_size = static_cast<int64_t>(store_info.free);
            if (size < 0) {
                specify_size = false;
                size = physical_size;
            } else {
                if (size > static_cast<int64_t>(store_info.capacity)) {
                    LOG(ERROR) << "store:[" << section << "] size:[" << size
                        << "] over system max size:[" << store_info.capacity << "]";
                    return false;
                }
            }
            trash_dir = base::string_printf("%s/%s/", path.c_str(), kTmpDirName.c_str());
            if (!std::filesystem::exists(trash_dir, err)) {
                if (!std::filesystem::create_directory(trash_dir, err)) {
                    LOG(WARNING) << "store:[" << section << "] init trash dir failed, " << err.message();
                    return false;
                }
                const auto trash_parent_path = std::filesystem::path(trash_dir).parent_path();
                db::Status status = db::sync_directoryx(trash_parent_path.c_str());
                if (!status.IsOk()) {
                    LOG(ERROR) << "sync trash parent directory failed, dir:["
                        << trash_parent_path << "], " << status;
                    return false;
                }
            }
        }
        StorePtr store(new Store(id, path, trash_dir, active, physical_size, size, free_size, specify_size, capacity));
        stores->emplace(std::make_pair(id, store));
        return true;
    };

    return StoreCfg::Parse(store_cfg, check_and_create_store_fn);
}

bool StoreManager::Init() {
    std::unique_lock lm(_mutex);
    return ParseStoreCfgFile(FLAGS_psvr_store_config_file, _is_absolute_path, &_stores);
}

bool StoreManager::InitBatchFetch(ControlPtr control) {
    if (!FetcherType::IsBatchByCluster()) {
        LOG(NOTICE) << "disable batch fetch or batch fetch type not cluster";
        return true;
    }
    gaiadb::common::Config config;
    if (FLAGS_psvr_fetch_batch_cluster_type_config_file.empty()
            || !config.Load(FLAGS_psvr_fetch_batch_cluster_type_config_file)) {
        LOG(ERROR) << "load or parse batch cluster fetch config file failed,"
            << " file:[" << FLAGS_psvr_fetch_batch_cluster_type_config_file
            << "]";
        return false;
    }

    std::vector<std::string> clusters;
    int size = config.GetStringLists("cluster", "id", &clusters);
    if (size) {
        control->segment_manager()->SetBatchFetchClusters(clusters);
    }
    LOG(NOTICE) << "load use batch cluster fetch config ok,"
        << " size:[" << size
        << "]";
    return true;
}

bool StoreManager::Start(ControlPtr control, std::shared_ptr<LoadStat> load_stat) {
    LOG(NOTICE) << "start to load store segments ...";
    // set flag to wait load thread
    _stopped = false;
    std::vector<std::shared_ptr<std::thread>> threads;
    std::vector<std::shared_ptr<LoadContext>> load_ctxs;
    uint32_t count = StoreCount();
    for (uint32_t i = 0; i < count; ++i) {
        std::shared_ptr<LoadContext> load_ctx(new LoadContext(control, i, load_stat));
        std::shared_ptr<std::thread> thread(new std::thread(&StoreManager::LoadStoreSegments, this, load_ctx));
        load_ctxs.push_back(load_ctx);
        threads.push_back(thread);
    }

    for (uint32_t i = 0; i < count; ++i) {
        threads[i]->join();
    }

    bool has_error = false;
    for (uint32_t i = 0; i < count; ++i) {
        if (load_ctxs[i]->load_failed_count.load()
                || !load_ctxs[i]->rc) {
            LOG(ERROR) << "store:[" << _stores[i]->path() << "] load segments failed";
            has_error = true;
        }
    }

    //for (uint32_t i = 0; i < count; ++i) {
        //auto load_ctx = load_ctxs[i];
        //for (auto segment : load_ctx->segments) {
            //if (segment->is_prepare()) {
                //continue;
            //}
        //}
    //}
    if (!has_error) {
        LOG(NOTICE) << "load store segments success";
    }
    return true;
}

void StoreManager::Stop() {
    _stopped = true;
    LOG(NOTICE) << "store manager stopped!";
}

bool StoreManager::StoreConfigFile() {
    std::shared_lock lm(_mutex);
    gaiadb::common::Config config;
    config.SetInt("store", "count", _stores.size());
    for (auto& it : _stores) {
        it.second->GetConfigItems(&config);
    }
    const std::string& store_cfg = FLAGS_psvr_store_config_file;
    if (!atomic_write_file(store_cfg, config.ToString(), true/*sync*/)) {
        LOG(ERROR) << "store config[" << store_cfg << "] file failed";
        return false;
    }
    const auto store_cfg_parent_path = std::filesystem::path(store_cfg).parent_path();
    db::Status status = db::sync_directoryx(store_cfg_parent_path.c_str());
    if (!status.IsOk()) {
        LOG(ERROR) << "store config directory sync failed, file:[" << store_cfg
            << "], dir:[" << store_cfg_parent_path << "], " << status;
        return false;
    }
    return true;
}

void StoreManager::LoadStoreSegments(std::shared_ptr<LoadContext> load_ctx) {
    StorePtr store = _stores[load_ctx->store_id];
    load_ctx->rc = store->LoadSegments(load_ctx);
    if (!load_ctx->rc) {
        LOG(ERROR) << "load segment failed on " << store;
        return;
    }
    if (load_ctx->load_failed_count.load(std::memory_order_relaxed)) {
        LOG(ERROR) << "load segment failed on " << store;
        return;
    }
    // wait finish
    while (!_stopped) {
        if ((load_ctx->load_finish_count.load() + load_ctx->load_failed_count.load())
                >= load_ctx->segment_count.load()) {
            break;
        }
        sleep_for(SLEEP_SECOND);
    }

    LOG(NOTICE) << store << " load succ, finish_size:[" << load_ctx->load_finish_count.load()
        << "] fail_size:[" << load_ctx->load_failed_count.load()
        << "] total_size:[" << load_ctx->segment_count.load()
        << "]";
}

uint32_t StoreManager::StoreCount() {
    std::shared_lock lm(_mutex);
    return static_cast<uint32_t>(_stores.size());
}

StorePtr StoreManager::GetStore(int32_t id) {
    std::shared_lock lm(_mutex);
    auto it = _stores.find(id);
    if (it != _stores.end()) {
        return it->second;
    }
    return nullptr;
}

uint32_t StoreManager::GetStores(const StoreIteratorFn& fn) {
    std::vector<StorePtr> stores;
    uint32_t n = GetStores(&stores);
    for (auto& it : stores) {
        if (!fn (it)) {
            break;
        }
    }
    return n;
}

uint32_t StoreManager::GetStores(std::vector<StorePtr>* stores) {
    std::shared_lock lm(_mutex);
    for (auto& it : _stores) {
        stores->push_back(it.second);
    }
    return static_cast<uint32_t>(_stores.size());
}

}
