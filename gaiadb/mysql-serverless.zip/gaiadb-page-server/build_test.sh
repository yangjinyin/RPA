bcloud local --update -j8 --no-release.bcloud
make -j8
make test

if [ ! -d output ]; then
    mkdir output
fi

find ../../../bc_out/baidu/dba/gaiadb-page-server -name '*.gcno' | xargs -I {} cp {} ./output
find ../../../bc_out/baidu/dba/gaiadb-page-server -name '*.gcda' | xargs -I {} cp {} ./output
