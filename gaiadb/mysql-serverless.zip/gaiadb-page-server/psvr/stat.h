/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/stat.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <bvar/bvar.h>

namespace psvr {

int64_t get_stat_flow_count(void*);
int64_t get_window_stat_flow_qps(void*);

static constexpr time_t kSlaWindowSize = 10;

namespace detail {

template<typename R>
class WindowExType {
public:
    R var;
    bvar::Window<R> window;

    WindowExType(time_t window_size)
        : window(&var, window_size) {}
};

template<typename R>
class PerSecondExType {
public:
    R var;
    bvar::PerSecond<R> window;

    PerSecondExType(time_t window_size)
        : window(&var, window_size) {}
};

template<typename R, typename ExType>
class WindowEx {
    typedef typename R::value_type value_type;
public:
    WindowEx(time_t window_size)
        : _window_size(window_size),
        _ex(_window_size) {}
    WindowEx(const base::StringPiece& prefix,
        time_t window_size)
        : WindowEx(window_size) {
        expose(prefix);
    }

    WindowEx(const base::StringPiece& prefix,
        const base::StringPiece& name,
        time_t window_size)
        : WindowEx(window_size) {
        expose_as(prefix, name);
    }

    ~WindowEx() {
        hide();
    }

    int expose(const base::StringPiece& prefix) {
        return _ex.window.expose(prefix);
    }

    int expose_as(const base::StringPiece& prefix,
            const base::StringPiece& name) {
        return _ex.window.expose_as(prefix, name);
    }

    bool hide() {
        return _ex.window.hide();
    }

    value_type get_value() const {
        return _ex.window.get_value();
    }

    template<typename T>
    WindowEx& operator<<(T value) {
        _ex.var << value;
        return *this;
    }

private:
    time_t _window_size;
    ExType _ex;
};

template<typename R>
using Window = WindowEx<R, WindowExType<R>>;

template<typename R>
using PerSecond = WindowEx<R, PerSecondExType<R>>;

} // end of ns detail

// 在 window_size 该段时间内的累加数
template<typename T = int32_t>
using StatCountT = detail::Window<bvar::Adder<T>>;
using StatCount = StatCountT<>;
// 在 window_size 该段时间内的, 平均每秒的累加值
template<typename T = int32_t>
using StatQpsT = detail::PerSecond<bvar::Adder<T>>;
using StatQps = StatQpsT<>;
template<typename T = int64_t>
using StatBwT = detail::PerSecond<bvar::Adder<T>>;
using StatBw = StatBwT<>;
// 在 window_size 该段时间内的平均值
using StatAvg = detail::Window<bvar::IntRecorder>;
// 在 window_size 该段时间内的最大和最小值
template<typename T = int64_t>
using StatMaxT = detail::Window<bvar::Maxer<T>>;
using StatMax = StatMaxT<>;
template<typename T = int64_t>
using StatMinT = detail::Window<bvar::Miner<T>>;
using StatMin = StatMinT<>;

class StatLatency : public bvar::LatencyRecorder {
public:
    StatLatency() : bvar::LatencyRecorder() {}
    StatLatency(time_t window_size) : bvar::LatencyRecorder(window_size) {}
    StatLatency(const base::StringPiece& prefix,
        time_t window_size)
        : bvar::LatencyRecorder(prefix, window_size) {}
    StatLatency(const base::StringPiece& prefix,
        const base::StringPiece& name,
        time_t window_size)
        : bvar::LatencyRecorder(prefix, name, window_size) {}

    int expose_as(const base::StringPiece& prefix,
            const base::StringPiece& name) {
        return bvar::LatencyRecorder::expose(prefix, name);
    }
    StatLatency& operator <<(int64_t latency) {
        if (static_cast<int64_t>(static_cast<int32_t>(latency)) == latency) {
            bvar::LatencyRecorder::operator << (latency);
        }
        return *this;
    }

};

class StatSize {
public:
    StatSize(time_t window_size)
        : _avg(window_size),
         _max(window_size),
        _min(window_size),
        _qps(window_size) {
    }
    StatSize(const base::StringPiece& prefix,
            time_t window_size) : StatSize(window_size) {
        expose(prefix);
    }
    StatSize(const base::StringPiece& prefix,
            const base::StringPiece& name,
            time_t window_size) : StatSize(window_size) {
        expose_as(prefix, name);
    }
    ~StatSize() {
        hide();
    }

    StatSize& operator <<(int64_t size) {
        _avg << size;
        _max << size;
        _min << size;
        _qps << 1;
        return *this;
    }

    void expose(const base::StringPiece& prefix) {
        expose_as(base::StringPiece(), prefix);
    }

    void expose_as(const base::StringPiece& prefix,
            const base::StringPiece& name) {
        base::StringPiece real_prefix = name;
        std::string tmp;
        if (!prefix.empty()) {
            tmp.reserve(prefix.size() + name.size() + 1);
            tmp.append(prefix.data(), prefix.size());
            tmp.push_back('_');
            tmp.append(name.data(), name.size());
            real_prefix = tmp;
        }
        _avg.expose_as(real_prefix, "avg");
        _max.expose_as(real_prefix, "max");
        _min.expose_as(real_prefix, "min");
        _qps.expose_as(real_prefix, "qps");
    }

    void hide() {
        _avg.hide();
        _max.hide();
        _min.hide();
        _qps.hide();
    }

private:
    StatAvg _avg;
    StatMax _max;
    StatMin _min;
    StatQps _qps;
};

template<typename T>
struct AutoStatLat {
    int64_t begin;
    T& stat_name;

    AutoStatLat(T& name) : begin(base::cpuwide_time_us()), stat_name(name) {}
    ~AutoStatLat() {
        stat_name << (base::cpuwide_time_us() - begin);
    }
};

}
