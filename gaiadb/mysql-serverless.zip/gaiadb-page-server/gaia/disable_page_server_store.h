/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/disable_page_server_store.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class DisablePageServerStore : public Command {
public:
    DisablePageServerStore() {
        SetName("disable-ps-store");
        SetDesc("disable store on page server (will drop store all segments)");
        SetDescCn("禁用存储服务器上的磁盘 (将删除该磁盘上所有分片)");

        AddNodeOption();
        AddRequiredArgOption("id", &_long_opt_val, kOptMax + 1, "the store will be droped", kint32_t);
        AddRequiredArgOption("path", &_long_opt_val, kOptMax + 2, "check if the store path matched", kstring);

        AddExample("-a <ip> -p <port> --id 1 --path \"/data/store0/data\"");
    }
    virtual ~DisablePageServerStore() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 0: // long option
            switch (_long_opt_val) {
            case kOptMax + 1:
                _store_id = std::strtol(opt, NULL, 10);
                break;
            case kOptMax + 2:
                _store_path = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::DisableStoreResponse& rsp);
private:
    std::string _address {};
    int32_t _port {0};
    int32_t _store_id {-1};
    std::string _store_path {};
};

}
}
