/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_page_server_recovery_prior.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class SetPageServerRecoveryPrior : public Command {
public:
    SetPageServerRecoveryPrior() {
        SetName("set-ps-recovery-prior");
        SetDesc("set priority for recovering segment on page server");
        SetDescCn("设置存储服务器上分片恢复的优先级");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "update segments that matches the cluster id", kstring);
        AddRequiredArgOption("segment-id", NULL, 's', "and match the segment id, if specified", kuint32_t);
        AddRequiredArgOption("prior", &_long_opt_val, kOptMax + 1,
                "prior number, larger values indicate higher priority",
                kuint32_t);
        
        AddExample("-a <ip> -p <port> -c gaia-test-perf -s 1 --prior 1");
    }
    virtual ~SetPageServerRecoveryPrior() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtol(opt, NULL, 10));
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _prior = std::strtol(opt, NULL, 10);
                break;
            default:
                return 1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::SetRecoverPriorResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
    uint32_t _prior {0};
};

}
}
