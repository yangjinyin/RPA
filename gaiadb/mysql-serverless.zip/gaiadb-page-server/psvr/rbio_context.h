/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/rbio_context.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <baidu/rpc/closure_guard.h>  // brpc ClosureGuard

#include "psvr/context_types.h"
#include "psvr/rbio.h"
#include "psvr/time_point.h"

namespace psvr {

struct BAIDU_CACHELINE_ALIGNMENT RbioManager::Context : public thread::TaskContext {
    Task* task {nullptr};
    Action action {Action::kInit};
    size_t thread_pool_idx {0};

    uint32_t idx {0};
    uint32_t space_id {gaia_apply::SPACE_UNKNOWN};
    uint32_t logical_page_no {gaia_apply::FIL_NULL};
    uint64_t page_physical_offset {gaia_apply::ULINT_UNDEFINED};
    uint64_t vlsn {0};
    uint64_t real_apply_lsn {0};
    uint64_t size {0};
    uint64_t lowest_lsn {0};

    int64_t fetch_begin_time {0};
    int64_t fetch_end_time {0};
    int64_t parse_end_time {0};
    int64_t apply_end_time {0};

    int64_t vlsn_diff_fetch {-1};
    int64_t vlsn_diff_ls_dispatch_lsn {-1};
    int64_t vlsn_diff_fetch_after_retry_xx[4] = {-1, -1, -1, -1}; //after retry 40/80/120/160 times
    int64_t vlsn_diff_ls_dispatch_lsn_after_retry_xx[4] = {-1, -1, -1, -1}; //after retry 40/80/120/160 times

    int64_t secondary_fetch_diff_fetch {-1};
    int64_t secondary_fetch_diff_parse {-1};
    int64_t secondary_ls_dispatch_diff_fetch {-1};
    int64_t secondary_ls_dispatch_diff_parse {-1};

    pspb::RbioResponse_ResponseInfo* read_rsp {nullptr};
    const pspb::WritePageRequest_RequestInfo* write_req {nullptr};

    BufBlockPtr buf_block {nullptr};

    uint32_t retry_times {0};
    uint32_t fetch_lsn_retry_times {0};
    const uint32_t max_retry_times {128};

    Timer stat_timer;           // for stat
    TimePoint* tp {nullptr};

    Context(Task* t)
        : thread::TaskContext(CtxType::kRbio), task(t) {}
    virtual ~Context() {}

    void Init(Action _action, uint64_t _request_id, uint32_t _idx,
            const pspb::RbioRequest_RequestInfo* req,
            pspb::RbioResponse_ResponseInfo* rsp, int64_t begin_time);

    void Init(Action _action, uint64_t _request_id, uint32_t _idx,
            const pspb::WritePageRequest_RequestInfo* req, int64_t begin_time);

    bool Finish(RbioError code, bool* is_ok);
    bool Finish(pspb::WritePageResponse_Error code, bool* is_ok);
};

struct BAIDU_CACHELINE_ALIGNMENT RbioManager::Task {
    enum ReqType {
        kUnInit = 0,
        kRead,
        kWrite,
    };
    enum ReqRole {
        RBIO_OTHER = 0,
        RBIO_PRIMARY,
        RBIO_SECONDARY,
    };

    SegmentWeakPtr segment;
    Timer stat_timer;

    bool is_peer_read;
    pspb::RbioRequest::VersionRule read_rule;
    bool segment_in_recovery;

    int32_t role;
    bool req_has_physical_extent_id;
    uint32_t req_physical_extent_id;
    bool enable_attachment_type;
    uint64_t secondary_fetch_lsn;
    uint64_t secondary_ls_dispatch_lsn;

    int32_t quota_store_id;

    const uint32_t req_count;
    std::atomic<uint32_t> finish_count;
    Context* reqs[GAIADB_EXTENT_PAGE_NUM];

    Task(SegmentPtr _segment, uint32_t req_nr);
    virtual ~Task();

    virtual ReqType type() const = 0;

    bool is_read() const { return type() == ReqType::kRead; }
    bool is_write() const { return type() == ReqType::kWrite; }

    bool is_primary_req() const { return role == RBIO_PRIMARY; }
    bool is_secondary_req() const { return role == RBIO_SECONDARY; }
};

struct BAIDU_CACHELINE_ALIGNMENT RbioManager::ReadTask : public RbioManager::Task {
    brpc::Controller* cntl;
    const pspb::RbioRequest* request;
    pspb::RbioResponse* response;
    ggpb::Closure* closure;
    std::atomic<pspb::RbioResponse::Error> last_error_code;
    bool wait_lsn;
    int32_t max_error_code;

    ReadTask(SegmentPtr _segment,
        uint32_t req_nr,
        brpc::Controller* _cntl,
        const pspb::RbioRequest* req,
        pspb::RbioResponse* rsp,
        ggpb::Closure* done)
        : Task(_segment, req_nr),
        cntl(_cntl), request(req), response(rsp), closure(done),
        last_error_code(pspb::RbioResponse::RBIO_SUCCESS),
        wait_lsn(false),
        max_error_code(kRbioMaxErrorCodeOld) {}
    virtual ~ReadTask() {
        baidu::rpc::ClosureGuard closure_guard(closure);
        auto st = handle_rbio_error_code(last_error_code.load(std::memory_order_acquire), max_error_code);
        response->set_errcode(st);
        if (enable_attachment_type
                && st == pspb::RbioResponse::RBIO_SUCCESS) {
            LOG(TRACE) << this << " enable attachment";
            for (uint32_t i = 0; i < req_count; ++i) {
                auto req = reqs[i];
                // if RBIO_SUCCESS, the req buf block must be alloced.
                cntl->response_attachment().append(req->buf_block->frame, req->size);
            }
        }
        if (st == pspb::RbioResponse::RBIO_SUCCESS) {
            PSVR_ASSERT(response->resvec_size() == request->reqvec_size());
        }
    }

    virtual ReqType type() const override { return ReqType::kRead; }
    bool Init(int64_t begin_time);
};

struct BAIDU_CACHELINE_ALIGNMENT RbioManager::WriteTask : public RbioManager::Task {
    const pspb::WritePageRequest* request;
    pspb::WritePageResponse* response;
    ggpb::Closure* closure;
    std::atomic<pspb::WritePageResponse::Error> last_error_code;

    WriteTask(SegmentPtr _segment,
        uint32_t req_nr,
        const pspb::WritePageRequest* req,
        pspb::WritePageResponse* rsp,
        ggpb::Closure* done)
        : Task(_segment, req_nr),
        request(req), response(rsp), closure(done),
        last_error_code(pspb::WritePageResponse::SUCCESS) {}
    virtual ~WriteTask() {
        baidu::rpc::ClosureGuard closure_guard(closure);
        response->mutable_status()->set_code(last_error_code.load(std::memory_order_acquire));
    }

    virtual ReqType type() const override { return ReqType::kWrite; }
    void Init(int64_t begin_time);
};

}
