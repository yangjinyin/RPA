/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_segment_replica.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/update_segment_replica.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int UpdateSegmentReplica::Run() {
    RpcStatus status;
    gaiapb::UpdateReplicaRequest request;
    gaiapb::AckResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_segment_id < 1) {
        print_error("miss --segment-id or error, %u", _segment_id);
        return 1;
    }

    if (!_replica_id.has_val) {
        print_error("miss --replica-id or error, %u", _replica_id.val);
        return 1;
    }

    if (_replica_new_addr.empty()) {
        print_error("miss --replica-new-addr");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    request.set_segment_id(_segment_id);
    request.set_replica_id(_replica_id.val);
    request.set_new_addr(_replica_new_addr);
    request.set_log_id(_log_id);
    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::update_replica, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " update replica failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("update replica failed, all nodes failed");
    return Output(response);
}

int UpdateSegmentReplica::Format(const gaiapb::AckResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
