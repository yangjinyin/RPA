/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/segment_data.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <psvr0recv.h>    // recv_parse_or_apply_log_rec_body
#include <psvr0meta.h>
#include <base/strings/string_number_conversions.h>
#include "psvr/segment.h"
#include "psvr/utils.h"
#include "psvr/page.h"
#include "psvr/page_op.h"
#include "psvr/control.h"
#include "psvr/compress_utils.h"
#include "psvr/encrypt_utils.h"

namespace psvr {

#define set_statistic(name, val)       \
    if (_statistic) {                  \
        (_statistic->name) << (val);   \
    }

static StatLatency stat_readpage_rpc_lat("psvr_readpage_rpc", kSlaWindowSize);

db::PageLockPtr Segment::GetPageLock(uint64_t physical_page_no) {
    return _db_engine->GetPageLock(physical_page_no);
}

int64_t Segment::GetPhysicalPageCompressSize(const gaia_apply::byte* page) {
    return page_compress_data_size(page, _db_engine->file_block_size());
}

db::Status Segment::TrimPhysicalPageData(int64_t log_id,
        gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no,
        uint64_t physical_offset, uint64_t size, bool is_empty_page) {
    db::Status s;
    segment_define_control_or_return_invalid_status();

    if (FLAGS_psvr_enable_append_file) {
        // dont trim page data if my is slowly node.
        // GC the page to apply records rely on this base data.
        if (!is_empty_page) {
            gaia_apply::lsn_t safe_trim_lsn = GetSpaceSafeTrimLsn(space_id);
            if (safe_trim_lsn == 0 || GetAppendDBCheckPointLsn() < safe_trim_lsn) {
                s.Reset(db::Code::kRetry, "ckp lsn is small, expect:%lu", safe_trim_lsn);
                return s;
            }
        }
    }

    if (physical_offset % _db_engine->page_size() != 0
            || size != _db_engine->page_size()) {
        PSVR_LOG(WARNING, log_id) << this << " invalid args,"
            << " physical_offset:[" << physical_offset
            << "] size:[" << size
            << "]";
        s.Reset(db::Code::kInvalid, "invalid args");
        return s;
    }

    db::TrimOptions options;
    options.log_id = log_id;
    options.logical_space_id = space_id;
    options.logical_page_no = logical_page_no;
    s = _db_engine->Trim(options, physical_offset, size);
    if (s.IsIOError()) {
        StorePtr store = control->store_manager()->GetStore(_store_id);
        if (store) {
            store->IncIOErrorCount(TRACE_FILE_LINE_C);
        }
    }

    PSVR_LOG(TRACE, log_id) << this << " trim page,"
        << " physical_offset:[" << physical_offset
        << "] " << s;
    return s;
}

db::Status Segment::ReadPhysicalPageDataWithDblwr(int64_t log_id, uint64_t physical_offset, uint64_t size, void* buf) {
    return ReadPhysicalPageDataWithDblwr(log_id, physical_offset, size, buf, nullptr, nullptr);
}

db::Status Segment::ReadPhysicalPageData(int64_t log_id, uint64_t physical_offset, uint64_t size, void* buf) {
    return ReadPhysicalPageData(log_id, physical_offset, size, buf, nullptr, nullptr);
}

db::Status Segment::ReadPhysicalPageData(int64_t log_id, uint64_t physical_offset,
        uint64_t size, void* buf, bool* is_compressed, uint64_t* real_write_size) {
    db::Status s;
    segment_define_control_or_return_invalid_status();
    if (physical_offset % _db_engine->page_size() != 0
            || size != _db_engine->page_size()) {
        PSVR_LOG(WARNING, log_id) << this << " invalid args,"
            << " physical_offset:[" << physical_offset
            << "] size:[" << size
            << "]";
        s.Reset(db::Code::kInvalid, "invalid args");
        return s;
    }

    StorePtr store = control->store_manager()->GetStore(_store_id);
    if (control->multi_type() && store) {
        if (!store->IsActive()) {
            s.Reset(db::Code::kIOError, "store is not active");
            return s;
        }
    }

    Timer timer(base::Timer::STARTED);
    db::ReadOptions options;
    options.log_id = log_id;

    db::ReadOutputs outputs;
    s = _db_engine->Read(options, physical_offset, size, buf, &outputs);
    if (s.IsIOError()) {
        if (store) {
            store->IncIOErrorCount(TRACE_FILE_LINE_C);
        }
    }
    PSVR_LOG(TRACE, log_id) << this << " read page,"
        << " physical_offset:[" << physical_offset
        << "] " << s;
    if (is_compressed) {
        *is_compressed= outputs.first_is_compressed;
    }
    if (real_write_size) {
        *real_write_size = outputs.real_write_size;
    }
    if (store) {
        store->PutReadLat(timer.u_elapsed());
    }

    bool need_decrypt = is_page_need_decrypt(static_cast<gaia_apply::byte *>(buf));
    if (need_decrypt) {
        EncryptHelperPtr encrypt_helper = _cluster->encrypt_helper();
        if (encrypt_helper.get() == nullptr) {
            s.Reset(db::Code::kInvalid, "decrypt not found helper");
            return s;
        }
        BlockAccessCipherStreamPtr cipher_stream = encrypt_helper->cipher_stream();
        if (cipher_stream.get() == nullptr) {
            s.Reset(db::Code::kInvalid, "decrypt not found cipher");
            return s;
        }
        bool res = cipher_stream->decrypt_page(static_cast<gaia_apply::byte*>(buf), outputs.real_write_size);
        if (!res) {
            s.Reset(db::Code::kCorrupted, "decrypt page failed");
            return s;
        }
    }

    return s;
}

db::Status Segment::ReadPhysicalPageDataWithDblwr(int64_t log_id, uint64_t physical_offset,
        uint64_t size, void* buf, bool* is_compressed, uint64_t* real_write_size) {
    db::Status s = _dblwr->Read(physical_offset, static_cast<gaia_apply::byte*>(buf));
    if (s.IsNotFound()) {
        s = ReadPhysicalPageData(log_id, physical_offset, size, buf, is_compressed, real_write_size);
    } else if (s.IsOk()) {
        if (is_compressed) {
            *is_compressed = false;
        }
        if (real_write_size) {
            *real_write_size = size;
        }
    }

    return s;
}

db::Status Segment::WritePhysicalPageData(int64_t log_id, gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t logical_page_no, uint64_t physical_offset, uint64_t size, void* buf) {
    return WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset,
            size, buf, FLAGS_psvr_gc_enable_punch_hole, nullptr);
}

db::Status Segment::WritePhysicalPageData(int64_t log_id, gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t logical_page_no, uint64_t physical_offset, uint64_t size, void* buf,
        bool compress, uint64_t* real_write_size) {
    db::Status s;
    segment_define_control_or_return_invalid_status();
    if (physical_offset % _db_engine->page_size() != 0
            || size != _db_engine->page_size()) {
        PSVR_LOG(WARNING, log_id) << this << " invalid args,"
            << " space:[" << space_id
            << "] page:[" << logical_page_no
            << "] physical_offset:[" << physical_offset
            << "] size:[" << size
            << "]";
        s.Reset(db::Code::kInvalid, "invalid args");
        return s;
    }

    StorePtr store = control->store_manager()->GetStore(_store_id);
    if (control->multi_type() && store) {
        if (!store->IsActive()) {
            s.Reset(db::Code::kIOError, "store is not active");
            return s;
        }
        if (FLAGS_multi_psvr_store_reserve_size > 0
                && store->physical_free_size() < FLAGS_multi_psvr_store_reserve_size) {
            s.Reset(db::Code::kIOError, "store reserve physical size small");
            return s;
        }
    }

    db::WriteOptions options;
    db::WriteOutputs outputs;
    options.log_id = log_id;
    if (compress) {
        {   // if segment has a custom config set, use it in preference
            std::shared_lock slk(_light_shared_mutex);
            options.enable_compress = _compress_cfg.enable;
            if (options.enable_compress) {
                options.compress_type = _compress_cfg.type;
                options.compress_level = _compress_cfg.level;
                if (options.compress_level < 0) {
                    if (_compress_cfg.type == PSVR_COMPRESS_TYPE_ZSTD) {
                        options.compress_level = FLAGS_psvr_gc_compress_zstd_level;
                    } else if (_compress_cfg.type == PSVR_COMPRESS_TYPE_LZ4) {
                        options.compress_level = FLAGS_psvr_gc_compress_lz4_level;
                    }   // Add new type need to update it.
                }
            }
        }
        if (!options.enable_compress) {
            // use global config set
            options.enable_compress = compress;
            options.compress_type = FLAGS_psvr_gc_compress_type;
            if (options.compress_type == PSVR_COMPRESS_TYPE_ZSTD) {
                options.compress_level = FLAGS_psvr_gc_compress_zstd_level;
            } else if (options.compress_type == PSVR_COMPRESS_TYPE_LZ4) {
                options.compress_level = FLAGS_psvr_gc_compress_lz4_level;
            } else {
                options.compress_level = FLAGS_psvr_gc_compress_level;
                // Add new type need to update it.
            }
        }
    } else {
        // disable compression
        options.enable_compress = false;
    }

    const uint32_t space_encrypt_status = GetSpaceEncryptStatus(space_id);
    if (space_encrypt_status_is_enable(space_encrypt_status)
        && FLAGS_psvr_enable_encrypt
        && !options.enable_compress) {
        do {
            EncryptHelperPtr encrypt_helper = _cluster->encrypt_helper();
            if (encrypt_helper.get() == nullptr) {
                PSVR_LOG(TRACE, log_id) << this << " get enrypt helper failed,"
                                        << " space:[" << space_id << "] page:[" << logical_page_no
                                        << "] physical_offset:[" << physical_offset;
                break;
            }
            BlockAccessCipherStreamPtr cipher_stream = encrypt_helper->cipher_stream();
            if (cipher_stream.get() == nullptr) {
                PSVR_LOG(TRACE, log_id) << this << " get cipher stream failed,"
                                        << " space:[" << space_id << "] page:[" << logical_page_no
                                        << "] physical_offset:[" << physical_offset;
                break;
            }
            bool res = cipher_stream->encrypt_page(space_id, logical_page_no,
                                                   static_cast<gaia_apply::byte *>(buf));
            if (!res) {
                s.Reset(db::Code::kInvalid, "encrypt page failed");
                return s;
            }
        } while (false);
    }

    Timer timer(base::Timer::STARTED);
    options.logical_space_id = space_id;
    options.logical_page_no = logical_page_no;
    options.alloc_extent_size = FLAGS_psvr_enable_fallocate_extent_first_page;
    s = _db_engine->Write(options, physical_offset, size, buf, &outputs);
    if (s.IsIOError()) {
        if (store) {
            store->IncIOErrorCount(TRACE_FILE_LINE_C);
        }
    }
    if (real_write_size) {
        *real_write_size = outputs.real_write_size;
    }
    PSVR_LOG(TRACE, log_id) << this << " write page,"
        << " space:[" << space_id
        << "] page:[" << logical_page_no
        << "] physical_offset:[" << physical_offset
        << "] " << s;
    if (store) {
        store->PutWriteLat(timer.u_elapsed());
    }
    return s;
}

// 1) if current page_lsn > max_apply_lsn return kAhead.
// 2) if current page_lsn == max_apply_lsn return kOk.
// 3) if current page_lsn < max_apply_lsn, apply record.
//      3.1) check space/space meta is right at first
//      3.2) apply records if rec_end_lsn <= max_apply_lsn.
//      3.3) if apply_size > 0, double check space/space meta is right.
//      3.4) return kOk if no error.
// --------
// -) empty page and empty records, return kOk.
// -) empty page and non-empty records:
//      -) kOk if first rec is init, other is error
// -) non-empty page and empty records:
//      -) return 1) or 2) result.
// -) non-empty page and non-empty records:
//      -) return 3) result.
db::Status Segment::ApplyPageLogRecordsNoLock(int64_t log_id,
        uint64_t physical_offset,
        gaia_apply::lsn_t max_apply_lsn, BufBlockPtr buf_block,
        LogRecordIteratorInterface& iter, uint32_t* apply_size) {
    db::Status s;
    *apply_size = 0;

    gaia_apply::lsn_t apply_lsn = buf_block_get_page_lsn(buf_block);
#ifdef GTEST
    gaia_apply::lsn_t page_lsn = apply_lsn;
#endif

    for (; iter.Valid() && !_stopped; iter.Next()) {
        if (!iter.Status().IsOk()) {
            return iter.Status();
        }
        const LogRecord& rec = iter.Get();
#ifdef GTEST
        LOG(NOTICE) << " apply rec, "
            << rec;
#endif
        if (rec.end_lsn > max_apply_lsn) { // apply over
            PSVR_LOG(TRACE, log_id) << this << " apply over, rec_end_lsn:[" << rec.end_lsn
                << "] max_apply_lsn:[" << max_apply_lsn << "]";
            break;
        }

        if (apply_lsn >= rec.end_lsn) {    // already apply
            PSVR_LOG(TRACE, log_id) << this << " page redo already applied, skip it."
                << " rec_space:[" << rec.space_id
                << "] rec_page:[" << rec.page_no
                << "] page_lsn:[" << apply_lsn
                << "] type:[" << rec.type << "] rec_start:[" << rec.start_lsn
                << "] rec_end:[" << rec.end_lsn
                << "] physical_offset:[" << physical_offset
                << "]";
            continue;
        }

        if (*apply_size == 0) {
            if (!check_buf_block_page_space(buf_block,
                        rec.type == gaia_apply::MLOG_INIT_FILE_PAGE2)) {
                PSVR_LOG_IF_EVERY_SECOND(WARNING, !in_recovery(), log_id) << this << " mismatch space/page, "
                    << " rec_space:[" << rec.space_id
                    << "] rec_page:[" << rec.page_no
                    << "] apply_space:[" << buf_block_get_space_id(buf_block)
                    << "] apply_page:[" << buf_block_get_page_no(buf_block)
                    << "] page_lsn:[" << apply_lsn
                    << "] rec_lsn:[" << rec.end_lsn
                    << "] rec_type:[" << gaia_apply::rec_type_name(rec.type)
                    << "] physical_offset:[" << physical_offset
                    << "]";
                s.Reset(db::Code::kCorrupted, "mismatch space/page before apply");
                return s;
            }
        }

        if (rec.type != gaia_apply::MLOG_INIT_FILE_PAGE2
                && rec.has_page_check_bits
                && rec.last_page_lsn != apply_lsn) {
            PSVR_LOG_EVERY_SECOND(ERROR, log_id)
                << this << " check page apply lsn failed, maybe record/page corrupt,"
                << " rec_space:[" << rec.space_id
                << "] rec_page:[" << rec.page_no
                << "] type:[" << rec.type
                << "] rec_start:[" << rec.start_lsn
                << "] rec_end:[" << rec.end_lsn
                << "] page_lsn:[" << apply_lsn
                << "] expected_page_lsn:[" << rec.last_page_lsn
                << "] physical_offset:[" << physical_offset
                << "] apply_size:[" << (*apply_size)
                << "] rec:[" << base::HexEncode(rec.body, rec.body_len)
                << "]";
            s.Reset(db::Code::kCorrupted, "mismatch page last lsn");
            return s;
        }

        ++(*apply_size);
        s = page_apply_log_record(rec, buf_block, &apply_lsn);
        if (!s.IsOk()) {
            PSVR_LOG_EVERY_SECOND(ERROR, log_id) << this << " apply-lib return nullptr, maybe record/page corrupt,"
                << " rec_space:[" << rec.space_id
                << "] rec_page:[" << rec.page_no
                << "] type:[" << rec.type
                << "] rec_start:[" << rec.start_lsn
                << "] rec_end:[" << rec.end_lsn
                << "] page_lsn:[" << apply_lsn
                << "] physical_offset:[" << physical_offset
                << "] apply_size:[" << (*apply_size)
                << "] rec:[" << base::HexEncode(rec.body, rec.body_len)
                << "]";
            return s;
        }

    }
    if (!iter.Status().IsOk()) {
        return iter.Status();
    }

    if (_stopped) {
        s.Reset(db::Code::kInterrupt, "interrupt");
        return s;
    }

    // Recalculate crc and check block after apply
    if (*apply_size > 0) {
        if (!buf_block_reset_checksum(buf_block, apply_lsn)) {
            s.Reset(db::Code::kApplyError, "reset checksum failed");
            return s;
        }
    }
    if (!check_buf_block_page_space(buf_block, *apply_size > 0)) {
        PSVR_LOG_EVERY_SECOND(ERROR, log_id) << this << " mismatch space/page,"
            << " space:[" << buf_block->page.id.space()
            << "] page:[" << buf_block->page.id.page_no()
            << "] apply_space:[" << buf_block_get_space_id(buf_block)
            << "] apply_page:[" << buf_block_get_page_no(buf_block)
            << "] page_lsn:[" << apply_lsn
            << "] physical_offset:[" << physical_offset
            << "] apply_size:[" << (*apply_size)
            << "]";
        if (apply_lsn > _start_checkpoint_lsn) {
            // replay append redo log records, need base page data
            s.Reset(db::Code::kApplyError, "mismatch space/page after apply");
            return s;
        }
    }
#ifdef GTEST
    LOG(NOTICE) << this << " apply done,"
        << " space:[" << buf_block->page.id.space()
        << "] page:[" << buf_block->page.id.page_no()
        << "] apply_size:[" << *apply_size
        << "] page_lsn:[" << page_lsn
        << "] max_apply_lsn:[" << max_apply_lsn
        << "] apply_lsn:[" << apply_lsn
        << "]";
#endif
    if (*apply_size == 0) {
        if (apply_lsn > max_apply_lsn) {
            s.Reset(db::Code::kAhead, "page lsn is bigger");
            return s;
        } else if (apply_lsn == max_apply_lsn) {
            s.Reset(db::Code::kOk, "not apply");
            return s;
        }
    }
    return s;
}

db::Status Segment::ReadPageDataNoLock(int64_t log_id,
            gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no,
            uint64_t physical_offset, BufBlockPtr buf_block) {
    db::Status s = _dblwr->Read(space_id, logical_page_no, physical_offset, buf_block->frame);
    if (s.IsNotFound()) {
        s = ReadPhysicalPageData(log_id, physical_offset, gaia_physical_page_size(), buf_block->frame);
    }

    if (!s.IsOk()) {
        return s;
    }

    init_buf_block(buf_block, space_id, logical_page_no, gaia_page_size());
    return s;
}

// WARNING: Check parse_lsn and max_apply_lsn in advance.
db::Status Segment::ReadPageData(int64_t log_id, TimePoint* tp,
        gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no,
        uint64_t physical_offset, gaia_apply::lsn_t max_apply_lsn,
        BufBlockPtr buf_block, bool* page_is_empty, gaia_apply::lsn_t* real_apply_lsn) {
    db::Status s;
    uint64_t physical_page_no = physical_offset / gaia_physical_page_size();
    db::PageLockPtr page_lock = GetPageLock(physical_page_no);
    ADD_TRACE_TP(tp, "get_lock");
    db::PageSharedLock lk(page_lock, std::try_to_lock);
    if (!lk) {
        s.Reset(db::Code::kBusy, "lock page failed");
        return s;
    }
    ADD_TRACE_TP(tp, "add_lock");
    s = ReadPageDataNoLock(log_id, space_id, logical_page_no, physical_offset, buf_block);
    if (!s.IsOk()) {
        return s;
    }
    ADD_TRACE_TP(tp, "read_page");
    if (buf_block_is_corrupted(buf_block, page_is_empty)) {
        PSVR_LOG(WARNING, log_id) << this << " page is corrupted,"
            << " physical_offset:[" << physical_offset
            << "] space:[" << space_id
            << "] page:[" << logical_page_no
            << "]";
        s.Reset(db::Code::kCorrupted, "page is corrupted");
        return s;
    }

    // check non-empty page meta is consistent
    if (!check_buf_block_page_space(buf_block, *page_is_empty)) {
        // dont set page_is_empty to true
        PSVR_LOG(TRACE, log_id) << this << " page mismatch,"
            << " physical_offset:[" << physical_offset
            << "] space:[" << space_id
            << "] page:[" << logical_page_no
            << "] apply_space:[" << buf_block_get_space_id(buf_block)
            << "] apply_page:[" << buf_block_get_page_no(buf_block)
            << "]";
        memset(buf_block->frame, 0x0, gaia_physical_page_size());
    }

    const auto cur_parse_lsn = parse_lsn();
    if (max_apply_lsn > cur_parse_lsn) {
        max_apply_lsn = cur_parse_lsn;
    }

    PagePtr page = _space_page_manager->GetPage(space_id, logical_page_no, false);
    if (!page) {
        gaia_apply::lsn_t page_lsn = buf_block_get_page_lsn(buf_block);
        *real_apply_lsn = std::max(max_apply_lsn, page_lsn);
        s.Reset(page_lsn <= max_apply_lsn ? db::Code::kOk : db::Code::kAhead, "page empty");
        return s;
    }
    // Lock: to apply page records
    std::shared_lock lm(page->shared_mutex());
    // read a uninit page
    gaia_apply::lsn_t queue_lsn = 0;
    if (page->LogRecordIsEmptyNoLock(max_apply_lsn, &queue_lsn)) {
        gaia_apply::lsn_t page_lsn = buf_block_get_page_lsn(buf_block);
        *real_apply_lsn = std::max(max_apply_lsn, page_lsn);
        s.Reset(page_lsn <= max_apply_lsn ? db::Code::kOk : db::Code::kAhead, "page queue empty");
        return s;
    }

    ADD_TRACE_TP(tp, "apply_check");
    PageLogRecordIterator iter(page);
    uint32_t apply_size = 0;
    *real_apply_lsn = max_apply_lsn;
    s = ApplyPageLogRecordsNoLock(log_id,
            physical_offset, max_apply_lsn, buf_block, iter, &apply_size);
    if (s.IsOk() && (*page_is_empty) && apply_size > 0) {
        *page_is_empty = false;
    }
    if (s.IsAhead()) {
        *real_apply_lsn = buf_block_get_page_lsn(buf_block);
    }
    ADD_TRACE_TP(tp, "apply_records_%u", apply_size);
    PSVR_LOG(TRACE, log_id) << this << " read done, " << page
        << " apply_lsn:[" << max_apply_lsn
        << "] page_lsn:[" << *real_apply_lsn
        << "] page_is_empty:[" << *page_is_empty
        << "] apply_size:[" << apply_size
        << "] " << s;
    return s;
}

db::Status Segment::WritePageDataNoLock(int64_t log_id,
        gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no,
        uint64_t physical_offset, uint64_t size, void* buf) {
    if (FLAGS_psvr_enable_append_file && FLAGS_psvr_dblwr_max_page_num > 0) {
        uint32_t flags = kDblwrFlagsNone;
        return _dblwr->Write(space_id, logical_page_no, static_cast<gaia_apply::byte*>(buf), physical_offset, flags);
    }
    return WritePhysicalPageData(log_id, space_id, logical_page_no, physical_offset, size, buf);
}

db::Status NO_OPTIMIZE Segment::WritePageData(int64_t log_id, TimePoint* tp,
        gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no,
        uint64_t physical_offset, gaia_apply::lsn_t max_apply_lsn, gaia_apply::lsn_t record_end_lsn,
        bool incomplete_gc) {
    db::Status s;
    segment_define_control_or_return_invalid_status();
    PagePtr page = _space_page_manager->GetPage(space_id, logical_page_no, false);
    if (!page) {
        PSVR_LOG(FATAL, log_id) << this << " gc failed, not found the space:[" << space_id
            << "] page:[" << logical_page_no
            << "] record_end_lsn:[" << record_end_lsn
            << "] max_apply_lsn:[" << max_apply_lsn
            << "]";
        s.Reset(db::Code::kStatusError, "not found page");
        return s;
    }

    if (page->last_gc_lsn() >= record_end_lsn) {
        PSVR_LOG(TRACE, log_id) << this << " gc ahead, page not found log records, " << page
            << " apply_lsn:[" << max_apply_lsn
            << "] last_gc_lsn:[" << page->last_gc_lsn()
            << "] record_end_lsn:[" << record_end_lsn
            << "]";
        page->set_purge_record_lsn(record_end_lsn);
        s.Reset(db::Code::kAhead, "page last gc lsn is bigger");
        return s;   // ahead of gc
    }

    if (incomplete_gc) {
        gaia_apply::lsn_t log_record_min_lsn = 0;
        if (page->LogRecordIsEmpty(max_apply_lsn, &log_record_min_lsn)) {
            if (log_record_min_lsn > max_apply_lsn) {
                s.Reset(db::Code::kAhead, "incomplete gc, page queue lowest lsn is bigger");
            } else {
                s.Reset(db::Code::kStatusError, "incomplete gc, not found page records");
            }
            return s;
        }
    }

    // Only for GC threads
    // 8 stores * 8 threads * 16kb = 1MB
    thread_local BufBlockPtr tl_buf_block = nullptr;
    thread_local BufBlockPtr tl_buf_block_ck = nullptr;
    if (!tl_buf_block) {
        tl_buf_block = control->buf_pool()->AllocBufBlock(gaia_apply::FLAGS_univ_page_size);
    }
    if (!tl_buf_block_ck) {
        tl_buf_block_ck = control->buf_pool()->AllocBufBlock(gaia_apply::FLAGS_univ_page_size);
    }
    if (gaia_physical_page_size() != gaia_apply::FLAGS_univ_page_size
            || !tl_buf_block || !tl_buf_block_ck) {
        s.Reset(db::Code::kSysError, "alloc buf failed");
        return s;
    }

    // 1) add shared physical page lock
    // 2) add shared page lock and apply records
    // 3) release shared lock for 1) & 2)
    // 4) add unique lock for physical page & page
    // 5) check physical page changed ?
    // 6)   NO: write & release records
    //      YES: gc retry it

    ADD_TRACE_TP(tp, "page_check");
    uint64_t physical_page_no = physical_offset / gaia_physical_page_size();
    db::PageLockPtr page_lock = GetPageLock(physical_page_no);
    ADD_TRACE_TP(tp, "get_lock");
    gaia_apply::space_id_t local_space_id = gaia_apply::SPACE_UNKNOWN;
    gaia_apply::page_no_t local_page_no = gaia_apply::FIL_NULL;
    gaia_apply::lsn_t local_page_lsn = 0;
    bool page_is_empty = false;
    uint32_t apply_size = 0;
    PageLogRecordIterator iter(page);
    {
        db::PageSharedLock slk(page_lock);
        ADD_TRACE_TP(tp, "add_slock");

        s = ReadPageDataNoLock(log_id, space_id, logical_page_no, physical_offset, tl_buf_block);
        if (!s.IsOk()) {
            PSVR_LOG_EVERY_SECOND(WARNING, log_id) << this << " read page failed,"
                << " physical_offset:[" << physical_offset
                << "] space:[" << space_id
                << "] page:[" << logical_page_no
                << "] " << s;
            return s;
        }
        ADD_TRACE_TP(tp, "read_page");
        if (buf_block_is_corrupted(tl_buf_block, &page_is_empty)) {
            PSVR_LOG_EVERY_SECOND(WARNING, log_id) << this << " page is corrupted,"
                << " physical_offset:[" << physical_offset
                << "] space:[" << space_id
                << "] page:[" << logical_page_no
                << "]";
            s.Reset(db::Code::kCorrupted, "page is corrupted");
            return s;
        }

        local_space_id = buf_block_get_space_id(tl_buf_block);
        local_page_no = buf_block_get_page_no(tl_buf_block);
        local_page_lsn = buf_block_get_page_lsn(tl_buf_block);

        gaia_apply::lsn_t log_record_min_lsn = 0;
        if (page->LogRecordIsEmpty(max_apply_lsn, &log_record_min_lsn)) {
            PSVR_LOG_EVERY_SECOND(ERROR, log_id) << this << " gc failed, page not found log records, " << page
                << " apply_lsn:[" << max_apply_lsn
                << "] last_record_lsn:[" << page->last_record_lsn()
                << "] log_record_min_lsn:[" << log_record_min_lsn
                << "] record_end_lsn:[" << record_end_lsn
                << "]";
            s.Reset(db::Code::kStatusError, "not found page records");
            return s;
        }

        if (!check_buf_block_page_space(tl_buf_block, page_is_empty)) {
            PSVR_LOG(TRACE, log_id) << this << " mismatch space/page, now memset buf block,"
                << " space:[" << space_id
                << "] page:[" << logical_page_no
                << "] apply_space:[" << buf_block_get_space_id(tl_buf_block)
                << "] apply_page:[" << buf_block_get_page_no(tl_buf_block)
                << "]";
            if (local_page_lsn > _start_checkpoint_lsn) {
                // replay append redo log records, need base page data
                memset(tl_buf_block->frame, 0x0, gaia_physical_page_size());
            }
        }

        std::shared_lock slm(page->shared_mutex());
        ADD_TRACE_TP(tp, "apply_check");
        s = ApplyPageLogRecordsNoLock(log_id, physical_offset, max_apply_lsn, tl_buf_block, iter, &apply_size);
        ADD_TRACE_TP(tp, "apply_done");
    }
    {
        db::PageUniqueLock lk(page_lock);
        ADD_TRACE_TP(tp, "add_lock");
        if (s.IsOk() || s.IsAhead()) {
            const auto s2 = ReadPageDataNoLock(log_id, space_id, logical_page_no, physical_offset, tl_buf_block_ck);
            if (!s2.IsOk()) {
                PSVR_LOG_EVERY_SECOND(WARNING, log_id) << this << " read page failed,"
                    << " physical_offset:[" << physical_offset
                    << "] space:[" << space_id
                    << "] page:[" << logical_page_no
                    << "] " << s2;
                return s2;
            }
            ADD_TRACE_TP(tp, "read_page");
            bool page_is_empty_ck = false;
            if (buf_block_is_corrupted(tl_buf_block_ck, &page_is_empty_ck)) {
                PSVR_LOG_EVERY_SECOND(WARNING, log_id) << this << " page is corrupted,"
                    << " physical_offset:[" << physical_offset
                    << "] space:[" << space_id
                    << "] page:[" << logical_page_no
                    << "]";
                s.Reset(db::Code::kCorrupted, "page is corrupted");
                return s;
            }

            if (buf_block_get_space_id(tl_buf_block_ck) != local_space_id
                    || buf_block_get_page_no(tl_buf_block_ck) != local_page_no
                    || buf_block_get_page_lsn(tl_buf_block_ck) != local_page_lsn
                    || page_is_empty != page_is_empty_ck) {
                s.Reset(db::Code::kRetry, "page is changed by other task");
                return s;
            }
        } // end of check page if changed

        std::unique_lock lm(page->shared_mutex());

        if (s.IsOk() || s.IsAhead()) {
            ADD_TRACE_TP(tp, "apply_%u", apply_size);
            if (apply_size > 0) {
                s = WritePageDataNoLock(log_id, space_id, page->page_no(),
                        physical_offset, gaia_physical_page_size(), tl_buf_block->frame);
                if (!s.IsOk()) {
                    return s;
                }
                ADD_TRACE_TP(tp, "write_page");
            }

            _recovery_lsn(max_apply_lsn, true);
            page->set_purge_record_lsn(record_end_lsn);
            page->PurgeLogRecordsNoLock(iter, max_apply_lsn);
            ADD_TRACE_TP(tp, "purge_records");

            PSVR_LOG(TRACE, log_id) << this << " gc done, " << page
                << " apply_lsn:[" << max_apply_lsn
                << "] page_lsn:[" << buf_block_get_page_lsn(tl_buf_block)
                << "] apply_size:[" << apply_size
                << "] " << s;
        } else if (s.IsCorrupted()) {
            bool retry = false;
            if (page_is_empty && apply_size == 0
                    && AddGcPageInRecovery(page_lock, space_id, logical_page_no, record_end_lsn, &retry)) {
                _recovery_lsn(record_end_lsn, true);
                page->set_purge_record_lsn(record_end_lsn);
                page->PurgeLogRecordsNoLock(record_end_lsn);

                PSVR_LOG(TRACE, log_id) << this << " ignore gc done, " << page
                    << " apply_lsn:[" << max_apply_lsn
                    << "] record_end_lsn:[" << record_end_lsn
                    << "] page_lsn:[" << buf_block_get_page_lsn(tl_buf_block)
                    << "] apply_size:[" << apply_size
                    << "] " << s;
                s.Reset(db::Code::kMissData, "page needs to recover base data first");
            } else if (retry) {
                LOG_EVERY_SECOND(NOTICE) << this << " page in recovery, " << page
                    << " apply_lsn:[" << max_apply_lsn
                    << "] record_end_lsn:[" << record_end_lsn
                    << "] page_lsn:[" << buf_block_get_page_lsn(tl_buf_block)
                    << "] page_is_empty:[" << page_is_empty
                    << "] apply_size:[" << apply_size
                    << "]";
                s.Reset(db::Code::kRetry, "page in recovery, retry it");
            }
        }
    }
    return s;
}

bool Segment::DblwrHasBufs() const {
    return _dblwr->HasBufs();
}

db::Status Segment::DumpDblwrBuf(int64_t log_id) {
    db::Status s;
    DblwrBufPtr dblwr_buf = _dblwr->DumpBuf();
    if (!dblwr_buf) {
        return s;
    }

    segment_define_control_or_return_invalid_status();

    if (!_dblwr->acquire_in_dump()) {
        s.Reset(db::Code::kStatusError, "segment dblwr in dumping");
        return s;
    }

    std::shared_ptr<nullptr_t> dblwr_dump_guard(nullptr, [this](nullptr_t){
                _dblwr->release_in_dump();
            });

    thread_local BufBlockPtr tl_buf_block = nullptr;
    thread_local BufBlockPtr tl_buf_block2 = nullptr;
    if (!tl_buf_block || !tl_buf_block2) {
        tl_buf_block = control->buf_pool()->AllocBufBlock(gaia_apply::FLAGS_univ_page_size);
        tl_buf_block2 = control->buf_pool()->AllocBufBlock(gaia_apply::FLAGS_univ_page_size);
        if (!tl_buf_block || !tl_buf_block2) {
            s.Reset(db::Code::kBusy, "alloc block buf failed");
            return s;
        }
    }

    BufBlockPtr buf_block = tl_buf_block;

    const DblwrFooter& footer = dblwr_buf->footer;
    for (auto& it : dblwr_buf->offs_to_slot) {
        uint64_t physical_offset = it.first;
        uint64_t physical_page_no = physical_offset / gaia_physical_page_size();

        gaia_apply::byte* frame = nullptr;
        s = _dblwr->Read(physical_offset, tl_buf_block2->frame);

        if (s.IsIOError()) {
            StorePtr store = control->store_manager()->GetStore(_store_id);
            if (store) {
                store->IncIOErrorCount(TRACE_FILE_LINE_C);
            }
            return s;
        }

        if (!s.IsOk()) {
            return s;
        }

        frame = tl_buf_block2->frame;
        gaia_apply::space_id_t space_id = gaia_apply::page_get_space_id(frame);
        gaia_apply::page_no_t page_no = gaia_apply::page_get_page_no(frame);
        gaia_apply::lsn_t page_lsn = page_get_page_lsn(frame);

        db::PageLockPtr page_lock = GetPageLock(physical_page_no);
        db::PageUniqueLock lk(page_lock);
        s = ReadPhysicalPageData(log_id, physical_offset, gaia_apply::FLAGS_univ_page_size, buf_block->frame);
        if (!s.IsOk()) {
            return s;
        }

        init_buf_block(buf_block, space_id, page_no, gaia_page_size());

        bool page_is_empty = false;
        if (!buf_block_is_corrupted(buf_block, &page_is_empty) && !page_is_empty) {
            gaia_apply::space_id_t local_space_id = gaia_apply::page_get_space_id(buf_block->frame);
            gaia_apply::page_no_t local_page_no = gaia_apply::page_get_page_no(buf_block->frame);
            gaia_apply::lsn_t local_page_lsn = buf_block_get_page_lsn(buf_block);
            // in backup recovery, extent will reuse to other pages.
            if (local_page_lsn >= page_lsn) {
                if (local_space_id == space_id && local_page_no == page_no) {
                    continue;
                }
                LOG(WARNING) << this << " page maybe reused,"
                    << " space_id:[" << space_id
                    << "] page_no:[" << page_no
                    << "] page_lsn:[" << page_lsn
                    << "] local_space_id:[" << local_space_id
                    << "] local_page_no:[" << local_page_no
                    << "] local_page_lsn:[" << local_page_lsn
                    << "] offset:[" << physical_offset
                    << "]";
            }
        } else if (!page_is_empty) {
            LOG(WARNING) << this << " page data is corrupted, will fix by dblwr."
                << " space_id:[" << space_id
                << "] page_no:[" << page_no
                << "] offset:[" << physical_offset
                << "]";
        }

        s = WritePhysicalPageData(log_id, space_id, page_no,
                physical_offset, gaia_physical_page_size(), frame,
                FLAGS_psvr_dblwr_enable_punch_hole, nullptr);
        if (!s.IsOk()) {
            return s;
        }
    }

    if (footer.ckp_lsn[1] > 0) {
        s = UpdateAppendDBCheckPoint(footer.ckp_lsn[1], true);
        if (!s.IsOk()) {
            return s;
        }
        PSVR_ASSERT_U(gc_lsn() >= footer.ckp_lsn[1]);
    }

    // sync db engine before remove dblwr file
    Sync();

    s = _dblwr->RemoveBuf(dblwr_buf);
    return s;
}

db::Status Segment::SealDblwrTimeout(int64_t timeout_us) {
    db::Status st;

    if (FLAGS_psvr_enable_append_file && FLAGS_psvr_dblwr_max_page_num > 0) {
        st = _dblwr->SealBufByTime(timeout_us);
        if (!st.IsOk()) {
            LOG(WARNING) << this << " seal least dblwr file failed," << st;
        }
    }

    return st;
}

void Segment::ReadPeerPage(ReadPeerPageContext* ctx, ggpb::Closure* closure) {
    segment_define_control_or_return_invalid_closure();
    auto rpc_ctx = new RpcRbioCtx;
    rpc_ctx->servers = ctx->request.peers;
    rpc_ctx->request.set_requestid(get_log_id());
    rpc_ctx->request.set_n(1);
    rpc_ctx->request.set_readtype(pspb::RbioRequest::READ_SYNC);
    rpc_ctx->request.set_peerread(true);
    rpc_ctx->request.set_segment_id(_segment_id);
    rpc_ctx->request.set_cluster_id(_cluster_id);
    rpc_ctx->request.set_max_error_code(pspb::RbioResponse::RBIO_SEGMENT_NOT_EXIST);

    if (rpc_ctx->current_server().has_zone()) {
        rpc_ctx->request.mutable_zone()->set_region(rpc_ctx->current_server().region);
        rpc_ctx->request.mutable_zone()->set_available_zone(rpc_ctx->current_server().available_zone);
    }

    auto req_vec = rpc_ctx->request.add_reqvec();
    req_vec->set_tablespaceid(ctx->request.space_id);
    req_vec->set_logicalpageno(ctx->request.logical_page_no);
    req_vec->set_vlsn(ctx->request.lsn);
    req_vec->set_ziplen(gaia_logical_page_size());

    init_buf_block(ctx->response.buf_block,
            ctx->request.space_id, ctx->request.logical_page_no, gaia_page_size());

    if (closure) {
        auto rpc_closure = brpc::NewCallback(this, &Segment::OnReadPeerPage, ctx, closure, rpc_ctx);
        control->client()->Rbio(rpc_ctx, rpc_closure);
    } else {
        control->client()->Rbio(rpc_ctx, nullptr);
        OnReadPeerPage(ctx, nullptr, rpc_ctx);
    }
}

void Segment::OnReadPeerPage(ReadPeerPageContext* ctx, ggpb::Closure* closure,
        RpcRbioCtx* rpc_ctx) {
    // 1) release rpc_ctx
    // 2) closure if invalid
    // 3) call closure
    std::unique_ptr<RpcRbioCtx> rpc_ctx_guard(rpc_ctx);
    segment_define_control_or_return_invalid_closure();
    brpc::ClosureGuard closure_guard(closure);

    const auto& req_vec = rpc_ctx->request.reqvec(0);
    const gaia_apply::space_id_t space_id = req_vec.tablespaceid();
    const gaia_apply::page_no_t page_no = req_vec.logicalpageno();
    const gaia_apply::lsn_t lsn = req_vec.vlsn();
    const uint32_t size = req_vec.ziplen();

    if (_stopped) {
        return;
    }

    stat_readpage_rpc_lat << rpc_ctx->latency_us;
    // response success
    if (rpc_ctx->status.IsOk()
            && rpc_ctx->response.errcode() == pspb::RbioResponse_Error_RBIO_SUCCESS) {
        do {
            const auto& rsp_vec = rpc_ctx->response.resvec(0);
            if (rsp_vec.tablespaceid() != space_id
                    || rsp_vec.logicalpageno() != page_no
                    || rsp_vec.pageframe().size() != size) {
                PSVR_LOG_CTX(ERROR, rpc_ctx) << this << " rbio rsp invalid,"
                    << " server:[" << rpc_ctx->current_server()
                    << "] space:[" << space_id
                    << "] rsp_space:[" << rsp_vec.tablespaceid()
                    << "] page:[" << page_no
                    << "] rsp_page:[" << rsp_vec.logicalpageno()
                    << "] page_size:[" << size
                    << "] rsp_page_size:[" << rsp_vec.pageframe().size()
                    << "] lsn:[" << lsn
                    << "]";
                break;
            }

            std::memcpy(ctx->response.buf_block->frame, rsp_vec.pageframe().c_str(), size);
            bool is_empty = false;
            bool is_corrupted = buf_block_is_corrupted(ctx->response.buf_block, &is_empty);
            if (rsp_vec.has_checkcrc() && rsp_vec.checkcrc() && is_corrupted) {
                PSVR_LOG_CTX(ERROR, rpc_ctx) << this << " rbio rsp block data is corrupt,"
                    << " server:[" << rpc_ctx->current_server()
                    << "] space:[" << space_id
                    << "] page:[" << page_no
                    << "] lsn:[" << lsn
                    << "]";
                break;
            }

            if (is_empty) {
                PSVR_LOG_CTX(TRACE, rpc_ctx) << this << " rbio rsp block is empty,"
                    << " server:[" << rpc_ctx->current_server()
                    << "] space:[" << space_id
                    << "] page:[" << page_no
                    << "] lsn:[" << lsn
                    << "]";

                // peer rsp is safe and right empty block
                if (rpc_ctx->response.has_valid_empty() && rpc_ctx->response.valid_empty()) {
                    MovePeerNodeToFirst(rpc_ctx->idx, rpc_ctx->current_server());
                    ctx->response.success = true;
                    ctx->response.is_empty = true;
                    return;
                }

                ++ctx->response.empty_page_count;
                auto majority_num = calc_peer_majority_num(ctx->request.peers.size() + 1);
                // majority peers return empty
                if (ctx->response.empty_page_count < majority_num) {
                    LOG(TRACE) << this << " major empty peer lower than total,"
                        << " majority_num:[" << majority_num
                        << "] empty_count:[" << ctx->response.empty_page_count
                        << "]";
                    break;
                }

                // success
                ctx->response.success = true;
                ctx->response.is_empty = true;
            } else {
                // in old version page server:
                //  the page checksum not recomputed after applying log records
                if (!rsp_vec.has_checkcrc() && is_corrupted) {
                    const gaia_apply::lsn_t page_lsn = buf_block_get_page_lsn(ctx->response.buf_block);
                    if (!buf_block_reset_checksum(ctx->response.buf_block, page_lsn)) {
                        LOG(WARNING) << this << " reset remote page crc failed";
                        break;
                    }
                }

                PSVR_LOG_CTX(TRACE, rpc_ctx) << this << " read rbio success,"
                    << " server:[" << rpc_ctx->current_server()
                    << "] space:[" << space_id
                    << "] page:[" << page_no
                    << "] lsn:[" << lsn
                    << "] page_lsn:[" << buf_block_get_page_lsn(ctx->response.buf_block)
                    << "]";

                MovePeerNodeToFirst(rpc_ctx->idx, rpc_ctx->current_server());
                ctx->response.success = true;
            }
        } while (false);
    } else {
        PSVR_LOG_CTX(WARNING, rpc_ctx) << this << " read rbio failed,"
            << " server:[" << rpc_ctx->current_server()
            << "] space:[" << space_id
            << "] page:[" << page_no
            << "] lsn:[" << lsn
            << "] errcode:[" << pspb::RbioResponse_Error_Name(rpc_ctx->response.errcode())
            << "] " << rpc_ctx->status;
        SetPeerNodeFailed(rpc_ctx->idx, rpc_ctx->current_server());
    }

    // failed
    ++ctx->retry_nr;
    if (!ctx->response.success) {
        ++rpc_ctx->idx;
        if (rpc_ctx->Retryable()) {
            if (rpc_ctx->current_server().has_zone()) {
                rpc_ctx->request.mutable_zone()->set_region(rpc_ctx->current_server().region);
                rpc_ctx->request.mutable_zone()->set_available_zone(rpc_ctx->current_server().available_zone);
            } else {
                rpc_ctx->request.clear_zone();
            }

            if (!closure_guard.empty()) {
                auto rpc_closure = brpc::NewCallback(this, &Segment::OnReadPeerPage,
                        ctx, closure_guard.release(), rpc_ctx_guard.release());
                control->client()->Rbio(rpc_ctx, rpc_closure);
            } else {
                control->client()->Rbio(rpc_ctx, nullptr);
                OnReadPeerPage(ctx, nullptr, rpc_ctx_guard.release());
            }
        }
    }
}

}
