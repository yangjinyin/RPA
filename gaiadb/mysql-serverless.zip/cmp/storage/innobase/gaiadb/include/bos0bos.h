/***************************************************************************** @file include/bos0delete.h
 fetch bos data
 *******************************************************/

#ifndef bos0bos_h
#define bos0bos_h

#include "bos0conductor.h"

namespace bos {

class BosWriter : public BosConductor {
public:
  static const long partSize = 1024 * 1024 * 5L * 10L; // 50M

  BosWriter() {}

  bool put_object_with_filename(const std::string &filename);

  bool put_object_in_multi_part(const std::string &filename, std::string &uploadId);

  bool abort_put_object_in_multi_part(const std::string &filename, const std::string &uploadId);

  bool get_multi_part_uploads_unfinished(std::vector<baidu::bos::cppsdk::MultipartUploadSummary> &uploads);

  bool put_object(const std::string &filename, const uint64_t size);
  bool put_object_with_progress(const std::string &filename);

  bool put_large_object(const std::string &filename);
};

class BosReader : public BosConductor {
public:
  BosReader() {}
  ~BosReader() {}
public:
  bool get_object_with_stream(const std::string &filename);
  bool get_object_to_file(const std::string &filename, const int64_t start_lsn, const int64_t end_lsn);
  bool get_object_in_memory(const std::string &filename, std::string &inMemoryData);
  bool get_object_in_range(const std::string &filename, const uint32_t start_lsn, const uint32_t end_lsn);
  bool get_object_with_progress(const std::string &filename);
  bool get_object(const std::string &filename);
};

class BosDelete : public BosConductor {
  BosDelete() {}
  ~BosDelete() {}

public:
  bool delete_object(const std::string &filename);
  bool delete_multi_objects(const std::vector<std::string> &filenames);
  bool delete_object_retry(const std::string &filename, const uint64_t retry = 3);
};
} // namespace bos

#endif
