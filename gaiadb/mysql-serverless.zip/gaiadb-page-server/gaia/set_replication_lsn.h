/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_replication_lsn.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class SetReplicationLsn : public Command {
public:
    SetReplicationLsn() {
        SetName("set-replication-lsn");
        SetDesc("set replication server apply lsn");
        SetDescCn("设置复制服务的应用 LSN");

        AddPsmClusterOption();
        AddRequiredArgOption("apply-lsn", &_long_opt_val, kOptMax + 1, "new apply lsn", kuint64_t);
        
        AddExample("--manager-address \"bns://xxx\" --apply-lsn 0");
    }
    virtual ~SetReplicationLsn() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _apply_lsn = std::strtoull(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::SetReplicationLsnResponse& rsp);

private:
    std::string _manager_address {};
    uint64_t _apply_lsn {0};
};

}
}
