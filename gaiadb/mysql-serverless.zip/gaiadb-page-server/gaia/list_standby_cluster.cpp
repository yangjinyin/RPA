/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_standby_cluster.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_standby_cluster.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ListStandbyCluster::Run() {
    RpcStatus status;
    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (_standby_cluster_id.empty()) {
        gaiapb::ListStandbyClusterRequest request;
        gaiapb::ListStandbyClusterResponse response;

        request.set_log_id(_log_id);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_standby_cluster, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                return Output(response);
            } else {
                LOG(WARNING) << node << " list standby cluster failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("list failed, all nodes failed");
        return Output(response);
    } else {
        gaiapb::GetStandbyClusterRequest request;
        gaiapb::GetStandbyClusterResponse response;

        request.set_log_id(_log_id);
        request.set_cluster_id(_standby_cluster_id);

        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_standby_cluster, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(response.status())) {
                return Output(response);
            } else {
                LOG(WARNING) << node << " get standby cluster failed, " << status << " " << response.status();
            }
        }
        response.mutable_status()->set_code(gaiadb::GIE_FAIL);
        response.mutable_status()->set_msg("get failed, all nodes failed");
        return Output(response);
    }
}

int ListStandbyCluster::Format(const gaiapb::GetStandbyClusterResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"lowest_trx_id:", rsp.lowest_trx_id()});
    table.AddRowsValue({"primary_lowest_trx_id:", rsp.primary_lowest_trx_id()});
    table.AddRowsValue({"apply_lsn:", rsp.apply_lsn()});
    table.AddRowsValue({"write_lsn:", rsp.write_lsn()});
    table.AddRowsValue({"primary_lsn:", rsp.primary_lsn()});
    table.AddRowsValue({"state:", gaiadb::NodeState_Name(rsp.state()).c_str()});
    table.Display();
    return 0;
}

int ListStandbyCluster::Format(const gaiapb::ListStandbyClusterResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table header(_raw_with_table, 2);
    header.AddRowsValue({"primary_lowest_trx_id:", rsp.primary_lowest_trx_id()});
    header.AddRowsValue({"primary_lsn:", rsp.primary_lsn()});
    header.Display();
    if (rsp.standby_clusters_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({"standby-cluster", "lowest-trx-id", "apply_lsn", "write_lsn", "state"}, true);
        for (auto& pb : rsp.standby_clusters()) {
            table.AddRowsValue({
                    pb.cluster_id(),
                    pb.lowest_trx_id(),
                    pb.apply_lsn(),
                    pb.write_lsn(),
                    gaiadb::NodeState_Name(pb.state())
                    });
        }
        table.Display();
    }
    return 0;
}

}
}
