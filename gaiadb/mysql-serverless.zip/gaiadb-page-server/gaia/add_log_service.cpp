/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/add_log_service.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/add_log_service.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int AddLogService::Run() {
    RpcStatus status;
    gaiapb::LogServiceRequest request;
    gaiapb::AckResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_addr.empty()) {
        print_error("miss --addr");
        return 1;
    }

    if (_zone.Invalid()) {
        print_error("error, --region and --available-zone should always appear in pairs");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    request.set_addr(_addr);
    if (_zone.region.size() && _zone.available_zone.size()) {
      request.mutable_zone()->set_region(_zone.region);
      request.mutable_zone()->set_available_zone(_zone.available_zone);
    }

    if (!_force) {
        bool cf_ret = execute_confirm("add log service node=%s?", _addr.c_str());
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::add_log_service, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " add log service failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("add failed, all nodes failed");
    return Output(response);
}

int AddLogService::Format(const gaiapb::AckResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
