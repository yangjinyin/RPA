/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_page_server_cluster_stat.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class SetPageServerClusterStat : public Command {
public:
    SetPageServerClusterStat() {
        SetName("set-ps-cluster-stat");
        SetDesc("disable or enable cluster unit statistic to page server");
        SetDescCn("启用或禁用存储服务器上的集群统计");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "cluster id in server", kstring);
        AddRequiredArgOption("enable", &_long_opt_val, kOptMax + 1, "enable or disable statistic", kenum);
        AddRequiredArgOption("prefix", &_long_opt_val, kOptMax + 2, "bvar statistic prefix name", kstring);
        
        AddExample("-a <ip> -p <port> --cluster-id <cluster_id or psm_address> --enable 0");
        AddExample("-a <ip> -p <port> --cluster-id <cluster_id or psm_address> --enable 1 --prefix <cluster_id>");
    }
    virtual ~SetPageServerClusterStat() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _enable.Set(!!std::strtoull(opt, NULL, 10));
                break;
            case kOptMax + 2:
                _prefix = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::EnableClusterStatResponse& rsp);
    int Format(const pspb::DisableClusterStatResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    VarOptional<bool> _enable;
    std::string _prefix {};
};

}
}
