#!/bin/bash

ulimit -s 16384
set -e

core_n=`ls core* | wc -l`

> test.log
for test in `ls output/test/test_*`; do
    echo $test | tee > test.log
    ./$test | tee >> test.log
    gmock_warn_n=`grep 'GMOCK WARNING' test.log | wc -l`
    if [ $gmock_warn_n -ne 0 ]; then
        echo "exists GMOCK WARNING on run $test"
        exit 1
    fi
    gmock_fail_n=`grep -w 'Failure' test.log | wc -l`
    if [ $gmock_fail_n -ne 0 ]; then
        echo "exists Failure on run $test"
        exit 1
    fi
    core_n2=`ls core* | wc -l`
    if [ $core_n -ne $core_n2 ]; then
        echo "exists new cores files on run $test"
        exit 1
    fi
done

echo "done"
