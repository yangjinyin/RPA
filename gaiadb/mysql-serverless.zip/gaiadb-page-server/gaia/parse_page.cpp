#include "gaia/parse_page.h"
#include <gaiadb/utils/ut.h>
#include <sys/stat.h>
#include "psvr/common.h"
#include "psvr/compress_utils.h"
#include "psvr/log.h"
#include "psvr/page_op.h"

namespace psvr {
namespace gaia {

const char *ParsePage::PageTypeName(gaia_apply::page_type_t type) {
    switch (type) {
        case gaia_apply::FIL_PAGE_TYPE_ALLOCATED:
            return "FIL_PAGE_TYPE_ALLOCATED (Freshly Allocated)";
        case gaia_apply::FIL_PAGE_UNDO_LOG:
            return "FIL_PAGE_UNDO_LOG";
        case gaia_apply::FIL_PAGE_INODE:
            return "FIL_PAGE_INODE";
        case gaia_apply::FIL_PAGE_IBUF_FREE_LIST:
            return "FIL_PAGE_IBUF_FREE_LIST";
        case gaia_apply::FIL_PAGE_IBUF_BITMAP:
            return "FIL_PAGE_IBUF_BITMAP";
        case gaia_apply::FIL_PAGE_TYPE_SYS:
            return "FIL_PAGE_TYPE_SYS";
        case gaia_apply::FIL_PAGE_TYPE_TRX_SYS:
            return "FIL_PAGE_TYPE_TRX_SYS";
        case gaia_apply::FIL_PAGE_TYPE_FSP_HDR:
            return "FIL_PAGE_TYPE_FSP_HDR";
        case gaia_apply::FIL_PAGE_TYPE_XDES:
            return "FIL_PAGE_TYPE_XDES";
        case gaia_apply::FIL_PAGE_TYPE_BLOB:
            return "FIL_PAGE_TYPE_BLOB";
        case gaia_apply::FIL_PAGE_TYPE_ZBLOB:
            return "FIL_PAGE_TYPE_ZBLOB";
        case gaia_apply::FIL_PAGE_TYPE_ZBLOB2:
            return "FIL_PAGE_TYPE_ZBLOB2";
        case gaia_apply::FIL_PAGE_TYPE_UNKNOWN:
            return "FIL_PAGE_TYPE_UNKNOWN";
        case gaia_apply::FIL_PAGE_COMPRESSED:
            return "FIL_PAGE_COMPRESSED";
        case gaia_apply::FIL_PAGE_ENCRYPTED:
            return "FIL_PAGE_ENCRYPTED";
        case gaia_apply::FIL_PAGE_COMPRESSED_AND_ENCRYPTED:
            return "FIL_PAGE_COMPRESSED_AND_ENCRYPTED";
        case gaia_apply::FIL_PAGE_ENCRYPTED_RTREE:
            return "FIL_PAGE_ENCRYPTED_RTREE";
        case gaia_apply::FIL_PAGE_SDI_BLOB:
            return "FIL_PAGE_SDI_BLOB";
        case gaia_apply::FIL_PAGE_SDI_ZBLOB:
            return "FIL_PAGE_SDI_ZBLOB";
        case gaia_apply::FIL_PAGE_TYPE_UNUSED:
            return "FIL_PAGE_TYPE_UNUSED";
        case gaia_apply::FIL_PAGE_TYPE_RSEG_ARRAY:
            return "FIL_PAGE_TYPE_RSEG_ARRAY";
        case gaia_apply::FIL_PAGE_TYPE_LOB_INDEX:
            return "FIL_PAGE_TYPE_LOB_INDEX";
        case gaia_apply::FIL_PAGE_TYPE_LOB_DATA:
            return "FIL_PAGE_TYPE_LOB_DATA";
        case gaia_apply::FIL_PAGE_TYPE_LOB_FIRST:
            return "FIL_PAGE_TYPE_LOB_FIRST";
        case gaia_apply::FIL_PAGE_TYPE_ZLOB_FIRST:
            return "FIL_PAGE_TYPE_ZLOB_FIRST";
        case gaia_apply::FIL_PAGE_TYPE_ZLOB_DATA:
            return "FIL_PAGE_TYPE_ZLOB_DATA";
        case gaia_apply::FIL_PAGE_TYPE_ZLOB_INDEX:
            return "FIL_PAGE_TYPE_ZLOB_INDEX";
        case gaia_apply::FIL_PAGE_TYPE_ZLOB_FRAG:
            return "FIL_PAGE_TYPE_ZLOB_FRAG";
        case gaia_apply::FIL_PAGE_TYPE_ZLOB_FRAG_ENTRY:
            return "FIL_PAGE_TYPE_ZLOB_FRAG_ENTRY";
        case gaia_apply::FIL_PAGE_INDEX:
            return "FIL_PAGE_INDEX (B-tree)";
        case gaia_apply::FIL_PAGE_RTREE:
            return "FIL_PAGE_RTREE";
        case gaia_apply::FIL_PAGE_SDI:
            return "FIL_PAGE_SDI";
        default:
            return "UNKNOWN";
    }
}

void ParsePage::DisplayFilHeader(const gaia_apply::byte *frame) {
    printf("\n--- FIL Header ---\n");

    uint32_t checksum = gaia_apply::mach_read_from_4(frame + gaia_apply::FIL_PAGE_SPACE_OR_CHKSUM);
    uint32_t offset = gaia_apply::mach_read_from_4(frame + gaia_apply::FIL_PAGE_OFFSET);
    uint32_t prev = gaia_apply::mach_read_from_4(frame + gaia_apply::FIL_PAGE_PREV);
    uint32_t next = gaia_apply::mach_read_from_4(frame + gaia_apply::FIL_PAGE_NEXT);
    uint64_t lsn = gaia_apply::mach_read_from_8(frame + gaia_apply::FIL_PAGE_LSN);
    gaia_apply::page_type_t page_type = gaia_apply::fil_page_get_type(frame);
    uint64_t flush_lsn = gaia_apply::mach_read_from_8(frame + gaia_apply::FIL_PAGE_FILE_FLUSH_LSN);
    uint32_t space_id = gaia_apply::page_get_space_id(frame);

    printf("  %-30s %u (0x%08X)\n", "Checksum:", checksum, checksum);
    printf("  %-30s %u\n", "FIL_PAGE_OFFSET:", offset);
    printf("  %-30s %s\n",
           "Prev Page:", prev == gaia_apply::FIL_NULL ? "FIL_NULL" : std::to_string(prev).c_str());
    printf("  %-30s %s\n",
           "Next Page:", next == gaia_apply::FIL_NULL ? "FIL_NULL" : std::to_string(next).c_str());
    printf("  %-30s %lu\n", "LSN:", lsn);
    printf("  %-30s %u (%s)\n", "Page Type:", page_type, PageTypeName(page_type));
    printf("  %-30s %lu\n", "Flush LSN:", flush_lsn);
    printf("  %-30s %u\n", "Space ID:", space_id);
}

void ParsePage::DisplayFilTrailer(const gaia_apply::byte *frame, uint64_t page_size) {
    printf("\n--- FIL Trailer ---\n");

    const gaia_apply::byte *trailer = frame + page_size - gaia_apply::FIL_PAGE_END_LSN_OLD_CHKSUM;
    uint32_t trailer_checksum = gaia_apply::mach_read_from_4(trailer);
    uint32_t trailer_lsn_low = gaia_apply::mach_read_from_4(trailer + 4);

    uint64_t header_lsn = gaia_apply::mach_read_from_8(frame + gaia_apply::FIL_PAGE_LSN);
    uint32_t header_lsn_low = static_cast<uint32_t>(header_lsn & 0xFFFFFFFF);

    printf("  %-30s %u (0x%08X)\n", "Old Checksum:", trailer_checksum, trailer_checksum);
    printf("  %-30s %u (0x%08X)\n", "LSN Low 32 bits:", trailer_lsn_low, trailer_lsn_low);
    printf("  %-30s %s\n",
           "LSN Low Match Header:", (trailer_lsn_low == header_lsn_low) ? "YES" : "NO - MISMATCH!");
}

void ParsePage::DisplayPageHeader(const gaia_apply::byte *frame) {
    printf("\n--- PAGE Header (INDEX page) ---\n");

    using namespace gaia_apply;

    uint16_t n_dir_slots = page_header_get_field(frame, PAGE_N_DIR_SLOTS);
    uint16_t heap_top = page_header_get_field(frame, PAGE_HEAP_TOP);
    uint16_t n_heap_raw = page_header_get_field(frame, PAGE_N_HEAP);
    uint16_t n_heap = n_heap_raw & 0x7FFF;
    bool is_compact = (n_heap_raw & 0x8000) != 0;
    uint16_t free_offset = page_header_get_field(frame, PAGE_FREE);
    uint16_t garbage = page_header_get_field(frame, PAGE_GARBAGE);
    uint16_t last_insert = page_header_get_field(frame, PAGE_LAST_INSERT);
    uint16_t direction = page_header_get_field(frame, PAGE_DIRECTION);
    uint16_t n_direction = page_header_get_field(frame, PAGE_N_DIRECTION);
    uint16_t n_recs = page_header_get_field(frame, PAGE_N_RECS);
    uint64_t max_trx_id = mach_read_from_8(frame + PAGE_HEADER + PAGE_MAX_TRX_ID);
    uint16_t level = page_header_get_field(frame, PAGE_LEVEL);
    uint64_t index_id = mach_read_from_8(frame + PAGE_HEADER + PAGE_INDEX_ID);

    const char *dir_name = "UNKNOWN";
    switch (direction) {
        case PAGE_LEFT:
            dir_name = "PAGE_LEFT";
            break;
        case PAGE_RIGHT:
            dir_name = "PAGE_RIGHT";
            break;
        case PAGE_SAME_REC:
            dir_name = "PAGE_SAME_REC";
            break;
        case PAGE_SAME_PAGE:
            dir_name = "PAGE_SAME_PAGE";
            break;
        case PAGE_NO_DIRECTION:
            dir_name = "PAGE_NO_DIRECTION";
            break;
        default:
            break;
    }

    printf("  %-30s %u\n", "N Dir Slots:", n_dir_slots);
    printf("  %-30s %u\n", "Heap Top:", heap_top);
    printf("  %-30s %u (compact: %s)\n", "N Heap:", n_heap, is_compact ? "yes" : "no");
    printf("  %-30s %u\n", "Free Offset:", free_offset);
    printf("  %-30s %u bytes\n", "Garbage:", garbage);
    printf("  %-30s %u\n", "Last Insert:", last_insert);
    printf("  %-30s %u (%s)\n", "Direction:", direction, dir_name);
    printf("  %-30s %u\n", "N Direction:", n_direction);
    printf("  %-30s %u\n", "N Records:", n_recs);
    printf("  %-30s %lu\n", "Max Trx ID:", max_trx_id);
    printf("  %-30s %u (%s)\n", "Page Level:", level, level == 0 ? "leaf" : "non-leaf");
    printf("  %-30s %lu\n", "Index ID:", index_id);
}

void ParsePage::DisplayRecordsSummary(gaia_apply::byte *frame) {
    printf("\n--- Records Summary ---\n");

    using namespace gaia_apply;

    bool is_comp = page_is_comp(frame);
    ulint n_recs_header = page_get_n_recs(frame);

    // Traverse the record linked list from infimum to supremum
    INIT_APPLY_RAW_ARG(false);
    const byte *supremum = page_get_supremum_rec(const_cast<const byte *>(frame));
    const rec_t *rec = page_rec_get_next_low(page_get_infimum_rec(const_cast<const byte *>(frame)),
                                             is_comp APPLY_RAW_ARG_NAME_CC);

    uint32_t count = 0;
    const uint32_t max_iterations = 0x7FFF;
    bool traversal_ok = false;

    if (!APPLY_RAW_IS_ERROR()) {
        while (rec != nullptr && rec != supremum && count < max_iterations) {
            ++count;
            rec = page_rec_get_next_low(rec, is_comp APPLY_RAW_ARG_NAME_CC);
            if (APPLY_RAW_IS_ERROR()) {
                break;
            }
        }
        traversal_ok = (rec == supremum);
    }

    printf("  %-30s %lu\n", "N Recs (from header):", n_recs_header);
    printf("  %-30s %u\n", "N Recs (from traversal):", count);
    printf("  %-30s %s\n",
           "Traversal reached supremum:", traversal_ok ? "YES" : "NO - possible corruption");
    if (count != n_recs_header) {
        printf("  *** WARNING: header count (%lu) and traversal count (%u) MISMATCH ***\n",
               n_recs_header, count);
    }
    printf("  %-30s %s\n", "Page format:", is_comp ? "COMPACT" : "REDUNDANT");
    printf("  %-30s %s\n", "Is Leaf:", page_is_leaf(frame) ? "yes" : "no");
    printf("  %-30s %s\n", "Is Empty:", page_is_empty(frame) ? "yes" : "no");
}

void ParsePage::DisplayRecordsDetail(gaia_apply::byte *frame) {
    printf("\n--- Records Detail ---\n");

    using namespace gaia_apply;

    bool is_comp = page_is_comp(frame);
    INIT_APPLY_RAW_ARG(false);

    const byte *supremum = page_get_supremum_rec(const_cast<const byte *>(frame));
    const rec_t *rec = page_rec_get_next_low(page_get_infimum_rec(const_cast<const byte *>(frame)),
                                             is_comp APPLY_RAW_ARG_NAME_CC);

    uint32_t rec_idx = 0;
    const uint32_t max_iterations = 0x7FFF;

    while (rec != nullptr && rec != supremum && rec_idx < max_iterations) {
        if (APPLY_RAW_IS_ERROR()) {
            printf("  *** ERROR: traversal error at record #%u ***\n", rec_idx);
            break;
        }

        ulint rec_offset = rec - frame;
        bool deleted = rec_get_deleted_flag(rec, is_comp);

        if (is_comp) {
            // COMPACT format
            ulint status = rec_get_status(rec);
            ulint info_bits = rec_get_info_bits(rec, true);
            ulint heap_no = rec_get_heap_no_new(rec);
            ulint n_owned = rec_get_n_owned_new(rec);
            ulint next_offs = rec_get_next_offs(rec, true APPLY_RAW_ARG_NAME_CC);

            const char *status_name = "UNKNOWN";
            switch (status) {
                case REC_STATUS_ORDINARY:
                    status_name = "ORDINARY";
                    break;
                case REC_STATUS_NODE_PTR:
                    status_name = "NODE_PTR";
                    break;
                case REC_STATUS_INFIMUM:
                    status_name = "INFIMUM";
                    break;
                case REC_STATUS_SUPREMUM:
                    status_name = "SUPREMUM";
                    break;
                default:
                    break;
            }

            printf("\n  Record #%u (offset: %lu)\n", rec_idx, rec_offset);
            printf("    --- Record Header (5 bytes) ---\n");
            printf("    Raw header hex:");
            for (int i = REC_N_NEW_EXTRA_BYTES; i > 0; --i) {
                printf(" %02x", *(rec - i));
            }
            printf("\n");
            printf("    %-24s 0x%02lx (delete_mark:%u min_rec:%u instant:%u versioned:%u)\n",
                   "Info Bits:", info_bits,
                   static_cast<unsigned>((info_bits & REC_INFO_DELETED_FLAG) ? 1 : 0),
                   static_cast<unsigned>((info_bits & REC_INFO_MIN_REC_FLAG) ? 1 : 0),
                   static_cast<unsigned>((info_bits & REC_INFO_INSTANT_FLAG) ? 1 : 0),
                   static_cast<unsigned>((info_bits & REC_INFO_VERSION_FLAG) ? 1 : 0));
            printf("    %-24s %lu\n", "N Owned:", n_owned);
            printf("    %-24s %lu (0x%04lx)\n", "Heap No:", heap_no, heap_no);
            printf("    %-24s %lu (%s)\n", "Status:", status, status_name);
            printf("    %-24s %lu (next record at page offset %lu)\n", "Next Offset:", next_offs,
                   next_offs);
            printf("    %-24s %s\n", "Deleted:", deleted ? "YES" : "no");

            if (_show_record_data) {
                // Without dict_index_t we cannot parse individual fields for COMPACT format.
                // Show raw data from rec pointer up to the next record or a reasonable limit.
                ulint data_len = 0;
                if (next_offs > 0 && next_offs > rec_offset) {
                    data_len = next_offs - rec_offset;
                    if (data_len > 256) data_len = 256;
                } else {
                    data_len = 64;  // fallback
                }
                // Ensure we don't read beyond the page
                if (rec_offset + data_len > gaia_apply::FLAGS_univ_page_size) {
                    data_len = gaia_apply::FLAGS_univ_page_size - rec_offset;
                }

                printf("    Data (%lu bytes):\n      ", data_len);
                for (ulint i = 0; i < data_len; ++i) {
                    printf("%02x ", rec[i]);
                    if ((i + 1) % 32 == 0 && i + 1 < data_len) printf("\n      ");
                }
                printf("\n");
            }
        } else {
            // REDUNDANT format: can parse fields without dict_index_t
            ulint heap_no = rec_get_heap_no_old(rec);
            ulint info_bits = rec_get_info_bits(rec, false);
            uint16_t n_fields = rec_get_n_fields_old_raw(rec);
            bool one_byte_offs = rec_get_1byte_offs_flag(rec);

            printf("\n  Record #%u (offset: %lu)\n", rec_idx, rec_offset);
            printf("    %-24s %lu\n", "Heap No:", heap_no);
            printf("    %-24s 0x%02lx\n", "Info Bits:", info_bits);
            printf("    %-24s %s\n", "Deleted:", deleted ? "YES" : "no");
            printf("    %-24s %u\n", "N Fields:", n_fields);
            printf("    %-24s %s\n", "Offset Form:", one_byte_offs ? "1-byte" : "2-byte");

            if (_show_record_data) {
                for (uint16_t i = 0; i < n_fields; ++i) {
                    ulint end_info;
                    bool is_null = false;
                    bool is_extern = false;

                    if (one_byte_offs) {
                        end_info = rec_1_get_field_end_info_low(rec, i APPLY_RAW_ARG_NAME_CC);
                        if (APPLY_RAW_IS_ERROR()) break;
                        is_null = (end_info & REC_1BYTE_SQL_NULL_MASK) != 0;
                    } else {
                        end_info = rec_2_get_field_end_info_low(rec, i APPLY_RAW_ARG_NAME_CC);
                        if (APPLY_RAW_IS_ERROR()) break;
                        is_null = (end_info & REC_2BYTE_SQL_NULL_MASK) != 0;
                        is_extern = (end_info & REC_2BYTE_EXTERN_MASK) != 0;
                    }

                    ulint field_start = rec_get_field_start_offs_low(rec, i APPLY_RAW_ARG_NAME_CC);
                    if (APPLY_RAW_IS_ERROR()) break;
                    ulint field_size = rec_get_nth_field_size_low(rec, i APPLY_RAW_ARG_NAME_CC);
                    if (APPLY_RAW_IS_ERROR()) break;

                    printf("    Field #%-3u offset=%-5lu len=%-5lu", i, field_start, field_size);
                    if (is_null) printf(" [NULL]");
                    if (is_extern) printf(" [EXTERN]");

                    if (!is_null && field_size > 0) {
                        const byte *data = rec + field_start;
                        ulint print_len = field_size > 64 ? 64 : field_size;
                        printf(" hex: ");
                        for (ulint j = 0; j < print_len; ++j) {
                            printf("%02x ", data[j]);
                        }
                        if (field_size > 64) printf("...");
                    }
                    printf("\n");
                }
            }
        }

        ++rec_idx;
        rec = page_rec_get_next_low(rec, is_comp APPLY_RAW_ARG_NAME_CC);
    }

    printf("\n  Total records displayed: %u\n", rec_idx);
}

void ParsePage::DisplayHexDump(const gaia_apply::byte *frame, uint64_t page_size) {
    printf("\n--- Hex Dump ---\n");

    uint64_t dump_size = page_size;
    if (_hex_dump_limit > 0 && _hex_dump_limit < page_size) {
        dump_size = _hex_dump_limit;
    }

    for (uint64_t i = 0; i < dump_size; i += 16) {
        printf("  %04lx: ", i);
        for (uint64_t j = 0; j < 16 && (i + j) < dump_size; ++j) {
            printf("%02x ", frame[i + j]);
            if (j == 7) printf(" ");
        }
        if (i + 16 > dump_size) {
            for (uint64_t j = dump_size - i; j < 16; ++j) {
                printf("   ");
                if (j == 7) printf(" ");
            }
        }
        printf(" |");
        for (uint64_t j = 0; j < 16 && (i + j) < dump_size; ++j) {
            uint8_t c = frame[i + j];
            printf("%c", (c >= 32 && c < 127) ? c : '.');
        }
        printf("|\n");
    }

    if (dump_size < page_size) {
        printf("  ... (%lu more bytes not shown)\n", page_size - dump_size);
    }
}

int ParsePage::Run() {
    gaiadb::common::ut_crc32_init();

    if (_ibd_file.empty()) {
        print_error("miss --ibd-file");
        return 1;
    }
    if (!_set_physical_page_no && !_set_offset) {
        print_error("miss --physical-page-no or --offset");
        return 1;
    }
    if (_set_physical_page_no && _set_offset) {
        print_error("cannot specify both --physical-page-no and --offset");
        return 1;
    }

    int fd = open(_ibd_file.c_str(), O_RDONLY, 0644);
    if (fd < 0) {
        print_error("open file failed, %s", strerror(errno));
        return 1;
    }
    std::shared_ptr<nullptr_t> guard_fd(nullptr, [&fd](nullptr_t) {
        if (fd > -1) {
            close(fd);
        }
    });

    struct stat sbuf;
    if (fstat(fd, &sbuf) != 0) {
        print_error("get file size failed");
        return 1;
    }

    uint64_t file_size = sbuf.st_size;
    if (file_size % gaia_apply::FLAGS_univ_page_size != 0 || file_size == 0) {
        print_error("file size not valid, %lu", file_size);
        return 1;
    }

    uint64_t read_offset = 0;
    if (_set_physical_page_no) {
        read_offset = _physical_page_no * gaia_apply::FLAGS_univ_page_size;
    } else {
        if (_offset % gaia_apply::FLAGS_univ_page_size != 0) {
            print_error("offset must be aligned to page size (%d)",
                        gaia_apply::FLAGS_univ_page_size);
            return 1;
        }
        read_offset = _offset;
    }
    if (read_offset >= file_size) {
        print_error("offset %lu exceeds file size %lu", read_offset, file_size);
        return 1;
    }

    struct BufBlockRelease {
        void operator()(gaia_apply::buf_block_t *p) const {
            free(p->frame);
            free(p);
        }
    };

    gaia_apply::page_size_t page_size(gaia_apply::FLAGS_univ_page_size,
                                      gaia_apply::FLAGS_univ_page_size, false);

    auto *block_raw =
            static_cast<gaia_apply::buf_block_t *>(malloc(sizeof(gaia_apply::buf_block_t)));
    void *buf =
            std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size);
    auto buf_compress = static_cast<gaia_apply::byte *>(
            std::aligned_alloc(gaia_apply::FLAGS_univ_page_size, gaia_apply::FLAGS_univ_page_size));
    block_raw->frame = static_cast<gaia_apply::byte *>(buf);
    block_raw->page.size.copy_from(page_size);

    BufBlockRelease buf_release;
    std::unique_ptr<gaia_apply::buf_block_t, BufBlockRelease> block(block_raw, buf_release);

    int64_t n = pread(fd, buf, gaia_apply::FLAGS_univ_page_size, read_offset);
    if (n != static_cast<int64_t>(gaia_apply::FLAGS_univ_page_size)) {
        print_error("read failed at offset %lu, read %ld bytes, error: %s", read_offset, n,
                    strerror(errno));
        return 1;
    }

    if (!decompress_page(block_raw->frame, buf_compress, gaia_apply::FLAGS_univ_page_size)) {
        print_error("decompress page failed at offset %lu", read_offset);
        return 1;
    }

    bool is_empty = false;
    bool corrupted = page_is_corrupted(block->frame, gaia_apply::FLAGS_univ_page_size, &is_empty);

    auto *frame = block->frame;

    printf("=== Page at offset %lu (physical page_no in file: %lu) ===\n", read_offset,
           read_offset / gaia_apply::FLAGS_univ_page_size);
    printf("File: %s\n", _ibd_file.c_str());
    printf("Checksum: %s\n", corrupted ? "CORRUPTED" : "OK");
    if (is_empty) {
        printf("Page is EMPTY (all zeros)\n");
    }

    uint32_t page_no = gaia_apply::mach_read_from_4(frame + gaia_apply::FIL_PAGE_OFFSET);
    printf("page_no: %u\n", page_no);

    if (_set_space_id) {
        uint32_t actual_space_id = gaia_apply::page_get_space_id(frame);
        if (actual_space_id != _space_id) {
            printf("*** WARNING: space_id MISMATCH! expected: %u, actual: %u ***\n", _space_id,
                   actual_space_id);
        } else {
            printf("Space ID: %u (matched)\n", _space_id);
        }
    }

    DisplayFilHeader(frame);

    auto page_type = gaia_apply::fil_page_get_type(frame);
    if (gaia_apply::fil_page_type_is_index(page_type)) {
        DisplayPageHeader(frame);
        if (!is_empty && !corrupted) {
            DisplayRecordsSummary(frame);
            if (_show_records) {
                DisplayRecordsDetail(frame);
            }
        }
    }

    DisplayFilTrailer(frame, gaia_apply::FLAGS_univ_page_size);

    if (_hex_dump) {
        DisplayHexDump(frame, gaia_apply::FLAGS_univ_page_size);
    }

    free(buf_compress);
    return corrupted ? 1 : 0;
}

}  // namespace gaia
}  // namespace psvr
