/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/common.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <atomic>
#include <functional>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <unordered_map>

#include <base/time.h>
#include <base/macros.h>
#include <bvar/bvar.h>

#include <gaiadb/utils/aarch64.h>
#include <gaiadb/utils/rw_lock.h>
#include <psvr0meta.h>

#include "psvr/stat.h"
#include "psvr/log.h"

namespace psvr {

#if _GLIBCXX_USE_PTHREAD_RWLOCK_T
using rwlock_t = gaiadb::common::shared_mutex;
#else
using rwlock_t = std::shared_mutex;
#endif

template<typename T>
class UpdateIfBigger {
public:
    UpdateIfBigger() : UpdateIfBigger(0) {}
    UpdateIfBigger(T val)
        : _val(val) {}
    UpdateIfBigger(const UpdateIfBigger& lhs)
        : _val(lhs.get()) {}
    ~UpdateIfBigger() {}

    void set(T val, bool update_if_bigger = false) {
        if (update_if_bigger) {
            T old = _val.load(std::memory_order_acquire);
            do {
                if (old >= val) {
                    break;
                }
            } while (!_val.compare_exchange_strong(old, val, std::memory_order_release));
        } else {
            _val.store(val, std::memory_order_release);
        }
    }
    T get() const {
        return _val.load(std::memory_order_acquire);
    }
    T operator()() const {
        return get();
    }
    void operator()(T val, bool update_if_bigger = false) {
        return set(val, update_if_bigger);
    }

private:
    std::atomic<T> _val;
};

using Lsn = UpdateIfBigger<gaia_apply::lsn_t>;

class AcquireLock {
public:
    AcquireLock() : _lock(false), _stopped(nullptr) {}
    AcquireLock(volatile bool* stopped) : _lock(false), _stopped(stopped) {}
    ~AcquireLock() {}

    void lock() {
        while (!_stopped ? true : (!*_stopped)) {
            if (!_lock.exchange(true, std::memory_order_acquire)) {
                break;
            }
            while (_lock.load(std::memory_order_relaxed)) {
                gaiadb::common::pause();
            }
        }
    }
    bool try_lock() {
        return !_lock.exchange(true, std::memory_order_acquire);
    }
    void unlock() {
        return _lock.store(false, std::memory_order_release);
    }
    bool test() const {
        return _lock.load(std::memory_order_acquire);
    }
private:
    std::atomic<bool> _lock;
    volatile bool* _stopped;
};

class Timer {
public:
    Timer() : _timer(0), _point_timer(0) {}
    // base::Timer::STARTED
    explicit Timer(base::Timer::TimerType) { reset(); }
    explicit Timer(int64_t us) { reset(us); }
    Timer(const Timer& t) : _timer(t._timer), _point_timer(t._point_timer) {}
    ~Timer() {}

    void reset() { reset(base::cpuwide_time_us()); }
    void reset(int64_t us) {
        _timer = us;
        _point_timer = us;
    }

    int64_t start_time() const { return _timer; }

    int64_t u_elapsed() const { return (base::cpuwide_time_us() - _timer); }
    int64_t m_elapsed() const { return u_elapsed() / 1000l; }
    int64_t s_elapsed() const { return m_elapsed() / 1000l; }

    int64_t u_elapsed_point() {
        auto new_point_timer = base::cpuwide_time_us();
        auto elapsed = (new_point_timer - _point_timer);
        _point_timer = new_point_timer;
        return elapsed;
    }
    int64_t m_elapsed_point() { return u_elapsed_point() / 1000l; }
    int64_t s_elapsed_point() { return m_elapsed_point() / 1000l; }

private:
    int64_t _timer;
    int64_t _point_timer;
};

struct TimerGuard {
    TimerGuard(StatLatency& lat) : _timer(base::Timer::STARTED), _lat(lat) {}
    TimerGuard(StatLatency& lat, int64_t us) : _timer(us), _lat(lat) {}
    ~TimerGuard() { _lat << _timer.u_elapsed() ; }

    int64_t start_time() const { return _timer.start_time(); }
    int64_t u_elapsed() const { return _timer.u_elapsed(); }
    int64_t m_elapsed() const { return _timer.m_elapsed(); }
    int64_t s_elapsed() const { return _timer.s_elapsed(); }

private:
    Timer _timer;
    StatLatency& _lat;
};

class BitFlag {
public:
class Ref {
public:
    Ref(uint32_t pos, BitFlag* p) : _pos(pos), _p(p) {}
    ~Ref() {}

    Ref& operator=(bool x);
    operator bool() const;

private:
    uint32_t _pos;
    BitFlag* _p;
};
public:
    // max count <= 64
    BitFlag(uint32_t count = 0) {
        if (count) {
            Reset(count);
        }
    }
    ~BitFlag() {}

    void Reset(uint32_t count) {
        //assert(count <= 64u && count > 0u);
        _v = 0;
        _count = count;
        _mask = (1ul << count) - 1;
    }

    // mark bit value to 1
    void SetIdx(uint32_t pos) {
        //assert(pos < _count);
        _v |= (0x1ul << pos);
    }

    // mark bit value to 0
    void ClearIdx(uint32_t pos) {
        //assert(pos < _count);
        _v &= ~(0x1ul << pos);
    }

    // test bit value is 1
    bool Test(uint32_t pos) const {
        //assert(pos < _count);
        return (0x1ul << pos) & _v;
    }

    // test [start, end) bits value are 1
    bool Test(uint32_t start, uint32_t end) const {
        //assert(start < _count && end <= _count);
        for (uint32_t i = start; i < end; ++i) {
            if (((0x1ul << i) & _v) == 0) {
                return false;
            }
        }
        return true;
    }

    // test all bits value are 1
    bool IsFull() const {
        return (_v & _mask) == _mask;
    }

    // test all bits value are 0
    bool IsEmpty() const {
        return _v == 0;
    }

    bool MajorityTest() const {
        if (IsFull()) {
            return true;
        }
        if (IsEmpty()) {
            return false;
        }
        uint32_t n = 0;
        for (uint32_t i = 0; i < _count; ++i) {
            if (((0x1ul << i) & _v) != 0) {
                if (++n > _count / 2) {
                    return true;
                }
            }
        }
        return false;
    }

    Ref operator[] (uint32_t pos) {
        return Ref(pos, this);
    }

private:
    uint64_t _v {0};
    uint32_t _count {0};
    uint64_t _mask {0};
};

inline BitFlag::Ref& BitFlag::Ref::operator=(bool x) {
    if (x) {
        _p->SetIdx(_pos);
    } else {
        _p->ClearIdx(_pos);
    }
    return *this;
}

inline BitFlag::Ref::operator bool() const {
    return _p->Test(_pos);
}

class RefCount {
public:
    RefCount() : _ref_n(1) {}
    virtual ~RefCount() {}

    int64_t IncRef() { return _ref_n.fetch_add(1, std::memory_order_relaxed); }
    int64_t DecRef() { return _ref_n.fetch_sub(1, std::memory_order_relaxed); }

private:
    std::atomic<int64_t> _ref_n;
};

template<typename Key, typename Value>
class BAIDU_CACHELINE_ALIGNMENT Manager {
public:
    Manager() {}
    ~Manager() {}

    rwlock_t& shared_mutex() { return _shared_mutex; }

    std::shared_ptr<Value> Get(const Key& key) {
        std::shared_lock slk(_shared_mutex);
        if (auto it = _entrys.find(key);
                it != _entrys.end()) {
            return it->second;
        }
        return nullptr;
    }

#define PSVR_PRIVATE_MANAGER_CREATE(CTOR_ARGS)              \
    if (auto it = _entrys.find(key);                        \
            it != _entrys.end()) {                          \
        return it->second;                                  \
    } else {                                                \
        std::shared_ptr<Value> entry(new Value CTOR_ARGS);  \
        return _entrys.emplace(key, entry).first->second;   \
    }

    std::shared_ptr<Value> GetOrCreate(const Key& key) {
        std::unique_lock lk(_shared_mutex);
        PSVR_PRIVATE_MANAGER_CREATE();
    }

    template<typename Arg1>
    std::shared_ptr<Value> GetOrCreate(const Key& key, Arg1 arg1) {
        std::unique_lock lk(_shared_mutex);
        PSVR_PRIVATE_MANAGER_CREATE((arg1));
    }

    template<typename Arg1, typename Arg2>
    std::shared_ptr<Value> GetOrCreate(const Key& key, Arg1 arg1, Arg2 arg2) {
        std::unique_lock lk(_shared_mutex);
        PSVR_PRIVATE_MANAGER_CREATE((arg1, arg2));
    }

#undef PSVR_PRIVATE_MANAGER_CREATE

    bool Remove(const Key& key) {
        std::unique_lock lk(_shared_mutex);
        return _entrys.erase(key) > 0;
    }

private:
    rwlock_t _shared_mutex;
    std::unordered_map<Key, std::shared_ptr<Value>> _entrys;
};

template<typename Key, typename Value>
class BAIDU_CACHELINE_ALIGNMENT ResManager : public std::enable_shared_from_this<ResManager<Key, Value>> {
    static constexpr bool _debug_trace = false;
    using Base = std::enable_shared_from_this<ResManager<Key, Value>>;
public:
    struct Deleter {
        std::shared_ptr<ResManager<Key, Value>> owner;
        Key key;
        Deleter(std::shared_ptr<ResManager<Key, Value>> o, Key k) : owner(o), key(k) {}
        ~Deleter() {}

        void operator()(Value* value) {
            owner->Remove(key);
            delete value;
            value = nullptr;
        }
    };

    ResManager(bvar::Adder<int64_t>& stat) : _stat_count(stat) {}
    ~ResManager() {}

#define PSVR_PRIVATE_RES_MANAGER_GET() \
    std::unique_lock lk(_mutex);    \
    if (auto it = _res_map.find(key); it != _res_map.end()) {   \
        auto value = it->second.lock(); \
        if (value) {    \
            LOG_IF(TRACE, _debug_trace) << "get " << (value.get());\
            return value;   \
        }   \
    }

#define PSVR_PRIVATE_RES_MANAGER_CREATE(CTOR_ARGS)  \
    Deleter deleter(Base::shared_from_this(), key);   \
    std::shared_ptr<Value> value(new Value CTOR_ARGS, deleter); \
    auto [it, result] = _res_map.emplace(key, value);   \
    if (!result) {  \
        assert(it->second.expired());    \
        _res_map[key] = value;  \
        LOG_IF(TRACE, _debug_trace) << "replace " << (value.get());\
    }   \
    _stat_count << 1;   \
    LOG_IF(TRACE, _debug_trace) << "create " << (value.get());\
    return value;

    std::shared_ptr<Value> Get(const Key& key) {
        PSVR_PRIVATE_RES_MANAGER_GET();
        return nullptr;
    }

    std::shared_ptr<Value> GetOrCreate(const Key& key) {
        PSVR_PRIVATE_RES_MANAGER_GET();
        PSVR_PRIVATE_RES_MANAGER_CREATE();
    }

    template<typename Arg1>
    std::shared_ptr<Value> GetOrCreate(const Key& key, const Arg1& arg1) {
        PSVR_PRIVATE_RES_MANAGER_GET();
        PSVR_PRIVATE_RES_MANAGER_CREATE((arg1));
    }

    template<typename Arg1, typename Arg2>
    std::shared_ptr<Value> GetOrCreate(const Key& key, const Arg1& arg1, const Arg2& arg2) {
        PSVR_PRIVATE_RES_MANAGER_GET();
        PSVR_PRIVATE_RES_MANAGER_CREATE((arg1, arg2));
    }

    template<typename Fn>
    void Iterator(Fn fn) {
        std::unique_lock lk(_mutex);
        for (auto&& [key, value] : _res_map) {
            fn(key, value.lock());
        }
    }

#undef PSVR_PRIVATE_RES_MANAGER_GET
#undef PSVR_PRIVATE_RES_MANAGER_CREATE

    bool Remove(Key key) {
        std::unique_lock lk(_mutex);
        _stat_count << -1;
        if (auto it = _res_map.find(key); it != _res_map.end()) {
            if (!it->second.expired()) {
                // 1) A wait to release
                // 2) B replace map key
                // 3) A release ok
                // 4) B release ok (erase key)
                LOG_IF(TRACE, _debug_trace) << "res create again, key:" << key;
                return false;
            } else {
                // 1) A wait to release
                // 2) B replace map key, and wait to release
                // 3) A or B release ok (erase key by first)
                _res_map.erase(key);
                return true;
            }
        } else {
            // 1) A wait to release
            // 2) B replace map key, and release ok (erase key)
            // 3) A release ok
            return false;
        }
    }

private:
    std::mutex _mutex;
    std::unordered_map<Key, std::weak_ptr<Value>> _res_map;
    // stat
    bvar::Adder<int64_t>& _stat_count;
};

struct GuardFd {
    GuardFd(int32_t& fd) : _fd(fd) {}
    ~GuardFd() {
        if (_fd > -1) {
            close(_fd);
            _fd = -1;
        }
    }

private:
    int32_t& _fd;
};

struct GuardFdPtr {
    GuardFdPtr(int32_t* fd) : _fd(fd), _none(-1) {}
    ~GuardFdPtr() {
        if (*_fd > -1) {
            close(*_fd);
            *_fd = -1;
        }
    }

    int32_t release() {
        const int32_t fd = *_fd;
        _fd = &_none;
        return fd;
    }

private:
    int32_t* _fd;
    int32_t _none;
};

template<typename Type, typename Fn>
struct ThreadLocalGuard {
    ThreadLocalGuard(Type** res, Fn fn) : _res(res), _fn(fn) {}
    ~ThreadLocalGuard() {
        if (*_res) {
            _fn(*_res);
        }
        *_res = nullptr;
    }
private:
    Type** _res;
    Fn _fn;
};

}
