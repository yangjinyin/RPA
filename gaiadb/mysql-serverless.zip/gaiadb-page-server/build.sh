bcloud local --set-bcloud-macro=PSVR_BUILD_PROFILER --no-release.bcloud
