/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/parse_apply_rec.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gaiadb/utils/ut.h>
#include <base/strings/string_number_conversions.h>
#include <new>
#include "psvr/common.h"
#include "psvr/utils.h"
#include "psvr/config.h"
#include "psvr/log.h"
#include "psvr/page_op.h"
#include "psvr/record_op.h"
#include "psvr/buf.h"
#include "psvr/redo_record.h"

namespace psvr::gaia {

class GaiaLogRecordIterator : public LogRecordIteratorInterface {
public:
    GaiaLogRecordIterator(gaia_apply::byte* start_ptr,
            gaia_apply::byte* end_ptr,
            gaia_apply::lsn_t page_apply_lsn,
            const gaia_apply::space_id_t* apply_space_id = nullptr,
            const gaia_apply::page_no_t* apply_page_no = nullptr);
    ~GaiaLogRecordIterator() override;

    bool Valid() const override { return _valid; }
    void Next() override;
    const LogRecord& Get() const override { return *_record; }
    const db::Status& Status() const override { return _status; }
    size_t ConsumedSize() const;

private:
    void ResetRecord();
    void LoadNext();

private:
    gaia_apply::byte* _scan_ptr;
    gaia_apply::byte* const _start_ptr;
    gaia_apply::byte* const _end_ptr;
    gaia_apply::lsn_t _last_record_end_lsn;
    const gaia_apply::space_id_t* const _apply_space_id;
    const gaia_apply::page_no_t* const _apply_page_no;
    db::Status _status;
    alignas(LogRecord) unsigned char _record_storage[sizeof(LogRecord)];
    LogRecord* _record;
    gaia_apply::ulint _record_len;
    bool _record_initialized;
    bool _valid;
};

bool ApplyPageLogRecordsNoLock(
        BufBlockPtr apply_buf_block,
        gaia_apply::lsn_t* page_apply_lsn,
        uint64_t* apply_records_size,
        LogRecordIteratorInterface& iter,
        uint32_t max_apply_num = 0);

bool parse_records(gaia_apply::byte* start_ptr,
        gaia_apply::byte* end_ptr,
        gaia_apply::lsn_t* page_apply_lsn,
        uint64_t* apply_records_size = nullptr,
        BufBlockPtr apply_buf_block = nullptr,
        const gaia_apply::space_id_t* apply_space_id = nullptr,
        const gaia_apply::page_no_t* apply_page_no = nullptr,
        uint32_t max_apply_num = 0,
        size_t* consumed_size = nullptr);

}
