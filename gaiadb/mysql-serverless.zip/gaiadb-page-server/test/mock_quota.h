/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_quota.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

namespace psvr {
namespace test {

// The quota limit of the mock. It must exceed the estimated footprint of the log
// blocks under test (calc_log_block_quota_size()), otherwise Quota::Enable() reports
// the quota as disabled and the acquire/release paths are never exercised.
static int64_t quota_size {1 << 20};

class MockQuota : public Quota {
public:
    MockQuota() : Quota(&quota_size) {}
    virtual ~MockQuota() {}

    MOCK_METHOD1(Acquire, bool(int64_t));
    MOCK_METHOD1(Release, void(int64_t));

private:
};

}
}
