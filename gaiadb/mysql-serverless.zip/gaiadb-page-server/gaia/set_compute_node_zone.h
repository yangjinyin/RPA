/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_compute_node_zone.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class SetComputeNodeZone : public Command {
public:
    SetComputeNodeZone() {
        SetName("set-compute-node-zone");
        SetDesc("set compute node zone in manager");
        SetDescCn("设置管理服务中计算节点的可用区");

        AddPsmClusterOption();
        AddRequiredArgOption("addr", &_long_opt_val, kOptMax + 1, "server endpoint information", kip_port);
        AddZoneOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "manager cluster id", kstring);
        
        AddExample("--manager-address \"bns://xxx\" --addr <ip:port> --region bjdd --available-zone test");
    }
    virtual ~SetComputeNodeZone() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'c':
            _cluster_id = opt;
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptRegion:
                _zone.region = opt;
                break;
            case kOptAvailableZone:
                _zone.available_zone = opt;
                break;
            case kOptMax + 1:
                _addr = opt;
                break;            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::AckResponse& rsp);

private:
    std::string _manager_address {};
    std::string _addr {};
    VarZone _zone;
    std::string _cluster_id {};
};

}
}
