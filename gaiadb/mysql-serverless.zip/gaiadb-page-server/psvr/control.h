/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/control.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gaiadb/common/types.h>
#include "psvr/common.h"
#include "psvr/utils.h"
#include "psvr/thread_pool.hpp"
#include "psvr/buf.h"
#include "psvr/segment_manager.h"
#include "psvr/store.h"
#include "psvr/fetch.h"
#include "psvr/parse.h"
#include "psvr/gc.h"
#include "psvr/recover.h"
#include "psvr/compress.h"
#include "psvr/rbio.h"
#include "psvr/client.h"
#include "psvr/rpc_srv.h"

namespace psvr {

uint64_t get_heartbeat_interval_us();

class Control : public std::enable_shared_from_this<Control> {
public:
struct Context;

enum class Action : uint32_t {
    kInitSegment = 1,
    kPreLoadSegment,
    kLoadSegment,
    kOnLoadSegment,
    kCreateSegment,
    kOnCreateSegment,
    kAsyncCreateSegment,
    kOnAsyncCreateSegment,
    kDropSegment,
    kDeleteSegment,
    kDisableStore,
    kUpdateStore,
    kModifySegmentManagerInfo,
    kMultiModifySegmentManagerInfo,
    kRefreshPsmInfoNodes,
    kLoadSegmentMeta,
    kOnLoadSegmentMeta,
    kGcStoreTrash,
    kMonitorStore,
    kMonitorSegment,
    kHeartbeat,
    kBatchHeartbeat,
    kClearSpaceStatus,
    kResetPsmQuota,
    kUpdateAllStore,
    kIncOrDecThreadNum,
    kUpdateLowestLsn,
    kSealDblwrFile,
};

private:
struct BatchHeartbeatGroup;
struct BatchHeartbeatTask;

using TimerType = thread::Timer<thread::TaskContext>;
using TimerTypePtr = std::shared_ptr<TimerType>;
using ThreadPoolType = ThreadPoolExecutor<Context, thread::TaskContext>;
using ThreadPoolTypePtr = std::shared_ptr<ThreadPoolType>;

public:
    Control(ClientPtr client, bool multi_type);
    virtual ~Control();

    bool stopped() const { return _stopped; }

    void Init();
    FUNC_MOCK bool Start();
    FUNC_MOCK void Stop();

    ControlPtr shared_this() { return std::enable_shared_from_this<Control>::shared_from_this(); }
    ControlWeakPtr weak_this() { return std::enable_shared_from_this<Control>::weak_from_this(); }

    bool multi_type() const { return _multi_type; }
    const base::EndPoint& myself() { return _myself; }
    const std::string& myself_str() { return _myself_str; }

    SegmentPtr one_segment() { return _one_segment; }

    ClientPtr client() { return _client; }
    TimerTypePtr timer() { return _timer; }

    BufPoolPtr buf_pool() { return _buf_pool; }

    SegmentManagerPtr segment_manager() { return _segment_manager; }
    StoreManagerPtr store_manager() { return _store_manager; }

    FetcherPtr fetcher() { return _fetcher; }
    ParserPtr parser() { return _parser; }
    GcManagerPtr gc() { return _gc; }
    RecovererPtr recoverer() { return _recoverer; }
    CompressorPtr compressor() { return _compressor; }
    RbioManagerPtr rbio_manager() { return _rbio_manager; }

    std::shared_ptr<gaiadb::common::DoublyBufferedNodeZone> dbd_zone() { return _dbd_zone; }

    bool Execute(Context* ctx);
    FUNC_MOCK void Dispatch(Context* ctx);
    FUNC_MOCK void RefreshPsmInfo(PsmInfoPtr psm_info);

    void StartWorking(SegmentPtr segment TRACE_FILE_LINE_DC);
private:
    bool InitAddr();
    void SetCtxClientId(Context* ctx);
    void OnCompletion(Context* ctx);
    bool OnTimer(thread::TaskContext* ctx);
    void Schedule(Context* ctx, uint64_t delay_us = 0, bool is_retry = false);

    StorePtr PickStore(int64_t log_id, const std::string& cluster_id, uint64_t size, int32_t store_id);

    RpcGetPageServerCtx* CreateGetPageServerRpcCtx(PsmInfoPtr psm_info,
                const std::string& cluster_id, uint32_t segment_id = 0);

    void InitSegment(Context* ctx);
    void OnInitSegment(PsmInfoPtr psm_info, Context* ctx, RpcGetPageServerCtx* rpc_ctx);

    const ThreadPoolTypePtr& GetThreadPool(Context* ctx) const;
    bool IsCoreAction(Context* ctx) const;

    void PreLoadSegment(Context* ctx);
    void LoadSegment(Context* ctx);
    void OnLoadSegment(Context* ctx);
    void OnLoadSegmentRPC(Context* ctx, RpcGetPageServerCtx* rpc_ctx);

    void CreateSegment(Context* ctx);
    void OnCreateSegment(Context* ctx);
    void OnCreateSegmentRPC(Context* ctx, RpcGetPageServerCtx* rpc_ctx);

    void AsyncCreateSegment(Context* ctx);
    void OnAsyncCreateSegment(Context* ctx);
    void OnAsyncCreateSegmentRPC(Context* ctx, RpcGetPageServerCtx* rpc_ctx);

    void LoadSegmentMeta(Context* ctx);
    void OnLoadSegmentMeta(Context* ctx);
    void OnLoadSegmentMetaRPC(Context* ctx, RpcGetPageServerCtx* rpc_ctx);

    void DropSegment(Context* ctx);
    void DeleteSegment(Context* ctx);

    void DisableStore(Context* ctx);
    void UpdateStore(Context* ctx);
    void UpdateAllStore(Context* ctx);

    void ModifySegmentManagerInfo(Context* ctx);
    void MultiModifySegmentManagerInfo(Context* ctx);
    void RefreshPsmInfoNodes(Context* ctx);

    void Heartbeat(Context* ctx);
    void OnHeartbeat(Context* ctx, RpcPageServerHeartbeatCtx* rpc_ctx);

    void BatchHeartbeat(Context* ctx);
    void OnBatchHeartbeat(PsmInfoPtr psm_info,
            std::shared_ptr<BatchHeartbeatTask> heartbeat_ctx,
            std::shared_ptr<BatchHeartbeatGroup> group);

    void RemoveGarbageSegment(const std::string& cluster_id,
            uint32_t segment_id, uint64_t version);
    void OnRemoveGarbageSegment(pspb::DropSegmentRequest* request, pspb::DropSegmentResponse* response);

    void GcStoreTrash(Context* ctx);
    void MonitorStore(Context* ctx);
    void MonitorSegment(Context* ctx);

    void ClearSpaceStatus(Context* ctx);
    void ResetPsmQuota(Context* ctx);

    void IncOrDecThreadNum(Context* ctx);

    void OnUpdateLowestLsn(RpcGetLowestCtx* rpc_ctx, ClusterPtr cluster);
    void UpdateLowestLsn(Context* ctx);

    void SealDblwrFile(Context* ctx);

private:
    base::EndPoint _myself;
    std::string _myself_str;
    ClientPtr _client;
    CONST_MOCK bool _multi_type;
    volatile bool _stopped;
    uint32_t _thread_num;
    uint32_t _task_thread_num;
    SegmentPtr _one_segment;    // for one segment mode
    TimerTypePtr _timer;
    ThreadPoolTypePtr _thread_pool;
    ThreadPoolTypePtr _task_thread_pool;
    SegmentManagerPtr _segment_manager;
    StoreManagerPtr _store_manager;
    BufPoolPtr _buf_pool;
    RPCServerPtr _rpc_server;
    FetcherPtr _fetcher;
    ParserPtr _parser;
    GcManagerPtr _gc;
    RecovererPtr _recoverer;
    CompressorPtr _compressor;
    RbioManagerPtr _rbio_manager;
    std::atomic<uint64_t> _heartheat_epoch;
    std::shared_ptr<gaiadb::common::DoublyBufferedNodeZone> _dbd_zone;
    std::shared_ptr<LoadStat> _load_stat;
    int64_t _server_start_time;
    int64_t _get_metadata_quota_per_cluster;
    rwlock_t _mutex;
    std::atomic<int32_t> _running_context_size;
    std::atomic<bool> _in_stopping;
    // stat
    StatLatency _stat_heartbeat_task_lat;
    StatLatency _stat_heartbeat_rpc_lat;
};

}
