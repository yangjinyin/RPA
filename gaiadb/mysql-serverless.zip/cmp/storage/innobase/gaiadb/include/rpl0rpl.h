/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file include/rpl0rpl.h
 Gaiadb redo log replication

 Created 10/12/2021 Hongyu Qiao
 *******************************************************/

#pragma once

#include "base/macros.h"
#include "gflags/gflags.h"
#include "rpl0assemble.h"
#include "rpl0metric.h"
#include <string>

namespace rpl {

constexpr static uint64_t MB = 1024 * 1024;

DECLARE_bool(rpl_enable_delta_replay);

using speed_t = uint64_t;

class RplSys;

extern RplSys *rpl_sys;

extern lsn_t get_ls_dispatch_lsn();
extern lsn_t get_fetch_lsn();
extern lsn_t get_parse_lsn();
extern lsn_t get_apply_lsn();
extern lsn_t get_read_lsn();
extern lsn_t get_flush_lsn();
extern lsn_t get_master_vdl();
extern lsn_t get_lowest_lsn();
extern bool get_init_finished();
extern lsn_t get_init_lsn();

extern speed_t get_fetch_speed();
extern speed_t get_parse_speed();
extern speed_t get_apply_speed();
extern uint64_t get_behind_master();
extern trx_id_t get_max_trx_no();

extern bool rpl_sys_init();
extern bool rpl_sys_start();
extern bool rpl_sys_close();
extern void rpl_sys_deinit();
extern void stop_background_threads();

extern uint32_t rbio_get_refed_read_lsn(lsn_t &vlsn, lsn_t *refed_lsn, lsn_t *lowest_lsn);
extern int32_t rbio_further_apply(uint32_t refed_type, uint64_t refed_index,
    buf_block_t *block, lsn_t start_lsn, lsn_t end_lsn);
extern void rbio_finish_apply(uint32_t refed_type, uint64_t refed_index);

extern void bp_get_further_apply(buf_block_t *block);
extern thread_local bool is_apply_thread;
extern bool rpl_binlog_in_redo_flusher(bool binlog_in_redo);

extern uint64_t get_fetch_get_log_bw(void*);

struct RplConst {
  static constexpr uint64_t RPL_FETCH_BLOCK_NUMS = 128;     // 64K
  static constexpr uint64_t RPL_SLOTS_PARALLEL = 10;        // apply threads
};

struct RplStat {
  std::atomic<speed_t> fetch_speed{0};
  std::atomic<speed_t> parse_speed{0};
  std::atomic<speed_t> apply_speed{0};
  std::atomic<uint64_t> behind_master{0};
};

class RplReloadMeta {
public:
  RplReloadMeta() {}

  RplReloadMeta(const std::string &db_name, const std::chrono::steady_clock::time_point &start_time,
                const int &delay): db_name_(db_name),
                start_time_(start_time), delay_(delay),need_reload_meta_(true) {}
  RplReloadMeta& operator=(const RplReloadMeta& other) {
    db_name_ =  other.db_name_;
    start_time_ = other.start_time_;
    delay_ =  other.delay_;
    need_reload_meta_ =other.need_reload_meta_;
    return *this;
  }

  void set_need_reload_meta(const bool need) {
    need_reload_meta_ = need;
  }

  bool get_need_reload_meta() {
    return need_reload_meta_;
  }

  const std::string &get_db_name() {
    return db_name_;
  }

  const std::chrono::steady_clock::time_point &get_start_time() {
    return start_time_;
  }

  const int &get_delay() {
    return delay_;
  }

private:
  std::string db_name_;
  std::chrono::steady_clock::time_point start_time_;
  int delay_; //delay in seconds
  bool need_reload_meta_{false};
};

class RplSys {
  RplSys() {}

 public:
  static RplSys &get_instance();

  void stop();
  bool should_stop();

  speed_t fetch_speed();
  void set_fetch_speed(speed_t fetch_speed);

  speed_t parse_speed();
  void set_parse_speed(speed_t parse_speed);

  speed_t apply_speed();
  void set_apply_speed(speed_t apply_speed);

  uint64_t behind_master();
  void set_behind_master(uint64_t behind_master);

  uint64_t lowest_lsn();
  void update_lowest_lsn();
  lsn_t init_lsn() const { return init_lsn_; }
  void set_init_lsn(lsn_t lsn) { init_lsn_ = lsn; }

  bool get_init_finished() const { return init_finished_; }
  void set_init_finished() { init_finished_ = true; }

  RplReloadMeta* get_rpl_reload_meta() { return &rpl_reload_meta_; }

 private:
  DISALLOW_COPY_AND_ASSIGN(RplSys);
  std::atomic_bool should_stop_{false};
  std::atomic_uint64_t lowest_lsn_{0};
  lsn_t init_lsn_{0};
  RplStat rpl_stat_;
  RplReloadMeta rpl_reload_meta_;
  bool init_finished_{false};
};

}  // namespace rpl
