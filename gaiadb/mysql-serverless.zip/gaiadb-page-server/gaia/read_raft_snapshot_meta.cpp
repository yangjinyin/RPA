/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/read_raft_snapshot_meta.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <raft/configuration.h>
#include <raft/protobuf_file.h>
#include <raft/local_storage.pb.h>
#include <raft/util.h>
#include <base/iobuf.h>
#include <base/sys_byteorder.h>
#include "gaia/read_raft_snapshot_meta.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

[[maybe_unused]]
static int save(const std::string& file_name, const raft::LocalSnapshotPbMeta* message) {
    std::string file = file_name + ".tmp";
    auto flags = O_CREAT | O_RDWR;
    int fd = open(file.c_str(), flags, S_IRUSR | S_IWUSR | O_TRUNC);
    if (fd < 0) {
        print_error("open file failed, %s", strerror(errno));
        return 1;
    }

    base::IOBuf header_buf;
    base::IOBuf msg_buf;
    base::IOBufAsZeroCopyOutputStream msg_wrapper(&msg_buf);
    message->SerializeToZeroCopyStream(&msg_wrapper);

    int32_t header_len = base::HostToNet32(msg_buf.length());
    header_buf.append(&header_len, sizeof(int32_t));

    if (sizeof(int32_t) != raft::file_pwrite(header_buf, fd, 0)) {
        print_error("write file failed, %s", strerror(errno));
        close(fd);
        return 1;
    }

    ssize_t len = msg_buf.size();
    if (len != raft::file_pwrite(msg_buf, fd, sizeof(int32_t))) {
        print_error("write body data failed, %s", strerror(errno));
        close(fd);
        return 1;
    }

    fsync(fd);
    close(fd);

    std::cout << "fix file to:" << file << std::endl;

    return 0;
}

int ReadRaftSnapshotMeta::Run() {
    RpcStatus status;

    if (_file.empty()) {
        print_error("miss --file");
        return 1;
    }

    auto flags = O_RDWR | O_EXCL;
    int fd = open(_file.c_str(), flags, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        print_error("open file failed, %s", strerror(errno));
        return 1;
    }
    raft::LocalSnapshotPbMeta pb_meta;

    base::IOPortal header_buf;
    ssize_t read_size = raft::file_pread(&header_buf, fd, 0, sizeof(int32_t));
    if (static_cast<size_t>(read_size) != sizeof(int32_t)) {
        print_error("read len failed, %s", strerror(errno));
        close(fd);
        return 1;
    }

    int32_t len = 0;
    header_buf.copy_to(&len, sizeof(int32_t));
    int32_t left_len = base::NetToHost32(len);

    // read protobuf data
    base::IOPortal msg_buf;
    if (left_len != raft::file_pread(&msg_buf, fd, sizeof(int32_t), left_len)) {
        print_error("read body failed, %s", strerror(errno));
        close(fd);
        return -1;
    }

    base::IOBufAsZeroCopyInputStream msg_wrapper(msg_buf);
    pb_meta.ParseFromZeroCopyStream(&msg_wrapper);

    if (pb_meta.has_meta()) {
        Table t1(_raw_with_table, 2);
        t1.AddRowsValue({"last_included_index", pb_meta.meta().last_included_index()});
        t1.AddRowsValue({"last_included_term", pb_meta.meta().last_included_term()});
        for (auto& peer : pb_meta.meta().peers()) {
            t1.AddRowsValue({"peer:", peer});
        }
        for (auto& peer : pb_meta.meta().old_peers()) {
            t1.AddRowsValue({"old_peer:", peer});
        }
        t1.Display();
    }

    Table t2(_raw_with_table);
    t2.AddRowsWithName({"file_name", "user_meta", "source", "checksum"});
    for (auto& file : pb_meta.files()) {
        t2.AddRowsValue({file.name(),
                file.has_meta() ? std::string(file.meta().user_meta()) : "",
                file.has_meta() ? static_cast<int>(file.meta().source()) : -1,
                file.has_meta() ? file.meta().checksum() : ""
                });
    }
    t2.Display();

    close(fd);

    if (_fix_path) {
        for (int i = 0; i < pb_meta.files_size(); ++i) {
            auto suff = pb_meta.files(i).name().substr(strlen("rocksdb_snapshot"));
            pb_meta.mutable_files(i)->set_name("rocksdb_snapshot/" + suff);
        }
        if (save(_file, &pb_meta)) {
            return 1;
        }
    }

    return 0;
}

}
}
