/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/repair_page_server_page.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <sys/ioctl.h>
#include <termios.h>
#include <sys/stat.h>
#include "gaia/parse_apply_rec.h"
#include "gaia/repair_page_server_page.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

bool RepairPageServerPage::GetPagePhysicalOffset(std::vector<base::EndPoint>& nodes,
        uint32_t* physical_extent_id,
        uint64_t* physical_offset) {
    RpcStatus status;
    gaiapb::GetSpaceExtentMapRequest request;
    gaiapb::GetSpaceExtentMapResponse response;

    request.set_space_id(_space_id.val);
    request.set_begin_extent_id(_page_no.val / GAIADB_EXTENT_PAGE_NUM);
    request.set_num(1);
    request.set_need_physical_extent_id(true);
    request.set_use_bytes(true);

    for (size_t i = 0; i < nodes.size(); ++i) {
        auto& node = nodes[i];
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_space_extent_map, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            LOG(NOTICE) << pb2jsonstr(response);
            if (i > 0) {
                std::swap(nodes[0], nodes[1]);
            }
            if (response.status().code() != gaiadb::GIE_OK) {
                std::cout << "get page extend failed, " << response.status() << std::endl;
                return false;
            }
            gaiapb::GetSpaceExtentMapResponse response2;
            response2.mutable_status()->CopyFrom(response.status());
            response2.set_total_extent_num(response.total_extent_num());
            if (response.has_extent_map_bytes()) {
                struct ExtentMap {
                    uint32_t segment_id;
                    uint32_t extent_id;
                };
                const ExtentMap* entry = reinterpret_cast<const ExtentMap*>(response.extent_map_bytes().c_str());
                const uint32_t count = response.extent_map_bytes().length() / sizeof(*entry);
                for (uint32_t j = 0; j < count; ++j) {
                    auto m = response2.mutable_extent_map()->add_entries();
                    m->set_segment_id(entry->segment_id);
                    m->set_physical_extent_id(entry->extent_id);
                    ++entry;
                }
            } else {
                response2.mutable_extent_map()->CopyFrom(response.extent_map());
            }

            const auto& extent_map = response2.extent_map();
            if (extent_map.entries_size() > 0) {
                const auto& m = extent_map.entries(0);
                uint32_t align_page_no = request.begin_extent_id() * GAIADB_EXTENT_PAGE_NUM;
                PSVR_ASSERT(_page_no.val >= align_page_no);
                PSVR_ASSERT(_page_no.val - align_page_no < GAIADB_EXTENT_PAGE_NUM);
                *physical_extent_id = m.physical_extent_id();
                *physical_offset = m.physical_extent_id() * GAIADB_EXTENT_SIZE
                    + (_page_no.val - align_page_no) * gaia_apply::FLAGS_univ_page_size;
                if (_segment_id.val != m.segment_id()) {
                    print_error("mismatch --segment-id, expect: %u", m.segment_id());
                    return false;
                }
                std::cout << "get extent info ok,"
                    << " space:[" << _space_id.val
                    << "] page:[" << _page_no.val
                    << "] physical_extent_id:[" << *physical_extent_id
                    << "] physical_offset:[" << *physical_offset
                    << "] segment_id:[" << m.segment_id()
                    << "]" << std::endl;
                return true;
            } else {
                std::cout << "not found page extend in psm" << std::endl;
                return false;
            }
        } else {
            LOG(WARNING) << node << " get space extend failed, " << status << " " << response.status();
        }
    }
    std::cout << "all get space extend rpc are failed" << std::endl;
    return false;
}

bool RepairPageServerPage::GetLogServiceNodes(std::vector<base::EndPoint>& nodes,
        std::vector<base::EndPoint>* ls_nodes) {
    RpcStatus status;
    gaiapb::LogServiceBatchGetRequest request;
    gaiapb::LogServiceBatchGetResponse response;

    request.set_log_id(_log_id);

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_log_service, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            if (response.status().code() != gaiadb::GIE_OK) {
                std::cout << "get log service failed, " << response.status() << std::endl;
                return false;
            }
            for (auto& ls : response.log_services()) {
                base::EndPoint ls_node;
                base::str2endpoint(ls.addr().c_str(), &ls_node);
                ls_nodes->emplace_back(ls_node);
            }
            return !ls_nodes->empty();
        } else {
            LOG(WARNING) << node << " list log service failed, " << status << " " << response.status();
        }
    }
    std::cout << "all list log service rpc are failed" << std::endl;
    return false;
}

bool RepairPageServerPage::ReadBasePage(const base::EndPoint& node,
        BufBlockPtr buf_block) {
    RpcStatus status;
    pspb::RbioRequest request;
    pspb::RbioResponse response;

    request.set_requestid(_log_id);
    request.set_cluster_id(_cluster_id);
    request.set_segment_id(_segment_id.val);
    request.set_readtype(pspb::RbioRequest_Type_READ_SYNC);
    request.set_n(1);

    auto request_info = request.add_reqvec();
    request_info->set_tablespaceid(_space_id.val);
    request_info->set_logicalpageno(_page_no.val);
    request_info->set_vlsn(_page_base_lsn);
    request_info->set_ziplen(gaia_apply::FLAGS_univ_page_size);

    _client.Call(_log_id, node, &pspb::RbioService_Stub::Rbio, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        print_error("rpc request failed. %s", status.msg.c_str());
        return false;
    }

    if (response.errcode() != pspb::RbioResponse::RBIO_SUCCESS) {
        print_error("read base page failed, %s", pspb::RbioResponse_Error_Name(response.errcode()).c_str());
        return false;
    }

    auto rsp_info = response.resvec(0);
    const gaia_apply::page_t* page =
        reinterpret_cast<const gaia_apply::page_t*>(rsp_info.pageframe().c_str());
    auto page_size = rsp_info.pageframe().size();
    if (page_size != gaia_apply::FLAGS_univ_page_size) {
        print_error("page size invalid %lu", page_size);
        return false;
    }

    memcpy(buf_block->frame, page, page_size);

    auto page_lsn = buf_block_get_page_lsn(buf_block);
    auto space_id = gaia_apply::page_get_space_id(buf_block->frame);
    auto page_no = gaia_apply::page_get_page_no(buf_block->frame);
    bool is_empty = false;
    bool is_corrupted = page_is_corrupted(buf_block->frame, gaia_apply::FLAGS_univ_page_size, &is_empty);

    std::cout << "read page info ok,  "
        << " is_corrupted:[" << is_corrupted
        << "] is_empty:[" << is_empty
        << "] space:[" << _space_id.val
        << "] data_space:[" << space_id
        << "] page:[" << _page_no.val
        << "] data_page:[" << page_no
        << "] lsn:[" << _page_base_lsn
        << "] data_lsn:[" << page_lsn
        << "]" << std::endl;
    return true;
}

bool RepairPageServerPage::FetchRecords(std::vector<base::EndPoint>& nodes,
        std::string* records_buf) {
    RpcStatus status;
    lspb::psrv_get_log_request request;
    lspb::psrv_get_log_response response;

    request.set_segment_id(_segment_id.val);
    request.set_fetch_lsn(_start_apply_lsn);

    base::EndPoint specify_node;
    if (!_ls_addr.empty()) {
        if (base::str2endpoint(_ls_addr.c_str(), &specify_node)) {
            print_error("invalid --ls-addr");
            return false;
        }
    }

    for (auto& node : nodes) {
        if (!_ls_addr.empty()) {
            if (specify_node != node) {
                continue;
            }
        }
        brpc::Controller cntl;
        cntl.set_timeout_ms(_timeout_ms);
        cntl.set_log_id(_log_id);

        _client.Call(&cntl, node, &lspb::PageServerService_Stub::get_log, &request, &response, nullptr);
        if (cntl.Failed()) {
            LOG(WARNING) << "fetch log fail, " << cntl.ErrorText().c_str();
            continue;
        }

        *records_buf = response.data_returned();
        std::cout << "get log ok,"
            << " fetch_lsn:[" << _start_apply_lsn
            << "] last_lsn:[" << response.last_lsn()
            << "] buf_size:[" << response.total_len()
            << "] from:[" << node
            << "] checksum:[" << response.data_checksum()
            << "]" << std::endl;

        _start_apply_lsn = response.last_lsn();
        return true;
    }

    std::cout << "all get log rpc are failed" << std::endl;
    return false;
}

bool RepairPageServerPage::BackupOldPage(const base::EndPoint& node,
        BufBlockPtr buf_block,
        uint64_t physical_extent_id) {
    RpcStatus status;
    pspb::ReadRequest request;
    pspb::ReadResponse response;

    uint64_t offset = physical_extent_id * GAIADB_EXTENT_SIZE
        + (_page_no.val % GAIADB_EXTENT_PAGE_NUM) * gaia_apply::FLAGS_univ_page_size;

    request.set_log_id(_log_id);
    request.set_cluster_id(_cluster_id);
    request.set_segment_id(_segment_id.val);
    request.set_offset(offset);
    request.set_size(gaia_apply::FLAGS_univ_page_size);

    _client.Call(_log_id++, node, &pspb::QueryService_Stub::Read, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        print_error("rpc request failed. %s", status.msg.c_str());
        return false;
    }

    if (response.status().code() != pspb::Status_ReturnCode_SUCCESS) {
        std::cout << "backup old page failed," << response.status() << std::endl;
        return false;
    }

    memcpy(buf_block->frame, response.data().c_str(), gaia_apply::FLAGS_univ_page_size);

    auto page_lsn = buf_block_get_page_lsn(buf_block);
    auto space_id = gaia_apply::page_get_space_id(buf_block->frame);
    auto page_no = gaia_apply::page_get_page_no(buf_block->frame);
    bool is_empty = false;
    bool is_corrupted = page_is_corrupted(buf_block->frame, gaia_apply::FLAGS_univ_page_size, &is_empty);

    std::cout << "backup page info ok,"
        << " is_corrupted:[" << is_corrupted
        << "] is_empty:[" << is_empty
        << "] space:[" << _space_id.val
        << "] data_space:[" << space_id
        << "] page:[" << _page_no.val
        << "] data_page:[" << page_no
        << "] lsn:[" << _page_base_lsn
        << "] data_lsn:[" << page_lsn
        << "]" << std::endl;

    return true;
}

bool RepairPageServerPage::WriteNewPage(const base::EndPoint& node,
        BufBlockPtr buf_block,
        uint64_t physical_extent_id) {
    RpcStatus status;
    pspb::WritePageRequest request;
    pspb::WritePageResponse response;

    request.set_request_id(_log_id);
    request.set_cluster_id(_cluster_id);
    request.set_segment_id(_segment_id.val);
    request.set_physical_extent_id(physical_extent_id);
    request.set_n(1);

    auto request_info = request.add_requestvec();
    request_info->set_space_id(_space_id.val);
    request_info->set_page_no(_page_no.val);
    request_info->set_data(reinterpret_cast<const char*>(buf_block->frame), gaia_apply::FLAGS_univ_page_size);
    request_info->set_ziplen(gaia_apply::FLAGS_univ_page_size);

    _client.Call(_log_id, node, &pspb::RbioService_Stub::WritePhysicalPages, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        print_error("rpc request failed. %s", status.msg.c_str());
        return false;
    }

    if (response.status().code() != pspb::WritePageResponse::SUCCESS) {
        print_error("write failed. %s", response.status().msg().c_str());
        return false;
    }

    std::cout << "write ok,"
        << " space:[" << _space_id.val
        << "] page_no:[" << _page_no.val
        << "] physical_extent_id:[" << physical_extent_id
        << "] write_to:[" << node
        << "]";
    return true;
}

int RepairPageServerPage::Run() {
    gaiadb::common::ut_crc32_init();
    BufPool buf_pool;

    if (_manager_address.empty()) {
        print_error("missing --manager-address");
        return 1;
    }
    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> psm_nodes;
    if (!psm_info.GetOrRefreshNodes(&psm_nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (_ps_addr.empty() || _ps_port <= 0) {
        print_error("missing --address or --port");
        return 1;
    }
    base::EndPoint ps_node;
    int ret = base::str2endpoint(_ps_addr.c_str(), _ps_port, &ps_node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    if (_cluster_id.empty()) {
        print_error("missing --cluster-id");
        return 1;
    }
    if (!_segment_id.has_val) {
        print_error("missing --segment-id");
        return 1;
    }
    if (!_space_id.has_val || !_page_no.has_val) {
        print_error("missing --space-id or --page-no");
        return 1;
    }
    if (_page_base_lsn == 0) {
        _page_base_lsn = LOG_START_LSN + gaia_apply::LOG_BLOCK_HDR_SIZE;
    }
    if (_start_apply_lsn == 0) {
        _start_apply_lsn = _page_base_lsn;
    }
    if (_start_apply_lsn < _page_base_lsn) {
        print_error("invalid --start-lsn, small --page-lsn");
        return 1;
    }

    //1) get page physical offset
    //2) get log service nodes
    //3) read base page from ps
    //4) fetch records from ls
    //5) apply rec to page
    //6) write page to ps

    BufBlockPtr buf_block = buf_pool.AllocBufBlock(gaia_apply::FLAGS_univ_page_size);
    BufBlockPtr backup_buf_block = buf_pool.AllocBufBlock(gaia_apply::FLAGS_univ_page_size);

    uint32_t physical_extent_id = kInvalidExtentId;
    uint64_t physical_offset = kInvalidOffset;
    if (_physical_offset.has_val) {
        physical_extent_id = _physical_offset.val / GAIADB_EXTENT_SIZE;
        physical_offset = _physical_offset.val;
    } else {
        ret = GetPagePhysicalOffset(psm_nodes, &physical_extent_id, &physical_offset);
        if (!ret) {
            return 1;
        }
    }

    std::vector<base::EndPoint> ls_nodes;
    if (_ls_addr.empty()) {
        ret = GetLogServiceNodes(psm_nodes, &ls_nodes);
        if (!ret) {
            return 1;
        }
    } else {
        base::EndPoint specify_node;
        if (base::str2endpoint(_ls_addr.c_str(), &specify_node)) {
            print_error("invalid --ls-addr");
            return false;
        }
        ls_nodes.push_back(specify_node);
    }

    ret = ReadBasePage(ps_node, buf_block);
    if (!ret) {
        return 1;
    }

    std::string records_buf;
    ret = FetchRecords(ls_nodes, &records_buf);
    if (!ret) {
        return 1;
    }

    const auto buf_size = records_buf.size();
    auto buf = static_cast<gaia_apply::byte*>(std::malloc(buf_size));
    if (!buf) {
        print_error("malloc buf failed, size:%zu, %s", buf_size, strerror(errno));
        return 1;
    }
    memcpy(buf, records_buf.c_str(), buf_size);
    gaia_apply::byte* start_ptr = buf;
    gaia_apply::byte* end_ptr = buf + buf_size;

    auto page_apply_lsn = buf_block_get_page_lsn(buf_block);
    uint64_t apply_records_size = 0;
    if (!parse_records(start_ptr, end_ptr,
                &page_apply_lsn, &apply_records_size,
                buf_block, &_space_id.val, &_page_no.val,
                _max_apply_num)) {
        return 1;
    }

    std::cout << "apply records ok,"
        << " apply_records_size:[" << apply_records_size
        << "] page_apply_lsn:[" << page_apply_lsn
        << "]" << std::endl;;
    if (apply_records_size == 0) {
        return 0;
    }

    if (!page_reset_checksum(buf_block->frame,  gaia_apply::FLAGS_univ_page_size,
                _space_id.val, _page_no.val, page_apply_lsn)) {
        std::cout << "reset page checksum fail,"
            << " apply_records_size:[" << apply_records_size
            << "] page_apply_lsn:[" << page_apply_lsn
            << "]" << std::endl;;
        return 1;
    }

    ret = BackupOldPage(ps_node, backup_buf_block, physical_extent_id);
    if (!ret) {
        return 1;
    }

    if (!_force) {
        if (!execute_confirm("check page data ok? next step is backup and rewrite remote page")) {
            std::cout << "quit!" << std::endl;
            return -1;
        }
    }

    std::string backup_fname = base::string_printf("page_%s_%u_%u_%u_%lu_%lu_%s_%d.bak",
            _cluster_id.c_str(), _segment_id.val, _space_id.val, _page_no.val,
            physical_offset, _page_base_lsn, _ps_addr.c_str(), _ps_port);
    int backup_fd = open(backup_fname.c_str(), O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
    if (backup_fd < 0) {
        print_error("open backup file failed, %s", strerror(errno));
        return 1;
    }

    GuardFd guard_fd(backup_fd);
    ssize_t backup_w = pwrite(backup_fd, backup_buf_block->frame,
            gaia_apply::FLAGS_univ_page_size, 0);
    if (backup_w != static_cast<ssize_t>(gaia_apply::FLAGS_univ_page_size)) {
        std::cout << "back page data fail!"
            << " backup_w:[" << backup_w
            << "]" << std::endl;
        return -1;
    }

    ret = WriteNewPage(ps_node, buf_block, physical_extent_id);
    if (!ret) {
        return 1;
    }

    return 0;
}

}
}
