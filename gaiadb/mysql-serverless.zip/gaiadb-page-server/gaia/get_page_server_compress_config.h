/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_page_server_compress_config.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class GetPageServerCompressConfig : public Command {
public:
    GetPageServerCompressConfig() {
        SetName("get-ps-compress-config");
        SetDesc("get cluster or segment compress config in page server");
        SetDescCn("获取存储服务器上集群或分片的压缩配置");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "query all segments cluster in server", kstring);
        AddRequiredArgOption("segment-id", NULL, 's', "only query this id of cluster in server", kint32_t);
        
        AddExample("-a <ip> -p <port> --cluster-id <cluster_id>\"");
        AddExample("-a <ip> -p <port> --cluster-id <cluster_id> --segment-id <segment_id>\"");
    }
    virtual ~GetPageServerCompressConfig() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtol(opt, NULL, 10));
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::GetCompressConfigResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
};

}
}
