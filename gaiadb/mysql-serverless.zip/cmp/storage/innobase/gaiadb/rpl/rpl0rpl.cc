/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file rpl/rpl0rpl.cc
 Redo log replication system

 Created 10/12/2021 Hongyu Qiao
 *******************************************************/

#include "rpl0rpl.h"
#include "os0thread-create.h"
#include "rpl0apply.h"
#include "rpl0conductor.h"
#include "rpl0fetch.h"
#include "rpl0metric.h"
#include "rpl0parse.h"
#include "rpl0schedule.h"
#include "srv0srv.h"
#include "trx0sys.h"

#ifdef ENABLED_GAIADB_PAGE_VALIDATION
#include "rpl0pv.h"
#endif

namespace rpl {

// forbidden to modify rpl_enable_delta_replay online
DEFINE_bool(rpl_enable_delta_replay, true,
            "enable rpl delta replay for secondary");

DEFINE_uint64(rpl_gc_interval_ms, 15, "rpl gc interval in ms");

DEFINE_uint64(rpl_lsn_update_interval_ms, 15, "rpl lsn update interval in ms");

DEFINE_int32(rpl_metric_window_s, 1, "rpl metric stat window size in second");

lsn_t get_ls_dispatch_lsn() { return g_rpl_conductor->ls_dispatch_lsn(); }

lsn_t get_fetch_lsn() { return g_rpl_conductor->fetch_lsn(); }

lsn_t get_parse_lsn() { return g_rpl_conductor->parse_lsn(); }

lsn_t get_apply_lsn() { return g_rpl_conductor->apply_lsn(); }

lsn_t get_read_lsn() { return g_rpl_conductor->read_lsn(); }

uint32_t rbio_get_refed_read_lsn(lsn_t &vlsn, lsn_t *refed_lsn, lsn_t *lowest_lsn) {
  ut_ad(refed_lsn);
  ut_ad(lowest_lsn);
  return g_rpl_conductor->rbio_apply_register(vlsn, refed_lsn, lowest_lsn);
}

lsn_t get_flush_lsn() { return g_rpl_conductor->flush_lsn(); }

lsn_t get_master_vdl() { return g_rpl_conductor->master_vdl(); }

lsn_t get_lowest_lsn() { return rpl_sys->lowest_lsn(); }

lsn_t get_init_lsn() { return rpl_sys->init_lsn(); }

bool get_init_finished() { return rpl_sys->get_init_finished(); }

speed_t get_fetch_speed() { return rpl_sys->fetch_speed(); }

speed_t get_parse_speed() { return rpl_sys->parse_speed(); }

speed_t get_apply_speed() { return rpl_sys->apply_speed(); }

trx_id_t get_max_trx_no() { return g_rpl_conductor->max_trx_no(); }

uint64_t get_behind_master() { return rpl_sys->behind_master(); }

static void start_background_threads();

bool rpl_sys_init() {
  LOG(TRACE) << "rpl_sys_init";
  ut_a(compute_node_info != nullptr);
  if (FLAGS_rpl_enable_delta_replay) {
    rpl_sys->update_lowest_lsn();
    g_rpl_scheduler->register_task("lowest_lsn_update",
                                   FLAGS_rpl_gc_interval_ms * 1000,
                                   update_lowest_lsn);
    g_rpl_scheduler->register_task(
        "rpl_gc", FLAGS_rpl_lsn_update_interval_ms * 1000, rpl_recycle);
  }
  g_rpl_conductor->init(compute_node_info->apply_lsn);
  rpl_sys->set_init_lsn(compute_node_info->apply_lsn);
  srv_threads.m_rpl_apply_workers =
      ut::new_arr_withkey<IB_thread>(UT_NEW_THIS_FILE_PSI_KEY, ut::Count{RplConst::RPL_SLOTS_PARALLEL});

  g_rpl_fetcher->init();
  g_rpl_parser->init();
  g_rpl_coordinator->init();

#ifdef ENABLED_GAIADB_PAGE_VALIDATION
  if (srv_fake_gaia_secondary) {
    page_validator_init();
  }
#endif /* ENABLED_GAIADB_PAGE_VALIDATION */
  return true;
}

bool rpl_sys_start() {
  LOG(TRACE) << "rpl_sys_start";
  ut_a(trx_sys != nullptr);
  trx_sys_mutex_enter();
  if (!trx_sys->rw_trx_ids.empty()) {
    g_rpl_conductor->set_max_trx_no(trx_sys->rw_trx_ids.front());
  }
  trx_sys_mutex_exit();
#ifdef ENABLED_GAIADB_PAGE_VALIDATION
  if (!srv_fake_gaia_secondary) {
    start_background_threads();
  } else {
    start_page_validator_thread();
  }
#else
  start_background_threads();
#endif
  rpl_sys->set_init_finished();
  return true;
}

void rpl_sys_deinit() {
  g_rpl_fetcher->cleanup();
  g_rpl_parser->cleanup();
  g_rpl_coordinator->cleanup();
  g_rpl_conductor->cleanup();
}

bool rpl_sys_close() {
#ifdef ENABLED_GAIADB_PAGE_VALIDATION
  if (!srv_fake_gaia_secondary) {
    stop_background_threads();
  }
#else
  stop_background_threads();
#endif
  rpl_sys_deinit();
  return true;
}

int32_t rbio_further_apply(uint32_t refed_type, uint64_t refed_index,
    buf_block_t *block, lsn_t start_lsn, lsn_t end_lsn) {
  if (!block) {
    return 0;
  }
  return g_rpl_conductor->rbio_further_apply(refed_type, refed_index,
                                             block, start_lsn, end_lsn);
}

void rbio_finish_apply(uint32_t refed_type, uint64_t refed_index) {
  g_rpl_conductor->rbio_finish_apply(refed_type, refed_index);
}

void bp_get_further_apply(buf_block_t *block) {
  g_rpl_conductor->bp_get_further_apply(block);
}

RplSys *rpl_sys = &(RplSys::get_instance());
/* init g_rpl_metric should set rpl_sys variable before */
RplMetric *g_rpl_metric = &(RplMetric::get_instance());

RplSys &RplSys::get_instance() {
  static RplSys _rpl_sys;
  return _rpl_sys;
}

speed_t RplSys::fetch_speed() { return rpl_stat_.fetch_speed.load(); }

speed_t RplSys::parse_speed() { return rpl_stat_.parse_speed.load(); }

speed_t RplSys::apply_speed() { return rpl_stat_.apply_speed.load(); }

uint64_t RplSys::behind_master() { return rpl_stat_.behind_master.load(); }

lsn_t RplSys::lowest_lsn() { return lowest_lsn_; }

void RplSys::set_fetch_speed(speed_t fetch_speed) {
  rpl_stat_.fetch_speed.store(fetch_speed);
}

uint64_t get_fetch_get_log_bw(void*) { return rpl_sys ? get_fetch_speed() : 0; }

void RplSys::set_parse_speed(speed_t parse_speed) {
  rpl_stat_.parse_speed.store(parse_speed);
}

void RplSys::set_apply_speed(speed_t apply_speed) {
  rpl_stat_.apply_speed.store(apply_speed);
}

void RplSys::set_behind_master(uint64_t behind_master) {
  rpl_stat_.behind_master.store(behind_master);
}

void RplSys::update_lowest_lsn() {
  lsn_t lowest_ps_lsn = 0;
  lsn_t ps_lowest_gc_lsn = 0;
  lsn_t rbio_lowest_gc_lsn = 0;
  auto ret = 0;
  for (int i = 0; i < 5; i++) {
    ret = psmcli->get_ps_lowest_lsn(&lowest_ps_lsn, &ps_lowest_gc_lsn, &rbio_lowest_gc_lsn);
    if (ret == 0) {
      break;
    }
    LOG(WARNING) << "update lowest lsn failed, ret=" << ret;
    std::this_thread::sleep_for(std::chrono::microseconds(500));
  }
  if (ret == 0 && lowest_ps_lsn > 0) {
    if (ps_lowest_gc_lsn > lowest_ps_lsn) {
      lowest_ps_lsn = ps_lowest_gc_lsn;
    }
    if (rbio_lowest_gc_lsn > lowest_ps_lsn) {
      lowest_ps_lsn = rbio_lowest_gc_lsn;
    }
    lsn_t old = lowest_lsn_.load();
    do {
      if (old >= lowest_ps_lsn) {
        break;
      }
      LOG(TRACE) << "lowest_lsn update to: " << lowest_ps_lsn;
    } while (!lowest_lsn_.compare_exchange_strong(old, lowest_ps_lsn));
  }
}

bool RplSys::should_stop() { return should_stop_.load(); }

void RplSys::stop() { should_stop_.store(true); }

extern void rpl_fetcher();
extern void rpl_parser();
extern void rpl_binlog_flusher();
extern void rpl_coordinator();
extern void rpl_apply_worker(uint64_t i);
extern void rpl_scheduler();

void rpl_background_threads_active_validate() {
  ut_a(srv_thread_is_active(srv_threads.m_rpl_fetcher));
  ut_a(srv_thread_is_active(srv_threads.m_rpl_shredder));
  ut_a(srv_thread_is_active(srv_threads.m_rpl_binlog_flusher));
  ut_a(srv_thread_is_active(srv_threads.m_rpl_coordinator));
  for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; i++) {
    ut_a(srv_thread_is_active(srv_threads.m_rpl_apply_workers[i]));
  }
  ut_a(srv_thread_is_active(srv_threads.m_rpl_scheduler));
}

void rpl_background_threads_inactive_validate() {
  ut_a(!srv_thread_is_active(srv_threads.m_rpl_fetcher));
  ut_a(!srv_thread_is_active(srv_threads.m_rpl_shredder));
  ut_a(!srv_thread_is_active(srv_threads.m_rpl_binlog_flusher));
  ut_a(!srv_thread_is_active(srv_threads.m_rpl_coordinator));
  for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; i++) {
    ut_a(!srv_thread_is_active(srv_threads.m_rpl_apply_workers[i]));
  }
  ut_a(!srv_thread_is_active(srv_threads.m_rpl_scheduler));
}

void start_background_threads() {
  rpl_background_threads_inactive_validate();

  srv_threads.m_rpl_fetcher =
      os_thread_create(rpl_fetcher_thread_key, 0, rpl_fetcher);
  srv_threads.m_rpl_shredder =
      os_thread_create(rpl_shredder_thread_key, 0, rpl_parser);
  srv_threads.m_rpl_binlog_flusher =
      os_thread_create(rpl_binlog_flusher_thread_key, 0, rpl_binlog_flusher);
  srv_threads.m_rpl_coordinator =
      os_thread_create(rpl_coordinator_thread_key, 0, rpl_coordinator);
  srv_threads.m_rpl_scheduler =
      os_thread_create(rpl_scheduler_thread_key, 0, rpl_scheduler);
  for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; i++) {
    srv_threads.m_rpl_apply_workers[i] =
        os_thread_create(rpl_apply_worker_thread_key, 0, rpl_apply_worker, i);
  }

  srv_threads.m_rpl_fetcher.start();
  srv_threads.m_rpl_shredder.start();
  srv_threads.m_rpl_binlog_flusher.start();
  for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; i++) {
    srv_threads.m_rpl_apply_workers[i].start();
  }
  srv_threads.m_rpl_coordinator.start();
  srv_threads.m_rpl_scheduler.start();
  rpl_background_threads_active_validate();
}

void stop_background_threads() {
  ib_info(ER_IB_GAIA_MSG_RPL)
      << "Gaia replication background threads are being closed...";
  rpl_background_threads_active_validate();
  rpl_sys->stop();
  while (srv_thread_is_active(srv_threads.m_rpl_fetcher)) {
    std::this_thread::sleep_for(std::chrono::microseconds(10));
  }
  while (srv_thread_is_active(srv_threads.m_rpl_shredder)) {
    std::this_thread::sleep_for(std::chrono::microseconds(10));
  }
  while (srv_thread_is_active(srv_threads.m_rpl_binlog_flusher)) {
    std::this_thread::sleep_for(std::chrono::microseconds(10));
  }
  while (srv_thread_is_active(srv_threads.m_rpl_coordinator)) {
    std::this_thread::sleep_for(std::chrono::microseconds(10));
  }
  while (srv_thread_is_active(srv_threads.m_rpl_scheduler)) {
    std::this_thread::sleep_for(std::chrono::microseconds(10));
  }
  for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; i++) {
    while (srv_thread_is_active(srv_threads.m_rpl_apply_workers[i])) {
      std::this_thread::sleep_for(std::chrono::microseconds(10));
    }
  }
  rpl_background_threads_inactive_validate();
  ib_info(ER_IB_GAIA_MSG_RPL)
      << "Gaia replication background threads stopped...";
}

}  // namespace rpl
