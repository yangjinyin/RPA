/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server_psminfo.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ListPageServerPsmInfo : public Command {
public:
    ListPageServerPsmInfo() {
        SetName("list-ps-psminfo");
        SetDesc("list psm address information from page server");
        SetDescCn("列出存储服务器的管理地址信息");
        
        AddNodeOption();
        AddRequiredArgOption("manager-address", NULL, 'M',
                "show psm address information that matches the address",
                kstring, kGroup2Scope);

        AddExample("-a <ip> -p <port>");
        AddExample("-a <ip> -p <port> --manager-address bns://xx");
    }
    virtual ~ListPageServerPsmInfo() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::ListPsmInfoResponse& rsp);
private:
    std::string _address {};
    int32_t _port {0};
    std::string _manager_address;
};

}
}
