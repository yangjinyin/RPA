/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/thread_pool.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <chrono>
#include <base/time.h>
#include <gaiadb/utils/thread_pool.hpp>
#include "psvr/common.h"
#include "psvr/config.h"
#include "psvr/quota.h"
#include "psvr/utils.h"

namespace psvr {
namespace thread {

using TaskContext = gaiadb::common::thread::TaskContext;

template<typename TaskType> using Timer
    = gaiadb::common::thread::Timer<TaskType>;

template<typename TaskType, typename TimerType> using Thread
    = gaiadb::common::thread::Thread<TaskType, TimerType>;

template<typename TaskType, typename TimerType = TaskType> using Executor
    = gaiadb::common::thread::Executor<TaskType, TimerType>;

} // end of ns thread

template<typename TaskType, typename TimerType = TaskType> using ThreadPoolExecutor
    = gaiadb::common::ThreadPoolExecutor<TaskType, TimerType, kMaxThreadNum>;


template<typename TaskType, typename TimerType = TaskType>
class GroupThreadPoolExecutor {
    using TimerTypePtr = std::shared_ptr<thread::Timer<TimerType>>;
    using ThreadType = thread::Thread<TaskType, TimerType>;
    using ThreadTypePtr = std::shared_ptr<thread::Thread<TaskType, TimerType>>;
    using ThreadPoolType = ThreadPoolExecutor<TaskType, TimerType>;
    using ThreadPoolTypePtr = std::shared_ptr<ThreadPoolType>;
public:
    using TaskFn = typename ThreadPoolType::TaskFn;
public:
    GroupThreadPoolExecutor() {}
    FUNC_MOCK ~GroupThreadPoolExecutor() {}

    size_t size() const { return _thread_pool_size; }

    FUNC_MOCK bool Start(size_t size, const std::string& name,
            TimerTypePtr timer, uint32_t thread_num, TaskFn& fn, bool shared = true) {
        _thread_pool_size = size;
        for (size_t i = 0; i < size; ++i) {
            _thread_pool_vec.emplace_back(std::make_shared<ThreadPoolType>());
            if (!_thread_pool_vec.back()->Start(base::string_printf("%s_%lu", name.c_str(), i),
                        timer, thread_num, shared, fn)) {
                return false;
            }
        }
        return true;
    }

    FUNC_MOCK void Stop(bool join) {
        for (auto& thread_pool : _thread_pool_vec) {
            thread_pool->Stop(join);
        }
    }

    FUNC_MOCK uint64_t GetThreadQueueSize(size_t idx, uint32_t client_id) {
        return _thread_pool_vec[idx % _thread_pool_size]->GetThreadQueueSize(client_id);
    }

    FUNC_MOCK void RecycleTask(TaskFn fn) {
        for (auto& thread_pool : _thread_pool_vec) {
            thread_pool->RecycleTask(fn);
        }
    }

    FUNC_MOCK bool Execute(size_t idx, TaskType* task) {
        return _thread_pool_vec[idx % _thread_pool_size]->Execute(task);
    }

    FUNC_MOCK bool EmergentExecute(size_t idx, TaskType* task) {
        return _thread_pool_vec[idx % _thread_pool_size]->EmergentExecute(task);
    }

    FUNC_MOCK bool Schedule(size_t idx, TimerType* task, uint64_t delay_us) {
         return _thread_pool_vec[idx % _thread_pool_size]->Schedule(task, delay_us);
    }

    FUNC_MOCK bool Cancel(size_t idx, TimerType* task) {
        return _thread_pool_vec[idx % _thread_pool_size]->Cancel(task);
    }

    FUNC_MOCK bool IncThread(size_t idx, uint32_t thread_num = 1) {
        return _thread_pool_vec[idx % _thread_pool_size]->IncThread(thread_num);
    }

    FUNC_MOCK std::vector<ThreadTypePtr> DecThread(size_t idx, uint32_t thread_num = 1) {
        return _thread_pool_vec[idx % _thread_pool_size]->DecThread(thread_num);
    }

private:
    size_t _thread_pool_size;
    std::vector<ThreadPoolTypePtr> _thread_pool_vec;
};

template<typename TaskType, typename QueueType>
struct ConditionQueue {
    using Fn = std::function<void(const TaskType&)>;

    void Push(const TaskType& task) {
        static_cast<QueueType*>(this)->Push(task);
    }
    void PopIf(Fn& fn) {
        static_cast<QueueType*>(this)->PopIf(fn);
    }
    void Clear(Fn& fn) {
        static_cast<QueueType*>(this)->Clear(fn);
    }
};

template<typename TaskType, typename QueueType>
class ConditionThread {
public:
    using Fn = typename ConditionQueue<TaskType, QueueType>::Fn;

    ConditionThread(const std::string& name,
        Fn& fn,
        const int64_t* sleep_interval_us)
        : _stopped(false),
         _name(name),
        _fn(fn),
        _queue(new QueueType()),
         _sleep_interval_us(sleep_interval_us) {
        _thread.reset(new std::thread(&ConditionThread::Run, this));
    }
    FUNC_MOCK ~ConditionThread() {
        if (!_stopped) {
            Stop(true);
        }
    }

    FUNC_MOCK void Stop(bool join) {
        _stopped = true;
        if (join && _thread && _thread->joinable()) {
            _thread->join();
        }
    }

    FUNC_MOCK void Schedule(const TaskType& task) {
        _queue->Push(task);
    }

    FUNC_MOCK void Clear() {
        if (_stopped) {
            _queue->Clear(_fn);
        }
    }

private:
    void PopWaitIf() {
        _queue->PopIf(_fn);
    }

    void Run() {
        pthread_setname_np(pthread_self(), _name.c_str());
        while (!_stopped) {
            PopWaitIf();
            std::this_thread::sleep_for(std::chrono::microseconds(*_sleep_interval_us));
        }
        Clear();
        LOG(NOTICE) << "thread " << _name << " stopped";
    }

private:
    volatile bool _stopped;
    std::string _name;
    Fn _fn;
    std::shared_ptr<std::thread> _thread;
    std::shared_ptr<QueueType> _queue;
    const int64_t* _sleep_interval_us;
};

template<typename TaskType, typename QueueType>
class GroupConditionThread {
    using ThreadType = ConditionThread<TaskType, QueueType>;
    using ThreadTypePtr = std::shared_ptr<ThreadType>;
public:
    using Fn = typename ThreadType::Fn;
public:
    GroupConditionThread() : _size(0) {}
    FUNC_MOCK ~GroupConditionThread() {}

    FUNC_MOCK bool Start(size_t size,
            const std::string& name,
            Fn& fn,
            const int64_t* sleep_interval) {
        _size = size;
        for (size_t i = 0; i < size; ++i) {
            _threads.emplace_back(std::make_shared<ThreadType>(
                        base::string_printf("%s_%lu", name.c_str(), i),
                        fn, sleep_interval));
        }
        return true;
    }

    FUNC_MOCK void Stop(bool join) {
        for (auto& t : _threads) {
            t->Stop(join);
        }
    }

    FUNC_MOCK void Schedule(size_t idx, const TaskType& task) {
        _threads[idx % _size]->Schedule(task);
    }

    FUNC_MOCK void Clear() {
        for (auto& t : _threads) {
            t->Clear();
        }
    }

private:
    size_t _size;
    std::vector<ThreadTypePtr> _threads;
};

template<typename TaskType, typename QuotaType>
class QuotaThread {
public:
    using Fn = std::function<void(TaskType)>;
    struct QuotaTask {
        QuotaType quota;
        std::list<TaskType> tasks;

        QuotaTask(QuotaType q) : quota(q) {}
        QuotaTask(QuotaTask&& qt) : quota(qt.quota), tasks(std::move(qt.tasks)) {}
    };
public:
    QuotaThread() {}
    FUNC_MOCK ~QuotaThread() {
        if (!_stopped) {
            Stop(true);
        }
    }

    FUNC_MOCK bool Start(const std::string& name, Fn fn, const int64_t* sleep_us) {
        _stopped = false;
        _name = name;
        _fn = fn;
        _sleep_interval_us = sleep_us;
        _thread.reset(new std::thread(&QuotaThread::Run, this));
        return true;
    }

    void Stop(bool join) {
        _stopped = true;
        if (join && _thread && _thread->joinable()) {
            _thread->join();
        }
    }

    FUNC_MOCK bool GetQuota(TaskType task, QuotaType quota) {
        if (_stopped || quota >= task) {
            return true;
        } else {
            std::unique_lock lk(_push_shared_mutex);
            if (auto it = _push_quota_tasks.find(quota); it != _push_quota_tasks.end()) {
                it->second.tasks.emplace_back(task);
            } else {
                auto insert_it = _push_quota_tasks.emplace(quota, std::move(QuotaTask(quota)));
                insert_it.first->second.tasks.emplace_back(task);
            }
            return false;
        }
    }

private:
    void MoveTask() {
        std::unique_lock lk(_push_shared_mutex);
        auto it = _push_quota_tasks.begin();
        while (it != _push_quota_tasks.end()) {
            if (!it->second.tasks.empty()) {
                auto fit = _quota_tasks.find(it->first);
                if (fit != _quota_tasks.end()) {
                    fit->second.tasks.splice(fit->second.tasks.end(), it->second.tasks);
                } else {
                    _quota_tasks.emplace(it->first, std::move(it->second));
                }
            }
            ++it;
        }
    }
    void Run() {
        pthread_setname_np(pthread_self(), _name.c_str());
        while (!_stopped) {
            MoveTask();
            {
                auto it = _quota_tasks.begin();
                while (it != _quota_tasks.end()) {
                    QuotaType quota = it->first;
                    while (!it->second.tasks.empty()) {
                        if (quota >= it->second.tasks.front()) {
                            _fn (it->second.tasks.front());
                            it->second.tasks.pop_front();
                            continue;
                        }
                        break;
                    }
                    ++it;
                }
            }
            std::this_thread::sleep_for(std::chrono::microseconds(*_sleep_interval_us));
        }

        MoveTask();
        auto it = _quota_tasks.begin();
        while (it != _quota_tasks.end()) {
            QuotaType quota = it->first;
            while (!it->second.tasks.empty()) {
                _fn (it->second.tasks.front());
                it->second.tasks.pop_front();
            }
            ++it;
        }

        _quota_tasks.clear();
        _push_quota_tasks.clear();
    }

private:
    volatile bool _stopped;
    std::string _name;
    Fn _fn;
    const int64_t* _sleep_interval_us;
    char pad0 BAIDU_CACHELINE_ALIGNMENT;
    std::map<QuotaType, QuotaTask> _quota_tasks;
    char pad1 BAIDU_CACHELINE_ALIGNMENT;
    std::shared_mutex _push_shared_mutex;
    std::map<QuotaType, QuotaTask> _push_quota_tasks;
    char pad2 BAIDU_CACHELINE_ALIGNMENT;
    std::shared_ptr<std::thread> _thread;
};

}
