/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_space.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ListSpace : public Command {
public:
    ListSpace() {
        SetName("list-space");
        SetDesc("list all or one space information from manager");
        SetDescCn("从管理器列出所有或指定表空间的信息");

        AddPsmClusterOption();
        AddRequiredArgOption("space-id", &_long_opt_val,
                kOptMax + 1,
                "show information if the specified space exists",
                kuint32_t, kGroup2Scope);

        AddExample("--manager-address \"bns://xxx\"");
        AddExample("--manager-address \"bns://xxx\" --space-id 1");
    }
    virtual ~ListSpace() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _specify_space_id = true;
                _space_id = std::strtoul(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::GetSpaceMetaResponse& rsp);
    int Format(const gaiapb::GetAllSpaceIdsResponse& rsp);

private:
    std::string _manager_address {};
    uint32_t _space_id {0};
    bool _specify_space_id {false};
};

}
}
