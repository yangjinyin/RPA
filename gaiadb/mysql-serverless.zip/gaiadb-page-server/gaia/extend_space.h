/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/extend_space.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ExtendSpace : public Command {
public:
    ExtendSpace() {
        SetName("extend-space");
        SetDesc("extend a space size in manager");
        SetDescCn("在管理服务中扩展表空间大小");

        AddPsmClusterOption();
        AddRequiredArgOption("space-id", &_long_opt_val, kOptMax + 1, "extend space id", kuint32_t);
        AddRequiredArgOption("begin-extent-id", &_long_opt_val, kOptMax + 2, "extend begin id", kuint32_t);
        AddRequiredArgOption("num", &_long_opt_val, kOptMax + 3, "extend number", kuint32_t);

        AddExample("--manager-address \"bns://xxx\" --space-id 1 --begin-extent-id x --num x");
    }
    virtual ~ExtendSpace() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _space_id.Set(std::strtoul(opt, NULL, 10));
                break;
            case kOptMax + 2:
                _begin_extent_id.Set(std::strtoul(opt, NULL, 10));
                break;
            case kOptMax + 3:
                _num = std::strtoul(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::ExtendSpaceResponse& rsp);

private:
    std::string _manager_address {};
    VarOptional<uint32_t> _space_id;
    VarOptional<uint32_t> _begin_extent_id;
    uint32_t _num {0};
};

}
}
