/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file tools/rw_threads_lock.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/common.h"
#include "psvr/namespace.h"
#include "psvr/thread_pool.hpp"
#include "psvr/dbengine.h"
#include "psvr/config.h"
#include <baidu/rpc/server.h>
#include <base/rand_util.h>
#include <gaiadb/utils/rw_lock.h>
#include <pthread.h>
#include <chrono>

namespace psvr {

class RWLock {
public:
    RWLock() {
        pthread_rwlockattr_init(&attr_);
        pthread_rwlockattr_setkind_np(&attr_,
                PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP);
        pthread_rwlock_init(&lock_, &attr_);
    }

    ~RWLock() {
        pthread_rwlock_destroy(&lock_);
        pthread_rwlockattr_destroy(&attr_);
    }

    void lock() {
        pthread_rwlock_wrlock(&lock_);
    }

    bool try_lock() {
        return pthread_rwlock_trywrlock(&lock_);
    }

    void lock_shared() {
        pthread_rwlock_rdlock(&lock_);
    }

    bool try_lock_shared() {
        return pthread_rwlock_tryrdlock(&lock_);
    }

    void unlock() {
        pthread_rwlock_unlock(&lock_);
    }

    void unlock_shared() {
        unlock();
    }

private:
    pthread_rwlock_t lock_;
    pthread_rwlockattr_t attr_;
};

struct Context : public thread::TaskContext {
    bool is_write;
    gaia_apply::space_id_t space_id;
    gaia_apply::page_no_t page_no;
    uint64_t physical_page_no;
    int64_t start_time;
    int32_t group_id;

    Context(bool write,
        gaia_apply::space_id_t id,
        gaia_apply::page_no_t no,
        uint64_t phy_no)
        : is_write(write),
        space_id(id),
        page_no(no),
        physical_page_no(phy_no){
        start_time = base::cpuwide_time_us();
        group_id = 0;
    }
};


static StatLatency stat_wlock_lat("wlock", kSlaWindowSize);
static StatLatency stat_rlock_lat("rlock", kSlaWindowSize);

static StatCount stat_werr_count("wlock_err", kSlaWindowSize);
static StatCount stat_rerr_count("rlock_err", kSlaWindowSize);

static bvar::Adder<int64_t> stat_write_size("wlock_queue_size");
static bvar::Adder<int64_t> stat_read_size("rlock_queue_size");

static bvar::Adder<int64_t> stat_page_lock_used_count("psvr_db_page_lock_used_count");

class RwThreadsLock {
public:
    RwThreadsLock() {}
    ~RwThreadsLock() {}

    db::PageLockPtr GetPageLock(uint64_t physical_page_no) {
        return _page_lock_manager[physical_page_no % FLAGS_psvr_segment_page_lock_slice_count]
            ->GetOrCreate(physical_page_no, physical_page_no, gaia_apply::FLAGS_univ_page_size);
    }

    void Run() {
        for (int32_t i = 0; i < FLAGS_psvr_segment_page_lock_slice_count; ++i) {
            _page_lock_manager.emplace_back(std::make_shared<db::PageLockManager>(stat_page_lock_used_count));
        }

        _timer.reset(new thread::Timer<thread::TaskContext>("shared"));
        typename thread::Timer<thread::TaskContext>::TaskFn timer_fn = std::bind(&RwThreadsLock::OnTimer,
                this, ARG::_1);
        _timer->Start(FLAGS_psvr_timer_tick_interval, timer_fn);

        typename thread::Executor<Context, thread::TaskContext>::TaskFn fn
            = std::bind(&RwThreadsLock::OnCompletion, this, ARG::_1);

        _gc_thread_pool.reset(new GroupThreadPoolExecutor<Context, thread::TaskContext>);
        if (!_gc_thread_pool->Start(4, "gc", _timer,
                    FLAGS_multi_psvr_gc_thread_num_per_group, fn, FLAGS_multi_psvr_gc_thread_enable_shared)) {
            LOG(ERROR) << "gc thread pool start failed";
            return;
        }

        _rbio_thread_pool.reset(new GroupThreadPoolExecutor<Context, thread::TaskContext>);
        if (!_rbio_thread_pool->Start(4, "rbio", _timer,
                    FLAGS_multi_psvr_rbio_thread_num_per_group, fn, FLAGS_multi_psvr_rbio_thread_enable_shared)) {
            LOG(ERROR) << "rbio thread pool start failed";
            return;
        }

        std::thread bench_t(&RwThreadsLock::BenchRun, this);
        bench_t.join();
        return;
    }

    void BenchRun() {
        _task_size.store(0);
        uint32_t i = 0;
        while (true) {
            bool is_write = base::RandInt(0, 100) < 2;
            uint32_t space_id = 1; //base::RandInt(0, 1);
            uint32_t page_no = 2; //base::RandInt(0, 20);
            uint64_t physical_page_no = 0;
            auto ctx = new Context(is_write, space_id, page_no, physical_page_no);
            ctx->group_id = page_no;

            _task_size.fetch_add(1);
            if (is_write) {
                stat_write_size << 1;
                _gc_thread_pool->Execute(ctx->group_id, ctx);
            } else {
                stat_read_size << 1;
                ctx->client_id = i;
                _rbio_thread_pool->Execute(ctx->group_id, ctx);
            }
            std::this_thread::sleep_for(std::chrono::microseconds(100));
            if (_task_size.load() > 1000) {
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            }
            ++i;
        }
    }

    bool OnTimer(thread::TaskContext* ctx) {
        OnCompletion(static_cast<Context*>(ctx));
        return true;
    }

    void OnCompletion(Context* ctx) {
        std::unique_ptr<Context> ctx_ptr(ctx);
        db::PageLockPtr page_lock = GetPageLock(ctx->physical_page_no);
        auto st = base::cpuwide_time_us();
        if (ctx->is_write) {
            LOG(NOTICE) << "write task";
            //std::unique_lock lk(_shared_mutex);
            //db::PageUniqueLock lk(page_lock);
            db::PageUniqueLock lk(page_lock, std::try_to_lock);
            if (!lk) {
                stat_werr_count << 1;
                if (base::cpuwide_time_us() - ctx->start_time < second2microseconds(3)) {
                    _gc_thread_pool->Schedule(ctx->log_id, ctx_ptr.release(), 500);
                }
                return;
            }
            stat_wlock_lat << (base::cpuwide_time_us() - st);
            stat_write_size << -1;
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        } else {
            LOG_EVERY_SECOND(NOTICE) << "read task";
            //std::shared_lock slk(_shared_mutex);
            //db::PageSharedLock lk(page_lock, std::try_to_lock);
            //if (!lk) {
                //stat_rerr_count << 1;
                //if (base::cpuwide_time_us() - ctx->start_time < second2microseconds(3)) {
                    //_rbio_thread_pool->Schedule(ctx->log_id, ctx_ptr.release(), 500);
                //}
                //return;
            //}
            db::PageSharedLock lk(page_lock);
            stat_read_size << -1;
            stat_rlock_lat << (base::cpuwide_time_us() - st);
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        _task_size.fetch_sub(1);
    }


private:
    //std::shared_mutex _shared_mutex;
    //gaiadb::common::shared_mutex _shared_mutex;
    //RWLock _shared_mutex;
    std::atomic<int32_t> _task_size;
    std::vector<std::shared_ptr<db::PageLockManager>> _page_lock_manager;
    std::shared_ptr<thread::Timer<thread::TaskContext>> _timer;
    std::shared_ptr<GroupThreadPoolExecutor<Context, thread::TaskContext>> _gc_thread_pool;
    std::shared_ptr<GroupThreadPoolExecutor<Context, thread::TaskContext>> _rbio_thread_pool;
};


}

int main() {
#if _GLIBCXX_USE_PTHREAD_RWLOCK_T
    std::cout << "define _GLIBCXX_USE_PTHREAD_RWLOCK_T: yes" << std::endl;
#endif
#if _GTHREAD_USE_MUTEX_TIMEDLOCK
    std::cout << "define _GTHREAD_USE_MUTEX_TIMEDLOCK: yes" << std::endl;
#endif

    if (psvr::FLAGS_psvr_rbio_server_port == -1) {
        psvr::FLAGS_psvr_rbio_server_port = 8999;
    }

    std::shared_ptr<baidu::rpc::Server> rpc_server(new baidu::rpc::Server());
    baidu::rpc::ServerOptions options;
    options.num_threads = 9;
    options.idle_timeout_sec = -1;
    if (rpc_server->Start(psvr::FLAGS_psvr_rbio_server_port, &options) != 0) {
        return 1;
    }

    psvr::RwThreadsLock rw_threads_lock;
    rw_threads_lock.Run();
    return 0;
}
