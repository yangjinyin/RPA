/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/open_tde.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/open_tde.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int OpenTDE::Run() {
    RpcStatus status;
    gaiapb::OpenTDERequest request;
    gaiapb::OpenTDEResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (!_version.has_val) {
        print_error("miss --version");
        return 1;
    }

    if (_encryption_key.empty()) {
        print_error("miss --encryption-key");
        return 1;
    }

    if (_encryption_iv.empty()) {
        print_error("miss --encryption-iv");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_force) {
        if (!execute_confirm("open tde with version:%u ?", _version.val)) {
            std::cout << "quit!" << std::endl;
            return -1;
        }
    }

    request.set_log_id(_log_id);
    auto info = request.mutable_info();
    info->set_version(_version.val);
    info->set_encryption_key(_encryption_key);
    info->set_encryption_iv(_encryption_iv);
    if (!_encryption_alg.empty()) {
        info->set_encryption_alg(_encryption_alg);
    }

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::open_tde, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " open tde failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("open tde failed, all nodes failed");
    return Output(response);
}

int OpenTDE::Format(const gaiapb::OpenTDEResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
