/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ListPageServer : public Command {
public:
    ListPageServer() {
        SetName("list-page-server");
        SetDesc("list all or one page servers information from manager");
        SetDescCn("从管理器列出所有或指定页面服务器的信息");

        AddPsmClusterOption();
        AddRequiredArgOption("addr", &_long_opt_val, kOptMax + 1,
                "show information if the specified node exists", kip_port, kGroup2Scope);
        AddRequiredArgOption("segment-id", NULL, 's',
                "show only matching id", kuint32_t, kGroup2Scope);

        AddExample("--manager-address \"bns://xxx\"");
        AddExample("--manager-address \"bns://xxx\" --addr 127.0.0.1:8888");
        AddExample("--manager-address \"bns://xxx\" --addr 127.0.0.1:8888 --segment-id 1");
    }
    virtual ~ListPageServer() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 's':
            _segment_id = std::strtoul(opt, NULL, 10);
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _addr = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::GetPageServerResponse& rsp);
    int Format(const gaiapb::ListPageServerResponse& rsp);
    int Format(const gaiapb::GetSegmentResponse& rsp);

private:
    std::string _manager_address {};
    std::string _addr {};
    uint32_t _segment_id {0};
};

}
}
