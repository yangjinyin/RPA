/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_gc.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/gc.h"
#include "test/mock_thread_pool.h"
#include "test/mock_dbengine.h"
#include "test/mock_dblwr.h"
#include "bmock.h"

namespace psvr {
namespace test {

class GcTests : public PsvrTest {
 public:
    GcTests() : _gc_manager(nullptr) {
        _mock_control->gc()->Stop();
    }
    virtual ~GcTests() {}

    void SetUp() {
        _gc_manager.reset(new GcManager(_mock_client, _control));
        _mock_thread_pool = new MockGroupThreadPoolExecutor<GcManager::Context, thread::TaskContext>;
        _gc_manager->_thread_pool.reset(_mock_thread_pool);
        _gc_manager->_append_thread_pool = _gc_manager->_thread_pool;
        _gc_manager->_dblwr_dump_thread_pool = _gc_manager->_thread_pool;

        _mock_condition_thread_pool = new MockGroupConditionThread<GcManager::ConditionTask, GcManager::ConditionGcQueue>;
        _gc_manager->_condition_thread_pool.reset(_mock_condition_thread_pool);

        gaia_apply::page_size_t page_size(16<<10, 16<<10, false);

        FLAGS_psvr_gc_parallel_num = 1;
        FLAGS_psvr_enable_append_file = false;

        // The mock objects created by BMOCK_NS_METHOD attach their hooks at static-init
        // time, so they would stay in effect for the whole binary. Stop them all here and
        // let each test enable only the ones it injects with BMOCK_NS_RESUME.
        BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    }

    void TearDown() {
    }

    void OnCompletion(size_t, GcManager::Context* ctx) {
        _gc_manager->OnCompletion(ctx);
    }

private:
    GcManagerPtr _gc_manager;
    MockGroupThreadPoolExecutor<GcManager::Context, thread::TaskContext>* _mock_thread_pool;
    MockGroupConditionThread<GcManager::ConditionTask, GcManager::ConditionGcQueue>* _mock_condition_thread_pool;
};

bool MockExecuteOk(size_t, GcManager::Context* ctx) {
    delete ctx;
    return true;
}

bool MockScheduleOk(size_t, thread::TaskContext* ctx, uint64_t) {
    delete ctx;
    return true;
}

bool MockCondScheduleOk(size_t, const GcManager::ConditionTask& task) {
    delete task.ctx;
    return true;
}

TEST_F(GcTests, test_GcCondition) {
    auto segment = create_segment();
    GcManager::Context ctx(GcManager::Action::kGcLogBlock, segment, create_empty_log_block(1111));
    {
        GcManager::ConditionTask task(&ctx, segment->cluster(), 1024, 1024 + 100, false, base::cpuwide_time_us());
        GcManager::ConditionTask task2(task);
        GcManager::ConditionTask task3(task);
        ASSERT_EQ(task2.min_lsn, task3.min_lsn);
        ASSERT_EQ(task2.max_lsn, task3.max_lsn);

        ASSERT_FALSE(task2);
        ASSERT_FALSE(task3);
        ASSERT_EQ(task2.retry_nr, 0);

        segment->_cluster->_cn_lowest_lsn(1024);
        ASSERT_FALSE(task2);
        ASSERT_FALSE(task3);
        ASSERT_EQ(task2.retry_nr, 0);

        segment->_cluster->_cn_lowest_lsn(1025);
        ASSERT_TRUE(task2);
        ASSERT_TRUE(task3);

        GcManager::ConditionTask task4(task);
        task4.has_data = true;
        {
            FLAGS_psvr_gc_delay_lsn_size = 10;
            ASSERT_FALSE(task4);
            FLAGS_psvr_gc_delay_lsn_size = 0;

            FLAGS_psvr_gc_delay_time_us = 100000000;
            ASSERT_FALSE(task4);
            FLAGS_psvr_gc_delay_time_us = 0;
        }
        {
            segment->_cluster->_cn_lowest_lsn(1025 + 100 + 10);
            FLAGS_psvr_gc_delay_lsn_size = 10;
            ASSERT_TRUE(task4);
            FLAGS_psvr_gc_delay_lsn_size = 0;

            FLAGS_psvr_gc_delay_time_us = 100000000;
            task4.wait_start_time = base::cpuwide_time_us() - FLAGS_psvr_gc_delay_time_us - 1;
            ASSERT_TRUE(task4);
            FLAGS_psvr_gc_delay_time_us = 0;
        }
    }
    {
        GcManager::ConditionGcQueue queue;
        GcManager::ConditionTask task(&ctx, segment->cluster(), 1024, 1024 + 100, true, base::cpuwide_time_us());
        GcManager::ConditionTask task2(&ctx, segment->cluster(), 1025, 1024 + 200, true, base::cpuwide_time_us());

        queue.Push(task);
        queue.Push(task2);

        typename ConditionThread<GcManager::ConditionTask, GcManager::ConditionGcQueue>::Fn fun1 = [](const GcManager::ConditionTask& t1) {
                    ASSERT_EQ(t1.min_lsn, 1024);
                };
        queue.PopIf(fun1);

        typename ConditionThread<GcManager::ConditionTask, GcManager::ConditionGcQueue>::Fn fun2 = [](const GcManager::ConditionTask& t1) {
                    ASSERT_EQ(t1.min_lsn, 1025);
                };
        queue.Clear(fun2);
    }
}

TEST_F(GcTests, test_GcCondition2) {
    FLAGS_psvr_enable_append_file = true;

    auto segment = create_segment();
    GcManager::Context ctx(GcManager::Action::kGcLogBlock, segment, create_empty_log_block(1111));
    FLAGS_psvr_gc_delay_append_lsn_size = 0;
    FLAGS_psvr_gc_delay_append_data_size = 0;
    FLAGS_psvr_gc_delay_append_time_us = 0;
    {
        FLAGS_psvr_gc_delay_append_lsn_size = 1000;
        GcManager::ConditionTask task(&ctx, segment->cluster(), 1024, 1024 + 100, false, base::cpuwide_time_us());
        ASSERT_FALSE(task);

        segment->cluster()->set_cn_lowest_lsn(task.max_lsn + FLAGS_psvr_gc_delay_append_lsn_size);
        ASSERT_TRUE(task);
        FLAGS_psvr_gc_delay_append_lsn_size = 0;
    } END_OF_CASE;
    {
        FLAGS_psvr_gc_delay_append_data_size = 1000;
        GcManager::ConditionTask task(&ctx, segment->cluster(), 1024, 1024 + 100, false, base::cpuwide_time_us());
        ASSERT_FALSE(task);

        segment->_append_un_gc_size.store(FLAGS_psvr_gc_delay_append_data_size);
        ASSERT_TRUE(task);
        FLAGS_psvr_gc_delay_append_data_size = 0;
    } END_OF_CASE;
    {
        FLAGS_psvr_gc_delay_append_time_us = 100000;
        GcManager::ConditionTask task(&ctx, segment->cluster(), 1024, 1024 + 100, false, base::cpuwide_time_us());
        ASSERT_FALSE(task);

        sleep_for(FLAGS_psvr_gc_delay_append_time_us + 100);
        segment->_append_un_gc_size.store(FLAGS_psvr_gc_delay_append_time_us);
        ASSERT_TRUE(task);
        FLAGS_psvr_gc_delay_append_time_us = 0;
    } END_OF_CASE;
}

TEST_F(GcTests, test_Start_Stop) {
    {
        // fail
        EXPECT_CALL(*_mock_condition_thread_pool, Start(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _, _mock_control->timer(), _, _, _)).WillOnce(Return(false));
        ASSERT_FALSE(_gc_manager->Start(1));
    }

    {
        // fail: append thread pool start failed
        EXPECT_CALL(*_mock_condition_thread_pool, Start(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _, _mock_control->timer(), _, _, _))
            .WillOnce(Return(true))
            .WillOnce(Return(false));
        ASSERT_FALSE(_gc_manager->Start(1));
    } END_OF_CASE;
    {
        // fail: dblwr dump thread pool start failed
        EXPECT_CALL(*_mock_condition_thread_pool, Start(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _, _mock_control->timer(), _, _, _))
            .WillOnce(Return(true))
            .WillOnce(Return(true))
            .WillOnce(Return(false));
        ASSERT_FALSE(_gc_manager->Start(1));
    } END_OF_CASE;
    {
        // ok
        EXPECT_CALL(*_mock_condition_thread_pool, Start(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, Start(_, _, _mock_control->timer(), _, _, _))
            .WillOnce(Return(true))
            .WillOnce(Return(true))
            .WillOnce(Return(true));
        ASSERT_TRUE(_gc_manager->Start(1));
    } END_OF_CASE;
    {
        // fail
        _gc_manager->_control.reset();
        ASSERT_FALSE(_gc_manager->Start(1));
    } END_OF_CASE;
    {
        // stop
        _gc_manager->Stop();
    }
}

TEST_F(GcTests, test_IncOrDecThreadNum) {
    _gc_manager->_thread_num = FLAGS_multi_psvr_gc_thread_num_per_group;
    _mock_thread_pool->_thread_pool_size = 1;
    {
        _gc_manager->_stopped = false;
        EXPECT_CALL(*_mock_thread_pool, IncThread(_, _))
            .Times(3)
            .WillRepeatedly(Return(true));
        _gc_manager->IncOrDecThreadNum();
    }
    {
        // inc
        FLAGS_multi_psvr_gc_thread_num_per_group += 1;
        _gc_manager->IncOrDecThreadNum();
    }
    {
        // dec
        std::vector<MockExecutor<GcManager::Context, thread::TaskContext>::ThreadType> vec;
        FLAGS_multi_psvr_gc_thread_num_per_group -= 1;
        EXPECT_CALL(*_mock_thread_pool, DecThread(_, _)).WillOnce(Return(vec));
        _gc_manager->IncOrDecThreadNum();
    }
    _gc_manager->_stopped = true;
}


TEST_F(GcTests, test_Dispatch) {
    _gc_manager->_stopped = false;
    {
        auto segment = create_mock_segment();
        auto lb = create_empty_log_block(1024, false);
        segment->_parse_log_block_queue.SetlastLsn(lb->start_lsn);
        EXPECT_CALL(*segment, AppendRecoverParseFinish()).WillOnce(Return(true));
        segment->AddParseLogBlock(lb);
        segment->SetClusterCnLowestLsn(1204 + 10000);
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _gc_manager->Dispatch(segment TRACE_FILE_LINE_CC, 0);
        // again
        _gc_manager->Dispatch(segment TRACE_FILE_LINE_CC, 1024);
    }
}

TEST_F(GcTests, test_ConditionFn) {
    GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, create_segment(), create_log_block());
    GcManager::ConditionTask task(ctx, nullptr, 0, 100, false, base::cpuwide_time_us());
    EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Invoke(MockExecuteOk));
    _gc_manager->ConditionFn(task);
}

BMOCK_NS_METHOD1(gaiadb::common, terminate, void(int));
TEST_F(GcTests, test_Schedule) {
    {
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, create_segment(), nullptr);
        _gc_manager->Schedule(ctx TRACE_FILE_LINE_CC, 10, false);
    }

    _gc_manager->_stopped = false;
    {
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, create_segment(), nullptr);
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _gc_manager->Schedule(ctx TRACE_FILE_LINE_CC, 0, true);
    }
    {
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, create_segment(), nullptr);
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->Schedule(ctx TRACE_FILE_LINE_CC, 10, true);
    }
    {
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, create_segment(), nullptr);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _gc_manager->Execute(ctx);
    }
    {
        _gc_manager->_stopped = true;
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, create_segment(), nullptr);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Return(false));
        ASSERT_FALSE(_gc_manager->Execute(ctx));
    }
    {
        _gc_manager->_stopped = false;
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, create_segment(), nullptr);
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Return(false));
        BMOCK_NS_RESUME(gaiadb::common, terminate, void(int));
        EXPECT_CALL(BMOCK_NS_OBJECT(gaiadb::common, terminate), terminate(_)).WillOnce(Return());
        ASSERT_FALSE(_gc_manager->Execute(ctx));
        BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
    }
}

TEST_F(GcTests, test_OnCompletion) {
    {
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, create_mock_segment());
        _gc_manager->OnCompletion(ctx);
    }
    {
        auto segment = create_mock_segment();
        segment->_status = Segment::Status::kDelete;
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        _gc_manager->OnCompletion(ctx);
    }
    {
        _gc_manager->_stopped = true;
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kRecoverPage, segment);
        _gc_manager->OnCompletion(ctx);
    }
}

TEST_F(GcTests, test_GcLogBlock) {
    {
        // stoped
        auto log_block = create_log_block(1024, true);
        auto segment = create_mock_segment();
        _gc_manager->PreGcLogBlock(segment, log_block);
    } END_OF_CASE;
    _gc_manager->_stopped = false;
    {
        // invalid lb
        auto log_block = create_log_block(1024, false);
        auto segment = create_mock_segment();
        _gc_manager->PreGcLogBlock(segment, log_block);
    } END_OF_CASE;
    {
        // AddGetSpaceExtentEvent in advance
        auto log_block = create_log_block(1024, true, 1);
        auto segment = create_mock_segment_by_cluster("test_ok", 1);
        segment->_cluster->_cn_lowest_lsn(10000);
        EXPECT_CALL(*segment.get(), ExistSpacePagePhysicalOffset(_, _)).WillOnce(Return(false));
        auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, gaia_apply::page_no_t, ggpb::Closure* closure, pspb::Status* status) {
            if (status) {
                status->set_code(pspb::Status::INVALID);
            }
            closure->Run();
        };
        EXPECT_CALL(*_mock_parser, AddGetSpaceExtentEvent(_ TRACE_MOCK_ARG_CC, _, _, _, _))
            .WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _gc_manager->PreGcLogBlock(segment, log_block);
    } END_OF_CASE;
    {
        // AddGetSpaceExtentEvent in advance
        auto log_block = create_log_block(1024, true, 1);
        auto segment = create_mock_segment_by_cluster("test_ok2", 1);
        segment->_cluster->_cn_lowest_lsn(100);
        EXPECT_CALL(*segment.get(), ExistSpacePagePhysicalOffset(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockCondScheduleOk));
        _gc_manager->PreGcLogBlock(segment, log_block);
    } END_OF_CASE;

    {
        auto log_block = create_log_block(1024, true, 1);
        auto segment = create_mock_segment_by_cluster("test_ok2", 1);
        segment->_cluster->_cn_lowest_lsn(100);
        auto ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment, log_block);
        ctx->get_meta_reqs_count = 2;
        EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockCondScheduleOk));
        _gc_manager->OnPreEvent(ctx);
        _gc_manager->OnPreEvent(ctx);
    } END_OF_CASE;

    {
        // log_block->start_lsn >= cn_lowest_lsn
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->parallel_task->latency_us();
        ctx->log_block = create_empty_log_block(1024, 1025, true);
        segment->_cluster->_cn_lowest_lsn(1023);
        segment->_parse_lsn(2048);
        EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockCondScheduleOk));
        _gc_manager->OnCompletion(ctx);
        ASSERT_EQ(segment->gc_lsn(), 0);
    } END_OF_CASE;

    {
        // empty
        auto segment = create_mock_segment();
        segment->append_log_block_queue().Plug();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_empty_log_block(1000, 1024, true);
        segment->_cluster->_cn_lowest_lsn(1023);
        segment->_parse_lsn(2048);
        //EXPECT_CALL(*segment.get(), GcDelayForRecovery(_)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockCondScheduleOk));
        _gc_manager->OnCompletion(ctx);
        ASSERT_EQ(segment->gc_lsn(), 1023);
    } END_OF_CASE;

    {
        // empty
        auto segment = create_mock_segment();
        segment->append_log_block_queue().Plug();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_empty_log_block(1000, 1024, true);
        segment->_cluster->_cn_lowest_lsn(1024);
        segment->_parse_lsn(2048);
        EXPECT_CALL(*segment.get(), UpdateAppendDBCheckPoint(_, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*segment.get(), GcDelayForRecovery(_)).WillOnce(Return(false));
        _gc_manager->OnCompletion(ctx);
        ASSERT_EQ(segment->gc_lsn(), 1024);
    } END_OF_CASE;

    {
        // empty
        auto segment = create_mock_segment();
        segment->append_log_block_queue().Plug();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_empty_log_block(1000, 1024, true);
        segment->_cluster->_cn_lowest_lsn(1024);
        segment->_parse_lsn(2048);
        EXPECT_CALL(*segment.get(), UpdateAppendDBCheckPoint(_, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*segment.get(), GcDelayForRecovery(_)).WillOnce(Return(true));
        FLAGS_psvr_gc_delay_for_recovery_us = 0;
        _gc_manager->OnCompletion(ctx);
        ASSERT_EQ(segment->gc_lsn(), 1024);
    } END_OF_CASE;

    {
        // empty
        auto segment = create_mock_segment();
        segment->append_log_block_queue().Plug();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_empty_log_block(1000, 1024, true);
        segment->_cluster->_cn_lowest_lsn(1024);
        segment->_parse_lsn(2048);
        EXPECT_CALL(*segment.get(), UpdateAppendDBCheckPoint(_, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*segment.get(), GcDelayForRecovery(_)).WillOnce(Return(true));
        FLAGS_psvr_gc_delay_for_recovery_us = 10;
        FLAGS_psvr_gc_delay_max_times_for_recovery = 10;
        ctx->delay_times = 10;
        //EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockCondScheduleOk));
        _gc_manager->OnCompletion(ctx);
        ASSERT_EQ(segment->gc_lsn(), 1024);
    } END_OF_CASE;

    {
        // empty
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_empty_log_block(1000, 1024, true);
        segment->_cluster->_cn_lowest_lsn(1024);
        segment->_parse_lsn(2048);
        EXPECT_CALL(*segment.get(), GcDelayForRecovery(_)).WillOnce(Return(true));
        ctx->delay_times = 9;
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->OnCompletion(ctx);
        ASSERT_EQ(segment->gc_lsn(), 1024);
    } END_OF_CASE;

    {
        // empty & ok
        auto segment = create_mock_segment();
        segment->append_log_block_queue().Plug();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_empty_log_block(1000, 1024, true);
        segment->_cluster->_cn_lowest_lsn(1024);
        segment->_parse_lsn(2048);
        FLAGS_psvr_gc_long_query_time_us = 1;
        EXPECT_CALL(*segment.get(), UpdateAppendDBCheckPoint(_, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*segment.get(), GcDelayForRecovery(_)).WillOnce(Return(false));
        _gc_manager->OnCompletion(ctx);
        ASSERT_EQ(segment->gc_lsn(), 1024);
    } END_OF_CASE;

    {
        // empty & next
        auto segment = create_mock_segment();
        segment->append_log_block_queue().Plug();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_empty_log_block(1000, 1024, true);
        segment->_cluster->_cn_lowest_lsn(1026);
        segment->_parse_lsn(2048);
        EXPECT_CALL(*segment.get(), UpdateAppendDBCheckPoint(_, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*segment.get(), GcDelayForRecovery(_)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));

        segment->append_log_block_queue().Plug();
        segment->append_log_block_queue().SetlastLsn(1025);
        segment->append_log_block_queue().PushBack(create_empty_log_block(1025, 1028, true));

        _gc_manager->OnCompletion(ctx);
        ASSERT_EQ(segment->gc_lsn(), 1024);
    } END_OF_CASE;

    {
        // non-empty & cn_lowest_lsn <= incomplete_lift_start_lsn
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_log_block(1024, 1024 + 100, true, 1);

        segment->_cluster->_cn_lowest_lsn(ctx->log_block->chunks[0]->incomplete_lift_start_lsn);
        segment->_parse_lsn(100000);
        segment->_gc_lsn(1);

        EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockCondScheduleOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // non-empty & GetSpacePagePhysicalOffset failed
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_log_block(1024, 1024 + 100, true, 1);

        segment->_cluster->_cn_lowest_lsn(1024 + 10 + 12);
        segment->_parse_lsn(100000);
        segment->_gc_lsn(1);

        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(false));

        auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, gaia_apply::page_no_t, ggpb::Closure* closure, pspb::Status* status) {
            status->set_code(pspb::Status::INVALID);
            closure->Run();
        };
        EXPECT_CALL(*_mock_parser, AddGetSpaceExtentEvent(_ TRACE_MOCK_ARG_CC, _, _, _, _))
            .Times(2).WillRepeatedly(Invoke(fun1));

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _))
            .WillRepeatedly(Invoke(MockScheduleOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // non-empty & offset_cache_lock lock failed
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_log_block(1024, 1024 + 100, true, 1);
        int32_t lock_v = 0;
        ctx->log_block->offset_cache_lock.compare_exchange_strong(lock_v, 1);
        ctx->log_block->append_info.fold_size = 1;

        segment->_cluster->_cn_lowest_lsn(1024 + 10 + 12);
        segment->_parse_lsn(100000);
        segment->_gc_lsn(1);

        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(false));

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // non-empty & write failed
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_log_block(1024, 1024 + 100, true, 1);

        segment->_cluster->_cn_lowest_lsn(1024 + 10 + 12);
        segment->_parse_lsn(100000);
        segment->_gc_lsn(1);

        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*segment, WritePageData(_, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kStatusError, "mock err")));

        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // non-empty & write failed
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_log_block(1024, 1024 + 100, true, 1);

        segment->_cluster->_cn_lowest_lsn(1024 + 10 + 12);
        segment->_parse_lsn(100000);
        segment->_gc_lsn(1);

        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*segment, WritePageData(_, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kCorrupted, "mock err")));

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // non-empty & write failed & ingore space
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_log_block(1024, 1024 + 100, true, 1);

        segment->_cluster->_cn_lowest_lsn(1024 + 200);
        segment->_parse_lsn(100000);
        segment->_gc_lsn(1);

        segment->append_log_block_queue().Plug();

        //EXPECT_CALL(*segment.get(), GetSpaceStatus(_)).WillOnce(Return(kSpaceStatusWork));
        EXPECT_CALL(*segment.get(), UpdateAppendDBCheckPoint(_, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*segment.get(), GcDelayForRecovery(_)).WillOnce(Return(false));
        //EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(true));
        //EXPECT_CALL(*segment, WritePageData(_, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kApplyError, "mock err")));

        segment->cluster()->_ignore_corrupt_info->AddSpace(0);
        _gc_manager->OnCompletion(ctx);
        segment->cluster()->_ignore_corrupt_info->RemoveSpace(0);
    } END_OF_CASE;

    {
        // non-empty & write ok
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_log_block(1024, 1024 + 100, true, 1);
        ctx->log_block->drop_space_lsn_map[12] = 1028;

        segment->_cluster->_cn_lowest_lsn(1024 + 200);
        segment->_parse_lsn(100000);
        segment->_gc_lsn(1);

        segment->append_log_block_queue().Plug();

        EXPECT_CALL(*segment.get(), UpdateAppendDBCheckPoint(_, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*segment.get(), GcDelayForRecovery(_)).WillOnce(Return(false));
        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*segment, WritePageData(_, _, _, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kAhead, "mock ok")));

        _gc_manager->OnCompletion(ctx);
        ASSERT_EQ(segment->_gc_lsn(), 1024 + 100);
    } END_OF_CASE;

    {
        // non-empty & write ok
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_log_block(1024, 1024 + 100, true, 1);
        ctx->log_block->drop_space_lsn_map[12] = 1028;

        segment->_cluster->_cn_lowest_lsn(1024 + 200);
        segment->_parse_lsn(100000);
        segment->_gc_lsn(1);

        segment->append_log_block_queue().Plug();

        EXPECT_CALL(*segment.get(), UpdateAppendDBCheckPoint(_, _)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*segment.get(), GcDelayForRecovery(_)).WillOnce(Return(false));
        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*segment, WritePageData(_, _, _, _, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kRetry, "mock retry")))
            .WillOnce(Return(db::Status(db::Code::kMissData, "mock missdata")));

        _gc_manager->OnCompletion(ctx);
        ASSERT_EQ(segment->_gc_lsn(), 1024 + 100);
    } END_OF_CASE;

    {
        // non-empty & write ok2
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_log_block(1024, 1024 + 100, true, 2);
        ctx->log_block->drop_space_lsn_map[12] = 1028;
        ctx->log_block->drop_space_lsn_map[13] = 1024 + 55;

        segment->_cluster->_cn_lowest_lsn(1024 + 52);
        segment->_parse_lsn(100000);
        segment->_gc_lsn(1);

        segment->append_log_block_queue().Plug();

        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _))
            .WillOnce(Return(true))
            .WillOnce(Return(true));
        EXPECT_CALL(*segment, WritePageData(_, _, _, _, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kOk, "mock ok")))
            .WillOnce(Return(db::Status(db::Code::kOk, "mock ok")));

        EXPECT_CALL(*_mock_condition_thread_pool, Schedule(_, _)).WillOnce(Invoke(MockCondScheduleOk));

        FLAGS_psvr_logblock_long_query_time_us = 0;
        _gc_manager->OnCompletion(ctx);
        ASSERT_EQ(segment->_gc_lsn(), 1024 + 52);
    } END_OF_CASE;
}

BMOCK_NS_METHOD3(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));

void set_buf_block(BufBlockPtr buf_block, gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no, const gaia_apply::page_size_t& page_size, gaia_apply::lsn_t lsn = 1024) {
    init_buf_block(buf_block, space_id, page_no, page_size);
    gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, space_id);
    gaia_apply::mach_write_to_4(buf_block->frame + gaia_apply::FIL_PAGE_OFFSET, page_no);
    page_set_page_lsn(buf_block->frame, page_size.physical(), lsn);
}

TEST_F(GcTests, test_RecoverPage) {
    _gc_manager->_stopped = false;
    {
        // get peer fail
        auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, ggpb::Closure* closure, pspb::Status* status) {
            brpc::ClosureGuard closure_guard(closure);
            status->set_code(pspb::Status::INVALID);
        };
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kRecoverPage, segment);
        ctx->log_block = create_log_block(1024 + 100, true, 1);
        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(Return(false));
        EXPECT_CALL(*_mock_parser, AddGetPeerEvent(_ TRACE_MOCK_ARG_CC, _, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // get peer fail2 & GetOrAllocBufBlock fail
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kRecoverPage, segment, create_empty_log_block(1024));
        ctx->log_block = create_log_block(1024 + 100, true, 1);
        ctx->page_physical_offset = 0;

        std::vector<gaiadb::common::PeerZone> peers;
        FillServers(&peers, 2);
        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(DoAll(SetArgPointee<0>(peers), Return(false)));
        EXPECT_CALL(*_mock_parser, AddGetPeerEvent(_ TRACE_MOCK_ARG_CC, _, _)).WillOnce(Return());

        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(nullptr));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // get peer ok & GetOrAllocBufBlock fail
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kRecoverPage, segment, create_empty_log_block(1024));
        ctx->log_block = create_log_block(1024 + 100, true, 1);
        ctx->page_physical_offset = 0;

        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(nullptr));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;
    {
        // rbio fail
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kRecoverPage, segment, create_empty_log_block(1024));
        ctx->log_block = create_log_block(1024 + 100, true, 1);
        ctx->page_physical_offset = 0;

        auto fun1 = [](ReadPeerPageContext* ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
        };

        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _)).WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment.get(), ReadPeerPage(_, _)).WillOnce(Invoke(fun1));
        auto fun2 = [this](size_t, thread::TaskContext* ctx, uint64_t) {
            _gc_manager->OnCompletion(static_cast<GcManager::Context*>(ctx));
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(fun2))  // OnRecoverPage
            .WillOnce(Invoke(MockScheduleOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // GetOrAllocBufBlock fail
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kRecoverPage, segment, create_empty_log_block(1024));
        ctx->log_block = create_log_block(1024 + 100, true, 1);
        ctx->page_physical_offset = 0;

        auto fun1 = [](ReadPeerPageContext* ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
            ctx->response.success = true;
        };

        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(_buf_block))
            .WillOnce(Return(nullptr));
        EXPECT_CALL(*segment.get(), ReadPeerPage(_, _)).WillOnce(Invoke(fun1));

        auto fun2 = [this](size_t, GcManager::Context* ctx) {
            _gc_manager->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Invoke(fun2));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // ReadPhysicalPageData fail
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kRecoverPage, segment, create_empty_log_block(1024));
        ctx->log_block = create_log_block(1024 + 100, true, 1);
        ctx->page_physical_offset = 0;

        auto fun1 = [](ReadPeerPageContext* ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
            ctx->response.success = true;
        };

        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(_buf_block))
            .WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment.get(), ReadPeerPage(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kBusy, "mock")));

        auto fun2 = [this](size_t, GcManager::Context* ctx) {
            _gc_manager->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Invoke(fun2));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // ReadPhysicalPageData kCorrupted: falls through to recover from peer
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kRecoverPage, segment, create_empty_log_block(1024));
        ctx->log_block = create_log_block(1024 + 100, true, 1);
        ctx->page_physical_offset = 0;

        auto fun1 = [](ReadPeerPageContext* ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
            ctx->response.success = true;
        };

        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(_buf_block))
            .WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment.get(), ReadPeerPage(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kCorrupted, "mock")));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _))
            .WillOnce(Return(db::Status(db::Code::kBusy, "mock")));

        auto fun2 = [this](size_t, GcManager::Context* ctx) {
            _gc_manager->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Invoke(fun2));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // page_is_corrupted true
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kRecoverPage, segment, create_empty_log_block(1024));
        ctx->log_block = create_log_block(1024 + 100, true, 1);
        ctx->page_physical_offset = 0;

        auto fun1 = [](ReadPeerPageContext* ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
            ctx->response.success = true;
        };

        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(_buf_block))
            .WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment.get(), ReadPeerPage(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk, "mock")));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(Return(true));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kBusy, "mock")));

        auto fun2 = [this](size_t, GcManager::Context* ctx) {
            _gc_manager->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Invoke(fun2));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // empty & WritePhysicalPageData ok
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kRecoverPage, segment, create_empty_log_block(1024));
        ctx->log_block = create_log_block(1024 + 100, true, 1);
        ctx->page_physical_offset = 0;

        auto fun1 = [](ReadPeerPageContext* ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
            ctx->response.success = true;
        };

        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(_buf_block))
            .WillOnce(Return(_buf_block));
        EXPECT_CALL(*segment.get(), ReadPeerPage(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk, "mock")));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(true), Return(false)));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk, "mock")));

        auto fun2 = [this](size_t, GcManager::Context* ctx) {
            _gc_manager->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Invoke(fun2))
            .WillOnce(Invoke(MockExecuteOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // check_page_space & WritePhysicalPageData ok
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kRecoverPage, segment, create_empty_log_block(1024));
        ctx->log_block = create_log_block(1024 + 100, true, 1);
        ctx->space_id = 1;
        ctx->page_physical_offset = 0;

        auto fun1 = [](ReadPeerPageContext* ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
            ctx->response.success = true;
        };

        auto buf_block2 = _mock_bufpool->RealAllocBufBlock(16<<10, nullptr);
        set_buf_block(buf_block2, 1 + 1, 1, gaia_page_size(), 9999);

        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(_buf_block))
            .WillOnce(Return(buf_block2));
        EXPECT_CALL(*segment.get(), ReadPeerPage(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk, "mock")));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));
        EXPECT_CALL(*segment, WritePhysicalPageData(_, _, _, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk, "mock")));

        auto fun2 = [this](size_t, GcManager::Context* ctx) {
            _gc_manager->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Invoke(fun2))
            .WillOnce(Invoke(MockExecuteOk));
        _gc_manager->OnCompletion(ctx);
    } END_OF_CASE;

    {
        // already recover it
        auto segment = create_mock_segment();
        GcManager::Context* ctx = new GcManager::Context(GcManager::Action::kRecoverPage, segment, create_empty_log_block(1024));
        ctx->log_block = create_log_block(1024 + 100, true, 1);
        ctx->space_id = 1;
        ctx->page_no = 1;
        ctx->page_physical_offset = 0;

        auto fun1 = [](ReadPeerPageContext* ctx, ggpb::Closure* closure) {
            brpc::ClosureGuard closure_guard(closure);
            ctx->response.success = true;
        };

        auto buf_block2 = _mock_bufpool->RealAllocBufBlock(16<<10, nullptr);
        set_buf_block(_buf_block, 1, ctx->page_no, gaia_page_size(), 9998);
        set_buf_block(buf_block2, 1, ctx->page_no, gaia_page_size(), 9999);

        EXPECT_CALL(*segment.get(), GetPeerNodes(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_bufpool, AllocBufBlock(_, _))
            .WillOnce(Return(_buf_block))
            .WillOnce(Return(buf_block2));
        EXPECT_CALL(*segment.get(), ReadPeerPage(_, _)).WillOnce(Invoke(fun1));
        EXPECT_CALL(*segment, ReadPhysicalPageData(_, _, _, _)).WillOnce(Return(db::Status(db::Code::kOk, "mock")));
        BMOCK_NS_RESUME(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
        EXPECT_CALL(BMOCK_NS_OBJECT(psvr, page_is_corrupted), page_is_corrupted(_, _, _)).WillOnce(DoAll(SetArgPointee<2>(false), Return(false)));

        auto fun2 = [this](size_t, GcManager::Context* ctx) {
            _gc_manager->OnCompletion(ctx);
            return true;
        };
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Invoke(fun2))
            .WillOnce(Invoke(MockExecuteOk));
        _gc_manager->OnCompletion(ctx);
        BMOCK_NS_STOP(psvr, page_is_corrupted, bool(gaia_apply::byte*, gaia_apply::uint, bool*));
    } END_OF_CASE;
}

TEST_F(GcTests, test_DoAppendFileGc) {
    _gc_manager->_stopped = false;
    {
        auto segment = create_segment();
        auto log_block = create_log_block();
        ASSERT_EQ(log_block->fold_space_page_lsn_map.size(), 0);

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _gc_manager->DoAppendFileGc(segment, log_block);
        ASSERT_TRUE(log_block->fold_space_page_offset_cache.buf() == nullptr);
    } END_OF_CASE;
    { auto segment = create_segment();
        auto log_block = create_log_block(1000, 2000, true, 10, false);
        log_block->from_append_file = true;
        ASSERT_GT(log_block->fold_space_page_lsn_map.size(), 0);

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _gc_manager->DoAppendFileGc(segment, log_block);
        ASSERT_TRUE(log_block->fold_space_page_offset_cache.buf() == nullptr);
    } END_OF_CASE;
    {
        auto segment = create_segment();
        auto log_block = create_log_block(1000, 2000, true, 10, false);
        ASSERT_GT(log_block->fold_space_page_lsn_map.size(), 0);

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _gc_manager->DoAppendFileGc(segment, log_block);
        ASSERT_TRUE(log_block->fold_space_page_offset_cache.buf() != nullptr);
    } END_OF_CASE;
}

TEST_F(GcTests, test_PreAppendFileGc) {
    _gc_manager->_stopped = false;
    FLAGS_psvr_enable_append_file = true;
    {
        auto segment = create_mock_segment();
        auto log_block = create_log_block(1000, 2000, true, 10, false);
        auto ctx = new GcManager::Context(GcManager::Action::kPreAppendFileGc, segment, log_block);
        ctx->merge_head = log_block;
        size_t fold_size = log_block->fold_space_page_lsn_map.size();
        size_t align_fold_size = 0;
        for (auto& it : log_block->fold_space_page_lsn_map) {
            const auto& fold = it.first;
            if (log_block->fold_space_align_pages.emplace(fold_space_page_align(fold)).second) {
                ++align_fold_size;
            }
        }
        ASSERT_GT(align_fold_size, 0);
        log_block->fold_space_page_offset_cache.Init(align_fold_size);

        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _)).Times(align_fold_size)
            .WillRepeatedly(DoAll(SetArgPointee<2>(0), Return(true)));
        EXPECT_CALL(*segment, AppendLog(_)).WillOnce(Return(db::Status(db::Code::kIOError)));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));

        _gc_manager->PreAppendFileGc(ctx);
    } END_OF_CASE;

    {
        auto segment = create_mock_segment();
        auto log_block = create_log_block(1000, 2000, true, 10, false);
        auto ctx = new GcManager::Context(GcManager::Action::kPreAppendFileGc, segment, log_block);
        ctx->merge_head = log_block;
        size_t fold_size = log_block->fold_space_page_lsn_map.size();
        size_t align_fold_size = 0;
        for (auto& it : log_block->fold_space_page_lsn_map) {
            const auto& fold = it.first;
            if (log_block->fold_space_align_pages.emplace(fold_space_page_align(fold)).second) {
                ++align_fold_size;
            }
        }
        ASSERT_GT(align_fold_size, 3);
        log_block->fold_space_page_offset_cache.Init(align_fold_size);

        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _))
            .WillOnce(Return(false))
            .WillOnce(Return(false))
            .WillRepeatedly(DoAll(SetArgPointee<2>(0), Return(true)));

        auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, gaia_apply::page_no_t, ggpb::Closure* closure, pspb::Status* status) {
            if (status) {
                status->set_code(pspb::Status::INVALID);
            }
            closure->Run();
        };
        EXPECT_CALL(*_mock_parser, AddGetSpaceExtentEvent(_ TRACE_MOCK_ARG_CC, _, _, _, _))
            .WillOnce(Invoke(fun1))
            .WillOnce(Invoke(fun1));

        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));

        _gc_manager->PreAppendFileGc(ctx);
    } END_OF_CASE;

    FLAGS_psvr_enable_encrypt = true;
    _cluster->set_enable_encypt();
    {
        auto segment = create_mock_segment();
        auto log_block = create_log_block(1000, 2000, true, 10, false);
        auto ctx = new GcManager::Context(GcManager::Action::kPreAppendFileGc, segment, log_block);
        ctx->merge_head = log_block;
        size_t fold_size = log_block->fold_space_page_lsn_map.size();
        size_t align_fold_size = 0;
        for (auto& it : log_block->fold_space_page_lsn_map) {
            const auto& fold = it.first;
            if (log_block->fold_space_align_pages.emplace(fold_space_page_align(fold)).second) {
                ++align_fold_size;
            }
        }
        ASSERT_GT(align_fold_size, 0);
        log_block->fold_space_page_offset_cache.Init(align_fold_size);

        EXPECT_CALL(*segment, GetSpacePagePhysicalOffset(_, _, _, _))
                .Times(align_fold_size)
            .WillRepeatedly(DoAll(SetArgPointee<2>(0), Return(true)));
        EXPECT_CALL(*segment, GetSpaceEncryptStatus(_))
            .Times(align_fold_size)
            .WillOnce(Return(kSpaceEncryptStatusUnknown))
            .WillRepeatedly(Return(kSpaceEncryptStatusWithPSM));
        auto fun1 = [](SegmentPtr TRACE_FILE_LINE_DTC, gaia_apply::space_id_t, ggpb::Closure* closure, pspb::Status* status) {
            if (status) {
                status->set_code(pspb::Status::SUCCESS);
            }
            if (closure) {
                closure->Run();
            }
        };
        EXPECT_CALL(*_mock_parser, AddGetSpaceMetaEvent(_ TRACE_MOCK_ARG_CC, _, _, _)).WillOnce(Invoke(fun1));
        // EXPECT_CALL(*segment, AppendLog(_)).WillOnce(Return(db::Status(db::Code::kIOError)));
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));

        _gc_manager->PreAppendFileGc(ctx);
    } END_OF_CASE;

}




TEST_F(GcTests, test_GcLogBlock_dblwr) {
    _gc_manager->_stopped = false;
    {
        // dblwr disabled, DblwrHasBufs true, DumpDblwrBuf fails → retry with backoff
        FLAGS_psvr_dblwr_max_page_num = 0;
        auto segment = create_mock_segment();
        auto ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_empty_log_block(1000, 1024, true);
        segment->_cluster->_cn_lowest_lsn(1024);
        segment->_parse_lsn(2048);
        EXPECT_CALL(*segment, DblwrHasBufs()).WillOnce(Return(true));
        EXPECT_CALL(*segment, DumpDblwrBuf(_))
            .WillOnce(Return(db::Status(db::Code::kIOError)));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->GcLogBlock(ctx);
    } END_OF_CASE;
    {
        // dblwr disabled, DblwrHasBufs true, DumpDblwrBuf ok but still has bufs → immediate reschedule
        FLAGS_psvr_dblwr_max_page_num = 0;
        auto segment = create_mock_segment();
        auto ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_empty_log_block(1000, 1024, true);
        segment->_cluster->_cn_lowest_lsn(1024);
        segment->_parse_lsn(2048);
        EXPECT_CALL(*segment, DblwrHasBufs())
            .WillOnce(Return(true))
            .WillOnce(Return(true));
        EXPECT_CALL(*segment, DumpDblwrBuf(_)).WillOnce(Return(db::Status()));
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _gc_manager->GcLogBlock(ctx);
    } END_OF_CASE;
}

TEST_F(GcTests, test_GcLogBlock_dblwr_bufs_limit) {
    _gc_manager->_stopped = false;
    {
        // dblwr enabled, append enabled, bufs_size >= limit → throttle with backoff
        FLAGS_psvr_dblwr_max_page_num = 128;
        FLAGS_psvr_enable_append_file = true;
        FLAGS_psvr_dblwr_buf_file_limit_per_segment = 2;
        auto segment = create_mock_segment();
        auto mock_dblwr = new MockDblwr();
        mock_dblwr->_bufs_size.store(2);  // bufs_size == limit triggers throttle
        segment->_dblwr.reset(mock_dblwr);
        auto ctx = new GcManager::Context(GcManager::Action::kGcLogBlock, segment);
        ctx->parallel_task = std::make_shared<ParallelTask>();
        ctx->log_block = create_empty_log_block(1000, 1024, true);
        segment->_cluster->_cn_lowest_lsn(1024);
        segment->_parse_lsn(2048);
        // FLAGS_psvr_dblwr_max_page_num > 0, so dblwr-disabled check is skipped
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->GcLogBlock(ctx);
    } END_OF_CASE;
}

TEST_F(GcTests, test_DumpDblwrBuf) {
    _gc_manager->_stopped = false;
    {
        // DumpDblwrBuf creates kDblwrDump context and dispatches to dblwr_dump_thread_pool
        auto segment = create_mock_segment();
        EXPECT_CALL(*_mock_thread_pool, Execute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _gc_manager->DumpDblwrBuf(segment);
    } END_OF_CASE;
}

TEST_F(GcTests, test_DblwrDump) {
    _gc_manager->_stopped = false;
    {
        // DblwrDump calls segment->DumpDblwrBuf up to psvr_dblwr_dump_max_num_per_round times,
        // then reschedules with delay when bufs_size < do_next_n
        FLAGS_psvr_dblwr_dump_max_num_per_round = 2;
        auto segment = create_mock_segment();
        auto mock_dblwr = new MockDblwr();
        mock_dblwr->_bufs_size.store(0);
        segment->_dblwr.reset(mock_dblwr);
        auto ctx = new GcManager::Context(GcManager::Action::kDblwrDump, segment);
        EXPECT_CALL(*segment, DumpDblwrBuf(_))
            .Times(2)
            .WillRepeatedly(Return(db::Status()));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->DblwrDump(ctx);
    } END_OF_CASE;
    {
        // DblwrDump reschedules with backoff on DumpDblwrBuf failure
        FLAGS_psvr_dblwr_dump_max_num_per_round = 3;
        auto segment = create_mock_segment();
        auto ctx = new GcManager::Context(GcManager::Action::kDblwrDump, segment);
        EXPECT_CALL(*segment, DumpDblwrBuf(_))
            .WillOnce(Return(db::Status(db::Code::kIOError)));
        EXPECT_CALL(*_mock_thread_pool, Schedule(_, _, _)).WillOnce(Invoke(MockScheduleOk));
        _gc_manager->DblwrDump(ctx);
    } END_OF_CASE;
}

TEST_F(GcTests, test_WakeupDblwr) {
    _gc_manager->_stopped = false;
    {
        // no dblwr ctx: WakeupDblwr does nothing
        auto segment = create_segment();
        _gc_manager->WakeupDblwr(segment);
    } END_OF_CASE;
    {
        // already woken up: second call returns early without cancelling
        auto segment = create_segment();
        _gc_manager->WakeupDblwr(segment);  // first: wakeup_dblwr() returns 0, dblwr_ctx is null
        _gc_manager->WakeupDblwr(segment);  // second: wakeup_dblwr() returns 1, returns early
    } END_OF_CASE;
    {
        // has ctx, cancel fails: ctx not re-executed
        auto segment = create_segment();
        auto ctx = new GcManager::Context(GcManager::Action::kDblwrDump, segment);
        segment->set_dblwr_ctx(ctx);
        EXPECT_CALL(*_mock_thread_pool, Cancel(_, _)).WillOnce(Return(false));
        _gc_manager->WakeupDblwr(segment);
    } END_OF_CASE;
    {
        // has ctx, cancel succeeds: Execute(ctx) called
        auto segment = create_segment();
        auto ctx = new GcManager::Context(GcManager::Action::kDblwrDump, segment);
        segment->set_dblwr_ctx(ctx);
        EXPECT_CALL(*_mock_thread_pool, Cancel(_, _)).WillOnce(Return(true));
        EXPECT_CALL(*_mock_thread_pool, EmergentExecute(_, _)).WillOnce(Invoke(MockExecuteOk));
        _gc_manager->WakeupDblwr(segment);
        // second wakeup: already woken up, returns early
        _gc_manager->WakeupDblwr(segment);
    } END_OF_CASE;
}

}
}
