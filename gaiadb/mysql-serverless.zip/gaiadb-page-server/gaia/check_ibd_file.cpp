/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file tools/src/check_ibd_file.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <sys/ioctl.h>
#include <termios.h>
#include <sys/stat.h>
# define __SYSMACROS_DEPRECATED_INCLUSION
#include <sys/sysmacros.h>
#include <time.h>
#include <gaiadb/utils/ut.h>
#include "psvr/common.h"
#include "psvr/config.h"
#include "psvr/log.h"
#include "psvr/compress_utils.h"
#include "psvr/page_op.h"
#include "gaia/check_ibd_file.h"
#include <gaiadb/utils/mb_alloc.h>
#include <zlib.h>
#include <rapidjson/document.h>
#include <rapidjson/error/en.h>
#include <rapidjson/filewritestream.h>
#include <rapidjson/istreamwrapper.h>
#include <rapidjson/ostreamwrapper.h>
#include <rapidjson/prettywriter.h>

namespace psvr {
namespace gaia {

constexpr uint32_t PAGE_SIZE (16*1024);
#define MAX_RETRY_TIMES 3

gaia_apply::byte* alloc_buf(uint32_t len) {
    static gaiadb::common::MemArena mb_arena(4096);
    auto buf = static_cast<gaia_apply::byte*>(mb_arena.Alloc(len + 1));
    buf[len] = '\0';
    return buf;
}

gaia_apply::byte* get_buf(gaia_apply::byte* frame, uint32_t off, uint32_t len, gaia_apply::byte* buf = nullptr) {
    if (!buf) {
        buf = alloc_buf(len);
    }
    memcpy(buf, frame + off, len);
    return buf;
}

gaia_apply::byte* zip_uncompress(Table &table, gaia_apply::byte *src, uint32_t src_len, uint32_t dst_len) {
    gaia_apply::byte* dst = alloc_buf(dst_len);
    uLongf dst_len1 = dst_len;
    int ret = uncompress(dst, &dst_len1, src, src_len);
    if (ret != Z_OK) {
        table.AddRowsValue({"ERROR", "zip uncompress error", ret});
        return nullptr;
    }
    return dst;
}

uint32_t do_show_page_header(Table &table, gaia_apply::byte* frame, uint32_t space_id, uint32_t page_no) {
    table.AddRowsValue({"--Page header"});
    table.AddRowsValue({"FIL_PAGE_SPACE_OR_CHKSUM",      gaia_apply::mach_read_from_4(frame), "checksum field 1"});
    table.AddRowsValue({"FIL_PAGE_OFFSET",               gaia_apply::mach_read_from_4(frame + 4), "page no"});
    if (page_no == 0) {
        table.AddRowsValue({"FIL_PAGE_SRV_VERSION",      gaia_apply::mach_read_from_4(frame + 4 + 4), "server version"});
        table.AddRowsValue({"FIL_PAGE_SPACE_VERSION",    gaia_apply::mach_read_from_4(frame + 4 + 4 + 4), "table space version"});
    } else {
        table.AddRowsValue({"FIL_PAGE_PREV",             gaia_apply::mach_read_from_4(frame + 4 + 4), "prev page no"});
        table.AddRowsValue({"FIL_PAGE_NEXT",             gaia_apply::mach_read_from_4(frame + 4 + 4 + 4), "next page no"});
    }
    table.AddRowsValue({"FIL_PAGE_LSN",                  gaia_apply::mach_read_from_8(frame + 4 + 4 + 4 + 4), "page lsn"});
    uint32_t page_type =                                 gaia_apply::mach_read_from_2(frame + 4 + 4 + 4 + 4 + 8);
    table.AddRowsValue({"FIL_PAGE_TYPE",                 page_type, "page type"});
    if (space_id == 0 && page_no == 0) {
        table.AddRowsValue({"FIL_PAGE_FILE_FLUSH_LSN",   gaia_apply::mach_read_from_8(frame + 4 + 4 + 4 + 4 + 8 + 2), "flush lsn"});
    } else if (page_type == gaia_apply::FIL_PAGE_COMPRESSED) {
        table.AddRowsValue({"FIL_PAGE_VERSION",          gaia_apply::mach_read_from_1(frame + 4 + 4 + 4 + 4 + 8 + 2), "compress version"});
        table.AddRowsValue({"FIL_PAGE_ALGORITHM_V1",     gaia_apply::mach_read_from_1(frame + 4 + 4 + 4 + 4 + 8 + 2 + 1), "compress algorithm"});
        table.AddRowsValue({"FIL_PAGE_ORIGINAL_SIZE_V1", gaia_apply::mach_read_from_2(frame + 4 + 4 + 4 + 4 + 8 + 2 + 1 + 1), "original size"});
        table.AddRowsValue({"FIL_PAGE_COMPRESS_SIZE_V1", gaia_apply::mach_read_from_2(frame + 4 + 4 + 4 + 4 + 8 + 2 + 1 + 1 + 2), "compress size"});
    }
    table.AddRowsValue({"FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID",
                                                         gaia_apply::mach_read_from_4(frame + 4 + 4 + 4 + 4 + 8 + 2 + 8), "space id"});
    return page_type;
}

void do_show_page_trailer(Table &table, gaia_apply::byte* frame) {
    table.AddRowsValue({"--Page trailer"});
    table.AddRowsValue({"FIL_PAGE_OLD_CHKSUM",  gaia_apply::mach_read_from_4(frame + PAGE_SIZE - 8), "checksum field 2"});
    table.AddRowsValue({"FIL_PAGE_END_LSN_4B",  gaia_apply::mach_read_from_4(frame + PAGE_SIZE - 4), "lowest 4B page lsn"});
}

void do_show_node(Table &table, const std::string& lable, gaia_apply::byte* frame, uint32_t off, const std::string &pre_msg) {
    table.AddRowsValue({lable, gaia_apply::mach_read_from_4(frame + off),  pre_msg + " list prev page no"});
    table.AddRowsValue({lable, gaia_apply::mach_read_from_2(frame + off + 4),  pre_msg + " list prev page offset"});
    table.AddRowsValue({lable, gaia_apply::mach_read_from_4(frame + off + 6),  pre_msg + " list next page no"});
    table.AddRowsValue({lable, gaia_apply::mach_read_from_2(frame + off + 10),  pre_msg + " list next page offset"});
}

void do_show_base_node(Table &table, const std::string& lable, gaia_apply::byte* frame, uint32_t off, const std::string &pre_msg) {
    table.AddRowsValue({lable, gaia_apply::mach_read_from_4(frame + off),  pre_msg + " list size"});
    table.AddRowsValue({lable, gaia_apply::mach_read_from_4(frame + off + 4),  pre_msg + " list first page no"});
    table.AddRowsValue({lable, gaia_apply::mach_read_from_2(frame + off + 6),  pre_msg + " list first page offset"});
    table.AddRowsValue({lable, gaia_apply::mach_read_from_4(frame + off + 10),  pre_msg + " list last page no"});
    table.AddRowsValue({lable, gaia_apply::mach_read_from_2(frame + off + 14),  pre_msg + " list last page offset"});
}

void do_show_addr(Table &table, const std::string& lable, gaia_apply::byte* frame, uint32_t off, const std::string &pre_msg) {
    table.AddRowsValue({lable, gaia_apply::mach_read_from_4(frame + off),  pre_msg + " addr space id"});
    table.AddRowsValue({lable, gaia_apply::mach_read_from_4(frame + off + 4),  pre_msg + " addr page no"});
    table.AddRowsValue({lable, gaia_apply::mach_read_from_2(frame + off + 8),  pre_msg + " addr page offset"});
}

// total 10240 byte
void do_show_xdes_entrys(Table &table, gaia_apply::byte* frame, uint32_t off) {
    for (uint32_t i = 0; i < 256; ++i) {
        std::string lable = base::string_printf("XDES_%u", i);
        table.AddRowsValue({lable, gaia_apply::mach_read_from_8(frame + off + i * 40), "belong to segment id"});
        do_show_node(table, lable, frame, off + 8 + i * 40, "xdes extent");
        auto state = gaia_apply::mach_read_from_4(frame + off + 8 + 12 + i * 40);
        table.AddRowsValue({lable, state, "state, 0:NOT_INITED, 1:FREE, 2:FREE_FRAG, 3:FULL_FRAG, 4:FSEG, 5:FSEG_FRAG"});
        if (state == 0) {
            continue;
        }
        std::string tmp;
        for (uint32_t j = 0; j < 64; ++j) {
            uint32_t index = 2 * j;
            uint32_t b = gaia_apply::mach_read_from_1(frame + off + 8 + 12 + 4 + (index/8) + i * 40);
            uint32_t free = (1 & (b >> (index % 8)));
            uint32_t clean = (1 & (b >> ((index + 1) % 8)));
            tmp.append(base::string_printf("%d|%d, ", free, clean));
            if (j && (j + 1) % 8 == 0) {
                if (j == 7) {
                    table.AddRowsValue({lable, tmp, "64 pages status, free|clean"});
                } else {
                    table.AddRowsValue({"", tmp, ""});
                }
                tmp.clear();
            }
        }
    }
}

uint32_t fsp_flags_get(uint32_t flags, uint32_t n, uint32_t shift) {
    return ((flags & ((~(~0U << n)) << shift)) >> shift);
}

void do_show_page_0(Table &table, gaia_apply::byte* frame) {
    table.AddRowsValue({"--File space header"});
    table.AddRowsValue({"FSP_SPACE_ID",         gaia_apply::mach_read_from_4(frame + 38), "space id"});
    table.AddRowsValue({"FSP_NOT_USED",         gaia_apply::mach_read_from_4(frame + 38 + 4), "not used"});
    table.AddRowsValue({"FSP_SIZE",             gaia_apply::mach_read_from_4(frame + 38 + 4 + 4), "space size, page number"});
    table.AddRowsValue({"FSP_FREE_LIMIT",       gaia_apply::mach_read_from_4(frame + 38 + 4 + 4 + 4), "lowest free page no"});
    uint32_t space_flags =                      gaia_apply::mach_read_from_4(frame + 38 + 4 + 4 + 4 + 4);
    table.AddRowsValue({"FSP_SPACE_FLAGS",      space_flags, "space flags"});
    table.AddRowsValue({"",      fsp_flags_get(space_flags, 1, 0), "support Antelope format"});
    table.AddRowsValue({"",      fsp_flags_get(space_flags, 4, 1), "zip page size"});
    table.AddRowsValue({"",      fsp_flags_get(space_flags, 1, 5), "atomic blobs"});
    table.AddRowsValue({"",      fsp_flags_get(space_flags, 4, 6), "page size"});
    table.AddRowsValue({"",      fsp_flags_get(space_flags, 1, 10), "file per table"});
    table.AddRowsValue({"",      fsp_flags_get(space_flags, 1, 11), "shared space"});
    table.AddRowsValue({"",      fsp_flags_get(space_flags, 1, 12), "temp space"});
    table.AddRowsValue({"",      fsp_flags_get(space_flags, 1, 13), "encrypt space"});
    table.AddRowsValue({"",      fsp_flags_get(space_flags, 1, 14), "store sdi"});

    table.AddRowsValue({"FSP_FRAG_N_USED",      gaia_apply::mach_read_from_4(frame + 38 + 4 + 4 + 4 + 4 + 4), "free frag list used page number"});

    do_show_base_node(table, "FSP_FREE", frame, 38 + 24, "free extent");
    do_show_base_node(table, "FSP_FREE_FRAG", frame, 38 + 24 + 16, "free frag extent");
    do_show_base_node(table, "FSP_FULL_FRAG", frame, 38 + 24 + 16 + 16, "full frag extent");

    table.AddRowsValue({"FSP_SEG_ID",           gaia_apply::mach_read_from_8(frame + 38 + 72), "next alloc segment id"});

    do_show_base_node(table, "FSP_SEG_INODES_FULL", frame, 38 + 72 + 8, "full index node");
    do_show_base_node(table, "FSP_SEG_INODES_FREE", frame, 38 + 72 + 8 + 16, "free index node");

    do_show_xdes_entrys(table, frame, 38 + 112);

    // fsp_header_get_encryption_offset
    table.AddRowsValue({"--Encryption info"});
    table.AddRowsValue({"MAGIC_SIZE",      get_buf(frame, 38 + 112 + 10240, 3), "magic num: lCC"});
    table.AddRowsValue({"MASTER_KEY",      gaia_apply::mach_read_from_4(frame + 38 + 128 + 10240 + 3), "master key"});
    table.AddRowsValue({"SERVER_UUID",     get_buf(frame, 38 + 112 + 10240 + 3 + 4, 36), "server uuid"});
    table.AddRowsValue({"KEY",             get_buf(frame, 38 + 112 + 10240 + 3 + 4 + 36, 32), "key"});
    table.AddRowsValue({"IV",              get_buf(frame, 38 + 112 + 10240 + 3 + 4 + 36 + 32, 32), "iv"});
    table.AddRowsValue({"CHECKSUM",        gaia_apply::mach_read_from_4(frame + 38 + 112 + 10240 + 3 + 4 + 36 + 32 + 32), "key + iv checksum"});
    table.AddRowsValue({"-",               gaia_apply::mach_read_from_4(frame + 38 + 112 + 10240 + 3 + 4 + 36 + 32 + 32 + 4), "unused"});

    table.AddRowsValue({"--SDI info"});
    table.AddRowsValue({"SDI_VERSION",     gaia_apply::mach_read_from_4(frame + 38 + 112 + 10240 + 115), "version"});
    table.AddRowsValue({"SDI_PAGE",        gaia_apply::mach_read_from_4(frame + 38 + 112 + 10240 + 115 + 4), "sdi data store page no"});

    table.AddRowsValue({"--Encryption progress"});
    table.AddRowsValue({"OPERATION_INFO",  gaia_apply::mach_read_from_1(frame + 38 + 112 + 10240 + 115 + 8), "operation, 1: ENCRYPT_IN_PROGRESS, 2: DECRYPT_IN_PROGRESS, 0: NONE"});
    table.AddRowsValue({"PROGRESS_INFO",   gaia_apply::mach_read_from_4(frame + 38 + 112 + 10240 + 115 + 8 + 1), "from page"});
}

void do_show_page_ibuf_bitmap(Table &table, gaia_apply::byte* frame, uint32_t page_no) {
    table.AddRowsValue({"--Ibuf bitmap"});
    page_no /= 16384;
    std::string tmp;
    for (uint32_t i = 0; i < 16384; ++i) {
        uint32_t index = (i * 4);
        uint32_t b = gaia_apply::mach_read_from_1(frame + 38 + index / 8);

        uint32_t free = (b >> (index % 8)) & 0b11;
        uint32_t buffed = (b >> ((index + 2) % 8)) & 0b1;
        uint32_t ibuf = (b >> ((index + 3) % 8)) & 0b1;

        tmp.append(base::string_printf("%u|%u|%u, ", ibuf, buffed, free));

        if (i && (i + 1) % 8 == 0) {
            std::string lable = base::string_printf("page: %u-%u", page_no + i - 7, page_no + i);
            table.AddRowsValue({lable, tmp, "ibuf page | has data | free size"});
            tmp.clear();
        }
    }
}

void do_show_fseg_header(Table &table, const std::string& lable, gaia_apply::byte* frame, uint32_t off, bool ignore_empty = true) {
    // FSEG_ID
    uint64_t segment_id = gaia_apply::mach_read_from_8(frame + off);
    if (segment_id == 0 && ignore_empty) {
        return;
    }
    table.AddRowsValue({lable, segment_id, "segment id"});
    // FSEG_NOT_FULL_N_USED
    table.AddRowsValue({lable, gaia_apply::mach_read_from_4(frame + off + 8), "fseg not full list used page num"});
    // FSEG_FREE
    do_show_base_node(table, lable, frame, off + 8 + 4, "fseg free");
    // FSEG_NOT_FULL
    do_show_base_node(table, lable, frame, off + 8 + 4 + 16 , "fseg not full");
    // FSEG_FULL
    do_show_base_node(table, lable, frame, off + 8 + 4 + 16 + 16, "fseg full");
    // FSEG_MAGIC_N
    table.AddRowsValue({lable, gaia_apply::mach_read_from_4(frame + off + 8 + 4 + 48), "magic num"});
    // FSEG_FRAG_ARR
    std::string tmp;
    for (uint32_t j = 0; j < 32; ++j) {
        uint32_t page = gaia_apply::mach_read_from_4(frame + off + 8 + 4 + 48 + 4 + j * 4);
        tmp.append(base::string_printf("%u, ", page));
        if (j && (j + 1) % 4 == 0) {
            if (j == 3) {
                table.AddRowsValue({lable, tmp, "32 pages frag array slots"});
            } else {
                table.AddRowsValue({"", tmp, ""});
            }
            tmp.clear();
        }
    }
}

void do_show_page_inode(Table &table, gaia_apply::byte* frame) {
    table.AddRowsValue({"--index node"});
    do_show_node(table, "FLST_NODE_SIZE", frame, 38, "inode");

    for (uint32_t i = 0; i < 85; ++i) {
        std::string lable = base::string_printf("FSeg_INODE_%u", i);
        do_show_fseg_header(table, lable, frame, 50 + i * 192);
    }
}

void do_show_page_ibuf_inode(Table &table, gaia_apply::byte* frame) {
    table.AddRowsValue({"--ibuf index node"});
    do_show_node(table, "FLST_NODE_SIZE", frame, 38, "inode");

    for (uint32_t i = 0; i < 85; ++i) {
        std::string lable = base::string_printf("FSeg_INODE_%u", i);
        do_show_fseg_header(table, lable, frame, 50 + i * 192);
    }
}

void do_show_page_xdes(Table &table, gaia_apply::byte* frame) {
    table.AddRowsValue({"--xdes"});
    do_show_xdes_entrys(table, frame, 38);
}

void do_show_page_trx(Table &table, gaia_apply::byte* frame) {
    table.AddRowsValue({"--Trx sys"});
    table.AddRowsValue({"TRX_SYS_TRX_ID_STORE", gaia_apply::mach_read_from_8(frame + 38), "max trx id"});
    do_show_addr(table, "TRX_SYS_FSEG_HEADER", frame, 38 + 8, "inode");
    for (uint32_t i = 0; i < 128; ++i) {
        std::string lable = base::string_printf("TRX_SYS_RSEGS_%u", i);
        uint32_t space_id = gaia_apply::mach_read_from_4(frame + 38 + 8 + 10 + i * 8);
        uint32_t page_no =  gaia_apply::mach_read_from_4(frame + 38 + 8 + 10 + 4 + i * 8);
        std::string value = base::string_printf("%u | %u", space_id, page_no);
        table.AddRowsValue({lable, value, "rseg addr, space | page"});
    }
    table.AddRowsValue({"TRX_SYS_MYSQL_LOG_MAGIC_N_FLD", gaia_apply::mach_read_from_4(frame + 16384 - 1000), "binlog magic numer: 873422344"});
    table.AddRowsValue({"TRX_SYS_MYSQL_LOG_OFFSET_HIGH", gaia_apply::mach_read_from_4(frame + 16384 - 1000 + 4), "binlog pos hight 4 byte"});
    table.AddRowsValue({"TRX_SYS_MYSQL_LOG_OFFSET_LOW",  gaia_apply::mach_read_from_4(frame + 16384 - 1000 + 4 + 4), "binlog pos lower 4 byte"});
    table.AddRowsValue({"TRX_SYS_MYSQL_LOG_NAME",        get_buf(frame, 16384 - 1000 + 4 + 4 + 4, 512), "binlog file name"});
    table.AddRowsValue({"TRX_SYS_TRX_NUM_GTID",          gaia_apply::mach_read_from_8(frame + 16384 - 1000 + 4 + 4 + 512), "gtid"});

    do_show_addr(table, "TRX_SYS_FSEG_HEADER", frame, 16384 - 200, "double write inode");

    table.AddRowsValue({"TRX_SYS_DOUBLEWRITE_MAGIC",  gaia_apply::mach_read_from_4(frame + 16384 - 200 + 10), "double write magic numer: 536853855"});
    table.AddRowsValue({"TRX_SYS_DOUBLEWRITE_BLOCK1", gaia_apply::mach_read_from_4(frame + 16384 - 200 + 10 + 4), "double write block 1 first page"});
    table.AddRowsValue({"TRX_SYS_DOUBLEWRITE_BLOCK2", gaia_apply::mach_read_from_4(frame + 16384 - 200 + 10 + 4 + 4), "double write block 2 first page"});

    table.AddRowsValue({"REPEAT_TRX_SYS_DOUBLEWRITE_MAGIC",  gaia_apply::mach_read_from_4(frame + 16384 - 200 + 10 + 4 + 4 + 4), "double write magic numer: 536853855"});
    table.AddRowsValue({"REPEAT_TRX_SYS_DOUBLEWRITE_BLOCK1", gaia_apply::mach_read_from_4(frame + 16384 - 200 + 10 + 4 + 4 + 4 + 4), "double write block 1 first page"});
    table.AddRowsValue({"REPEAT_TRX_SYS_DOUBLEWRITE_BLOCK2", gaia_apply::mach_read_from_4(frame + 16384 - 200 + 10 + 4 + 4 + 4 + 4 + 4), "double write block 2 first page"});

    table.AddRowsValue({"TRX_SYS_DOUBLEWRITE_SPACE_ID_STORED", gaia_apply::mach_read_from_4(frame + 16384 - 200 + 10 + 4 + 4 + 4 + 4 + 4 + 4), "double write invalid if not 1783657386"});
}

void do_show_page_dict(Table &table, gaia_apply::byte* frame) {
    table.AddRowsValue({"--Dict header"});
    table.AddRowsValue({"DICT_HDR_ROW_ID",          gaia_apply::mach_read_from_8(frame + 38), "max row id for invisible primary key"});
    table.AddRowsValue({"DICT_HDR_TABLE_ID",        gaia_apply::mach_read_from_8(frame + 38 + 8), "max table id"});
    table.AddRowsValue({"DICT_HDR_INDEX_ID",        gaia_apply::mach_read_from_8(frame + 38 + 8 + 8), "max index id"});
    table.AddRowsValue({"DICT_HDR_MAX_SPACE_ID",    gaia_apply::mach_read_from_4(frame + 38 + 8 + 8+ 8), "max space id"});
    table.AddRowsValue({"DICT_HDR_MIX_ID_LOW",      gaia_apply::mach_read_from_4(frame + 38 + 8 + 8+ 8 + 4), "discard"});
    table.AddRowsValue({"DICT_HDR_TABLES",          gaia_apply::mach_read_from_4(frame + 38 + 8 + 8+ 8 + 4 + 4), "sys table root page"});
    table.AddRowsValue({"DICT_HDR_TABLE_IDS",       gaia_apply::mach_read_from_4(frame + 38 + 8 + 8+ 8 + 4 + 4 + 4), "sys ids table root page"});
    table.AddRowsValue({"DICT_HDR_COLUMNS",         gaia_apply::mach_read_from_4(frame + 38 + 8 + 8+ 8 + 4 + 4 + 4 + 4), "sys column table root page"});
    table.AddRowsValue({"DICT_HDR_INDEXES",         gaia_apply::mach_read_from_4(frame + 38 + 8 + 8+ 8 + 4 + 4 + 4 + 4 + 4), "sys index table root page"});
    table.AddRowsValue({"DICT_HDR_FIELDS",          gaia_apply::mach_read_from_4(frame + 38 + 8 + 8+ 8 + 4 + 4 + 4 + 4 + 4 + 4), "sys field table root page"});
    do_show_fseg_header(table, "DICT_HDR_FSEG_HEADER", frame, 38 + 56);
}

uint32_t get_next_rec_offset(gaia_apply::byte* frame, gaia_apply::byte* rec) {
    INIT_APPLY_RAW_ARG(false);
    bool is_comp = gaia_apply::page_is_comp(frame);
    return gaia_apply::rec_get_next_offs(rec, is_comp APPLY_RAW_ARG_NAME_CC);
}

bool get_rec_info_bit(gaia_apply::byte* rec, uint32_t shift) {
    uint32_t info_bit = gaia_apply::mach_read_from_1(rec - 5);
    uint32_t n = (1u << (shift + 4));
    return info_bit & n;
}

uint32_t get_rec_type(gaia_apply::byte* rec) {
    gaia_apply::byte rec_type_byte = *(rec - 3);
    return (rec_type_byte & 0x7);
}

uint32_t get_rec_heap_no(gaia_apply::byte* rec) {
    uint16_t st = gaia_apply::mach_read_from_2(rec - 3);
    return (st & 0xFFF8UL) >> 3;
}

gaia_apply::byte* get_next_rec(Table &table, gaia_apply::byte* frame, gaia_apply::byte* rec,
        uint32_t *rec_off = nullptr) {
    bool is_comp = gaia_apply::page_is_comp(frame);
    uint32_t next_rec_off = get_next_rec_offset(frame, rec);

    if (rec_off) {
        *rec_off = next_rec_off;
    }

    if (next_rec_off == 0) {
        table.AddRowsValue({"ERROR", "next rec offset invalid", next_rec_off});
        return nullptr;
    }

    gaia_apply::byte* next_rec = frame + next_rec_off;
    //table.AddRowsValue({"", (next_rec - frame), "rec page offset"});

    if (gaia_apply::rec_get_deleted_flag(next_rec, is_comp)) {    // is delete
        table.AddRowsValue({"MESSAGE", "rec is deleted", next_rec_off});
        return get_next_rec(table, frame, next_rec, rec_off);
    }

    // REC_STATUS_SUPREMUM
    if (get_rec_type(next_rec) == 3) {
        if (memcmp(next_rec, "supremum", strlen("supremum")) != 0) {
            table.AddRowsValue({"ERROR", "mismatch supremum rec data", get_buf(next_rec, 0, strlen("supremum"))});
            return nullptr;
        }

        uint32_t supremum_next_rec_off = gaia_apply::mach_read_from_2(next_rec - 2);
        if (supremum_next_rec_off != 0) {
            table.AddRowsValue({"ERROR", "mismatch supremum next rec offset", supremum_next_rec_off});
            return nullptr;
        }

        uint32_t next_page_num = gaia_apply::mach_read_from_4(frame + gaia_apply::FIL_PAGE_NEXT);
        if (next_page_num == gaia_apply::FIL_NULL) {
            table.AddRowsValue({"MESSAGE", "reach page end rec"});
            return nullptr;
        }

        //TODO:  get next page & check page type & return new page first rec
        table.AddRowsValue({"MESSAGE", "next page unsupport"});
        return nullptr;
    }

    table.AddRowsValue({"REC OFFSET", next_rec_off, "rec offset"});
    table.AddRowsValue({"REC TYPE", get_rec_type(next_rec), "rec type"});
    table.AddRowsValue({"REC HEAP NO", get_rec_heap_no(next_rec), "rec heap no"});

    return next_rec;
}

gaia_apply::byte* get_first_rec(Table &table, gaia_apply::byte* frame, uint32_t *rec_off = nullptr) {
    bool is_comp = gaia_apply::page_is_comp(frame);
    // REC_N_NEW_EXTRA_BYTES last 2 byte
    uint32_t next_rec_off = gaia_apply::mach_read_from_2(frame + 94 + 5 - 2);

    if (next_rec_off >= PAGE_SIZE) {
        table.AddRowsValue({"ERROR", "first user rec offset invalid", next_rec_off});
        return nullptr;
    }

    if (memcmp(frame + 94 + 5, "infimum", strlen("infimum")) != 0) {
        table.AddRowsValue({"ERROR", "mismatch infimum rec data", get_buf(frame,  94 + 5, 8)});
        return nullptr;
    }

    gaia_apply::byte* next_rec = frame + 94 + 5 + next_rec_off;
    //table.AddRowsValue({"", (next_rec - frame), "rec page offset"});

    if (gaia_apply::rec_get_deleted_flag(next_rec, is_comp)) {    // is delete
        table.AddRowsValue({"MESSAGE", "rec is deleted", next_rec_off});
        return get_next_rec(table, frame, next_rec, rec_off);
    }

    table.AddRowsValue({"REC OFFSET", next_rec_off, "rec offset"});
    table.AddRowsValue({"REC TYPE", get_rec_type(next_rec), "rec type"});
    table.AddRowsValue({"REC HEAP NO", get_rec_heap_no(next_rec), "rec heap no"});

    if (rec_off) {
        *rec_off = next_rec_off;
    }

    return next_rec;
}

uint32_t get_rec_data(Table &table, gaia_apply::byte* rec, gaia_apply::byte** rec_data, uint32_t *rec_len_real) {
    uint32_t rec_len_type = 0;
    uint32_t rec_len = gaia_apply::mach_read_from_1(rec - 5 - 1);
    uint32_t rec_len_in_page = 0;
    if (rec_len & 0x80) {
        rec_len_in_page = (rec_len & 0x3f) << 8;
        if (rec_len & 0x40) {
            rec_len_type = 3;
            uint32_t extern_space_id = gaia_apply::mach_read_from_4(rec + 33 + rec_len_in_page);
            uint32_t extern_page_no  = gaia_apply::mach_read_from_4(rec + 33 + rec_len_in_page + 4);
            uint32_t extern_offset   = gaia_apply::mach_read_from_4(rec + 33 + rec_len_in_page + 4 + 4);
            uint64_t extern_len      = gaia_apply::mach_read_from_8(rec + 33 + rec_len_in_page + 4 + 4 + 4);
            // TODO
            table.AddRowsValue({"", "rec use extern, len:", rec_len});
            table.AddRowsValue({"", extern_space_id, "extern_space_id"});
            table.AddRowsValue({"", extern_page_no, "extern_page_no"});
            table.AddRowsValue({"", extern_offset, "extern_offset"});
            table.AddRowsValue({"", extern_len, "extern_len"});
            rec_len = rec_len_in_page + extern_len;
            return 0;
        } else {
            rec_len_type = 2;
            rec_len  = rec_len_in_page + gaia_apply::mach_read_from_1(rec - 5 - 2);
        }
    } else {
        rec_len_type = 1;
    }

    *rec_data = get_buf(rec, 33, rec_len);
    *rec_len_real = rec_len;
    return rec_len_type;
}

void do_show_slots(Table &table, gaia_apply::byte* frame, uint32_t slot_num) {
    table.AddRowsValue({"--Page slots", slot_num, "slots number"});
    for (uint32_t i = 0; i < slot_num ; ++i) {
        gaia_apply::byte* slot = frame + PAGE_SIZE - 8 - ((i + 1) * 2);
        uint32_t slot_addr = gaia_apply::mach_read_from_2(slot);
        table.AddRowsValue({i, slot_addr, "slot page offset"});
    }
}

void do_show_sdi_page(Table &table, gaia_apply::byte* frame) {
    uint32_t rec_off = 0;
    gaia_apply::byte *rec = get_first_rec(table, frame, &rec_off);
    while (rec) {
        uint32_t sdi_type = gaia_apply::mach_read_from_4(rec);
        uint64_t sdi_id = gaia_apply::mach_read_from_8(rec + 4);
        uint32_t sdi_uncomp_len = gaia_apply::mach_read_from_4(rec + 4 + 8 + 6 + 7);
        uint32_t sdi_comp_len = gaia_apply::mach_read_from_4(rec + 4 + 8 + 6 + 7 + 4);

        gaia_apply::byte* rec_data = nullptr;
        uint32_t rec_len = 0;
        uint32_t rec_len_type = get_rec_data(table, rec, &rec_data, &rec_len);

        table.AddRowsValue({"SDI_TYPE", sdi_type, "sdi type"});
        table.AddRowsValue({"SDI_ID", sdi_id, "sdi id"});
        table.AddRowsValue({"SDI_UNCOMP_LEN", sdi_uncomp_len, "sdi len"});
        table.AddRowsValue({"SDI_COMP_LEN", sdi_comp_len, "sdi compress len"});
        table.AddRowsValue({"REC_LEN", rec_len, "sdi rec len"});
        table.AddRowsValue({"REC_LEN_TYPE", rec_len_type, "1: in page, 2:in page with 2byte, 3: extern"});

        if (rec_len != sdi_comp_len) {
            table.AddRowsValue({"ERROR", "rec len not equal compress len"});
            return;
        }

        gaia_apply::byte* sdi_data = rec_data;
        if (sdi_uncomp_len != sdi_comp_len) {
            sdi_data = zip_uncompress(table, rec_data, rec_len, sdi_uncomp_len);
            if (!sdi_data) {
                return;
            }
        }

        {
            rapidjson::Document d;
            rapidjson::ParseResult ok = d.Parse(reinterpret_cast<char *>(sdi_data));
            if (!ok) {
                table.AddRowsValue({"ERROR", "json parse failed"});
                return;
            }
            rapidjson::StringBuffer b;
            rapidjson::PrettyWriter<rapidjson::StringBuffer> writer(b);
            d.Accept(writer);
            std::cout << b.GetString() << std::endl;
            std::cout << sdi_data << std::endl;
            //table.AddRowsValue({"REC_DATA", b.GetString()});
        }

        rec = get_next_rec(table, frame, rec, &rec_off);
    }
}

void do_show_index_page(Table &table, gaia_apply::byte* frame) {
    uint32_t rec_off = 0;
    gaia_apply::byte *rec = get_first_rec(table, frame, &rec_off);
    while (rec) {
        gaia_apply::byte* rec_data = nullptr;
        uint32_t rec_len = 0;
        uint32_t rec_len_type = get_rec_data(table, rec, &rec_data, &rec_len);

        table.AddRowsValue({"REC_LEN", rec_len, "rec len"});
        table.AddRowsValue({"REC_LEN_TYPE", rec_len_type, "1: in page, 2:in page with 2byte, 3: extern"});

        std::cout << std::string(reinterpret_cast<const char*>(rec_data), rec_len) << std::endl;

        rec = get_next_rec(table, frame, rec, &rec_off);
    }
}


void do_show_page(gaia_apply::byte* frame, uint32_t space_id, uint32_t page_no) {
    PSVR_ASSERT(reinterpret_cast<uintptr_t>(frame) % PAGE_SIZE == 0);

    Table table(3);
    uint32_t page_type = do_show_page_header(table, frame, space_id, page_no);
    if (page_no == 0 || page_type == gaia_apply::FIL_PAGE_TYPE_FSP_HDR) {
        do_show_page_0(table, frame);
    } else if (page_type == gaia_apply::FIL_PAGE_TYPE_XDES) {
        do_show_page_xdes(table, frame);
    } else if (page_no == 1 || page_type == gaia_apply::FIL_PAGE_IBUF_BITMAP) {
        do_show_page_ibuf_bitmap(table, frame, page_no);
    } else if (page_no == 2 || page_type == gaia_apply::FIL_PAGE_INODE) {
        do_show_page_inode(table, frame);
    } else if (space_id == 0 && page_no == 3) {
        do_show_page_ibuf_inode(table, frame);
    } else if (space_id == 0 && page_no == 4) {
        table.AddRowsValue({"ibuf btree root", "TODO"});
    } else if (space_id == 0 && page_no == 5) {
        do_show_page_trx(table, frame);
    } else if (space_id == 0 && page_no == 6) {
        table.AddRowsValue({"rseg", "TODO"});
    } else if (space_id == 0 && page_no == 7) {
        assert(page_type == gaia_apply::FIL_PAGE_TYPE_TRX_SYS);
        do_show_page_dict(table, frame);
    } else {
        table.AddRowsValue({"--Page data", "----"});
        uint32_t slot_num =                             gaia_apply::mach_read_from_2(frame + 38);
        table.AddRowsValue({"PAGE_N_DIR_SLOTS",         slot_num, "slot number, per slot 2 byte"});
        table.AddRowsValue({"PAGE_HEAP_TOP",            gaia_apply::mach_read_from_2(frame + 38 + 2), "last rec heap no"});
        uint32_t n_heap =                               gaia_apply::mach_read_from_2(frame + 38 + 2 + 2);
        table.AddRowsValue({"PAGE_N_HEAP",              n_heap & 0x7fff, "total rec"});
        bool is_compact = n_heap & 0x8000;
        table.AddRowsValue({"PAGE_IS_COMP",             is_compact, "rec format is compact"});
        table.AddRowsValue({"PAGE_FREE",                gaia_apply::mach_read_from_2(frame + 38 + 2 + 2 + 2), "free rec offset"});
        table.AddRowsValue({"PAGE_GARBAGE",             gaia_apply::mach_read_from_2(frame + 38 + 2 + 2 + 2 + 2), "garbage rec length"});
        table.AddRowsValue({"PAGE_LAST_INSERT",         gaia_apply::mach_read_from_2(frame + 38 + 2 + 2 + 2 + 2 + 2), "last insert rec offset"});
        table.AddRowsValue({"PAGE_DIRECTION",           gaia_apply::mach_read_from_2(frame + 38 + 2 + 2 + 2 + 2 + 2 + 2), "cur insert direction, 1:LEFT, 2:RIGHT, 3:SAME_REC, 4:SAME_PAGE, 4:NO_DIRECTION"});
        table.AddRowsValue({"PAGE_N_DIRECTION",         gaia_apply::mach_read_from_2(frame + 38 + 2 + 2 + 2 + 2 + 2 + 2 + 2), "same direction rec number"});
        table.AddRowsValue({"PAGE_N_RECS",              gaia_apply::mach_read_from_2(frame + 38 + 2 + 2 + 2 + 2 + 2 + 2 + 2 + 2), "user rec number"});
        table.AddRowsValue({"PAGE_MAX_TRX_ID",          gaia_apply::mach_read_from_8(frame + 38 + 2 + 2 + 2 + 2 + 2 + 2 + 2 + 2 + 2), "last update trx id"});

        table.AddRowsValue({"PAGE_LEVEL",               gaia_apply::mach_read_from_2(frame + 38 + 26), "btree level, 0 is leaf"});
        table.AddRowsValue({"PAGE_INDEX_ID",            gaia_apply::mach_read_from_8(frame + 38 + 26 + 2), "belong to index id, see mysql/idnexs table"});

        do_show_addr(table, "PAGE_BTR_SEG_LEAF", frame, 38 + 36, "seg leaf page inode");
        do_show_addr(table, "PAGE_BTR_SEG_TOP",  frame, 38 + 36 + 10, "seg top page inode");

        table.AddRowsValue({"--Page sys rec", "----"});
        table.AddRowsValue({"INFIMUM"});
        table.AddRowsValue({"OWNED_REC_NUM",    gaia_apply::mach_read_from_1(frame + 94), "owned rec number"});
        table.AddRowsValue({"HEAP_NO",          gaia_apply::mach_read_from_2(frame + 94 + 1), "heap no"});
        table.AddRowsValue({"NEXT_REC_OFFSET",  gaia_apply::mach_read_from_2(frame + 94 + 3), "pointer to supremum or next rec"});
        table.AddRowsValue({"DATA",             get_buf(frame, 94 + 5, 8), "rec offset = 99"});

        table.AddRowsValue({"SUPREMUM"});
        table.AddRowsValue({"OWNED_REC_NUM",    gaia_apply::mach_read_from_1(frame + 94 + 5 + 8), "owned rec number"});
        table.AddRowsValue({"HEAP_NO",          gaia_apply::mach_read_from_2(frame + 94 + 5 + 8 + 1), "heap no"});
        table.AddRowsValue({"NEXT_REC_OFFSET",  gaia_apply::mach_read_from_2(frame + 94 + 5 + 8 + 3), "end of record list"});
        table.AddRowsValue({"DATA",             get_buf(frame, 94 + 5 + 8 + 5, 8), "rec offset = 112"});

        table.AddRowsValue({"--Page user rec", "----"});
        if (page_type == gaia_apply::FIL_PAGE_SDI) {
            do_show_sdi_page(table, frame);
        } else if (page_type == gaia_apply::FIL_PAGE_INDEX) {
            do_show_index_page(table, frame);
        }

        do_show_slots(table, frame, slot_num);
    }

    do_show_page_trailer(table, frame);
    table.Display();
}

int CheckIbdFile::Run() {
    gaiadb::common::ut_crc32_init();
    _start_time = std::chrono::steady_clock::now();

    if (!_ibd_file.size()) {
        print_error("miss --ibd-file");
        return 1;
    }

    _fd = open(_ibd_file.c_str(), O_RDONLY, 0644);
    if (_fd < 0) {
        print_error("open file failed, %s", strerror(errno));
        return 1;
    }

    std::shared_ptr<nullptr_t> guard_fp(nullptr,
            [this](nullptr_t) {
                if (_fd > -1) {
                    close(_fd);
                }
        });

    struct stat sbuf;
    if (fstat(_fd, &sbuf) != 0) {
        print_error("get file size failed");
        return 1;
    }

    if (_stat) {
        printf("ID of containing device: [%x,%x]\n", major(sbuf.st_dev), minor(sbuf.st_dev));
        printf("File type:                ");
        switch (sbuf.st_mode & S_IFMT) {
        case S_IFBLK:
            printf("block device\n");
            break;
        case S_IFCHR:
            printf("character device\n");
            break;
        case S_IFDIR:
            printf("directory\n");
            break;
        case S_IFIFO:
            printf("FIFO/pipe\n");
            break;
        case S_IFLNK:
            printf("symlink\n");
            break;
        case S_IFREG:
            printf("regular file\n");
            break;
        case S_IFSOCK:
            printf("socket\n");
            break;
        default:
            printf("unknown?\n");
            break;
        }

        printf("I-node number:            %ju\n", static_cast<uintmax_t>(sbuf.st_ino));
        printf("Mode:                     %jo (octal)\n", static_cast<uintmax_t>(sbuf.st_mode));

        printf("Link count:               %ju\n", static_cast<uintmax_t>(sbuf.st_nlink));
        printf("Ownership:                UID=%ju   GID=%ju\n", static_cast<uintmax_t>(sbuf.st_uid), static_cast<uintmax_t>(sbuf.st_gid));

        printf("Preferred I/O block size: %jd bytes\n", static_cast<uintmax_t>(sbuf.st_blksize));
        printf("File size:                %jd bytes\n", static_cast<uintmax_t>(sbuf.st_size));
        printf("Blocks allocated:         %jd\n", static_cast<uintmax_t>(sbuf.st_blocks));

        printf("Last status change:       %s", ctime(&sbuf.st_ctime));
        printf("Last file access:         %s", ctime(&sbuf.st_atime));
        printf("Last file modification:   %s", ctime(&sbuf.st_mtime));

        return 0;
    }

    _file_size = sbuf.st_size;
    if (_file_size % PAGE_SIZE != 0 || _file_size == 0) {
        print_error("file size not right, %lu", _file_size);
        return 1;
    }

    struct BufBlockRelease {
        void operator()(gaia_apply::buf_block_t* p) const {
            free(p->frame);
            free(p);
        }
    };

    gaia_apply::page_size_t page_size(PAGE_SIZE, PAGE_SIZE, false);

    auto* block_raw = static_cast<gaia_apply::buf_block_t*>(malloc(sizeof(gaia_apply::buf_block_t)));
    void* buf = std::aligned_alloc(PAGE_SIZE, PAGE_SIZE);
    auto buf_compress = static_cast<gaia_apply::byte*>(std::aligned_alloc(PAGE_SIZE, PAGE_SIZE));
    if (!block_raw || !buf || !buf_compress) {
        print_error("alloc buf failed, %s", strerror(errno));
        free(block_raw);
        free(buf);
        free(buf_compress);
        return 1;
    }
    block_raw->frame = static_cast<gaia_apply::byte*>(buf);
    block_raw->page.size.copy_from(page_size);

    BufBlockRelease buf_release;
    std::unique_ptr<gaia_apply::buf_block_t, BufBlockRelease> block(block_raw, buf_release);

    int64_t start_off = 0;
    if (_offset > 0) {
        start_off = (_offset / PAGE_SIZE) * PAGE_SIZE;
    }

    std::cout << "start check ibd file:" << _ibd_file
        << " pages data, start offset:" << start_off
        << ", file size:" << RowSize(_file_size, _human_readable)
        << ", page size:" << PAGE_SIZE << std::endl;

    bool is_empty = 0;
    uint32_t crc = 0;
    uint32_t retry_time = 0;
    uint64_t check_page_num = _page_num;
    if (check_page_num == 0) {
        check_page_num = (_file_size - start_off) / PAGE_SIZE;
    }
    for (uint64_t off = start_off; off < _file_size && check_page_num; /*nothing*/) {
        if (_stopped) {
            return 1;
        }
        int64_t n = pread(_fd, buf, PAGE_SIZE, off);
        if (n != PAGE_SIZE) {
            LOG(ERROR) << "read ibd file length error, size: " << n << ", error:" << strerror(errno);
            return -1;
        }

        if (!decompress_page(block_raw->frame, buf_compress, PAGE_SIZE)) {
            return -1;
        }

        gaia_apply::space_id_t space_id = 0;
        gaia_apply::page_no_t page_no = 0;

        block->page.id.reset(space_id, page_no);

        bool ret = page_is_corrupted(block->frame, PAGE_SIZE, &is_empty);
        if (ret) {
            LOG(WARNING) << "offset:" << off << " data corrupted, retry it";
            ++retry_time;
            if (retry_time > MAX_RETRY_TIMES) {
                LOG(ERROR) << "offset:" << off << " data corrupted, retry reach max error times";
                std::cout << "offset:" << off << " data corrupted, retry reach max error times" << std::endl;
                space_id = gaia_apply::page_get_space_id(block_raw->frame);
                page_no = gaia_apply::page_get_page_no(block_raw->frame);
                auto lsn = gaia_apply::mach_read_from_8(block_raw->frame + gaia_apply::FIL_PAGE_LSN);
                std::cout << "off:" << off << ", lsn:" << lsn
                    << ", space_id:" << space_id << ", page_no:" << page_no << "\n";
                return -1;
            }
            usleep(retry_time * 500);
            continue;
        }

        crc = gaia_apply::mach_read_from_4(block->frame + gaia_apply::FIL_PAGE_SPACE_OR_CHKSUM);
        LOG(DEBUG) << "check off: " << off << " page ok, is empty:" << is_empty << " crc:" << crc;
        if (!_silent) {
            if (!is_empty || _show_empty_page) {
                space_id = gaia_apply::page_get_space_id(block_raw->frame);
                page_no = gaia_apply::page_get_page_no(block_raw->frame);
                auto lsn = gaia_apply::mach_read_from_8(block_raw->frame + gaia_apply::FIL_PAGE_LSN);
                std::cout << "off:" << off << ", crc:" << crc << ", lsn:" << lsn
                    << ", space_id:" << space_id << ", page_no:" << page_no << "\n";
            }
        }
        ShowProgress(off, _file_size);

        if (_show_page_detail && !_show_process && !is_empty) {
            do_show_page(block->frame, space_id, page_no);
        }

        retry_time = 0;
        off += PAGE_SIZE;
        --check_page_num;
    }
    LOG(NOTICE) << "check done, all pages are ok, start offset:" << start_off;
    return 0;
}

void CheckIbdFile::ShowProgress(int64_t done, int64_t total) {
    if (!_show_process) {
        return;
    }

    static std::chrono::steady_clock::time_point last_time = std::chrono::steady_clock::now();
    auto time_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - last_time).count();
    if (time_elapsed > 1000 * 3) {
        last_time = std::chrono::steady_clock::now();
    } else {
        return;
    }

    int64_t width = 80;
    float progress = 1.0;
    int64_t pos = width;

    if (width > 0) {
        progress = static_cast<float>(done * 1.0) / total;
        pos = static_cast<uint32_t>(width * progress);
    }

    std::cout << "[";
    for (uint32_t i = 0; i < width; ++i) {
        if (i < pos) {
            std::cout << "=";
        } else if (i == pos) {
            std::cout << ">";
        } else {
            std::cout << " ";
        }
    }
    std::cout << " | size:" << total <<  "] " << static_cast<uint32_t>(progress * 100.0) << "% ";
    time_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - _start_time).count();
    std::cout << static_cast<float>(time_elapsed / 1000.0) << "s\r";
    std::cout.flush();
}

}
}
