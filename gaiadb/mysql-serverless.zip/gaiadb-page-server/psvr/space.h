/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/space.h
* @author
* @brief
*/

#pragma once

#include <map>
#include <unordered_map>

#include <base/string_printf.h>

#include <psvr0page.h>  // page_size_t

#include "psvr/common.h"
#include "psvr/page.h"

namespace psvr {

#define MAX_SPACE_STATUS_SIZE 32768lu

const gaia_apply::page_size_t& gaia_page_size();
gaia_apply::ulint gaia_physical_page_size();
gaia_apply::ulint gaia_logical_page_size();
bool gaia_page_is_compressed();

template<typename T>
struct InflightReqLock {

    bool GetReqLock(const T& key) {
        std::unique_lock lk(_mutex);
        return _inflight_keys.emplace(key).second;
    }

    bool PutReqLock(const T& key) {
        std::unique_lock lk(_mutex);
        return _inflight_keys.erase(key) > 0;
    }

private:
    std::mutex _mutex;
    std::set<T> _inflight_keys;
};

static constexpr uint32_t kSpaceStatusUnknown = 0u;
static constexpr uint32_t kSpaceStatusWork = 1u;
static constexpr uint32_t kSpaceStatusDeleted = 2u;
static constexpr uint32_t kSpaceStatusWithPSM = 4u;

inline bool space_status_is_unknown(uint32_t s) {
    return (s == kSpaceStatusUnknown);
}
inline bool space_status_is_work(uint32_t s) {
    return (s & kSpaceStatusWork) > 0;
}
inline bool space_status_is_deleted(uint32_t s) {
    return (s & kSpaceStatusDeleted) > 0;
}
inline bool space_status_with_psm(uint32_t s) {
    return (s & kSpaceStatusWithPSM) > 0;
}

static constexpr uint32_t kSpaceEncryptStatusUnknown = 0u;
static constexpr uint32_t kSpaceEncryptStatusWithPSM = 2u;
static constexpr uint32_t kSpaceEncryptStatusEnable = 4u;

inline bool space_encrypt_status_is_unknown(uint32_t s) {
    return (s == kSpaceEncryptStatusUnknown);
}

inline bool space_encrypt_status_with_psm(uint32_t s) {
    return (s & kSpaceEncryptStatusWithPSM) > 0;
}

inline bool space_encrypt_status_is_enable(uint32_t s) {
    return (s & kSpaceEncryptStatusEnable) > 0;
}

class SpaceStatusManager {
public:
    SpaceStatusManager() : _space_status_size(0) {}
    FUNC_MOCK ~SpaceStatusManager();

    size_t GetSpaceStatusCount() const;
    bool SetSpaceStatus(gaia_apply::space_id_t space_id, uint32_t s);
    uint32_t GetSpaceStatus(gaia_apply::space_id_t space_id) const;

    bool SetSpaceEncryptStatus(gaia_apply::space_id_t space_id, uint32_t s);
    uint32_t GetEncryptSpaceStatus(gaia_apply::space_id_t space_id) const;
    int32_t ClearUseLessSpaceStatus();

    bool SetSafeTrimLsn(gaia_apply::space_id_t space_id, gaia_apply::lsn_t lsn);
    gaia_apply::lsn_t GetSafeTrimLsn(gaia_apply::space_id_t space_id) const;

private:
    struct SpaceStatus {
        uint32_t status;
        uint32_t encrypt_status;
        gaia_apply::lsn_t safe_trim_lsn;
        int64_t time;
        SpaceStatus(uint32_t s, uint32_t es, gaia_apply::lsn_t lsn)
            : status(s), encrypt_status(es), safe_trim_lsn(lsn) {
            time = base::cpuwide_time_ms();
        }
        SpaceStatus(const SpaceStatus &rhs)
            : status(rhs.status),
              encrypt_status(rhs.encrypt_status),
              safe_trim_lsn(rhs.safe_trim_lsn),
              time(rhs.time) {}
    };
    mutable rwlock_t _shared_mutex;
    std::unordered_map<gaia_apply::space_id_t, SpaceStatus> _space_status;
    size_t _space_status_size;
};

class ExtentMetaManager {
public:
    ExtentMetaManager() {}
    FUNC_MOCK ~ExtentMetaManager() {}

    rwlock_t& shared_mutex() { return _shared_mutex; }

    void Set(gaia_apply::space_id_t space_id,
            uint32_t logic_extent_id, uint32_t physical_extent_id);
    void SetNoLock(gaia_apply::space_id_t space_id,
            uint32_t logic_extent_id, uint32_t physical_extent_id);

    FUNC_MOCK bool Get(gaia_apply::space_id_t space_id,
            uint32_t logic_extent_id, uint32_t* physical_extent_id = nullptr) const;
    bool GetNoLock(gaia_apply::space_id_t space_id,
            uint32_t logic_extent_id, uint32_t* physical_extent_id) const;

    bool SetPhysicalExtent(uint32_t physical_extent_id,
            gaia_apply::space_id_t space_id, uint32_t logic_extent_id);

    bool SetPhysicalExtentNoLock(uint32_t physical_extent_id,
            gaia_apply::space_id_t space_id, uint32_t logic_extent_id);

    FUNC_MOCK bool GetPhysicalExtent(uint32_t physical_extent_id,
            gaia_apply::space_id_t* space_id, uint32_t* logic_extent_id, bool* match) const;

    bool GetPhysicalExtentNoLock(uint32_t physical_extent_id,
            gaia_apply::space_id_t* space_id, uint32_t* logic_extent_id, bool* match) const;

    bool ExistPhysicalExtentNoLock(uint32_t physical_extent_id) const;

    bool CleanSpaceExtent(gaia_apply::space_id_t space_id);

private:
    mutable rwlock_t _shared_mutex;
    // space id -> extent id -> physical extent id
    std::map<uint32_t, std::map<uint32_t, uint32_t>> _space_extent_to_physical_extent;
    // physical extent id -> (fold (space id, extent id), same segment id)
    std::map<uint32_t, std::pair<uint64_t, bool>> _physical_extent_to_space_extent;
};

class SpacePageManager {
public:
    SpacePageManager();
    FUNC_MOCK ~SpacePageManager() {}

    FUNC_MOCK PagePtr GetPage(gaia_apply::space_id_t space_id,
            gaia_apply::page_no_t page_no, bool create_if_not_exists = false);
    FUNC_MOCK PagePtr GetOrCreatePage(gaia_apply::space_id_t space_id,
            gaia_apply::page_no_t page_no);

private:
    using PageManager = ResManager<uint64_t, Page>;
    std::vector<std::shared_ptr<PageManager>> _slice_res_page_manager;
};

}   // end of ns
