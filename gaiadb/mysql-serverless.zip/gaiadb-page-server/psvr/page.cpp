/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/page.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/page.h"

namespace psvr {

bool Page::LogRecordEmpty() {
    std::shared_lock slk(_shared_mutex);
    return _log_records_size == 0;
}

bool Page::AppendLogRecord(const LogRecord* rec) {
    std::unique_lock lk(_shared_mutex);
    if (rec->end_lsn <= _last_record_lsn.load()) {
        LOG(WARNING) << this << " invalid rec,"
            << " rec_end_lsn:[" << rec->end_lsn
            << "] last_record_lsn:[" << _last_record_lsn.load()
            << "]";
        return false;
    }
    ++_log_records_size;
    _log_records.emplace_back(rec);
    _last_record_lsn.store(_log_records.back()->end_lsn);
    return true;
}

bool Page::AppendLogRecords(std::list<const LogRecord*>&& list_rec) {
    std::unique_lock lk(_shared_mutex);
    const LogRecord* rec = list_rec.back();
    if (rec->end_lsn <= _last_record_lsn.load()) {
        LOG(WARNING) << this << " invalid rec,"
            << " rec_end_lsn:[" << rec->end_lsn
            << "] last_record_lsn:[" << _last_record_lsn.load()
            << "]";
        return false;
    }

    _log_records_size += list_rec.size();
    _log_records.splice(_log_records.end(), list_rec);
    _last_record_lsn.store(_log_records.back()->end_lsn);
    return true;
}

bool Page::LogRecordIsEmpty(gaia_apply::lsn_t max_lsn, gaia_apply::lsn_t* lsn) {
    std::shared_lock slk(_shared_mutex);
    return LogRecordIsEmptyNoLock(max_lsn, lsn);
}

bool Page::LogRecordIsEmptyNoLock(gaia_apply::lsn_t max_lsn, gaia_apply::lsn_t* lsn) {
    if (_log_records_size == 0) {
        return true;
    }
    gaia_apply::lsn_t min_lsn = _log_records.front()->end_lsn;
    if (lsn) {
        *lsn = min_lsn;
    }
    return min_lsn > max_lsn;
}

gaia_apply::mlog_id_t Page::GetFirstLogRecordTypeNoLock(gaia_apply::lsn_t max_lsn) {
    if (_log_records_size > 0) {
        const auto& rec = _log_records.front();
        if (max_lsn == 0 || max_lsn >= rec->end_lsn) {
            return rec->type;
        }
    }
    return gaia_apply::MLOG_BIGGEST_TYPE;
}

gaia_apply::mlog_id_t Page::GetFirstLogRecordType(gaia_apply::lsn_t max_lsn) {
    std::shared_lock slk(_shared_mutex);
    return GetFirstLogRecordTypeNoLock(max_lsn);
}

bool Page::FirstLogRecordTypeIsInit(gaia_apply::lsn_t max_lsn) {
    std::shared_lock slk(_shared_mutex);
    return FirstLogRecordTypeIsInitNoLock(max_lsn);
}

bool Page::FirstLogRecordTypeIsInitNoLock(gaia_apply::lsn_t max_lsn) {
    return GetFirstLogRecordTypeNoLock(max_lsn) == gaia_apply::MLOG_INIT_FILE_PAGE2;
}

void Page::PurgeLogRecords(gaia_apply::lsn_t max_record_lsn) {
    std::unique_lock lk(_shared_mutex);
    PurgeLogRecordsNoLock(max_record_lsn);
}

void Page::PurgeLogRecordsNoLock(gaia_apply::lsn_t max_record_lsn) {
    PSVR_ASSERT(_log_records_size > 0);
    auto it = _log_records.begin();
    while (it != _log_records.end()) {
        const LogRecord* rec = *it;
        if (rec->end_lsn > max_record_lsn) {
            break;
        }

        --_log_records_size;
        ++it;
        //LOG(TRACE) << "purge a record,"
        //<< " type:[" << rec->type
        //<< "] space:[" << _space_id
        //<< "] page:[" << _page_no
        //<< "] lsn:[" << rec->start_lsn << "," << rec->end_lsn
        //<< "]";
    }
    // not need to free rec
    it = _log_records.erase(_log_records.begin(), it);
    PSVR_ASSERT(max_record_lsn >= last_gc_lsn());
    PSVR_ASSERT(_log_records_size >= 0);
    _last_gc_lsn.store(max_record_lsn);
}

void Page::PurgeLogRecordsNoLock(const PageLogRecordIterator& iter,
        gaia_apply::lsn_t max_record_lsn) {
    PSVR_ASSERT(_log_records_size >= iter.size());
    _log_records_size -= iter.size();
    _log_records.erase(_log_records.begin(), iter.end());
    PSVR_ASSERT(max_record_lsn >= last_gc_lsn());
    _last_gc_lsn.store(max_record_lsn);
}

}
