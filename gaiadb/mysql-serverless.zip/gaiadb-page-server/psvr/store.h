/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/store.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gaiadb/utils/configuration.h>
#include "psvr/namespace.h"
#include "psvr/common.h"
#include "psvr/segment.h"

namespace psvr {

class Store;
using StorePtr = std::shared_ptr<Store>;
class StoreManager;
using StoreManagerPtr = std::shared_ptr<StoreManager>;

struct LoadStat {
    std::atomic<uint32_t> load_num {0};
    std::atomic<uint32_t> prepared_num {0};
    std::atomic<uint32_t> failed_num {0};
    std::atomic<uint32_t> succ_num {0};
    int64_t start_time {0};
};

struct LoadContext {
    ControlPtr control;
    int32_t store_id;
    std::atomic<uint32_t> segment_count;
    std::atomic<uint32_t> load_finish_count;
    std::atomic<uint32_t> load_failed_count;
    bool rc;
    std::list<SegmentPtr> segments;
    std::mutex mutex;
    std::shared_ptr<LoadStat> load_stat;

    LoadContext(ControlPtr _control, int32_t _store_id,
        std::shared_ptr<LoadStat> _load_stat)
        : control(_control), store_id(_store_id),
        segment_count(0), load_finish_count(0), load_failed_count(0), rc(false),
        load_stat(_load_stat) {}

    void PushSegment(SegmentPtr segment) {
        std::unique_lock<std::mutex> lm(mutex);
        segments.push_back(segment);
    }
};

using LoadSegmentFn = std::function<void(bool, SegmentPtr)>;

class Store {
friend class StoreManager;
public:
    Store(int32_t id, const std::string& path, const std::string& trash_path, bool active,
        int64_t physical_size, int64_t size, int64_t free_size, bool specify_size, int64_t capacity)
        : _id(id), _path(path), _trash_path(trash_path), _active(active),
        _physical_size(physical_size), _size(size), _free_size(free_size),
        _specify_size(specify_size), _capacity(capacity),
        _used_capacity(0), _logic_used_size(0), _physical_used_size(physical_size - free_size),
        _physical_free_size(free_size),
        _enable_punch_hole(false), _io_error_count(0),
        _stat_read_lat(kSlaWindowSize),
        _stat_write_lat(kSlaWindowSize),
        _stat_sync_lat(kSlaWindowSize),
        _stat_gc_log_block_buf_bw(kSlaWindowSize),
        _stat_gc_log_block_page_bw(kSlaWindowSize) {
        Expose();
    }
    FUNC_MOCK ~Store() {
        _stat_read_lat.hide();
        _stat_write_lat.hide();
        _stat_sync_lat.hide();
        _stat_gc_log_block_buf_bw.hide();
        _stat_gc_log_block_page_bw.hide();
    }

    uint32_t id() const { return _id; }
    const std::string& path() const { return _path; }
    const std::string& trash_path() const { return _trash_path; }
    int64_t free_size() const { return _free_size.load(std::memory_order_relaxed); }
    int64_t physical_free_size() const { return _physical_free_size.load(std::memory_order_relaxed); }

    bool enable_punch_hole() const { return _enable_punch_hole; }

    std::string GetSegmentDBPath(const std::string& cluster_id, uint32_t segment_id);
    FUNC_MOCK SegmentPtr OpenSegment(ControlPtr control,
            const std::string& segment_dir, bool* is_trash, bool delete_inactive = true);
    bool LoadSegments(std::shared_ptr<LoadContext> load_ctx);

    FUNC_MOCK bool EnableAddSegment(int64_t size);
    FUNC_MOCK bool IncStatistic(SegmentPtr segment, bool is_load = false);
    void DecStatistic(SegmentPtr segment);
    void GetStoreInfo(pspb::MultiGetStatusResponse::Store* info);

    bool DeleteSegment(SegmentPtr segment);
    FUNC_MOCK bool DeleteSegmentPath(const std::string& path,
            const std::string& cluster_id, uint32_t segment_id);

    void IncIOErrorCount(TRACE_FILE_LINE_D);
    void ClearIOError();
    void GcTrash(volatile const bool& stopped);
    void UpdateFreeSize(volatile const bool& stopped);

    bool IsActive();
    FUNC_MOCK bool Disable();
    FUNC_MOCK bool Enable();
    int64_t UpdateCapacity(int64_t capacity);
    int64_t UpdateSize(int64_t size);

    void GetConfigItems(gaiadb::common::Config* config);

    void PutReadLat(int64_t lat) {
      _stat_read_lat << lat;
    }

    void PutWriteLat(int64_t lat) {
      _stat_write_lat << lat;
    }

    void PutSyncLat(int64_t lat) {
      _stat_sync_lat << lat;
    }

private:
    void Expose();
    void UpdateFreeSizeNoLock(volatile const bool& stopped);
private:
    const int32_t _id;
    const std::string _path;
    const std::string _trash_path;
    bool _active;
    int64_t _physical_size;
    int64_t _size;
    std::atomic<int64_t> _free_size;
    bool _specify_size;
    int64_t _capacity;
    int64_t _used_capacity;
    int64_t _logic_used_size;
    int64_t _physical_used_size;
    std::atomic<int64_t> _physical_free_size;
    bool _enable_punch_hole;
    std::atomic<int64_t> _io_error_count;
    rwlock_t _mutex;
    // stat
    StatLatency _stat_read_lat;
    StatLatency _stat_write_lat;
    StatLatency _stat_sync_lat;
    StatBw _stat_gc_log_block_buf_bw;
    StatBw _stat_gc_log_block_page_bw;
};

inline std::ostream& operator<<(std::ostream& os, Store* s) {
    if (s) {
        os << "store:[id=" << s->id() << ", path=" << s->path() << "]";
    }
    return os;
}
inline std::ostream& operator<<(std::ostream& os, const StorePtr& s) {
    if (s) {
        os << s.get();
    }
    return os;
}

using StoreIteratorFn = std::function<bool(StorePtr)>;

class StoreManager {
public:
    StoreManager() : _stopped(true), _is_absolute_path(true) {}
    FUNC_MOCK ~StoreManager() {}

    bool ParseStoreCfgFile(const std::string& store_cfg,
        bool is_absolute_path, std::map<int32_t, StorePtr>* stores);

    FUNC_MOCK bool Init();
    FUNC_MOCK bool InitBatchFetch(ControlPtr control);
    FUNC_MOCK bool Start(ControlPtr control, std::shared_ptr<LoadStat> load_stat);
    void Stop();
    FUNC_MOCK bool StoreConfigFile();

    uint32_t StoreCount();

    FUNC_MOCK StorePtr GetStore(int32_t id);
    FUNC_MOCK uint32_t GetStores(const StoreIteratorFn& fn);
    FUNC_MOCK uint32_t GetStores(std::vector<StorePtr>* stores);

    void StatStoreGcInfo(int32_t id, int32_t buf_size, int32_t page_count) {
        auto s = GetStore(id);
        if (s) {
            s->_stat_gc_log_block_buf_bw << buf_size;
            s->_stat_gc_log_block_page_bw << page_count;
        }
    }

    void StatReadLat(int32_t id, int64_t lat) {
        auto s = GetStore(id);
        if (s) {
            s->_stat_read_lat << lat;
        }
    }

    void StatWriteLat(int32_t id, int64_t lat) {
        auto s = GetStore(id);
        if (s) {
            s->_stat_write_lat << lat;
        }
    }

    void StatSyncLat(int32_t id, int64_t lat) {
        auto s = GetStore(id);
        if (s) {
            s->_stat_sync_lat << lat;
        }
    }

private:
    void LoadStoreSegments(std::shared_ptr<LoadContext>);

private:
    volatile bool _stopped;
    bool _is_absolute_path;
    std::map<int32_t, StorePtr> _stores;
    rwlock_t _mutex;
};

}
