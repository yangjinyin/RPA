/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/segment.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gaiadb/common/types.h>
#include <gaiadb/utils/utils.h>

#include "psvr/append_file.h"
#include "psvr/client.h"
#include "psvr/common.h"
#include "psvr/dbengine.h"
#include "psvr/dblwr.h"
#include "psvr/log_block.h"
#include "psvr/model.h"
#include "psvr/page.h"
#include "psvr/psminfo.h"
#include "psvr/quota.h"
#include "psvr/space.h"
#include "psvr/time_point.h"

namespace psvr {

#define define_control_or_return_invalid(_ctx) \
    ControlPtr control = _control.lock();   \
    while (!control || _stopped) { \
        CtxGuard ctx_guard(_ctx); \
        return;     \
    }

#define define_segment_or_return_invalid(_ctx) \
    SegmentPtr segment = _ctx->segment.lock();  \
    while (!segment_is_valid(segment)) { \
        CtxGuard ctx_guard(_ctx);   \
        return; \
    }

#define define_segment_or_return_invalid_exclude(_ctx, _flag) \
    SegmentPtr segment = _ctx->segment.lock();  \
    while (!segment_is_valid_exclude(segment, _flag)) { \
        CtxGuard ctx_guard(_ctx);   \
        return; \
    }

#define segment_define_control_or_return_invalid_closure()  \
    ControlPtr control = _control.lock();  \
    while (!control) {  \
        brpc::ClosureGuard closure_guard(closure);  \
        return;   \
    }

#define segment_define_control_or_return_invalid_status()  \
    ControlPtr control = _control.lock();  \
    while (!control) {  \
        s.Reset(db::Code::kInterrupt, "server stopped");    \
        return s;   \
    }

#define segment_set_stage_info_with_action(_segment, _stage, _action) \
    do { \
        if (_segment) { \
            (_segment)->set_stage_info((_stage), (_action)); \
        } \
    } while (0)

#define segment_set_stage_info(_segment, _stage) \
    do { \
        if (_segment) { \
            (_segment)->set_stage_info((_stage)); \
        } \
    } while (0)

struct event_space_extent_t;
struct ExtentArg;

class Cluster;
using ClusterPtr = std::shared_ptr<Cluster>;
using ClusterWeakPtr = std::weak_ptr<Cluster>;

class Segment;
using SegmentPtr = std::shared_ptr<Segment>;
using SegmentWeakPtr = std::weak_ptr<Segment>;

std::ostream& operator<<(std::ostream& os, const SegmentPtr& segment);
std::ostream& operator<<(std::ostream& os, const Segment* segment);

template<typename T>
class CtxGuard {
public:
    CtxGuard(T* t) : _t(t) {}
    ~CtxGuard() {
        std::unique_ptr<T> ctx_guard(_t);
    }

    T* release() {
        T* t = _t;
        _t = nullptr;
        return t;
    }
private:
    T* _t;
};

template<>
class CtxGuard<nullptr_t> {
public:
    CtxGuard(nullptr_t) {}
    ~CtxGuard() {}

    nullptr_t release() {
        return nullptr;
    }
};

CtxGuard(nullptr_t) -> CtxGuard<nullptr_t>;

struct Statistic;
#define SEGMENT_KEY(s, i) base::string_printf("%s_%u", (s), (i))

struct Statistic {
    Statistic(Segment* _segment, const std::string& prefix);
    FUNC_MOCK ~Statistic();

    void HideBvar();

    const std::string prefix;
    Segment* segment;

    bvar::PassiveStatus<bvar::Vector<gaia_apply::lsn_t, 5>> stat_lsn;
    bvar::Adder<uint32_t> stat_fetch_logblock_count;
    bvar::Adder<uint32_t> stat_parse_logblock_count;
    bvar::Adder<uint32_t> stat_append_logblock_count;
    bvar::Adder<uint32_t> stat_gc_logblock_count;
    StatBw stat_fetch_logblock_data_bw;
    StatBw stat_recover_redo_rec_log_bw;
    StatLatency stat_parse_logblock_lat;
    StatLatency stat_parse_logblock_real_lat;
    StatLatency stat_append_logblock_lat;
    StatLatency stat_append_logblock_real_lat;
    StatLatency stat_gc_logblock_lat;
    StatLatency stat_gc_logblock_real_lat;
    StatCount stat_gc_logblock_in_prior_thread_count;
    StatLatency stat_gc_task_lat;
    StatLatency stat_gc_page_lat;
    StatSize stat_gc_task_size;
    StatCount stat_gc_schedule_count;
    StatCount stat_parse_records_count;
    StatCount stat_apply_records_count;
    bvar::PassiveStatus<bvar::Vector<uint64_t, 2>> stat_logblock_unparse_ungc_count;
    StatBw stat_recover_bw;
private:
    bool _is_hid;
};

#define set_segment_statistic(s, var, val)       \
do {                                              \
    auto _stat = s->statistic();                  \
    if (_stat) {                                  \
        (_stat->var) << (val);                   \
    }                                             \
} while(0)

#define set_segment_cluster_statistic(s, var, val)       \
    set_cluster_stat(s->cluster(), var, val)

struct PeerInfo {
    std::vector<gaiadb::common::PeerZone> replicas;
    BitFlag replicas_status;
    bool has_zone {false};
    uint32_t zone_count {0};
    uint32_t last_zone_version {0};
    AcquireLock lock;
    rwlock_t shared_mutex;

    std::ostream& ToString(std::ostream& os) const {
        os << "peer_info:[count=" << replicas.size();
        for (auto& peer : replicas) {
            os << "," << peer.addr << ":" << peer.region << ":" << peer.available_zone;
        }
        return os << "]";
    }
};

inline std::ostream& operator<<(std::ostream& os, const PeerInfo& peer_info) {
    return peer_info.ToString(os);
}

struct CompressConfig {
    bool enable {false};
    int32_t type {0};
    int32_t level {-1};

    CompressConfig() {}
    CompressConfig& operator=(const CompressConfig& lhs) {
        enable = lhs.enable;
        type = lhs.type;
        level = lhs.level;
        return *this;
    }
    ~CompressConfig() {}
};

struct StatCompress {
    bool inited;
    std::atomic<bool> data_updated;
    std::atomic<int64_t> last_compress_time_s;
    std::atomic<int32_t> compress_times;
    std::atomic<uint64_t> non_empty_page_count;
    std::atomic<uint64_t> last_compress_data_size;
    // sort_* only update in the compression CalcPriority thread
    uint64_t sort_data_size_mb;
    int64_t sort_last_compress_time_s;
    int32_t sort_compress_times;
    int32_t sort_drop_space_num;
    int32_t sort_update_extent_num;

    StatCount stat_drop_space_num;
    StatCount stat_update_page_count;

    StatCompress();
    ~StatCompress() {}
};

struct RecoveryInfo {
    struct Tablet {
        const size_t idx;
        const uint64_t start;
        const uint64_t end;
        uint64_t offset;

        Tablet(size_t _idx, uint64_t _start, uint64_t _end)
            : idx(_idx), start(_start), end(_end), offset(_start) {}
    };
    bool stopped {true};
    bool is_force {false};
    uint64_t offset {0};
    uint64_t finish_size {0};
    uint32_t inflight_count {0};
    uint64_t data_check_round_count {0};
    int64_t last_recover_time {0};
    std::atomic<bool> append_file_cleanup_frozen {false};
    std::vector<Tablet> tablets;
    size_t tablets_idx {0};
    mutable rwlock_t shared_mutex;
    AcquireLock lock;
    // in db::page_lock
    struct PageMinLsn {
        gaia_apply::space_id_t space_id;
        gaia_apply::page_no_t page_no;
        uint64_t min_lsn;
        PageMinLsn() : space_id(gaia_apply::SPACE_UNKNOWN), page_no(0), min_lsn(0) {}
    };
    PageMinLsn* pages_min_lsn {nullptr};
    std::map<gaia_apply::space_id_t, uint64_t> drop_spaces {};
    Lsn min_apply_lsn {0};

    RecoveryInfo() {}
    ~RecoveryInfo() {
        if (pages_min_lsn) {
            delete[] pages_min_lsn;
            pages_min_lsn = nullptr;
        }
        drop_spaces.clear();
    }

    void AddTablet(size_t idx, uint64_t start, uint64_t end) {
        tablets.emplace_back(idx, start, end);
    }
};

struct RecoverBlockTask {
    uint64_t offset {0};
    uint64_t size {0};
    int32_t idx {-1};
};

struct ReadPeerPageContext {
    struct Request {
        gaia_apply::space_id_t space_id;
        gaia_apply::page_no_t logical_page_no;
        gaia_apply::lsn_t lsn;
        std::vector<gaiadb::common::PeerZone> peers;
        Request(gaia_apply::space_id_t _space_id,
            gaia_apply::page_no_t _logical_page_no,
            gaia_apply::lsn_t _lsn)
            : space_id(_space_id),
            logical_page_no(_logical_page_no),
            lsn(_lsn) {}
        Request(gaia_apply::space_id_t _space_id,
            gaia_apply::page_no_t _logical_page_no,
            gaia_apply::lsn_t _lsn,
            const std::vector<gaiadb::common::PeerZone>& _peers)
            : space_id(_space_id),
            logical_page_no(_logical_page_no),
            lsn(_lsn),
            peers(_peers) {}
    };
    struct Response {
        bool success;
        uint32_t empty_page_count;
        bool is_empty;
        BufBlockPtr buf_block;
        Response(BufBlockPtr _buf_block)
            : success(false),
            empty_page_count(0),
            is_empty(false),
            buf_block(_buf_block) {}
    };

    Request request;
    Response response;
    int32_t retry_nr;
    int64_t begin_time;

    ReadPeerPageContext(gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t logical_page_no,
        gaia_apply::lsn_t lsn,
        BufBlockPtr buf_block)
        : request(space_id, logical_page_no, lsn), response(buf_block),
        retry_nr(0), begin_time(base::cpuwide_time_us()) {}
    ReadPeerPageContext(gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t logical_page_no,
        gaia_apply::lsn_t lsn,
        const std::vector<gaiadb::common::PeerZone>& peers,
        BufBlockPtr buf_block)
        : request(space_id, logical_page_no, lsn, peers), response(buf_block),
        retry_nr(0), begin_time(base::cpuwide_time_us()) {}
    ~ReadPeerPageContext() {}
};

class UniqueRunningTask {
public:
    UniqueRunningTask() : _plug_count(0) {}
    FUNC_MOCK ~UniqueRunningTask() {}

    bool Plug(uint64_t n = 1) {
        uint64_t expected = _plug_count.load(std::memory_order_relaxed);
        do {
            // nothing
        } while (!_plug_count.compare_exchange_strong(expected, expected + n));
        return expected == 0lu;
    }
    bool UnPlug(uint64_t n = 1) {
        uint64_t expected = _plug_count.load(std::memory_order_relaxed);
        do {
            PSVR_ASSERT(expected >= n);
        } while (!_plug_count.compare_exchange_strong(expected, expected - n));
        return expected == n;
    }

    size_t Size() const { return _plug_count.load(std::memory_order_relaxed); }

private:
    char pad0 BAIDU_CACHELINE_ALIGNMENT;
    std::atomic<uint64_t> _plug_count;
};

class LogBlockQueue : public UniqueRunningTask {
public:
    LogBlockQueue() : _last_lsn(0), _log_block_size(0) {}
    FUNC_MOCK ~LogBlockQueue() {}

    void SetlastLsn(gaia_apply::lsn_t lsn) {
        std::unique_lock lm(_mutex);
        _last_lsn = lsn;
    }

    // data logblock
    bool PushBack(LogBlockPtr lb, gaia_apply::lsn_t* last_lsn = nullptr) {
        std::unique_lock lm(_mutex);
        if (last_lsn) {
            *last_lsn = _last_lsn;
        }
        if (_last_lsn != lb->start_lsn) {
            return false;
        }
        PSVR_ASSERT(_last_lsn == lb->start_lsn);
        _log_block_list.emplace_back(lb);
        _last_lsn = lb->end_lsn;
        ++_log_block_size;
        return true;
    }
    // event logblock
    void PushFront(LogBlockPtr lb) {
        std::unique_lock lm(_mutex);
        _log_block_list.emplace_front(lb);
        ++_log_block_size;
    }

    LogBlockPtr Pop(uint64_t fit_max_size = 0) {
        std::unique_lock lm(_mutex);
        if (_log_block_list.empty()) {
            return nullptr;
        }
        auto lb = _log_block_list.front();
        if (fit_max_size > 0 && lb->buf_size > fit_max_size) {
            return nullptr;
        }
        _log_block_list.pop_front();
        --_log_block_size;
        return lb;
    }

    size_t log_block_size() const {
        return _log_block_size;
    }

private:
    char pad1 BAIDU_CACHELINE_ALIGNMENT;
    mutable std::mutex _mutex;
    std::list<LogBlockPtr> _log_block_list;
    gaia_apply::lsn_t _last_lsn;
    char pad2 BAIDU_CACHELINE_ALIGNMENT;
    std::atomic<size_t> _log_block_size;
};

enum fSegmentInvalid : uint32_t {
    fSegmentIsNull = 1,
    fSegmentIsStop = 1<<1,
    fSegmentIsDelete = 1<<2,
    fSegmentIsDisable = 1<<3,
    fSegmentIsInvalied = fSegmentIsNull | fSegmentIsStop | fSegmentIsDelete | fSegmentIsDisable,
};

bool segment_is_valid(SegmentPtr segment);
bool segment_is_valid_exclude(SegmentPtr segment, uint32_t flag);
uint64_t calc_physical_offset_by_extent_id(uint32_t physical_extent_id, uint32_t logical_page_no);
gaiadb::common::extent_t calc_begin_extent_id(uint32_t logical_page_no);

template <typename OffsetCache>
bool get_physical_offset_from_cache(const OffsetCache& offset_cache,
        gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no,
        uint64_t* physical_offset) {
    const auto aligned_fold = fold_space_page_align(
            fold_space_page_t(space_id, page_no));
    uint32_t physical_extent_id = 0;
    if (!offset_cache.Get(fold_space_page_to_key(aligned_fold), &physical_extent_id)) {
        return false;
    }
    *physical_offset = calc_physical_offset_by_extent_id(
            physical_extent_id, page_no);
    return true;
}

constexpr uint32_t SegmentMetaVersion = 2;

struct MetaData {
    std::string cluster_id;
    uint32_t segment_id;
    uint64_t segment_size;
    uint32_t replica_id;
    uint32_t version;
    std::string status;
    std::string manager_address;
    uint32_t meta_version;
    std::string rebalance_from;
    uint64_t rebalance_version;
};

struct StageInfo {
    friend std::ostream& operator<<(std::ostream& os, const StageInfo& stage_info);

    StageInfo()
        : _fetch(pspb::FetchStageUnInit),
        _fetch_action(0),
        _parse(pspb::ParseStageUnInit),
        _parse_action(0),
        _append(pspb::AppendStageUnInit),
        _append_action(0),
        _gc(pspb::GCStageUnInit),
        _gc_action(0),
        _recovery(pspb::RecoverStageUnInit),
        _recovery_action(0),
        _dblwr(pspb::DblwrStageUnInit),
        _dblwr_action(0) {}

    void SetStage(pspb::SegmentStage stage, uint32_t action) {
        if (stage < pspb::ParseStageUnInit) {
            _fetch.store(stage);
            _fetch_action.store(action);
        } else if (stage < pspb::AppendStageUnInit) {
            _parse.store(stage);
            _parse_action.store(action);
        } else if (stage < pspb::GCStageUnInit) {
            _append.store(stage);
            _append_action.store(action);
        } else if (stage < pspb::RecoverStageUnInit) {
            _gc.store(stage);
            _gc_action.store(action);
        } else if (stage < pspb::DblwrStageUnInit) {
            _recovery.store(stage);
            _recovery_action.store(action);
        } else {
            _dblwr.store(stage);
            _dblwr_action.store(action);
        }
    }

    void GetStageInfos(const Segment* segment,
            google::protobuf::RepeatedPtrField<pspb::SegmentStageInfo>* infos) const;

private:
    std::atomic<pspb::SegmentStage> _fetch;
    std::atomic<uint32_t> _fetch_action;
    std::atomic<pspb::SegmentStage> _parse;
    std::atomic<uint32_t> _parse_action;
    std::atomic<pspb::SegmentStage> _append;
    std::atomic<uint32_t> _append_action;
    std::atomic<pspb::SegmentStage> _gc;
    std::atomic<uint32_t> _gc_action;
    std::atomic<pspb::SegmentStage> _recovery;
    std::atomic<uint32_t> _recovery_action;
    std::atomic<pspb::SegmentStage> _dblwr;
    std::atomic<uint32_t> _dblwr_action;
};

std::ostream& operator<<(std::ostream& os, const StageInfo& stage_info);

class Segment {
friend struct Statistic;
public:

enum class Status : uint32_t {
    kPrepare = 1,
    kCreating,
    kOpen,
    kDelete,
    kUnknown,
};

constexpr static uint32_t kUnInit = 0;
constexpr static uint32_t kInitMeta = 1;
constexpr static uint32_t kInitDB = 2;
constexpr static uint32_t kInitAppendDB = 4;
constexpr static uint32_t kInitSucc = 7;  // kInitMeta | kInitDB | kInitAppendDB
constexpr static uint32_t kInitError = 8;  //

constexpr static uint64_t kUnknownVersion = 0;
constexpr static int32_t kUnknownStoreID = 0;
constexpr static gaiadb::common::replica_t kUnknownReplicaID = 0;

constexpr static bool DB_CREATE_IF_MISSING = true;
constexpr static bool DB_OPEN_EXISTS = false;

    Segment(ControlWeakPtr control,
            const std::string& cluster_id,
            gaiadb::common::segment_t segment_id,
            gaiadb::common::replica_t replica_id,
            uint64_t version,
            uint64_t segment_size,
            bool enable_punch_hole,
            Status status,
            const std::string& db_path,
            int32_t store_id,
            ClusterPtr cluster);
    FUNC_MOCK ~Segment();

    const char* status2str() {
        return status2str(_status.load());
    }
    const char* status2str(Status s) {
        switch (s) {
        case Status::kPrepare:
            return "Prepare";
        case Status::kCreating:
            return "Creating";
        case Status::kOpen:
            return "Open";
        case Status::kDelete:
            return "Delete";
        default:
            PSVR_ASSERT(false);
            return "Unknown";
        }
    }

    static Status str2status(const std::string& str) {
        if (str == "Prepare") {
            return Status::kPrepare;
        } else if (str == "Creating") {
            return Status::kCreating;
        } else if (str == "Open") {
            return Status::kOpen;
        } else if (str == "Delete") {
            return Status::kDelete;
        } else {
            return Status::kUnknown;
        }
    }

    const char* initflag2str() {
        auto flag = _init_flag.load(std::memory_order_relaxed);
        if (flag == kInitError) {
            return "InitError";
        } else if (flag == kInitSucc) {
            return "InitSucc";
        } else if (flag & kInitDB) {
            return "InitDB";
        } else if (flag & kInitMeta) {
            return "InitMeta";
        } else {
            return "UnInit";
        }
    }

    bool is_prepare() const { return _status.load() == Status::kPrepare; }
    bool is_delete() const { return _status.load() == Status::kDelete; }
    bool is_active() const { return _status.load() == Status::kOpen; }

    bool is_stopped() const { return _stopped.load(std::memory_order_relaxed); }

    bool is_init() const { return _init_flag.load() == kInitSucc; }
    bool is_init_db() const { return (_init_flag.load() & kInitDB) > 0; }
    bool is_init_append_db() const { return (_init_flag.load() & kInitAppendDB) > 0; }
    void set_init_error() { _init_flag.store(kInitError); }

    /* 1 is default value
     * 0 fetch fail
     * 2 fetch ok */
    bool is_invalid_start_lsn() const { return _is_invalid_start_lsn.load() == 0; }
    void set_is_invalid_start_lsn(bool s) { _is_invalid_start_lsn.store(s ? 0 : 2); }
    bool is_start_lsn_ok() const { return _is_invalid_start_lsn.load() > 1; }

    bool is_disable() const { return _disable.load(); }

    const std::string& key() const { return _key; }
    int64_t start_time() const { return _start_time; }
    const std::string& cluster_id() const { return _cluster_id; }
    gaiadb::common::segment_t segment_id() const { return _segment_id; }
    gaiadb::common::replica_t replica_id() const { return _replica_id.load(); }
    uint64_t version() const { return _version.load(); }
    uint64_t segment_size() const { return _segment_size; }
    bool enable_punch_hole() const { return _enable_punch_hole; }
    uint64_t segment_physical_size() const { return _segment_physical_size.load(std::memory_order_relaxed); }
    uint64_t append_db_size() const { return _append_db_size.load(std::memory_order_relaxed); }
    void set_meta_version(uint32_t v) { _meta_version = v; }

    gaia_apply::lsn_t ls_vdl() const { return _ls_vdl(); }
    gaia_apply::lsn_t ls_write_lsn() const { return _ls_write_lsn(); }
    gaia_apply::lsn_t ls_parse_lsn() const { return _ls_parse_lsn(); }
    gaia_apply::lsn_t ls_dispatch_lsn() const { return _ls_dispatch_lsn(); }
    void set_ls_lsn(gaia_apply::lsn_t vdl,
            gaia_apply::lsn_t write_lsn,
            gaia_apply::lsn_t parse_lsn,
            gaia_apply::lsn_t dispatch_lsn) {
        _ls_vdl(vdl, true);
        _ls_write_lsn(write_lsn, true);
        _ls_parse_lsn(parse_lsn, true);
        _ls_dispatch_lsn(dispatch_lsn, true);
        set_is_invalid_start_lsn(false);
    }

    void CopyTo(SegmentPtr segment);

    gaia_apply::lsn_t start_checkpoint_lsn() const { return _start_checkpoint_lsn; }

    gaia_apply::lsn_t fetch_lsn() const { return _fetch_lsn(); }
    gaia_apply::lsn_t parse_lsn() const { return _parse_lsn(); }
    gaia_apply::lsn_t append_lsn() const { return _append_lsn(); }
    gaia_apply::lsn_t gc_lsn() const { return _gc_lsn(); }
    gaia_apply::lsn_t append_gc_lsn() const { return std::max(append_lsn(), _start_lsn); }
    void set_gc_lsn(gaia_apply::lsn_t lsn) { _gc_lsn(lsn, true); }
    gaia_apply::lsn_t peer_gc_lsn() const { return _peer_gc_lsn(); }
    void set_peer_gc_lsn(gaia_apply::lsn_t lsn) { _peer_gc_lsn(lsn, true); }
    void set_seg_lowest_gc_lsn(gaia_apply::lsn_t lsn) { _seg_lowest_gc_lsn(lsn, true); }
    gaia_apply::lsn_t seg_lowest_gc_lsn() const { return _seg_lowest_gc_lsn(); }
    gaia_apply::lsn_t recovery_lsn() const { return _recovery_lsn(); }
    int32_t store_id() const { return _store_id; }
    const std::string& db_path() const { return _db_path; }
    uint32_t hash_val() const { return _hash_val; }

    int64_t wakeup_fetch() { return _wakeup_fetch_nr.fetch_add(1, std::memory_order_relaxed); }
    void clear_wakeup_fetch() { _wakeup_fetch_nr.store(0, std::memory_order_relaxed); }

    void set_fetch_ctx(void* ctx) { _fetch_ctx = ctx; }
    void* fetch_ctx() { return _fetch_ctx; }

    void set_fetch_batch_idx(int32_t idx) { _fetch_batch_idx = idx; }
    int32_t fetch_batch_idx() const { return _fetch_batch_idx; }

    void set_last_fetch_time(int64_t t) { _last_fetch_time = t; }
    int32_t last_fetch_time() const { return _last_fetch_time; }

    void set_fetch_quota_state(pspb::QuotaState st) { _fetch_quota_state = st; }
    pspb::QuotaState fetch_quota_state() const { return _fetch_quota_state; }

    int64_t wakeup_dblwr() { return _wakeup_dblwr_nr.fetch_add(1, std::memory_order_relaxed); }
    void clear_wakeup_dblwr() { _wakeup_dblwr_nr.store(0, std::memory_order_relaxed); }

    void set_dblwr_ctx(void* ctx) { _dblwr_ctx = ctx; }
    void* dblwr_ctx() { return _dblwr_ctx; }

    rwlock_t& light_shared_mutex() { return _light_shared_mutex; }

    gaiadb::RecoveryStatus recovery_status() const {
        return _recovery_status.load();
    }
    bool in_recovery() const { return recovery_status() == gaiadb::RECOVERY_IN; }
    bool recovery_status_is_finish() const { return recovery_status() == gaiadb::RECOVERY_FINISH; }

    ClusterPtr cluster() { return _cluster; }
    uint32_t GetClusterHashVal() const;
    gaia_apply::lsn_t GetClusterCnLowestLsn() const;
    void SetClusterCnLowestLsn(gaia_apply::lsn_t lsn);
    void SetClusterCnLowestGcLsn(gaia_apply::lsn_t lsn);
    gaia_apply::lsn_t GetClusterPsLowestLsn() const;
    void SetClusterPsLowestLsn(gaia_apply::lsn_t lsn);
    void SetClusterPsLowestGcLsn(gaia_apply::lsn_t lsn);

    void InitPsmInfo(PsmInfoPtr psm_info);
    FUNC_MOCK bool ResetPsmInfo(PsmInfoPtr psm_info);
    PsmInfoPtr GetPsmInfo();

    FUNC_MOCK bool GetSpaceReqLock(gaia_apply::space_id_t space_id);
    void PutSpaceReqLock(gaia_apply::space_id_t space_id);

    FUNC_MOCK bool GetSpaceExtentReqLock(gaia_apply::space_id_t space_id,
            uint32_t begin_extent_id);
    void PutSpaceExtentReqLock(gaia_apply::space_id_t space_id,
            uint32_t begin_extent_id);

    bool GetRebalanceNode(std::string* from, uint64_t* version);
    void SetRebalanceNode(const std::string& from, uint64_t version);
    void ClearRebalanceNode();

    void SetCompressConfig(const pspb::CompressConfig& cfg);
    void GetCompressConfig(pspb::CompressConfig* cfg);

    const StatCompress& stat_compress() const { return _stat_compress; }
    FUNC_MOCK void UpdateStatCompress(int64_t& sum_non_empty_page_count, int64_t& sum_compress_data_size);
    void LoadComperssLogNoLock();
    void CompressFinish(bool succ, int64_t non_empty_page_count, int64_t last_compress_data_size);

    int64_t stat_last_trim_extent_time() const { return _stat_last_trim_extent_time; }
    void set_stat_last_trim_extent_time(int64_t time_s) { _stat_last_trim_extent_time = time_s; }

    void set_stage_info(pspb::SegmentStage stage) {
        _stage_info.SetStage(stage, 0);
    }

    template<typename T>
    void set_stage_info(pspb::SegmentStage stage, T action) {
        _stage_info.SetStage(stage, static_cast<uint32_t>(action));
    }

    void get_stage_infos(
            google::protobuf::RepeatedPtrField<pspb::SegmentStageInfo>* infos) const {
        _stage_info.GetStageInfos(this, infos);
    }

    const StageInfo& stage_info() const { return _stage_info; }

    void Stop();
    FUNC_MOCK bool LoadEngineWithMeta(const gaiapb::PageServerInfo& meta);
    FUNC_MOCK bool InitMeta(const gaiapb::PageServerInfo& meta);
    FUNC_MOCK bool InitLsn(const gaiapb::PageServerInfo& meta);
    FUNC_MOCK bool InitConfig(const gaiapb::PageServerInfo& meta, bool is_created);
    FUNC_MOCK bool CreateMeta(const std::string& trash_path);
    FUNC_MOCK bool CreateEngine(const std::string& trash_path);
    FUNC_MOCK bool OpenEngine(bool create_if_missing);
    FUNC_MOCK bool CloseEngine();
    FUNC_MOCK bool Delete();
    FUNC_MOCK bool ReOpen(const gaiapb::PageServerInfo& meta);
    FUNC_MOCK bool UpdateMetaVersionIf();
    FUNC_MOCK void Sync();

    FUNC_MOCK bool GetPreDisable();
    void PutPreDisable();
    FUNC_MOCK bool PreDisable();
    FUNC_MOCK bool Disable();

    void UpdateDBSize();

    bool EnableQuota(int64_t size) const { return _fetch_quota->Enable(size); }
    bool GetQuota(int64_t size) { return _fetch_quota->Acquire(size); }
    void PutQuota(int64_t size) { return _fetch_quota->Release(size); }

    LogBlockQueue& fetch_log_block_queue() { return _fetch_log_block_queue; }
    const LogBlockQueue& fetch_log_block_queue() const { return _fetch_log_block_queue; }
    LogBlockQueue& parse_log_block_queue() { return _parse_log_block_queue; }
    const LogBlockQueue& parse_log_block_queue() const { return _parse_log_block_queue; }
    LogBlockQueue& append_log_block_queue() { return _append_log_block_queue; }
    const LogBlockQueue& append_log_block_queue() const { return _append_log_block_queue; }

    FUNC_MOCK uint32_t GetSpaceStatus(gaia_apply::space_id_t id) const;
    bool SetSpaceStatus(gaia_apply::space_id_t id, uint32_t s);
    void ClearUseLessSpaceStatus();
    FUNC_MOCK size_t GetSpaceStatusCount() const;

    FUNC_MOCK uint32_t GetSpaceEncryptStatus(gaia_apply::space_id_t id) const;
    bool SetSpaceEncryptStatus(gaia_apply::space_id_t id, uint32_t s);

    gaia_apply::lsn_t GetSpaceSafeTrimLsn(gaia_apply::space_id_t id);
    bool SetSpaceSafeTrimLsn(gaia_apply::space_id_t id, gaia_apply::lsn_t lsn);

    FUNC_MOCK PagePtr GetPage(gaia_apply::space_id_t id,
            gaia_apply::page_no_t page_no, bool create_if_missing = false);

    void InitSpaceStatusWithPsm(gaia_apply::space_id_t id, bool not_exists);
    void InitAllSpaceId(const gaiapb::GetAllSpaceIdsResponse& rsp);

    FUNC_MOCK bool AddFetchLogBlock(LogBlockPtr log_block);
    void AddParseLogBlock(LogBlockPtr log_block);
    void AddAppendLogBlock(LogBlockPtr log_block);

    LogBlockPtr NextParseLogBlock(bool plug);
    LogBlockPtr NextAppendLogBlock(bool plug, uint64_t unplug_size = 1);
    LogBlockPtr NextGcLogBlock(bool plug, uint64_t plug_size = 1);

    FUNC_MOCK bool ParseLogBlockToLogRecords(int64_t log_id, LogBlockPtr log_block);

    void SetGcDelayForRecovery(bool delay);
    FUNC_MOCK bool GcDelayForRecovery(gaia_apply::lsn_t lsn);
    void DropSpace(gaia_apply::space_id_t id, gaia_apply::lsn_t lsn);

    void RetryPushGcLsn(LogBlockPtr log_block, const LogBlockChunk& chunk);
    void PushGcLsn(LogBlockPtr log_block);

    FUNC_MOCK bool ExistSpacePagePhysicalOffset(gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no);
    FUNC_MOCK bool GetSpacePagePhysicalOffset(gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no,
            uint64_t* physical_offset, bool* data_invalid = nullptr);
    void SetSpaceExtent(const event_space_extent_t& fold, ExtentArg extent_arg,
            bool not_exists, const gaiapb::GetSpaceExtentMapResponse& response);
    void SetSpaceExtent(gaia_apply::space_id_t space_id, uint32_t begin_extent_id,
            ExtentArg extent_arg, bool not_exists, const gaiapb::GetSpaceExtentMapResponse& response);

    bool GetPeerReqLock() { return _peer_info.lock.try_lock(); }
    void PutPeerReqLock() { return _peer_info.lock.unlock(); }

    uint64_t peer_last_recover_time_s() const { return _peer_last_recover_time_s(); }
    void UpdatePeerLastRecoverTime();

    FUNC_MOCK bool GetPeerNodes(std::vector<gaiadb::common::PeerZone>* replicas, bool need_random = true);
    void UpdatePeerNodes(gaiadb::common::segment_t segment_id,
            bool not_exists, const gaiapb::GetSegmentResponse& response);

    void MovePeerNodeToFirst(uint32_t idx, const base::EndPoint& node);
    void MovePeerNodeToFirst(uint32_t idx, const gaiadb::common::PeerZone& node);
    void SetPeerNodeFailed(uint32_t idx, const base::EndPoint& node);
    void SetPeerNodeFailed(uint32_t idx, const gaiadb::common::PeerZone& node);

    bool EnableCheckAgain(int64_t interval_us);
    bool TurnOnRecovery(bool is_force);
    void TurnOffRecovery();
    FUNC_MOCK bool StartRecovery();
    void FinishRecovery();

    FUNC_MOCK bool RecoveryStoped();
    FUNC_MOCK bool GetRecoveryNextBlockTask(RecoverBlockTask* task);
    FUNC_MOCK void FinishRecoveryBlockTask(const RecoverBlockTask& task);

    FUNC_MOCK bool AddGcPageInRecovery(db::PageLockPtr page_lock,
            gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no,
            gaia_apply::lsn_t min_lsn, bool* retry);
    FUNC_MOCK void AddGcDropSpaceInRecovery(gaia_apply::space_id_t space_id,
            gaia_apply::lsn_t lsn);
    FUNC_MOCK bool CheckGcPageInRecovery(db::PageLockPtr page_lock,
            gaia_apply::lsn_t* page_min_lsn, gaia_apply::lsn_t* min_lsn);
    FUNC_MOCK bool DropGcPageInRecovery(db::PageLockPtr page_lock, gaia_apply::lsn_t lsn);
    FUNC_MOCK bool CheckRecovery();

    uint64_t GetRecoveryMaxSize() const;
    void GetRecoveryStatus(bool* status, bool* is_force) const;
    void GetRecoveryInfo(pspb::GetRecoverInfoResponse* rsp) const;
    void GetRecoveryInfo(pspb::MultiGetRecoverInfoResponse::Segment* seg) const;
    void GetRecoveryInfo(pspb::ListRecoveryInfoResponse::Segment* rsp) const;

    db::PageLockPtr GetPageLock(uint64_t physical_page_no);

private:
    FUNC_MOCK db::Status ReadPageDataNoLock(int64_t log_id,
            gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no,
            uint64_t physical_offset, BufBlockPtr buf_block);

    FUNC_MOCK db::Status WritePageDataNoLock(int64_t log_id,
            gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no,
            uint64_t physical_offset, uint64_t size, void* buf);

public:
    FUNC_MOCK db::Status ApplyPageLogRecordsNoLock(int64_t log_id,
            uint64_t physical_offset,
            gaia_apply::lsn_t max_apply_lsn, BufBlockPtr buf_block,
            LogRecordIteratorInterface& iter, uint32_t* apply_size);

    FUNC_MOCK db::Status ApplyAppendRedoToPageNoLock(int64_t log_id,
            uint64_t physical_offset,
            gaia_apply::lsn_t start_lsn,
            gaia_apply::lsn_t apply_end_lsn,
            BufBlockPtr buf_block, AppendReadBuf* read_buf = nullptr);

    int64_t GetPhysicalPageCompressSize(const gaia_apply::byte* page);

    FUNC_MOCK db::Status ReadPhysicalPageDataWithDblwr(int64_t log_id,
            uint64_t physical_offset, uint64_t size, void* buf);

    FUNC_MOCK db::Status ReadPhysicalPageDataWithDblwr(int64_t log_id,
            uint64_t physical_offset, uint64_t size, void* buf, bool* is_compressed, uint64_t* real_write_size);

    FUNC_MOCK db::Status ReadPhysicalPageData(int64_t log_id,
            uint64_t physical_offset, uint64_t size, void* buf);

    FUNC_MOCK db::Status ReadPhysicalPageData(int64_t log_id,
            uint64_t physical_offset, uint64_t size, void* buf, bool* is_compressed, uint64_t* real_write_size);

    FUNC_MOCK db::Status WritePhysicalPageData(int64_t log_id, gaia_apply::space_id_t space_id,
            gaia_apply::page_no_t logical_page_no, uint64_t physical_offset, uint64_t size, void* buf);

    FUNC_MOCK db::Status WritePhysicalPageData(int64_t log_id, gaia_apply::space_id_t space_id,
            gaia_apply::page_no_t logical_page_no, uint64_t physical_offset, uint64_t size, void* buf,
            bool compress, uint64_t* real_write_size);

    FUNC_MOCK db::Status TrimPhysicalPageData(int64_t log_id,
            gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no,
            uint64_t physical_offset, uint64_t size, bool is_empty_page);

    FUNC_MOCK db::Status ReadPageData(int64_t log_id, TimePoint* tp,
            gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no,
            uint64_t physical_offset, gaia_apply::lsn_t max_apply_lsn,
            BufBlockPtr buf_block, bool* page_is_empty, gaia_apply::lsn_t* real_apply_lsn);
    FUNC_MOCK db::Status WritePageData(int64_t log_id, TimePoint* tp,
            gaia_apply::space_id_t space_id, gaia_apply::page_no_t logical_page_no,
            uint64_t physical_offset, gaia_apply::lsn_t max_apply_lsn, gaia_apply::lsn_t record_end_lsn,
            bool incomplete_gc);

    void UpdateAppendSize();
    uint64_t GetAppendUnGcSize();

    FUNC_MOCK db::Status AppendLog(LogBlockPtr log_block);

    FUNC_MOCK db::Status AppendRecover(gaia_apply::lsn_t start_lsn,
        db::LogHeader* log_header, AppendInfo* append_info,
        base::Slice* offset_cache, base::Slice* redo, char** log_buf);
    FUNC_MOCK db::Status FinishAppendRecover();

    FUNC_MOCK bool AppendRecoverFetchFinish();
    FUNC_MOCK bool AppendRecoverParseFinish();
    FUNC_MOCK bool AppendRecoverGcFinish();
    db::Status AppendPreRecoverNextLog();

    FUNC_MOCK db::Status GetLogBlockOffCache(LogBlockPtr log_block);
    FUNC_MOCK db::Status UpdateAppendDBCheckPoint(gaia_apply::lsn_t lsn, bool is_dblwr_dump = false);
    FUNC_MOCK gaia_apply::lsn_t GetAppendDBCheckPointLsn() const;
    FUNC_MOCK db::Status ClearAppendDB();

    DblwrPtr dblwr() { return _dblwr; }
    const DblwrPtr dblwr() const { return _dblwr; }
    FUNC_MOCK bool DblwrHasBufs() const;
    FUNC_MOCK db::Status DumpDblwrBuf(int64_t log_id);
    FUNC_MOCK db::Status SealDblwrTimeout(int64_t timeout_us);

    FUNC_MOCK db::Status FetchRedoLog(gaia_apply::lsn_t fetch_lsn,
            base::Slice* key, base::Slice* value, char** buf,
            uint32_t* key_crc, uint32_t* value_crc, uint32_t* records_count, uint32_t* fold_size,
            gaia_apply::lsn_t *next_seek_lsn,
            uint64_t& block_no, uint64_t& block_offset,
            AppendReadBuf* read_buf = nullptr);

    FUNC_MOCK void ReadPeerPage(ReadPeerPageContext* ctx, ggpb::Closure* closure);

    std::shared_ptr<Statistic> statistic() { return _statistic; }
private:
    bool InitPathNoLock(const std::string& trash_path);
    bool InitLsnNoLock(const gaiapb::PageServerInfo& meta);
    bool InitConfigNoLock(const gaiapb::PageServerInfo& meta);
    bool OpenEngineNoLock(bool create_if_missing);
    bool CloseEngineNoLock(Status status, uint32_t init_flag);
    void InitVersionNoLock(const gaiapb::PageServerInfo& meta);
    void CopyMetaDataForStore(MetaData* meta_data);
    bool StoreMetaNoLock(const MetaData& meta_data);
    bool StoreMetaNoLock();
    void SetCompressConfigNoLock(bool enable, const std::string& name, int32_t level);
    void GetCompressConfigNoLock(pspb::CompressConfig* cfg);
    void UpdateDBSizeNoLock();

    void OnReadPeerPage(ReadPeerPageContext* ctx, ggpb::Closure* closure, RpcRbioCtx* rpc_ctx);

private:
    // for status
    volatile std::atomic<Status> _status;
    volatile std::atomic<uint32_t> _init_flag;
    volatile std::atomic<bool> _stopped;
    volatile std::atomic<int32_t> _is_invalid_start_lsn;
    volatile std::atomic<bool> _disable;
    ControlWeakPtr _control;
    // for init
    const int64_t _start_time;
    const std::string _cluster_id;
    const gaiadb::common::segment_t _segment_id;
    const std::string _key;
    const uint64_t _segment_size;
    const bool _enable_punch_hole;
    CompressConfig _compress_cfg;
    CONST_MOCK ClusterPtr _cluster;  // cluster* const _cluster
    PsmInfoPtr _psm_info;   // lock
    uint32_t _meta_version;
    std::atomic<uint64_t> _segment_physical_size;
    std::atomic<uint64_t> _append_db_size;
    std::atomic<uint64_t> _append_un_gc_size;
    std::atomic<gaiadb::common::replica_t> _replica_id;  // for load snapshot data
    std::atomic<uint64_t> _version;
    gaia_apply::lsn_t _start_checkpoint_lsn;
    gaia_apply::lsn_t _last_apply_lsn;
    gaia_apply::lsn_t _start_lsn;
    std::atomic<gaiadb::RecoveryStatus> _recovery_status;
    const uint32_t _hash_val;
    std::atomic<bool> _pre_disable;
    std::atomic<int64_t> _wakeup_fetch_nr;
    void* _fetch_ctx;
    std::atomic<int32_t> _fetch_batch_idx;
    std::atomic<int64_t> _last_fetch_time;
    std::atomic<pspb::QuotaState> _fetch_quota_state;
    std::atomic<int64_t> _wakeup_dblwr_nr;
    void* _dblwr_ctx;
    // for work status
    std::shared_ptr<Quota> _fetch_quota;
    Lsn _ls_vdl;
    Lsn _ls_write_lsn;
    Lsn _ls_parse_lsn;
    Lsn _ls_dispatch_lsn;
    Lsn _fetch_lsn;
    Lsn _parse_lsn;
    Lsn _append_lsn;
    Lsn _gc_lsn;
    Lsn _peer_gc_lsn;
    Lsn _recovery_lsn;
    Lsn _seg_lowest_gc_lsn;
    gaia_apply::lsn_t _db_checkpoint_lsn;
    gaia_apply::lsn_t _db_append_lsn;
    gaia_apply::lsn_t _dblwr_checkpoint_lsn;
    std::atomic<int32_t> _gc_delay_flag;
    LogBlockQueue _fetch_log_block_queue;
    LogBlockQueue _parse_log_block_queue;
    LogBlockQueue _append_log_block_queue;
    CONST_MOCK std::string _db_path;
    const int32_t _store_id;
    bool _db_is_init;
    // for rebalance
    std::string _rebalance_from;
    uint64_t _rebalance_version;
    // for peer
    PeerInfo _peer_info;
    UpdateIfBigger<uint64_t> _peer_last_recover_time_s;
    RecoveryInfo _recovery_info;
    StatCompress _stat_compress;
    StageInfo _stage_info;
    int64_t _stat_last_trim_extent_time {0};
    // for resource
    DBEnginePtr _db_engine;
    AppendDBEnginePtr _append_db_engine;
    DblwrPtr _dblwr;
    std::shared_ptr<SpacePageManager> _space_page_manager;
    std::shared_ptr<SpaceStatusManager> _space_status_manager;
    std::shared_ptr<ExtentMetaManager> _extent_meta_manager;
    InflightReqLock<gaia_apply::space_id_t> _inflight_space_reqs;
    InflightReqLock<uint64_t> _inflight_space_extent_reqs;
    std::shared_ptr<Statistic> _statistic;
    rwlock_t _light_shared_mutex;
    rwlock_t _shared_mutex;
};

}
