/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server_status.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ListPageServerStatus : public Command {
public:
    ListPageServerStatus() {
        SetName("list-ps-status");
        SetDesc("list segment status and store statistic in page server");
        SetDescCn("列出存储服务器上分片状态和存储统计信息");

        AddClusterAndNodeOptions();
        AddRequiredArgOption("cluster-id", NULL, 'c',
                "list only segments matched by the cluster id",
                kstring, kGroup2Scope);
        AddRequiredArgOption("segment-id", NULL, 's',
                "list matched by the segment id, if specified",
                kuint32_t, kGroup2Scope);
        AddRequiredArgOption("multi-segment", &_long_opt_val,
                kOptMax + 1, "in multi type. list segments you want",
                kjson, kOnlyMultiPSScope | kGroup2Scope);
        AddOptionalArgOption("show-store", &_long_opt_val,
                kOptMax + 2,
                "display the store statistic information, if specified",
                kbool, kOnlyMultiPSScope | kGroup3Scope);
        AddNoArgOption("only-show-store", &_long_opt_val,
                kOptMax + 3,
                "only display the store statistic information, if specified",
                kOnlyMultiPSScope | kGroup3Scope);
        AddRequiredArgOption("output-iplist", &_long_opt_val,
                kOptMax + 4,
                "output server address list sorted by topology_zone to the specified file",
                kstring, kOnlyMultiPSScope | kGroup3Scope);
        AddNoArgOption("show-stage-infos", &_long_opt_val,
                kOptMax + 5,
                "display segment stage information",
                kOnlyMultiPSScope | kGroup3Scope);

        AddExample("--cluster-addr bns://xxx --cluster-id xx --segment-id 1");
        AddExample("-a <ip> -p <port> --cluster-id xx --segment-id 1");
        AddExample("-m --cluster-addr bns:/xxx");
        AddExample("-m --cluster-addr bns:/xxx --cluster-id xx");
        AddExample("-m --cluster-addr bns:/xxx --cluster-id xx --segment-id 1");
        AddExample("-m -a <ip> -p <port> --cluster-id xx");
        AddExample("-m -a <ip> -p <port> --cluster-id xx --segment-id 1");
        AddExample("-m -a <ip> -p <port> --multi-segment "
                "'{\"segments\":[{\"cluster_id\": \"gaia-test-perf\", \"segment_id\": 1}]}'");
        AddExample("-m --cluster-addr bns:/xxx --multi-segment "
                "'{\"segments\":[{\"cluster_id\": \"gaia-test-perf\"}]}'");
        AddExample("-m -a <ip> -p <port> --show-store");
        AddExample("-m --cluster-addr bns:/xxx --show-store");
        AddExample("-m --cluster-addr bns:/xxx --only-show-store");
        AddExample("-m --cluster-addr bns:/xxx --output-iplist iplist.txt");
    }
    virtual ~ListPageServerStatus() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtol(opt, NULL, 10));
            break;
        case 'C':
            _cluster_addr = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _segments = opt;
                break;
            case kOptMax + 2:
                _show_store = opt ? !!std::strtol(opt, NULL, 10) : true;
                break;
            case kOptMax + 3:
                _only_show_store = true;
                break;
            case kOptMax + 4:
                _only_show_store = true;
                _output_iplist = opt;
                break;
            case kOptMax + 5:
                _show_stage_infos = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;
private:
    int Execute(const base::EndPoint& node,
            pspb::GetStatusResponse* response, RpcStatus* status, ggpb::Closure* closure);
    int Execute(const base::EndPoint& node,
            pspb::MultiGetStatusResponse* response, RpcStatus* status, ggpb::Closure* closure);

    void Done(pspb::BatchGetStatusResponse_ServerStatus* server_status,
            pspb::GetStatusResponse* response, RpcStatus* status);
    void Done2(pspb::BatchMultiGetStatusResponse_ServerStatus* server_status,
            pspb::MultiGetStatusResponse* response, RpcStatus* status);

    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::GetStatusResponse& rsp);
    int Format(const pspb::BatchGetStatusResponse& rsp);
    int Format(const pspb::MultiGetStatusResponse& rsp);
    int Format(const pspb::BatchMultiGetStatusResponse& rsp);
private:
    std::string _cluster_addr {};
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
    std::string _segments {};
    bool _show_store {false};
    bool _only_show_store {false};
    bool _show_stage_infos {false};
    std::string _output_iplist {};
    std::atomic<uint64_t> _task_count {0};
};

}
}
