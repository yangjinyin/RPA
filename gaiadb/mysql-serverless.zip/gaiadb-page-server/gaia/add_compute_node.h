/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/add_compute_node.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class AddComputeNode : public Command {
public:
    AddComputeNode() {
        SetName("add-compute-node");
        SetDesc("add compute node to manager");
        SetDescCn("添加计算节点到管理服务");

        AddPsmClusterOption();
        AddRequiredArgOption("addr", &_long_opt_val, kOptMax + 1, "server endpoint information", kip_port);
        AddZoneOption();
        AddRequiredArgOption("server-id", &_long_opt_val, kOptMax + 2, "server id", kstring);
        AddNoArgOption("is-primary", &_long_opt_val, kOptMax + 3, "set server as primary", kGroup2Scope);

        AddExample("--manager-address \"bns://xxx\" --server-id x --addr <ip:port>");
        AddExample("--manager-address \"bns://xxx\" --server-id x --addr <ip:port> --is-primary");
        AddExample("--manager-address \"bns://xxx\" --server-id x --addr <ip:port>"
                " --region bjdd --available-zone test");
    }
    virtual ~AddComputeNode() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptRegion:
                _zone.region = opt;
                break;
            case kOptAvailableZone:
                _zone.available_zone = opt;
                break;
            case kOptMax + 1:
                _addr = opt;
                break;
            case kOptMax + 2:
                _server_id = opt;
                break;
            case kOptMax + 3:
                _is_primary = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::AckResponse& rsp);

private:
    std::string _manager_address {};
    std::string _addr {};
    VarZone _zone;
    std::string _server_id {};
    bool _is_primary {false};
};

}
}
