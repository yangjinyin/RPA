/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/do_takeover_compute_node.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/do_takeover_compute_node.h"

namespace psvr {
namespace gaia {

int DoTakeOverComputeNode::Run() {
    RpcStatus status;

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    computenode::takeover_primary_request request;
    computenode::takeover_primary_response response;

    if (!_cluster_id.empty()) {
        request.set_cluster_id(_cluster_id);
    }
    if (!_task_id.empty()) {
        request.set_task_id(_task_id);
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Takeover node=%s:%d to primary?", _address.c_str(), _port);
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    _client.Call(_log_id, node, &computenode::SecondaryService_Stub::takeover_primary, &request, &response,
            nullptr, &status, _timeout_ms);
    if (status.IsOk()) {
        return Output(response);
    }

    LOG(WARNING) << node << " taskover failed, " << status << " " << response.status();
    print_error("rpc fail, %s", status.msg.c_str());
    return 1;
}

int DoTakeOverComputeNode::Format(const computenode::takeover_primary_response& rsp) {
    SHOW_CMP_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"current_task_id:", rsp.current_task_id()});
    table.Display();
    return 0;
}

}
}
