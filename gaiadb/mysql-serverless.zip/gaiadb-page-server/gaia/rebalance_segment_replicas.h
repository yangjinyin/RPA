/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/rebalance_segment_replicas.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <cmath>
#include <iomanip>
#include <iostream>
#include "gaia/command.h"

namespace psvr {
namespace gaia {

inline int64_t cacl_disk_used_thousandth(int64_t used_size, int64_t total_size) {
    return 1000 * (used_size * 1.0 / total_size);
}

static constexpr size_t kMinReserveSize = (128lu<<30);

static constexpr size_t kDiskMaxNumOfPartTotal = 8;
static constexpr size_t kClusterMaxNumOfPartTotal = 2;

static constexpr size_t kMaxNum = 24;
static constexpr size_t kDiskMaxNum = kMaxNum / kDiskMaxNumOfPartTotal;
static constexpr size_t kClusterMaxNum = kMaxNum / kClusterMaxNumOfPartTotal;

static constexpr size_t kMaxRecoveryNum = kMaxNum;
static constexpr size_t kDiskMaxRecoveryNum = kDiskMaxNum;
static constexpr size_t kClusterMaxRecoveryNum = kClusterMaxNum;

static constexpr int64_t kDiskFloatingRate = 15;

static constexpr int64_t kMinReplicaCountForRebalance = 3;

struct Replica {
    const std::string cluster_id;
    const uint32_t segment_id;
    const base::EndPoint addr;
    int64_t logical_size {0};
    int64_t physical_size {0};
    bool in_recovery {false};
    int32_t store_id {0};
    std::string manager_address;
    uint64_t version {0};
    uint32_t replica_id {0};
    bool has_rebalance {false};
    base::EndPoint rebalance_from {};
    uint64_t rebalance_version {0};
    bool is_ok {false};
    int32_t zone {0};

    Replica(const std::string& cluster_id_,
        uint32_t segment_id_,
        const base::EndPoint& addr_)
        : cluster_id(cluster_id_), segment_id(segment_id_), addr(addr_) {}
    ~Replica() {}

    std::ostream& ToString(std::ostream& os) {
        return os << "cluster=" << cluster_id
            << ", id=" << segment_id
            << ", replica_id=" << replica_id
            << ", version=" << version
            << ", addr=" << addr
            << ", store_id=" << store_id
            << ", physical_size=" << physical_size
            << ", logical_size=" << logical_size
            << ", in_recovery=" << in_recovery
            << ", zone=" << zone
            << ", is_ok=" << is_ok;
    }
};

inline std::ostream& operator<<(std::ostream& os, const std::shared_ptr<Replica>& replica) {
    return replica->ToString(os);
}

inline std::ostream& operator<<(std::ostream& os, const std::vector<std::shared_ptr<Replica>>& vec_replicas) {
    for (size_t i = 0; i < vec_replicas.size(); ++i) {
        os << i << ":" << vec_replicas[i] << ";";
    }
    return os;
}

struct Segment {
    const uint32_t id;
    int64_t replica_count {0};
    std::map<base::EndPoint, std::shared_ptr<Replica>> replica_map;
    std::map<base::EndPoint, std::shared_ptr<Replica>> rebalance_from_replica_map;
    std::map<base::EndPoint, std::shared_ptr<Replica>> rebalance_to_replica_map;
    std::map<base::EndPoint, std::shared_ptr<Replica>> in_recovery_replica_map;

    Segment(uint32_t id_) : id(id_) {}
    ~Segment() {}

    void AddReplica(std::shared_ptr<Replica> replica) {
        replica_map.emplace(replica->addr, replica);
    }

    std::shared_ptr<Replica> GetReplica(const base::EndPoint& addr) {
        if ( auto it = replica_map.find(addr); it != replica_map.end()) {
            return it->second;
        }
        return nullptr;
    }

    int64_t GetRealReplicaSum(std::vector<std::shared_ptr<Replica>>* rebalance_from_replica_vec,
            std::vector<std::shared_ptr<Replica>>* rebalance_to_replica_vec,
            std::vector<std::shared_ptr<Replica>>* in_recovery_replica_vec) {
        replica_count = replica_map.size();
        for (auto& it : replica_map) {
            auto replica = it.second;
            if (replica->in_recovery) {
                in_recovery_replica_map.emplace(replica->addr, replica);
                in_recovery_replica_vec->emplace_back(replica);
            }
            if (replica->has_rebalance && replica_count > 2) {
                if (auto from = GetReplica(replica->rebalance_from);
                        from && from->version == replica->rebalance_version) {
                    rebalance_from_replica_map.emplace(from->addr, from);
                    rebalance_to_replica_map.emplace(replica->addr, replica);
                    --replica_count;
                    rebalance_from_replica_vec->emplace_back(from);
                    rebalance_to_replica_vec->emplace_back(replica);
                }
            }
        }
        return replica_count;
    }

    bool IsValidReplica(std::shared_ptr<Replica> replica) {
        assert(replica_map.find(replica->addr) != replica_map.end());
        return rebalance_from_replica_map.find(replica->addr) == rebalance_from_replica_map.end();
    }

    std::shared_ptr<Replica> GetInRebalanceReplica() {
        for (auto& it : rebalance_from_replica_map) {
            return it.second;
        }
        return nullptr;
    }

    std::shared_ptr<Replica> GetInRecoveryReplica() {
        for (auto& it : in_recovery_replica_map) {
            return it.second;
        }
        return nullptr;
    }

    void AddNewRebalanceReplica(std::shared_ptr<Replica> from, std::shared_ptr<Replica> to) {
        assert(replica_map.find(from->addr) != replica_map.end());
        rebalance_from_replica_map.emplace(from->addr, from);
        rebalance_to_replica_map.emplace(to->addr, to);
        in_recovery_replica_map.emplace(to->addr, to);
        replica_map.emplace(to->addr, to);
    }

    std::ostream& ToString(std::ostream& os) {
        return os << "id=" << id
            << ", replica_count=" << replica_count;
    }
};

inline std::ostream& operator<<(std::ostream& os, const std::shared_ptr<Segment>& segment) {
    return segment->ToString(os);
}

struct DiskCluster {
    const std::string cluster_id;
    int64_t replica_count {0};
    double real_replica_count_on_disk_score {0.0};
    bool is_calc {false};

    std::vector<std::shared_ptr<Replica>> replica_list;
    std::vector<std::shared_ptr<Replica>>::iterator iter;

    DiskCluster(const std::string& cluster_id_) : cluster_id(cluster_id_) {
        replica_list.reserve(16);
    }
    ~DiskCluster() {}

    void PrintReplicas(std::ostream& os, int tabn) {
        for (auto& it : replica_list) {
            os << std::setw(tabn * 4) << " " << it << std::endl;
        }
    }

    void AddReplica(std::shared_ptr<Replica> replica) {
        replica_list.emplace_back(replica);
    }

    void CalcReplicaSumAndScore(const std::map<uint32_t, std::shared_ptr<Segment>>& segment_map,
            int64_t avg_replica_count_on_disk) {
        if (is_calc) {
            return;
        }
        for (auto& replica : replica_list) {
            auto it = segment_map.find(replica->segment_id);
            if (it == segment_map.end()) {
                assert(false);
            }
            if (it->second->IsValidReplica(replica)) {
                ++replica_count;
            }
        }
        real_replica_count_on_disk_score = replica_count * 1.0 / avg_replica_count_on_disk;
        is_calc = true;
    }

    void AddRebalanceReplica(std::shared_ptr<Replica> /*replica*/,
            int64_t avg_replica_count_on_disk) {
        ++replica_count;
        //replica_list.emplace_back(replica);
        real_replica_count_on_disk_score = replica_count * 1.0 / avg_replica_count_on_disk;
    }

    void DelRebalanceReplica(std::shared_ptr<Replica> replica,
            int64_t avg_replica_count_on_disk) {
        --replica_count;
        assert(replica == *iter);
        iter = replica_list.erase(iter);
        real_replica_count_on_disk_score = replica_count * 1.0 / avg_replica_count_on_disk;
    }

    std::ostream& ToString(std::ostream& os) {
        return os << "id=" << cluster_id
            << ", count=" << replica_count
            << ", score=" << real_replica_count_on_disk_score;
    }
};

inline std::ostream& operator<<(std::ostream& os, const std::shared_ptr<DiskCluster>& disk_cluster) {
    return disk_cluster->ToString(os);
}

struct Disk {
    const base::EndPoint addr;
    const int32_t id;
    bool is_active {false};
    int64_t used_size {0};
    int64_t total_size {-1};
    int64_t used_thousandth {0};
    int64_t used_capacity {0};
    int64_t total_capacity {-1};
    bool has_io_error {false};
    int32_t zone {0};

    int64_t avg_used_thousandth {0};
    int64_t inflation_used_thousandth {0};
    int64_t deflation_used_thousandth {0};

    std::map<std::string, std::shared_ptr<DiskCluster>> cluster_replica_map;

    std::vector<std::shared_ptr<Replica>> rebalance_pick_from_replicas_vec;
    std::vector<std::shared_ptr<Replica>> rebalance_pick_to_replicas_vec;
    std::vector<std::shared_ptr<Replica>> in_recovery_replica_vec;

    Disk(const base::EndPoint& addr_, int32_t id_) : addr(addr_), id(id_) {}
    ~Disk() {}

    void PrintClusterReplicas(std::ostream& os, int tabn) {
        for (auto& it : cluster_replica_map) {
            os << std::setw(tabn * 4) << " " << "cluster:" << it.first << std::endl;
            it.second->PrintReplicas(os, tabn + 1);
        }
    }

    std::shared_ptr<DiskCluster> GetReplicaDiskCluster(std::shared_ptr<Replica> replica) {
        if (auto it = cluster_replica_map.find(replica->cluster_id);
                it != cluster_replica_map.end()) {
            return it->second;
        }
        return nullptr;
    }

    void AddReplica(std::shared_ptr<Replica> replica) {
        std::shared_ptr<DiskCluster> disk_cluster = nullptr;
        if (auto it = cluster_replica_map.find(replica->cluster_id);
                it != cluster_replica_map.end()) {
            disk_cluster = it->second;
        } else {
            disk_cluster = cluster_replica_map.emplace(replica->cluster_id,
                    std::make_shared<DiskCluster>(replica->cluster_id)).first->second;
        }
        disk_cluster->AddReplica(replica);
    }

    void AddRebalanceFromReplica(std::shared_ptr<Replica> replica, bool is_new = true) {
        rebalance_pick_from_replicas_vec.emplace_back(replica);
        if (is_new) {
            --used_capacity;
            used_size -= replica->physical_size;
            used_thousandth = cacl_disk_used_thousandth(used_size, total_size);
        }
    }

    void AddRebalanceToReplica(std::shared_ptr<Replica> replica, bool is_new = true) {
        rebalance_pick_to_replicas_vec.emplace_back(replica);
        if (is_new) {
            ++used_capacity;
            used_size += replica->physical_size;
            used_thousandth = cacl_disk_used_thousandth(used_size, total_size);
        }
    }

    void AddInRecoveryReplica(std::shared_ptr<Replica> replica) {
        in_recovery_replica_vec.emplace_back(replica);
    }

    int64_t GetClusterReplicaCountOnDisk(std::shared_ptr<Replica> replica) {
        if (auto it = cluster_replica_map.find(replica->cluster_id); it != cluster_replica_map.end()) {
            return it->second->replica_count;
        }
        return 0;
    }

    std::shared_ptr<Replica> ZoneConflict(std::shared_ptr<Replica> replica, std::shared_ptr<Segment> segment) {
        for (auto& it : segment->replica_map) {
            auto peer = it.second;
            if (peer == replica) {
                continue;
            }
            if (peer->zone == zone && zone) {
                return peer;
            }
        }
        return nullptr;
    }

    std::ostream& ToString(std::ostream& os) {
        return os << "addr=" << addr
            << ", id=" << id
            << ", used_capacity=" << used_capacity
            << ", total_capacity=" << total_capacity
            << ", total_size=" << total_size
            << ", used_size=" << used_size
            << ", used_thousandth=" << used_thousandth
            << ", zone=" << zone
            << ", io_error=" << has_io_error;
    }
};

inline std::ostream& operator<<(std::ostream& os, const std::shared_ptr<Disk>& disk) {
    return disk->ToString(os);
}

struct ClusterDisk {
    std::shared_ptr<Disk> disk;
    std::shared_ptr<DiskCluster> disk_cluster;

    ClusterDisk(std::shared_ptr<Disk> d, std::shared_ptr<DiskCluster> s)
        : disk(d), disk_cluster(s) {}
};

struct CompareDisk {
    std::shared_ptr<Replica> replica;

    CompareDisk(std::shared_ptr<Replica> replica_) : replica(replica_) {}
    ~CompareDisk() {}

    bool operator()(std::shared_ptr<Disk> lhs, std::shared_ptr<Disk> rhs) const {
        const int64_t lhs_n = lhs->GetClusterReplicaCountOnDisk(replica);
        const int64_t rhs_n = rhs->GetClusterReplicaCountOnDisk(replica);
        return lhs_n == rhs_n
            ? (lhs->used_thousandth < rhs->used_thousandth)
            : (lhs_n < rhs_n);
    }
};

struct Server {
    const base::EndPoint addr {};
    bool is_offline {false};
    int32_t zone {0};
    int32_t replica_count {0};
    std::map<int32_t, std::shared_ptr<Disk>> disk_map;

    pspb::MultiGetStatusRequest rpc_request;
    pspb::MultiGetStatusResponse rpc_response;
    RpcStatus rpc_status;
    int32_t rpc_retry_times {0};
    bool rpc_ok {false};

    Server(const base::EndPoint& addr_) : addr(addr_) {}
    ~Server() {}

    void PrintDiskReplicas(std::ostream& os, int tabn) {
        os << std::setw(tabn * 4) << " " << "server:" << addr << std::endl;
        for (auto& it : disk_map) {
            it.second->PrintClusterReplicas(os, tabn + 1);
        }
    }

    // if RPC succ, init server status
    // 1) init disk map
    // 2) add replicas to disk
    void InitServerStatus() {
        is_offline = rpc_response.has_topology_to_offline() ? rpc_response.topology_to_offline() : false;
        zone = rpc_response.has_topology_zone() ? rpc_response.topology_zone() : 0;
        for (int32_t i = 0; i < rpc_response.stores_size(); ++i) {
            const auto& store = rpc_response.stores(i);
            auto disk = disk_map.emplace(store.store_id(),
                    std::make_shared<Disk>(addr, store.store_id())).first->second;
            disk->is_active = store.active() && store.physical_store_size() > 0;
            if (disk->is_active) {
                disk->used_size = store.physical_used_size();
                disk->total_size = store.physical_store_size();
                disk->used_thousandth = cacl_disk_used_thousandth(
                        store.physical_used_size(), store.physical_store_size());
                disk->used_capacity = store.used_capacity();
                disk->total_capacity = store.capacity();
                disk->has_io_error = store.io_error_count() > 0;
                disk->zone = zone;
            }
        }
        replica_count = rpc_response.segments_size();
        for (int32_t i = 0; i < rpc_response.segments_size(); ++i) {
            const auto& segment = rpc_response.segments(i);
            auto replica = std::make_shared<Replica>(segment.cluster_id(), segment.segment_id(), addr);
            replica->logical_size = segment.segment_size();
            replica->physical_size = segment.segment_physical_size();
            replica->in_recovery = segment.in_recovery();
            replica->store_id = segment.store_id();
            replica->manager_address = segment.manager_address();
            replica->version = segment.version();
            replica->replica_id = segment.replica_id();
            if (segment.has_rebalance_from()) {
                replica->has_rebalance = true;
                base::str2endpoint(segment.rebalance_from().c_str(), &replica->rebalance_from);
                replica->rebalance_version = segment.rebalance_version();
            }
            replica->is_ok = segment.segment_status() == "Open" && segment.init_flag() == "InitSucc";
            if (replica->is_ok && segment.has_init_lsn_ok()) {
                replica->is_ok = segment.init_lsn_ok();
            }
            replica->zone = zone;
            // add to disk
            disk_map[segment.store_id()]->AddReplica(replica);
        }
        rpc_ok = true;
    }

    std::shared_ptr<Disk> GetDisk(int32_t disk_id) const {
        auto it = disk_map.find(disk_id);
        if (it != disk_map.end()) {
            return it->second;
        }
        return nullptr;
    }

    std::shared_ptr<Replica> ReplicaOnServer(std::shared_ptr<Segment> segment) {
        for (auto& it : segment->replica_map) {
            if (it.first == addr) {
                return it.second;
            }
        }
        return nullptr;
    }

};

struct Cluster {
    const std::string id;
    int64_t replica_count {0};
    int64_t avg_replica_count_on_disk {0};
    std::map<uint32_t, std::shared_ptr<Segment>> segment_map;

    std::vector<std::shared_ptr<Replica>> rebalance_from_replica_vec;
    std::vector<std::shared_ptr<Replica>> rebalance_to_replica_vec;
    std::vector<std::shared_ptr<Replica>> in_recovery_replica_vec;

    Cluster(const std::string& id_) : id(id_) {
        rebalance_from_replica_vec.reserve(128);
        rebalance_to_replica_vec.reserve(128);
        in_recovery_replica_vec.reserve(128);
    }
    ~Cluster() {}

    std::shared_ptr<Segment> GetReplicaSegment(std::shared_ptr<Replica> replica) {
        return segment_map[replica->segment_id];
    }

    void AddReplica(std::shared_ptr<Replica> replica) {
        std::shared_ptr<Segment> segment = nullptr;
        if (auto it = segment_map.find(replica->segment_id); it != segment_map.end()) {
            segment = it->second;
        } else {
            segment = segment_map.emplace(replica->segment_id,
                    std::make_shared<Segment>(replica->segment_id)).first->second;
        }
        segment->AddReplica(replica);
    }

    void CalcReplicaSumAndAvgOnDisk(int64_t disk_total_num,
            const std::map<base::EndPoint, std::shared_ptr<Server>>& server_map) {
        replica_count = 0;
        for (auto& it : segment_map) {
            auto segment = it.second;
            replica_count += segment->GetRealReplicaSum(&rebalance_from_replica_vec,
                    &rebalance_to_replica_vec, &in_recovery_replica_vec);
        }
        avg_replica_count_on_disk = static_cast<int64_t>(
                std::max(1.0, std::ceil(replica_count * 1.0 / disk_total_num)));
        assert(avg_replica_count_on_disk >= 1);

        for (auto& replica : rebalance_from_replica_vec) {
            auto it = server_map.find(replica->addr);
            assert(it != server_map.end());
            auto disk = it->second->GetDisk(replica->store_id);
            disk->AddRebalanceFromReplica(replica, false);
        }

        for (auto& replica : rebalance_to_replica_vec) {
            auto it = server_map.find(replica->addr);
            assert(it != server_map.end());
            auto disk = it->second->GetDisk(replica->store_id);
            disk->AddRebalanceToReplica(replica, false);
        }

        for (auto& replica : in_recovery_replica_vec) {
            auto it = server_map.find(replica->addr);
            assert(it != server_map.end());
            auto disk = it->second->GetDisk(replica->store_id);
            disk->AddInRecoveryReplica(replica);
        }
    }

    void AddNewRebalanceReplica(std::shared_ptr<Replica> from, std::shared_ptr<Replica> to) {
        rebalance_from_replica_vec.emplace_back(from);
        rebalance_to_replica_vec.emplace_back(to);
        in_recovery_replica_vec.emplace_back(to);
        GetReplicaSegment(from)->AddNewRebalanceReplica(from, to);
    }

    std::ostream& ToString(std::ostream& os) {
        return os << "id=" << id
            << ", replica_count=" << replica_count
            << ", segment_count=" << segment_map.size();
    }
};

inline std::ostream& operator<<(std::ostream& os, const std::shared_ptr<Cluster>& cluster) {
    return cluster->ToString(os);
}

struct ServerManager {
    std::atomic<size_t> task_count {0};
    std::map<base::EndPoint, std::shared_ptr<Server>> server_map;
    std::map<std::string, std::shared_ptr<Cluster>> cluster_map;

    std::vector<std::shared_ptr<Replica>> rebalance_from_replica_vec;
    std::vector<std::shared_ptr<Replica>> rebalance_to_replica_vec;
    std::vector<std::shared_ptr<Replica>> in_recovery_replica_vec;

    ServerManager() {
        rebalance_from_replica_vec.reserve(1024);
        rebalance_to_replica_vec.reserve(1024);
        in_recovery_replica_vec.reserve(1024);
    }
    ~ServerManager() {}

    std::shared_ptr<Server> GetReplicaServer(std::shared_ptr<Replica> replica) {
        return server_map[replica->addr];
    }

    std::shared_ptr<Server> GetDiskServer(std::shared_ptr<Disk> disk) {
        return server_map[disk->addr];
    }

    std::shared_ptr<Cluster> GetCluster(const std::string& cluster_id) {
        return cluster_map[cluster_id];
    }

    std::shared_ptr<Cluster> GetReplicaCluster(std::shared_ptr<Replica> replica) {
        return cluster_map[replica->cluster_id];
    }

    std::shared_ptr<Segment> GetReplicaSegment(std::shared_ptr<Replica> replica) {
        return cluster_map[replica->cluster_id]->segment_map[replica->segment_id];
    }

    // if get server list ok, init server map
    void InitServerMap(const std::vector<base::EndPoint>& nodes) {
        task_count.store(nodes.size());
        for (const auto& addr : nodes) {
            server_map.emplace(addr, std::make_shared<Server>(addr));
        }
    }

    // get all server status successfully, start to build Cluster and Segment
    // 1) iterate over Disk replicas, add it to Cluster and Segment
    void BuildClusterAndSegmentFromServerDiskReplicas() {
        for (auto it : server_map) {
            auto server = it.second;
            for (auto it2 : server->disk_map) {
                auto disk = it2.second;
                for (auto it3 : disk->cluster_replica_map) {
                    auto disk_cluster = it3.second;
                    for (auto& replica : disk_cluster->replica_list) {
                        std::shared_ptr<Cluster> cluster = nullptr;
                        if (auto fit = cluster_map.find(replica->cluster_id); fit != cluster_map.end()) {
                            cluster = fit->second;
                        } else {
                            cluster = cluster_map.emplace(replica->cluster_id,
                                    std::make_shared<Cluster>(replica->cluster_id)).first->second;
                        }
                        cluster->AddReplica(replica);
                    }
                }
            }
        }
    }

    void AddNewRebalanceReplica(std::shared_ptr<Replica> from, std::shared_ptr<Replica> to) {
        rebalance_from_replica_vec.emplace_back(from);
        rebalance_to_replica_vec.emplace_back(to);
        in_recovery_replica_vec.emplace_back(to);
        assert(from->cluster_id == to->cluster_id);
        GetReplicaCluster(from)->AddNewRebalanceReplica(from, to);
    }

};

class RebalanceSegmentReplicas : public Command {
public:
    RebalanceSegmentReplicas() {
        SetName("rebalance-ps-replicas");
        SetDesc("rebalance segment replicas on page server cluster");
        SetDescCn("在存储服务器集群上重新均衡分片副本");

        static const std::string kMaxNumDesc =
                "max number of rebalance replicas (default: " + std::to_string(kMaxNum) + ")";
        static const std::string kFloatingRateDesc =
                "floating rate, dividing disk groups: low, middle, high. (default: "
                + std::to_string(kDiskFloatingRate) + ")";
        static const std::string kDiskMaxNumDesc =
                "max number of rebalance replicas per disk (default: " + std::to_string(kDiskMaxNum) + ")";
        static const std::string kClusterMaxNumDesc =
                "max number of rebalance replicas per cluster (default: " + std::to_string(kClusterMaxNum) + ")";
        static const std::string kDiskMaxRecoveryNumDesc =
                "max number of recovery replicas per disk (default: " + std::to_string(kDiskMaxRecoveryNum) + ")";
        static const std::string kClusterMaxRecoveryNumDesc =
                "max number of recovery replicas per cluster (default: "
                + std::to_string(kClusterMaxRecoveryNum) + ")";
        static const std::string kMaxRecoveryNumDesc =
                "max number of recovery replicas (default: " + std::to_string(kMaxRecoveryNum) + ")";
        static const std::string kMinReplicaCountDesc =
                "minimum active replica count required for a segment to be picked as rebalance source (default: "
                + std::to_string(kMinReplicaCountForRebalance) + ")";
        static const std::string kMinReserveSizeDesc =
                "minimum reserved disk space in bytes (default: "
                + std::to_string(kMinReserveSize) + ")";
        static const std::string kOnlyOfflineDesc =
                "only rebalance replicas on offline server disks when offline servers exist (default: 1)";

        AddClusterOption();
        AddRequiredArgOption("max-num", NULL, 'n', kMaxNumDesc.c_str(), kuint64_t);
        AddRequiredArgOption("floating-rate", NULL, 'F',
                kFloatingRateDesc.c_str(),
                kstring, kGroup2Scope);
        AddRequiredArgOption("cluster-id", NULL, 'c',
                "only rebalance replicas of the specified cluster",
                kstring, kGroup2Scope);
        AddNoArgOption("debug", &_long_opt_val, kOptMax + 1,
                "trace rebalance strategy logs", kGroup5Scope);
        AddRequiredArgOption("disk-max-num", &_long_opt_val, kOptMax + 2,
                kDiskMaxNumDesc.c_str(),
                kuint64_t, kGroup3Scope);
        AddRequiredArgOption("cluster-max-num", &_long_opt_val, kOptMax + 3,
                kClusterMaxNumDesc.c_str(),
                kuint64_t, kGroup3Scope);
        AddRequiredArgOption("disk-max-recovery-num", &_long_opt_val, kOptMax + 4,
                kDiskMaxRecoveryNumDesc.c_str(),
                kuint64_t, kGroup3Scope);
        AddRequiredArgOption("cluster-max-recovery-num", &_long_opt_val, kOptMax + 5,
                kClusterMaxRecoveryNumDesc.c_str(),
                kuint64_t, kGroup3Scope);
        AddRequiredArgOption("max-recovery-num", &_long_opt_val, kOptMax + 6,
                kMaxRecoveryNumDesc.c_str(),
                kuint64_t, kGroup3Scope);
        AddRequiredArgOption("min-replica-count", &_long_opt_val, kOptMax + 7,
                kMinReplicaCountDesc.c_str(),
                kuint64_t, kGroup3Scope);
        AddRequiredArgOption("min-reserve-size", &_long_opt_val, kOptMax + 8,
                kMinReserveSizeDesc.c_str(),
                kuint64_t, kGroup3Scope);
        AddRequiredArgOption("only-offline", &_long_opt_val, kOptMax + 9,
                kOnlyOfflineDesc.c_str(),
                kbool, kGroup3Scope);

        AddExample("--cluster-addr <bns::ps_list> -n 64");
        AddExample("--cluster-addr <bns::ps_list> -n 8 -c <cluster_id>");
    }
    virtual ~RebalanceSegmentReplicas() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'n':
            _max_num = std::strtoul(opt, NULL, 10);
            break;
        case 'F':
            _disk_floating_rate = std::strtoul(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 'C':
            _cluster_addr = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _debug = true;
                break;
            case kOptMax + 2:
                _disk_max_num = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 3:
                _cluster_max_num = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 4:
                _disk_max_recovery_num = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 5:
                _cluster_max_recovery_num = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 6:
                _max_recovery_num = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 7:
                _min_replica_count = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 8:
                _min_reserve_size = std::strtoll(opt, NULL, 10);
                break;
            case kOptMax + 9:
                _only_offline = !!std::strtol(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;
private:

    bool GetPageServerReplicasAndStores();
    void OnGetServerStatus(std::shared_ptr<Server> server);
    int StartRebalanceReplicas(pspb::GaiaReblanceSegments& rebalance_replicas);
    bool DoRebalance(const std::vector<std::shared_ptr<Disk>>& from_disks,
            const std::vector<std::shared_ptr<Disk>>& candidate_disks,
            const std::vector<std::shared_ptr<Disk>>& normal_disks,
            const std::vector<std::shared_ptr<Disk>>& all_disks,
            pspb::GaiaReblanceSegments& rebalance_replicas);

    uint32_t PickReplica(std::shared_ptr<DiskCluster> disk_cluster,
            std::shared_ptr<Disk> from, std::vector<std::shared_ptr<Disk>>& candidate_disks,
            bool& end_task, bool& end_disk_task, bool check_usage_threshold,
            pspb::GaiaReblanceSegments* rebalance_replicas);
    std::shared_ptr<Replica> PickReplicaToRebalance(std::shared_ptr<Disk> disk,
            std::shared_ptr<DiskCluster> disk_cluster, bool& end_task, bool& end_disk_task,
            bool check_usage_threshold, bool is_offline);
    std::shared_ptr<Disk> PickBestDiskToStoreReplica(std::shared_ptr<Replica> replica,
            const std::vector<std::shared_ptr<Disk>>& candidate_disks,
            bool check_usage_threshold, bool is_offline);
    void AddReplicaToRebalanceList(std::shared_ptr<Replica> replica,
            std::shared_ptr<Disk> from, std::shared_ptr<Disk> to, pspb::GaiaReblanceSegments* rebalance_replicas);

    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::GaiaReblanceSegments& rsp);
private:
    std::string _cluster_addr {};
    size_t _max_num {kMaxNum};
    size_t _disk_max_num {kDiskMaxNum};
    size_t _cluster_max_num {kClusterMaxNum};
    size_t _max_recovery_num {kMaxRecoveryNum};
    size_t _disk_max_recovery_num {kDiskMaxRecoveryNum};
    size_t _cluster_max_recovery_num {kClusterMaxRecoveryNum};
    int64_t _disk_floating_rate {kDiskFloatingRate};
    int64_t _min_replica_count {kMinReplicaCountForRebalance};
    int64_t _min_reserve_size {static_cast<int64_t>(kMinReserveSize)};
    std::string _cluster_id {};
    bool _only_offline {true};
    bool _debug {false};
    ServerManager _server_manager;
};

}
}
