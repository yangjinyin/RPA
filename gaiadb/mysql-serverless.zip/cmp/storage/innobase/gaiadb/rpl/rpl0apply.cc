/*****************************************************************************

Copyright (c) 2021, Baidu Inc. All Rights Reserved.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file include/rpl0apply.cc
 Gaiadb redo log apply worker

 Created 10/22/2021 Hongyu Qiao
 *******************************************************/

#include "rpl0apply.h"
#include "buf0buf.h"
#include "dict0dict.h"
#include "gflags/gflags.h"
#include "rpl0conductor.h"
#include "rpl0metric.h"
#include "rpl0rpl.h"
#include "rpl0schedule.h"
#include "sql/current_thd.h"
#include "sql/sql_thd_internal_api.h"
#include "ut0new.h"

namespace rpl {

static bvar::Maxer<int64_t> stat_diff_apply_lsn_2_vdl;
static bvar::Window<bvar::Maxer<int64_t>> stat_diff_apply_lsn_2_vdl_w(
    "cmp_rpl_gaia_cmp_stat_diff_apply_lsn_2_vdl", &stat_diff_apply_lsn_2_vdl, 1);

RplCoordinator *g_rpl_coordinator = &(RplCoordinator::get_instance());

static const char *const rpl_coordinator_str = "rpl_coordinator";
static const char *const rpl_apply_worker_str = "rpl_apply_worker";

thread_local bool is_apply_thread = false;

void rpl_coordinator() {
  DBUG_ENTER(rpl_coordinator_str);
  pthread_setname_np(pthread_self(), rpl_coordinator_str);
  /** set high priority to rpl_coordinator thread */
#ifdef UNIV_LINUX_ONLY
  setpriority(PRIO_PROCESS, (pid_t)syscall(SYS_gettid), -20);
  if (getpriority(PRIO_PROCESS, (pid_t)syscall(SYS_gettid)) != -20) {
    ib_warn() << "Gaia rpl set priority failed:" << strerror(errno);
  }
#endif
  ib_info(ER_IB_GAIA_MSG_RPL) << "Gaia replication coordinator thread started";

  is_apply_thread = true;

  // for currrent_thd usage, auto bind to current_thd.
  g_rpl_coordinator->m_thd = create_thd(false, true, true, 0, 0);

  g_rpl_coordinator->routine();

  destroy_thd(g_rpl_coordinator->m_thd);
  ib_info(ER_IB_GAIA_MSG_RPL)
      << "Gaia replication coordinator threads stopped";
  DBUG_VOID_RETURN;
}

void rpl_apply_worker(uint64_t slot_id) {
  DBUG_ENTER(rpl_apply_worker_str);
  is_apply_thread = true;
  pthread_setname_np(pthread_self(), rpl_apply_worker_str);
#ifdef UNIV_LINUX_ONLY
  setpriority(PRIO_PROCESS, (pid_t)syscall(SYS_gettid), -20);
#endif
  ib_info(ER_IB_GAIA_MSG_RPL)
      << "Gaia replication apply worker threads started " << slot_id;
  g_rpl_coordinator->slot_materializer(slot_id).routine();
  ib_info(ER_IB_GAIA_MSG_RPL)
      << "Gaia replication apply worker threads stoped " << slot_id;
  DBUG_VOID_RETURN;
}

static const char* apply_state_2_str(ApplyState as) {
  switch(as) {
  case UNINIT:
    return "uninit";
  case PICK_ASMB:
    return "pick_asmb";
  case PREPARE:
    return "prepare";
  case APPLY_PAGE:
    return "apply_page";
  case COMMIT:
    return "commit";
  case FINISH:
    return "finish";
  case SHUTDOWN:
    return "shutdown";
  }
  ut_error;
  return "unknown";
}

RplCoordinator::RplCoordinator() {
  m_thd = nullptr;
  rpl_materializers_.reserve(RplConst::RPL_SLOTS_PARALLEL);
  for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; ++i) {
    rpl_materializers_.push_back(new RplMaterializer(i));
  }
}

RplCoordinator::~RplCoordinator() {
  for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; ++i) {
    delete rpl_materializers_[i];
  }
  rpl_materializers_.clear();
}

const char* RplCoordinator::apply_state_str() {
  return apply_state_2_str(apply_state_);
}

bool RplCoordinator::init() {
  for (uint64_t i = 0; i < rpl_materializers_.size(); i++) {
    rpl_materializers_[i]->init();
  }
  apply_state_ = UNINIT;
  return true;
}

bool RplCoordinator::cleanup() {
  for (size_t i = 0; i < rpl_materializers_.size(); ++i) {
    rpl_materializers_[i]->cleanup();
  }
  apply_state_ = SHUTDOWN;
  return true;
}

void RplCoordinator::routine() {
  ut_a(trx_sys != nullptr);
  uint32_t wait_buf_count = 0;
  for (uint64_t step = 0; !rpl_sys->should_stop(); ++step) {
    // wait for parser to produce an assembly
    RplAssembly *assembly = nullptr;
    apply_state_ = PICK_ASMB;
    {
      ScopedLatencyRecorder _(&g_rpl_metric->apply_assembly_pick);
      assembly = g_rpl_conductor->apply_next();
    }
    {
      if (!assembly) {
        LOG_EVERY_SECOND(TRACE) << "coordinator wait for assembly";
        sleep_buf_not_enough(++wait_buf_count);
        continue;
      }
      wait_buf_count = 0;
    }

    g_rpl_metric->apply_batch_size << (assembly->end_lsn - assembly->start_lsn);

    LOG(TRACE) << "coordinate assembly, epoch: " << assembly->epoch << ", "
               << assembly->lsn_range();

    if (assembly->record_count == 0) {
      apply_state_ = PREPARE;
      assembly->apply_prepare();
      LOG(TRACE) << "assembly epoch: " << assembly->epoch
                 << assembly->lsn_range()
                 << " has no record, skip page materialize";
      apply_state_ = COMMIT;
      assembly->apply_commit();
      apply_state_ = FINISH;
      assembly->finish_apply();
      g_rpl_conductor->update_apply_lsn(assembly->end_lsn);

      if (!FLAGS_rpl_enable_delta_replay) {
        g_rpl_scheduler->add_gc_job(assembly);
      }
      continue;
    }

    ut_a(g_rpl_conductor->apply_lsn() == assembly->start_lsn);
    apply_state_ = PREPARE;
    assembly->apply_prepare();
    {
      apply_state_ = APPLY_PAGE;
      ScopedLatencyRecorder _(&g_rpl_metric->apply_wait_for_materialize);
      for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; ++i) {
        rpl_materializers_[i]->add_apply_task(assembly);
      }
      LOG(TRACE) << "coordinate wait for assembly epoch: " << assembly->epoch
                 << " finish apply";
      assembly->wait_for_all_slot_materialized();
    }

    apply_state_ = COMMIT;
    assembly->apply_commit();
    apply_state_ = FINISH;
    assembly->finish_apply_low();
    g_rpl_conductor->update_apply_lsn(assembly->end_lsn);

    auto last_rpl_time = assembly->rpl_last_time;
    if (last_rpl_time > 0) {
      auto now = my_micro_time();
      auto delay = now > last_rpl_time ? (now - last_rpl_time) / 1000 : 0;
      rpl_sys->set_behind_master(delay);
      g_rpl_metric->behind_master << delay;
    }
    if (!FLAGS_rpl_enable_delta_replay) {
      g_rpl_scheduler->add_gc_job(assembly);
    }
  }
}

RplMaterializer &RplCoordinator::slot_materializer(uint64_t slot_id) {
  ut_a(slot_id < rpl_materializers_.size());
  return *rpl_materializers_[slot_id];
}

RplMaterializer::RplMaterializer(uint64_t id) : slot_id_(id) {}

RplMaterializer::~RplMaterializer() {}

bool RplMaterializer::init() {
  index_ = 0;
  return true;
}

bool RplMaterializer::cleanup() {
  return true;
}

// return true if page truely modified
bool RplMaterializer::apply_page(buf_block_t *block, RplAssembly *asmb) {
  ut_a(block != nullptr);
  auto vdl = g_rpl_conductor->master_vdl();
  auto applied_lsn = g_rpl_conductor->apply_lsn();
  if (vdl > 0) {
    stat_diff_apply_lsn_2_vdl << (int64_t)(vdl - applied_lsn);
  }
  auto count = asmb->apply_materialize(block);
  return !!count;
}

void RplMaterializer::add_apply_task(RplAssembly *task) {
  if (!task) {
    return;
  }
  uint32_t count = 0;
  while (!apply_tasks_.push(task)) {
    if (count++ >= 32) {
      count = 0;
      std::this_thread::sleep_for(std::chrono::microseconds(10));
    } else {
      UT_RELAX_CPU();
    }
  }
}

RplAssembly *RplMaterializer::pick_one_task() {
  RplAssembly *asmb = nullptr;
  apply_tasks_.pop(asmb);
  return asmb;
}

void RplMaterializer::routine() {
  uint32_t wait_buf_count = 0;
  for (; !rpl_sys->should_stop();) {
    RplAssembly *assembly = pick_one_task();
    if (!assembly) {
      const uint64_t parse_index = g_rpl_conductor->parse_index();
      LOG_EVERY_SECOND(TRACE)
          << "apply worker " << slot_id_ << " wait for apply task,"
          << " index:" << index_ << " parse_index:" << parse_index;
      if (index_ >= parse_index) {
        sleep_buf_not_enough(++wait_buf_count);
      } else {
        std::this_thread::sleep_for(std::chrono::microseconds(50));
      }
      continue;
    }
    assembly->apply_slot(slot_id_);
    index_ = assembly->snapshot_index;
    wait_buf_count = 0;
  }
}

}  // namespace rpl
