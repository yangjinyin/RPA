/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/rw16k.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <cstdio>
#include <memory>
#include <iostream>
#include <filesystem>
#include <sys/stat.h>

constexpr uint64_t page_size = 4 * 1024;

void stat_info(const char* file, long int st_blocks, long int file_szie) {
    struct stat st;
    stat(file, &st);
    std::cout << "st_size:" << st.st_size
        //<< ", st_blksize:" << st.st_blksize
        << ", st_blocks:" << st.st_blocks
        << std::endl;
    if (st_blocks != st.st_blocks) {
        std::cout << "error: st_blocks not right." << std::endl;
        exit(1);
    }
    if (file_szie != st.st_size) {
        std::cout << "error: file_szie not right." << std::endl;
        exit(1);
    }
}

void run_test(int fd, char* file_name) {
    char buf[128];
    char buf2[128];
    memset(buf, 'a', 128);
    auto nr = pwrite(fd, buf, 128, 0);
    if (nr != 128) {
        std::cout << "pwrite failed first" << std::endl;
        return;
    }
    stat_info(file_name, 8, 128);

    nr = pwrite(fd, buf, 128, page_size);
    if (nr != 128) {
        std::cout << "pwrite failed first" << std::endl;
        return;
    }
    stat_info(file_name, 16, page_size + 128);

    int ret = fallocate(fd, FALLOC_FL_PUNCH_HOLE | FALLOC_FL_KEEP_SIZE, 0, page_size);
    if (ret != 0) {
        std::cout << "fallocate failed" << std::endl;
        return;
    }
    stat_info(file_name, 8, page_size + 128);

    nr = pread(fd, buf2, 128, 0);;
    if (memcmp(buf, buf2, 128) == 0
            || buf2[0] != '\0') {
        std::cout << "fallocate error, read error data" << std::endl;
        return;
    }

    nr = pwrite(fd, buf, 128, 0);
    if (nr != 128) {
        std::cout << "pwrite failed first" << std::endl;
        return;
    }
    stat_info(file_name, 16, page_size + 128);
    nr = pread(fd, buf2, 128, 0);;
    if (memcmp(buf, buf2, 128) != 0) {
        std::cout << "fallocate error, read error data" << std::endl;
        return;
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("./%s <test_file_name>\n", argv[0]);
        printf("./Usage: verify punch hole for write file\n");
        return -1;
    }
    char* file = argv[1];
    int fd = open(file, O_CREAT | O_RDWR | O_EXCL, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        printf("open file:%s failed:%s\n", file, strerror(errno));
        return -1;
    }
    run_test(fd, file);
    return 0;
}
