#include "bir0async_binlog.h"
#include <ctype.h>
#include <base/base64.h>
#include <openssl/hmac.h>
#include <baidu/rpc/uri.h>
#include <baidu/rpc/details/http_message.h>
#include <openssl/aes.h>
#include "gaiadb/common/global_flags.h"
#include "rpl0rpl.h"
#include "rpl0parse.h"
#include "gaiadb/redo_fetch/fetch_mdc_object.h"
#include "gaiadb/redo_fetch/fetch_mdc_utils.h"
#include "sql/binlog.h"
#include "sql/mysqld.h"

// extern void build_new_binlog_file_name(char *buff, uint32_t new_index_num);

namespace bir {

using ::build_new_binlog_file_name;

static constexpr uint32_t C_PARSE_WAIT_STEP = 4;
static const char *const binlog_fetcher_str = "bir_fetcher";
static const char *const binlog_parser_str = "bir_parser";
static const char *const binlog_sync_str = "bir_sync";
static const char *const binlog_bos_str = "bir_bos";

#define GAIA_LOG_START_LSN ((uint32_t)8192 + LOG_BLOCK_HDR_SIZE)

BirAsyncBinlog *g_bir_async = &(BirAsyncBinlog::get_instance());

void bir_binlog_async_init(lsn_t start_lsn, lsn_t apply_lsn) {
  if (!g_bir_async->init(start_lsn, apply_lsn)) {
    LOG(NOTICE) << "init bir async binlog success. start_lsn: " << start_lsn;
  } else {
    LOG(WARNING) << "init bir async binlog failed. start_lsn: " << start_lsn;
  }
}

void bir_binlog_async_reinit(lsn_t start_lsn, lsn_t apply_lsn) {
  if (!g_bir_async->reinit(start_lsn, apply_lsn)) {
    LOG(NOTICE) << "reinit bir async binlog success. start_lsn: " << start_lsn;
  } else {
    LOG(WARNING) << "reinit bir async binlog failed. start_lsn: " << start_lsn;
  }
}

void start_binlog_async_background_thread() {
  if (!opt_bin_log) {
    return;
  }
  ut_a(!srv_thread_is_active(srv_threads.m_bir_binlog_fetcher));
  ut_a(!srv_thread_is_active(srv_threads.m_bir_binlog_parser));
  ut_a(!srv_thread_is_active(srv_threads.m_bir_binlog_sync));
  ut_a(!srv_thread_is_active(srv_threads.m_bir_binlog_bos));
  srv_threads.m_bir_binlog_fetcher =
      os_thread_create(bir_binlog_flusher_thread_key, 0, bir_fetcher);
  srv_threads.m_bir_binlog_parser = 
      os_thread_create(bir_binlog_parser_thread_key, 0, bir_parser);
  srv_threads.m_bir_binlog_sync =
      os_thread_create(bir_binlog_sync_thread_key, 0, bir_binlog_sync);
  srv_threads.m_bir_binlog_bos = 
      os_thread_create(bir_binlog_bos_thread_key, 0, bir_binlog_bos);
  srv_threads.m_bir_binlog_fetcher.start();
  srv_threads.m_bir_binlog_parser.start();
  srv_threads.m_bir_binlog_sync.start();
  srv_threads.m_bir_binlog_bos.start();
  ut_a(srv_thread_is_active(srv_threads.m_bir_binlog_fetcher));
  ut_a(srv_thread_is_active(srv_threads.m_bir_binlog_parser));
  ut_a(srv_thread_is_active(srv_threads.m_bir_binlog_sync));
  ut_a(srv_thread_is_active(srv_threads.m_bir_binlog_bos));
  g_bir_async->set_threads_started(true);
}

void stop_binlog_async_background_thread() {
  if (!opt_bin_log) {
    return;
  }
  if (!g_bir_async->threads_started()) {
    g_bir_async->cleanup();
    return;
  }
  ut_a(srv_thread_is_active(srv_threads.m_bir_binlog_fetcher));
  ut_a(srv_thread_is_active(srv_threads.m_bir_binlog_parser));
  ut_a(srv_thread_is_active(srv_threads.m_bir_binlog_sync));
  ut_a(srv_thread_is_active(srv_threads.m_bir_binlog_bos));
  g_bir_async->set_stop();
  while (srv_thread_is_active(srv_threads.m_bir_binlog_fetcher)) {
    std::this_thread::sleep_for(std::chrono::microseconds(10));
  }
  while (srv_thread_is_active(srv_threads.m_bir_binlog_parser)) {
    std::this_thread::sleep_for(std::chrono::microseconds(10));
  }
  while (srv_thread_is_active(srv_threads.m_bir_binlog_sync)) {
    std::this_thread::sleep_for(std::chrono::microseconds(10));
  }
  while (srv_thread_is_active(srv_threads.m_bir_binlog_bos)) {
    std::this_thread::sleep_for(std::chrono::microseconds(10));
  }
  g_bir_async->cleanup();
  ut_a(!srv_thread_is_active(srv_threads.m_bir_binlog_fetcher));
  ut_a(!srv_thread_is_active(srv_threads.m_bir_binlog_parser));
  ut_a(!srv_thread_is_active(srv_threads.m_bir_binlog_sync));
  ut_a(!srv_thread_is_active(srv_threads.m_bir_binlog_bos));
  g_bir_async->set_threads_started(false);
}

void add_binlog_async_info_task(BinlogInRedoInfo &binlog_in_redo_info) {
  g_bir_async->add_binlog_async_info_task(binlog_in_redo_info);
}

void bir_variables_notify() {
  g_bir_async->variables_cv_notify();
}

void set_binlog_ready(bool ready) {
  g_bir_async->set_binlog_ready(ready);
}

BirAsyncBinlog::~BirAsyncBinlog() {}

void BirAsyncBinlog::init_common(lsn_t start_lsn) {
  lsn_t real_start_lsn = start_lsn < GAIA_LOG_START_LSN ? GAIA_LOG_START_LSN : start_lsn;
  fetch_lsn_ = real_start_lsn;
  parse_lsn_ = real_start_lsn;
  copy_lsn_ = real_start_lsn;
  set_binlog_ready(srv_gaia_binlog_in_redo_log_for_primary);

  if (parse_log_buf_size_ > 0) {
    parse_log_buf_.dealloc();
  }

  parse_log_buf_size_ = log_buf_size() * 2;
  ut_ad(parse_log_buf_size_ > 0);
  parse_log_buf_.alloc_withkey(UT_NEW_THIS_FILE_PSI_KEY, ut::Count{parse_log_buf_size_});
  LOG(NOTICE) << "int bir parse buf,"
    << " start_lsn:" << real_start_lsn
    << ", buf_size:" << parse_log_buf_size_;
}

bool BirAsyncBinlog::init(lsn_t start_lsn, lsn_t apply_lsn) {
  if (!Conductor::is_init()) {
    Conductor::init();
    init_common(start_lsn);
  }
  apply_lsn_ = apply_lsn;
  return false;
}

bool BirAsyncBinlog::reinit(lsn_t start_lsn, lsn_t apply_lsn) {
  lsn_t real_start_lsn = start_lsn < GAIA_LOG_START_LSN ? GAIA_LOG_START_LSN : start_lsn;
  fetch_lsn_ = real_start_lsn;
  parse_lsn_ = real_start_lsn;
  copy_lsn_ = real_start_lsn;
  set_binlog_ready(srv_gaia_binlog_in_redo_log_for_primary);
  Conductor::reinit();
  apply_lsn_ = apply_lsn;
  return false;
}

bool BirAsyncBinlog::init(lsn_t start_lsn, size_t buf_size, lsn_t apply_lsn) {
  Conductor::init(buf_size);
  init_common(start_lsn);
  apply_lsn_ = apply_lsn;
  return false;
}

bool BirAsyncBinlog::cleanup() {
  Conductor::cleanup();
  parse_log_buf_size_ = 0;
  parse_log_buf_.dealloc();
  replicator_trunk_files.Clear();
  return false;
}

bool BirAsyncBinlog::bir_binlog_in_redo_flusher() {
  size_t buf_size = srv_log_buffer_size;
  lsn_t start_lsn = get_binlog_start_lsn();
  lsn_t end_lsn = get_gaia_apply_lsn();
  lsn_t current_lsn = 0;
  int count = 0;
retry_resize_buf:
  init(start_lsn, buf_size, apply_lsn_);
  ib_info(ER_GAIA_BINLOG_IN_REDO) << "binlog in redo v2 recover, start_lsn:" 
      << start_lsn
      << ", end_lsn:" << end_lsn;
  bool last_fetch_from_bos = false;
  while (parse_lsn_ < end_lsn && count < 10) {
    fetch_log(&last_fetch_from_bos, end_lsn);
    if (!parse_log()) {
      if (parse_data_len_ - parse_data_pos_ > buf_size / 2) {
        buf_size = buf_size * 1.382;
        start_lsn = parse_lsn_;
        ib_info(ER_GAIA_BINLOG_IN_REDO)
          << "binlog in redo v2 recover resize buf,"
          << " buf_len:" << parse_data_len_
          << " buf_pos:" << parse_data_pos_
          << " buf_size:" << buf_size;
        goto retry_resize_buf;
      }
      count++;
      continue;
    }
    if (current_lsn < parse_lsn_) {
      current_lsn = parse_lsn_;
    } else {
      count++;
    }

    mutex_enter(binlog_mutex());
    binlog_recover()->sync();
    mutex_exit(binlog_mutex());
  }
  ib_info(ER_GAIA_BINLOG_IN_REDO) << "binlog in redo v2 recover done";
  return false;
}

lsn_t get_binlog_start_lsn() {
  // 1. Retrieve information from the last binlog_index. Also, pass the async_info.
  BinlogInRedoInfo binlog_info; 
  uint32_t last_index_id = 0;
  BinlogInRedoInfoV2 binlog_info_v2;
  retry_operation(UINT64_MAX, gaiadb_get_binlog_in_redo_info_v2_start_info, 
    &binlog_info, last_index_id, &binlog_info_v2);
  // 2. Check if the last binlog exists. If it does, 
  // truncate it to the position `pos` and continue replaying. 
  // If it doesn't exist, start replaying from the `start_lsn` of the index.
  g_bir_async->set_sync_index_id(last_index_id);
  char new_name[FN_REFLEN];
  ::build_new_binlog_file_name(new_name, last_index_id);
  if (!check_binlog_file_exist(new_name)) {
    return binlog_info_v2.start_lsn;
  } else {
    if (binlog_info.binlog_sync_lsn == 0) {
      LOG(NOTICE) << "binlog info binlog_sync_lsn is 0";
      return binlog_info_v2.start_lsn;
    }
    // pos == 0 means that the binlog_in_redo switch was previously turned off,
    // so truncate was not performed.
    if (binlog_info.binlog_pos == 0) {
      LOG(NOTICE) << "binlog info binlog_pos is 0";
      return binlog_info.binlog_sync_lsn;
    }
    if (mysql_bin_log.truncate_binlog_file(binlog_info.binlog_pos, new_name)) {
      LOG(ERROR) << "truncate binlog file failed";
    }
    return binlog_info.binlog_sync_lsn;
  }
}

void bir_fetcher() {
  pthread_setname_np(pthread_self(), binlog_fetcher_str);
#ifdef UNIV_LINUX_ONLY
  setpriority(PRIO_PROCESS, (pid_t)syscall(SYS_gettid), -20);
#endif
  ib_info(ER_GAIA_BINLOG_IN_REDO) << "binlog in redo recover fetcher started";
  g_bir_async->fetch_routine();
  ib_info(ER_GAIA_BINLOG_IN_REDO) << "binlog in redo recover fetcher stopped";
}

void bir_parser() {
  pthread_setname_np(pthread_self(), binlog_parser_str);
#ifdef UNIV_LINUX_ONLY
  setpriority(PRIO_PROCESS, (pid_t)syscall(SYS_gettid), -20);
#endif
  ib_info(ER_GAIA_BINLOG_IN_REDO) << "binlog in redo recover parser started";
  g_bir_async->parse_routine();
  ib_info(ER_GAIA_BINLOG_IN_REDO) << "binlog in redo recover parser stopped";
}

void bir_binlog_sync() {
  setpriority(PRIO_PROCESS, (pid_t)syscall(SYS_gettid), -20);
#ifdef UNIV_LINUX_ONLY
  pthread_setname_np(pthread_self(), binlog_sync_str);
#endif
  ib_info(ER_IB_GAIA_MSG_RPL)
      << "Gaia replication binlog flusher threads started";
  g_bir_async->binlog_sync_routine();
  ib_info(ER_IB_GAIA_MSG_RPL)
      << "Gaia replication binlog flusher threads stopped";
}

void bir_binlog_bos() {
  setpriority(PRIO_PROCESS, (pid_t)syscall(SYS_gettid), -20);
#ifdef UNIV_LINUX_ONLY
  pthread_setname_np(pthread_self(), binlog_bos_str);
#endif
  ib_info(ER_IB_GAIA_MSG_RPL)
      << "Gaia replication binlog bos threads started";
  g_bir_async->binlog_bos_routine();
  ib_info(ER_IB_GAIA_MSG_RPL)
      << "Gaia replication binlog bos threads stopped";
  return;
}

void add_bir_binlog_to_bos_task(BinlogToBosTask &binlog_to_bos) {
  g_bir_async->add_binlog_to_bos_task(binlog_to_bos);
}

bool download_binlog_file_from_bos(const char *log_file_name) {
  return bos::download_from_bos(log_file_name);
}

} // namespace bir
