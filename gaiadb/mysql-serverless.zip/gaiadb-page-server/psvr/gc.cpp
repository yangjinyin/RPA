/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/gc.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <bthread/task_group.h>
#include "psvr/config.h"
#include "psvr/control.h"
#include "psvr/page_op.h"
#include "psvr/gc_context.h"

namespace psvr {

static uint64_t gc_get_delay_us(uint32_t retry_times,
        uint64_t retry_interval_us = FLAGS_psvr_gc_delay_min_us,
        uint64_t max_delay_us = FLAGS_psvr_gc_delay_max_us) {
    if (FLAGS_psvr_enable_append_file &&
            max_delay_us == FLAGS_psvr_gc_delay_max_us) {
        max_delay_us = FLAGS_psvr_gc_delay_max_us_for_append;
    }
    return get_delay_us(retry_times, retry_interval_us, max_delay_us);
}

static uint64_t dblwr_dump_get_delay_us(uint32_t retry_times,
        uint64_t retry_interval_us = FLAGS_psvr_dblwr_dump_delay_min_us,
        uint64_t max_delay_us = FLAGS_psvr_dblwr_dump_delay_max_us) {
    return get_delay_us(retry_times, retry_interval_us, max_delay_us);
}

static int32_t get_gc_in_wait_count(void* arg) {
    return static_cast<GcManager*>(arg)->in_wait_size();
}

static const char* action2str(GcManager::Action action) {
    switch (action) {
    case GcManager::Action::kRecoverPage:
        return "kRecoverPage";
    case GcManager::Action::kDisposeRecoveryPage:
        return "kDisposeRecoveryPage";
    case GcManager::Action::kGcLogBlock:
        return "kGcLogBlock";
    case GcManager::Action::kPreAppendFileGc:
        return "kPreAppendFileGc";
    case GcManager::Action::kAppendFileGc:
        return "kAppendFileGc";
    case GcManager::Action::kFinishGcLogBlock:
        return "kFinishGcLogBlock";
    case GcManager::Action::kDblwrDump:
        return "kDblwrDump";
    default:
        return "unknown";
    }
}

const char* GcManager::action2str(GcManager::Action action) {
    return psvr::action2str(action);
}

static bool is_append_action(GcManager::Context* ctx) {
    return ctx->action == GcManager::Action::kPreAppendFileGc
            || ctx->action == GcManager::Action::kAppendFileGc;
}

static bool is_dblwr_action(GcManager::Context* ctx) {
    return ctx->action == GcManager::Action::kDblwrDump;
}

static StatQps stat_cond_trigger_lsn("gc_cond_trigger_lsn", kSlaWindowSize);
static StatQps stat_cond_trigger_data("gc_cond_trigger_data", kSlaWindowSize);
static StatQps stat_cond_trigger_time("gc_cond_trigger_time", kSlaWindowSize);

GcManager::ConditionTask::operator bool() {
    auto cls = cluster.lock();
    if (!cls) {
        return true;    // cluster is deleted
    }

    const auto real_cn_lowest_lsn = cls->real_cn_lowest_lsn();
    if (real_cn_lowest_lsn <= min_lsn) {
        return false;
    }

    auto delay_append_fn = [this, &real_cn_lowest_lsn]() {
        auto seg = ctx->segment.lock();
        const auto in_recovery = seg ? seg->in_recovery() : false;
        const int64_t multiple = in_recovery ? 8 : 1;
        if (FLAGS_psvr_gc_delay_append_lsn_size
                && real_cn_lowest_lsn >= max_lsn + FLAGS_psvr_gc_delay_append_lsn_size) {
            stat_cond_trigger_lsn << 1;
            return true;
        }
        if (FLAGS_psvr_gc_delay_append_data_size
                && seg && seg->GetAppendUnGcSize() >= FLAGS_psvr_gc_delay_append_data_size * multiple) {
            stat_cond_trigger_data << 1;
            return true;
        }
        if (FLAGS_psvr_gc_delay_append_time_us
                && base::cpuwide_time_us() >= FLAGS_psvr_gc_delay_append_time_us + wait_start_time) {
            stat_cond_trigger_time << 1;
            return true;
        }
        if (FLAGS_psvr_gc_nowait_peer_recovery_window_s > 0 && seg) {
            const uint64_t now_s = base::cpuwide_time_s();
            if (seg->peer_last_recover_time_s() + FLAGS_psvr_gc_nowait_peer_recovery_window_s >= now_s) {
                return true;
            }
        }
        return false;
    };

    if (FLAGS_psvr_enable_append_file) {
        const bool enable_delay = FLAGS_psvr_gc_delay_append_lsn_size
            || FLAGS_psvr_gc_delay_append_data_size
            || FLAGS_psvr_gc_delay_append_time_us
            || FLAGS_psvr_gc_nowait_peer_recovery_window_s;
        if (enable_delay) {
            return delay_append_fn();
        }
    }

    if (!has_data) {
        return true;    // no data apply, just lift lsn
    }

    if (real_cn_lowest_lsn < max_lsn
            && ++retry_nr <= FLAGS_psvr_gc_wait_lsn_max_times) {
        return false;
    }

    auto delay_fn = [this, &real_cn_lowest_lsn]() {
        if (FLAGS_psvr_gc_delay_lsn_size
                && real_cn_lowest_lsn >= FLAGS_psvr_gc_delay_lsn_size + max_lsn) {
            return true;
        }
        if (FLAGS_psvr_gc_delay_time_us
                && base::cpuwide_time_us() >= FLAGS_psvr_gc_delay_time_us + wait_start_time) {
            return true;
        }
        return false;
    };

    if (FLAGS_psvr_gc_delay_lsn_size || FLAGS_psvr_gc_delay_time_us) {
        // delay log block to GC, increase applying more records probability
        return delay_fn();
    }

    return true;
}

void GcManager::ConditionGcQueue::Push(const ConditionTask& task) {
    std::unique_lock lk(_mutex);
    _tasks.emplace_back(task);
}

void GcManager::ConditionGcQueue::PopIf(Fn& fn) {
    std::list<ConditionTask> tasks;
    {
        std::unique_lock lk(_mutex);
        tasks = std::move(_tasks);
    }
    for (auto it = tasks.begin(); it != tasks.end(); ) {
        ConditionTask& task = *it;
        if (task) {
            fn (task);
            it = tasks.erase(it);
        } else {
            ++it;
        }
    }
    if (!tasks.empty()) {
        std::unique_lock lk(_mutex);
        _tasks.splice(_tasks.begin(), std::move(tasks));
    }
}

void GcManager::ConditionGcQueue::Clear(Fn& fn) {
    std::unique_lock lk(_mutex);
    for (auto it = _tasks.begin(); it != _tasks.end(); ) {
        ConditionTask& task = *it;
        fn(task);
        it = _tasks.erase(it);
    }
}

GcManager::GcManager(ClientPtr client, ControlWeakPtr control)
    : Model<GcManager>(client, control),
    _thread_num(FLAGS_psvr_gc_thread_num),
    _append_thread_num(1),
    _prior_thread_num(0),
    _condi_thread_num(1),
    _dblwr_dump_thread_num(1),
    _thread_pool(nullptr),
    _append_thread_pool(nullptr),
    _in_wait_size(0),
    _stat_gc_task_lat(kSlaWindowSize),
    _stat_gc_task_dispatch_size(kSlaWindowSize),
    _stat_gc_parallel_size(kSlaWindowSize),
    _stat_gc_recover_lat(kSlaWindowSize),
    _stat_gc_recover_rpc_lat(kSlaWindowSize),
    _stat_gc_dblwr_dump_lat(kSlaWindowSize),
    _stat_gc_log_block_bw(kSlaWindowSize),
    _stat_gc_log_block_lsn_size(kSlaWindowSize),
    _stat_gc_in_wait_count(get_gc_in_wait_count, this),
    _stat_gc_schedule_qps(kSlaWindowSize),
    _stat_gc_retry_qps(kSlaWindowSize),
    _stat_gc_ignore_qps(kSlaWindowSize),
    _stat_gc_interrupt_by_lsn_qps(kSlaWindowSize),
    _stat_gc_interrupt_by_space_extent_qps(kSlaWindowSize),
    _stat_gc_interrupt_by_recover_qps(kSlaWindowSize),
    _stat_gc_get_space_extent_in_advance_qps(kSlaWindowSize),
    _stat_gc_append_merge_size(kSlaWindowSize),
    _stat_gc_page_count(kSlaWindowSize),
    _stat_gc_real_page_count(kSlaWindowSize),
    _stat_gc_incomplete_lift_count(kSlaWindowSize),
    _stat_gc_record_err_count(kSlaWindowSize),
    _stat_gc_recover_err_count(kSlaWindowSize) {
    _thread_pool.reset(new ThreadPoolType);
    _append_thread_pool.reset(new ThreadPoolType);
    _condition_thread_pool.reset(new ConditionThreadType);
    _dblwr_dump_thread_pool.reset(new ThreadPoolType);
    Expose();
}

void GcManager::Expose() {
#ifndef GTEST
    _stat_gc_task_lat.expose("psvr_gc_task");
    _stat_gc_task_dispatch_size.expose("psvr_gc_task_dispatch_size");
    _stat_gc_parallel_size.expose("psvr_gc_parallel_size");
    _stat_gc_recover_lat.expose("psvr_gc_recover");
    _stat_gc_recover_rpc_lat.expose("psvr_gc_recover_rpc");
    _stat_gc_dblwr_dump_lat.expose("psvr_gc_dblwr_dump");
    _stat_gc_log_block_bw.expose("psvr_gc_log_block_bw");
    _stat_gc_log_block_lsn_size.expose("psvr_gc_log_block_lsn_size");
    _stat_gc_in_wait_count.expose("psvr_gc_in_wait_count");
    _stat_gc_schedule_qps.expose("psvr_gc_schedule_qps");
    _stat_gc_retry_qps.expose("psvr_gc_retry_qps");
    _stat_gc_ignore_qps.expose("psvr_gc_ignore_qps");
    _stat_gc_interrupt_by_lsn_qps.expose("psvr_gc_interrupt_by_lsn_qps");
    _stat_gc_interrupt_by_space_extent_qps.expose("psvr_gc_interrupt_by_space_extent_qps");
    _stat_gc_interrupt_by_recover_qps.expose("psvr_gc_interrupt_by_recover_qps");
    _stat_gc_get_space_extent_in_advance_qps.expose("psvr_gc_get_space_extent_in_advance_qps");
    _stat_gc_append_merge_size.expose("psvr_gc_append_merge_size");
    _stat_gc_page_count.expose("psvr_gc_page_count");
    _stat_gc_real_page_count.expose("psvr_gc_real_page_count");
    _stat_gc_incomplete_lift_count.expose("psvr_gc_incomplete_lift_count");
    _stat_gc_record_err_count.expose("psvr_gc_record_error_count");
    _stat_gc_recover_err_count.expose("psvr_gc_recover_error_count");
#endif
}

bool GcManager::SetUp() {
    ControlPtr control = _control.lock();
    if (!control) {
        LOG(ERROR) << "failed, control is release";
        return false;
    }

    if (control->multi_type()) {
        _thread_num = FLAGS_multi_psvr_gc_thread_num_per_group;
        _append_thread_num = FLAGS_multi_psvr_append_thread_num_per_group;
        _prior_thread_num = FLAGS_multi_psvr_gc_prior_thread_num_per_group;
        _dblwr_dump_thread_num = FLAGS_multi_psvr_dblwr_dump_num_per_group;

        auto cfg_cond_tn = static_cast<uint32_t>(FLAGS_multi_psvr_gc_condition_thread_num);
        uint32_t store_cond_tn = (_store_count + 1u) / 2;
        _condi_thread_num = std::min(cfg_cond_tn, store_cond_tn);
    }

    typename ConditionThreadType::Fn cond_fn
        = std::bind(&GcManager::ConditionFn, this, std::placeholders::_1);
    _condition_thread_pool->Start(_condi_thread_num, "gc_cond", cond_fn,
            &FLAGS_psvr_gc_wait_lsn_sleep_interval_us);

    // IO will block thread on bad store, so let GC tasks for each store run disjointly
    typename ThreadPoolType::TaskFn fn
        = std::bind(&GcManager::OnCompletion, this, std::placeholders::_1);

    uint32_t group_num = _store_count;
    if (FLAGS_multi_psvr_gc_group_num > 0
            && static_cast<uint32_t>(FLAGS_multi_psvr_gc_group_num) < _store_count) {
        group_num = FLAGS_multi_psvr_gc_group_num;
    }
    if (!_thread_pool->Start(group_num, "gc", control->timer(),
                _thread_num, fn, FLAGS_multi_psvr_gc_thread_enable_shared)) {
        LOG(ERROR) << "gc thread pool start failed";
        return false;
    }
    if (!_append_thread_pool->Start(group_num, "append", control->timer(),
                _append_thread_num, fn, FLAGS_multi_psvr_gc_thread_enable_shared)) {
        LOG(ERROR) << "append thread pool start failed";
        _thread_pool->Stop(true);
        return false;
    }
    if (!_dblwr_dump_thread_pool->Start(group_num, "dblwr", control->timer(),
                _dblwr_dump_thread_num, fn, FLAGS_multi_psvr_gc_thread_enable_shared)) {
        LOG(ERROR) << "dblwr dump thread pool start failed";
        _thread_pool->Stop(true);
        _append_thread_pool->Stop(true);
        return false;
    }
    return true;
}

void GcManager::TearDown() {
    LOG(NOTICE) << "gc manager will stop ...";
    _condition_thread_pool->Stop(false);
    _thread_pool->Stop(false);
    _append_thread_pool->Stop(false);
    _dblwr_dump_thread_pool->Stop(false);
    _stat_gc_task_lat.hide();
    _stat_gc_task_dispatch_size.hide();
    _stat_gc_parallel_size.hide();
    _stat_gc_recover_lat.hide();
    _stat_gc_recover_rpc_lat.hide();
    _stat_gc_dblwr_dump_lat.hide();
    _stat_gc_log_block_bw.hide();
    _stat_gc_log_block_lsn_size.hide();
    _stat_gc_in_wait_count.hide();
    _stat_gc_schedule_qps.hide();
    _stat_gc_retry_qps.hide();
    _stat_gc_ignore_qps.hide();
    _stat_gc_interrupt_by_lsn_qps.hide();
    _stat_gc_interrupt_by_space_extent_qps.hide();
    _stat_gc_interrupt_by_recover_qps.hide();
    _stat_gc_get_space_extent_in_advance_qps.hide();
    _stat_gc_append_merge_size.hide();
    _stat_gc_page_count.hide();
    _stat_gc_real_page_count.hide();
    _stat_gc_incomplete_lift_count.hide();
    _stat_gc_record_err_count.hide();
    _stat_gc_recover_err_count.hide();
}

void GcManager::Join() {
    LOG(NOTICE) << "gc manager will join ...";
    _condition_thread_pool->Stop(true);
    _thread_pool->Stop(true);
    _append_thread_pool->Stop(true);
    _dblwr_dump_thread_pool->Stop(true);
    LOG(NOTICE) << "gc manager will join ok";
}

bool GcManager::IncOrDecThreadNum() {
    bool ret = false;
    {
        uint32_t cfg_n = FLAGS_multi_psvr_gc_thread_num_per_group;
        uint32_t cur_n = IncOrDecGroupThreadNum(_thread_num, cfg_n,
                _thread_pool, _thread_pool->size(),
                [this](Context* ctx){
                    Schedule(ctx TRACE_FILE_LINE_CC);
                });

        LOG_IF(NOTICE, cfg_n != cur_n) << "gc thread num per store changed,"
            << " old:[" << cur_n
            << "] new:[" << cfg_n
            << "]";
        ret = cfg_n != cur_n;
    }
    {
        uint32_t cfg_n = FLAGS_multi_psvr_append_thread_num_per_group;
        uint32_t cur_n = IncOrDecGroupThreadNum(_append_thread_num, cfg_n,
                _append_thread_pool, _append_thread_pool->size(),
                [this](Context* ctx){
                    Schedule(ctx TRACE_FILE_LINE_CC);
                });

        LOG_IF(NOTICE, cfg_n != cur_n) << "append thread num per store changed,"
            << " old:[" << cur_n
            << "] new:[" << cfg_n
            << "]";
        ret = ret || cfg_n != cur_n;
    }
    {
        uint32_t cfg_n = FLAGS_multi_psvr_dblwr_dump_num_per_group;
        uint32_t cur_n = IncOrDecGroupThreadNum(_dblwr_dump_thread_num, cfg_n,
                _dblwr_dump_thread_pool, _dblwr_dump_thread_pool->size(),
                [this](Context* ctx){
                    Schedule(ctx TRACE_FILE_LINE_CC);
                });

        LOG_IF(NOTICE, cfg_n != cur_n) << "dblwr dump thread num per store changed,"
            << " old:[" << cur_n
            << "] new:[" << cfg_n
            << "]";
        ret = ret || cfg_n != cur_n;
    }
    return ret;
}

void GcManager::Dispatch(SegmentPtr segment TRACE_FILE_LINE_DC, gaia_apply::lsn_t lsn) {
    LOG(TRACE) << segment << " push log block to gc, lsn:[" << lsn << "]" << TRACE_FILE_LINE_LOG_STR;
    LogBlockPtr log_block = segment->NextAppendLogBlock(true);
    if (log_block) {
        DoAppendFileGc(segment, log_block);
    }
}

void GcManager::DumpDblwrBuf(SegmentPtr segment) {
    LOG(TRACE) << segment << " start to dump dblwr bufs";
    std::unique_lock lk(segment->light_shared_mutex());
    if (segment->dblwr_ctx()) {
        return;
    }
    auto* ctx = new Context(Action::kDblwrDump, segment);
    SetCtxClientId(ctx);
    segment->set_dblwr_ctx(ctx);
    Schedule(ctx TRACE_FILE_LINE_CC);
}

void GcManager::SetCtxClientId(Context* ctx) {
    static std::atomic<uint32_t> round_robin_id = 0;
    auto segment = ctx->segment.lock();
    if (segment) {
        ctx->client_id = (segment->hash_val() + ctx->parallel_idx);
        ctx->thread_pool_idx = segment->store_id();
    } else {
        auto idx = round_robin_id.fetch_add(1, std::memory_order_relaxed);
        ctx->client_id = idx % (is_append_action(ctx) ? _append_thread_num
                : (is_dblwr_action(ctx) ? _dblwr_dump_thread_num : _thread_num));
        ctx->thread_pool_idx = 0;
    }
}

const GcManager::ThreadPoolTypePtr& GcManager::GetThreadPool(Context* ctx) const {
    if (is_append_action(ctx)) {
        return _append_thread_pool;
    } else if (is_dblwr_action(ctx)) {
        return _dblwr_dump_thread_pool;
    }
    return _thread_pool;
}

bool GcManager::Execute(Context* ctx) {
    SegmentPtr segment = ctx->segment.lock();
    if (segment) {
        if (is_append_action(ctx)) {
            segment_set_stage_info_with_action(segment, pspb::AppendStageSchedule, ctx->action);
        } else if (is_dblwr_action(ctx)) {
            segment_set_stage_info_with_action(segment, pspb::DblwrStageSchedule, ctx->action);
        } else {
            segment_set_stage_info_with_action(segment, pspb::GCStageSchedule, ctx->action);
        }
    }
    if (!GetThreadPool(ctx)->EmergentExecute(ctx->thread_pool_idx, ctx)) {
        if (_stopped) {
            std::unique_ptr<Context> ctx_guard(ctx);
        } else {
            psvr_terminate();
        }
        return false;
    }
    return true;
}

void GcManager::Schedule(Context* ctx TRACE_FILE_LINE_DC, uint64_t delay_us, bool is_retry) {
    PSVR_LOG_CTX(TRACE, ctx) << "ctx action:[" << static_cast<uint32_t>(ctx->action) << "," << action2str(ctx->action)
        << "] retry_times:[" << ctx->retry_times
        << "] ctx:[" << ctx
        << "]" << TRACE_FILE_LINE_LOG_STR;
    _stat_gc_schedule_qps << 1;
    if (BAIDU_UNLIKELY(_stopped)) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }
    SetCtxClientId(ctx);

    SegmentPtr segment = ctx->segment.lock();
    if (segment) {
        if (is_append_action(ctx)) {
            segment_set_stage_info_with_action(segment, pspb::AppendStageSchedule, ctx->action);
        } else if (is_dblwr_action(ctx)) {
            segment_set_stage_info_with_action(segment, pspb::DblwrStageSchedule, ctx->action);
        } else {
            segment_set_stage_info_with_action(segment, pspb::GCStageSchedule, ctx->action);
        }
    }

    if (is_retry) {
        ++ctx->retry_times;
    }
    if (delay_us == 0) {
        if (GetThreadPool(ctx)->Execute(ctx->thread_pool_idx, ctx)) {
            return;
        }
    } else {
        if (GetThreadPool(ctx)->Schedule(ctx->thread_pool_idx, ctx, delay_us)) {
            return;
        }
    }

    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }

    PSVR_LOG_CTX(ERROR, ctx) << "dispatch segment to gc pool failed,"
        << TRACE_FILE_LINE_LOG_STR;
    psvr_terminate();
}

void GcManager::ConditionSchedule(SegmentPtr segment,
        Context* ctx, gaia_apply::lsn_t min_lsn, gaia_apply::lsn_t max_lsn) {
    _in_wait_size.fetch_add(1, std::memory_order_relaxed);
    PSVR_LOG_CTX(TRACE, ctx) << segment << " enqueue waiting gc task, lsn:[" << min_lsn << "," << max_lsn <<  "]";
    if (is_append_action(ctx)) {
        segment_set_stage_info_with_action(segment, pspb::AppendStageCondition, ctx->action);
    } else if (is_dblwr_action(ctx)) {
        segment_set_stage_info_with_action(segment, pspb::DblwrStageCondition, ctx->action);
    } else {
        segment_set_stage_info_with_action(segment, pspb::GCStageCondition, ctx->action);
    }
    _condition_thread_pool->Schedule(segment->GetClusterHashVal(),
            ConditionTask(ctx, segment->cluster(), min_lsn, max_lsn,
                ctx->log_block->valid_records_count, ctx->log_block->time));
}

void GcManager::ConditionFn(const ConditionTask& task) {
    _in_wait_size.fetch_sub(1, std::memory_order_relaxed);
    PSVR_LOG_CTX(TRACE, task.ctx) << "dequeue waiting gc task";
    ADD_TRACE_TP_EXTRA(task.ctx->tp, false, "dequeue");
    task.ctx->cond_retry_times += task.retry_nr;
    Execute(task.ctx);
}

void GcManager::OnCompletion(Context* ctx) {
    PSVR_LOG_CTX(TRACE, ctx) << "ctx action:[" << static_cast<uint32_t>(ctx->action) << "," << action2str(ctx->action)
        << "] retry_times:[" << ctx->retry_times
        << "] ctx:[" << ctx
        << "]";
    if (BAIDU_UNLIKELY(_stopped)) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }

    SegmentPtr segment = ctx->segment.lock();
    if (segment) {
        if (is_append_action(ctx)) {
            segment_set_stage_info_with_action(segment, pspb::AppendStageDo, ctx->action);
        } else if (is_dblwr_action(ctx)) {
            segment_set_stage_info_with_action(segment, pspb::DblwrStageDo, ctx->action);
        } else {
            segment_set_stage_info_with_action(segment, pspb::GCStageDo, ctx->action);
        }
    }

    switch (ctx->action) {
    case Action::kRecoverPage:
        return RecoverPage(ctx);
    case Action::kDisposeRecoveryPage:
        return DisposeRecoveryPage(ctx);
    case Action::kGcLogBlock:
        return GcLogBlock(ctx);
    case Action::kPreAppendFileGc:
        return PreAppendFileGc(ctx);
    case Action::kAppendFileGc:
        return AppendFileGc(ctx);
    case Action::kFinishGcLogBlock:
        return FinishGcLogBlock(ctx);
    case Action::kDblwrDump:
        return DblwrDump(ctx);
    default:
        PSVR_ASSERT(false);
        return;
    }
}

void GcManager::DoAppendFileGc(SegmentPtr segment, LogBlockPtr log_block) {
    auto* ctx = new Context(Action::kPreAppendFileGc, segment, log_block);
    auto head = log_block;
    bool has_records = false;
    while (head) {
        size_t fold_size = head->fold_space_page_lsn_map.size();
        if (fold_size > 0 && head->from_append_file == FROM_NONE) {
            size_t align_fold_size = 0;
            for (auto& it : head->fold_space_page_lsn_map) {
                const auto& fold = it.first;
                if (head->fold_space_align_pages.emplace(fold_space_page_align(fold)).second) {
                    ++align_fold_size;
                }
            }
            head->fold_space_page_offset_cache.Init(align_fold_size);
            has_records = true;
        }
        head = head->next;
        ++ctx->merge_size;
    }

    ctx->merge_head = log_block;
    if (has_records) {
        Schedule(ctx TRACE_FILE_LINE_CC);
    } else {
        // not records to apply
        ctx->action = Action::kAppendFileGc;
        Schedule(ctx TRACE_FILE_LINE_CC);
    }
}

void GcManager::OnPreAppendFileGc(Context* ctx) {
    if (ctx->get_meta_reqs_count.fetch_sub(1) == 1) {
        Schedule(ctx TRACE_FILE_LINE_CC);
    }
}

void GcManager::PreAppendFileGc(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);
    LogBlockPtr log_block = ctx->merge_head;
    auto ignore_corrupt_info = segment->cluster()->ignore_corrupt_info();
    auto& offset_cache = log_block->fold_space_page_offset_cache;
    size_t unreadly_num = 0;
    auto it = log_block->fold_space_align_pages.begin();
    while(it != log_block->fold_space_align_pages.end()) {
        auto fold = *it;
        uint64_t physical_offset = kInvalidOffset;
        if (segment->GetSpacePagePhysicalOffset(fold.space_id, fold.page_no, &physical_offset)) {
            PSVR_ASSERT(physical_offset % GAIADB_EXTENT_SIZE == 0);
            const uint32_t extent_id = physical_offset >> GAIADB_EXTENT_SIZE_SHIFT;
            offset_cache.Add(fold_space_page_to_key(fold), extent_id);
            it = log_block->fold_space_align_pages.erase(it);
        } else if (!ignore_corrupt_info->empty()
                && ignore_corrupt_info->Exist(segment->segment_id(), fold.space_id)) {
            // ignore it
            offset_cache.Add(fold_space_page_to_key(fold), gaia_apply::FIL_NULL);
            it = log_block->fold_space_align_pages.erase(it);
        } else {
            ++it;
            ++unreadly_num;
        }
    }

    bool cluster_enable_encrypt = false;
    ClusterPtr cluster = segment->cluster();
    if (cluster.get() != nullptr) {
        cluster_enable_encrypt = cluster->enable_encrypt();
    }
    std::set<gaia_apply::space_id_t> space_need_encrypt_metas;
    if (FLAGS_psvr_enable_encrypt && cluster_enable_encrypt) {
        for (auto space_id : log_block->fold_space_ids) {
            const uint32_t encrypt_status = segment->GetSpaceEncryptStatus(space_id);
            if (space_encrypt_status_is_unknown(encrypt_status)) {
                space_need_encrypt_metas.emplace(space_id);
                ++unreadly_num;
            }
        }
    }

    if (unreadly_num == 0) {
        offset_cache.set_init();
        if (!log_block->next) {
            ctx->action = Action::kAppendFileGc;
            AppendFileGc(ctx);
        } else {
            ctx->merge_head = log_block->next;
            Schedule(ctx TRACE_FILE_LINE_CC);
        }
        return;
    }

    ctx->get_meta_reqs_count.store(unreadly_num);
    auto tmp_fold_space_align_pages = log_block->fold_space_align_pages;
    for (auto& fold : tmp_fold_space_align_pages) {
        auto closure = brpc::NewCallback(this, &GcManager::OnPreAppendFileGc, ctx);
        control->parser()->AddGetSpaceExtentEvent(segment TRACE_FILE_LINE_CC,
                fold.space_id, fold.page_no, closure, nullptr);
    }
    for (auto& space_id : space_need_encrypt_metas) {
        auto closure = brpc::NewCallback(this, &GcManager::OnPreAppendFileGc, ctx);
        control->parser()->AddGetSpaceMetaEvent(segment TRACE_FILE_LINE_CC,
                                                space_id, closure, nullptr);
    }
}

void GcManager::AppendFileGc(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);
    LogBlockPtr log_block = ctx->log_block;

    if (log_block->from_append_file != FROM_LOCAL && FLAGS_psvr_enable_append_file) {
        auto& offset_cache = log_block->fold_space_page_offset_cache;
        PSVR_ASSERT(offset_cache.pos() == offset_cache.size());

        db::Status st = segment->AppendLog(log_block);
        if (!st.IsOk()) {
            PSVR_LOG_CTX(ERROR, ctx) << segment << " gc append log failed, " << st
                << " log_block:[" << log_block
                << "]";
            ctx->action = Action::kAppendFileGc;
            Schedule(ctx TRACE_FILE_LINE_CC, gc_get_delay_us(ctx->retry_times), true);
            return;
        }
        _stat_gc_append_merge_size << ctx->merge_size;
    }

    segment->AddAppendLogBlock(log_block);

    std::unique_ptr<Context> ctx_guard(ctx);
    LogBlockPtr next_log_block = segment->NextAppendLogBlock(false, ctx->merge_size);
    if (next_log_block) {
        DoAppendFileGc(segment, next_log_block);
    } else {
        segment_set_stage_info(segment, pspb::AppendStageIdle);
    }

    log_block = segment->NextGcLogBlock(true, ctx->merge_size);
    if (log_block) {
        PreGcLogBlock(segment, log_block);
    }
}

void GcManager::OnEvent(Context* ctx, pspb::Status* st) {
    define_segment_or_return_invalid(ctx);
    const bool ok = st->code() == pspb::Status::SUCCESS;
    LOG_IF_EVERY_N(WARNING, !ok, 64) << segment << " gc get page meta failed, " << ctx->st;
    if (ok) {
        ctx->retry_times = 0;
        Execute(ctx);
    } else {
        Schedule(ctx TRACE_FILE_LINE_CC, gc_get_delay_us(ctx->retry_times), true);
    }
}

void GcManager::RetryGcLogBlock(Context* ctx TRACE_FILE_LINE_DC, bool ok) {
    ctx->action = Action::kGcLogBlock;
    if (ok) {
        ctx->retry_times = 0;
        Execute(ctx);
    } else {
        Schedule(ctx TRACE_FILE_LINE_ARG_CC, gc_get_delay_us(ctx->retry_times), true);
    }
}

void GcManager::PreGcLogBlock(SegmentPtr segment, LogBlockPtr log_block) {
    ControlPtr control = _control.lock();
    if (!control || _stopped) {
        return;
    }
    if (!log_block->is_parsed) {
        PSVR_LOG(ERROR, log_block->log_id) << segment << " lb status invalid,"
            << " status:[" << log_block->is_parsed
            << " logblock:[" << log_block
            << "]";
        return;
    }

    log_block->PrepareGc();
    _stat_gc_parallel_size << log_block->parallel_size;

    _prior_thread_num = FLAGS_multi_psvr_gc_prior_thread_num_per_group;
    ADD_TRACE_TP(log_block->tp, "start_gc_%d", log_block->parallel_size);

    PSVR_LOG(TRACE, log_block->log_id) << segment << " prepare start gc log_block,"
        << " end_lsn:[" << log_block->end_lsn
        << "] records_count:[" << log_block->records_count
        << "] parallel_size:[" << log_block->parallel_size
        << "]";

    auto parallel_task = std::make_shared<ParallelTask>();
    if (_prior_thread_num < _thread_num && _prior_thread_num) {
        if (log_block->parallel_size > 1
#define LOG_BLOCK_MAX_LAG_LSN_ON_NORMAL_THREAD 500lu
                || (log_block->end_lsn + MBToByte(LOG_BLOCK_MAX_LAG_LSN_ON_NORMAL_THREAD))
                        < segment->GetClusterCnLowestLsn()) {
            parallel_task->in_prior_thread = true;
            PSVR_LOG_EVERY_SECOND(TRACE, log_block->log_id) << segment << " in prior thread,"
                << " parallel_size:[" << log_block->parallel_size
                << "] valid_records_count:[" << log_block->valid_records_count
                << "] end_lsn:[" << log_block->end_lsn
                << "] cn_lsn:[" << segment->GetClusterCnLowestLsn()
                << "]";
        }
    }
    const bool enable_gc = log_block->EnableGc(segment->GetClusterCnLowestLsn());
    for (int32_t idx = 0; idx < log_block->parallel_size; ++idx) {
        auto* ctx = new Context(Action::kGcLogBlock, segment, log_block);
        ctx->log_id = log_block->log_id;
        ctx->parallel_idx = idx;
        ctx->parallel_task = parallel_task;
        if (!parallel_task->in_prior_thread) {
            ctx->client_id = _prior_thread_num + ctx->client_id % (_thread_num + _prior_thread_num);
        }

        ctx->stat_timer.reset();
        TP_INIT_IF(ctx->tp, FLAGS_psvr_enable_gc_annotate);

        // get meta in advance if need
        auto& chunk = *log_block->chunks[idx];
        std::shared_lock slk(chunk.shared_mutex);
        size_t fold_size = chunk.fold_space_page_lsn_map.size();
        if (fold_size > 0 && log_block->from_append_file == FROM_NONE) {
            ctx->get_meta_reqs_count.store(fold_size);
            for (auto& it : chunk.fold_space_page_lsn_map) {
                auto& fold = it.first;
                if (!segment->ExistSpacePagePhysicalOffset(fold.space_id, fold.page_no)) {
                    PSVR_LOG_CTX(TRACE, ctx) << segment << " gc need get space extent first,"
                        << " space_id:[" << fold.space_id
                        << "] page_no:[" << fold.page_no
                        << "] parallel_idx:[" << idx
                        << "]";
                    --fold_size;
                    _stat_gc_get_space_extent_in_advance_qps << 1;
                    auto closure = brpc::NewCallback(this, &GcManager::OnPreEvent, ctx);
                    control->parser()->AddGetSpaceExtentEvent(segment TRACE_FILE_LINE_CC,
                            fold.space_id, fold.page_no, closure, nullptr);
                }
            }

            if (fold_size == 0
                    || ctx->get_meta_reqs_count.fetch_sub(fold_size) != fold_size) {
                continue;
            }
        }

        if (enable_gc || log_block->EnableGc(segment->GetClusterCnLowestLsn())) {
            ADD_TRACE_TP(ctx->tp, "begin");
            Schedule(ctx TRACE_FILE_LINE_CC);
        } else {
            ADD_TRACE_TP(ctx->tp, "enqueue");
            _stat_gc_interrupt_by_lsn_qps << 1;
            ++ctx->interrupt_times;
            ConditionSchedule(segment, ctx, log_block->start_lsn, log_block->end_lsn);
        }
    }
}

void GcManager::OnPreEvent(Context* ctx) {
    if (ctx->get_meta_reqs_count.fetch_sub(1) == 1) {
        define_control_or_return_invalid(ctx);
        define_segment_or_return_invalid(ctx);
        if (ctx->log_block->EnableGc(segment->GetClusterCnLowestLsn())) {
            ADD_TRACE_TP(ctx->tp, "meta_begin");
            Schedule(ctx TRACE_FILE_LINE_CC);
        } else {
            ADD_TRACE_TP(ctx->tp, "meta_enqueue");
            _stat_gc_interrupt_by_lsn_qps << 1;
            ++ctx->interrupt_times;
            ConditionSchedule(segment, ctx, ctx->log_block->start_lsn, ctx->log_block->end_lsn);
        }
    }
}

void GcManager::GcLogBlock(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    // check dblwr bufs are dump to idb file if disable dblwer.
    if (FLAGS_psvr_dblwr_max_page_num <= 0 && segment->DblwrHasBufs()) {
        db::Status st = segment->DumpDblwrBuf(ctx->log_id);
        if (!st.IsOk()) {
            PSVR_LOG_CTX(TRACE, ctx) << segment << " dump dblwr buf failed, "
                << st;
            Schedule(ctx TRACE_FILE_LINE_CC, gc_get_delay_us(ctx->retry_times), true);
            return;
        }
        if (segment->DblwrHasBufs()) {
            Schedule(ctx TRACE_FILE_LINE_CC);
            return;
        }
    }

    if (FLAGS_psvr_dblwr_buf_file_limit_per_segment > 0
            && FLAGS_psvr_dblwr_max_page_num > 0
            && FLAGS_psvr_enable_append_file
            && segment->dblwr() != nullptr
            && segment->dblwr()->bufs_size() >= static_cast<size_t>(FLAGS_psvr_dblwr_buf_file_limit_per_segment)) {
        PSVR_LOG_CTX(WARNING, ctx) << segment << " dump dblwr files number exceed limited,"
            << " num:[" << segment->dblwr()->bufs_size()
            << "], limit:[" << FLAGS_psvr_dblwr_buf_file_limit_per_segment
            << "]";
        WakeupDblwr(segment);
        Schedule(ctx TRACE_FILE_LINE_CC, gc_get_delay_us(ctx->retry_times), true);
        return;
    }

    set_segment_statistic(segment, stat_gc_schedule_count, 1);

    LogBlockPtr log_block = ctx->log_block;
    const int32_t parallel_idx = ctx->parallel_idx;
    ++ctx->gc_times;
    ADD_TRACE_TP(ctx->tp, "gc_%d", ctx->gc_times);

    const auto parse_lsn = segment->parse_lsn();
    PSVR_ASSERT(parse_lsn >= log_block->end_lsn);

    const auto real_cn_lowest_lsn = segment->GetClusterCnLowestLsn();
    if (log_block->start_lsn >= real_cn_lowest_lsn) {
        _stat_gc_interrupt_by_lsn_qps << 1;
        ++ctx->interrupt_times;
        ConditionSchedule(segment, ctx, log_block->start_lsn, log_block->end_lsn);
        return;
    }

    LogBlockChunk& chunk = *log_block->chunks[parallel_idx];
    const bool incomplete_gc = log_block->end_lsn > real_cn_lowest_lsn;
    if (incomplete_gc) {
        PSVR_LOG_CTX(TRACE, ctx) << segment << " try incomplete gc,"
            << " start_lsn:[" << log_block->start_lsn
            << "] end_lsn:[" << log_block->end_lsn
            << "] real_cn_lowest_lsn:[" << real_cn_lowest_lsn
            << "] incomplete_lift_start_lsn:[" << chunk.incomplete_lift_start_lsn
            << "] parallel_idx:[" << parallel_idx
            << "]";
        if (real_cn_lowest_lsn <= chunk.incomplete_lift_start_lsn) {
            _stat_gc_interrupt_by_lsn_qps << 1;
            ++ctx->interrupt_times;
            ConditionSchedule(segment, ctx, chunk.incomplete_lift_start_lsn, log_block->end_lsn);
            return;
        }
    }

    auto ignore_corrupt_info = segment->cluster()->ignore_corrupt_info();
    { // start gc records
        std::unique_lock lk(chunk.shared_mutex);
        auto it = chunk.fold_space_page_lsn_map.begin();
        while (it != chunk.fold_space_page_lsn_map.end()) {
            ctx->space_id = it->first.space_id;
            ctx->page_no = it->first.page_no;
            const auto page_gc_begin_lsn = it->second.min_lsn;
            if (page_gc_begin_lsn >= real_cn_lowest_lsn) {
                ++it;
                PSVR_LOG_CTX(TRACE, ctx) << segment << " page not able to gc,"
                    << " page_gc_start_lsn:[" << page_gc_begin_lsn
                    << "] real_cn_lowest_lsn:[" << real_cn_lowest_lsn
                    << "] space:[" << ctx->space_id
                    << "] page:[" << ctx->page_no
                    << "] parallel_idx:[" << parallel_idx
                    << "]";
                continue;
            }

            if (!ignore_corrupt_info->empty()) {
                if (ignore_corrupt_info->Exist(segment->segment_id(), ctx->space_id)) {
                    PSVR_LOG_CTX(NOTICE, ctx) << segment << " gc with ignore corrupt space,"
                        << " space:[" << ctx->space_id
                        << "] page:[" << ctx->page_no
                        << "]";
                    it = chunk.fold_space_page_lsn_map.erase(it);
                    continue;
                }
            }

            ctx->page_physical_offset = kInvalidOffset;
            if (log_block->from_append_file == FROM_NONE) {
                const bool ret = segment->GetSpacePagePhysicalOffset(
                        ctx->space_id, ctx->page_no, &ctx->page_physical_offset);
                if (!ret) {
                    PSVR_LOG_CTX(NOTICE, ctx) << segment << " gc need get space extent first,"
                        << " space_id:[" << ctx->space_id
                        << "] page_no:[" << ctx->page_no
                        << "] parallel_idx:[" << parallel_idx
                        << "]";
                    _stat_gc_interrupt_by_space_extent_qps << 1;
                    ++ctx->interrupt_times;
                    auto closure = brpc::NewCallback(this, &GcManager::OnEvent, ctx, &ctx->st);
                    control->parser()->AddGetSpaceExtentEvent(segment TRACE_FILE_LINE_CC,
                            ctx->space_id, ctx->page_no, closure, &ctx->st);
                    return;
                }
            } else {
                const auto& offset_cache = log_block->fold_space_page_offset_cache;
                if (log_block->append_info.fold_size == 0) {
                    PSVR_LOG_CTX(NOTICE, ctx) << segment << " gc append loglock offset cache invalid,"
                        << " space_id:[" << ctx->space_id
                        << "] page_no:[" << ctx->page_no
                        << "] parallel_idx:[" << parallel_idx
                        << "] lsn_range:[" << log_block->start_lsn << "," << log_block->end_lsn
                        << "]";
                    Schedule(ctx TRACE_FILE_LINE_CC, gc_get_delay_us(ctx->retry_times), true);
                    return;
                }
                if (!offset_cache.is_init()) {
                    int32_t lock_v = 0;
                    if (!log_block->offset_cache_lock.compare_exchange_strong(lock_v, 1)) {
                        Schedule(ctx TRACE_FILE_LINE_CC, gc_get_delay_us(ctx->retry_times), true);
                        return;
                    }
                    const db::Status st = segment->GetLogBlockOffCache(log_block);
                    if (!st.IsOk()) {
                        lock_v = 1;
                        log_block->offset_cache_lock.compare_exchange_strong(lock_v, 0);
                        PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << segment << " gc get offset cache failed,"
                            << " space_id:[" << ctx->space_id
                            << "] page_no:[" << ctx->page_no
                            << "] parallel_idx:[" << parallel_idx
                            << "] lsn_range:[" << log_block->start_lsn << "," << log_block->end_lsn
                            << "] " << st;
                        Schedule(ctx TRACE_FILE_LINE_CC, gc_get_delay_us(ctx->retry_times), true);
                        return;
                    }
                }
                if (!get_physical_offset_from_cache(
                            offset_cache, ctx->space_id, ctx->page_no,
                            &ctx->page_physical_offset)) {
                    PSVR_LOG_EVERY_SECOND_CTX(WARNING, ctx) << segment << " gc not found page offset from cache,"
                        << " space_id:[" << ctx->space_id
                        << "] page_no:[" << ctx->page_no
                        << "] parallel_idx:[" << parallel_idx
                        << "] lsn_range:[" << log_block->start_lsn << "," << log_block->end_lsn
                        << "]";
                    Schedule(ctx TRACE_FILE_LINE_CC, gc_get_delay_us(ctx->retry_times), true);
                    return;
                }
            }

            const gaia_apply::lsn_t page_gc_end_lsn = it->second.max_lsn;
            const gaia_apply::lsn_t real_page_gc_end_lsn = std::min(page_gc_end_lsn, real_cn_lowest_lsn);
            gaia_apply::lsn_t page_max_gc_lsn = std::min(segment->parse_lsn(), segment->GetClusterCnLowestLsn());
            if (FLAGS_psvr_enable_append_file && segment->in_recovery() && page_max_gc_lsn > real_page_gc_end_lsn) {
                page_max_gc_lsn = real_page_gc_end_lsn;
            }
            PSVR_ASSERT(real_page_gc_end_lsn <= log_block->end_lsn);
            PSVR_ASSERT(real_page_gc_end_lsn >= segment->gc_lsn());

            Timer timer_gc_page(base::Timer::STARTED);
            TimePoint* tp = nullptr;
            TP_INIT_IF(tp, FLAGS_psvr_enable_gc_annotate);
            db::Status s = segment->WritePageData(ctx->log_id, tp, ctx->space_id, ctx->page_no,
                    ctx->page_physical_offset, page_max_gc_lsn, real_page_gc_end_lsn, incomplete_gc);
            if (s.IsRetry()) {
                _stat_gc_retry_qps << 1;
                s = segment->WritePageData(ctx->log_id, tp, ctx->space_id, ctx->page_no,
                        ctx->page_physical_offset, page_max_gc_lsn, real_page_gc_end_lsn, incomplete_gc);
            }
            if (FLAGS_psvr_gc_page_long_query_time_us > 0
                    && TP_ELAPSED(tp, FLAGS_psvr_gc_page_long_query_time_us)) {
                PSVR_LOG_CTX(NOTICE, ctx) << segment << " slow gc page,"
                    << " space:[" << ctx->space_id
                    << "] page:[" << ctx->page_no
                    << "] end_lsn:[" << page_max_gc_lsn
                    << "] parallel_idx:[" << parallel_idx
                    << "] lsn_range:[" << log_block->start_lsn << "," << log_block->end_lsn
                    << "] " << s << tp;
            }
            TP_DESTROY(tp);
            if (s.IsMissData()) {
                _stat_gc_ignore_qps << 1;
            }
            set_segment_statistic(segment, stat_gc_page_lat, timer_gc_page.u_elapsed());

            PSVR_LOG_CTX(TRACE, ctx) << segment << " finish gc record,"
                << " space:[" << ctx->space_id
                << "] page:[" << ctx->page_no
                << "] record_end_lsn:[" << real_page_gc_end_lsn
                << "] end_lsn:[" << log_block->end_lsn
                << "] real_cn_lowest_lsn:[" << real_cn_lowest_lsn
                << "] incomplete_gc:[" << incomplete_gc
                << "] parallel_idx:[" << parallel_idx
                << "] " << s;

            PSVR_LOG_IF_CTX(WARNING,
                    !s.IsOk() && !s.IsAhead() && !s.IsMissData() && segment->recovery_status_is_finish(),
                    ctx) << segment << " gc apply log records failed," << s
                << " space:[" << ctx->space_id
                << "] page:[" << ctx->page_no
                << "] physical_offset:[" << ctx->page_physical_offset
                << "] record_end_lsn:[" << real_page_gc_end_lsn
                << "] max_gc_lsn:[" << page_max_gc_lsn
                << "] log_block:[" << log_block
                << "] real_cn_lowest_lsn:[" << real_cn_lowest_lsn
                << "] incomplete_gc:[" << incomplete_gc
                << "] parallel_idx:[" << parallel_idx
                << "]";

            if (s.IsOk()) {
                ++ctx->rw_times;
                ++chunk.real_gc_page_count;
                ++log_block->real_gc_page_count;
                _stat_gc_real_page_count << 1;
                ctx->retry_times = 0;
                if (real_page_gc_end_lsn >= page_gc_end_lsn) {
                    it = chunk.fold_space_page_lsn_map.erase(it);
                } else {
                    it->second.min_lsn = real_page_gc_end_lsn;
                    ++it;
                }
                set_segment_cluster_statistic(segment, stat_write_size_count, 1);
            } else if (s.IsAhead() || s.IsMissData()) {
                ctx->retry_times = 0;
                if (real_page_gc_end_lsn >= page_gc_end_lsn) {
                    it = chunk.fold_space_page_lsn_map.erase(it);
                } else {
                    it->second.min_lsn = real_page_gc_end_lsn;
                    ++it;
                }
            } else if (s.IsCorrupted() && FLAGS_psvr_gc_corrupted_enable_recover) {
                _stat_gc_record_err_count << 1;
                ++ctx->recover_times;
                ctx->retry_times = 0;
                ctx->action = Action::kRecoverPage;
                ADD_TRACE_TP(ctx->tp, "recover_%d", ctx->recover_times);
                Schedule(ctx TRACE_FILE_LINE_CC);
                return;
            } else {
                _stat_gc_record_err_count << 1;
                Schedule(ctx TRACE_FILE_LINE_CC, gc_get_delay_us(ctx->retry_times), true);
                return;
            }

            _stat_gc_page_count << 1;
            if (incomplete_gc) {
                _stat_gc_incomplete_lift_count << 1;
            }

            if (_stopped) {
                std::unique_ptr<Context> ctx_guard(ctx);
                return;
            }
        }
    } // end of gc record
    if (parallel_idx == 0) { // drop space
        auto it = log_block->drop_space_lsn_map.begin();
        while (it != log_block->drop_space_lsn_map.end()) {
            if (!incomplete_gc
                    || real_cn_lowest_lsn >= it->second) {
                segment->DropSpace(it->first, it->second);
                it = log_block->drop_space_lsn_map.erase(it);
            } else {
                ++it;
            }
        }
    }

    if (incomplete_gc) {
        chunk.incomplete_lift_start_lsn = real_cn_lowest_lsn;
    } else {
        chunk.incomplete_lift_start_lsn = log_block->end_lsn;
    }
    segment->RetryPushGcLsn(log_block, chunk);

    if (_stopped) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }

    if (incomplete_gc) {
        chunk.real_gc_page_count = 0;
        _stat_gc_interrupt_by_lsn_qps << 1;
        ++ctx->interrupt_times;
        ConditionSchedule(segment, ctx, real_cn_lowest_lsn, log_block->end_lsn);
        return;
    }

    {
        std::shared_lock slk(chunk.shared_mutex);
        PSVR_ASSERT(chunk.fold_space_page_lsn_map.empty());
    }
    ADD_TRACE_TP(ctx->tp, "done");
    if (parallel_idx == 0
            && segment->GcDelayForRecovery(log_block->end_lsn)
            && FLAGS_psvr_gc_delay_for_recovery_us > 0
            && ctx->delay_times++ < FLAGS_psvr_gc_delay_max_times_for_recovery) {
        _stat_gc_interrupt_by_recover_qps << 1;
        PSVR_LOG_EVERY_SECOND_CTX(NOTICE, ctx) << segment << " delay gc for recover data,"
            << " end_lsn:[" << log_block->end_lsn
            << "]";
        Schedule(ctx TRACE_FILE_LINE_CC, FLAGS_psvr_gc_delay_for_recovery_us, true);
        return;
    }

    if (FLAGS_psvr_gc_long_query_time_us > 0
            && TP_ELAPSED(ctx->tp, FLAGS_psvr_gc_long_query_time_us)) {
        PSVR_LOG_CTX(NOTICE, ctx) << segment << " slow gc request,"
            << " lsn_range:[" << log_block->start_lsn << "," << log_block->end_lsn
            << "] task_parallel_idx:[" << parallel_idx
            << "] task_gc_times:[" << ctx->gc_times
            << "] task_rw_times:[" << ctx->rw_times
            << "] task_interrupt_times:[" << ctx->interrupt_times
            << "] task_delay_times:[" << ctx->delay_times
            << "] task_cond_retry_times:[" << ctx->cond_retry_times
            << "] buf_size:[" << log_block->data_length()
            << "] records_count:[" << log_block->valid_records_count
            << "] parallel_count:[" << log_block->parallel_size
            << "]" << ctx->tp;
    }

    PSVR_ASSERT(real_cn_lowest_lsn >= log_block->end_lsn);

    _stat_gc_task_lat << ctx->stat_timer.u_elapsed();
    _stat_gc_task_dispatch_size << ctx->gc_times;
    set_segment_statistic(segment, stat_gc_task_lat, ctx->stat_timer.u_elapsed());
    set_segment_statistic(segment, stat_gc_task_size, ctx->gc_times);

    if (log_block->gc_ref_nr.fetch_sub(1, std::memory_order_relaxed) != 1) {
        std::unique_ptr<Context> ctx_guard(ctx);
        return;
    }

    // finish
    FinishGcLogBlock(ctx);
}

void GcManager::FinishGcLogBlock(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    LogBlockPtr log_block = ctx->log_block;
    const auto real_cn_lowest_lsn = segment->GetClusterCnLowestLsn();
    PSVR_ASSERT(real_cn_lowest_lsn >= log_block->end_lsn);
    PSVR_ASSERT(log_block->gc_ref_nr.load() == 0);

    if (BAIDU_UNLIKELY(FLAGS_psvr_in_chaos)) {
        // do check page recs purge
        for (auto page : log_block->page_refs) {
            PSVR_ASSERT(page->LogRecordIsEmpty(log_block->end_lsn));
        }
    }

    if (ctx->parallel_task->in_prior_thread) {
        set_segment_statistic(segment, stat_gc_logblock_in_prior_thread_count, 1);
    }

    const db::Status st = segment->UpdateAppendDBCheckPoint(log_block->end_lsn);
    if (!st.IsOk() && !st.IsAhead()) {
        PSVR_LOG_CTX(WARNING, ctx) << segment << " update append db checkpoint failed," << st;
        ctx->action = Action::kFinishGcLogBlock;
        Schedule(ctx TRACE_FILE_LINE_CC, gc_get_delay_us(ctx->retry_times), true);
        return;
    }

    std::unique_ptr<Context> ctx_guard(ctx);

    segment->PushGcLsn(log_block);
    set_segment_statistic(segment, stat_gc_logblock_real_lat, ctx->parallel_task->latency_us());

    ADD_TRACE_TP(log_block->tp, "gc_done");
    if (FLAGS_psvr_logblock_long_query_time_us > 0
            && TP_ELAPSED(log_block->tp, FLAGS_psvr_logblock_long_query_time_us)) {
        PSVR_LOG_CTX(NOTICE, ctx) << segment << " slow logblock,"
            << " lsn_range:[" << log_block->start_lsn << "," << log_block->end_lsn
            << "]" << log_block->tp;
    }

    _stat_gc_log_block_bw << log_block->data_length();
    _stat_gc_log_block_lsn_size << log_block->lsn_length();
    set_segment_cluster_statistic(segment, stat_log_block_buf_bw, log_block->data_length());
    set_segment_cluster_statistic(segment, stat_log_block_page_bw, log_block->real_gc_page_count.load());

    PSVR_LOG_CTX(TRACE, ctx) << segment << " finish gc log_block,"
        << " start_lsn:[" << log_block->start_lsn
        << "] end_lsn:[" << log_block->end_lsn
        << "] parallel_idx:[" << ctx->parallel_idx
        << "] parallel_count:[" << log_block->parallel_size
        << "]";

    LogBlockPtr next_log_block = segment->NextGcLogBlock(false);
    if (next_log_block) {
        PreGcLogBlock(segment, next_log_block);
    } else {
        segment_set_stage_info(segment, pspb::GCStageIdle);
    }
}

void GcManager::RecoverPage(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    std::vector<gaiadb::common::PeerZone> peers;
    if (!segment->GetPeerNodes(&peers, ctx->retry_times == 0)) {
        if (peers.empty()) {
            PSVR_LOG_CTX(NOTICE, ctx) << segment << " gc recover need get peer nodes first";
            auto closure = brpc::NewCallback(this, &GcManager::OnEvent, ctx, &ctx->st);
            control->parser()->AddGetPeerEvent(segment TRACE_FILE_LINE_CC, closure, &ctx->st);
            return;
        } else {
            control->parser()->AddGetPeerEvent(segment TRACE_FILE_LINE_CC, nullptr, nullptr);
        }
    }

    auto buf_block = control->buf_pool()->AllocBufBlock(gaia_logical_page_size());
    if (!buf_block) {
        PSVR_LOG_CTX(WARNING, ctx) << segment << " alloc buf failed on gc";
        Schedule(ctx TRACE_FILE_LINE_CC, gc_get_delay_us(ctx->retry_times), true);
        return;
    }

    PSVR_ASSERT(ctx->page_physical_offset != gaia_apply::ULINT_UNDEFINED);
    ctx->read_peer_page_ctx.reset(new ReadPeerPageContext(ctx->space_id, ctx->page_no,
            segment->gc_lsn(), peers, buf_block));
    auto closure = brpc::NewCallback(this, &GcManager::OnRecoverPage, ctx);
    segment->ReadPeerPage(ctx->read_peer_page_ctx.get(), closure);
}

void GcManager::OnRecoverPage(Context* ctx) {
    define_control_or_return_invalid(ctx);
    TimerGuard lat_timer(_stat_gc_recover_rpc_lat, ctx->read_peer_page_ctx->begin_time);
    ctx->action = Action::kDisposeRecoveryPage;
    if (ctx->read_peer_page_ctx->response.success) {
        ctx->retry_times = 0;
        Execute(ctx);
    } else {
        Schedule(ctx TRACE_FILE_LINE_CC, gc_get_delay_us(ctx->retry_times), true);
    }
}

void GcManager::DisposeRecoveryPage(Context* ctx) {
    auto read_peer_page_ctx = ctx->read_peer_page_ctx.release();
    std::unique_ptr<ReadPeerPageContext> read_peer_page_ctx_guard(read_peer_page_ctx);

    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    TimerGuard lat_timer(_stat_gc_recover_lat, read_peer_page_ctx->begin_time);

    if (!read_peer_page_ctx->response.success) {
        LOG_EVERY_SECOND(WARNING) << segment << " failed to read page data from peer during gc,"
            << " space:[" << ctx->space_id
            << "] page:[" << ctx->page_no
            << "]";
        _stat_gc_recover_err_count << 1;
        RetryGcLogBlock(ctx TRACE_FILE_LINE_CC);
        return;
    }

    auto local_buf_block = control->buf_pool()->AllocBufBlock(gaia_logical_page_size());
    if (!local_buf_block) {
        _stat_gc_recover_err_count << 1;
        RetryGcLogBlock(ctx TRACE_FILE_LINE_CC);
        return;
    }

    const uint64_t physical_page_no = ctx->page_physical_offset / gaia_physical_page_size();
    auto page_lock = segment->GetPageLock(physical_page_no);
    db::PageUniqueLock lm(page_lock);
    db::Status s = segment->ReadPhysicalPageData(ctx->log_id, ctx->page_physical_offset,
            gaia_physical_page_size(), local_buf_block->frame);
    if (!s.IsOk()) {
        if (!s.IsCorrupted()) {     // decompress or decrypt failed
            _stat_gc_recover_err_count << 1;
            RetryGcLogBlock(ctx TRACE_FILE_LINE_CC);
            return;
        }
    }

    // check local page if update by recoverer
    bool local_is_empty = false;
    if (!page_is_corrupted(local_buf_block->frame, gaia_physical_page_size(), &local_is_empty)
            && !local_is_empty
            && check_page_space(local_buf_block->frame, false, ctx->space_id, ctx->page_no)) {
        const auto local_page_lsn = buf_block_get_page_lsn(local_buf_block);
        const auto remote_page_lsn = buf_block_get_page_lsn(read_peer_page_ctx->response.buf_block);
        if (local_page_lsn >= remote_page_lsn) {
            PSVR_LOG_CTX(TRACE, ctx) << segment << " page alreay recovered,"
                << " space:[" << ctx->space_id
                << "] page:[" << ctx->page_no
                << "] offset:[" << ctx->page_physical_offset
                << "] " << s;
            _stat_gc_recover_err_count << 1;
            RetryGcLogBlock(ctx TRACE_FILE_LINE_CC, true);
            return;
        }
    }

    s = segment->WritePhysicalPageData(ctx->log_id, ctx->space_id, ctx->page_no,
            ctx->page_physical_offset, gaia_physical_page_size(), read_peer_page_ctx->response.buf_block->frame);
    if (!s.IsOk()) {
        PSVR_LOG_CTX(ERROR, ctx) << segment << " write failed,"
            << " space:[" << ctx->space_id
            << "] page:[" << ctx->page_no
            << "] offset:[" << ctx->page_physical_offset
            << "] " << s;
        _stat_gc_recover_err_count << 1;
    } else {
        PSVR_LOG_IF_CTX(NOTICE,
                segment->recovery_status_is_finish(), ctx) << segment << " recover ok,"
            << " space:[" << ctx->space_id
            << "] page:[" << ctx->page_no
            << "] page_lsn:[" << buf_block_get_page_lsn(read_peer_page_ctx->response.buf_block)
            << "] empty:[" << read_peer_page_ctx->response.is_empty
            << "] empty_page_count:[" << read_peer_page_ctx->response.empty_page_count
            << "] replicas_size:[" << read_peer_page_ctx->request.peers.size()
            << "] offset:[" << ctx->page_physical_offset
            << "]";
    }

    RetryGcLogBlock(ctx TRACE_FILE_LINE_CC, s.IsOk());
}

void GcManager::WakeupDblwr(SegmentPtr segment) {
    if (segment->wakeup_dblwr()) {
        return;
    }
    Context* ctx = static_cast<Context*>(segment->dblwr_ctx());
    if (ctx && GetThreadPool(ctx)->Cancel(ctx->thread_pool_idx, ctx)) {
        Execute(ctx);
    }
}

void GcManager::DblwrDump(Context* ctx) {
    define_control_or_return_invalid(ctx);
    define_segment_or_return_invalid(ctx);

    int32_t limit = std::max(FLAGS_psvr_dblwr_dump_max_num_per_round, 1);
    for (int32_t i = 0; i < limit; ++i) {
        TimerGuard lat_timer(_stat_gc_dblwr_dump_lat);
        db::Status st = segment->DumpDblwrBuf(ctx->log_id);
        if (!st.IsOk()) {
            PSVR_LOG_CTX(ERROR, ctx) << segment << " dump dblwr bufs failed, "
                << st;
            break;
        }
    }

    size_t do_next_n = FLAGS_psvr_dblwr_buf_file_limit_per_segment > 4 ?
        FLAGS_psvr_dblwr_buf_file_limit_per_segment / 4 : 1;
    if (segment->dblwr()->bufs_size() >= do_next_n) {
        ctx->retry_times = 0;
        Schedule(ctx TRACE_FILE_LINE_CC);
    } else {
        Schedule(ctx TRACE_FILE_LINE_CC, dblwr_dump_get_delay_us(ctx->retry_times), true);
    }
    segment->clear_wakeup_dblwr();
}

} // end of ns psvr
