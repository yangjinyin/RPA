/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/compress_context.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/context_types.h"
#include "psvr/compress.h"
#include "psvr/segment.h"

namespace psvr {

struct Compressor::Task {
    SegmentWeakPtr segment {};
    uint64_t offset;
    uint64_t size;
    int32_t store_id;
    bool running;

    Task(SegmentPtr seg)
        : segment(seg),
        offset(0),
        size(seg->segment_size()),
        store_id(seg->store_id()),
        running(false) {}
};

struct Compressor::Store {
    int32_t store_id;
    std::atomic<double> compress_rate;
    std::shared_ptr<Quota> task_quota;
    std::shared_ptr<FlowQuota> flow_quota;
    std::list<std::shared_ptr<Task>> compress_tasks;
    rwlock_t shared_mutex;

    Store(int32_t id) : store_id(id), compress_rate(0) {}
    ~Store() {}
};


struct Compressor::Context : public thread::TaskContext {
    Action action;

    int32_t fix_client_id {-1};
    int32_t shift_client_id {0};

    std::shared_ptr<Task> compress_task {nullptr};
    int32_t store_id {0};
    uint32_t retry_times {0};
    bool has_quota {false};
    uint64_t quota_size {0};

    gaia_apply::space_id_t trim_space_id {gaia_apply::SPACE_UNKNOWN};
    int64_t trim_space_id_time {0};

    int64_t segment_compress_before_size {-1};
    int64_t segment_compress_after_size {-1};
    int64_t segment_page_count {0};
    int64_t segment_compressed_page_count {0};
    int64_t segment_valid_compress_page_count {0};
    int64_t segment_trim_page_count {0};
    int64_t segment_empty_page_count {0};
    int64_t segment_non_empty_page_count {0};
    int64_t segment_compress_data_size {0};
    int32_t interrupt_by_quota_count {0};
    int32_t interrupt_by_meta_count {0};
    int32_t interrupt_by_other_count {0};
    int32_t interrupt_by_io_count {0};

    pspb::Status st;
    Timer stat_timer;

    Context(Action _action)
        : thread::TaskContext(CtxType::kCompress), action(_action) {}
    Context(Action _action, int32_t _store_id)
        : thread::TaskContext(CtxType::kCompress), action(_action), store_id(_store_id) {}
    virtual ~Context() {}
};


// tracks which store currently has a running TrimFreeExtent task, so that
// at most one trim task runs concurrently per store.
struct Compressor::TrimFreeExtentTask {
    std::map<uint32_t, std::atomic<uint32_t>> store_status;

    TrimFreeExtentTask(uint32_t store_count) {
        for (uint32_t i = 0; i < store_count; ++i) {
            store_status[i] = 0;
        }
    }

    bool CanRun(uint32_t store_id, uint32_t max) {
        uint32_t num = store_status[store_id].load();
        if (num >= max) {
            return false;
        }
        return store_status[store_id].compare_exchange_strong(num, num + 1);
    }

    void Finish(uint32_t store_id) {
        store_status[store_id].fetch_sub(1);
    }
};

}
