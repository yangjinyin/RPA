/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_buf.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/rpc_srv.h"

namespace psvr {
namespace test {

class MockRPCServer : public RPCServer {
public:
    MockRPCServer(ControlWeakPtr control, bool multi_type) : RPCServer(control, multi_type) {}
    virtual ~MockRPCServer() {}

    MOCK_METHOD0(Init, bool());
    MOCK_METHOD0(Start, bool());

};

}
}
