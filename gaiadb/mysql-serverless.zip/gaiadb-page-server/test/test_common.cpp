/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_common.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/common.h"
#include "psvr/option.h"
#include "psvr/namespace.h"
#include "bmock.h"

using ::testing::DoAll;
using ::testing::SetArgReferee;
using ::testing::Return;

namespace psvr {
namespace test {

class CommonTests : public PsvrTest {
 public:
    CommonTests() {}
    virtual ~CommonTests() {}

    void SetUp() {
        // The mock objects created by BMOCK_NS_METHOD attach their hooks at static-init
        // time, so they would stay in effect for the whole binary. Stop them all here and
        // let each test enable only the ones it injects with BMOCK_NS_RESUME.
        BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
    }

    void TearDown() {
    }

private:
};

TEST_F(CommonTests, test_sleep_for) {
    sleep_for(10);
    sleep_for(std::chrono::microseconds(10));
}

TEST_F(CommonTests, test_JoinVec) {
    std::vector<uint32_t> vec {1, 2, 4, 5};
    std::string vec_str = JoinVec(vec, ",%u");
    LOG(INFO) << vec_str;
    ASSERT_EQ(memcmp(vec_str.c_str(), "1,2,4,5, size:4", strlen("1,2,4,5, size:4") - 1), 0);

    uint64_t vec2[3] = {2, 4, 6};
    vec_str = JoinVec(vec2, 3, ",%lu");
    LOG(INFO) << vec_str;
    ASSERT_EQ(memcmp(vec_str.c_str(), "2,4,6, size:3", strlen("2,4,6, size:3") - 1), 0);
}

class Model2 : public Model<Model2> {
public:
    Model2(ClientPtr client, ControlWeakPtr control) : Model<Model2>(client, control) {}
    virtual void Join() {
    }
};

TEST_F(CommonTests, test_Model) {
    auto m = std::make_shared<Model2>(_mock_client, _control);
    ASSERT_TRUE(m->Start(1));
    m->Stop();
    auto sm = m->weak_this().lock();
    ASSERT_TRUE(sm != nullptr);
}

TEST_F(CommonTests, test_GuardFd) {
    std::filesystem::create_directory("./test1");
    std::string file = "./test1/test_close_file";
    int32_t fd = open(file.c_str(), O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
    printf("fd:%d, %m\n", fd);
    ASSERT_GT(fd, -1);
    {
        GuardFd guard_fd(fd);
    }
    ASSERT_EQ(fd, -1);
    std::filesystem::remove_all("./test1");
}

TEST_F(CommonTests, test_GuardFdPtr) {
    std::filesystem::create_directory("./test2");
    std::string file = "./test2/test_close_file";
    int32_t fd = open(file.c_str(), O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
    printf("fd:%d, %m\n", fd);
    ASSERT_GT(fd, -1);
    {
        GuardFdPtr guard_fd(&fd);
        ASSERT_EQ(fd, *guard_fd._fd);
        ASSERT_EQ(-1, guard_fd._none);
        fd = guard_fd.release();
        ASSERT_EQ(guard_fd._none, *guard_fd._fd);
        ASSERT_EQ(-1, *guard_fd._fd);
    }
    ASSERT_GT(fd, -1);
    ssize_t rwrite = pwrite(fd, std::string(1024, 'a').c_str(), 1024, 0);
    ASSERT_EQ(rwrite, 1024);

    {
        GuardFdPtr guard_fd(&fd);
    }
    ASSERT_EQ(fd, -1);
    std::filesystem::remove_all("./test2");
}

TEST_F(CommonTests, test_pb) {
    std::string error;
    pspb::ReadPageRequest pb_msg;
    ASSERT_FALSE(jsonstr2pb("", &pb_msg));
    bool ret = jsonstr2pb("{\"physical_offset\": 100}", &pb_msg, &error);
    LOG(NOTICE) << error;
    ASSERT_TRUE(ret);
    ASSERT_EQ(pb_msg.physical_offset(), 100);

    base::IOBuf in;
    pspb::ReadPageRequest pb_msg2;
    ASSERT_FALSE(parse_message_from_iobuf(&pb_msg2, in));
    ASSERT_FALSE(parse_message_from_iobuf(&pb_msg2, in, &error));

    base::IOBufAsZeroCopyOutputStream wrapper(&in);
    pb_msg.SerializeToZeroCopyStream(&wrapper);
    ASSERT_TRUE(parse_message_from_iobuf(&pb_msg2, in));
    ASSERT_EQ(pb_msg2.physical_offset(), 100);
}

TEST_F(CommonTests, test_Lsn) {
    Lsn lsn0;
    ASSERT_EQ(lsn0.get(), 0);

    Lsn lsn(1);
    ASSERT_EQ(lsn.get(), 1);

    lsn.set(0, true);
    ASSERT_EQ(lsn.get(), 1);

    lsn.set(0);
    ASSERT_EQ(lsn.get(), 0);

    lsn.set(1);
    ASSERT_EQ(lsn.get(), 1);

    lsn.set(2, true);
    ASSERT_EQ(lsn.get(), 2);

    Lsn lsn2(lsn);
    ASSERT_EQ(lsn2.get(), 2);
}

TEST_F(CommonTests, test_Manager) {
    Manager<int32_t, int32_t> manager;

    ASSERT_TRUE(manager.Get(1) == nullptr);
    ASSERT_FALSE(manager.Remove(1));
    ASSERT_TRUE(manager.GetOrCreate(1, 2) != nullptr);
    ASSERT_TRUE(manager.Get(1) != nullptr);
    ASSERT_TRUE(manager.Remove(1));
    ASSERT_TRUE(manager.Get(1) == nullptr);

    auto p1 = manager.GetOrCreate(1, 2);
    auto p2 = manager.GetOrCreate(1, 3);
    ASSERT_EQ(p1, p2);
    auto p3 = manager.Get(1);
    ASSERT_EQ(p1, p3);

    ASSERT_TRUE(manager.Get(2) == nullptr);
    {
        ASSERT_TRUE(manager.GetOrCreate(2, 2) != nullptr);
    }
    ASSERT_TRUE(manager.Get(2) != nullptr);
}

TEST_F(CommonTests, test_ResManager) {
    bvar::Adder<int64_t> stat;
    auto manager = std::make_shared<ResManager<int32_t, int64_t>>(stat);

    ASSERT_TRUE(manager->Get(2) == nullptr);
    {
        ASSERT_TRUE(manager->GetOrCreate(2) != nullptr);
    }
    ASSERT_TRUE(manager->Get(2) == nullptr);

    auto p1 = manager->GetOrCreate(2);
    auto p2 = manager->GetOrCreate(2);
    auto p3 = manager->Get(2);
    ASSERT_EQ(p1, p2);
    ASSERT_EQ(p1, p3);

    manager->Iterator([](int32_t i, std::shared_ptr<int64_t> it){
                std::cout << i << *it;
            });

    auto p4 = manager->GetOrCreate(3);
    manager->Remove(3);
    auto p5 = manager->GetOrCreate(3);
    ASSERT_EQ(p4, p5);
}

TEST_F(CommonTests, test_WaitLock) {
    gaiadb::common::Condition wait_lock;
    uint32_t n = 0;
    auto t1 = std::thread([&wait_lock, &n]() {
                while (++n < 10) {
                    wait_lock.wait(10);
                }
            });
    t1.join();
    ASSERT_GT(n, 0);

    n = 0;
    auto t2 = std::thread([&wait_lock, &n]() {
                std::unique_lock<std::mutex> lk(wait_lock.mutex());
                n = 50;
                LOG(NOTICE) << "set n to 50, wait notify";
                wait_lock.wait_with_lock(lk);
                n = 100;
                LOG(NOTICE) << "set n to 100, notify done";
            });
    do {
        if (n == 50) {
            {
                std::unique_lock<std::mutex> lk(wait_lock.mutex());
                // wait to release lock
            }
            LOG(NOTICE) << "n is 50, to notify";
            wait_lock.notify();
            break;
        }
        gaiadb::common::pause();
    } while (true);
    t2.join();
    ASSERT_EQ(n, 100);
}

TEST_F(CommonTests, test_Quota) {
    int64_t size = 100;
    Quota quota(&size);

    ASSERT_EQ(size, quota.total());
    ASSERT_EQ(size, quota.remain());

    ASSERT_FALSE(quota.Acquire(101));

    ASSERT_TRUE(quota.Acquire(10));
    ASSERT_TRUE(quota.Acquire(90));
    ASSERT_FALSE(quota.Acquire(1));

    quota.Release(60);
    ASSERT_FALSE(quota.Acquire(61));
    ASSERT_TRUE(quota.Acquire(60));

    quota.Release(100);
    ASSERT_TRUE(quota.Acquire(100));

    {
        quota.Release(100);
        std::atomic<int64_t> n = 0;
        auto t1 = std::thread([&quota, &n]() {
                for (uint32_t i = 1; i < 1000; ++i) {
                    if (quota.Acquire(i % 55)) {
                        n.fetch_add(i % 55);
                    }
                    usleep(10);
                }
            });
        auto t2 = std::thread([&quota, &n](){
                for (uint32_t i = 0; i < 1000; ++i) {
                    auto n1 = n.load();
                    if (n1 > 0) {
                        quota.Release(n1);
                        n.fetch_sub(n1);
                    }
                    usleep(12);
                }
            });
        size = 110;
        t1.join();
        t2.join();

        if (quota.total() == 110) {
            ASSERT_EQ(110, n.load() + quota.remain());
        } else {
            ASSERT_EQ(100, quota.total());
            ASSERT_EQ(100, n.load() + quota.remain());
        }
    }
}

TEST_F(CommonTests, test_AcquireLock) {
    AcquireLock lock;

    {
        lock.lock();
        ASSERT_FALSE(lock.try_lock());
        lock.unlock();
        ASSERT_TRUE(lock.try_lock());
        lock.unlock();
    }

    {
        {
            std::unique_lock<AcquireLock> lk(lock);
            ASSERT_FALSE(lock.try_lock());
        }
        ASSERT_TRUE(lock.try_lock());
        lock.unlock();
    }

    {
        lock.lock();
        {
            std::unique_lock<AcquireLock> lk(lock, std::adopt_lock);
            ASSERT_FALSE(lock.try_lock());
        }
        ASSERT_TRUE(lock.try_lock());
        lock.unlock();
    }

    {
        lock.lock();
        std::thread lock_thread([&lock](){
            lock.lock();
            ASSERT_FALSE(lock.try_lock());
            lock.unlock();
            ASSERT_TRUE(lock.try_lock());
            lock.unlock();
        });
        std::this_thread::sleep_for(std::chrono::seconds(5));
        lock.unlock();
        lock_thread.join();
        ASSERT_TRUE(lock.try_lock());
        lock.unlock();
    }
}

TEST_F(CommonTests, test_BitFlag) {
    {
        BitFlag bf(1);
        ASSERT_TRUE(bf.IsEmpty());
        ASSERT_FALSE(bf.IsFull());
        ASSERT_FALSE(bf.Test(0, 1));
        ASSERT_FALSE(bf[0]);

        bf.SetIdx(0);
        ASSERT_FALSE(bf.IsEmpty());
        ASSERT_TRUE(bf.IsFull());
        ASSERT_TRUE(bf.Test(0, 1));
        ASSERT_TRUE(bf[0]);

        bf.ClearIdx(0);
        ASSERT_TRUE(bf.IsEmpty());
        ASSERT_FALSE(bf.IsFull());
        ASSERT_FALSE(bf.Test(0, 1));
    }

    {
        BitFlag bf(2);
        ASSERT_TRUE(bf.IsEmpty());
        ASSERT_FALSE(bf.IsFull());
        ASSERT_FALSE(bf.Test(0, 1));
        ASSERT_FALSE(bf.Test(0, 2));
        ASSERT_FALSE(bf.Test(0));
        ASSERT_FALSE(bf.Test(1));

        bf.SetIdx(0);
        ASSERT_FALSE(bf.IsEmpty());
        ASSERT_FALSE(bf.IsFull());
        ASSERT_TRUE(bf.Test(0, 1));
        ASSERT_FALSE(bf.Test(1, 2));
        ASSERT_FALSE(bf.Test(0, 2));
        ASSERT_FALSE(bf.MajorityTest());
        ASSERT_TRUE(bf.Test(0));
        ASSERT_FALSE(bf.Test(1));

        bf.SetIdx(1);
        ASSERT_FALSE(bf.IsEmpty());
        ASSERT_TRUE(bf.IsFull());
        ASSERT_TRUE(bf.Test(0, 1));
        ASSERT_TRUE(bf.Test(1, 2));
        ASSERT_TRUE(bf.Test(0, 2));
        ASSERT_TRUE(bf.MajorityTest());
        ASSERT_TRUE(bf.Test(0));
        ASSERT_TRUE(bf.Test(1));
    }

    {
        BitFlag bf(3);
        ASSERT_TRUE(bf.IsEmpty());
        ASSERT_FALSE(bf.IsFull());
        ASSERT_FALSE(bf.Test(0, 1));
        ASSERT_FALSE(bf.Test(0, 2));
        ASSERT_FALSE(bf.Test(0, 3));

        bf.SetIdx(1);
        ASSERT_FALSE(bf.IsEmpty());
        ASSERT_FALSE(bf.IsFull());
        ASSERT_FALSE(bf.Test(0, 1));
        ASSERT_TRUE(bf.Test(1, 2));
        ASSERT_FALSE(bf.Test(2, 3));
        ASSERT_FALSE(bf.Test(0, 3));
        ASSERT_FALSE(bf.MajorityTest());

        bf.SetIdx(2);
        ASSERT_FALSE(bf.IsEmpty());
        ASSERT_FALSE(bf.IsFull());
        ASSERT_FALSE(bf.Test(0, 1));
        ASSERT_TRUE(bf.Test(1, 2));
        ASSERT_TRUE(bf.Test(1, 3));
        ASSERT_FALSE(bf.Test(0, 3));
        ASSERT_TRUE(bf.MajorityTest());
    }

    {
        BitFlag bf(5);
        ASSERT_TRUE(bf.IsEmpty());
        ASSERT_FALSE(bf.IsFull());
        ASSERT_FALSE(bf.Test(0, 1));
        ASSERT_FALSE(bf.Test(0, 2));
        ASSERT_FALSE(bf.Test(0, 3));
        ASSERT_FALSE(bf.Test(0, 4));
        ASSERT_FALSE(bf.Test(0, 5));

        bf.SetIdx(0);
        bf.SetIdx(2);
        bf.SetIdx(4);

        ASSERT_FALSE(bf.IsEmpty());
        std::cout << "bf:" << bf._v << ", bf.m:" << bf._mask << "\n";
        ASSERT_FALSE(bf.IsFull());
        ASSERT_TRUE(bf.Test(0, 1));
        ASSERT_FALSE(bf.Test(1, 2));
        ASSERT_TRUE(bf.Test(2, 3));
        ASSERT_FALSE(bf.Test(3, 4));
        ASSERT_FALSE(bf.Test(2, 4));
        ASSERT_TRUE(bf.MajorityTest());

        bf.SetIdx(3);
        ASSERT_TRUE(bf.Test(2, 4));
    }
}

TEST_F(CommonTests, test_FlowQuota_without_lock) {
    int64_t total = 128;
    FlowQuota flow_quota(&total);
    LOG(NOTICE) << "fill_rate:" << flow_quota._fill_rate;
    bool stopped = false;
    std::thread t1([&flow_quota, &stopped]{
            while (1) {
                int64_t us = flow_quota.GetQuota(1);
                if (us) {
                    sleep_for(us);
                }
                if (stopped) {
                    return;
                }
            }
        });
    for (uint32_t i = 0; i < 10; ++i) {
        LOG(NOTICE) << "flow bw:" << flow_quota.stat_used_size_per_seoncd().get_value();
        sleep_for(500 * 1000);
        if (i == 5) {
            total = 256;
        }
    }
    stopped = true;
    t1.join();
}

TEST_F(CommonTests, test_FlowQuota) {
    int64_t total = 128;
    FlowQuota flow_quota(&total, true);
    LOG(NOTICE) << "fill_rate:" << flow_quota._fill_rate;
    bool stopped = false;
    std::thread t1([&flow_quota, &stopped]{
            while (1) {
                int64_t us = flow_quota.GetQuota(1);
                if (us) {
                    sleep_for(us);
                }
                if (stopped) {
                    return;
                }
            }
        });
    std::thread t2([&flow_quota, &stopped]{
            while (1) {
                int64_t us = flow_quota.GetQuota(2);
                if (us) {
                    sleep_for(us);
                }
                if (stopped) {
                    return;
                }
            }
        });
    for (uint32_t i = 0; i < 10; ++i) {
        LOG(NOTICE) << "flow bw:" << flow_quota.stat_used_size_per_seoncd().get_value();
        sleep_for(500 * 1000);
        if (i == 5) {
            total = 256;
        }
    }
    stopped = true;
    t1.join();
    t2.join();
}

static bool read_file_data(const std::string& file,
        ssize_t read_size,
        std::string& file_data) {
    int fd = open(file.c_str(), O_RDWR);
    if (fd < 0) {
        return false;
    }
    file_data.resize(read_size);
    auto size = ::pread(fd, &(file_data[0]), read_size, 0);
    return size == read_size;
}

TEST_F(CommonTests, test_atomic_write_file) {
    std::filesystem::create_directory("./test");
    std::string file = "./test/test_atomic_file";
    std::string file_data = "iijjxx";
    bool rc = atomic_write_file(file, file_data, true);
    ASSERT_TRUE(rc);

    std::string output;
    rc = read_file_data(file, file_data.size(), output);
    ASSERT_TRUE(rc);
    ASSERT_EQ(file_data, output);

    file_data = "123456";
    rc = atomic_write_file(file, file_data, true);
    ASSERT_TRUE(rc);

    output.clear();
    rc = read_file_data(file, file_data.size(), output);
    ASSERT_TRUE(rc);
    ASSERT_EQ(file_data, output);
}

BMOCK_NS_METHOD1(gaiadb::common, terminate, void(int));
TEST_F(CommonTests, test_terminate) {
    BMOCK_NS_RESUME(gaiadb::common, terminate, void(int));
    EXPECT_CALL(BMOCK_NS_OBJECT(gaiadb::common, terminate), terminate(_))
        .WillOnce(Return());
    terminate();
    BMOCK_NS_STOP(gaiadb::common, terminate, void(int));
}

TEST_F(CommonTests, test_build_short_options) {
    auto kOptMax = 1;
    int long_opt_val;
    static struct option options[] = {
        {"ip", 1, NULL, 'a'},
        {"test", 0, NULL, 't'},
        {"addr", 1, &long_opt_val, kOptMax + 1},
        PSVR_ARGS_OPTION_END
    };

    std::string s = build_short_options(options);
    ASSERT_EQ(s, "a:t");
}

TEST_F(CommonTests, test_Timer) {
    {
        Timer timer;
        ASSERT_EQ(0, timer.start_time());
        timer.reset();
        ASSERT_NE(0, timer.start_time());
    }
    {
        Timer timer(base::Timer::STARTED);
        ASSERT_NE(0, timer.start_time());

        Timer timer2(timer);
        ASSERT_EQ(timer.start_time(), timer2.start_time());
    }

    {
        Timer timer(1l);
        ASSERT_EQ(1, timer.start_time());
        ASSERT_GT(timer.u_elapsed(), 0);
        sleep_for(1100);
        ASSERT_GT(timer.m_elapsed(), 0);
        sleep_for(1100000);
        ASSERT_GT(timer.s_elapsed(), 0);

        timer.u_elapsed_point();
        timer.m_elapsed_point();
        timer.s_elapsed_point();
    }
    {
        StatLatency lat;
        TimerGuard timer_guard(lat);
        timer_guard.start_time();
        timer_guard.u_elapsed();
        timer_guard.m_elapsed();
        timer_guard.s_elapsed();

        TimerGuard timer_guard2(lat, 1l);
    }
}

TEST_F(CommonTests, test_AutoStatLat) {
    StatLatency st;
    AutoStatLat auto_st(st);
}

}
}
