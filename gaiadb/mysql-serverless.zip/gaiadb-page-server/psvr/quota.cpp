/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/quota.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/quota.h"

namespace psvr {

bvar::Vector<int64_t, 2> get_quota_stat_fn(void* arg) {
    Quota* quota = static_cast<Quota*>(arg);
    bvar::Vector<int64_t, 2> result;
    result[0] = quota->total();
    result[1] = quota->remain();
    return result;
}

bvar::Vector<int64_t, 2> get_flow_quota_stat_fn(void* arg) {
    FlowQuota* flow_quota = static_cast<FlowQuota*>(arg);
    bvar::Vector<int64_t, 2> result;
    result[0] = flow_quota->max_per_second_quota();
    result[1] = flow_quota->stat_used_size_per_seoncd().get_value();
    return result;
}


}
