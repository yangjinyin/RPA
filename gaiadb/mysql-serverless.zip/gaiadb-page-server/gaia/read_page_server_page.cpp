/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/read_page_server_page.cpp
* @author guolingjie@baidu.com
* @brief
*/

#include <sstream>
#include <base/file_util.h>
#include "psvr/record_op.h"
#include "psvr/page_op.h"
#include "psvr/space.h"
#include "gaia/read_page_server_page.h"

namespace psvr {
namespace gaia {

constexpr uint32_t FSP_SIZE = 8;
constexpr uint32_t FSP_FREE_LIMIT = 12;
constexpr uint32_t FSP_SPACE_FLAGS = 16;
constexpr uint32_t FSP_FREE = 24;

constexpr uint32_t FIL_PAGE_DATA = 38;
constexpr uint32_t FSP_HEADER_OFFSET = FIL_PAGE_DATA;

constexpr uint32_t FSP_FLAGS_WIDTH_PAGE_SSIZE = 4;
constexpr uint32_t FSP_FLAGS_POS_POST_ANTELOPE = 0;
constexpr uint32_t FSP_FLAGS_WIDTH_POST_ANTELOPE = 1;
constexpr uint32_t FSP_FLAGS_WIDTH_ZIP_SSIZE = 4;
constexpr uint32_t FSP_FLAGS_WIDTH_ATOMIC_BLOBS = 1;
constexpr uint32_t FSP_FLAGS_POS_ZIP_SSIZE = FSP_FLAGS_POS_POST_ANTELOPE + FSP_FLAGS_WIDTH_POST_ANTELOPE;
constexpr uint32_t FSP_FLAGS_POS_ATOMIC_BLOBS = FSP_FLAGS_POS_ZIP_SSIZE + FSP_FLAGS_WIDTH_ZIP_SSIZE;
constexpr uint32_t FSP_FLAGS_POS_PAGE_SSIZE = FSP_FLAGS_POS_ATOMIC_BLOBS + FSP_FLAGS_WIDTH_ATOMIC_BLOBS;
constexpr uint32_t FSP_FLAGS_MASK_PAGE_SSIZE =
    (~(~0U << FSP_FLAGS_WIDTH_PAGE_SSIZE)) << FSP_FLAGS_POS_PAGE_SSIZE;

constexpr uint32_t FSP_FLAGS_GET_PAGE_SSIZE(uint32_t flags) {
    return (flags & FSP_FLAGS_MASK_PAGE_SSIZE) >> FSP_FLAGS_POS_PAGE_SSIZE;
}

void parse_page_0(const gaia_apply::byte* frame) {
    bool is_empty = false;
    if (page_is_corrupted(frame, gaia_apply::FLAGS_univ_page_size, &is_empty) || is_empty) {
        print_error("page is corrupted or empty:%d", is_empty);
        return;
    }
    gaia_apply::page_no_t page_no = gaia_apply::page_get_page_no(frame);
    if (page_no != 0) {
        return;
    }

    gaia_apply::page_no_t size = gaia_apply::mach_read_from_4(frame + FSP_HEADER_OFFSET + FSP_SIZE);
    gaia_apply::page_no_t free_limit = gaia_apply::mach_read_from_4(frame + FSP_HEADER_OFFSET + FSP_FREE_LIMIT);
    gaia_apply::page_no_t free = gaia_apply::mach_read_from_4(frame + FSP_HEADER_OFFSET + FSP_FREE);
    uint32_t flags = gaia_apply::mach_read_from_4(frame + FSP_HEADER_OFFSET + FSP_SPACE_FLAGS);
    gaia_apply::page_size_t page_size(flags);

    printf("%s %u\n", "space_size:", size);
    printf("%s %u\n", "space_free_limit:", free_limit);
    printf("%s %u\n", "space_free:", free);
    printf("%s %u\n", "space_flags:", flags);
    printf("%s %u\n", "space_size:", page_size.physical());
}

int ReadPageServerPage::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }
    if (_multi_type && (_cluster_id.empty() || !_segment_id.has_val)) {
        print_error("in multi_type, --cluster-id and --segment-id is required");
        return 1;
    }

    if (_segment_id.has_val && _segment_id.val < 1) {
        print_error("invalid value for --segment-id: %d", _segment_id.val);
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    if (_offset.has_val) {
        if (!_direct) {
            pspb::ReadPageRequest request;
            pspb::ReadPageResponse response;

            request.set_physical_offset(_offset.val);
            request.set_log_id(_log_id);
            if (!_cluster_id.empty()) {
                request.set_cluster_id(_cluster_id);
            }
            if (_segment_id.has_val) {
                request.set_segment_id(_segment_id.val);
            }
            request.set_request_lsn(_vlsn);
            request.set_size(std::max(_zip_len, gaia_apply::FLAGS_univ_page_size));

            RpcStatus status;
            _client.Call(_log_id++, node, &pspb::QueryService_Stub::ReadPhysicalPage, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (!status.IsOk()) {
                print_error("rpc request failed. %s", status.msg.c_str());
                return 1;
            }
            return Output(response);
        } else {
            pspb::ReadRequest request;
            pspb::ReadResponse response;

            if (!_cluster_id.empty()) {
                request.set_cluster_id(_cluster_id);
            }
            if (_segment_id.has_val) {
                request.set_segment_id(_segment_id.val);
            }
            request.set_offset(_offset.val);
            request.set_size(std::max(_zip_len, gaia_apply::FLAGS_univ_page_size));

            RpcStatus status;
            _client.Call(_log_id++, node, &pspb::QueryService_Stub::Read, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (!status.IsOk()) {
                print_error("rpc request failed. %s", status.msg.c_str());
                return 1;
            }
            return Output(response);
        }
    } else {
        if (_vlsn < LOG_START_LSN) {
            print_error("invalid value for --vlsn: %ld", _vlsn);
            return 1;
        }

        if (_space_id == std::numeric_limits<uint32_t>::max() ||
                _page_no == std::numeric_limits<uint32_t>::max()) {
            print_error("miss --space-id or --page-no");
            return 1;
        }

        pspb::RbioRequest request;
        pspb::RbioResponse response;
        request.set_requestid(_log_id);
        if (!_cluster_id.empty()) {
            request.set_cluster_id(_cluster_id);
        }
        if (_segment_id.has_val) {
            request.set_segment_id(_segment_id.val);
        }
        request.set_readtype(pspb::RbioRequest_Type_READ_SYNC);

        request.set_n(1);
        auto request_info = request.add_reqvec();
        request_info->set_tablespaceid(_space_id);
        request_info->set_logicalpageno(_page_no);
        request_info->set_vlsn(_vlsn);
        request_info->set_ziplen(_zip_len);

        RpcStatus status;
        _client.Call(_log_id++, node, &pspb::RbioService_Stub::Rbio, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            print_error("rpc request failed. %s", status.msg.c_str());
            return 1;
        }
        return Output(response);
    }
}

int ReadPageServerPage::Format(const pspb::ReadPageResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);

    const gaia_apply::byte* frame = reinterpret_cast<const gaia_apply::byte*>(rsp.data().c_str());

    auto space_id = gaia_apply::page_get_space_id(frame);
    auto page_no = gaia_apply::page_get_page_no(frame);
    auto lsn = gaia_apply::mach_read_from_8(frame + gaia_apply::FIL_PAGE_LSN);
    std::cout << "lsn:" << lsn
        << ", space_id:" << space_id << ", page_no:" << page_no << "\n";

    parse_page_0(frame);

    if (_dump_page) {
        std::stringstream ss;
        if (!_cluster_id.empty()) {
            ss << _cluster_id << "_" << _segment_id.val << "_";
        }
        ss << "offset_" << _offset.val;
        std::string file_path_str(ss.str());
        base::FilePath file_path(file_path_str);
        // file already exists, double check
        if (base::PathExists(file_path) && !_force) {
            bool cf_ret = execute_confirm("file[%s] already exists, do you want to overwrite it?", file_path_str.c_str());
            if (!cf_ret) {
                printf("quit!\n");
                return 1;
            }
        }
        base::File file(file_path, base::File::FLAG_OPEN_ALWAYS | base::File::FLAG_WRITE);

        file.Write(0, rsp.data().c_str(), rsp.data().size());
        file.Close();

        printf("%s %s %s\n", "page_file:", file_path_str.c_str(), "(try to read use [hexdump])");
    }
    return 0;
}

int ReadPageServerPage::Format(const pspb::ReadResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);

    const gaia_apply::byte* frame = reinterpret_cast<const gaia_apply::byte*>(rsp.data().c_str());

    auto space_id = gaia_apply::page_get_space_id(frame);
    auto page_no = gaia_apply::page_get_page_no(frame);
    auto lsn = gaia_apply::mach_read_from_8(frame + gaia_apply::FIL_PAGE_LSN);
    std::cout << "lsn:" << lsn
        << ", space_id:" << space_id << ", page_no:" << page_no << "\n";

    parse_page_0(frame);

    if (_dump_page) {
        std::stringstream ss;
        if (!_cluster_id.empty()) {
            ss << _cluster_id << "_" << _segment_id.val << "_";
        }
        ss << "offset_" << _offset.val;
        std::string file_path_str(ss.str());
        base::FilePath file_path(file_path_str);
        // file already exists, double check
        if (base::PathExists(file_path) && !_force) {
            bool cf_ret = execute_confirm("file[%s] already exists, do you want to overwrite it?", file_path_str.c_str());
            if (!cf_ret) {
                printf("quit!\n");
                return 1;
            }
        }
        base::File file(file_path, base::File::FLAG_OPEN_ALWAYS | base::File::FLAG_WRITE);

        file.Write(0, rsp.data().c_str(), rsp.data().size());
        file.Close();

        printf("%s %s %s\n", "page_file:", file_path_str.c_str(), "(try to read use [hexdump])");
    }
    return 0;
}

int ReadPageServerPage::Format(const pspb::RbioResponse& rsp) {
    Table __table(_raw_with_table, 2);
    __table.AddRowsValue({"request_id:", rsp.requestid()});
    __table.AddRowsValue({"code:", pspb::RbioResponse_Error_Name(rsp.errcode()).c_str()});
    __table.Display();
    if (rsp.errcode() != pspb::RbioResponse_Error_RBIO_SUCCESS) {
        return 1;
    }
    auto rsp_info = rsp.resvec(0);
    const gaia_apply::page_t* page =
        reinterpret_cast<const gaia_apply::page_t*>(rsp_info.pageframe().c_str());
    auto page_size = rsp_info.pageframe().size();
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"tablespace_id:", rsp_info.tablespaceid()});
    table.AddRowsValue({"page_no:", rsp_info.logicalpageno()});
    table.AddRowsValue({"vlsn:", rsp_info.vlsn()});
    table.AddRowsValue({"first 4 byte of page:", gaia_apply::mach_read_from_4(page)});
    table.AddRowsValue({"last 4+4 byte of page:",
            RowStr(gaia_apply::mach_read_from_4(page + page_size - 8),
                   gaia_apply::mach_read_from_4(page + page_size - 4))});
    table.Display();

    parse_page_0(page);

    if (_dump_page) {
        std::stringstream ss;
        if (!_cluster_id.empty()) {
            ss << _cluster_id << "_" << _segment_id.val << "_";
        }
        ss << "page_" << rsp_info.tablespaceid() << "_" << rsp_info.logicalpageno()
            << "_" << rsp_info.vlsn();
        std::string file_path_str(ss.str());
        base::FilePath file_path(file_path_str);
        // file already exists, double check
        if (base::PathExists(file_path) && !_force) {
            bool cf_ret = execute_confirm("file[%s] already exists, do you want to overwrite it?", file_path_str.c_str());
            if (!cf_ret) {
                printf("quit!\n");
                return 1;
            }
        }
        base::File file(file_path, base::File::FLAG_OPEN_ALWAYS | base::File::FLAG_WRITE);

        file.Write(0, rsp_info.pageframe().c_str(), rsp_info.pageframe().size());
        file.Close();

        printf("%s %s %s\n", "page_file:", file_path_str.c_str(), "(try to read use [hexdump])");
    }
    return 0;
}

}
}
