/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/store_cfg.hpp
* @author yukeyong@baidu.com
* @brief
*/

#include <filesystem>
#include <gaiadb/utils/configuration.h>
#include "psvr/log.h"
#include "psvr/store_cfg.h"

namespace psvr {

const char* kMetaFileName = "meta";
const char* kDataFileName = "data.ibd";
const char* kCompressFileName = "compress";

const std::string kTmpDirName = ".tmp";
const std::string kTrashSegmentPrefixName = "segment";
const std::string kPunchHoleFile = ".gaia_check_punch_hole.tmp";

const std::string kAppendFilePath = "append";
const std::string kAppendCheckPointName = "checkpoint";
const std::string kDblwrFilePath = "dblwr";

bool StoreCfg::Parse(const std::string& cfg, ParseFn& fn) {
    gaiadb::common::Config config;
    if (!config.Load(cfg)) {
        LOG(ERROR) << "load or parse store config file failed, file:[" << cfg << "]";
        return false;
    }

    int32_t count = config.GetInt("store", "count");
    if (count < 1) {
        LOG(ERROR) << "not found store count item in config file or count < 1";
        return false;
    }

    for (int32_t i = 0; i < count; ++i) {
        std::string section = base::string_printf("store%d", i);
        std::string path = config.GetString(section, "path");
        bool active = config.GetInt(section, "active") != 0;
        int64_t size = config.GetInt(section, "size", -1);
        int64_t capacity = config.GetInt(section, "capacity", -1);
        // call fn
        if (!fn (i, section, path, active, size, capacity)) {
            return false;
        }
    }

    return true;
}

bool StoreCfg::IteratorSegments(const std::string& path,
        IterSegFn& iter_seg_fn, IterClsFn& iter_cluster_fn) {
    bool rc = true;
    std::error_code ec;
    // Segment Path: /store_path/cluster_id/segment_id/
    for (auto& cluster_dir : std::filesystem::directory_iterator(path, ec)) {
        std::error_code cluster_dir_ec;
        if (!cluster_dir.is_directory()) {
            LOG(WARNING) << "found a not page server file:[" << cluster_dir.path()
                << "]";
            continue;
        }
        // ignore trash dir
        if (cluster_dir.path().filename() == kTmpDirName) {
            continue;
        }
        // list cluster path all segments
        uint32_t segment_count = 0;
        for (auto& segment_dir : std::filesystem::directory_iterator(cluster_dir.path(), cluster_dir_ec)) {
            ++segment_count;
            iter_seg_fn(segment_dir.path());
        }

        if (cluster_dir_ec) {
            LOG(ERROR) << "iterator path:[" << cluster_dir << "] failed, " << cluster_dir_ec.message();
            rc = false;
        } else {
            iter_cluster_fn(cluster_dir.path(), segment_count);
        }
    }

    if (ec) {
        rc = false;
        LOG(ERROR) << "iterator path:[" << path << "] failed, " << ec.message();
    }

    return rc;
}

}
