/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/psminfo.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <base/rand_util.h>

#include <gaiadb/common/types.h>
#include <gaiadb/utils/utils.h>

#include "psvr/common.h"
#include "psvr/namespace.h"
#include "psvr/utils.h"

namespace psvr {

class PsmInfo;
using PsmInfoPtr = std::shared_ptr<PsmInfo>;
using PsmInfoWeakPtr = std::weak_ptr<PsmInfo>;

class PsmInfo {
public:
    PsmInfo(const std::string& address, bool both = false)
        : _address(address), _hash_val(Get32bitHash(address)),
        _is_parsed(false), _both(both), _err_times(0), _heartheat_epoch(0) {
    }
    FUNC_MOCK ~PsmInfo() {}

    bool operator==(const PsmInfo& other) const {
        return _address == other._address;
    }

    const std::string& address() { return _address; }
    uint32_t hash_val() const { return _hash_val; }

    uint64_t heartheat_epoch() const { return _heartheat_epoch.get(); }
    void set_heartheat_epoch(uint64_t e) { return _heartheat_epoch.set(e, true); }

    bool AcquireRefreshLock() { return _lock.try_lock(); }
    void ReleaseRefreshLock() { return _lock.unlock(); }

    bool ParseAddress() {
        std::unique_lock lm(_shared_mutex);
        return ParseAddressNoLock();
    }

    void SetNodesFromHeartbeat(const base::EndPoint& leader,
            const ggpb::RepeatedPtrField<std::string>& peer_list);

    FUNC_MOCK bool RefreshNodes() {
        std::unique_lock lm(_shared_mutex);
        return RefreshNodesNoLock();
    }

    FUNC_MOCK bool GetOrRefreshNodes(std::vector<base::EndPoint>* nodes, bool sync = false);
    FUNC_MOCK bool GetOrRefreshBNSNodes(std::vector<base::EndPoint>* nodes);

    void SetFailed(uint32_t n = 1) {
        _err_times.fetch_add(n, std::memory_order_relaxed);
    }

    void MoveLeaderToFirst(uint32_t idx, const base::EndPoint& node);

    std::ostream& ToString(std::ostream& os) const;

private:

    bool GetOrRefreshNodesImpl(std::vector<base::EndPoint>* nodes,
            bool sync, bool include_heartbeat);
    bool ParseAddressNoLock();
    bool RefreshNodesNoLock();

private:
    const std::string _address;
    const uint32_t _hash_val;
    std::atomic<bool> _is_parsed;
    bool _both;
    std::atomic<uint32_t> _err_times;
    std::string _hostname;
    int32_t _port;
    gaiadb::common::AddressType _type;
    std::vector<base::EndPoint> _nodes;
    mutable rwlock_t _shared_mutex;
    AcquireLock _lock;
    /* bns is not always timely, so we get psm address also from heartbeat.
     * If failed after trying all _nodes, then try _nodes_from_heartbeat.
     */
    std::vector<base::EndPoint> _nodes_from_heartbeat;
    //
    Lsn _heartheat_epoch;
};

inline std::ostream& operator<<(std::ostream& os, PsmInfoPtr psm_info) {
    return psm_info ? psm_info->ToString(os) : os;
}

inline bool operator==(PsmInfoPtr lhs, PsmInfoPtr rhs) {
    return lhs && rhs && *lhs == *rhs;
}

}
