/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server_cluster_stauts.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ListPageServerClusterStatus : public Command {
public:
    ListPageServerClusterStatus() {
        SetName("list-ps-cluster-status");
        SetDesc("list page server cluster status in page server");
        SetDescCn("列出存储服务器上的集群状态");

        AddNodeOption();
        AddClusterOption(kGroup2Scope);
        AddRequiredArgOption("sort", &_long_opt_val, kOptMax + 1, "sort by type: segment|redo|rbio|write", kenum);

        AddExample("-a <ip> -p <port> --sort <type>");
        AddExample("--cluster-addr \"bns://xxx\" --sort <type>");
    }
    virtual ~ListPageServerClusterStatus() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'C':
            _cluster_addr = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _sort = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;
private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }
    int Format(const pspb::ListClusterStatusResponse& rsp);
private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_addr {};
    std::string _sort {};
};

}
}
