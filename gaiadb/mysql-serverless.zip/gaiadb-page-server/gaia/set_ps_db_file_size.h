/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_ps_db_file_size.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class SetPageServerDbFileSize : public Command {
public:

    constexpr static uint64_t k_default_db_file_size = 34359738368lu;

    SetPageServerDbFileSize() {
        SetName("set-ps-db-file-size");
        SetDesc("set segment db file size on page server");
        SetDescCn("设置存储服务器上分片数据文件大小");

        AddRequiredArgOption("store-cfg-file", &_long_opt_val, kOptMax + 1, "page server store config file", kstring);
        
        AddRequiredArgOption("size", &_long_opt_val, kOptMax + 2,
                "db file size to set, default 34359738368", kuint64_t);

        AddExample("--store-cfg-file conf/store.cfg --size 34359738368");
    }
    virtual ~SetPageServerDbFileSize() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _cfg_file = opt;
                break;
            case kOptMax + 2:
                _size = std::strtoull(opt, nullptr, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    std::string _cfg_file {};
    uint64_t _size {0};
};

}
}
