#include "gtest/gtest.h"
#include "psvr/encrypt_utils.h"

namespace psvr {
namespace test {

class BlockAccessCipherStreamTest : public ::testing::Test {
protected:
    void SetUp() override {
        test_data = "test_data_12345678901234567890";

        gaiapb::EncryptionInfo aes_encryption_info_pb;
        aes_encryption_info_pb.set_encryption_iv("iv_0123456789012");
        aes_encryption_info_pb.set_encryption_key("ase_key_12345678");
        aes_encryption_info_pb.set_encryption_alg(AES_ENCRYPTION);

        EncryptionInfo aes_encryption_info;
        EXPECT_TRUE(aes_encryption_info.Init(aes_encryption_info_pb));
        EXPECT_TRUE(aes_encryption_info.is_valid());
        _aes_stream.reset(new BlockAccessCipherStream(aes_encryption_info));

        gaiapb::EncryptionInfo sm4_encryption_info_pb;
        sm4_encryption_info_pb.set_encryption_iv("iv_0123456789012");
        sm4_encryption_info_pb.set_encryption_key("sm4_key_12345678");
        sm4_encryption_info_pb.set_encryption_alg(SM4_ENCRYPTION);

        EncryptionInfo sm4_encryption_info;
        EXPECT_TRUE(sm4_encryption_info.Init(sm4_encryption_info_pb));
        EXPECT_TRUE(sm4_encryption_info.is_valid());
        _sm4_stream.reset(new BlockAccessCipherStream(sm4_encryption_info));
    }

    std::unique_ptr<BlockAccessCipherStream> _aes_stream;
    std::unique_ptr<BlockAccessCipherStream> _sm4_stream;

    std::string test_data;
    gaia_apply::byte* generate_one_page();

private:
    void set_page_meta(gaia_apply::byte* page);
    void set_page_data(gaia_apply::byte* page);
    void set_page_type(gaia_apply::byte* page, gaia_apply::page_type_t type);
};

gaia_apply::byte* BlockAccessCipherStreamTest::generate_one_page() {
    gaia_apply::byte *page = (gaia_apply::byte *)malloc(gaia_apply::FLAGS_univ_page_size);
    if (page == nullptr) {
        return nullptr;
    }

    set_page_meta(page);
    set_page_data(page);

    return page;
}

void BlockAccessCipherStreamTest::set_page_meta(gaia_apply::byte* page) {
    INIT_APPLY_RAW_ARG(false);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_SPACE_OR_CHKSUM, 1);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_OFFSET, 2);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_PREV, 0);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_NEXT, 2);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_LSN, 100ul);
    gaia_apply::mach_write_to_2(page + gaia_apply::FIL_PAGE_TYPE, gaia_apply::FIL_PAGE_INODE APPLY_RAW_ARG_NAME_CC);
    gaia_apply::mach_write_to_8(page + gaia_apply::FIL_PAGE_FILE_FLUSH_LSN, 0);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_SPACE_ID, 2);
}

void BlockAccessCipherStreamTest::set_page_data(gaia_apply::byte *page) {
    uint32_t data_size = gaia_apply::FLAGS_univ_page_size - gaia_apply::FIL_PAGE_DATA;
    for (uint32_t i = 0; i < data_size; ++i) {
        page[gaia_apply::FIL_PAGE_DATA + i] = ((base::fast_rand() + i) % 26) + 'a';
    }
}

void BlockAccessCipherStreamTest::set_page_type(gaia_apply::byte* page, gaia_apply::page_type_t type) {
    INIT_APPLY_RAW_ARG(false);
    gaia_apply::mach_write_to_2(page + gaia_apply::FIL_PAGE_TYPE, type APPLY_RAW_ARG_NAME_CC);
}

// Test normal encrypt and decrypt page with ase
TEST_F(BlockAccessCipherStreamTest, EncrypDecryptPageWithAes) {
    gaia_apply::byte *original_page = generate_one_page();
    gaia_apply::byte *encrypted_page = (gaia_apply::byte *)malloc(gaia_apply::FLAGS_univ_page_size);
    EXPECT_TRUE(encrypted_page != nullptr);
    memcpy(static_cast<void *>(encrypted_page), static_cast<void *>(original_page),
           gaia_apply::FLAGS_univ_page_size);

    bool res = _aes_stream->encrypt_page(2, 2, encrypted_page);
    EXPECT_TRUE(res);
    int ret = memcmp(static_cast<void *>(original_page + gaia_apply::FIL_PAGE_DATA),
                     static_cast<void *>(encrypted_page + gaia_apply::FIL_PAGE_DATA),
                     gaia_apply::FLAGS_univ_page_size - gaia_apply::FIL_PAGE_DATA);
    EXPECT_NE(ret, 0);

    res = _aes_stream->decrypt_page(encrypted_page, gaia_apply::FLAGS_univ_page_size);
    EXPECT_TRUE(res);
    ret = memcmp(static_cast<void *>(original_page + gaia_apply::FIL_PAGE_DATA),
                 static_cast<void *>(encrypted_page + gaia_apply::FIL_PAGE_DATA),
                 gaia_apply::FLAGS_univ_page_size - gaia_apply::FIL_PAGE_DATA);
    EXPECT_EQ(ret, 0);

    free(static_cast<void *>(original_page));
    free(static_cast<void *>(encrypted_page));
}

// Test normal encrypt and decrypt page with sm4
TEST_F(BlockAccessCipherStreamTest, EncrypDecryptPageWithSm4) {
    gaia_apply::byte *original_page = generate_one_page();
    gaia_apply::byte *encrypted_page = (gaia_apply::byte *)malloc(gaia_apply::FLAGS_univ_page_size);
    EXPECT_TRUE(encrypted_page != nullptr);
    memcpy(static_cast<void *>(encrypted_page), static_cast<void *>(original_page),
           gaia_apply::FLAGS_univ_page_size);

    bool res = _sm4_stream->encrypt_page(2, 2, encrypted_page);
    EXPECT_TRUE(res);
    int ret = memcmp(static_cast<void *>(original_page + gaia_apply::FIL_PAGE_DATA),
                     static_cast<void *>(encrypted_page + gaia_apply::FIL_PAGE_DATA),
                     gaia_apply::FLAGS_univ_page_size - gaia_apply::FIL_PAGE_DATA);
    EXPECT_NE(ret, 0);

    res = _sm4_stream->decrypt_page(encrypted_page, gaia_apply::FLAGS_univ_page_size);
    EXPECT_TRUE(res);
    ret = memcmp(static_cast<void *>(original_page + gaia_apply::FIL_PAGE_DATA),
                 static_cast<void *>(encrypted_page + gaia_apply::FIL_PAGE_DATA),
                 gaia_apply::FLAGS_univ_page_size - gaia_apply::FIL_PAGE_DATA);
    EXPECT_EQ(ret, 0);

    free(static_cast<void *>(original_page));
    free(static_cast<void *>(encrypted_page));
}

// Test abnormal encrypt page with aes
TEST_F(BlockAccessCipherStreamTest, EncryptPageAbnormal) {
    gaia_apply::byte *original_page = generate_one_page();
    gaia_apply::byte *encrypted_page = (gaia_apply::byte *)malloc(gaia_apply::FLAGS_univ_page_size);
    EXPECT_TRUE(encrypted_page != nullptr);
    memcpy(static_cast<void *>(encrypted_page), static_cast<void *>(original_page),
           gaia_apply::FLAGS_univ_page_size);

    {
        // page type is FILE_PAGE_RTRREE, will return true, do not encrypt
        set_page_type(encrypted_page, gaia_apply::FIL_PAGE_RTREE);
        bool res = _aes_stream->encrypt_page(2, 2, encrypted_page);
        EXPECT_TRUE(res);
        int ret = memcmp(static_cast<void *>(original_page + gaia_apply::FIL_PAGE_DATA),
                         static_cast<void *>(encrypted_page + gaia_apply::FIL_PAGE_DATA),
                         gaia_apply::FLAGS_univ_page_size - gaia_apply::FIL_PAGE_DATA);
        EXPECT_EQ(ret, 0);
    }

    {
        // page type is FIL_PAGE_COMPRESSED, data is commpressed by mysql or pageserver, do not
        // encrypt
        set_page_type(encrypted_page, gaia_apply::FIL_PAGE_COMPRESSED);
        bool res = _aes_stream->encrypt_page(2, 2, encrypted_page);
        EXPECT_TRUE(res);
        int ret = memcmp(static_cast<void *>(original_page + gaia_apply::FIL_PAGE_DATA),
                         static_cast<void *>(encrypted_page + gaia_apply::FIL_PAGE_DATA),
                         gaia_apply::FLAGS_univ_page_size - gaia_apply::FIL_PAGE_DATA);
        EXPECT_EQ(ret, 0);
    }

    set_page_type(encrypted_page, gaia_apply::FIL_PAGE_INODE);

    {
        // space id is not match, do not encrypt and return true
        bool res = _aes_stream->encrypt_page(3, 2, encrypted_page);
        EXPECT_TRUE(res);
        int ret = memcmp(static_cast<void *>(original_page + gaia_apply::FIL_PAGE_DATA),
                         static_cast<void *>(encrypted_page + gaia_apply::FIL_PAGE_DATA),
                         gaia_apply::FLAGS_univ_page_size - gaia_apply::FIL_PAGE_DATA);
        EXPECT_EQ(ret, 0);
    }

    {
        // pageno is not match, do not encrypt and return true
        bool res = _aes_stream->encrypt_page(2, 3, encrypted_page);
        EXPECT_TRUE(res);
        int ret = memcmp(static_cast<void *>(original_page + gaia_apply::FIL_PAGE_DATA),
                         static_cast<void *>(encrypted_page + gaia_apply::FIL_PAGE_DATA),
                         gaia_apply::FLAGS_univ_page_size - gaia_apply::FIL_PAGE_DATA);
        EXPECT_EQ(ret, 0);
    }
}

}  // namespace test
}  // namespace psvr
