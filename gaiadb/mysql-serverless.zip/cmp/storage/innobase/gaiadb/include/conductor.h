#pragma once

#include <shared_mutex>

#include "buf0buf.h"

#include "gflags/gflags.h"

DECLARE_uint64(rpl_parse_batch_interval_threshold);
class Conductor {
  
public:
  Conductor() {}
  bool init();
  bool init(const size_t buf_size);
  bool reinit();
  inline bool is_init() {
    return init_;
  }

  byte *log_buf();
  ut::aligned_array_pointer<byte, OS_FILE_LOG_BLOCK_SIZE>& get_log_buf();
  std::mutex& log_buf_mutex();
  size_t& log_buf_size();

  ib_mutex_t *binlog_mutex();
  BinlogRecover *binlog_recover();
  bool cleanup();
  virtual lsn_t fetch_lsn() const = 0;
  virtual lsn_t copy_lsn() const = 0;

  void resize_buf_if(const bool set_stat_rpl_bvar);
private:
  ut::aligned_array_pointer<byte, OS_FILE_LOG_BLOCK_SIZE> log_buf_;
  size_t log_buf_size_ = 0;
  // update of state.fetch_lsn and state.parse_lsn
  // should be protected by log_buf_mutex_ because
  // they all related to log_buf_
  std::mutex log_buf_mutex_;

  // for binlog
  mutable ib_mutex_t binlog_mutex_;
  BinlogRecover *binlog_recover_;
  bool init_ = false;
};
