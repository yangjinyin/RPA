/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/drop_page_server_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class DropPageServerSegment : public Command {
public:
    DropPageServerSegment() {
        SetName("drop-ps-segment");
        SetDesc("drop a segment replica on page server");
        SetDescCn("删除存储服务器上的分片副本");

        AddRequiredArgOption("cluster-id", NULL, 'c', "target cluster ID", kstring);
        AddRequiredArgOption("segment-id", NULL, 's', "segment ID to drop, omit to drop all", kuint32_t);

        AddNodeOption(kGroup2Scope);
        AddClusterOption(kGroup3Scope);

        AddExample("-a <ip> -p <port> -c gaia-test-perf");
        AddExample("-a <ip> -p <port> -c gaia-test-perf -s 1");
        AddExample("--cluster-addr bns://xx -c gaia-test-perf");
        AddExample("--cluster-addr bns://xx -c gaia-test-perf -s 1");
    }
    virtual ~DropPageServerSegment() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtoul(opt, NULL, 10));
            break;
        case 'C':
            _cluster_addr = opt;
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::DropSegmentResponse& rsp);
    int Format(const pspb::BatchDropSegmentResponse& rsp);
private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_addr {};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
};

}
}
