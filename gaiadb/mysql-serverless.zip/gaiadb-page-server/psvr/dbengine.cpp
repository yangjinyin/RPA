/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file /data/yukeyong/baidu/dba/gaiadb-page-server/psvr/dbengine.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/config.h"
#include "psvr/compress_utils.h"
#include "psvr/dbengine.h"
#include "psvr/utils.h"

namespace psvr {
namespace db {

static const int32_t kFlagsPunchHoleMode = FALLOC_FL_PUNCH_HOLE | FALLOC_FL_KEEP_SIZE;
static const int32_t kFlagsAllocMode = 0;

static bvar::Vector<uint64_t, 2> get_compress_size_info(void* arg) {
    db::DBEngineStatistic* db_engine_stat = static_cast<db::DBEngineStatistic*>(arg);
    bvar::Vector<uint64_t, 2> result;
    result[0] = db_engine_stat->stat_avg_write_size.get_value().get_average_int();       // origin size
    result[1] = db_engine_stat->stat_avg_write_real_size.get_value().get_average_int();  // compress size
    return result;
}

void check_punch_hole_feature(const std::string& file_name, bool* enable) {
    *enable = false;
    // create file and fallocate size and puch hole file
    int flags = O_RDWR | O_CREAT;
    int fd = open(file_name.c_str(), flags, S_IRUSR | S_IWUSR);
    if (fd < 0) {
        LOG(WARNING) << "open file failed,"
            << " file_name:[" << file_name
            << "] err:[" << strerror(errno)
            << "]";
        return;
    }

    std::shared_ptr<nullptr_t> guard_fd(nullptr,
            [&fd](nullptr_t) {
                close(fd);
        });

    const off_t size = 4096;
    if (std::filesystem::file_size(file_name) < size) {
        if (db::fallocate(fd, 0, 0/*offset*/, size) != 0) {
            LOG(WARNING) << "fallocate file size failed,"
                << " file_name:[" << file_name
                << "] err:[" << strerror(errno)
                << "]";
            return;
        }
    }

    int mode = db::kFlagsPunchHoleMode;
    if (db::fallocate(fd, mode, 0/*offset*/, size) != 0) {
        LOG(WARNING) << "fallocate punch hole file size failed,"
            << " file_name:[" << file_name
            << "] err:[" << strerror(errno)
            << "]";
        return;
    }

    *enable = true;
    LOG(NOTICE) << "enable punch hole, file:[" << file_name << "]";
}

DBEngineStatistic::DBEngineStatistic()
    : stat_db_compress_size("psvr", "db_compress_size", &get_compress_size_info, this),
    stat_db_read_lat("psvr", "db_read", kSlaWindowSize),
    stat_db_write_lat("psvr", "db_write", kSlaWindowSize),
    stat_page_compress_lat("psvr", "page_compress", kSlaWindowSize),
    stat_page_compress_fail_count("psvr", "page_compress_fail_count", kSlaWindowSize),
    stat_page_decompress_lat("psvr", "page_decompress", kSlaWindowSize),
    stat_db_read_bw("psvr_db_read_bw", kSlaWindowSize),
    stat_db_write_bw("psvr_db_write_bw", kSlaWindowSize),
    stat_db_read_io_err_count("psvr_db_read_io_err_count", kSlaWindowSize),
    stat_db_write_io_err_count("psvr_db_write_io_err_count", kSlaWindowSize) {
    stat_db_compress_size.set_vector_names("origin,compress");
}

} // end of ns db

static std::unique_ptr<db::DBEngineStatistic> l_dbengine_stat {nullptr};

static void PSVR_FUNC_CTOR init_dbengine_statistic() {
    l_dbengine_stat.reset(new db::DBEngineStatistic);
}

static db::Status open_or_create_file(int64_t log_id, const std::string& file_name, uint64_t file_size,
        int flags, bool enable_punch_hole, int* fd = nullptr, uint64_t* file_real_size = nullptr) {
    db::Status s;
    int fd_ = open(file_name.c_str(), flags, S_IRUSR | S_IWUSR);
    if (fd_ < 0) {
        PSVR_LOG(WARNING, log_id) << "open failed,"
            << " file_name:[" << file_name
            << "] err:[" << strerror(errno)
            << "]";
        s = db::GetErrStatus();
        return s;
    }
    PSVR_LOG(TRACE, log_id) << "open or create file,"
        << " file_name:[" << file_name
        << "] flags:[" << flags
        << "] file_size:[" << file_size
        << "] size:[" << std::filesystem::file_size(file_name)
        << "]";
    ssize_t cur_file_size = 0;
    if (!db::get_file_size(fd_, &cur_file_size)) {
        s = db::GetErrStatus();
        close(fd_);
        return s;
    }

    if (cur_file_size == 0 && file_size > 0) {
        // reset file size, holding file system physical size
        if (db::fallocate(fd_, 0, 0/*offset*/, file_size) != 0) {
            LOG(TRACE) << "fallocate fail, retrytry ftruncate";
            if (db::ftruncate(fd_, file_size) != 0) {
                s = db::GetErrStatus();
                PSVR_LOG(WARNING, log_id) << "holding physical file failed,"
                    << " file_name:[" << file_name
                    << "] file_size:[" << file_size
                    << "] err:[" << strerror(errno)
                    << "]";
            }
        }

        // free physical size
        if (s.IsOk() && enable_punch_hole) {
            int mode = db::kFlagsPunchHoleMode;
            if (db::fallocate(fd_, mode, 0/*offset*/, file_size) != 0) {
                PSVR_LOG(WARNING, log_id) << "fallocate failed,"
                    << " file_name:[" << file_name
                    << "] file_size:[" << file_size
                    << "] mode:[" << mode
                    << "] err:[" << strerror(errno)
                    << "]";
            }
        }

        // get file size again
        if (s.IsOk() && !db::get_file_size(fd_, &cur_file_size)) {
            s = db::GetErrStatus();
            close(fd_);
            return s;
        }
    }

    if (s.IsOk() && file_size > 0 && static_cast<uint64_t>(cur_file_size) > file_size) {
        s.Reset(db::Code::kMisMacth, std::string("file size over, ") + file_name);
    }

    if (!s.IsOk()) {
        close(fd_);
        return s;
    } else {
        if (file_real_size) {
            *file_real_size = static_cast<uint64_t>(cur_file_size);
        }

        if (fd) {
            *fd = fd_;
        } else {
            close(fd_);
        }
        return s;
    }
}

static bvar::Adder<int64_t> stat_page_lock_used_count("psvr_db_page_lock_used_count");

DBEngine::DBEngine() : _engine_type(db::EngineType::kUnknown),
        _page_size(gaia_apply::FLAGS_univ_page_size),
        _fd(-1), _file_name(), _file_open_size(0), _file_max_size(0),
        _ckp_file_name(),
        _file_block_size(gaia_apply::ULINT_UNDEFINED) {
    for (int32_t i = 0; i < FLAGS_psvr_segment_page_lock_slice_count; ++i) {
        _page_lock_manager.emplace_back(std::make_shared<db::PageLockManager>(stat_page_lock_used_count));
    }
}

DBEngine::~DBEngine() {
    Close();
}

db::Status DBEngine::Open(const db::OpenOptions& options) {
    _engine_type = options.engine_type;
    _page_size = options.page_size;
    if (_engine_type == db::EngineType::kFile) {
        return OpenFile(options);
    } else {
        // TODO:
        return db::Status(db::Code::kInvalid, "unknown db type");
    }
}

db::Status DBEngine::OpenFile(const db::OpenOptions& options) {
    std::unique_lock lk(_shared_mutex);
    const auto& file_options = options.file;
    db::Status s;

    if (_fd > -1) {
        return db::Status(db::Code::kStatusError, "db alreay open");
    }

    int flags = O_RDWR;
    if (options.create_if_missing) {
        flags |= O_CREAT;
    }

    bool enable_punch_hole = file_options.enable_punch_hole;
    LOG(TRACE) << "open file,"
        << " flags:[" << flags
        << "] enable_punch_hole:[" << enable_punch_hole
        << "] create_ckp:[" << file_options.create_ckp
        << "]";
    if (file_options.create_ckp) {
        s = open_or_create_file(options.log_id, file_options.ckp_name,
                file_options.ckp_size, flags, enable_punch_hole);
        if (!s.IsOk()) {
            return s;
        }
        _ckp_file_name = file_options.ckp_name;
    }
    s = open_or_create_file(options.log_id, file_options.name,
            file_options.size, flags, enable_punch_hole, &_fd, &_file_open_size);
    if (!s.IsOk()) {
        return s;
    }

    if (_file_open_size > file_options.max_size) {
        s.Reset(db::Code::kMisMacth, std::string("file size over max size, ") + file_options.name);
        return s;
    }

    if (_file_open_size > 0 && (_file_open_size % gaia_apply::FLAGS_univ_page_size) > 0) {
        PSVR_LOG(WARNING, options.log_id) << "last file maybe close interrupt or gc with compress,"
            << " file:[" << options.file.name
            << "] file_size:[" << _file_open_size
            << "]";
        /** gc with compression action:
         * 1) db file append a page in gc, page size is 16kb, compressed with 12kb, so db file size increases by 4kb.
         * 2) read db file newly appended data of 16kb, it returns only 4kb.
         * 3) read API need to check it, and expand size to 16kb. see ReadFile method.
         */
        _file_open_size -= (_file_open_size % gaia_apply::FLAGS_univ_page_size);
    }

    gaia_apply::ulint block_size = file_options.block_size;
    if (enable_punch_hole
            && block_size == gaia_apply::ULINT_UNDEFINED) {
        struct ::stat st;
        if (0 == db::stat(options.file.name.c_str(), &st)
                && st.st_blksize > 0 && static_cast<uint64_t>(st.st_blksize) <= _page_size) {
            block_size = st.st_blksize;
        } else {
            PSVR_LOG(WARNING, options.log_id) << "stat file failed, close enable_punch_hole!!"
                << " file:[" << options.file.name << "]";
            enable_punch_hole = false;
        }
    }

    _file_name = file_options.name;
    _file_max_size = file_options.max_size;
    _file_block_size = block_size;
    if (!enable_punch_hole) {
        PSVR_LOG(ERROR, options.log_id) << "disalbe fallocate command, close compress page!"
            << " file:[" << options.file.name << "]";
        _file_block_size = gaia_apply::ULINT_UNDEFINED;
    }
    PSVR_LOG(NOTICE, options.log_id) << "open file engine succ,"
        << " file_name:[" << _file_name
        << "] file_open_size:[" << _file_open_size
        << "] file_max_size:[" << _file_max_size
        << "] file_block_size:[" << _file_block_size
        << "] " << s;
    return s;
}

db::Status DBEngine::Close() {
    std::unique_lock lk(_shared_mutex);
    db::Status s;
    if (_engine_type == db::EngineType::kFile) {
        if (_fd >= 0) {
            close(_fd);
            _fd = -1;
        }
    }
    return s;
}

int64_t DBEngine::GetSize(bool physical) {
    if (_engine_type == db::EngineType::kFile) {
        return GetFileSize(physical);
    } else {
        return -1L;
    }
}

int64_t DBEngine::GetFileSize(bool physical) {
    struct ::stat sbuf;
    if (_fd >= 0) {
        if (db::fstat(_fd, &sbuf) == 0) {
            return physical ? (sbuf.st_blocks * FLAGS_psvr_db_file_block_size) : sbuf.st_size;
        }
    }
    if (db::stat(_file_name.c_str(), &sbuf) == 0) {
        return physical ? (sbuf.st_blocks * FLAGS_psvr_db_file_block_size) : sbuf.st_size;
    }
    return -1L;
}

db::Status DBEngine::Read(const db::ReadOptions& options,
        uint64_t offset, uint64_t size, void* buf, db::ReadOutputs* outputs) {
    db::Status s;
    Timer stat_timer(base::Timer::STARTED);
    if (outputs) {
        outputs->first_is_compressed = false;
        outputs->real_write_size = size;
    }
    if (_engine_type == db::EngineType::kFile) {
        s = ReadFile(options, offset, size, buf, outputs);
    } else {
        s.Reset(db::Code::kStatusError, "unknown engine type");
    }
    l_dbengine_stat->stat_db_read_lat << stat_timer.u_elapsed();
    l_dbengine_stat->stat_db_read_bw << size;
    if (!s.IsOk()) {
        l_dbengine_stat->stat_db_read_io_err_count << 1;
    }
    return s;
}

db::Status DBEngine::ReadFile(const db::ReadOptions& options,
        uint64_t offset, uint64_t size, void* buf, db::ReadOutputs* outputs) {
    db::Status s;
    if (_fd < 0) {
        s.Reset(db::Code::kStatusError, "engine not open!");
    }
    if (s.IsOk()
            && (offset >= _file_max_size || offset + size > _file_max_size)) {
        s.Reset(db::Code::kInvalid, "offset or size invalid");
    }
    if (s.IsOk()) {
        const ssize_t read_size = db::pread(_fd, buf, size, offset);
        if (static_cast<ssize_t>(size) != read_size) {
            // expand data size to reader, constraints:
            // 1) read range < open file size
            // 2) read offset and read size are aligned 16kb
            // 3) expand size alianged 4kb
            if (offset + size > _file_open_size && read_size >= 0
                    && offset % _page_size == 0
                    && size % _page_size == 0
                    && _file_block_size != gaia_apply::ULINT_UNDEFINED
                    && (size - read_size) % _file_block_size == 0) {
                const uint64_t non_write_size = size - read_size;
                memset(static_cast<char*>(buf) + read_size, 0x0, non_write_size);
                if (outputs) {
                    outputs->real_write_size = read_size;
                }
            } else {
                PSVR_LOG(FATAL, options.log_id) << "fail to pread,"
                    << " file:[" << _file_name
                    << "] size:[" << size
                    << "] offset:[" << offset
                    << "] read_size:[" << read_size
                    << "] msg:[" << strerror(errno)
                    << "]";
                s = db::GetErrStatus();
            }
        }
        if (options.read_raw) {
            return s;
        }
    }
    if (s.IsOk()) {
        if (_page_size && offset % _page_size == 0
                && size % _page_size == 0) {
            thread_local void* decompressed_buf = nullptr;
            thread_local ThreadLocalGuard decompressed_buf_guard(&decompressed_buf, std::free);
            if (!decompressed_buf) {
                decompressed_buf = std::aligned_alloc(_page_size, _page_size);
                if (!decompressed_buf) {
                    s.Reset(db::Code::kSysError, "alloc memory failed");
                    return s;
                }
            }
            for (uint64_t pos = 0; pos < size; pos += _page_size) {
                auto* page_frame = static_cast<gaia_apply::byte*>(buf) + pos;
                if (!page_is_compressed(page_frame)) {
                    continue;
                }
                if (pos == 0 && outputs) {
                    outputs->first_is_compressed = true;
                }
                Timer decompress_timer(base::Timer::STARTED);
                bool ret = decompress_page(page_frame, static_cast<gaia_apply::byte*>(decompressed_buf), _page_size);
                if (!ret) {
                    PSVR_LOG(FATAL, options.log_id) << "fail to decompress page,"
                        << " file:[" << _file_name
                        << "] page_size:[" << _page_size
                        << "] page_offset:[" << offset + pos
                        << "]";
                    s.Reset(db::Code::kCorrupted, "page decompress failed");
                    return s;
                }
                l_dbengine_stat->stat_page_decompress_lat << decompress_timer.u_elapsed();
            }
        } // else: read unalign page, decompress by caller
    }
    return s;
}

db::Status DBEngine::Write(const db::WriteOptions& options,
        uint64_t offset, uint64_t size, void* buf, db::WriteOutputs* outputs) {
    db::Status s;
    Timer stat_timer(base::Timer::STARTED);
    if (outputs) {
        outputs->real_write_size = size;
    }
    if (_engine_type == db::EngineType::kFile) {
        s = WriteFile(options, offset, size, buf, outputs);
    } else {
        s.Reset(db::Code::kStatusError, "unknown engine type");
    }
    l_dbengine_stat->stat_db_write_lat << stat_timer.u_elapsed();
    l_dbengine_stat->stat_db_write_bw << size;
    if (!s.IsOk()) {
        l_dbengine_stat->stat_db_write_io_err_count << 1;
    }
    return s;
}

db::Status DBEngine::WriteFile(const db::WriteOptions& options,
        uint64_t offset, uint64_t size, void* buf, db::WriteOutputs* outputs) {
    db::Status s;
    if (_fd < 0) {
        s.Reset(db::Code::kStatusError, "engine not open!");
        return s;
    }
    if (s.IsOk()
            && (offset >= _file_max_size || offset + size > _file_max_size)) {
        s.Reset(db::Code::kInvalid, "offset or size invalid");
        return s;
    }
    if (options.alloc_extent_size && (offset % GAIADB_EXTENT_SIZE) == 0) {
        // best-effort preallocate the whole extent when writing its first page,
        // do not care about the result, following pwrite decides success or failure.
        db::fallocate(_fd, db::kFlagsAllocMode, offset, GAIADB_EXTENT_SIZE);
    }
    if (options.enable_compress
            && _page_size && (offset % _page_size == 0) && (size % _page_size == 0)
            && _file_block_size != gaia_apply::ULINT_UNDEFINED) {
        thread_local void* compressed_buf = nullptr;
        thread_local ThreadLocalGuard compressed_buf_guard(&compressed_buf, std::free);
        const gaia_apply::ulint compressed_buf_size = _page_size * 2;
        if (!compressed_buf) {
            compressed_buf = std::aligned_alloc(_page_size, compressed_buf_size);
            if (!compressed_buf) {
                PSVR_LOG(WARNING, options.log_id) << "alloc buf failed, size:[" << compressed_buf_size << "]";
            }
        }
        if (compressed_buf) {
            int32_t compress_type = options.compress_type;
            int32_t compress_level = options.compress_level;
            if (outputs) {
                outputs->real_write_size = 0;
            }
            for (uint64_t pos = 0; pos < size; pos += _page_size) {
                gaia_apply::byte* page_frame = static_cast<gaia_apply::byte*>(buf) + pos;
                gaia_apply::ulint compressed_size = 0;

                Timer compress_timer(base::Timer::STARTED);
                if (compress_page(options.logical_space_id, options.logical_page_no,
                            _file_block_size, compress_type, compress_level,
                            page_frame, _page_size,
                            reinterpret_cast<gaia_apply::byte*>(compressed_buf), compressed_buf_size,
                            &compressed_size)
                        && compressed_size < _page_size) {

                    l_dbengine_stat->stat_avg_write_size << _page_size;
                    l_dbengine_stat->stat_avg_write_real_size << compressed_size;
                    l_dbengine_stat->stat_page_compress_lat << compress_timer.u_elapsed();

                    ssize_t write_size = db::pwrite(_fd, compressed_buf, compressed_size, offset + pos);
                    if (write_size == static_cast<ssize_t>(compressed_size)) {
                        uint64_t punch_hole_size = _page_size - compressed_size;
                        PSVR_ASSERT((punch_hole_size % _file_block_size) == 0);
                        if (db::fallocate(_fd, db::kFlagsPunchHoleMode, offset + pos + compressed_size, punch_hole_size) == 0) {
                            if (outputs) {
                                outputs->real_write_size += write_size;
                            }
                            continue;
                        }
                    }
                }

                l_dbengine_stat->stat_page_compress_fail_count << 1;
                // write origin data
                ssize_t write_size = db::pwrite(_fd, page_frame, _page_size, offset + pos);
                if (write_size == static_cast<ssize_t>(_page_size)) {
                    if (outputs) {
                        outputs->real_write_size += write_size;
                    }
                    continue;
                }

                PSVR_LOG(WARNING, options.log_id) << "write page data failed,"
                    << " file:[" << _file_name
                    << "] page_size:[" << _page_size
                    << "] page_offset:[" << offset + pos
                    << "] write_size:[" << write_size
                    << "] msg:[" << strerror(errno)
                    << "]";
                s = db::GetErrStatus();
                break;
            }
            // write ok or fail
            return s;
        }
    }

    ssize_t write_size = db::pwrite(_fd, buf, size, offset);
    if (static_cast<ssize_t>(size) != write_size) {
        PSVR_LOG(FATAL, options.log_id) << "fail to pwrite"
            << " fd:[" << _fd
            << "] size:[" << size
            << "] offset:[" << offset
            << "] write_size:[" << write_size
            << "] msg:[" << strerror(errno)
            << "]";
        s = db::GetErrStatus();
    } else if (outputs) {
        outputs->real_write_size = write_size;
    }

    return s;
}

db::Status DBEngine::Trim(const db::TrimOptions& options, uint64_t offset, uint64_t size) {
    db::Status s;
    if (_engine_type == db::EngineType::kFile) {
        s = TrimFile(options, offset, size);
    } else {
        s.Reset(db::Code::kStatusError, "unknown engine type");
    }
    return s;
}

db::Status DBEngine::TrimFile(const db::TrimOptions& options, uint64_t offset, uint64_t size) {
    db::Status s;
    if (_fd < 0) {
        s.Reset(db::Code::kStatusError, "engine not open!");
        return s;
    }
    if (_page_size && (offset % _page_size == 0) && (size % _page_size == 0)) {
        if (_file_block_size != gaia_apply::ULINT_UNDEFINED) {
            if (db::fallocate(_fd, db::kFlagsPunchHoleMode, offset, size) != 0) {
                s.Reset(db::Code::kSysError, "fallocate file failed");
            }
        } else if (options.write_zero_if_disable) {
            static void* zero_buf = std::calloc(1, gaia_apply::FLAGS_univ_page_size);
            void* buf = zero_buf;
            bool free_buf = false;
            if (!zero_buf || gaia_apply::FLAGS_univ_page_size < size) {
                buf = std::calloc(1, size);
                free_buf = true;
                LOG_EVERY_N(WARNING, 99) << "trim alloc normal size buf,"
                    << " size:[" << size << "]";
            }
            if (!buf) {
                s.Reset(db::Code::kBusy, "alloc buf failed");
            } else {
                ssize_t write_size = db::pwrite(_fd, buf, size, offset);
                if (static_cast<ssize_t>(size) != write_size) {
                    PSVR_LOG(FATAL, options.log_id) << "fail to trim pwrite"
                        << " fd:[" << _fd
                        << "] size:[" << size
                        << "] offset:[" << offset
                        << "] write_size:[" << write_size
                        << "] msg:[" << strerror(errno)
                        << "]";
                    s = db::GetErrStatus();
                }
                if (free_buf) {
                    std::free(buf);
                }
            }
        } // else is ok
    } else {
        s.Reset(db::Code::kInvalid, "invalid offset or size");
    }
    return s;
}

db::Status DBEngine::Sync(bool data) {
    if (_engine_type == db::EngineType::kFile) {
        return SyncFile(data);
    } else {
        db::Status s(db::Code::kStatusError, "unkown engine type");
        return s;
    }
}

db::Status DBEngine::SyncFile(bool data) {
    db::Status s;
    if (_fd < 0) {
        s.Reset(db::Code::kStatusError, "engine not open!");
    }
    if (s.IsOk() && (0 != data ? db::fdatasync(_fd) : db::fsync(_fd))) {
        LOG(FATAL) << "fail to fsync/fdatasync,"
            << " file:[" << _file_name
            << "] msg:[" << strerror(errno)
            << "]";
        s = db::GetErrStatus();
    }
    return s;
}

db::PageLockPtr DBEngine::GetPageLock(uint64_t physical_page_no) {
    return _page_lock_manager[physical_page_no % FLAGS_psvr_segment_page_lock_slice_count]
        ->GetOrCreate(physical_page_no, physical_page_no, _page_size);
}

}
