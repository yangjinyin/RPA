/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file include/rpl0conductor.h
 Gaiadb redo log replication

 Created 10/12/2021 Hongyu Qiao
 *******************************************************/

#pragma once
#include <shared_mutex>
#include "buf0buf.h"
#include "rpl0assemble.h"
#include "conductor.h"

namespace rpl {

class RplConductor;
extern RplConductor *g_rpl_conductor;

// core state of rpl system
struct RplState {
  void init(lsn_t start_lsn);

  atomic_lsn_t ls_dispatch_lsn{0};
  atomic_lsn_t fetch_lsn{0};
  atomic_lsn_t parse_lsn{0};
  atomic_lsn_t copy_lsn{0};
  atomic_lsn_t apply_lsn{0};
  atomic_lsn_t flush_lsn{0};
  atomic_lsn_t master_vdl{0};
  atomic_lsn_t read_lsn{0};
  std::atomic<trx_id_t> max_trx_no{0};
};

inline bvar::Vector<int64_t, 2> get_rpl_lsn_fetch_parse(void* arg) {
  auto state = static_cast<RplState*>(arg);
  bvar::Vector<int64_t, 2> result;
  result[0] = state->master_vdl - state->fetch_lsn;
  result[1] = state->fetch_lsn - state->parse_lsn;
  return result;
}

void sleep_buf_not_enough(uint32_t wait_count);
DECLARE_int64(rpl_max_sleep_us_redo_not_enough);
DECLARE_int64(rpl_interval_sleep_us_redo_not_enough);

class RplAssemblyBus {
 public:
  RplAssemblyBus();
  ~RplAssemblyBus();

  bool init();
  bool cleanup();

  // operator or checker with lock protection
  bool can_advance_parse();

  uint64_t parse_index() const { return parse_index_.load(std::memory_order_relaxed); }
  uint64_t apply_index() const { return apply_index_.load(std::memory_order_relaxed); }
  uint64_t gc_index() const { return gc_index_.load(std::memory_order_relaxed); }

  RplAssembly *pick_to_parse_assembly();
  RplAssembly *pick_to_apply_assembly();

  void advance_parse();
  void advance_apply();

  bool recycle_assembly(RplAssembly *assembly);
  void recycle_before_lsn(lsn_t lsn);

  uint32_t rbio_apply_register(lsn_t &vlsn, uint64_t *refed_index, lsn_t *lowest_lsn);
  int32_t rbio_further_apply(uint32_t refed_type, uint64_t refed_index,
                          buf_block_t *block, lsn_t start_lsn, lsn_t end_lsn);
  void rbio_finish_apply(uint32_t refed_type, uint64_t refed_index);

  void bp_get_further_apply(buf_block_t *block);

private:
  void release_asmb_rbio_refer(uint64_t refed_index, bool locked);

 private:
  RplAssembly *asmb_vec_;
  std::atomic<uint64_t> parse_index_{0};
  std::atomic<uint64_t> apply_index_{0};
  std::atomic<uint64_t> gc_index_{0};
};

class RplConductor : public Conductor {
  RplConductor()
    : stat_rpl_lsn_("rpl_lsn_fetch_parse", get_rpl_lsn_fetch_parse, &rpl_state_) {}

 public:
  bool init(lsn_t start_lsn);

  bool cleanup();

  static RplConductor &get_instance();

  void update_ls_dispatch_lsn(lsn_t ls_dispatch_lsn);
  lsn_t ls_dispatch_lsn();

  void update_fetch_lsn(lsn_t fetch_lsn);
  lsn_t fetch_lsn() const override;

  void update_parse_lsn(lsn_t parse_lsn);
  lsn_t parse_lsn();

  void update_copy_lsn(lsn_t copy_lsn);
  lsn_t copy_lsn() const override;

  void update_apply_lsn(lsn_t apply_lsn);
  lsn_t apply_lsn();

  void update_flush_lsn(lsn_t flush_lsn);
  lsn_t flush_lsn();

  void update_master_vdl(lsn_t master_vdl);
  lsn_t master_vdl();

  void update_read_lsn(lsn_t read_lsn);
  lsn_t read_lsn();

  void set_max_trx_no(trx_id_t trx_no);
  trx_id_t max_trx_no();

  void set_trx_sys_max_id_inited();
  bool trx_sys_max_id_inited();

  void apply_rpl_msg(uint8_t type, uint8_t flags, const byte *payload,
                     uint64_t payload_len);
  void rpl_reload_outline(bool retain_counters);

  bool log_buf_has_space_for_lsn(lsn_t fetch_lsn, lsn_t& copy_lsn);
  bool log_buf_reach_lsn(lsn_t lsn);

  bool can_advance_parse() { return assembly_bus_.can_advance_parse(); }

  void advance_parse() { assembly_bus_.advance_parse(); }
  void advance_apply() { assembly_bus_.advance_apply(); }

  uint64_t parse_index() const { return assembly_bus_.parse_index(); }
  uint64_t apply_index() const { return assembly_bus_.apply_index(); }
  uint64_t gc_index() const { return assembly_bus_.gc_index(); }

  RplAssembly *parse_next() { return assembly_bus_.pick_to_parse_assembly(); }
  RplAssembly *apply_next() { return assembly_bus_.pick_to_apply_assembly(); }

  void recycle_assembly(RplAssembly *assembly);
  void recycle_assembly_before_lsn(lsn_t lsn);

  uint32_t rbio_apply_register(lsn_t &vlsn, uint64_t *refed_index, lsn_t *lowest_lsn) {
    return assembly_bus_.rbio_apply_register(vlsn, refed_index, lowest_lsn);
  }

  int32_t rbio_further_apply(uint32_t refed_type, uint64_t refed_index,
                          buf_block_t *block, lsn_t start_lsn, lsn_t end_lsn) {
    return assembly_bus_.rbio_further_apply(refed_type, refed_index,
                                            block, start_lsn, end_lsn);
  }

  void rbio_finish_apply(uint32_t refed_type, uint64_t refed_index) {
    assembly_bus_.rbio_finish_apply(refed_type, refed_index);
  }

  void bp_get_further_apply(buf_block_t *block) {
    assembly_bus_.bp_get_further_apply(block);
  }


 private:
  RplState rpl_state_;
  bvar::PassiveStatus<bvar::Vector<int64_t, 2>> stat_rpl_lsn_;

  RplAssemblyBus assembly_bus_;


  std::atomic_bool trx_sys_max_id_inited_{false};
};

}  // namespace rpl
