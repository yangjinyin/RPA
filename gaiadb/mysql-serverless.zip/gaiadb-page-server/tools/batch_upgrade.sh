#!/bin/bash

# to find gaia command
source /etc/bashrc

set -e

# ============================================================
# BNS configuration (uncomment the target environment)
# ============================================================
#BNS="sandbox-multips00.gaia.bjdd:6000"
#BNS="sandbox-multips00.gaia.gzns:6000"
#BNS="multips00.gaia.njxg:6000"

if [ -f ./bin/gaia ]; then
    export PATH=`pwd`/bin:$PATH
elif [ -f ./output/bin/gaia ]; then
    export PATH=`pwd`/output/bin:$PATH
fi

# Remote page_server deployment directory
REMOTE_DIR="/home/work/page_server"

# Seconds to wait between hosts during rolling upgrade
SLEEP_SEC=60

# Seconds to wait between status check retries
STATUS_CHECK_RETRY_SLEEP_SEC=1

IPLIST_TMP=""
HOSTS_FILE=""
cleanup() {
    [ -n "$IPLIST_TMP" ] && rm -f "$IPLIST_TMP"
    [ -n "$HOSTS_FILE" ] && rm -f "$HOSTS_FILE"
}
trap cleanup EXIT

# ============================================================
# Usage
# ============================================================
TODAY=$(date +%Y%m%d)

usage() {
    echo "Usage: sh $0 <upgrade|rollback> <source_addr_or_backup_name> [backup_name] [bns] [--confirm-each-host]"
    echo ""
    echo "  upgrade  <ip:port> [backup_name]  - batch upgrade, download new binary from the given address"
    echo "  rollback <backup_name>            - batch rollback to the specified backup"
    echo ""
    echo "  backup_name          - optional for upgrade, creates backup with this name before upgrade"
    echo "  bns                  - optional, overrides the BNS setting in the script"
    echo "  --confirm-each-host  - after each host is processed, require manual confirmation before continuing"
    echo ""
    echo "Examples:"
    echo "  sh $0 upgrade  10.211.126.18:8989"
    echo "  sh $0 upgrade  10.211.126.18:8989 ${TODAY}_backup"
    echo "  sh $0 rollback ${TODAY}_v1.2.3"
    echo "  sh $0 upgrade  10.211.126.18:8989 ${TODAY}_backup  sandbox-multips00.gaia.bjdd:6000"
    echo "  sh $0 upgrade  10.211.126.18:8989 ${TODAY}_backup  sandbox-multips00.gaia.bjdd:6000 --confirm-each-host"
    exit 1
}

CONFIRM_EACH_HOST=0
if [ "$#" -gt 0 ]; then
    last_arg="${!#}"
    if [ "$last_arg" = "--confirm-each-host" ]; then
        CONFIRM_EACH_HOST=1
        set -- "${@:1:$(($# - 1))}"
    fi
fi

MODE=${1:-}
ARG=${2:-}
BACKUP_NAME=${3:-}
BNS_OVERRIDE=${4:-}
START_IDX=1

if [ -z "$MODE" ] || [ -z "$ARG" ]; then
    usage
fi

if [ "$MODE" = "upgrade" ]; then
    # For upgrade: ARG is source_addr, BACKUP_NAME is optional
    BNS_OVERRIDE=$4
elif [ "$MODE" = "rollback" ]; then
    # For rollback: ARG is backup_name, shift BACKUP_NAME to BNS
    BNS_OVERRIDE=$3
    BACKUP_NAME=""
fi

if [ "$MODE" != "upgrade" ] && [ "$MODE" != "rollback" ]; then
    echo "Error: mode must be 'upgrade' or 'rollback'"
    usage
fi

# Command-line BNS takes precedence over the in-script value
if [ -n "$BNS_OVERRIDE" ]; then
    BNS="$BNS_OVERRIDE"
fi

if [ -z "$BNS" ]; then
    echo "Error: BNS not set. Uncomment a BNS line in the script or pass it as 3rd argument."
    exit 1
fi

# Resolve local script path
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
if [ "$MODE" = "upgrade" ]; then
    LOCAL_SCRIPT="$SCRIPT_DIR/upgrade.sh"
    REMOTE_CMD="sh $REMOTE_DIR/upgrade.sh $ARG"
    if [ -n "$BACKUP_NAME" ]; then
        REMOTE_CMD="$REMOTE_CMD $BACKUP_NAME"
    fi
else
    LOCAL_SCRIPT="$SCRIPT_DIR/rollback.sh"
    # Use -t (pseudo-tty) if the remote script requires interactive input
    REMOTE_CMD="sh $REMOTE_DIR/rollback.sh $ARG"
fi

if [ ! -f "$LOCAL_SCRIPT" ]; then
    echo "Error: local script not found: $LOCAL_SCRIPT"
    exit 1
fi

echo "=== Batch $MODE ==="
echo "BNS:    $BNS"
echo "Arg:    $ARG"
echo "Script: $LOCAL_SCRIPT"
if [ "$CONFIRM_EACH_HOST" -eq 1 ]; then
    echo "Confirm each host: enabled"
fi
echo ""

# Generate host list
IPLIST_TMP=$(mktemp ./batch_upgrade_iplist.XXXXXX)
rm -f $IPLIST_TMP
echo "+ gaia list-ps-status -m --cluster-addr \"bns://$BNS\" --output-iplist \"$IPLIST_TMP\""
gaia list-ps-status -m --cluster-addr "bns://$BNS" --output-iplist "$IPLIST_TMP"
if [ ! -s "$IPLIST_TMP" ]; then
    echo "Error: failed to get host list via gaia for BNS: $BNS"
    rm -f "$IPLIST_TMP"
    exit 1
fi

# Parse iplist: produce "zone ip:port" lines sorted by zone, then IP address
HOSTS_FILE=$(mktemp ./batch_upgrade_hosts.XXXXXX)
awk '/^topology_zone:/{zone=$2; next} /^[0-9]/{split($1, addr, ":"); split(addr[1], ip, "."); printf "%s %03d.%03d.%03d.%03d %s\n", zone, ip[1], ip[2], ip[3], ip[4], $0}' "$IPLIST_TMP" \
    | sort -k1,1 -k2,2 \
    | awk '{print $1" "$3}' > "$HOSTS_FILE"
rm -f "$IPLIST_TMP"

if [ ! -s "$HOSTS_FILE" ]; then
    echo "Error: no hosts found for BNS: $BNS"
    rm -f "$HOSTS_FILE"
    exit 1
fi

TOTAL=$(wc -l < "$HOSTS_FILE")
IDX=0
PROCESSED=0
FAILED=""

echo ""
echo "Host list (ordered by topology_zone, then IP):"
awk '{printf "  [%d] zone=%s  %s\n", NR, $1, $2}' "$HOSTS_FILE"
echo ""
while true; do
    read -p "Start from which host index? (1-$TOTAL, default: 1, quit: q): " START_IDX
    case "$START_IDX" in
        q|Q) echo "Aborted by user."; exit 1 ;;
        *) break ;;
    esac
    START_IDX=${START_IDX:-1}
    if [[ "$START_IDX" =~ ^[0-9]+$ ]] && [ "$START_IDX" -ge 1 ] && [ "$START_IDX" -le "$TOTAL" ]; then
        break
    fi
    echo "Invalid input, please enter a number between 1 and $TOTAL."
done
REMAINING=$((TOTAL - START_IDX + 1))
while true; do
    read -p "Confirm to proceed with $REMAINING hosts from index $START_IDX? (y/N): " confirm
    case "$confirm" in
        y|Y) break ;;
        n|N|"") echo "Aborted by user."; rm -f "$HOSTS_FILE"; exit 0 ;;
        *) echo "Invalid input, please enter y or n." ;;
    esac
done

# Run a command; on failure prompt the user: retry / quit / skip
# Usage: run_with_retry <description> <command...>
run_with_retry() {
    local desc="$1"
    shift
    while true; do
        echo "+ $*"
        if "$@"; then
            return 0
        fi
        echo ""
        echo "FAILED: $desc"
        while true; do
            read -p "  [r] retry  [q] quit  [s] skip this host  > " action < /dev/tty
            case "$action" in
                r|R) echo "Retrying: $desc"; break ;;
                q|Q) echo "Aborted by user."; exit 1 ;;
                s|S) return 1 ;;
                *)   echo "Invalid input, please enter r/q/s." ;;
            esac
        done
    done
}

# Run a command with automatic retries; after all attempts fail, prompt retry / quit.
# Usage: run_status_check_with_retry <description> <command...>
run_status_check_with_retry() {
    local desc="$1"
    local max_retries=3
    local attempt
    shift

    while true; do
        for attempt in $(seq 1 "$max_retries"); do
            echo "+ $*"
            if "$@"; then
                return 0
            fi
            echo "FAILED: $desc (attempt $attempt/$max_retries)"
            if [ "$attempt" -lt "$max_retries" ]; then
                echo "Sleeping ${STATUS_CHECK_RETRY_SLEEP_SEC}s before retry..."
                sleep "$STATUS_CHECK_RETRY_SLEEP_SEC"
            fi
        done

        while true; do
            read -p "  Status check failed after $max_retries attempts. [r] retry  [q] quit  > " action < /dev/tty
            case "$action" in
                r|R)
                    echo "Sleeping ${STATUS_CHECK_RETRY_SLEEP_SEC}s before retrying: $desc"
                    sleep "$STATUS_CHECK_RETRY_SLEEP_SEC"
                    break
                    ;;
                q|Q) echo "Aborted by user."; exit 1 ;;
                *)   echo "Invalid input, please enter r/q." ;;
            esac
        done
    done
}

check_store_status() {
    local host_ip="$1"
    local host_port="$2"
    local output
    local rc

    if output=$(gaia list-ps-status -m -a "$host_ip" -p "$host_port" --only-show-store --table -H 2>&1); then
        rc=0
    else
        rc=$?
    fi

    printf '%s\n' "$output"
    if [ "$rc" -ne 0 ]; then
        return "$rc"
    fi

    if printf '%s\n' "$output" | grep -Eq '^[|][[:space:]]*code:[[:space:]]*[|][[:space:]]*([^|]*ERROR|[^|]*FAIL)'; then
        return 1
    fi
    if printf '%s\n' "$output" | grep -Eq 'Connection refused|Not connected'; then
        return 1
    fi

    return 0
}

PREV_ZONE=""
exec 3< "$HOSTS_FILE"  # Use fd 3 for host file, keep stdin free for user input
while IFS=' ' read -r ZONE HOST <&3; do
    IDX=$((IDX + 1))
    if [ "$IDX" -lt "$START_IDX" ]; then
        PREV_ZONE="$ZONE"
        continue
    fi
    PROCESSED=$((PROCESSED + 1))
    # HOST is ip:port from gaia output; ssh/scp only need the IP
    HOST_IP=$(echo "$HOST" | cut -d: -f1)
    HOST_PORT=$(echo "$HOST" | cut -d: -f2)

    # Zone boundary: prompt before starting a new zone (skip on the very first host)
    if [ -n "$PREV_ZONE" ] && [ "$ZONE" != "$PREV_ZONE" ]; then
        echo ""
        echo "=== Zone $PREV_ZONE completed. Next: zone $ZONE ==="
        while true; do
            read -p "Continue to zone $ZONE? (y/N): " confirm < /dev/tty
            case "$confirm" in
                y|Y) break ;;
                n|N|"") echo "Aborted by user after zone $PREV_ZONE."; rm -f "$HOSTS_FILE"; exit 0 ;;
                *) echo "Invalid input, please enter y or n." ;;
            esac
        done
    fi
    PREV_ZONE="$ZONE"

    echo ""
    echo "[$PROCESSED/$REMAINING] index=$IDX === $HOST (zone=$ZONE) ==="

    # Show store status before upgrade
    echo ""
    if ! run_status_check_with_retry "checking status before $MODE for $HOST" \
            check_store_status "$HOST_IP" "$HOST_PORT"; then
        FAILED="$FAILED $HOST"
        continue
    fi
    echo ""

    # Distribute script to remote host
    echo "Sleeping 2s before scp..."
    sleep 2
    if ! run_with_retry "scp to $HOST" \
            scp -o StrictHostKeyChecking=no "$LOCAL_SCRIPT" "work@$HOST_IP:$REMOTE_DIR/"; then
        FAILED="$FAILED $HOST"
        continue
    fi

    # Execute remotely
    if ! run_with_retry "ssh $MODE on $HOST" \
            ssh -o StrictHostKeyChecking=no "work@$HOST_IP" "$REMOTE_CMD"; then
        FAILED="$FAILED $HOST"
        continue
    fi

    echo "[$PROCESSED/$REMAINING] OK: index=$IDX $HOST"

    # Show store status after upgrade
    echo ""
    echo "Sleeping 1s before checking status..."
    sleep 1
    if ! run_status_check_with_retry "checking status for $HOST" \
            check_store_status "$HOST_IP" "$HOST_PORT"; then
        FAILED="$FAILED $HOST"
        continue
    fi
    echo ""

    # Optional per-host confirmation, otherwise keep the existing first-host safety confirmation.
    if [ $PROCESSED -lt $REMAINING ]; then
        NEXT_IDX=$((IDX + 1))
        NEXT_PROCESSED=$((PROCESSED + 1))
        NEXT_INFO=$(awk -v idx="$NEXT_IDX" 'NR == idx { print "index=" idx " " $2 " (zone=" $1 ")" }' "$HOSTS_FILE")
        if [ "$CONFIRM_EACH_HOST" -eq 1 ]; then
            echo ""
            while true; do
                read -p "Host [$PROCESSED/$REMAINING] index=$IDX done. Continue to next host [$NEXT_PROCESSED/$REMAINING] $NEXT_INFO? (y/N): " confirm < /dev/tty
                case "$confirm" in
                    y|Y) break ;;
                    n|N|"") echo "Aborted by user after host index=$IDX."; exit 0 ;;
                    *) echo "Invalid input, please enter y or n." ;;
                esac
            done
        elif [ $PROCESSED -eq 1 ]; then
            echo ""
            while true; do
                read -p "First processed host done. Continue to remaining $((REMAINING - 1)) hosts, next host $NEXT_INFO? (y/N): " confirm < /dev/tty
                case "$confirm" in
                    y|Y) break ;;
                    n|N|"") echo "Aborted by user after first processed host."; exit 0 ;;
                    *) echo "Invalid input, please enter y or n." ;;
                esac
            done
        fi
    fi

    # No sleep after the last host. In confirm-each-host mode, manual confirmation replaces sleep.
    if [ $PROCESSED -lt $REMAINING ] && [ "$CONFIRM_EACH_HOST" -ne 1 ]; then
        echo "Sleeping ${SLEEP_SEC}s before next host..."
        sleep $SLEEP_SEC
    fi
done
exec 3<&-  # Close fd 3
rm -f "$HOSTS_FILE"

echo ""
if [ -z "$FAILED" ]; then
    echo "=== Batch $MODE completed: all $REMAINING selected hosts OK ==="
else
    echo "=== Batch $MODE finished with failures: $FAILED ==="
    exit 1
fi
