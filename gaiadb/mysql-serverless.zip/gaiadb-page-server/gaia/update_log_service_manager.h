/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_log_service_manager.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"
#include <gaiadb/proto/log_service/lsrv_message_service.pb.h>
#include <gaiadb/proto/log_service/lsrv_error_code.pb.h>

namespace psvr {
namespace gaia {

class UpdateLogServiceManager : public Command {
public:
    UpdateLogServiceManager() {
        SetName("update-ls-manager");
        SetDesc("reset manager address of log service");
        SetDescCn("重置日志服务的管理地址");

        AddNodeOption();
        AddRequiredArgOption("manager-address", NULL, 'M',
                "set new manager address to log service", kstring);
        
        AddExample("-a <ip> -p <port> --manager-address bns://xxx");
    }
    virtual ~UpdateLogServiceManager() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            default:
                return 1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const lspb::lsrv_modify_manager_response& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _manager_address {};
};

}
}
