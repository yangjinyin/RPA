/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_replication_status.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/list_replication_status.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ListReplicationStatus::Run() {
    if (_cluster_addr.empty() && (_address.empty() || _port < 1)) {
        print_error("miss --cluster-addr or (--address and --port)");
        return 1;
    }

    if (_cluster_addr.empty()) {
        base::EndPoint node;
        int ret = base::str2endpoint(_address.c_str(), _port, &node);
        if (ret != 0) {
            print_error("--address and --port convert to endpoint error");
            return 1;
        }
        RpcStatus status;
        if (_cluster_id.size()) {
            replicate::pb::GetReplicatorRequest request;
            replicate::pb::GetReplicatorResponse response;

            request.set_log_id(_log_id);
            request.set_standby_cluster_id(_cluster_id);
            _client.Call(_log_id, node, &replicate::pb::ReplicationService_Stub::GetReplicator, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (!status.IsOk()) {
                LOG(WARNING) << node << " get failed, " << status << " " << response.status();
                response.mutable_status()->set_code(replicate::pb::RPC_ERROR);
                response.mutable_status()->set_msg(status.msg);
            }
            return Output(response);
        } else {
            replicate::pb::ListReplicatorRequest request;
            replicate::pb::ListReplicatorResponse response;
            request.set_log_id(_log_id);
            _client.Call(_log_id, node, &replicate::pb::ReplicationService_Stub::ListReplicator, &request, &response,
                    nullptr, &status, _timeout_ms);
            if (!status.IsOk()) {
                LOG(WARNING) << node << " list failed, " << status << " " << response.status();
                response.mutable_status()->set_code(replicate::pb::RPC_ERROR);
                response.mutable_status()->set_msg(status.msg);
            }
            return Output(response);
        }
    } else {
        PsmInfo psm_info(_cluster_addr, _both);
        std::vector<base::EndPoint> nodes;
        if (!psm_info.GetOrRefreshNodes(&nodes)) {
            print_error("--cluster-addr parse failed, cant get server list from it");
            return 1;
        }

        auto wait_finish_fn = [this] () {
            while (!_stopped) {
                if (_task_count.load(std::memory_order_acquire) == 0) {
                    break;
                } else {
                    gaiadb::common::pause();    // x86
                }
            }
            if (_stopped) {
                print_error("quit by signal");
                return 1;
            }
            return 0;
        };

        _task_count.store(nodes.size());
        replicate::pb::BatchListReplicatorResponse response;
        response.set_log_id(_log_id);
        for (auto& node : nodes) {
            auto server_status = response.add_server_status();
            server_status->set_addr(gaiadb::common::endpoint2str(node));
            replicate::pb::ListReplicatorResponse* rsp = server_status->mutable_status();
            replicate::pb::ListReplicatorRequest request;
            request.set_log_id(_log_id);
            RpcStatus* status = new RpcStatus;
            auto closure = brpc::NewCallback(this, &ListReplicationStatus::Done, rsp, status);
            _client.Call(_log_id, node, &replicate::pb::ReplicationService_Stub::ListReplicator, &request, rsp,
                    closure, status, _timeout_ms);
        }
        if (wait_finish_fn()) {
            return 1;
        }
        return Output(response);
    }
}

void ListReplicationStatus::Done(replicate::pb::ListReplicatorResponse* rsp, RpcStatus* status) {
    if (!status->IsOk()) {
        rsp->set_log_id(_log_id);
        rsp->mutable_status()->set_code(replicate::pb::RPC_ERROR);
        rsp->mutable_status()->set_msg(status->msg);
    }
    delete status;
}

static std::string replicate_codes_to_str(const ggpb::RepeatedField<int>& replicate_codes) {
    std::string str;
    for (int i = 0; i < replicate_codes.size(); ++i) {
        if (i) {
            str.append(" ");
        }
        str.append(replicate::pb::ReplicateCode_Name(static_cast<replicate::pb::ReplicateCode>(replicate_codes[i])));
    }
    return str;
}

int ListReplicationStatus::Format(const replicate::pb::GetReplicatorResponse& rsp) {
    SHOW_RPL_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    {
        Table table(_raw_with_table, 3);
        table.AddRowsValue({"role:", rsp.role()});
        table.AddRowsValue({"state:", rsp.state()});
        table.AddRowsValue({"primay:", rsp.primary_cluster_id()});
        table.AddRowsValue({"standby:", rsp.standby_cluster_id()});
        table.AddRowsValue({"primary_vdl:", rsp.primary_vdl()});
        table.AddRowsValue({"standby_vdl:", rsp.standby_vdl(), rsp.primary_vdl() - rsp.standby_vdl()});
        table.AddRowsValue({"fetch_lsn:", rsp.fetch_lsn()});
        table.AddRowsValue({"parse_lsn:", rsp.parse_lsn()});
        table.AddRowsValue({"write_lsn:", rsp.write_lsn()});
        table.AddRowsValue({"write_vdl:", rsp.write_vdl(), rsp.write_lsn() - rsp.write_vdl()});
        table.AddRowsValue({"apply_lsn:", rsp.apply_lsn()});
        table.AddRowsValue({"inflight_fetch_lsn:", rsp.inflight_fetch_lsn(), rsp.inflight_fetch_lsn() - rsp.fetch_lsn()});
        table.AddRowsValue({"inflight_write_lsn:", rsp.inflight_write_lsn(), rsp.inflight_write_lsn() - rsp.write_lsn()});
        table.AddRowsValue({"lowest_ddl_lsn:", rsp.lowest_ddl_lsn()});
        table.AddRowsValue({"cn_lowest_lsn:", rsp.cn_lowest_lsn()});
        table.AddRowsValue({"ps_lowest_lsn:", rsp.ps_lowest_lsn()});
        table.AddRowsValue({"replicate_codes:", replicate_codes_to_str(rsp.replicate_codes())});
        table.Display();
    }
    return 0;
}

int ListReplicationStatus::Format(const replicate::pb::ListReplicatorResponse& rsp) {
    SHOW_RPL_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    {
        if (rsp.replicators_size()) {
            Table table(_raw_with_table, 0);
            table.AddRowsWithName({"role", "state", "primary", "standby",
                    "primary_vdl", "standby_vdl",
                    "fetch_lsn", "parse_lsn", "write_vdl", "write_lsn",
                    "cn_lowest_lsn", "ps_lowest_lsn", "replicate_codes"}, true);
            for (auto& pb : rsp.replicators()) {
                table.AddRowsValue({
                    pb.role(),
                    pb.state(),
                    pb.primary_cluster_id(),
                    pb.standby_cluster_id(),
                    pb.primary_vdl(),
                    pb.standby_vdl(),
                    pb.fetch_lsn(),
                    pb.parse_lsn(),
                    pb.write_vdl(),
                    pb.write_lsn(),
                    pb.cn_lowest_lsn(),
                    pb.ps_lowest_lsn(),
                    replicate_codes_to_str(pb.replicate_codes())
                });
            }
            table.Display();
        }
    }
    return 0;
}

int ListReplicationStatus::Format(const replicate::pb::BatchListReplicatorResponse& rsp) {
    Table __header(_raw_with_table, 2);
    __header.AddRowsValue({"log_id:", _log_id});
    __header.Display();
    for (auto& server_pb : rsp.server_status()) {
        const auto& server = server_pb.status();
        Table __server(_raw_with_table, 2);
        __server.AddRowsValue({"server:", server_pb.addr().c_str()});
        __server.AddRowsValue({"code:", replicate::pb::Code_Name(server.status().code()).c_str()});
        __server.AddRowsValue({"msg:", server.status().msg().c_str()});
        __server.Display();
        if (server.status().code() == replicate::pb::SUCCESS) {
            if (server.replicators_size()) {
                Table table(_raw_with_table, 0);
                table.AddRowsWithName({"role", "state", "primary", "standby",
                        "fetch_lsn", "parse_lsn", "write_vdl", "write_lsn",
                        "cn_lowest_lsn", "ps_lowest_lsn", "primary_vdl", "standby_vdl", "replicate_codes"}, true);
                for (auto& pb : server.replicators()) {
                    table.AddRowsValue({
                            pb.role(),
                            pb.state(),
                            pb.primary_cluster_id(),
                            pb.standby_cluster_id(),
                            pb.fetch_lsn(),
                            pb.parse_lsn(),
                            pb.write_vdl(),
                            pb.write_lsn(),
                            pb.cn_lowest_lsn(),
                            pb.ps_lowest_lsn(),
                            pb.primary_vdl(),
                            pb.standby_vdl(),
                            replicate_codes_to_str(pb.replicate_codes())
                        });
                }
            }
        }
    }
    return 0;
}

}
}
