/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/segment_manager.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <unordered_set>
#include "psvr/common.h"
#include "psvr/segment.h"
#include "psvr/namespace.h"
#include "psvr/cluster.h"

namespace psvr {

class SegmentManager;
using SegmentManagerPtr = std::shared_ptr<SegmentManager>;
using SegmentIteratorFn = std::function<void(SegmentPtr)>;

class SegmentManager {
    using ClusterResManager = ResManager<std::string, Cluster>;
    using PsmInfoResManager = ResManager<std::string, PsmInfo>;
public:
    SegmentManager();
    FUNC_MOCK ~SegmentManager() {}

    void Start(uint32_t store_count);
    FUNC_MOCK void Stop();

    size_t segment_size() { return _segment_size.load(); }
    int64_t GetClusterSize();
    int64_t GetPsmInfoSize();

    void SetBatchFetchClusters(const std::vector<std::string>& clusters);

    FUNC_MOCK ClusterPtr GetOrCreateCluster(const std::string& cluster_id);
    FUNC_MOCK ClusterPtr GetCluster(const std::string& cluster_id);

    FUNC_MOCK PsmInfoPtr GetPsmInfo(const std::string& address);
    FUNC_MOCK PsmInfoPtr GetOrCreatePsmInfo(const std::string& address);
    FUNC_MOCK void GetPsmInfos(pspb::ListPsmInfoResponse* response);

    FUNC_MOCK bool AddSegment(SegmentPtr segment);
    FUNC_MOCK bool ReplaceSegment(SegmentPtr segment, SegmentPtr new_segment);
    FUNC_MOCK bool DropSegment(SegmentPtr segment);
    FUNC_MOCK bool ExistSegment(SegmentPtr segment);
    FUNC_MOCK SegmentPtr GetSegment(const std::string& cluster_id, uint32_t segment_id);
    FUNC_MOCK uint32_t GetAllSegments(const SegmentIteratorFn& fn);
    FUNC_MOCK void GetAllSegments(std::vector<SegmentPtr>* segments);
    FUNC_MOCK void GetAllClusters(std::vector<std::string>* clusters);
    FUNC_MOCK void GetClusterSegments(const std::string& cluster_id,
            std::vector<SegmentPtr>* segments);
    FUNC_MOCK uint32_t GetClusterSegments(const std::string& cluster_id,
            const SegmentIteratorFn& fn);
    FUNC_MOCK uint32_t DropClusterSegments(const std::string& cluster_id,
            const SegmentIteratorFn& fn);
    FUNC_MOCK uint32_t GetStoreSegments(int32_t store_id,
            std::vector<SegmentPtr>* segments);
    FUNC_MOCK uint32_t DropStoreSegments(int32_t store_id,
            const SegmentIteratorFn& fn);

    FUNC_MOCK void ListAllClusterSegmentSize(pspb::ListClusterStatusResponse* rsp);

    bool GetClusterUpdateLowestLsnLock(const std::string& cluster_id) {
        return _cluster_update_lowest_lsn_locks.GetReqLock(cluster_id);
    }
    void PutClusterUpdateLowestLsnLock(const std::string& cluster_id) {
        _cluster_update_lowest_lsn_locks.PutReqLock(cluster_id);
    }

private:
    struct SegmentCluster {
        const std::string id;
        std::map<uint32_t, SegmentPtr> segments;
        std::map<uint32_t, std::list<SegmentPtr>::iterator> slots;

        SegmentCluster(const std::string& _id) : id(_id), segments(), slots() {}

        SegmentPtr Get(uint32_t segment_id) {
            if (auto it = segments.find(segment_id);
                it != segments.end()) {
                return it->second;
            }
            return nullptr;
        }

        bool Add(SegmentPtr segment) {
            return segments.emplace(segment->segment_id(), segment).second;
        }
        bool Del(SegmentPtr segment) {
            return segments.erase(segment->segment_id()) > 0;
        }
        bool Replace(SegmentPtr segment, SegmentPtr new_segment) {
            if (Del(segment)) {
                return Add(new_segment);
            }
            return false;
        }
        bool Clear(SegmentPtr segment) {
            return segments.erase(segment->segment_id()) && slots.erase(segment->segment_id());
        }
    };

    struct SegmentStore {
        const int32_t id;
        std::list<SegmentPtr> segments;

        SegmentStore(int32_t _id) : id(_id), segments() {}

        bool Add(SegmentPtr segment, SegmentCluster& cluster) {
            segments.emplace_front(segment);
            if (!cluster.slots.emplace(segment->segment_id(), segments.begin()).second) {
                segments.pop_front();
                return false;
            }
            return true;
        }

        bool Del(SegmentPtr segment, SegmentCluster& cluster) {
            if (auto it = cluster.slots.find(segment->segment_id());
                    it != cluster.slots.end()) {
                segments.erase(it->second);
                cluster.slots.erase(it);
                return true;
            }
            return false;
        }

        bool Replace(SegmentPtr segment, SegmentPtr new_segment, SegmentCluster& cluster) {
            if (Del(segment, cluster)) {
                return Add(new_segment, cluster);
            }
            return false;
        }
    };

    SegmentCluster& GetOrCreateSegmentClusterNoLock(const std::string& cluster_id);

private:
    std::atomic<size_t> _segment_size;
    size_t _segment_version;
    rwlock_t _shared_mutex;
    std::unordered_map<std::string, SegmentCluster> _cluster_segments;
    std::vector<SegmentStore> _store_segments;

    std::vector<std::shared_ptr<PsmInfoResManager>> _psm_infos;
    std::vector<std::shared_ptr<ClusterResManager>> _clusters;
    std::set<std::string> _use_batch_fetch_clusters;
    size_t _use_batch_fetch_clusters_size;

    InflightReqLock<std::string> _cluster_update_lowest_lsn_locks;
};

}
