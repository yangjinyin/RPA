/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_buf.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/dbengine.h"
#include "psvr/append_file.h"

namespace psvr {
namespace test {

class MockDBEngine : public DBEngine {
public:
    MockDBEngine() : DBEngine() {}
    virtual ~MockDBEngine() {}

    MOCK_METHOD1(Open, db::Status(const db::OpenOptions&));

    MOCK_METHOD1(GetSize, int64_t(bool));
    MOCK_METHOD5(Read, db::Status(const db::ReadOptions&, uint64_t, uint64_t, void*, db::ReadOutputs*));
    MOCK_METHOD5(Write, db::Status(const db::WriteOptions&, uint64_t, uint64_t, void*, db::WriteOutputs*));
    MOCK_METHOD1(Sync, db::Status(bool));
    MOCK_METHOD3(Trim, db::Status(const db::TrimOptions&, uint64_t, uint64_t));


};

class MockAppendDBEngine : public AppendDBEngine {
public:
    MockAppendDBEngine() : AppendDBEngine() {}
    virtual ~MockAppendDBEngine() {}


    MOCK_METHOD4(Open, db::Status(const std::string&, gaia_apply::lsn_t, gaia_apply::lsn_t*, gaia_apply::lsn_t*));
    //MOCK_METHOD1(Init, db::Status(gaia_apply::lsn_t));
    MOCK_METHOD3(SetCheckPointLsn, db::Status(gaia_apply::lsn_t, uint64_t, bool));
    MOCK_CONST_METHOD0(GetCheckPointLsn, gaia_apply::lsn_t());
    MOCK_METHOD6(Append, db::Status(const db::LogHeader&, const Slice&, const Slice&, uint64_t*, uint64_t*, bool));
    MOCK_METHOD5(BatchAppend, db::Status(const std::vector<db::LogHeader>&,
            const std::vector<Slice>&, const std::vector<Slice>&,
            std::vector<uint64_t>*, std::vector<uint64_t>*));
    MOCK_METHOD5(Read, db::Status(uint64_t, uint64_t, Slice*, char*, uint32_t));
    MOCK_METHOD1(RecoverStart, db::Status(uint64_t*));
    MOCK_METHOD6(RecoverLog, db::Status(db::LogHeader*, Slice*, Slice*, char**, uint64_t*, uint64_t*));
    MOCK_METHOD8(FetchRedoLog, db::Status(uint64_t, db::LogHeader*, Slice*, Slice*, char**, uint64_t&, uint64_t&, AppendReadBuf*));

};



}
}
