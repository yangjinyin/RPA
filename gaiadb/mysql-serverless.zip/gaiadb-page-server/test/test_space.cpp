/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_space.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/space.h"

namespace psvr {
namespace test {

class SpaceTests : public PsvrTest {
 public:
    SpaceTests()  {
        gaiadb::common::ut_crc32_init();
    }
    virtual ~SpaceTests() {}

    void SetUp() {
    }

    void TearDown() {
    }

private:
};

TEST_F(SpaceTests, test_InflightReqLock) {
    InflightReqLock<uint32_t> inflight;
    ASSERT_TRUE(inflight.GetReqLock(1));
    ASSERT_FALSE(inflight.GetReqLock(1));
    ASSERT_TRUE(inflight.PutReqLock(1));
    ASSERT_FALSE(inflight.PutReqLock(1));
    ASSERT_TRUE(inflight.GetReqLock(1));
}

TEST_F(SpaceTests, test_SpaceStatusManager) {
    SpaceStatusManager ssm;
    ASSERT_EQ(ssm.GetSpaceStatusCount(), 0);

    ssm.SetSpaceStatus(1, kSpaceStatusWork);
    ASSERT_EQ(ssm.GetSpaceStatus(1), kSpaceStatusWork);
    ssm.SetSpaceStatus(1, kSpaceStatusWork);
    ASSERT_EQ(ssm.GetSpaceStatus(1), kSpaceStatusWork);
    ssm.SetSpaceStatus(1, kSpaceStatusWork | kSpaceStatusWithPSM);
    ASSERT_EQ(ssm.GetSpaceStatus(1), kSpaceStatusWork);

    ssm.SetSpaceStatus(1, kSpaceStatusDeleted);
    ASSERT_EQ(ssm.GetSpaceStatus(1), kSpaceStatusDeleted);

    ssm.SetSpaceStatus(1, kSpaceStatusDeleted | kSpaceStatusWithPSM);
    ASSERT_EQ(ssm.GetSpaceStatus(1), kSpaceStatusDeleted | kSpaceStatusWithPSM);

    ssm.SetSpaceStatus(2, kSpaceStatusDeleted | kSpaceStatusWithPSM);
    ASSERT_NE(ssm.GetSpaceStatus(2), kSpaceStatusDeleted);
    ssm.SetSpaceStatus(2, kSpaceStatusDeleted);
    ASSERT_EQ(ssm.GetSpaceStatus(2), kSpaceStatusDeleted);

    ssm.SetSpaceStatus(3, kSpaceStatusWork | kSpaceStatusWithPSM);
    ASSERT_EQ(ssm.GetSpaceStatus(3), kSpaceStatusWork | kSpaceStatusWithPSM);

    ssm.SetSpaceStatus(4, kSpaceStatusWork);

    FLAGS_psvr_clear_space_status_interval_ms = 2;
    sleep_for(SLEEP_SECOND);

    ASSERT_EQ(ssm.GetSpaceStatusCount(), 4);
    ssm.ClearUseLessSpaceStatus();
    ASSERT_EQ(ssm.GetSpaceStatusCount(), 1);
}

TEST_F(SpaceTests, test_SpaceStatusManagerSafeTrimLsn) {
    SpaceStatusManager ssm;

    ASSERT_EQ(ssm.GetSafeTrimLsn(1), 0);
    ASSERT_TRUE(ssm.SetSafeTrimLsn(1, 100));
    ASSERT_EQ(ssm.GetSafeTrimLsn(1), 100);
    ASSERT_EQ(ssm.GetSpaceStatusCount(), 1);

    ASSERT_TRUE(ssm.SetSafeTrimLsn(1, 100));
    ASSERT_EQ(ssm.GetSpaceStatusCount(), 1);
    ASSERT_TRUE(ssm.SetSafeTrimLsn(1, 200));
    ASSERT_EQ(ssm.GetSafeTrimLsn(1), 200);
    ASSERT_EQ(ssm.GetSpaceStatusCount(), 1);
    END_OF_CASE;
}

TEST_F(SpaceTests, test_Space_GetPage) {
    SpacePageManager smm;
    auto page = smm.GetPage(1, 1, false);
    ASSERT_EQ(page, nullptr);

    page = smm.GetOrCreatePage(1, 1);
    ASSERT_TRUE(page != nullptr);

    auto page2 = smm.GetPage(1, 1, false);
    ASSERT_EQ(page, page2);
}

TEST_F(SpaceTests, test_Space_Extent) {
    ExtentMetaManager emm;

    uint32_t physical_extent_id = 0;
    gaia_apply::space_id_t space_id;
    uint32_t logic_extent_id;
    bool match = false;

    emm.Set(1, 0, 0);
    emm.Set(2, 0, 1);
    emm.Set(2, 1, 2);

    ASSERT_FALSE(emm.Get(1, 1, &physical_extent_id));

    ASSERT_TRUE(emm.Get(1, 0, &physical_extent_id));
    ASSERT_EQ(physical_extent_id, 0);

    ASSERT_TRUE(emm.Get(2, 0, &physical_extent_id));
    ASSERT_EQ(physical_extent_id, 1);

    ASSERT_TRUE(emm.Get(2, 1, &physical_extent_id));
    ASSERT_EQ(physical_extent_id, 2);

    ASSERT_FALSE(emm.Get(2, 2, &physical_extent_id));
    ASSERT_FALSE(emm.Get(3, 0, &physical_extent_id));

    ASSERT_FALSE(emm.CleanSpaceExtent(3));
    ASSERT_TRUE(emm.CleanSpaceExtent(2));
    ASSERT_FALSE(emm.Get(2, 0, &physical_extent_id));
    ASSERT_FALSE(emm.Get(2, 1, &physical_extent_id));

    ASSERT_FALSE(emm.GetPhysicalExtent(1, &space_id, &logic_extent_id, &match));
    ASSERT_FALSE(emm.GetPhysicalExtent(2, &space_id, &logic_extent_id, &match));

    ASSERT_TRUE(emm.GetPhysicalExtent(0, &space_id, &logic_extent_id, &match));
    ASSERT_EQ(space_id, 1);
    ASSERT_EQ(logic_extent_id, 0);

    ASSERT_FALSE(emm.SetPhysicalExtent(1, 1, 0));

    ASSERT_TRUE(emm.GetPhysicalExtent(0, &space_id, &logic_extent_id, &match));
    ASSERT_EQ(space_id, 1);
    ASSERT_EQ(logic_extent_id, 0);
    ASSERT_TRUE(match);

    ASSERT_TRUE(emm.SetPhysicalExtent(1, 1, 1));
    ASSERT_TRUE(emm.GetPhysicalExtent(1, &space_id, &logic_extent_id, &match));
    ASSERT_EQ(space_id, 1);
    ASSERT_EQ(logic_extent_id, 1);
    ASSERT_FALSE(match);

    ASSERT_TRUE(emm.SetPhysicalExtent(1, 3, 1));
    ASSERT_TRUE(emm.GetPhysicalExtent(1, &space_id, &logic_extent_id, &match));
    ASSERT_EQ(space_id, 3);
    ASSERT_EQ(logic_extent_id, 1);
    ASSERT_FALSE(match);
}

TEST_F(SpaceTests, test_Segment) {
    auto seg = create_segment();
    bool ret = seg->GetSpaceExtentReqLock(1, 1);
    ASSERT_TRUE(ret);
    ret = seg->GetSpaceExtentReqLock(1, 1);
    ASSERT_FALSE(ret);
    seg->PutSpaceExtentReqLock(1, 1);
    ret = seg->GetSpaceExtentReqLock(1, 1);
    ASSERT_TRUE(ret);
    seg->PutSpaceExtentReqLock(1, 1);

    ASSERT_FALSE(gaia_page_is_compressed());
}

}
}
