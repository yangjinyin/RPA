/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_takeover_compute_node.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/get_takeover_compute_node.h"

namespace psvr {
namespace gaia {

int GetTakeOverComputeNode::Run() {
    RpcStatus status;

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    computenode::takeover_status_request request;
    computenode::takeover_status_response response;

    if (!_task_id.empty()) {
        request.set_task_id(_task_id);
    }

    _client.Call(_log_id, node, &computenode::StatusQueryService_Stub::query_takeover_status, &request, &response,
            nullptr, &status, _timeout_ms);
    if (status.IsOk()) {
        return Output(response);
    }

    LOG(WARNING) << node << " query taskover status failed, " << status << " " << response.status();
    print_error("rpc fail, %s", status.msg.c_str());
    return 1;
}

int GetTakeOverComputeNode::Format(const computenode::takeover_status_response& rsp) {
    SHOW_CMP_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"task_status:", computenode::TakeoverStatus_Name(rsp.task_status())});
    table.AddRowsValue({"current_task_id:", rsp.current_task_id()});
    table.Display();
    return 0;
}

}
}
