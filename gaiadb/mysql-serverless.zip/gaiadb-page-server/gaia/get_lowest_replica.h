/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_lowest_replica.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

static constexpr uint64_t k_min_distance = 536870912ul;

class GetLowestReplica : public Command {
public:
    GetLowestReplica() {
        SetName("get-lowest-replica");
        SetDesc("get lowest lsn segment replica in cluster");
        SetDescCn("获取集群中最低的 LSN 分片副本");

        AddPsmClusterOption();
        AddRequiredArgOption("min-distance", &_long_opt_val, kOptMax + 1, "min distance", kuint64_t);
        
        AddExample("--manager-address \"bns://xxx\" --min-distance 536870912");
    }
    virtual ~GetLowestReplica() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _min_distance = std::strtoul(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    void FindLowestNode(const gaiapb::ListPageServerResponse& rsp, pspb::LowestNode* rsp2);
    int Format(const pspb::LowestNode& rsp);

private:
    std::string _manager_address {};
    uint64_t _min_distance {k_min_distance};
};

}
}
