/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/psminfo.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "psvr/psminfo.h"

namespace psvr {

bool PsmInfo::GetOrRefreshBNSNodes(std::vector<base::EndPoint>* nodes) {
    return GetOrRefreshNodesImpl(nodes, false, false);
}

bool PsmInfo::GetOrRefreshNodes(std::vector<base::EndPoint>* nodes, bool sync) {
    return GetOrRefreshNodesImpl(nodes, sync, true);
}

bool PsmInfo::GetOrRefreshNodesImpl(std::vector<base::EndPoint>* nodes,
        bool sync, bool include_heartbeat) {
    if (!_is_parsed.load(std::memory_order_acquire)) {
        std::unique_lock lm(_shared_mutex, std::try_to_lock);
        if (!lm) {
            return false;
        }
        if (!_is_parsed.load(std::memory_order_relaxed) && !ParseAddressNoLock()) {
            return false;
        }
    }
    bool force_refresh = sync ||
            _err_times.load(std::memory_order_relaxed) > 1;
    if (!force_refresh) {
        std::shared_lock slm(_shared_mutex);
        if (!_nodes.empty()) {
            *nodes = _nodes;
            if (include_heartbeat) {
                nodes->insert(nodes->end(),
                        _nodes_from_heartbeat.begin(), _nodes_from_heartbeat.end());
            }
            return true;
        }
    }

    std::unique_lock lm(_shared_mutex, std::try_to_lock);
    if (!lm) {
        return false;
    }
    if ((_nodes.empty() || force_refresh)
            && !RefreshNodesNoLock()) {
        return false;
    }
    *nodes = _nodes;
    if (include_heartbeat) {
        nodes->insert(nodes->end(),
                _nodes_from_heartbeat.begin(), _nodes_from_heartbeat.end());
    }
    return !nodes->empty();
}

void PsmInfo::MoveLeaderToFirst(uint32_t idx, const base::EndPoint& node) {
    std::unique_lock lm(_shared_mutex, std::try_to_lock);
    if (!lm) {
        return;
    }
    if (idx < _nodes.size()) {
        for (; idx > 0 && idx < _nodes.size(); ++idx) {
            if (node == _nodes[idx]) {
                std::swap(_nodes[0], _nodes[idx]);
            }
        }
    } else {
        idx -= _nodes.size();
        for (; idx > 0 && idx < _nodes_from_heartbeat.size(); ++idx) {
            if (node == _nodes_from_heartbeat[idx]) {
                std::swap(_nodes_from_heartbeat[0], _nodes_from_heartbeat[idx]);
            }
        }
    }

}

std::ostream& PsmInfo::ToString(std::ostream& os) const {
    std::shared_lock lm(_shared_mutex);
    os << "psm_info:[address:" << _address << ", count_parsed_from_address=" << _nodes.size();
    for (auto& ep : _nodes) {
        os << "," << ep;
    }
    os << ". count_from_heartbeat=" << _nodes_from_heartbeat.size();
    for (auto& nh : _nodes_from_heartbeat) {
        os << "," << nh;
    }
    return os << "]";
}

bool PsmInfo::ParseAddressNoLock() {
    if (_is_parsed) {
        return true;
    }
    int ret = gaiadb::common::parse_address(_address, &_hostname, &_port, &_type);
    if (ret != 0) {
        LOG(WARNING) << "parse manager address failed,"
            << " addrs:[" << _address
            << "] ret:[" << ret
            << "]";
        return false;
    }
    _is_parsed.store(true, std::memory_order_release);
    LOG(NOTICE) << "parse manager info succ,"
        << " addrs:[" << _address
        << "] hostname:[" << _hostname
        << "] port:[" << _port
        << "] type:[" << static_cast<int32_t>(_type)
        << "]";
    return true;
}

bool PsmInfo::RefreshNodesNoLock() {
    if (!_is_parsed && !ParseAddressNoLock()) {
        return false;
    }
    std::vector<base::EndPoint> nodes;
    int ret = 0;
    if (_both) {
        ret = gaiadb::common::get_parse_address_all(_hostname,
                _port, _type, true, &nodes);
    } else {
        ret = gaiadb::common::get_parse_address(_hostname,
                _port, _type, &nodes);
    }
    if (ret != 0 || nodes.empty()) {
        LOG(WARNING) << "get manager address list failed,"
            << " addrs:[" << _address
            << "] ret:[" << ret
            << "] hostname:[" << _hostname
            << "] port:[" << _port
            << "] type:[" << static_cast<int32_t>(_type)
            << "] nodes_count:[" << nodes.size()
            << "]";
        return false;
    }
    _nodes = std::move(nodes);
    _err_times.store(0, std::memory_order_relaxed);
    return true;
}

void PsmInfo::SetNodesFromHeartbeat(const base::EndPoint& leader,
        const ggpb::RepeatedPtrField<std::string>& peer_list) {
    std::vector<base::EndPoint> nodes;
    nodes.emplace_back(leader);
    for (auto& peer : peer_list) {
        base::EndPoint endpoint;
        base::str2endpoint(peer.c_str(), &endpoint);
        if (endpoint != leader) {
            nodes.emplace_back(endpoint);
        }
    }

    {
        std::unique_lock lm(_shared_mutex);
        _nodes_from_heartbeat = std::move(nodes);
    }
}

}
