/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_topology.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/get_topology.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int GetTopology::Run() {
    RpcStatus status;
    gaiapb::TopologyRequest request;
    gaiapb::TopologyResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_topology, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " get topology failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("get failed, all nodes failed");
    return Output(response);
}

int GetTopology::Format(const gaiapb::TopologyResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.topology().has_cluster_role()) {
        Table table(_raw_with_table, 2);
        table.AddRowsValue({"cluster_role:", gaiadb::ClusterRole_Name(rsp.topology().cluster_role()).c_str()});
        table.Display();
    }
    {
        if (rsp.topology().segments_size()) {
            for (auto& seg_pb : rsp.topology().segments()) {
                Table seg_table(_raw_with_table, 0);
                seg_table.AddRowsWithName({"segment_id", "replica_id", "state", "addr", "zone"});
                for (auto& replica_pb : seg_pb.page_servers()) {
                    seg_table.AddRowsValue({
                            seg_pb.segment_id(),
                            replica_pb.replica_id(),
                            gaiadb::NodeState_Name(replica_pb.state()),
                            replica_pb.addr(),
                            GetZoneStrWithName(replica_pb)
                            });
                }
                seg_table.Display();
            }
        }
        if (rsp.topology().log_services_size()) {
            Table ls_table(_raw_with_table, 0);
            ls_table.AddRowsWithName({"log_service", "state", "zone"});
            for (auto& ls_pb : rsp.topology().log_services()) {
                ls_table.AddRowsValue({
                        ls_pb.addr(),
                        gaiadb::NodeState_Name(ls_pb.state()),
                        GetZoneStrWithName(ls_pb)
                        });
            }
            ls_table.Display();
        }
        if (rsp.topology().compute_nodes_size()) {
            Table cp_table(_raw_with_table, 0);
            cp_table.AddRowsWithName({"compute", "state", "is_primary", "zone"});
            for (auto& cp_pb : rsp.topology().compute_nodes()) {
                cp_table.AddRowsValue({
                        cp_pb.addr(),
                        gaiadb::NodeState_Name(cp_pb.state()),
                        cp_pb.is_primary() ? "yes" : "no",
                        GetZoneStrWithName(cp_pb)
                        });
            }
            cp_table.Display();
        }
        if (rsp.topology().standby_clusters_size()) {
            Table st_table(_raw_with_table, 0);
            st_table.AddRowsWithName({"standby", "state"});
            for (auto& standby_pb : rsp.topology().standby_clusters()) {
                st_table.AddRowsValue({
                        standby_pb.cluster_id(),
                        gaiadb::NodeState_Name(standby_pb.state())
                        });
            }
            st_table.Display();
        }
        if (rsp.topology().replicators_size()) {
            Table rpl_table(_raw_with_table, 0);
            rpl_table.AddRowsWithName({"replicator", "state", "zone"});
            for (auto& replicator_pb : rsp.topology().replicators()) {
                rpl_table.AddRowsValue({
                        replicator_pb.addr(),
                        gaiadb::NodeState_Name(replicator_pb.state()),
                        GetZoneStrWithName(replicator_pb)
                        });
            }
            rpl_table.Display();
        }
    }
    return 0;
}

}
}
