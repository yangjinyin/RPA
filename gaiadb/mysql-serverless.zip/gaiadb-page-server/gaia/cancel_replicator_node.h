/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/cancel_replicator_node.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class CancelReplicatorNode : public Command {
public:
    CancelReplicatorNode() {
        SetName("cancel-replicator-node");
        SetDesc("cancel an existing replicator node");
        SetDescCn("注销已有的复制服务节点");

        AddPsmClusterOption();
        AddRequiredArgOption("addr", &_long_opt_val, kOptMax + 1, "the replicator endpoint", kip_port);
        AddRequiredArgOption("epoch", &_long_opt_val, kOptMax + 2,
                "only cancel the matching epoch node, if specified",
                kuint64_t, kGroup2Scope);
        
        AddExample("--manager-address \"bns://xxx\" --addr 127.0.0.1:1999");
        AddExample("--manager-address \"bns://xxx\" --addr 127.0.0.1:1999 --epoch 1");
    }
    virtual ~CancelReplicatorNode() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _addr = opt;
                break;
            case kOptMax + 2:
                _epoch = std::strtoull(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::UpdateReplicationResponse& rsp);

private:
    std::string _manager_address {};
    std::string _addr {};
    uint64_t _epoch {0};
};

}
}
