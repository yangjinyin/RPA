/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/parse_log_block_buf.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ParseLogBlockBuf : public Command {
public:
    ParseLogBlockBuf() : Command(true) {
        SetName("parse-log-block-buf");
        SetDesc("parse log block buf to records and apply records to page");
        SetDescCn("解析日志块数据为记录并应用到页面");

        AddRequiredArgOption("buf-file", &_long_opt_val, kOptMax + 1, "buf file path name", kstring, kGroup1Scope);

        AddNodeOption(kGroup2Scope);
        AddRequiredArgOption("segment-id", NULL, 's', "get log by segment id", kuint32_t, kGroup2Scope);
        AddRequiredArgOption("fetch-lsn", &_long_opt_val, kOptMax + 2, "get log start lsn", kuint64_t, kGroup2Scope);

        AddRequiredArgOption("buf-json-file", &_long_opt_val,
                kOptMax + 3, "get log from json file",
                kstring, kGroup3Scope);

        AddRequiredArgOption("page-file", &_long_opt_val,
                kOptMax + 4, "apply records to this page",
                kstring, kGroup4Scope);
        AddNoArgOption("update-page-file", &_long_opt_val,
                kOptMax + 5, "save apply records to page file",
                kGroup4Scope);

        AddExample("--buf-file xx");
        AddExample("--buf-file xx --buf-json-file json_file");
        AddExample("--buf-file xx -a ip -p port --segment-id x --fetch-lsn lsn");
        AddExample("--buf-file xx -a ip -p port --segment-id x "
                "--fetch-lsn lsn --page-file page_file --update-page-file");
    }
    virtual ~ParseLogBlockBuf() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _ls_addr = opt;
            break;
        case 'p':
            _ls_port = std::strtol(opt, NULL, 10);
            break;
        case 's':
            _segment_id = std::strtoul(opt, NULL, 10);
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _buf_file = opt;
                break;
            case kOptMax + 2:
                _fetch_lsn = std::strtoull(opt, NULL, 10);
                break;
            case kOptMax + 3:
                _buf_json_file = opt;
                break;
            case kOptMax + 4:
                _page_file = opt;
                break;
            case kOptMax + 5:
                _page_file_update = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    std::string _buf_file {};
    std::string _buf_json_file {};
    std::string _ls_addr {};
    int32_t _ls_port {0};
    uint32_t _segment_id {0};
    uint64_t _fetch_lsn {0};
    std::string _page_file {};
    bool _page_file_update {false};
};

}
}
