/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_takeover_compute_node.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class GetTakeOverComputeNode : public Command {
public:
    GetTakeOverComputeNode() {
        SetName("get-takeover-compute-node");
        SetDesc("get takeover status from secondary compute node");
        SetDescCn("获取从计算节点的热切状态");
        
        AddNodeOption();
        AddRequiredArgOption("task-id", &_long_opt_val, kOptMax + 1, "task name", kstring);
        
        AddExample("-a <ip> -p <port> --task-id x");
    }
    virtual ~GetTakeOverComputeNode() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _task_id = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const computenode::takeover_status_response& rsp);

private:
    std::string _address {};
    int32_t _port {-1};
    std::string _task_id {};
};

}
}
