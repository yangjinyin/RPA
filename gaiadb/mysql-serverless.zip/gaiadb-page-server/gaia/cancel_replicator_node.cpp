/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/cancel_replicator_node.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/cancel_replicator_node.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int CancelReplicatorNode::Run() {
    RpcStatus status;
    gaiapb::UpdateReplicationRequest request;
    gaiapb::UpdateReplicationResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_addr.empty()) {
        print_error("miss --addr");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_force) {
        bool cf_ret = _epoch ?
            execute_confirm("Cancel addr:%s epoch:%lu node?", _addr.c_str(), _epoch) :
            execute_confirm("Cancel addr:%s all epoch nodes?", _addr.c_str());
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    auto node_pb = request.add_cancel_nodes();
    node_pb->set_addr(_addr);
    if (_epoch) {
        node_pb->set_epoch(_epoch);
    }
    request.set_log_id(_log_id);
    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::cancel_replicator_node, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " cancel replicator failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("cancel replicator failed, all nodes failed");
    return Output(response);
}

int CancelReplicatorNode::Format(const gaiapb::UpdateReplicationResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
