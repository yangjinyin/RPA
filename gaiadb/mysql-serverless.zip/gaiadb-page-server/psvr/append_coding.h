/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/append_coding.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/common.h"
#include <base/slice.h>
#include <base/sys_byteorder.h>

namespace psvr {
namespace coding {

#if defined(ARCH_CPU_LITTLE_ENDIAN)
static constexpr bool kLittleEndian = true;
#else
static constexpr bool kLittleEndian = false;
#endif

static_assert(kLittleEndian);

inline void Encode32(char* buf, uint32_t value) {
    if (kLittleEndian) {
        memcpy(buf, &value, sizeof(value));
    } else {
        buf[0] = value & 0xff;
        buf[1] = (value >> 8) & 0xff;
        buf[2] = (value >> 16) & 0xff;
        buf[3] = (value >> 24) & 0xff;
    }
}

inline uint32_t Decode32(const char* ptr) {
    if (kLittleEndian) {
        uint32_t value;
        memcpy(&value, ptr, sizeof(value));
        return value;
    } else {
        return ((static_cast<uint32_t>(static_cast<unsigned char>(ptr[0]))) |
                (static_cast<uint32_t>(static_cast<unsigned char>(ptr[1])) << 8) |
                (static_cast<uint32_t>(static_cast<unsigned char>(ptr[2])) << 16) |
                (static_cast<uint32_t>(static_cast<unsigned char>(ptr[3])) << 24));
    }
}

inline void Encode64(char* buf, uint64_t value) {
    if (kLittleEndian) {
        memcpy(buf, &value, sizeof(value));
    } else {
        buf[0] = value & 0xff;
        buf[1] = (value >> 8) & 0xff;
        buf[2] = (value >> 16) & 0xff;
        buf[3] = (value >> 24) & 0xff;
        buf[4] = (value >> 32) & 0xff;
        buf[5] = (value >> 40) & 0xff;
        buf[6] = (value >> 48) & 0xff;
        buf[7] = (value >> 56) & 0xff;
    }
}

inline uint64_t Decode64(const char* ptr) {
    if (kLittleEndian) {
        uint64_t value;
        memcpy(&value, ptr, sizeof(value));
        return value;
    } else {
        uint64_t lo = Decode32(ptr);
        uint64_t hi = Decode32(ptr + 4);
        return (hi << 32) | lo;
    }
}

inline void Append32(std::string* dst, uint32_t value) {
    char buf[sizeof(value)];
    Encode32(buf, value);
    dst->append(buf, sizeof(buf));
}

inline void Append64(std::string* dst, uint64_t value) {
    char buf[sizeof(value)];
    Encode32(buf, value);
    dst->append(buf, sizeof(buf));
}

inline bool Get32(base::Slice* input, uint32_t* value) {
    if (input->size() < sizeof(*value)) {
        return false;
    }
    *value = Decode32(input->data());
    input->remove_prefix(sizeof(*value));
    return true;
}

inline bool Get64(base::Slice* input, uint64_t* value) {
    if (input->size() < sizeof(*value)) {
        return false;
    }
    *value = Decode64(input->data());
    input->remove_prefix(sizeof(*value));
    return true;
}

}
}
