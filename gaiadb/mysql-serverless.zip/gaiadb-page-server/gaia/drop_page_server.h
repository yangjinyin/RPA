/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/drop_page_server.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class DropPageServer : public Command {
public:
    DropPageServer() {
        SetName("drop-page-server");
        SetDesc("drop page server from manager");
        SetDescCn("从管理服务中删除存储节点");
        
        AddPsmClusterOption();
        AddRequiredArgOption("addr", &_long_opt_val, kOptMax + 1, "the page server address", kip_port);
        AddNoArgOption("ignore-fail", &_long_opt_val, kOptMax + 2, "ignore if can not be deleted");

        AddExample("--manager-address \"bns://xxx\" --addr <ip:port>");
        AddExample("--manager-address \"bns://xxx\" --addr <ip:port> --ignore-fail");
    }
    virtual ~DropPageServer() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _addr = opt;
                break;
            case kOptMax + 2:
                _ignore_fail = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::DropPageServerResponse& rsp);

private:
    std::string _manager_address {};
    std::string _addr {};
    bool _ignore_fail {false};
};

}
}
