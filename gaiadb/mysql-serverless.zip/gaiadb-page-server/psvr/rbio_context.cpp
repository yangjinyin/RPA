/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/rbio_context.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <bthread/task_group.h>
#include "psvr/config.h"
#include "psvr/page_op.h"
#include "psvr/rbio_context.h"

namespace psvr {

std::ostream& operator<<(std::ostream& os, RbioManager::Context* ctx) {
    if (ctx) {
        return os << "idx:[" << ctx->idx
            << "] space:[" << ctx->space_id
            << "] page:[" << ctx->logical_page_no
            << "] vlsn:[" << ctx->vlsn
            << "] lowest_lsn:[" << ctx->lowest_lsn
            << "] size:[" << ctx->size
            << "] logid:[" << ctx->log_id
            << "] role:[" << ctx->task->role
            << "] read_rule:[" << pspb::RbioRequest::VersionRule_Name(ctx->task->read_rule)
            << "] peer_read:[" << ctx->task->is_peer_read
            << "]";
    }
    return os;
}

void RbioManager::Context::Init(RbioManager::Action _action, uint64_t _log_id, uint32_t _idx,
        const pspb::RbioRequest_RequestInfo* req,
        pspb::RbioResponse_ResponseInfo* rsp, int64_t begin_time) {
    log_id = _log_id;
    action = _action;
    idx = _idx;
    space_id = req->tablespaceid();
    logical_page_no = req->logicalpageno();
    vlsn = req->vlsn();
    real_apply_lsn = req->vlsn();
    size = req->ziplen();
    if (req->has_lowest_lsn()) {
        lowest_lsn = req->lowest_lsn();
    }
    read_rsp = rsp;

    stat_timer.reset(begin_time);
    TP_INIT_IF(tp, FLAGS_psvr_enable_rbio_annotate);
}

void RbioManager::Context::Init(RbioManager::Action _action, uint64_t _log_id, uint32_t _idx,
        const pspb::WritePageRequest_RequestInfo* req, int64_t begin_time) {
    log_id = _log_id;
    idx = _idx;
    action = _action;
    space_id = req->space_id();
    logical_page_no = req->page_no();
    vlsn = 0;
    real_apply_lsn = 0;
    size = req->ziplen();
    write_req = req;

    stat_timer.reset(begin_time);
    TP_INIT_IF(tp, FLAGS_psvr_enable_rbio_annotate);
}

bool RbioManager::Context::Finish(pspb::WritePageResponse_Error code, bool* is_ok) {
    if (code == pspb::WritePageResponse::SUCCESS) {
        *is_ok = true;
        ADD_TRACE_TP(tp, "ok");
    } else {
        auto write_ctx = dynamic_cast<WriteTask*>(task);
        write_ctx->last_error_code.store(code);
        ADD_TRACE_TP(tp, "fail");
    }

    SegmentPtr segment = task->segment.lock();
    if (segment && FLAGS_psvr_rbio_long_write_page_us > 0
            && TP_ELAPSED(tp, FLAGS_psvr_rbio_long_write_page_us)) {
        LOG_EVERY_SECOND(NOTICE) << segment << " write page slow request, " << this << tp;
    }
    TP_DESTROY(tp);

    return task->finish_count.fetch_add(1, std::memory_order_relaxed) + 1 == task->req_count;
}

bool RbioManager::Context::Finish(RbioError code, bool* is_ok) {
    SegmentPtr segment = task->segment.lock();
    if (code == pspb::RbioResponse::RBIO_SUCCESS) {
        *is_ok = true;
        read_rsp->set_tablespaceid(space_id);
        read_rsp->set_logicalpageno(logical_page_no);
        read_rsp->set_vlsn(real_apply_lsn);
        if (!task->enable_attachment_type) {
            read_rsp->set_pageframe(buf_block->frame, size);
            uint64_t page_lsn = buf_block_get_page_lsn(buf_block);
            if (segment && !task->is_peer_read && (page_lsn > real_apply_lsn || page_lsn > vlsn)) {
                LOG(ERROR) << segment << " rbio page_lsn invalid, "
                    << this
                    << " vlsn:[" << vlsn
                    << "] real_apply_lsn:[" << real_apply_lsn
                    << "] page_lsn:[" << buf_block_get_page_lsn(buf_block)
                    << "]";
            }
        }
        if (task->read_rule != pspb::RbioRequest::LE) {
            PSVR_ASSERT(real_apply_lsn >= vlsn);
        }
        read_rsp->set_checkcrc(true);
        ADD_TRACE_TP(tp, "ok");
    } else {
        auto read_ctx = dynamic_cast<ReadTask*>(task);
        read_ctx->last_error_code.store(code);
        ADD_TRACE_TP(tp, "fail");
    }

    apply_end_time = base::cpuwide_time_us();

    if (segment && FLAGS_psvr_rbio_long_query_time_us > 0
            && TP_ELAPSED(tp, FLAGS_psvr_rbio_long_query_time_us)) {
        LOG(NOTICE) << segment << " slow rbio request, " << this << tp;
    }
    TP_DESTROY(tp);

    const int64_t start_time = stat_timer.start_time();
    const int64_t all_cost = stat_timer.u_elapsed();
    read_rsp->set_diff_ls_dispatch_lsn(vlsn_diff_ls_dispatch_lsn);
    read_rsp->add_detail_time_cost(start_time);
    read_rsp->add_detail_time_cost(all_cost);//all_cost
    if (fetch_begin_time >= start_time) {
        read_rsp->add_detail_time_cost(fetch_begin_time - start_time);//init
        if (fetch_end_time >= fetch_begin_time) {
            read_rsp->add_detail_time_cost(fetch_end_time - fetch_begin_time);//fetch
            if (parse_end_time >= fetch_end_time) {
                read_rsp->add_detail_time_cost(parse_end_time - fetch_end_time);//parse
                if (apply_end_time >= parse_end_time) {
                    read_rsp->add_detail_time_cost(apply_end_time - parse_end_time);//apply
                }
            }
        }
    }
    //print slow rbio detail info
    if (segment && FLAGS_psvr_rbio_long_query_time_print_detail_us > 0
            && all_cost >= FLAGS_psvr_rbio_long_query_time_print_detail_us) {
        LOG(NOTICE) << segment << " slow rbio latency, " << this
            << " retry_times:[" << retry_times
            << "] cost_us:[" << all_cost
            << "] init_us:[" << fetch_begin_time - start_time
            << "] fetch_us:[" << fetch_end_time - fetch_begin_time
            << "] parse_us:[" << parse_end_time - fetch_end_time
            << "] apply_us:[" << apply_end_time - parse_end_time
            << "] fetch_retry_times:[" << fetch_lsn_retry_times
            << "] secondary_fetch_diff_fetch:[" << secondary_fetch_diff_fetch
            << "] secondary_fetch_diff_parse:[" << secondary_fetch_diff_parse
            << "] secondary_ls_dispatch_lsn_diff_fetch:[" << secondary_ls_dispatch_diff_fetch
            << "] secondary_ls_dispatch_lsn_diff_parse:[" << secondary_ls_dispatch_diff_parse
            << "] vlsn_diff_fetch:[" << vlsn_diff_fetch
            << "] vlsn_diff_ls_dispatch_lsn:[" << vlsn_diff_ls_dispatch_lsn
            << "] vlsn_diff_fetch_retry40:[" << vlsn_diff_fetch_after_retry_xx[0]
            << "] vlsn_diff_fetch_retry80:[" << vlsn_diff_fetch_after_retry_xx[1]
            << "] vlsn_diff_fetch_retry120:[" << vlsn_diff_fetch_after_retry_xx[2]
            << "] vlsn_diff_fetch_retry160:[" << vlsn_diff_fetch_after_retry_xx[3]
            << "] vlsn_diff_ls_dispatch_lsn_retry40:[" << vlsn_diff_ls_dispatch_lsn_after_retry_xx[0]
            << "] vlsn_diff_ls_dispatch_lsn_retry80:[" << vlsn_diff_ls_dispatch_lsn_after_retry_xx[1]
            << "] vlsn_diff_ls_dispatch_lsn_retry120:[" << vlsn_diff_ls_dispatch_lsn_after_retry_xx[2]
            << "] vlsn_diff_ls_dispatch_lsn_retry160:[" << vlsn_diff_ls_dispatch_lsn_after_retry_xx[3]
            << "]";
    }

    return task->finish_count.fetch_add(1, std::memory_order_relaxed) + 1 == task->req_count;
}

RbioManager::Task::Task(SegmentPtr _segment, uint32_t req_nr)
        : segment(_segment),
        is_peer_read(false),
        read_rule(pspb::RbioRequest::EQ),
        segment_in_recovery(_segment->in_recovery()),
        role(RBIO_OTHER),
        req_has_physical_extent_id(false),
        req_physical_extent_id(gaia_apply::FIL_NULL),
        enable_attachment_type(false),
        secondary_fetch_lsn(0),
        secondary_ls_dispatch_lsn(0),
        quota_store_id(-1),
        req_count(req_nr),
        finish_count(0),
        reqs() {
    for (uint32_t i = 0; i < req_nr; ++i) {
        reqs[i] = new Context(this);
    }
}

RbioManager::Task::~Task() {
    for (uint32_t i = 0; i < req_count; ++i) {
        delete reqs[i];
        reqs[i] = nullptr;
    }
}

bool RbioManager::ReadTask::Init(int64_t begin_time) {
    if (request->has_max_error_code()) {
        max_error_code = request->max_error_code();
    }

    SegmentPtr seg = segment.lock();
    if (!seg) {
        last_error_code = pspb::RbioResponse::RBIO_SEGMENT_NOT_EXIST;
        return false;
    }
    const gaia_apply::lsn_t parsed_lsn = seg->parse_lsn();

    response->set_requestid(request->requestid());
    response->set_parsed_lsn(parsed_lsn);
    response->set_valid_empty(seg->recovery_status_is_finish());
    response->set_lowest_gc_lsn(true);
    response->mutable_resvec()->Clear();    // maybe reuse response ?

    is_peer_read = request->has_peerread() ? request->peerread() : false;
    if (request->has_version_rule()) {
        read_rule = request->version_rule();
    }

    if (request->has_is_primary()) {
        role = request->is_primary() ? RBIO_PRIMARY : RBIO_SECONDARY;
    } else {
        role = RBIO_OTHER;  // peer read
    }

    req_has_physical_extent_id = request->has_physical_extent_id();
    if (req_has_physical_extent_id) {
        req_physical_extent_id = request->physical_extent_id();
    }

    if (cntl && request->has_enable_attachment_type()) {
        enable_attachment_type = request->enable_attachment_type();
    }

    if (request->has_fetch_lsn()) {
        secondary_fetch_lsn = request->fetch_lsn();
        secondary_ls_dispatch_lsn = request->ls_dispatch_lsn();
    }

    const auto req_id = request->requestid();
    const uint64_t max_vlsn = request->reqvec(0).vlsn();
    if (rbio_req_need_wait_lsn(read_rule, max_vlsn, parsed_lsn)) {
        wait_lsn = true;
        LOG(TRACE) << seg << " req vlsn > parsed";
        if (parsed_lsn + FLAGS_psvr_segment_fetch_max_buf_size < max_vlsn) {
            LOG_EVERY_SECOND(WARNING) << seg << " rbio failed, req vlsn > parsed,"
                << " req_id:[" << req_id
                << "] is_peer_read:[" << is_peer_read
                << "] parsed_lsn:[" << parsed_lsn
                << "] vlsn:[" << max_vlsn
                << "]";
            last_error_code = pspb::RbioResponse::RBIO_LSN_WAIT;
            return false;
        }
    }

    for (uint32_t i = 0; i < req_count; ++i) {
        const auto* req_info = &request->reqvec(i);
        auto* rsp_info = response->add_resvec();
        reqs[i]->Init(wait_lsn ? Action::kWaitLsn : Action::kRbio,
                req_id, i, req_info, rsp_info, begin_time);
    }

    stat_timer.reset(begin_time);
    return true;
}

void RbioManager::WriteTask::Init(int64_t begin_time) {
    req_has_physical_extent_id = request->has_physical_extent_id();
    if (req_has_physical_extent_id) {
        req_physical_extent_id = request->physical_extent_id();
    }
    const auto req_id = request->request_id();
    for (uint32_t i = 0; i < req_count; ++i) {
        const auto* req_info = &request->requestvec(i);
        reqs[i]->Init(Action::kPrepare, req_id, i, req_info, begin_time);
    }
    stat_timer.reset(begin_time);
}

}
