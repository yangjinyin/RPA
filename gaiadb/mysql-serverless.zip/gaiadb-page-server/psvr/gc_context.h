/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/gc_context.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/context_types.h"
#include "psvr/log_block.h"
#include "psvr/gc.h"
#include "psvr/segment.h"

namespace psvr {

struct ParallelTask {
    int64_t start_time;
    bool in_prior_thread;

    ParallelTask() : in_prior_thread(false) {
        start_time = base::cpuwide_time_us();
    }

    int64_t latency_us() const { return base::cpuwide_time_us() - start_time; }
};

struct GcManager::ConditionTask {
    Context* ctx;
    ClusterWeakPtr cluster;
    gaia_apply::lsn_t min_lsn;
    gaia_apply::lsn_t max_lsn;
    bool has_data;
    int32_t retry_nr;
    int64_t wait_start_time;

    ConditionTask(Context* _ctx,
        ClusterPtr _cluster,
        gaia_apply::lsn_t _min_lsn,
        gaia_apply::lsn_t _max_lsn,
        bool _has_data,
        int64_t start_time)
        : ctx(_ctx),
        cluster(_cluster),
        min_lsn(_min_lsn),
        max_lsn(_max_lsn),
        has_data(_has_data),
        retry_nr(0),
        wait_start_time(start_time) {}
    ConditionTask(const ConditionTask& lhs)
        : ctx(lhs.ctx),
        cluster(lhs.cluster),
        min_lsn(lhs.min_lsn),
        max_lsn(lhs.max_lsn),
        has_data(lhs.has_data),
        retry_nr(lhs.retry_nr),
        wait_start_time(lhs.wait_start_time) {}

    operator bool();
};

struct GcManager::ConditionGcQueue : public ConditionQueue<ConditionTask, ConditionGcQueue> {
    ConditionGcQueue() {}
    ~ConditionGcQueue() {}

    void Push(const ConditionTask& task);
    void PopIf(Fn& fn);
    void Clear(Fn& fn);

private:
    std::list<ConditionTask> _tasks;
    std::mutex _mutex;
};

struct GcManager::Context : public thread::TaskContext {
    Action action;
    SegmentWeakPtr segment {};
    LogBlockPtr log_block {nullptr};
    LogBlockPtr merge_head {nullptr};
    uint64_t merge_size {0};
    size_t thread_pool_idx {0};
    // for gc space page
    gaia_apply::space_id_t space_id {gaia_apply::SPACE_UNKNOWN};
    gaia_apply::page_no_t page_no {gaia_apply::FIL_NULL};
    uint64_t page_physical_offset {gaia_apply::ULINT_UNDEFINED};
    // for event
    pspb::Status st;
    // for delay
    uint32_t retry_times {0};
    int32_t delay_times {0};
    // for recovery
    std::unique_ptr<ReadPeerPageContext> read_peer_page_ctx {nullptr};
    //
    int32_t parallel_idx {0};
    std::atomic<size_t> get_meta_reqs_count {0};
    // for stat
    int32_t rw_times {0};
    int32_t interrupt_times {0};
    int32_t cond_retry_times {0};
    int32_t gc_times {0};
    int32_t recover_times {0};

    Timer stat_timer;
    TimePoint* tp {nullptr};
    std::shared_ptr<ParallelTask> parallel_task {nullptr};

    Context(Action _action, SegmentPtr _segment)
        : Context(_action, _segment, nullptr) {}
    Context(Action _action, SegmentPtr _segment, LogBlockPtr _log_block)
        : thread::TaskContext(CtxType::kGc),
        action(_action), segment(_segment), log_block(_log_block) {}
    virtual ~Context() { TP_DESTROY(tp); }
};


}
