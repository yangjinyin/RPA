/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/ignore_page_server_gc_space.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class IgnorePageServerGcSpace : public Command {
public:
    IgnorePageServerGcSpace() {
        SetName("ignore-ps-gc-space");
        SetDesc("select/add/remove/clear ignore gc spaces on page server");
        SetDescCn("查询/添加/移除/清除存储服务器上的 GC 忽略的表空间信息");

        AddNodeOption();
        AddRequiredArgOption("space-id", &_long_opt_val, kOptMax + 1, "space id", kint32_t);
        AddRequiredArgOption("op", &_long_opt_val, kOptMax + 2,
                "operator type, enum in select/add/remove/clear", kenum);
        AddRequiredArgOption("cluster-id", nullptr, 'c', "target cluster id", kstring);
        AddRequiredArgOption("segment-id", nullptr, 's',
                "segment id to operation, omit to operate all segments", kstring);

        AddExample("-a <ip> -p <port> -op <add/remove> --cluster-id xx --space-id 1 --space-id 2");
        AddExample("-a <ip> -p <port> -op <add/remove> --cluster-id xx --segment-id xx --space-id 1 --space-id 2");
        AddExample("-a <ip> -p <port> -op clear --cluster-id xx --segment-id xx");
        AddExample("-a <ip> -p <port> -op select --cluster-id xx --segment-id xx");
    }
    virtual ~IgnorePageServerGcSpace() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtoul(opt, NULL, 10));
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _space_ids.emplace(std::strtoul(opt, NULL, 10));
                break;
            case kOptMax + 2:
                _op = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;
private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::IgnoreSpaceRecordsResponse& rsp);

private:
    std::string _op {};
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
    std::set<uint32_t> _space_ids {};
    brpc::Controller _cntl;
};

}
}
