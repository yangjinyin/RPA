/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/create_page_server_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class CreatePageServerSegment : public Command {
public:
    CreatePageServerSegment() {
        SetName("create-ps-segment");
        SetDesc("create a segment replica on page server");
        SetDescCn("在存储服务器上创建分片副本");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "cluster id of the segment to create/load", kstring);
        AddRequiredArgOption("segment-id", NULL, 's', "id of the segment to create/load", kuint32_t);
        AddRequiredArgOption("manager-address", NULL, 'M',
                "manager address of the segment to create/load", kstring);
        AddRequiredArgOption("size", &_long_opt_val, kOptMax + 2, "size of the segment to create/load", kint64_t);

        AddRequiredArgOption("store-id", &_long_opt_val, kOptMax + 3,
                "the segment will be created on this store, if specified",
                kuint32_t, kGroup2Scope);

        AddRequiredArgOption("rebalance-from", &_long_opt_val, kOptMax + 4,
                "rebalance replica node", kip_port, kGroup3Scope);
        AddRequiredArgOption("rebalance-version", &_long_opt_val, kOptMax + 5,
                "rebalance replica version", kuint64_t, kGroup3Scope);

        AddExample("-a <ip> -p <port> -c gaia-test-perf -s 1 --manager-address \"bns://xxx\" --size 42949672960");
        AddExample("-a <ip> -p <port> -c gaia-test-perf -s 1"
                " --manager-address \"bns://xxx\" --size 42949672960"
                " --store-id 1");
        AddExample("-a <ip> -p <port> -c gaia-test-perf -s 1"
                " --manager-address \"bns://xxx\" --size 42949672960"
                " --store-id 1 --rebalance-from <ip:port>"
                " --rebalance-version <v>");
    }
    virtual ~CreatePageServerSegment() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id = std::strtoul(opt, NULL, 10);
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 2:
                _size = std::strtoll(opt, NULL, 10);
                break;
            case kOptMax + 3:
                _store_id = std::strtol(opt, NULL, 10);
                break;
            case kOptMax + 4:
                _rebalance_from = opt;
                break;
            case kOptMax + 5:
                _rebalance_version = std::strtol(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::CreateSegmentResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    uint32_t _segment_id {0};
    std::string _manager_address {};
    int64_t _size {-1};
    int32_t _store_id {-1};
    std::string _rebalance_from;
    uint64_t _rebalance_version;
};

}
}
