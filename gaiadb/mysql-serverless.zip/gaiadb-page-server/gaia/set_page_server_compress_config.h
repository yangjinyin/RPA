/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_page_server_compress_config.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class SetPageServerCompressConfig : public Command {
public:
    SetPageServerCompressConfig() {
        SetName("set-ps-compress-config");
        SetDesc("set cluster or segment compress config to page server");
        SetDescCn("设置存储服务器上集群或分片的压缩配置");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c', "query all segments cluster in server", kstring);
        AddRequiredArgOption("segment-id", NULL, 's', "only query this id of cluster in server", kint32_t);
        AddRequiredArgOption("cfg-enable", &_long_opt_val, kOptMax + 1, "enable or disable compression", kenum);
        AddRequiredArgOption("cfg-type", &_long_opt_val, kOptMax + 2, "name of compression algorithm", kenum);
        AddRequiredArgOption("cfg-level", &_long_opt_val, kOptMax + 3, "level of compression algorithm", kint32_t);
        
        AddExample("-a <ip> -p <port> --cluster-id <cluster_id> --cfg-enable 0");
        AddExample("-a <ip> -p <port> --cluster-id <cluster_id> --segment-id <segment_id> --cfg-enable 0");
        AddExample("-a <ip> -p <port> --cluster-id <cluster_id>"
                " --cfg-enable 1 --cfg-type \"<type>\" --cfg-level <level>");
        AddExample("-a <ip> -p <port> --cluster-id <cluster_id>"
                " --segment-id <segment_id> --cfg-enable 1"
                " --cfg-type \"<type>\" --cfg-level <level>");
    }
    virtual ~SetPageServerCompressConfig() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtol(opt, NULL, 10));
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _enable.Set(!!std::strtoull(opt, NULL, 10));
                break;
            case kOptMax + 2:
                _type = opt;
                break;
            case kOptMax + 3:
                _level = std::strtol(opt, NULL, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::SetCompressConfigResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
    // compress cfg
    VarOptional<bool> _enable;
    std::string _type {"none"};
    int32_t _level {-1};
};

}
}
