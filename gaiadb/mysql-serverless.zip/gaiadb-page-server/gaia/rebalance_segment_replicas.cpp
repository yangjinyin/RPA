/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/rebalance_segment_replicas.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/rebalance_segment_replicas.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

void RebalanceSegmentReplicas::OnGetServerStatus(std::shared_ptr<Server> server) {
    // 2.1.1) if RPC succ, init Server.
    if (server->rpc_status.IsOk()
            && server->rpc_response.status().code() == pspb::Status::SUCCESS) {
        server->InitServerStatus();
        _server_manager.task_count.fetch_sub(1);
        return;
    }

    // 2.1.2) if RPC fail, retry it.
    LOG(WARNING) << "get page server status RPC fail,"
        << " log_id:[" << _log_id
        << "] addr:[" << server->addr
        << "] rpc_st:[" << server->rpc_status
        << "] rsp_st:[" << server->rpc_response.status()
        << "]";
    if (++server->rpc_retry_times > 3 || _stopped) {
        _server_manager.task_count.fetch_sub(1);
        return;
    }
    // 2.1.2.1) async RPC retry agian
    auto closure = brpc::NewCallback(this, &RebalanceSegmentReplicas::OnGetServerStatus, server);
    _client.Call(_log_id, server->addr, &pspb::QueryService_Stub::MultiGetServerStatus,
            &server->rpc_request, &server->rpc_response, closure, &server->rpc_status, _timeout_ms);
}

bool RebalanceSegmentReplicas::GetPageServerReplicasAndStores() {
    // 2.1) send async RPC to all page server nodes
    for (auto& it : _server_manager.server_map) {
        std::shared_ptr<Server> server = it.second;
        server->rpc_request.set_log_id(_log_id);
        server->rpc_request.set_get_store_info(true);
        auto closure = brpc::NewCallback(this, &RebalanceSegmentReplicas::OnGetServerStatus, server);
        _client.Call(_log_id, server->addr, &pspb::QueryService_Stub::MultiGetServerStatus,
                &server->rpc_request, &server->rpc_response, closure, &server->rpc_status, _timeout_ms);
    }

    // 2.2) wait all async RPC done
    while (!_stopped) {
        if (_server_manager.task_count.load(std::memory_order_acquire) == 0) {
            break;
        } else {
            gaiadb::common::pause();    // x86
        }
    }

    if (_stopped) {
        LOG(WARNING) << "quit by stop signal, "
            << " log_id:[" << _log_id
            << "]";
        return false;
    }

    // 2.3) check all RPC responses are succ.
    for (auto& it : _server_manager.server_map) {
        std::shared_ptr<Server> server = it.second;
        if (!server->rpc_ok) {
            LOG(WARNING) << "server RPC failed,"
            << " log_id:[" << _log_id
            << "] addr:[" << server->addr
            << "]";
            return false;
        }
        LOG_IF(NOTICE, _debug) << "show server status,"
            << " log_id:[" << _log_id
            << "] addr:[" << server->addr
            << "] zone:[" << server->zone
            << "] replica_count:[" << server->replica_count
            << "] disk_count:[" << server->disk_map.size()
            << "] is_offline:[" << server->is_offline
            << "]";
    }
    return true;
}

int RebalanceSegmentReplicas::StartRebalanceReplicas(pspb::GaiaReblanceSegments& rebalance_replicas) {
    // 4.1) define disk groups:
    // inflation_disks -> rebalance replica from it
    // deflation_disks -> rebalance replica to it
    // normal_disks -> no need to move replica when rebalance disk type
    std::vector<std::shared_ptr<Disk>> inflation_disks;
    std::vector<std::shared_ptr<Disk>> deflation_disks;
    std::vector<std::shared_ptr<Disk>> normal_disks;

    bool has_offline = false;

    // 4.2) iterate over all server disks
    // - count disk number
    // - push disk to `all_disks`
    // - sum disk size used rate
    std::vector<std::shared_ptr<Disk>> all_disks;
    int64_t all_disks_num = 0;
    int64_t all_disks_used_thousandth_count = 0;
    all_disks.reserve(128 * 8);
    for (auto it : _server_manager.server_map) {
        auto server = it.second;
        for (auto it2 : server->disk_map) {
            auto disk = it2.second;
            if (disk->is_active) {
                if (server->is_offline) {
                    if (disk->cluster_replica_map.empty()) {
                        LOG_IF(NOTICE, _debug) << "ignore offline server disk without replicas,"
                            << " log_id:[" << _log_id
                            << "] disk:[" << disk
                            << "]";
                        continue;
                    }
                    has_offline = true;
                    inflation_disks.emplace_back(disk);
                    LOG_IF(NOTICE, _debug) << "add offline server disk to inflation group,"
                        << " log_id:[" << _log_id
                        << "] disk:[" << disk
                        << "]";
                    continue;
                }
                all_disks.emplace_back(disk);
                ++all_disks_num;
                all_disks_used_thousandth_count += disk->used_thousandth;
            } else {
                LOG_IF(NOTICE, _debug) << "disk is not active, disk:[" << disk << "]";
            }
        }
        if (_stopped) {
            LOG(WARNING) << "quit by stop signal, "
                << " log_id:[" << _log_id
                << "]";
            return -1;
        }
    }

    if (all_disks_num == 0) {
        LOG(WARNING) << "no active disk, "
            << " log_id:[" << _log_id
            << "]";
        return -1;
    }

    // 4.3) sort disk by size used rate DESC
    std::sort(all_disks.begin(), all_disks.end(),
            [](std::shared_ptr<Disk> lhs, std::shared_ptr<Disk> rhs) {
                return lhs->used_thousandth > rhs->used_thousandth;
            });
    if (_debug) {
        LOG(NOTICE) << "show the sorted disks,"
                << " log_id:[" << _log_id
                << "] count:[" << all_disks.size()
                << "]";
        for (auto& disk : all_disks) {
            LOG(NOTICE) << " log_id:[" << _log_id
                << "] disk:[" << disk
                << "]";
        }
    }

    // 4.4) calculate disk avg used rate
    // - inflation: if disk used rate more than it, move to inflation_disks group
    // - deflation: if disk used rate lower than it, move to deflation_disks group
    // - deflation: other disk
    const int64_t avg_disk_used_thousandth = all_disks_used_thousandth_count / all_disks_num;
    const int64_t inflation_disk_used_thousandth = avg_disk_used_thousandth + _disk_floating_rate;
    const int64_t deflation_disk_used_thousandth = avg_disk_used_thousandth - _disk_floating_rate;

    // 4.4.1) divide disks to different groups
    for (auto& disk : all_disks) {
        // set global used rate to disk
        disk->avg_used_thousandth = avg_disk_used_thousandth;
        disk->inflation_used_thousandth = inflation_disk_used_thousandth;
        disk->deflation_used_thousandth = deflation_disk_used_thousandth;
        // group by used rate
        if (disk->used_thousandth > inflation_disk_used_thousandth) {
            if (_only_offline && has_offline) {
                LOG_IF(NOTICE, _debug) << "ignore to add to inflation group,"
                    << " log_id:[" << _log_id
                    << "] disk:[" << disk
                    << "]";
                continue;
            }
            inflation_disks.emplace_back(disk);
            LOG_IF(NOTICE, _debug) << "add to inflation group,"
                << " log_id:[" << _log_id
                << "] disk:[" << disk
                << "]";

        } else if (disk->used_thousandth < deflation_disk_used_thousandth
                || (deflation_disk_used_thousandth < 0 && disk->used_thousandth < avg_disk_used_thousandth)) {
            deflation_disks.emplace_back(disk);
            LOG_IF(NOTICE, _debug) << "add to deflation group,"
                << " log_id:[" << _log_id
                << "] disk:[" << disk
                << "]";
        } else {
            normal_disks.emplace_back(disk);
            LOG_IF(NOTICE, _debug) << "add to normal group,"
                << " log_id:[" << _log_id
                << "] disk:[" << disk
                << "]";
        }
    }

    auto disk_max_num_part_total = kDiskMaxNumOfPartTotal;
    if (_only_offline && has_offline && !inflation_disks.empty()) {
        disk_max_num_part_total = std::min(kDiskMaxNumOfPartTotal, inflation_disks.size());
    }

    // auto reset variables
    if (_disk_max_num == kDiskMaxNum) {
        _disk_max_num = std::max(1lu, _max_num / disk_max_num_part_total);
    }
    if (_disk_max_recovery_num == kDiskMaxRecoveryNum) {
        _disk_max_recovery_num = std::max(1lu, _max_num / disk_max_num_part_total);
    }

    if (_max_num != kMaxNum) {
        if (_cluster_max_num == kClusterMaxNum) {
            _cluster_max_num = std::max(1lu, _max_num / kClusterMaxNumOfPartTotal);
        }
        if (_max_recovery_num == kMaxRecoveryNum) {
            _max_recovery_num = _max_num;
        }
        if (_cluster_max_recovery_num == kClusterMaxRecoveryNum) {
            _cluster_max_recovery_num = std::max(1lu, _max_num / kClusterMaxNumOfPartTotal);
        }

        LOG(NOTICE) << "reset rebalance info,"
            << " cluster_addr:[" << _cluster_addr
            << "] max_num:[" << _max_num
            << "] disk_max_num:[" << _disk_max_num
            << "] cluster_max_num:[" << _cluster_max_num
            << "] max_recovery_num:[" << _max_recovery_num
            << "] disk_max_recovery_num:[" << _disk_max_recovery_num
            << "] cluster_max_recovery_num:[" << _cluster_max_recovery_num
            << "] disk_floating_rate:[" << _disk_floating_rate
            << "] cluster_id:[" << _cluster_id
            << "]";
    }

    LOG(NOTICE) << "show disk groups rate msg,"
        << " log_id:[" << _log_id
        << "] avg_rate:[" << avg_disk_used_thousandth
        << "] inflation_rate:[" << inflation_disk_used_thousandth
        << "] deflation_rate:[" << deflation_disk_used_thousandth
        << "] disk_count:[" << all_disks_num
        << "] inflation_disks_count:[" << inflation_disks.size()
        << "] deflation_disks_count:[" << deflation_disks.size()
        << "]";

    if (_stopped) {
        LOG(WARNING) << "quit by stop signal, "
            << " log_id:[" << _log_id
            << "]";
        return -1;
    }

    LOG(NOTICE) << "show disk groups size (move inflation to deflation),"
        << " log_id:[" << _log_id
        << "] inflation_size:[" << inflation_disks.size()
        << "] deflation_size:[" << deflation_disks.size()
        << "] normal_size:[" << normal_disks.size()
        << "]";

    // 4.5) while iterating Cluster
    // - sum replicas number
    // - calc replica average number on each disk
    LOG(NOTICE) << "cacl clusters replica count and avg num on disk,"
        << " log_id:[" << _log_id
        << "]";
    for (auto& it : _server_manager.cluster_map) {
        auto cluster = it.second;
        cluster->CalcReplicaSumAndAvgOnDisk(all_disks_num, _server_manager.server_map);
        LOG_IF(NOTICE, _debug) << "log_id:[" << _log_id
            << "] cluster:[" << cluster->id
            << "] replica_count:[" << cluster->replica_count
            << "] avg_replica_count_on_disk:[" << cluster->avg_replica_count_on_disk
            << "]";
        // fill global rebalance replicas
        for (auto& replica : cluster->rebalance_from_replica_vec) {
            _server_manager.rebalance_from_replica_vec.emplace_back(replica);
        }
        for (auto& replica : cluster->rebalance_to_replica_vec) {
            _server_manager.rebalance_to_replica_vec.emplace_back(replica);
        }
        for (auto& replica : cluster->in_recovery_replica_vec) {
            _server_manager.in_recovery_replica_vec.emplace_back(replica);
        }

        if (_stopped) {
            LOG(WARNING) << "quit by stop signal, "
                << " log_id:[" << _log_id
                << "]";
            return -1;
        }
    }

    if (inflation_disks.empty() && deflation_disks.empty()) {
        std::vector<ClusterDisk> rebalance_clusters;
        for (auto& disk : all_disks) {
            for (auto& it : disk->cluster_replica_map) {
                auto& cluster_id = it.first;
                std::shared_ptr<Cluster> cluster = _server_manager.GetCluster(cluster_id);
                std::shared_ptr<DiskCluster> disk_cluster = it.second;
                disk_cluster->CalcReplicaSumAndScore(cluster->segment_map, cluster->avg_replica_count_on_disk);
                LOG_IF(NOTICE, _debug) << "show disk cluster info,"
                    << " disk:[" << disk
                    << "] cluster:[" << disk_cluster
                    << "]";
                if (disk_cluster->real_replica_count_on_disk_score >= 2.0) {
                    rebalance_clusters.emplace_back(disk, disk_cluster);
                }
            }
        }

        if (!rebalance_clusters.empty()) {
            std::sort(rebalance_clusters.begin(), rebalance_clusters.end(),
                    [](const ClusterDisk& lhs, const ClusterDisk& rhs){
                        return lhs.disk_cluster->real_replica_count_on_disk_score
                                    > rhs.disk_cluster->real_replica_count_on_disk_score;
                    });
            bool end_task = false;
            for (size_t i = 0; i < rebalance_clusters.size() && !_stopped && !end_task; ++i) {
                std::shared_ptr<Disk> from = rebalance_clusters[i].disk;
                std::shared_ptr<DiskCluster> disk_cluster = rebalance_clusters[i].disk_cluster;
                bool end_disk_task = false;
                // empty inflation branch: cluster-count rebalance, skip usage threshold checks
                PickReplica(disk_cluster, from, all_disks, end_task, end_disk_task,
                        false /* check_usage_threshold */, &rebalance_replicas);
            }

            if (_stopped) {
                LOG(WARNING) << "quit by stop signal, "
                    << " log_id:[" << _log_id
                    << "]";
                return -1;
            }
            LOG(NOTICE) << "end of rebalance clusters from all disks,"
                << " log_id:[" << _log_id
                << "]";

            rebalance_replicas.mutable_status()->set_code(pspb::Status::SUCCESS);
            rebalance_replicas.mutable_status()->set_msg("rebalance replicas ok");
            return Output(rebalance_replicas);
        }
        // no cluster-count rebalance source, fall through to the normal
        // rebalance path below.
    }

    // 4.6) iterate over inflation_disks
    // - select a right replica, move it to best disk.
    LOG(NOTICE) << "begin to rebalance inflation disks,"
        << " log_id:[" << _log_id
        << "]";

    // 4.6.1) iterate over candidate disks clusters
    std::vector<std::shared_ptr<Disk>>* candidate_disks = &deflation_disks;
    if (deflation_disks.empty()) {
        candidate_disks = &normal_disks;
    }
    for (auto& disk : *candidate_disks) {
        for (auto& it : disk->cluster_replica_map) {
            auto& cluster_id = it.first;
            std::shared_ptr<Cluster> cluster = _server_manager.GetCluster(cluster_id);
            std::shared_ptr<DiskCluster> disk_cluster = it.second;
            disk_cluster->CalcReplicaSumAndScore(cluster->segment_map, cluster->avg_replica_count_on_disk);
            LOG_IF(NOTICE, _debug) << "show candidate disk cluster info,"
                << " disk:[" << disk
                << "] cluster:[" << disk_cluster
                << "]";
        }
    }

    if (!DoRebalance(inflation_disks, *candidate_disks, normal_disks, all_disks, rebalance_replicas)) {
        // inflation disks cannot migrate to candidate disks, fall back to migrating
        // from normal disks. This fallback only makes sense when candidate_disks
        // points to deflation_disks (i.e. deflation_disks is not empty); otherwise
        // candidate_disks is normal_disks itself and normal -> normal is meaningless.
        if (deflation_disks.size()) {
            DoRebalance(normal_disks, *candidate_disks, normal_disks, all_disks, rebalance_replicas);
        }
    }

    if (_stopped) {
        LOG(WARNING) << "quit by stop signal, "
            << " log_id:[" << _log_id
            << "]";
        return -1;
    }
    LOG(NOTICE) << "end of rebalance inflation disks,"
        << " log_id:[" << _log_id
        << "]";

    rebalance_replicas.mutable_status()->set_code(pspb::Status::SUCCESS);
    rebalance_replicas.mutable_status()->set_msg("rebalance replicas ok");
    return Output(rebalance_replicas);
}

bool RebalanceSegmentReplicas::DoRebalance(const std::vector<std::shared_ptr<Disk>>& from_disks,
        const std::vector<std::shared_ptr<Disk>>& candidate_disks,
        const std::vector<std::shared_ptr<Disk>>& normal_disks,
        const std::vector<std::shared_ptr<Disk>>& all_disks,
        pspb::GaiaReblanceSegments& rebalance_replicas) {
    bool end_task = false;
    for (size_t i = 0; i < from_disks.size() && !_stopped && !end_task; ++i) {
        std::shared_ptr<Disk> from = from_disks[i];
        // 4.6.2) calc the score of clusters on disk
        LOG(NOTICE) << "start to rebalance inflation disk replicas,"
            << " log_id:[" << _log_id
            << "] disk:[" << from
            << "]";
        auto server = _server_manager.GetDiskServer(from);
        bool is_offline = server ? server->is_offline : false;
        std::vector<std::shared_ptr<DiskCluster>> disk_clusters;
        {
            for (auto& it : from->cluster_replica_map) {
                auto disk_cluster = it.second;
                auto cluster = _server_manager.GetCluster(disk_cluster->cluster_id);
                disk_cluster->CalcReplicaSumAndScore(cluster->segment_map, cluster->avg_replica_count_on_disk);
                disk_clusters.emplace_back(disk_cluster);
            }
            // sort disk clusters by score DESC
            std::sort(disk_clusters.begin(), disk_clusters.end(),
                    [this](std::shared_ptr<DiskCluster> lhs, std::shared_ptr<DiskCluster> rhs) {
                        return lhs->real_replica_count_on_disk_score > rhs->real_replica_count_on_disk_score;
                    });
            if (_debug) {
                LOG(NOTICE) << "show the sorted clusters on disk,"
                    << " log_id:[" << _log_id
                    << "] disk:[" << from
                    << "]";
                for (auto& disk_cluster : disk_clusters) {
                    LOG(NOTICE) << "log_id:[" << _log_id
                        << "] cluster:[" << disk_cluster->cluster_id
                        << "] replica_count:[" << disk_cluster->replica_count
                        << "] score:[" << disk_cluster->real_replica_count_on_disk_score
                        << "]";
                }
            }
        }

        // 4.6.3) iterate over disk clusters
        // - pick a replica of cluster and check if it is eligible to move
        bool end_disk_task = false;
        for (size_t j = 0; j < disk_clusters.size() && !_stopped && !end_task && !end_disk_task; ++j) {
            std::shared_ptr<DiskCluster> disk_cluster = disk_clusters[j];
            if (!_cluster_id.empty() && disk_cluster->cluster_id != _cluster_id) {
                LOG_IF(NOTICE, _debug) << "cluster id mismatch, ignore disk cluster:[" << disk_cluster << "]";
                continue;
            }
            auto candidate_disks_cp = candidate_disks;
            uint32_t n = PickReplica(disk_cluster, from, candidate_disks_cp, end_task, end_disk_task,
                    true /* check_usage_threshold */, &rebalance_replicas);
            LOG(NOTICE) << "cluster pick result, disk cluster:[" << disk_cluster
                << "] result:[" << n
                << "]";
            if (n == 0 && is_offline) {
                if (!normal_disks.empty()) {
                    candidate_disks_cp = normal_disks;
                    n = PickReplica(disk_cluster, from, candidate_disks_cp, end_task, end_disk_task,
                            true /* check_usage_threshold */, &rebalance_replicas);
                }
                if (n == 0) {
                    candidate_disks_cp = all_disks;
                    PickReplica(disk_cluster, from, candidate_disks_cp, end_task, end_disk_task,
                            true /* check_usage_threshold */, &rebalance_replicas);
                }
            }

        } // end of iterate disk_clusters
    } // end of iterate inflation_disks
    return rebalance_replicas.segments_size() > 0;
}

uint32_t RebalanceSegmentReplicas::PickReplica(std::shared_ptr<DiskCluster> disk_cluster,
        std::shared_ptr<Disk> from, std::vector<std::shared_ptr<Disk>>& candidate_disks,
        bool& end_task, bool& end_disk_task, bool check_usage_threshold,
        pspb::GaiaReblanceSegments* rebalance_replicas) {
    uint32_t pick_from_num = 0;
    uint32_t pick_to_num = 0;
    // sort disk cluster replicas by physical_size DESC
    std::sort(disk_cluster->replica_list.begin(), disk_cluster->replica_list.end(),
            [this](std::shared_ptr<Replica> lhs, std::shared_ptr<Replica> rhs) {
            return lhs->physical_size > rhs->physical_size;
            });
    if (_debug) {
        LOG(NOTICE) << "show the sorted cluster replicas on disk,"
            << " log_id:[" << _log_id
            << "] disk_cluster:[" << disk_cluster
            << "] replica_list_size:[" << disk_cluster->replica_list.size()
            << "]";
        for (auto& replica : disk_cluster->replica_list) {
            LOG(NOTICE) << "log_id:[" << _log_id
                << "] replica:[" << replica
                << "]";
        }
    }
    disk_cluster->iter = disk_cluster->replica_list.begin();
    while (disk_cluster->iter != disk_cluster->replica_list.end() && !_stopped && !end_task && !end_disk_task) {
        auto server = _server_manager.GetDiskServer(from);
        bool is_offline = server ? server->is_offline : false;
        std::shared_ptr<Replica> replica = PickReplicaToRebalance(from, disk_cluster, end_task, end_disk_task,
                check_usage_threshold, is_offline);
        if (replica) {
            ++pick_from_num;
            // resort it, last pick maybe changed candidate disks.
            CompareDisk cmp(replica);
            std::sort(candidate_disks.begin(), candidate_disks.end(), cmp);
            LOG_IF(NOTICE, _debug) << "try to move replica to deflation disk,"
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "]";
            std::shared_ptr<Disk> to = PickBestDiskToStoreReplica(replica, candidate_disks, check_usage_threshold, false);
            if (!to && is_offline) {
                to = PickBestDiskToStoreReplica(replica, candidate_disks, check_usage_threshold, is_offline);
            }
            if (to) {
                ++pick_to_num;
                AddReplicaToRebalanceList(replica, from, to, rebalance_replicas);
            } else {
                ++disk_cluster->iter;
            }
        }
    }
    return pick_from_num == pick_to_num;
}

std::shared_ptr<Replica> RebalanceSegmentReplicas::PickReplicaToRebalance(std::shared_ptr<Disk> disk,
        std::shared_ptr<DiskCluster> disk_cluster, bool& end_task, bool& end_disk_task,
        bool check_usage_threshold, bool is_offline) {
    // pick a replica to rebalance
    while (disk_cluster->iter != disk_cluster->replica_list.end() && !_stopped) {
        auto replica = *(disk_cluster->iter);
        auto cluster = _server_manager.GetReplicaCluster(replica);
        auto segment = cluster->GetReplicaSegment(replica);
        LOG_IF(NOTICE, _debug) << "try to rebalance replica:[" << replica << "]";
        if (_server_manager.rebalance_from_replica_vec.size() >= _max_num) {
            end_task = true;
            LOG(NOTICE) << "should stop rebalance task, in rebalance replicas num over max limit,"
                << " log_id:[" << _log_id
                << "] size:[" << _server_manager.rebalance_from_replica_vec.size()
                << "] limit:[" << _max_num
                << "] replica:[" << replica
                << "]";
            return nullptr;
        }
        if (_server_manager.in_recovery_replica_vec.size() >= _max_recovery_num) {
            end_task = true;
            LOG(NOTICE) << "should stop rebalance task, in recovery replicas num over max limit,"
                << " log_id:[" << _log_id
                << "] size:[" << _server_manager.in_recovery_replica_vec.size()
                << "] limit:[" << _max_recovery_num
                << "] replica:[" << replica
                << "]";
            return nullptr;
        }
        if (disk->rebalance_pick_from_replicas_vec.size() >= _disk_max_num) {
            end_disk_task = true;
            LOG(NOTICE) << "pick failed, rebalance replicas from disk num over max limit,"
                << " log_id:[" << _log_id
                << "] size:[" << disk->rebalance_pick_from_replicas_vec.size()
                << "] limit:[" << _disk_max_num
                << "] infos:[" << disk->rebalance_pick_from_replicas_vec
                << "] disk:[" << disk
                << "] replica:[" << replica
                << "]";
            return nullptr;
        }
        if (cluster->rebalance_from_replica_vec.size() >= _cluster_max_num) {
            disk_cluster->iter = disk_cluster->replica_list.end();
            LOG(NOTICE) << "pick failed, rebalance replicas from cluster num over max limit,"
                << " log_id:[" << _log_id
                << "] size:[" << cluster->rebalance_from_replica_vec.size()
                << "] limit:[" << _cluster_max_num
                << "] infos:[" << cluster->rebalance_from_replica_vec
                << "] cluster:[" << cluster
                << "] replica:[" << replica
                << "]";
            return nullptr;
        }
        if (cluster->in_recovery_replica_vec.size() >= _cluster_max_recovery_num) {
            disk_cluster->iter = disk_cluster->replica_list.end();
            LOG(NOTICE) << "pick failed, cluster in recovery replicas num over max limit,"
                << " log_id:[" << _log_id
                << "] size:[" << cluster->in_recovery_replica_vec.size()
                << "] limit:[" << _cluster_max_recovery_num
                << "] infos:[" << cluster->in_recovery_replica_vec
                << "] cluster:[" << cluster
                << "] replica:[" << replica
                << "]";
            return nullptr;
        }

        if (check_usage_threshold) {
            if (auto tmp = cacl_disk_used_thousandth(disk->used_size - replica->physical_size, disk->total_size);
                    tmp < disk->deflation_used_thousandth) {
                ++disk_cluster->iter;
                LOG(NOTICE) << "pick failed, disk used size rate will low than deflation rate,"
                    << " log_id:[" << _log_id
                    << "] new_used_thousandth:[" << tmp
                    << "] deflation_used_thousandth:[" << disk->deflation_used_thousandth
                    << "] cluster:[" << cluster
                    << "] replica:[" << replica
                    << "]";
                continue;
            }
        }
        if (!replica->is_ok) {
            ++disk_cluster->iter;
            LOG(NOTICE) << "pick failed, replica is not ok,"
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "]";
            continue;
        }
        if (replica->in_recovery) {
            ++disk_cluster->iter;
            LOG(NOTICE) << "pick failed, replica in recovery,"
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "]";
            continue;
        }
        if (auto tmp = segment->GetInRebalanceReplica(); tmp) {
            ++disk_cluster->iter;
            LOG(NOTICE) << "pick failed, my peer or myself in rebalance,"
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "] rebalance_replica:[" << tmp
                << "]";
            continue;
        }
        if (auto tmp = segment->GetInRecoveryReplica(); tmp) {
            ++disk_cluster->iter;
            LOG(NOTICE) << "pick failed, my peer or myself in recovery,"
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "] recovery_replica:[" << tmp
                << "]";
            continue;
        }
        if (!is_offline && segment->replica_count < _min_replica_count) {
            ++disk_cluster->iter;
            LOG(NOTICE) << "pick failed, segment active replica num lower than "
                << _min_replica_count << ","
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "] segment:[" << segment
                << "]";
            continue;
        }
        // select from replica ok
        LOG(NOTICE) << "pick to rebalance replica ok,"
            << " log_id:[" << _log_id
            << "] replica:[" << replica
            << "] is_offline:[" << is_offline
            << "]";
        return replica;
    } // end of iterate disk_cluster->replica_list
    LOG(NOTICE) << "pick all failed, not found a satisfactory replica on disk cluster,"
        << " log_id:[" << _log_id
        << "] disk:[" << disk
        << "] disk_cluster:[" << disk_cluster
        << "]";
    return nullptr;
}

std::shared_ptr<Disk> RebalanceSegmentReplicas::PickBestDiskToStoreReplica(std::shared_ptr<Replica> replica,
        const std::vector<std::shared_ptr<Disk>>& candidate_disks,
        bool check_usage_threshold, bool is_offline) {
    for (auto& disk : candidate_disks) {
        if (disk->addr == replica->addr && disk->id == replica->store_id) {
            LOG_IF(NOTICE, _debug) << "pick store disk fail, equal from disk,"
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "] disk:[" << disk
                << "]";
            continue;
        }

        auto server = _server_manager.GetDiskServer(disk);
        if (std::shared_ptr<Replica> peer
                = server->ReplicaOnServer(_server_manager.GetReplicaSegment(replica)); peer) {
            LOG_IF(NOTICE, _debug) << "pick store disk fail, another replica exists,"
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "] exists_replica:[" << peer
                << "] disk:[" << disk
                << "]";
            continue;
        }
        if (disk->in_recovery_replica_vec.size() >= _disk_max_recovery_num) {
            LOG_IF(NOTICE, _debug) << "pick store disk fail, disk in recovery replicas num over max limit,"
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "] size:[" << disk->in_recovery_replica_vec.size()
                << "] limit:[" << _disk_max_recovery_num
                << "] disk:[" << disk
                << "]";
            continue;
        }
        if (std::shared_ptr<Replica> peer
                = disk->ZoneConflict(replica, _server_manager.GetReplicaSegment(replica)); peer) {
            LOG_IF(NOTICE, _debug) << "pick store disk fail, another replica exists in same zone,"
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "] exists_replica:[" << peer
                << "] disk:[" << disk
                << "]";
            continue;
        }
        if (disk->has_io_error) {
            LOG_IF(NOTICE, _debug) << "pick store disk fail, disk has io error,"
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "] disk:[" << disk
                << "]";
            continue;
        }
        if (disk->used_capacity + 1 > disk->total_capacity) {
            LOG_IF(NOTICE, _debug) << "pick store disk fail, capacity will over limit,"
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "] disk:[" << disk
                << "]";
            continue;
        }
        if (disk->used_size + replica->physical_size + _min_reserve_size >= disk->total_size) {
            LOG_IF(NOTICE, _debug) << "pick store disk fail, used size will over limit,"
                << " log_id:[" << _log_id
                << "] replica:[" << replica
                << "] disk:[" << disk
                << "]";
            continue;
        }
        if (!is_offline && check_usage_threshold) {
            if (auto tmp = cacl_disk_used_thousandth(disk->used_size + replica->physical_size, disk->total_size);
                    tmp > disk->inflation_used_thousandth) {
                LOG_IF(NOTICE, _debug) << "pick store disk fail, used size rate will over inflation rate,"
                    << " log_id:[" << _log_id
                    << "] replica:[" << replica
                    << "] new_used_thousandth:[" << tmp
                    << "] inflation_used_thousandth:[" << disk->inflation_used_thousandth
                    << "] disk:[" << disk
                    << "]";
                continue;
            }
        }
        if (!is_offline) {
            if (auto tmp = (disk->GetClusterReplicaCountOnDisk(replica) + 1);
                    tmp > _server_manager.GetReplicaCluster(replica)->avg_replica_count_on_disk) {
                LOG_IF(NOTICE, _debug) << "pick store disk fail, disk replicas num over avg limit,"
                    << " log_id:[" << _log_id
                    << "] replica:[" << replica
                    << "] new_num:[" << tmp
                    << "] avg_num:[" << _server_manager.GetReplicaCluster(replica)->avg_replica_count_on_disk
                    << "] disk:[" << disk
                    << "]";
                continue;
            }
        }

        LOG(NOTICE) << "pick replica store disk ok,"
            << " log_id:[" << _log_id
            << "] replica:[" << replica
            << "] disk:[" << disk
            << "] is_offline:[" << is_offline
            << "]";
        return disk;
    }

    LOG(NOTICE) << "pick all failed, not found a satisfactory disk to store replica,"
        << " log_id:[" << _log_id
        << "] replica:[" << replica
        << "] candidate_disks_size:[" << candidate_disks.size()
        << "] is_offline:[" << is_offline
        << "]";
    return nullptr;
}

void RebalanceSegmentReplicas::AddReplicaToRebalanceList(std::shared_ptr<Replica> replica,
       std::shared_ptr<Disk> from, std::shared_ptr<Disk> to, pspb::GaiaReblanceSegments* rebalance_replicas) {
    std::shared_ptr<Replica> replica_new(new Replica(replica->cluster_id, replica->segment_id, to->addr));
    replica_new->logical_size = replica->logical_size;
    replica_new->physical_size = replica->physical_size;
    replica_new->in_recovery = true;
    replica_new->store_id = to->id;
    replica_new->manager_address = replica->manager_address;
    //replica_new->version = 0;
    //replica_new->replica_id = 0;
    replica_new->has_rebalance = true;
    replica_new->rebalance_from = replica->addr;
    replica_new->rebalance_version = replica->version;
    replica_new->is_ok = true;
    replica_new->zone = to->zone;

    _server_manager.AddNewRebalanceReplica(replica, replica_new);
    from->AddRebalanceFromReplica(replica);
    to->AddRebalanceToReplica(replica_new);
    to->AddInRecoveryReplica(replica_new);
    to->AddReplica(replica_new);

    {
        auto cluster = _server_manager.GetCluster(replica_new->cluster_id);
        to->GetReplicaDiskCluster(replica_new)->AddRebalanceReplica(replica_new, cluster->avg_replica_count_on_disk);
    }
    {
        auto cluster = _server_manager.GetCluster(replica->cluster_id);
        from->GetReplicaDiskCluster(replica)->DelRebalanceReplica(replica, cluster->avg_replica_count_on_disk);
    }

    LOG(NOTICE) << "make a rebalance replica record,"
        << " log_id:[" << _log_id
        << "] replica:[" << replica
        << "] from_disk:[" << from
        << "] to_disk:[" << to
        << "]";
    {
        // add rebalance replica to protobuf
        auto segment = rebalance_replicas->add_segments();
        segment->mutable_src()->set_addr(gaiadb::common::endpoint2str(replica->addr));
        segment->mutable_src()->set_cluster_id(replica->cluster_id);
        segment->mutable_src()->set_segment_id(replica->segment_id);
        segment->mutable_src()->set_store_id(replica->store_id);
        segment->mutable_src()->set_manager_address(replica->manager_address);
        segment->mutable_src()->set_size(replica->logical_size);
        segment->mutable_src()->set_version(replica->version);
        segment->mutable_dest()->set_addr(gaiadb::common::endpoint2str(to->addr));
        segment->mutable_dest()->set_store_id(to->id);
    }
}

int RebalanceSegmentReplicas::Run() {
    if (_cluster_addr.empty()) {
        print_error("miss --cluster-addr");
        return 1;
    }

    if (_max_num < 1) {
        print_error("miss --max-num or -n");
        return 1;
    }

    if (_disk_max_num < 1 || _cluster_max_num < 1 || _max_recovery_num < 1
            || _disk_max_recovery_num < 1 || _cluster_max_recovery_num < 1) {
        print_error("invalid limit num");
        return 1;
    }

    LOG(NOTICE) << "rebalance info,"
        << " cluster_addr:[" << _cluster_addr
        << "] max_num:[" << _max_num
        << "] disk_max_num:[" << _disk_max_num
        << "] cluster_max_num:[" << _cluster_max_num
        << "] max_recovery_num:[" << _max_recovery_num
        << "] disk_max_recovery_num:[" << _disk_max_recovery_num
        << "] cluster_max_recovery_num:[" << _cluster_max_recovery_num
        << "] disk_floating_rate:[" << _disk_floating_rate
        << "] cluster_id:[" << _cluster_id
        << "]";

    // 1) get all page server nodes
    PsmInfo psm_info(_cluster_addr, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--cluster-addr parse failed, cant get server list from it");
        return 1;
    }

    // 2.0) init Server list
    _server_manager.InitServerMap(nodes);
    // 2.1) got segment replicas and stores from all page server nodes
    if (!GetPageServerReplicasAndStores()) {
        print_error("got page server info failed");
        return 1;
    }

    if (_stopped) {
        LOG(WARNING) << "log_id:" << _log_id << " quit by signal";
        return 1;
    }

    // 3) use Server Disk replicas to build Cluster and Segment
    _server_manager.BuildClusterAndSegmentFromServerDiskReplicas();

    if (_stopped) {
        LOG(WARNING) << "log_id:" << _log_id << " quit by signal";
        return 1;
    }

    // 4) start rebalance replicas
    pspb::GaiaReblanceSegments rebalance_replicas;
    if (StartRebalanceReplicas(rebalance_replicas)) {
        LOG(WARNING) << "log_id:" << _log_id << " rebalance failed";
        return 1;
    }

    if (_stopped) {
        LOG(WARNING) << "log_id:" << _log_id << " quit by signal";
        return 1;
    }
    return 0;
}

int RebalanceSegmentReplicas::Format(const pspb::GaiaReblanceSegments& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.segments_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({"cluster_id", "segment_id", "manager_address", "size", "version",
                "from_addr", "from_store_id", "to_addr", "to_store_id"}, true);
        for (int32_t i = 0; i < rsp.segments_size(); ++i) {
            const auto& seg_pb = rsp.segments(i);
            table.AddRowsValue({
                    seg_pb.src().cluster_id(),
                    seg_pb.src().segment_id(),
                    seg_pb.src().manager_address(),
                    RowSize(seg_pb.src().size(), _human_readable),
                    seg_pb.src().version(),
                    seg_pb.src().addr(),
                    seg_pb.src().store_id(),
                    seg_pb.dest().addr(),
                    seg_pb.dest().store_id(),
                    });
        }
        table.Display();
    }
    return 0;
}

}
}
