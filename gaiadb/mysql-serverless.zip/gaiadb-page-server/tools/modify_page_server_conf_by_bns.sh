#!/usr/bin/env bash
set -euo pipefail

CONF_PATH="/home/work/page_server/conf/page_server.conf"
SSH_OPTS="-o ConnectTimeout=5 -o StrictHostKeyChecking=no"
SSH_USER="work"

usage() {
    cat <<'EOF'
Usage:
  ./modify_page_server_conf_by_bns.sh <bns> add <key> <value> [conf_path]
  ./modify_page_server_conf_by_bns.sh <bns> set <key> <value> [conf_path]
  ./modify_page_server_conf_by_bns.sh <bns> delete <key> [conf_path]

Examples:
  ./modify_page_server_conf_by_bns.sh group.example.all set max_query_num 100
  ./modify_page_server_conf_by_bns.sh group.example.all add enable_foo true
  ./modify_page_server_conf_by_bns.sh group.example.all delete enable_foo
  ./modify_page_server_conf_by_bns.sh group.example.all set max_query_num 100 /home/work/page_server/conf/page_server.conf

Notes:
  - Requires get_instance_by_service in PATH.
  - SSH uses work account: ssh work@node.
  - Config lines are treated as gflags in the form --key=value.
  - add fails if the key already exists as an active config item.
  - set fails if the key does not exist as an active config item.
  - delete removes all active config lines for the key.
  - Each node creates a backup before modifying: <conf_path>.bak.<timestamp>.
EOF
}

if [[ $# -lt 3 ]]; then
    usage
    exit 1
fi

BNS="$1"
ACTION="$2"
KEY="$3"
VALUE=""

case "$ACTION" in
    add|set)
        if [[ $# -lt 4 || $# -gt 5 ]]; then
            usage
            exit 1
        fi
        VALUE="$4"
        if [[ $# -eq 5 ]]; then
            CONF_PATH="$5"
        fi
        ;;
    delete)
        if [[ $# -gt 4 ]]; then
            usage
            exit 1
        fi
        if [[ $# -eq 4 ]]; then
            CONF_PATH="$4"
        fi
        ;;
    *)
        usage
        exit 1
        ;;
esac

KEY="${KEY#--}"
if [[ -z "$KEY" || "$KEY" == *"="* || "$KEY" =~ [[:space:]] ]]; then
    echo "ERROR: invalid key: $KEY" >&2
    exit 1
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

NODE_LIST="$TMP_DIR/nodes.txt"
FAILED_LOG="$TMP_DIR/failed.log"
: >"$FAILED_LOG"

trap 'echo; echo "Interrupted by user." >&2; if [[ -s "$FAILED_LOG" ]]; then echo; echo "Failures collected so far:"; cat "$FAILED_LOG"; fi; exit 130' INT

extract_nodes() {
    awk '
        /^[[:space:]]*$/ { next }
        /^#/ { next }
        {
            for (i = 1; i <= NF; i++) {
                field = $i
                gsub(/^\[/, "", field)
                gsub(/\]$/, "", field)

                if (field ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+(:[0-9]+)?$/) {
                    sub(/:[0-9]+$/, "", field)
                    print field
                    next
                }

                if (field ~ /^[A-Za-z0-9._-]+(:[0-9]+)?$/ && field !~ /^[0-9]+$/) {
                    sub(/:[0-9]+$/, "", field)
                    print field
                    next
                }
            }
        }
    ' | sort -u
}

if ! command -v get_instance_by_service >/dev/null 2>&1; then
    echo "ERROR: get_instance_by_service not found in PATH" >&2
    exit 2
fi

echo "Fetching BNS instances: $BNS" >&2
if ! get_instance_by_service "$BNS" 2>"$TMP_DIR/bns.err" | extract_nodes >"$NODE_LIST"; then
    echo "ERROR: failed to fetch BNS instances" >&2
    cat "$TMP_DIR/bns.err" >&2 || true
    exit 3
fi

if [[ ! -s "$NODE_LIST" ]]; then
    echo "ERROR: no nodes parsed from BNS: $BNS" >&2
    echo "Raw error output:" >&2
    cat "$TMP_DIR/bns.err" >&2 || true
    exit 3
fi

NODE_COUNT="$(wc -l <"$NODE_LIST")"
echo "Found $NODE_COUNT node(s)" >&2
echo "Action: $ACTION"
echo "Key:    $KEY"
if [[ "$ACTION" != "delete" ]]; then
    echo "Value:  $VALUE"
fi
echo "Path:   $CONF_PATH"
echo

SUCCESS_COUNT=0
FAILED_COUNT=0

while IFS= read -r node <&3; do
    safe_node="${node//[^A-Za-z0-9_.-]/_}"
    err_file="$TMP_DIR/${safe_node}.err"

    if ssh $SSH_OPTS "${SSH_USER}@${node}" bash -s -- "$CONF_PATH" "$ACTION" "$KEY" "$VALUE" >"$TMP_DIR/${safe_node}.out" 2>"$err_file" <<'REMOTE'
set -euo pipefail

conf_path="$1"
action="$2"
key="$3"
value="${4:-}"

if [[ ! -f "$conf_path" ]]; then
    echo "config file not found: $conf_path" >&2
    exit 10
fi
if [[ ! -r "$conf_path" || ! -w "$conf_path" ]]; then
    echo "config file is not readable/writable: $conf_path" >&2
    exit 11
fi

case "$key" in
    *[!A-Za-z0-9_./-]*|"")
        echo "invalid key: $key" >&2
        exit 12
        ;;
esac

conf_dir="$(dirname "$conf_path")"
conf_base="$(basename "$conf_path")"
backup_path="$conf_path.bak.$(date +%Y%m%d%H%M%S)"
tmp_path="$conf_dir/.${conf_base}.tmp.$$"

match_count="$(awk -v key="$key" '
    function is_target(line) {
        s = line
        sub(/^[[:space:]]+/, "", s)
        if (s ~ /^#/) {
            return 0
        }
        return s ~ ("^--" key "[[:space:]]*=")
    }
    is_target($0) { matched++ }
    END { print matched + 0 }
' "$conf_path")"

case "$action" in
    add)
        if [[ "$match_count" -gt 0 ]]; then
            echo "key already exists: $key (matched=$match_count)" >&2
            exit 20
        fi
        ;;
    set|delete)
        if [[ "$match_count" -eq 0 ]]; then
            echo "key does not exist: $key" >&2
            exit 21
        fi
        ;;
    *)
        echo "unsupported action: $action" >&2
        exit 22
        ;;
esac

cp -p "$conf_path" "$backup_path"

if awk -v action="$action" -v key="$key" -v value="$value" '
    function is_target(line) {
        s = line
        sub(/^[[:space:]]+/, "", s)
        if (s ~ /^#/) {
            return 0
        }
        return s ~ ("^--" key "[[:space:]]*=")
    }
    {
        if (is_target($0)) {
            if (action == "set") {
                indent = $0
                sub(/[^[:space:]].*$/, "", indent)
                print indent "--" key "=" value
            } else if (action == "delete") {
                next
            } else {
                print
            }
        } else {
            print
        }
    }
    END {
        if (action == "add") {
            print "--" key "=" value
        }
    }
' "$conf_path" >"$tmp_path"; then
    mv "$tmp_path" "$conf_path"
    echo "backup=$backup_path matched=$match_count"
else
    rc=$?
    rm -f "$tmp_path"
    echo "failed to rewrite config with awk, rc=$rc" >&2
    exit 13
fi
REMOTE
    then
        SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
        echo "OK     $node  $(cat "$TMP_DIR/${safe_node}.out")"
    else
        rc=$?
        FAILED_COUNT=$((FAILED_COUNT + 1))
        echo "FAILED $node" >&2
        {
            echo "===== $node ====="
            echo "exit_code=$rc"
            if [[ -s "$TMP_DIR/${safe_node}.out" ]]; then
                echo "--- stdout ---"
                cat "$TMP_DIR/${safe_node}.out"
            fi
            if [[ -s "$err_file" ]]; then
                echo "--- stderr ---"
                cat "$err_file"
            fi
            echo
        } >"$TMP_DIR/${safe_node}.failure"
        cat "$TMP_DIR/${safe_node}.failure" >&2
        cat "$TMP_DIR/${safe_node}.failure" >>"$FAILED_LOG"
    fi
done 3<"$NODE_LIST"

echo
echo "Summary"
echo "  BNS:           $BNS"
echo "  Config path:   $CONF_PATH"
echo "  Total nodes:   $NODE_COUNT"
echo "  Success nodes: $SUCCESS_COUNT"
echo "  Failed nodes:  $FAILED_COUNT"

if [[ -s "$FAILED_LOG" ]]; then
    echo
    echo "Failures:"
    cat "$FAILED_LOG"
fi

if [[ "$FAILED_COUNT" -gt 0 ]]; then
    exit 4
fi

exit 0
