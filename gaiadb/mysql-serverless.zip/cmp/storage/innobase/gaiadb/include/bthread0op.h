/***************************************************************************
* Copyright (c) baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file bthread0op.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <bthread/mutex.h>
#include <bthread.h>

#include <thread>
#include <chrono>

namespace gaia {

inline bool is_bthread() {
  return bthread_self() != INVALID_BTHREAD;
}

struct Mutex {
public:
  Mutex() : _bthread_id(INVALID_BTHREAD), _id(LATCH_ID_NONE), _file_name(nullptr), _line(0) {}

  void init(latch_id_t id, const char *file_name, uint32_t line) {
    CHECK_EQ(0, bthread_mutex_init(&_mutex, NULL));
    _id = id;
    _file_name = file_name;
    _line = line;
  }

  void destroy() {
    CHECK_EQ(0, bthread_mutex_destroy(&_mutex));
  }

  void enter(ulint, ulint, const char*, uint32_t) { lock(); }
  bool try_lock(const char*, uint32_t) { return try_lock(); }
  void exit() { unlock(); }

  bool validate() const { return !!_file_name; }


  void lock() {
    bthread_mutex_lock(&_mutex);
    _bthread_id = bthread_self();
  }

  void unlock() {
    bthread_mutex_unlock(&_mutex);
    _bthread_id = INVALID_BTHREAD;
  }

  bool try_lock() {
    return !bthread_mutex_trylock(&_mutex);
  }

private:
  DISALLOW_COPY_AND_ASSIGN(Mutex);
  bthread_mutex_t _mutex;
  bthread_t _bthread_id;
  latch_id_t _id;
  const char *_file_name;
  uint32_t _line;
};

namespace this_thread {

inline void yield(void) {
#ifdef WITH_BTHREAD_OP
  bthread_yield();
  return;
#endif
  std::this_thread::yield();
}

template <class Rep, class Period>
inline void sleep_for(const std::chrono::duration<Rep,Period>& rel_time) {
#ifdef WITH_BTHREAD_OP
  bthread_usleep(std::chrono::duration_cast<std::chrono::microseconds>(rel_time).count());
  return;
#endif
  std::this_thread::sleep_for(rel_time);
}

}
}

