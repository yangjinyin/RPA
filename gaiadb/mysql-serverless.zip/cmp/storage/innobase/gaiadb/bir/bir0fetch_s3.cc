#include "bir0async_binlog.h"
#include <ctype.h>
#include <base/base64.h>
#include <openssl/hmac.h>
#include <baidu/rpc/uri.h>
#include <baidu/rpc/details/http_message.h>
#include <openssl/aes.h>
#include "gaiadb/common/global_flags.h"
#include "rpl0rpl.h"
#include "rpl0parse.h"
#include "gaiadb/redo_fetch/fetch_mdc_object.h"
#include "gaiadb/redo_fetch/fetch_mdc_utils.h"

namespace bir {

// fetch s3 redo
void BirAsyncBinlog::build_headers_for_s3(
        std::map<std::string, std::string>& headers,
        std::string* headers_str, std::string* header_keys_str) {
  std::vector<std::string> headers_str_vec;
  std::vector<std::string> header_keys_str_vec;
  for (auto& it : headers) {
    std::string key = it.first;
    gaiadb::redo_fetch::str_to_lower(key);
    header_keys_str_vec.push_back(key);
    headers_str_vec.push_back(
      key.append(":").append(gaiadb::redo_fetch::trim(it.second)));
  }

  std::sort(headers_str_vec.begin(), headers_str_vec.end());
  std::sort(header_keys_str_vec.begin(), header_keys_str_vec.end());

  for (std::vector<std::string>::size_type i = 0; 
        i < headers_str_vec.size(); ++i) {
    headers_str->append(headers_str_vec[i]);
    headers_str->append("\n");

    header_keys_str->append(header_keys_str_vec[i]);
    if (i + 1 < headers_str_vec.size()) {
      header_keys_str->append(";");
    }
  }
  return;
}

// https://docs.aws.amazon.com/zh_cn/IAM/latest/UserGuide/reference_aws-signing.html
std::string BirAsyncBinlog::calculate_authrization_for_s3(
        const std::string& str_to_sign,
        const std::string& secret_access_key, const std::string& date,
        const std::string& region, const std::string& service) {
  //signing key = HMAC-SHA256(
  //              HMAC-SHA256(
  //              HMAC-SHA256(
  //              HMAC-SHA256("AWS4" + "<YourSecretAccessKey>", "20130524"),
  //                  "us-east-1"),
  //                  "s3"),
  //                  "aws4_request")
  auto date_key = gaiadb::redo_fetch::hmac_sha256(
      gaiadb::redo_fetch::kSignPrefixName + secret_access_key, date);
  auto date_region_key = 
      gaiadb::redo_fetch::hmac_sha256(date_key, region);
  auto date_region_service_key = 
      gaiadb::redo_fetch::hmac_sha256(date_region_key, service);
  auto signing_key = gaiadb::redo_fetch::hmac_sha256(
      date_region_service_key, "aws4_request");

  auto signature = gaiadb::redo_fetch::hex(
      gaiadb::redo_fetch::hmac_sha256(signing_key, str_to_sign));
  return signature;
}

void BirAsyncBinlog::set_request_meta_for_s3(
        brpc::Controller *cntl, const std::string& region,
        const std::string& ak, const std::string& sk,
        const std::string& host, const std::string& bucket,
        const std::string& object, const std::string& range) {
    brpc::HttpMethod method = brpc::HTTP_METHOD_GET;
    std::map<std::string, std::string> headers;
    time_t now = time(nullptr);

    auto date_str = gaiadb::redo_fetch::get_scope_date(now);
    std::string method_str = brpc::HttpMethod2Str(method);
    std::string service_name = "s3";
    // uri must start with '/'.
    std::string uri = object[0] == '/' ? object 
      : base::string_printf("/%s", object.c_str());;
    std::string scope = base::string_printf("%s/%s/%s/aws4_request",
            date_str.c_str(), region.c_str(), service_name.c_str());
    std::string query_string;
    std::string headers_str;
    std::string signed_header;
    std::string hash_payload = gaiadb::redo_fetch::hex(
        gaiadb::redo_fetch::sha256(""));

    // add headers
    headers["Host"] = base::string_printf("%s.%s", bucket.c_str(), host.c_str());
    //headers["Content-Type"] = kLogContentType;
    headers["Range"] = range;
    headers["X-Amz-Date"] = gaiadb::redo_fetch::get_gmt_date(now, "%Y%m%dT%H%M%SZ");
    headers["X-Amz-Content-SHA256"] = hash_payload;

    build_headers_for_s3(headers, &headers_str, &signed_header);

    headers["Date"] = gaiadb::redo_fetch::get_gmt_date(now, "%a, %d %b %Y %H:%M:%S %Z");
    headers["User-Agent"] = __COMPUTE_NODE_MODULE_NAME__  ;
    headers["Accept"] = "text/json, text/plain, application/octet-stream";
    // start to sign
    // https://docs.aws.amazon.com/AmazonS3/latest/API/sig-v4-header-based-auth.html
    std::string canonical_request;
    {
        canonical_request.append(method_str)
                         .append(gaiadb::redo_fetch::kEndl);
        canonical_request.append(uri)
                         .append(gaiadb::redo_fetch::kEndl);
        canonical_request.append(query_string).append(gaiadb::redo_fetch::kEndl);
        canonical_request.append(headers_str).append(gaiadb::redo_fetch::kEndl);
        canonical_request.append(signed_header).append(gaiadb::redo_fetch::kEndl);
        canonical_request.append(hash_payload);
    }
    std::string str_to_sign;
    {
        str_to_sign.append(gaiadb::redo_fetch::kAuthorizationType)
                   .append(gaiadb::redo_fetch::kEndl);
        str_to_sign.append(headers["X-Amz-Date"]).append(gaiadb::redo_fetch::kEndl);
        str_to_sign.append(scope).append(gaiadb::redo_fetch::kEndl);
        str_to_sign.append(gaiadb::redo_fetch::hex(
            gaiadb::redo_fetch::sha256(canonical_request)));
    }
    std::string signature = calculate_authrization_for_s3(
        str_to_sign, sk, date_str, region, service_name);
    // end of sign

    headers["Authorization"] = base::string_printf("%s Credential=%s/%s,SignedHeaders=%s,Signature=%s",
            gaiadb::redo_fetch::kAuthorizationType.c_str(), 
            ak.c_str(), scope.c_str(), signed_header.c_str(), signature.c_str());

    // set normal headers
    cntl->http_request().set_method(method);
    cntl->http_request().uri() = uri;
    for (auto& it : headers) {
        cntl->http_request().SetHeader(it.first, it.second);
    }
}


void BirAsyncBinlog::s3_get_redo(gaiadb::redo_fetch::ObjectStorage &object_storage) {
  const gaiadb::redo_fetch::ObjectS3& s3 = object_storage.s3();
  auto rpc_ctx = new gaiadb::redo_fetch::GetObjectContext;
  rpc_ctx->fetch_size = gaiadb::redo_fetch::ut_uintx_align_up<uint64_t>(
      gaiadb::redo_fetch::FLAGS_gaia_fetch_object_storage_size, OS_FILE_LOG_BLOCK_SIZE);
  rpc_ctx->region = s3.region;
  rpc_ctx->object = gaiadb::redo_fetch::lsn_to_lz_file(fetch_lsn_);
  rpc_ctx->host = s3.host;
  rpc_ctx->bucket = s3.bucket;
  rpc_ctx->ak = s3.access_key_id;
  rpc_ctx->sk = s3.secret_access_key;

  // set range
  const uint64_t lz_start_lsn = gaiadb::redo_fetch::calc_lz_start_lsn(fetch_lsn_);
  lsn_t start_lsn = fetch_lsn_;
  lsn_t request_lsn = ut_uint64_align_down(start_lsn, OS_FILE_LOG_BLOCK_SIZE);
  const uint64_t offset = request_lsn - lz_start_lsn;
  rpc_ctx->range = base::string_printf(
      "bytes=%lu-%lu", offset, offset + rpc_ctx->fetch_size - 1);

  // set request meta
  set_request_meta_for_s3(&rpc_ctx->cntl, rpc_ctx->region, rpc_ctx->ak, rpc_ctx->sk,
      rpc_ctx->host, rpc_ctx->bucket, rpc_ctx->object, rpc_ctx->range);

  LOG(NOTICE) << "try to get s3 object,"
    << " object:[" << rpc_ctx->object
    << "] host:[" << rpc_ctx->host
    << "] bucket:[" << rpc_ctx->bucket
    << "]";

  auto channel = get_or_creat_channel(rpc_ctx->host);
  if (!channel) {
    LOG(WARNING)  << "fail to get s3 rpc channel";
    return;
  }

  // get redo buf
  if (rpc_ctx->cntl.Failed()) {
    LOG(WARNING) << "fetch s3 failed,"
      << " object:[" << rpc_ctx->object
      << "] range:[" << rpc_ctx->range
      << "] err_msg:[" << rpc_ctx->cntl.ErrorText()
      << "] err_code:[" << rpc_ctx->cntl.ErrorCode()
      << "] " << rpc_ctx->cntl.response_attachment();

    Json::Value value;
    gaiadb::redo_fetch::JSONCPP_STRING errs;
    if (gaiadb::redo_fetch::json_decode(
      rpc_ctx->cntl.response_attachment().to_string(), &value, &errs)) {
      if (value["code"].asString() == "NoSuchKey") {
        LOG(ERROR) << "not found object in bos,"
            << " object:[" << rpc_ctx->object
            << "] range:[" << rpc_ctx->range
            << "]";
      }
    }
    return;
  }

  LOG_EVERY_SECOND(NOTICE) << "fetch redo from s3 ok,"
    << " object:[" << rpc_ctx->object
    << "] length:[" << rpc_ctx->fetch_size
    << "] range:[" << rpc_ctx->range
    << "] buf_size:[" << rpc_ctx->cntl.response_attachment().size()
    << "] align_fetch_lsn:[" << fetch_lsn_
    << "]";

  std::string redo_data = rpc_ctx->cntl.response_attachment().to_string();
  uint32_t real_block_num = rpc_ctx->fetch_size / OS_FILE_LOG_BLOCK_SIZE;

  if (rpc_ctx->tail_redo.size()) {
    real_block_num++;
    redo_data.append(rpc_ctx->tail_redo);
  }

  copy_to_fetch_log_buf(
    redo_data.c_str(), real_block_num, log_get_vdl(*log_sys), 0);
}
}
