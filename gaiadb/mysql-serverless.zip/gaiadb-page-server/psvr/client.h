/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/client.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <google/protobuf/descriptor.h>

#include "psvr/namespace.h"
#include "psvr/rpc_client.hpp"
#include "psvr/utils.h"

namespace psvr {

template<typename Request, typename Response, typename ServerNode = base::EndPoint>
struct ClientContext {
public:
    ClientContext() : timeout_ms(gaiadb::common::FLAGS_gaia_call_timeout_ms) {}
    FUNC_MOCK ~ClientContext() {}

    const ServerNode& current_server() const {
        static const ServerNode empty_node = ServerNode();
        return idx < servers.size() ? servers[idx] : empty_node;
    }

    bool Retryable() const {
        return idx < servers.size();
    }

    bool RetryNext() {
        return ++idx < servers.size();
    }

    brpc::Controller* controller {nullptr};
    Request request {};
    Response response {};
    int64_t begin_time {0};
    int64_t latency_us {0};

    typename std::vector<ServerNode> servers {};
    typename std::vector<ServerNode>::size_type idx {0};

    uint64_t log_id {0};
    int timeout_ms {0};
    RpcStatus status {RpcCode::kCntlFailed};
};

using RpcGetPageServerCtx = ClientContext<gaiapb::GetPageServerRequest, gaiapb::GetPageServerResponse>;
using RpcGetLowestCtx = ClientContext<gaiapb::EmptyMessage, gaiapb::GetLowestPointResponse>;
using RpcGetAllSpaceCtx = ClientContext<gaiapb::EmptyMessage, gaiapb::GetAllSpaceIdsResponse>;
using RpcBatchGetLogServiceCtx = ClientContext<gaiapb::LogServiceBatchGetRequest, gaiapb::LogServiceBatchGetResponse>;
using RpcGetSpaceMetaCtx = ClientContext<gaiapb::GetSpaceMetaRequest, gaiapb::GetSpaceMetaResponse>;
using RpcGetSpaceExtentMapCtx = ClientContext<gaiapb::GetSpaceExtentMapRequest, gaiapb::GetSpaceExtentMapResponse>;
using RpcGetSegmentCtx = ClientContext<gaiapb::GetSegmentRequest, gaiapb::GetSegmentResponse>;
using RpcListSegmentCtx = ClientContext<gaiapb::ListSegmentRequest, gaiapb::ListSegmentResponse>;
using RpcUpdateReplicaRecoveryStatusCtx = ClientContext<gaiapb::UpdateReplicaRecoveryStatusRequest, gaiapb::AckResponse>;
using RpcReadPageCtx = ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>;
using RpcReadCtx = ClientContext<pspb::ReadRequest, pspb::ReadResponse, gaiadb::common::PeerZone>;
using RpcRbioCtx = ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
using RpcPageServerHeartbeatCtx = ClientContext<gaiapb::PageServerHeartbeatRequest, gaiapb::HeartbeatResponse>;
using RpcBatchPageServerHeartbeatCtx = ClientContext<gaiapb::BatchPageServerHeartbeatRequest, gaiapb::BatchPageServerHeartbeatResponse>;
using RpcWritePageCtx = ClientContext<pspb::WritePageRequest, pspb::WritePageResponse>;
using RpcGetLogCtx = ClientContext<lspb::psrv_get_log_request, lspb::psrv_get_log_response, gaiadb::common::PeerZone>;
using RpcBatchGetLogCtx = ClientContext<lspb::batch_psrv_get_log_request, lspb::batch_psrv_get_log_response, gaiadb::common::PeerZone>;
using RpcSetReplicaRecovery = ClientContext<gaiapb::SetReplicaRecoveryRequest, gaiapb::SetReplicaRecoveryResponse>;
using RpcGetRedoRecLog = ClientContext<pspb::GetRedoRecLogRequest, pspb::GetRedoRecLogResponse, gaiadb::common::PeerZone>;

template<typename Request, typename Response, typename Error, typename ServerNode = base::EndPoint>
void try_update_leader(ClientContext<Request, Response, ServerNode>* rpc_ctx, Error code) {
    if (rpc_ctx->status.IsOk()
            && rpc_ctx->response.status().code() == code
            && rpc_ctx->response.status().has_leader_hint()) {
        const auto& leader_pb = rpc_ctx->response.status().leader_hint();
        base::EndPoint leader = base::EndPoint(base::int2ip(leader_pb.ip()), leader_pb.port());
        auto idx = rpc_ctx->idx + 2;
        for (; idx < rpc_ctx->servers.size(); ++idx) {
            if (rpc_ctx->servers[idx] == leader) {
                std::swap(rpc_ctx->servers[idx], rpc_ctx->servers[rpc_ctx->idx + 1]);
                break;
            }
        }
    }
}

template<typename Request, typename Response>
bool rpc_failed(ClientContext<Request, Response>* rpc_ctx, bool* not_exists, bool* rpc_ok = nullptr) {
    *not_exists = false;
    if (rpc_ok) {
        *rpc_ok = false;
    }
    if (!rpc_ctx->status.IsOk()) {
        LOG(WARNING) << "rpc failed,"
            << " server:[" << rpc_ctx->current_server()
            << "] rpc_st:[" << rpc_ctx->status
            << "] req_type:[" << rpc_ctx->request.GetDescriptor()->name()
            << "] rsp_type:[" << rpc_ctx->response.GetDescriptor()->name()
            << "] req:[" << pb2jsonstr(rpc_ctx->request)
            << "]";
        return true;
    }

    if (rpc_ok) {
        *rpc_ok = true;
    }
    if (rpc_ctx->response.status().code() != gaiadb::GIE_OK) {
        LOG_IF(WARNING, (rpc_ctx->response.status().code() != gaiadb::GIE_REDIRECT
                && rpc_ctx->response.status().code() != gaiadb::GIE_NOT_EXIST))
            << "rpc rsp failed,"
            << " server:[" << rpc_ctx->current_server()
            << "] rsp_st:[ " << rpc_ctx->response.status()
            << "] req_type:[" << rpc_ctx->request.GetDescriptor()->name()
            << "] rsp_type:[" << rpc_ctx->response.GetDescriptor()->name()
            << "] req:[" << pb2jsonstr(rpc_ctx->request)
            << "]";
        try_update_leader(rpc_ctx, gaiadb::GIE_REDIRECT);
        *not_exists = rpc_ctx->response.status().code() == gaiadb::GIE_NOT_EXIST;
        return true;
    }

    return false;
}


class Client {
public:
    Client();
    FUNC_MOCK ~Client() {}

    void Stop(bool join) {
        _stopped = true;
        while (join && _inflight_req_count.load() > 0) {
            LOG(NOTICE) << "wait rpc join, inflight_size:[" << _inflight_req_count.load() << "]";
            sleep_for(millisecond2microseconds(gaiadb::common::FLAGS_gaia_call_timeout_ms / 4 + 1));
        }
    }

    template <typename ServiceStub, typename Request, typename Response, typename ServerNode = base::EndPoint>
    void Call(std::shared_ptr<RpcClient> rpc_client,
            void (ServiceStub::*method)(ggpb::RpcController*, const Request*, Response*, ggpb::Closure*),
            ClientContext<Request, Response, ServerNode>* client_ctx,
            ggpb::Closure* closure) {
        client_ctx->latency_us = 0;
        if (client_ctx->log_id == 0) {
            client_ctx->log_id = _log_id.fetch_add(1, std::memory_order_relaxed);
        }
        if (client_ctx->idx >= client_ctx->servers.size()) {
            client_ctx->status.Reset(RpcCode::kInvalidArgs, "idx over size");
            if (closure) {
                closure->Run();
            }
            return;
        }
        if (!_stopped) {
            _inflight_req_count.fetch_add(1, std::memory_order_relaxed);
            client_ctx->begin_time = base::cpuwide_time_us();
            ggpb::Closure* rpc_closure = nullptr;
            if (closure) {
                rpc_closure = brpc::NewCallback(this, &Client::template OnCall<Request, Response, ServerNode>,
                        client_ctx, closure);
            }
            if (client_ctx->controller) {
                client_ctx->controller->set_log_id(client_ctx->log_id);
                if (client_ctx->timeout_ms) {
                    client_ctx->controller->set_timeout_ms(client_ctx->timeout_ms);
                }
                rpc_client->Call(client_ctx->controller, client_ctx->current_server(), method,
                        &client_ctx->request, &client_ctx->response,
                        rpc_closure);
            } else {
                rpc_client->Call(client_ctx->log_id, client_ctx->current_server(), method,
                        &client_ctx->request, &client_ctx->response,
                        rpc_closure, &client_ctx->status, client_ctx->timeout_ms);
            }
            if (!closure) {
                OnCall(client_ctx, closure);
            }
        } else {
            client_ctx->status.Reset(RpcCode::kOtherError, "client stopped");
            if (closure) {
                closure->Run();
            }
        }
    }

    FUNC_MOCK void GetSegmentInfo(RpcGetPageServerCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void GetLowestLsn(RpcGetLowestCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void ListLogService(RpcBatchGetLogServiceCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void GetAllSpace(RpcGetAllSpaceCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void GetSpaceMeta(RpcGetSpaceMetaCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void GetSpaceExtentMap(RpcGetSpaceExtentMapCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void ListSegmentReplica(RpcGetSegmentCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void ListSegment(RpcListSegmentCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void UpdateReplicaRecoveryStatus(RpcUpdateReplicaRecoveryStatusCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void ReadPhysicalPage(RpcReadPageCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void Read(RpcReadCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void Rbio(RpcRbioCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void Heartbeat(RpcPageServerHeartbeatCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void BatchHeartbeat(RpcBatchPageServerHeartbeatCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void WritePhysicalPages(RpcWritePageCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void GetLog(RpcGetLogCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void BatchGetLog(RpcBatchGetLogCtx* ctx, ggpb::Closure* closure);
    FUNC_MOCK void SetReplicaRecovery(RpcSetReplicaRecovery* ctx, ggpb::Closure* closure);
    FUNC_MOCK void GetRedoRecLog(RpcGetRedoRecLog* ctx, ggpb::Closure* closure);

private:
    template <typename Request, typename Response, typename ServerNode = base::EndPoint>
    void OnCall(ClientContext<Request, Response, ServerNode>* client_ctx,
            ggpb::Closure* closure) {
        _inflight_req_count.fetch_sub(1, std::memory_order_relaxed);
        client_ctx->latency_us = base::cpuwide_time_us() - client_ctx->begin_time;
        if (client_ctx->controller) {
            client_ctx->status.code = RpcCode::kSuccess;
            if (client_ctx->controller->Failed()) {
                client_ctx->status.Reset(RpcCode::kCntlFailed, "Rpc exec failed:(%d, %s)",
                        client_ctx->controller->ErrorCode(), client_ctx->controller->ErrorText().c_str());
            }
        }
        if (closure) {
            closure->Run();
        }
    }

private:
    volatile bool _stopped;
    std::atomic<int64_t> _inflight_req_count;
    std::atomic<int64_t> _log_id;
    std::shared_ptr<RpcClient> _rpc_client;
};

}
