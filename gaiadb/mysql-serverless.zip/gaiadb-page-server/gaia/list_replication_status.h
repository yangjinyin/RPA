/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_replication_status.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gaiadb/proto/replication/replication.pb.h>
#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ListReplicationStatus : public Command {
public:
    ListReplicationStatus() {
        SetName("list-replication-status");
        SetDesc("list replications information");
        SetDescCn("列出热活集群中复制节点的状态和信息");

        AddClusterAndNodeOptions();
        AddRequiredArgOption("cluster-id", NULL, 'c',
                "list only replications matched by the cluster id",
                kstring, kGroup2Scope);

        AddExample("--cluster-addr bns://xxx");
        AddExample("-a 127.0.0.1 -p 8000");
        AddExample("-a 127.0.0.1 -p 8000 -c gaia_xxx");
    }
    virtual ~ListReplicationStatus() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 'C':
            _cluster_addr = opt;
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    void Done(replicate::pb::ListReplicatorResponse* rsp, RpcStatus* status);

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const replicate::pb::GetReplicatorResponse& rsp);
    int Format(const replicate::pb::ListReplicatorResponse& rsp);
    int Format(const replicate::pb::BatchListReplicatorResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_addr {};
    std::string _cluster_id {};
    std::atomic<uint64_t> _task_count {0};
};

}
}
