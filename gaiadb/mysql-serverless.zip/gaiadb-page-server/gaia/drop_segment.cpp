/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/drop_segment.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/drop_segment.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int DropSegment::Run() {
    RpcStatus status;
    gaiapb::DropSegmentRequest request;
    gaiapb::AckResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_segment_id < 1) {
        print_error("miss --segment-id or error, %u", _segment_id);
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Drop this segment?");
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    request.set_segment_id(_segment_id);
    request.set_log_id(_log_id);
    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::drop_segment, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " drop segment failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("drop failed, all nodes failed");
    return Output(response);
}

int DropSegment::Format(const gaiapb::AckResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
