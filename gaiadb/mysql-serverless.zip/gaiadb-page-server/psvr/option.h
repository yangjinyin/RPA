/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/option.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <getopt.h>

namespace psvr {

#define PSVR_ARGS_OPTION_END      \
    { NULL, 0, NULL, 0}

inline const char* build_short_options(const struct option* opts) {
    static char stopts[256];     // short optons
    char *p = nullptr;
    const struct option* opt;
    p = stopts;
    for (opt = (opts); opt->name; ++opt) {
        if (!opt->flag) {
            *p++ = opt->val;
            if (opt->has_arg) {
                *p++ = ':';
            }
        }
    }
    *p = '\0';
    return stopts;
}

}
