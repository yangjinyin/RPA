/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_compute_node.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ListComputeNode : public Command {
public:
    ListComputeNode() {
        SetName("list-compute-node");
        SetDesc("list all or one compute node information in cluster");
        SetDescCn("列出集群中所有或指定计算节点的信息");

        AddPsmClusterOption();
        AddRequiredArgOption("addr", &_long_opt_val, kOptMax + 1,
                "show information if the specified node exists", kip_port, kGroup2Scope);

        AddExample("--manager-address \"bns://xxx\"");
        AddExample("--manager-address \"bns://xxx\" --addr 0.0.0.0:8888");
    }
    virtual ~ListComputeNode() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _addr = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::ComputeNodeResponse& rsp);
    int Format(const gaiapb::ComputeNodeBatchGetResponse& rsp);

private:
    std::string _manager_address {};
    std::string _addr {};
};

}
}
