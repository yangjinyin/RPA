/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_gc.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/recover_context.h"
#include "test/test_util.h"

namespace psvr {
namespace test {

class MockFlowControl : public Recoverer::FlowControl {
public:
    MockFlowControl() : FlowControl("test", 1, &total_limit, &store_limit) {}
    virtual ~MockFlowControl() {}

    MOCK_METHOD2(GetQuota, uint64_t(int64_t, int32_t));
    MOCK_METHOD3(GetQuota, bool(Recoverer::QuotaThreadTypePtr, Recoverer::Context*, int32_t));

private:
    int64_t total_limit;
    int64_t store_limit;
};

class MockFlowQuota : public FlowQuota {
public:
    MockFlowQuota() : FlowQuota(&total_limit) {}
    ~MockFlowQuota() {}

    MOCK_METHOD1(GetQuota, uint64_t(int64_t));

private:
    int64_t total_limit;
};

class MockRecoverer : public Recoverer {
public:
    MockRecoverer(ClientPtr client, ControlWeakPtr control) : Recoverer(client, control) {}
    virtual ~MockRecoverer() {}

    void MockDispatch(SegmentPtr, brpc::Controller*, const pspb::ReadPageRequest*,
            pspb::ReadPageResponse* response, ggpb::Closure* closure) {
        response->mutable_status()->set_code(pspb::Status::SUCCESS);
        if (closure) {
            closure->Run();
        }
    }

    void MockDispatch2(SegmentPtr, brpc::Controller*, const pspb::ReadRequest*,
            pspb::ReadResponse* response, ggpb::Closure* closure) {
        response->mutable_status()->set_code(pspb::Status::SUCCESS);
        if (closure) {
            closure->Run();
        }
    }

    MOCK_METHOD1(Start, bool(uint32_t));
    TRACE_MOCK_METHOD3(Dispatch, bool(SegmentPtr, bool, bool TRACE_FILE_LINE_DTC));
    MOCK_METHOD5(Dispatch, void(SegmentPtr, brpc::Controller*, const pspb::ReadPageRequest*, pspb::ReadPageResponse*, ggpb::Closure*));
    MOCK_METHOD5(Dispatch, void(SegmentPtr, brpc::Controller*, const pspb::ReadRequest*, pspb::ReadResponse*, ggpb::Closure*));
    MOCK_METHOD5(Dispatch, void(SegmentPtr, brpc::Controller*, const pspb::GetRedoRecLogRequest*, pspb::GetRedoRecLogResponse*, ggpb::Closure*));
    MOCK_METHOD5(Dispatch, void(SegmentPtr, brpc::Controller*, const pspb::WritePhysicalPageRequest*, pspb::WritePhysicalPageResponse*, ggpb::Closure*));
    MOCK_METHOD1(GetRecoveryInfo, void(pspb::ListRecoveryInfoResponse*));
    MOCK_METHOD1(Execute, bool(Recoverer::Context*));

};

}
}
