#pragma once

#ifdef ENABLED_GAIADB_PAGE_VALIDATION
// numPage + end_lsn + numPage*(space id + page no + page size + page checksum +
// page_data_offset) + data checksum(4bytes)
#define PAGE_VALIDATION_TOTAL_SIZE(num_page) 4 + 8 + num_page *(4 + 4 + 4 + 4 + 8) + 4;
#endif

namespace rpl {

#ifdef ENABLED_GAIADB_PAGE_VALIDATION
extern File rpl_page_validation_file_fd;

void rpl_page_validator();

void debug_for_buf_hexdump(const char *name, const void *buf, ulint size);

bool page_validator_init();

bool page_validator_is_active();

void start_page_validator_thread();
#endif

#ifdef UNIV_DEBUG
#include "os0file.h"

os_file_t rpl_redo_tmp_file = -100;
lsn_t rpl_write_redo_start_lsn = 0;
char rpl_redo_temp_buf[OS_FILE_LOG_BLOCK_SIZE]
    __attribute__((__aligned__(OS_FILE_LOG_BLOCK_SIZE)));

void fetcher_write_redo_block(const byte *log_block, lsn_t start_lsn) {
  if (rpl_redo_tmp_file == -100) {
    std::string redo_tmp_filename = "redo_tmp_file";
    char *redo_tmp_file_name = Fil_path::make(MySQL_datadir_path.path().c_str(),
                                              redo_tmp_filename, NO_EXT);
    rpl_redo_tmp_file = ::open(
        redo_tmp_file_name, O_CREAT | O_TRUNC | O_WRONLY | O_DIRECT, S_IRWXU);
    if (rpl_redo_tmp_file == -1) {
      ib_error(ER_IB_GAIA_MSG_RPL)
          << "Failed to create rpl_redo_tmp_file errno:" << errno
          << " Please confirm O_DIRECT is"
          << " supported and remove the file " << redo_tmp_file_name
          << " if it exists.";
      errno = 0;
    }
    ut::free(redo_tmp_file_name);
  }

  if (rpl_redo_tmp_file == -1) return;

  if (rpl_write_redo_start_lsn == 0) {
    rpl_write_redo_start_lsn = start_lsn;
  }

  std::memcpy(rpl_redo_temp_buf, log_block, OS_FILE_LOG_BLOCK_SIZE);
  // pwrite with O_DIRECT requires  the rpl_redo_temp_buf to be aligned to a
  // 512-byte address
  auto ret =
      pwrite(rpl_redo_tmp_file, rpl_redo_temp_buf, OS_FILE_LOG_BLOCK_SIZE,
             start_lsn - rpl_write_redo_start_lsn);
  if (ret < 0) {
    ib_error(ER_IB_GAIA_MSG_RPL)
        << "fetcher_write_redo_block, write falied, errno=" << errno
        << ", start_lsn=" << start_lsn
        << ", rpl_write_redo_start_lsn=" << rpl_write_redo_start_lsn;
  }
}

#endif /*UNIV_DEBUG*/

} // namespace rpl
