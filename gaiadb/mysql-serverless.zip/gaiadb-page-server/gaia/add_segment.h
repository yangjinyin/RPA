/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/add_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class AddSegment : public Command {
public:
    AddSegment() {
        SetName("add-segment");
        SetDesc("add a new segment metadata to cluster");
        SetDescCn("向集群添加新的分片元数据");

        AddPsmClusterOption();
        AddRequiredArgOption("task-id", &_long_opt_val, kOptMax + 1,
                "the segment unique task id", kuint64_t,
                kOnlyMultiPSScope | kGroup1Scope);
        AddRequiredArgOption("replica", &_long_opt_val, kOptMax + 2, "list of replicas endpoint information", kip_port);
        AddZoneOption();
        
        AddExample("--manager-address \"bns://xxx\" --replica <ip:port> --replica <ip:port> ...");
        AddExample("--manager-address \"bns://xxx\" -m --task-id 1000 --replica <ip:port> --replica <ip:port> ...");
        AddExample("--manager-address \"bns://xxx\" --replica <ip:port>"
                " --region bjdd --available-zone 1"
                " --replica <ip:port> --region bjdd --available-zone 2 ...");
    }
    virtual ~AddSegment() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptRegion:
                _regions.push_back(opt);
                break;
            case kOptAvailableZone:
                _available_zones.push_back(opt);
                break;
            case kOptMax + 1:
                _task_id = std::strtoull(opt, NULL, 10);
                break;
            case kOptMax + 2:
                _replicas.push_back(opt);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::AddSegmentResponse& rsp);

private:
    std::string _manager_address {};
    uint64_t _task_id {0};
    std::vector<std::string> _replicas;
    std::vector<std::string> _regions;
    std::vector<std::string> _available_zones;
};

}
}
