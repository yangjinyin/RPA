/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/transfer_raft_leader.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <raft/cli.pb.h>
#include "gaia/command.h"

namespace psvr {
namespace gaia {

class TransferRaftLeader : public Command {
public:
    TransferRaftLeader() {
        SetName("transfer-raft-leader");
        SetDesc("transfer leader from raft group");
        SetDescCn("转移 Raft 组的 Leader 节点");

        AddPsmClusterOption();
        AddRequiredArgOption("group-id", &_long_opt_val, kOptMax + 1,
                "raft group id: (gaiadb-manager, log-service, table-server)",
                kenum);
        AddRequiredArgOption("leader-id", &_long_opt_val, kOptMax + 2, "raft new leader", kstring);

        AddExample("--manager-address \"bns://xxx\" --group-id xxx --leader-id 127.0.0.0:1111");
    }
    virtual ~TransferRaftLeader() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _group_id = opt;
                break;
            case kOptMax + 2:
                _new_leader_id = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const raft::TransferLeaderResponse& rsp);

private:
    std::string _manager_address {};
    std::string _group_id {};
    std::string _new_leader_id {};
};

}
}
