/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/page_op.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gaiadb/utils/crc32.h>
#include <psvr0meta.h>
#include <psvr0page.h>
#include <psvr0recv.h>    // recv_parse_log_rec
#include "psvr/buf.h"
#include "psvr/status.h"

namespace psvr {

struct LogRecord;

db::Status page_apply_log_record(const LogRecord& record,
        BufBlockPtr buf_block, gaia_apply::lsn_t* page_lsn);

uint32_t calc_page_crc32(const gaia_apply::byte* page);

bool check_page_crc32(const gaia_apply::byte* const page,
        gaia_apply::ulint crc1, gaia_apply::ulint crc2);


bool page_reset_checksum(gaia_apply::byte* page, uint64_t logical_size,
        gaia_apply::space_id_t space_id, gaia_apply::page_no_t page_no,
        gaia_apply::lsn_t newest_lsn);

bool buf_block_reset_checksum(gaia_apply::buf_block_t* block, gaia_apply::lsn_t newest_lsn);

inline bool buf_block_reset_checksum(BufBlockPtr block, gaia_apply::lsn_t newest_lsn) {
    return buf_block_reset_checksum(block.get(), newest_lsn);
}

bool page_is_corrupted(const gaia_apply::byte* page, gaia_apply::uint logical_size, bool* is_empty);

inline bool buf_block_is_corrupted(BufBlockPtr block, bool* is_empty) {
    return page_is_corrupted(block->frame, block->page.size.logical(), is_empty);
}
inline bool buf_block_is_corrupted(gaia_apply::buf_block_t* block, bool* is_empty) {
    return page_is_corrupted(block->frame, block->page.size.logical(), is_empty);
}

inline gaia_apply::lsn_t page_get_page_lsn(const gaia_apply::page_t* page) {
    return gaia_apply::mach_read_from_8(page + gaia_apply::FIL_PAGE_LSN);
}
inline gaia_apply::lsn_t buf_block_get_page_lsn(BufBlockPtr block) {
    return page_get_page_lsn(block->frame);
}
inline gaia_apply::lsn_t buf_block_get_page_lsn(gaia_apply::buf_block_t* block) {
    return page_get_page_lsn(block->frame);
}

inline gaia_apply::space_id_t buf_block_get_space_id(gaia_apply::buf_block_t* block) {
    return gaia_apply::page_get_space_id(block->frame);
}
inline gaia_apply::space_id_t buf_block_get_space_id(BufBlockPtr block) {
    return buf_block_get_space_id(block.get());
}

inline gaia_apply::page_no_t buf_block_get_page_no(gaia_apply::buf_block_t* block) {
    return gaia_apply::page_get_page_no(block->frame);
}
inline gaia_apply::page_no_t buf_block_get_page_no(BufBlockPtr block) {
    return buf_block_get_page_no(block.get());
}

inline void page_set_page_lsn(gaia_apply::page_t* page,
        uint64_t page_size, gaia_apply::lsn_t lsn) {
    gaia_apply::mach_write_to_8(page + gaia_apply::FIL_PAGE_LSN, lsn);
    gaia_apply::mach_write_to_8(page + (page_size - gaia_apply::FIL_PAGE_END_LSN_OLD_CHKSUM), lsn);
}
inline void buf_block_set_page_lsn(BufBlockPtr block, gaia_apply::lsn_t lsn) {
    page_set_page_lsn(block->frame, block->page.size.logical(), lsn);
}
inline void buf_block_set_page_lsn(gaia_apply::buf_block_t* block, gaia_apply::lsn_t lsn) {
    page_set_page_lsn(block->frame, block->page.size.logical(), lsn);
}

inline bool check_page_space(gaia_apply::page_t* page, bool is_init,
        gaia_apply::space_id_t expect_space_id, gaia_apply::page_no_t expect_page_no,
        gaia_apply::space_id_t* origin_space_id = nullptr,
        gaia_apply::page_no_t* origin_page_no = nullptr) {
    if (is_init) {
        return true;
    }
    auto space_id = gaia_apply::page_get_space_id(page);
    auto page_no = gaia_apply::page_get_page_no(page);
    if (origin_space_id) {
        *origin_space_id = space_id;
        if (origin_page_no) {
            *origin_page_no = page_no;
        }
    }
    return page_no == expect_page_no && space_id == expect_space_id;
}

inline bool check_buf_block_page_space(gaia_apply::buf_block_t* block, bool is_init,
        gaia_apply::space_id_t* origin_space_id = nullptr,
        gaia_apply::page_no_t* origin_page_no = nullptr) {
    const gaia_apply::page_id_t& page_id = block->page.id;
    return check_page_space(block->frame, is_init, page_id.space(), page_id.page_no(),
            origin_space_id, origin_page_no);
}
inline bool check_buf_block_page_space(BufBlockPtr block, bool is_init,
        gaia_apply::space_id_t* origin_space_id = nullptr,
        gaia_apply::page_no_t* origin_page_no = nullptr) {
    return check_buf_block_page_space(block.get(), is_init, origin_space_id, origin_page_no);
}

inline gaia_apply::ulint psvr_recv_parse_log_rec(gaia_apply::mlog_id_t* type,
        gaia_apply::byte* ptr, gaia_apply::byte* end_ptr,
        gaia_apply::space_id_t* space_id, gaia_apply::page_no_t* page_no,
        gaia_apply::byte** body,
        uint32_t* check_bits_len APPLY_ARG_CC,
        bool* found_corrupt_log) {
    return gaia_apply::recv_parse_log_rec(type, ptr, end_ptr,
            space_id, page_no, body, check_bits_len APPLY_ARG_NAME_CC, found_corrupt_log);
}

inline void init_buf_block(gaia_apply::buf_block_t* block,
        gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no,
        const gaia_apply::page_size_t& page_size) {
    block->page.id.reset(space_id, page_no);
    block->page.size.copy_from(page_size);
    block->page.newest_modification = 0;
    block->page.oldest_modification = 0;
    block->page.zip.data = nullptr;
}

inline void init_buf_block(BufBlockPtr block,
        gaia_apply::space_id_t space_id,
        gaia_apply::page_no_t page_no,
        const gaia_apply::page_size_t& page_size) {
    return init_buf_block(block.get(), space_id, page_no, page_size);
}

}
