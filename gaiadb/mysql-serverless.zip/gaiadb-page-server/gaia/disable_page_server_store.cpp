/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/disable_page_server_store.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/disable_page_server_store.h"

namespace psvr {
namespace gaia {

int DisablePageServerStore::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    if (_store_id < 0) {
        print_error("miss or error --id");
        return 1;
    }
    if (_store_path.empty()) {
        print_error("miss --path");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error\n");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Disable this store:[id=%u,path=%s]?", _store_id, _store_path.c_str());
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    RpcStatus status;
    pspb::DisableStoreRequest request;
    pspb::DisableStoreResponse response;

    request.set_log_id(_log_id);
    request.set_store_id(_store_id);
    request.set_store_path(_store_path);

    _client.Call(_log_id++, node, &pspb::ManagerService_Stub::DisableStore, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int DisablePageServerStore::Format(const pspb::DisableStoreResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
