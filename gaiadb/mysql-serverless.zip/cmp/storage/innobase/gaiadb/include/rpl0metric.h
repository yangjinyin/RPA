/*****************************************************************************

Copyright (c) 2013, 2019, Oracle and/or its affiliates. All rights reserved.

Portions of this file contain modifications contributed and copyrighted by
Google, Inc. Those modifications are gratefully acknowledged and are described
briefly in the InnoDB documentation. The contributions by Google are
incorporated with their permission, and subject to the conditions contained in
the file COPYING.Google.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/**************************************************/ /**
 @file include/rpl0metric.h

 Rpl system metrics

 Created 2023-02-02
 Authors: wanglonglong01@baidu.com
 *******************************************************/

#pragma once

#include "bvar/bvar.h"

namespace rpl {

const char *const prefix = "cmp_rpl";

struct RplMetric;
extern RplMetric *g_rpl_metric;

DECLARE_int32(rpl_metric_window_s);

extern uint64_t get_fetch_get_log_bw(void*);

#define INIT_LATENCY_RECORD(var) var(prefix, #var)

#define CONCAT_(a, b) a##b
#define CONCAT(a, b) CONCAT_(a, b)
#define WINDOW_SUFFIX _w
#define WINDOW_VAR(name) CONCAT(name, WINDOW_SUFFIX)

#define INIT_WINDOW_VAR(var) \
  WINDOW_VAR(var)(prefix, #var, &var, FLAGS_rpl_metric_window_s)

// performance metric for gaiadb rpl system
struct RplMetric {
  static RplMetric &get_instance() {
    static RplMetric s_rpl_metric;
    return s_rpl_metric;
  }

  RplMetric()
      : INIT_LATENCY_RECORD(apply_batch_size),
        INIT_LATENCY_RECORD(apply_assembly_pick),
        INIT_LATENCY_RECORD(apply_prepare),
        INIT_LATENCY_RECORD(apply_materialize),
        INIT_LATENCY_RECORD(apply_wait_for_materialize),
        INIT_LATENCY_RECORD(apply_commit),
        INIT_WINDOW_VAR(fetch_periods_rpc),
        INIT_WINDOW_VAR(fetch_periods_pick_server),
        INIT_LATENCY_RECORD(fetch_get_log),
        fetch_get_log_bw(prefix, "fetch_get_log_bw", get_fetch_get_log_bw, nullptr),
        INIT_WINDOW_VAR(fetch_error_wait),
        INIT_WINDOW_VAR(fetch_vdl_wait),
        INIT_LATENCY_RECORD(fetch_space_wait),
        INIT_LATENCY_RECORD(fetch_buffer_copy),
        INIT_WINDOW_VAR(fetch_lsn_diff_vdl),
        INIT_LATENCY_RECORD(parse_assembly_wait),
        INIT_LATENCY_RECORD(parse_batch_wait),
        INIT_LATENCY_RECORD(parse_get_assembly),
        INIT_LATENCY_RECORD(parse_copy_buffer),
        INIT_LATENCY_RECORD(parse_batch_work),
        INIT_WINDOW_VAR(parse_wait_more_data),
        INIT_LATENCY_RECORD(parse_advance),
        INIT_WINDOW_VAR(parse_lsn_diff_fetch_lsn),
        INIT_LATENCY_RECORD(update_lowest),
        INIT_LATENCY_RECORD(gc),
        INIT_WINDOW_VAR(gc_2_parse_index_gap),
        INIT_WINDOW_VAR(gc_2_apply_index_gap),
        INIT_WINDOW_VAR(gc_2_parse_lsn_gap),
        INIT_WINDOW_VAR(gc_2_apply_lsn_gap),
        INIT_LATENCY_RECORD(recycle_assembly),
        INIT_LATENCY_RECORD(recycle_assembly_check),
        INIT_LATENCY_RECORD(recycle_assembly_wait_ref),
        INIT_LATENCY_RECORD(recycle_assembly_release),
        INIT_WINDOW_VAR(recycle_periods),
        INIT_WINDOW_VAR(force_recycle_count),
        INIT_WINDOW_VAR(behind_master),
        INIT_WINDOW_VAR(parse_behind_master),
        INIT_LATENCY_RECORD(further_rbio_apply),
        INIT_LATENCY_RECORD(further_bp_get_apply) {}

  bvar::LatencyRecorder apply_batch_size;

  bvar::LatencyRecorder apply_assembly_pick;

  bvar::LatencyRecorder apply_prepare;

  bvar::LatencyRecorder apply_materialize;

  bvar::LatencyRecorder apply_wait_for_materialize;

  bvar::LatencyRecorder apply_commit;

  bvar::Adder<uint64_t> fetch_periods_rpc;
  bvar::Window<bvar::Adder<uint64_t>> fetch_periods_rpc_w;

  bvar::Adder<uint64_t> fetch_periods_pick_server;
  bvar::Window<bvar::Adder<uint64_t>> fetch_periods_pick_server_w;

  bvar::LatencyRecorder fetch_get_log;
  bvar::PassiveStatus<uint64_t> fetch_get_log_bw;

  bvar::Adder<uint64_t> fetch_error_wait;
  bvar::Window<bvar::Adder<uint64_t>> fetch_error_wait_w;

  bvar::Adder<uint64_t> fetch_vdl_wait;
  bvar::Window<bvar::Adder<uint64_t>> fetch_vdl_wait_w;

  bvar::LatencyRecorder fetch_space_wait;

  bvar::LatencyRecorder fetch_buffer_copy;

  bvar::Maxer<uint64_t> fetch_lsn_diff_vdl;
  bvar::Window<bvar::Maxer<uint64_t>> fetch_lsn_diff_vdl_w;

  bvar::LatencyRecorder parse_assembly_wait;

  bvar::LatencyRecorder parse_batch_wait;

  bvar::LatencyRecorder parse_get_assembly;

  bvar::LatencyRecorder parse_copy_buffer;

  bvar::LatencyRecorder parse_batch_work;

  bvar::Adder<uint64_t> parse_wait_more_data;
  bvar::Window<bvar::Adder<uint64_t>> parse_wait_more_data_w;

  bvar::LatencyRecorder parse_advance;

  bvar::Maxer<uint64_t> parse_lsn_diff_fetch_lsn;
  bvar::Window<bvar::Maxer<uint64_t>> parse_lsn_diff_fetch_lsn_w;

  bvar::LatencyRecorder update_lowest;

  bvar::LatencyRecorder gc;

  bvar::Maxer<uint64_t> gc_2_parse_index_gap;
  bvar::Window<bvar::Maxer<uint64_t>> gc_2_parse_index_gap_w;

  bvar::Maxer<uint64_t> gc_2_apply_index_gap;
  bvar::Window<bvar::Maxer<uint64_t>> gc_2_apply_index_gap_w;

  bvar::Maxer<uint64_t> gc_2_parse_lsn_gap;
  bvar::Window<bvar::Maxer<uint64_t>> gc_2_parse_lsn_gap_w;

  bvar::Maxer<uint64_t> gc_2_apply_lsn_gap;
  bvar::Window<bvar::Maxer<uint64_t>> gc_2_apply_lsn_gap_w;

  bvar::LatencyRecorder recycle_assembly;

  bvar::LatencyRecorder recycle_assembly_check;

  bvar::LatencyRecorder recycle_assembly_wait_ref;

  bvar::LatencyRecorder recycle_assembly_release;

  bvar::Adder<uint64_t> recycle_periods;
  bvar::Window<bvar::Adder<uint64_t>> recycle_periods_w;

  bvar::Adder<uint64_t> force_recycle_count;
  bvar::Window<bvar::Adder<uint64_t>> force_recycle_count_w;

  bvar::Maxer<uint64_t> behind_master;
  bvar::Window<bvar::Maxer<uint64_t>> behind_master_w;

  bvar::Maxer<uint64_t> parse_behind_master;
  bvar::Window<bvar::Maxer<uint64_t>> parse_behind_master_w;

  bvar::LatencyRecorder further_rbio_apply;

  bvar::LatencyRecorder further_bp_get_apply;
};

}  // namespace rpl

