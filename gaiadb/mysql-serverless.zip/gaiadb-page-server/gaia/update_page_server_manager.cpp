/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_page_server_manager.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/update_page_server_manager.h"

namespace psvr {
namespace gaia {

int UpdatePageServerManager::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    RpcStatus status;
    if (!_multi_type) {
        if (_segments.size()) {
            print_error("--multi-segment is disable in single type");
            return 1;
        }
        if (_manager_address.empty()) {
            print_error("miss --manager-address");
            return 1;
        }
        if ((_cluster_id.size() && !_segment_id.has_val)
                || (_cluster_id.empty() && _segment_id.has_val)) {
            print_error("--cluster-id and --segment-id should always appear in pairs in single type");
            return 1;
        }
        if (_segment_id.has_val && _segment_id.val < 1) {
            print_error("error --segment-id:%u", _segment_id.val);
            return 1;
        }

        pspb::ModifyManagerRequest request;
        pspb::ModifyManagerResponse response;
        request.set_log_id(_log_id);
        request.set_manager_address(_manager_address);
        if (_cluster_id.size()) {
            request.set_cluster_id(_cluster_id);
            request.set_segment_id(_segment_id.val);
            if (!_force) {
                bool cf_ret = execute_confirm("Update segment[cluster=%s, id=%u] manager?", _cluster_id.c_str(), _segment_id.val);
                if (!cf_ret) {
                    printf("quit!\n");
                    return 1;
                }
            }
        } else {
            if (!_force) {
                bool cf_ret = execute_confirm("Update page server[%s:%d] manager?", _address.c_str(), _port);
                if (!cf_ret) {
                    printf("quit!\n");
                    return 1;
                }
            }
        }
        _client.Call(_log_id++, node, &pspb::ManagerService_Stub::ModifyManagerAddr, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }
        return Output(response);
    }

    if (_segments.empty() && _cluster_id.empty()) {
        print_error("miss --multi-segment or --cluster-id");
        return 1;
    }

    if (_segments.size() && _cluster_id.size()) {
        print_error("choice one between --multi-segment and --cluster-id");
        return 1;
    }

    pspb::MultiModifyManagerRequest request;
    pspb::MultiModifyManagerResponse response;
    request.set_log_id(_log_id);
    if (_segments.size()) {
        std::string error;
        ret = JsonToProtoMessage(_segments, &request, &error);
        if (!ret) {
            print_error("--multi-segment convert to json error, %s", error.c_str());
            return 1;
        }
    } else {
        if (_manager_address.empty()) {
            print_error("miss --manager-address");
            return 1;
        }
        auto segment_pb = request.add_segments();
        segment_pb->set_manager_address(_manager_address);
        segment_pb->set_cluster_id(_cluster_id);
        if (_segment_id.has_val) {
            if (_segment_id.val < 1) {
                print_error("error --segment-id:%u", _segment_id.val);
                return 1;
            }
            segment_pb->set_segment_id(_segment_id.val);
        }
    }
    if (!_force) {
        bool cf_ret = execute_confirm("Update segment manager?");
        if (!cf_ret) {
            return 1;
        }
    }
    _client.Call(_log_id++, node, &pspb::ManagerService_Stub::MultiModifyManager, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int UpdatePageServerManager::Format(const pspb::ModifyManagerResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

int UpdatePageServerManager::Format(const pspb::MultiModifyManagerResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.segments_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({"cluster_id", "segment_id", "status"}, true);
        for (int32_t i = 0; i < rsp.segments_size(); ++i) {
            const auto& seg_pb = rsp.segments(i);
            if (seg_pb.status().code() != pspb::Status_ReturnCode_SUCCESS) {
                table.AddRowsValue({
                        seg_pb.cluster_id(),
                        seg_pb.segment_id(),
                        RowStr(pspb::Status_ReturnCode_Name(seg_pb.status().code()),
                               std::string("(") + seg_pb.status().msg() + ")")
                        });
            } else {
                table.AddRowsValue({
                        seg_pb.cluster_id(),
                        seg_pb.segment_id(),
                        "ok"
                        });
            }
        }
        table.Display();
    }
    return 0;
}

}
}
