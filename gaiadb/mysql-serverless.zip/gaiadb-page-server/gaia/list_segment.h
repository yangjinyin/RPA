/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ListSegment : public Command {
public:
    ListSegment() {
        SetName("list-segment");
        SetDesc("list all or one segment information from manager");
        SetDescCn("从管理器列出所有或指定分片的信息");

        AddPsmClusterOption();
        AddRequiredArgOption("segment-id", NULL, 's',
                "show information if the specified id exists",
                kuint32_t, kGroup2Scope);
        AddNoArgOption("not-show-segments", &_long_opt_val, kOptMax + 2, "do not show segments details", kGroup3Scope);

        AddExample("--manager-address \"bns://xxx\"");
        AddExample("--manager-address \"bns://xxx\" --segment-id 1");
        AddExample("--manager-address \"bns://xxx\" --not-show-segments");
    }
    virtual ~ListSegment() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 's':
            _segment_id = std::strtoul(opt, NULL, 10);
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 2:
                _not_show_segments = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::GetSegmentResponse& rsp);
    int Format(const gaiapb::ListSegmentResponse& rsp);

private:
    std::string _manager_address {};
    uint32_t _segment_id {0};
    bool _not_show_segments {false};
};

}
}
