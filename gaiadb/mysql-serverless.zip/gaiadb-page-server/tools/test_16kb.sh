#!/bin/bash

start=$1

if [ -z "$start" ]; then
    echo "sh $0 1"
    exit 1
fi

if [ ! -f ./../output/bin/check_rw16kb ]; then
    echo "not found text exe, ./output/bin/test_16k"
    exit 1
fi

out=./test_16k_page.out

for i in `seq 1 10000`; do
    rm -f $out
    nohup ./../output/bin/test_16k $out 1 >$out.nohup 2>&1 &
    sleep $(($RANDOM%3+1))
    pid=`cat $out.nohup | cut -d: -f2`
    kill $pid
    ./../output/bin/test_16k $out 0
    if [ $? -ne 0 ]; then
        echo "check kill failed";
        exit 1
    fi
    echo "check kill ok, $i"
done

for i in `seq 1 10000`; do
    rm -f $out
    nohup ./../output/bin/test_16k $out 1 >$out.nohup 2>&1 &
    sleep $(($RANDOM%9+1))
    pid=`cat $out.nohup | cut -d: -f2`
    kill -9 $pid
    ./../output/bin/test_16k $out 0
    if [ $? -ne 0 ]; then
        echo "check kill -9 failed";
        exit 1
    fi
    echo "check kill -9 ok, $i"
done
