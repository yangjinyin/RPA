/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/list_page_server_recovery.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ListPageServerRecovery : public Command {
public:
    ListPageServerRecovery() {
        SetName("list-ps-recovery");
        SetDesc("list recovery task or show recovery information from page server");
        SetDescCn("列出存储服务器的恢复任务或恢复信息");

        AddClusterAndNodeOptions();
        AddRequiredArgOption("cluster-id", NULL, 'c',
                "show recovery information of only segments that matches the cluster id",
                kstring, kGroup2Scope);
        AddRequiredArgOption("segment-id", NULL, 's',
                "and match the segment id, if specified", kuint32_t, kGroup2Scope);
        AddRequiredArgOption("multi-segment", &_long_opt_val, kOptMax + 1,
                "in multi type. show recovery information of segments you want",
                kjson, kGroup2Scope | kOnlyMultiPSScope);
        AddNoArgOption("only-running", &_long_opt_val, kOptMax + 2,
                "ignore display wait tasks", kGroup3Scope | kOnlyMultiPSScope);

        AddExample("--cluster-addr bns://xxx");
        AddExample("-a <ip> -p <port>");
        AddExample("-a <ip> -p <port> --cluster-id xx --segment-id 1");
        AddExample("-a <ip> -p <port> -m --cluster-id xx");
        AddExample("-a <ip> -p <port> -m --cluster-id xx --segment-id 1");
        AddExample("-a <ip> -p <port> -m --multi-segment json_data");
    }
    virtual ~ListPageServerRecovery() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtoul(opt, NULL, 10));
            break;
        case 'C':
            _cluster_addr = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _segments = opt;
                break;
            case kOptMax + 2:
                _only_running = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    int RunSpecific();

    void Done(pspb::BatchListRecoveryInfoResponse_ServerStatus* server_status,
            pspb::ListRecoveryInfoResponse* response, RpcStatus* status);

    int Execute(const base::EndPoint& node,
            pspb::ListRecoveryInfoResponse* response, RpcStatus* status, ggpb::Closure* closure);

    void DoneMulti(pspb::BatchMultiGetRecoverInfoResponse_ServerStatus* server_status,
            pspb::MultiGetRecoverInfoResponse* response, RpcStatus* status);
    int Execute(const base::EndPoint& node,
            pspb::MultiGetRecoverInfoResponse* response, RpcStatus* status, ggpb::Closure* closure);

    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const pspb::GetRecoverInfoResponse& rsp);
    int Format(const pspb::MultiGetRecoverInfoResponse& rsp);
    int Format(const pspb::BatchMultiGetRecoverInfoResponse& rsp);
    int Format(const pspb::ListRecoveryInfoResponse& rsp);
    int Format(const pspb::BatchListRecoveryInfoResponse& rsp);
private:
    std::string _cluster_addr {};
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id;
    VarOptional<uint32_t> _segment_id;
    std::string _segments {};
    bool _only_running {false};
    std::atomic<uint64_t> _task_count {0};
};

}
}
