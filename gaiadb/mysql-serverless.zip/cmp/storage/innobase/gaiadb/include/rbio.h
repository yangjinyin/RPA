/*****************************************************************************

Copyright (c) 1995, 2019, Oracle and/or its affiliates. All Rights Reserved.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA
*****************************************************************************/

/** @file include/rbio.h
 client for read remote page block
 *******************************************************/

#ifndef rbio_h
#define rbio_h

#include <base/endpoint.h>
#include <vector>
#include "buf0types.h"
#include "log0types.h"
#include "page0size.h"
#include "gaiadb/proto/page_server/rbio.pb.h"
#include "gaiadb/psm_client/client.h"
#include "fil0fil.h"
#include "gaiadb/utils/rpc_client.hpp"
#include "gaiadb/common/global_flags.h"
#include "gaiadb/common/types.h"
#include "gaiadb/polar/utils.h"
#include <future>
#include <atomic>
#include <gaiadb/utils/thread_pool.hpp>
#include <gaiadb/utils/rpc_backrequest.hpp>

extern std::atomic<ulint> rbio_count;
extern std::atomic<ulonglong> rbio_time_sum;

/* Calculate extent_no and pass it to extent map lib,
@param[in]	space_id	space_id
@param[in]	page_no		page_no
@param[in]	page_size	page_size, by which we get extent_no
@return extent_no, by which we can get segment and ip+port from extent map lib*/
uint32_t extent_no_get(space_id_t space_id, page_no_t page_no,
                       const page_size_t page_size);

class RbioClient;

class RbioRetryPolicy : public baidu::rpc::RetryPolicy {
 public:
  RbioRetryPolicy() {}
  virtual ~RbioRetryPolicy() {}

  virtual bool DoRetry(const baidu::rpc::Controller* cntl) const override;
};

class RbioExlucdePolicy : public gaiadb::common::backup_request::ExlucdePolicy {
 public:
  RbioExlucdePolicy() {}
  virtual ~RbioExlucdePolicy() {}

  virtual int32_t DoExclude(const baidu::rpc::Controller* cntl) const override;
};

void destroy_gaia_backup_request();

namespace gaia {

void aio_init();

void aio_deinit();

constexpr uint8_t AIO_T1 = 1;
constexpr uint8_t AIO_T2 = 2;

struct AIO_cb_1 {
  ulint segment;
  void *slot;
  AIO_cb_1() : segment(0), slot(nullptr) {}
};

struct AIO_cb_2 {
  IORequest type;
  fil_node_t *m1;
  os_offset_t offset;
  byte *ptr;
  void *m2;
  uint64_t start_time;
  AIO_cb_2()
    : type(IORequest::UNSET), m1(nullptr),
    offset(0), ptr(nullptr), m2(nullptr), start_time(0) {}
};

struct AIO_cb : public gaiadb::common::thread::TaskContext {
  uint8_t type;     // 1 or 2
  uint8_t is_ibuf;     // 0 or 1
  union {
    AIO_cb_1 aio1;
    AIO_cb_2 aio2;
  };

  AIO_cb (uint8_t type_, uint8_t is_ibuf_ = 0) : type(type_), is_ibuf(is_ibuf_) {}
};

int aio_executer_cb(void *arg, bthread::TaskIterator<AIO_cb *> &it);

class AIO_Executor {
 public:
  AIO_Executor() {}
  ~AIO_Executor() {}

  bool start(size_t queue_size) {
    bthread::ExecutionQueueOptions options;
    options.max_tasks_size = queue_size;
    return 0 == bthread::execution_queue_start(&m_queue_id,
        &options, aio_executer_cb, nullptr);
  }

  bool stop() {
    return 0 == bthread::execution_queue_stop(m_queue_id);
  }

  bool join() {
    return 0 == bthread::execution_queue_join(m_queue_id);
  }

  bool submit(AIO_cb *aio_cb) {
    return 0 == bthread::execution_queue_execute(m_queue_id, aio_cb);
  }

 private:
  bthread::ExecutionQueueId<AIO_cb *> m_queue_id;
};

class AIO_Executor_Array {
 public:
  AIO_Executor_Array() : m_size(0), m_read_size(0), m_index(0), m_executer_arr() {}
  ~AIO_Executor_Array() {}

  bool init(size_t executer_size, size_t executer_queue_size) {
    ut_ad(executer_size > 0 && executer_queue_size > 0);
    m_executer_arr.resize(executer_size);
    size_t i = 0;
    for (; i < executer_size; ++i) {
      if (!m_executer_arr[i].start(executer_queue_size)) {
        break;
      }
      ++m_size;
    }
    if (executer_size != m_size) {
      deinit();
      m_size = 0;
    }
    m_read_size = m_size > 1 ? (m_size - 1) : m_size;
    return m_size > 0;
  }

  void deinit() {
    for (size_t i = 0; i < m_size; ++i) {
      m_executer_arr[i].stop();
    }
    for (size_t i = 0; i < m_size; ++i) {
      m_executer_arr[i].join();
    }
  }

  AIO_Executor &get_next() {
    return m_executer_arr[m_index++ % m_read_size];
  }

  bool submit(AIO_cb *aio_cb) {
    if (aio_cb->is_ibuf) {
      return  m_executer_arr[m_size - 1].submit(aio_cb);
    }
    if (m_read_size == 1) {
      return m_executer_arr[0].submit(aio_cb);
    }
    return get_next().submit(aio_cb);
  }

 private:
  size_t m_size;
  size_t m_read_size;
  size_t m_index;
  std::vector<AIO_Executor> m_executer_arr;
};

} // end ns gaia

class RbioClient {
  DISALLOW_COPY_AND_ASSIGN(RbioClient);

 public:
  struct RbioContext {
    RbioContext()
        : cntl(nullptr),
          request(nullptr),
          response(nullptr),
          server_addr(nullptr),
          backup_servers(),
          backup_servers_idx(0),
          segment_id(0),
          sync_segment(false),
          simple_rpc(false),
          use_polar(false),
          use_backup(true),
          use_gaia_backup(true),
          vlsn(0),
          ref_redo_type(0),
          refed_index(0),
          start_us(0),
          real_start_us(0),
          vlsn_diff_ls_dispatch_lsn(0),
          page_ptr(nullptr),
          bpage(nullptr),
          retry_count(0),
          success(false),
          space_not_exist(false),
          polar_sync_promise(nullptr),
          gaia_backup_ctx(nullptr),
          aio_cb(nullptr),
          purge_index_rbio(false) {}

    ~RbioContext();
    void deref_redo();

    page_id_t page_id{0, 0};
    baidu::rpc::Controller *cntl;
    page_server::RbioRequest *request;
    page_server::RbioResponse *response;
    gaiadb::common::PeerZone *server_addr;
    std::vector<gaiadb::common::PeerZone> backup_servers;
    size_t backup_servers_idx;
    gaiadb::common::segment_t segment_id;  // for async retry
    bool sync_segment;
    bool simple_rpc;
    bool use_polar;
    bool use_backup;
    bool use_gaia_backup;
    lsn_t vlsn;
    uint32_t ref_redo_type;
    uint64_t refed_index;
    uint64_t start_us;
    uint64_t real_start_us;
    int64_t vlsn_diff_ls_dispatch_lsn;
    void *page_ptr;
    void *bpage;
    uint32_t retry_count;
    bool success;
    bool space_not_exist;
    std::promise<void>* polar_sync_promise;
    gaiadb::common::BackRequestContext* gaia_backup_ctx;
    gaia::AIO_cb *aio_cb;
    bool purge_index_rbio;
  };

 public:
  RbioClient() : stopped_(false), rpc_log_id_(0), psm_client_(nullptr),
    rbio_retry_policy_(nullptr), rbio_exclude_policy_(nullptr),
    rbio_executors_succ_(false),
    last_zone_version_(0) {}
  virtual ~RbioClient() {}

  static RbioClient &get_instance() {
    static RbioClient rbio_client;
    return rbio_client;
  }

  bool init(gaiadb::psm_client::Psmgr_client *psm_client);
  void deinit();

  void set_stop() { stopped_ = true; }

  int io_submit(gaia::AIO_cb *aio_cb);

  // single page rbio
  dberr_t get_page(const page_id_t &page_id, void *page_ptr, void *bpage,
                   bool skip_delta_replay = false, bool purge_index_rbio = false,
                   gaia::AIO_cb *aio_cb = nullptr
#ifdef ENABLED_GAIADB_PAGE_VALIDATION
                   , lsn_t vlsn_p = 0
#endif /* ENABLED_GAIADB_PAGE_VALIDATION */
  );

 private:

  void reset_vlsn(RbioContext* context);

  dberr_t get_segment_id(uint32_t space_id, uint32_t logical_extent_id,
                         uint32_t &segment_id, uint32_t &physical_extent_id);
  dberr_t get_segment_replicas(uint32_t segment_id,
                               std::vector<gaiadb::common::PeerZone> &segment_replicas,
                               bool force_sync);

  dberr_t get_page_low(RbioContext* context);
  dberr_t get_page_by_gaia_backup(RbioContext* context);
  dberr_t get_page_by_brpc_backup(RbioContext* context);
  dberr_t get_page_by_brpc(RbioContext* context);
  void async_handler(RbioContext* context);

  void on_polar_rbio(RbioContext* context);
  void do_rbio(RbioContext* context,
      google::protobuf::Closure* closure);

  void on_rbio(RbioContext* context, bool is_backup);

  volatile bool stopped_;
  std::atomic<uint64_t> rpc_log_id_;
  gaiadb::psm_client::Psmgr_client *psm_client_;
  std::shared_ptr<RbioRetryPolicy> rbio_retry_policy_;
  std::shared_ptr<RbioExlucdePolicy> rbio_exclude_policy_;
  gaiadb::common::RpcClient rbio_client_;
  gaiadb::polar::RpcClient polar_rbio_client_;
  gaiadb::common::RpcBackRequest gaia_rpc_bakcup_request_;
  bool rbio_executors_succ_;
  gaiadb::polar::RpcExecutorGroup<gaiadb::polar::RbioRpcExecutor> rbio_executors_;
  uint32_t last_zone_version_;
};

#endif
