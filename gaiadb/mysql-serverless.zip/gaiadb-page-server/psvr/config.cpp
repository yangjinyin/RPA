/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/config.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "base/compiler_specific.h"
#include "psvr/config.h"

namespace psvr {

DEFINE_string(psvr_comlog_path, "./log", "For storing comlog files");
DEFINE_string(psvr_comlog_process, "page_server", "Log file prefix name");
DEFINE_int32(psvr_comlog_split_type, 1, "Log file split type: "
        "0(TRUNCT), 1(SIZECUT, split per cut_size), 2(DATECUT, split per 60min)");
DEFINE_bool(psvr_comlog_enable_async, true, "Write log with async mode");
DEFINE_bool(psvr_comlog_enable_wf, true, "Write warning or error level logs to an additional file");
DEFINE_int32(psvr_comlog_cut_size_mb, 2048, "Log file cut size (MB)");
DEFINE_int32(psvr_comlog_quota_size, 20480, "Max log file quota size (MB), in SIZECUT type");
DEFINE_int32(psvr_comlog_quota_day, 15, "Max log file quota day, in DATECUT type");

DEFINE_bool(psvr_enable_spd_log, true, "Logging using spd log");
DEFINE_int64(psvr_spd_log_max_items_num, 81920, "Max spd cache pool log records num");
DEFINE_int64(psvr_spd_log_thread_num, 3, "Spd log pool thread count");
DEFINE_int32(psvr_spd_log_flush_second, 3, "Spd flush cache log interval seconds");

DEFINE_bool(psvr_is_multi_type, false, "Turn on multi-segment");

// for single-segment begin
DEFINE_string(psvr_page_store_dir, "var/page_store", "For storing data and checkpoint files, in single-segment");
DEFINE_uint64(psvr_page_store_file_size, 34359738368, "Data file size (byte), in single-segment");   // 32GB
DEFINE_uint64(psvr_ckp_file_size, 65536, "Checkpoint file size (byte), in single-segment");    // 64KB
// for single-segment end

DEFINE_int32(psvr_bthread_num, 16, "Default bthread worker num");
DEFINE_bool(enable_server_rdma, false, "Turn on server RDMA");

DEFINE_string(psvr_interfaces, "bond0,xgbe0,xgbe1,eth1,eth0", "Interface list of this server");
DEFINE_string(psvr_rbio_server_ip, "", "Server IP address");
DEFINE_int32(psvr_rbio_server_port, 6000, "Server RPC listening port");

DEFINE_int32(psvr_annotate_max_num, 20, "Max size for process annotate");
DEFINE_bool(psvr_enable_logblock_annotate, false, "Turn on slow log tracking for logblock data");
DEFINE_bool(psvr_enable_fetch_annotate, true, "Turn on slow log tracking for fetch");
DEFINE_bool(psvr_enable_gc_annotate, true, "Turn on slow log tracking for GC");
DEFINE_bool(psvr_enable_recover_annotate, false, "Turn on slow log tracking for recover");
DEFINE_bool(psvr_enable_rbio_annotate, true, "Turn on slow log tracking for RBIO");

DEFINE_int64(psvr_logblock_long_query_time_us, 1000000, "Print trace logs of logblock long queries (us)");

DEFINE_int32(multi_psvr_gc_trash_segment_interval_second, 30, "Check segment trash directory every N seconds");
DEFINE_int64(multi_psvr_segment_in_trash_second, 86400, "Trash segment life, delete after");
DEFINE_int32(multi_psvr_gc_trash_segment_num, 3, "Remove trash segment number");

DEFINE_int32(multi_psvr_monitor_store_statistic_interval_second, 30, "Collect disks information every N seconds");
DEFINE_int32(multi_psvr_monitor_segment_statistic_interval_second, 120, "Collect segments information every N seconds");
DEFINE_int64(psvr_retry_delay_us_when_segment_not_enabled, 50000, "Delay time (us) to retry if segment is not enabled");
DEFINE_int64(psvr_clear_space_status_interval_ms, 15 * 60 * 1000, "Space status clear up interval (ms)");
DEFINE_int64(psvr_dblwr_dump_pick_interval_second, 3, "Pick Dblwr dump bufs interval (s)");

DEFINE_bool(psvr_get_extent_map_with_high_performance, true, "Use bytes format for get space extent metadata");
DEFINE_bool(psvr_enable_unknown_extent_to_garbage, false, "Unknown extent data is treated as garbage");

DEFINE_string(psvr_zone_region, "", "Server region name, in multi-AZ");
DEFINE_string(psvr_zone_available_zone, "", "Server available zone name, in multi-AZ");

DEFINE_int64(psvr_db_file_block_size, 512l, "File block size");
DEFINE_bool(psvr_enable_empty_db_file_on_creating, true, "Create segment db allows using empty file");
DEFINE_bool(psvr_enable_fdatasync, false, "Enable fdatasync instead of fsync");
DEFINE_bool(psvr_disable_sync, false, "disable fsync on GC finish");
DEFINE_bool(psvr_enable_sync_directory, false, "Enable fsync on directory");
DEFINE_bool(psvr_sync_on_recovery_or_compression, true, "Enable sync when finish recovery or compression");
DEFINE_uint64(psvr_sync_size_on_recovery_or_compression, 16lu<<20, "Sync when updating data length exceeds this size on recovery or compression");

DEFINE_string(psvr_store_config_file, "", "Stores config file, in multi-segment");
DEFINE_int32(psvr_topology_zone, 0, "Server topology zone number, 0 is disable, in multi-segment");
DEFINE_bool(psvr_topology_to_offline, false, "Server is offline, in multi-segment");

DEFINE_bool(multi_psvr_enable_cleanup_store_incomplete_segment, true, "Cleanup incomplete segment path on start server");
DEFINE_bool(multi_psvr_enable_remove_garbage_segment, true, "Remove segment if it is not on Manager server");

DEFINE_bool(psvr_auto_enable_segment_statistic, false, "Turn on segment statistic");
DEFINE_bool(psvr_auto_enable_cluster_statistic, true, "Turn on cluster statistic");

DEFINE_bool(psvr_disable_buf, false, "Disable buf block memory cache pool");
DEFINE_int64(psvr_init_page_buf_size, (32L<<20), "Single page buf cache size (byte)");
DEFINE_int64(multi_psvr_init_page_buf_size, (512L<<20), "Single page buf cache size (byte), in multi-segment");

DEFINE_int32(psvr_get_extent_size, 32, "Max number of segment extents to get per RPC");
DEFINE_bool(psvr_enable_get_all_spaces_on_load, false, "Load all space meta on segment initialization");
DEFINE_int64(psvr_query_metadata_quota_per_cluster, 512, "Query PSM server max QPS");
DEFINE_int64(psvr_query_metadata_quota_per_cluster_on_restart, 2048, "Query PSM server max QPS on restart server");
DEFINE_int64(psvr_query_metadate_quota_per_cluster_on_restart_valid_seconds, 7200, "Revert query PSM server max QPS after it");

DEFINE_uint64(psvr_single_az_raft_replica_size, 3, "Number of LogService raft replicas");
DEFINE_uint64(psvr_with_backup_az_raft_replica_size, 3, "Number of LogService raft replicas, in multi-AZ");

DEFINE_int32(psvr_batch_heartbeat_max_segment_size, 32, "Max number of segment size on batch heartbeat RPC");

DEFINE_int32(psvr_space_page_slice_count, 32, "Number of slices the space manager page");
DEFINE_int32(psvr_segment_page_lock_slice_count, 32, "Number of slices the segment manager page lock");

DEFINE_int32(psvr_timer_tick_interval, 100, "Timer tick interval (us)");
DEFINE_int32(psvr_control_thread_num, 1, "Number of control flow threads, in single-segment");
DEFINE_int32(psvr_fetcher_thread_num, 1, "Number of fetcher threads, in single-segment");
DEFINE_int32(psvr_parser_thread_num, 1, "Number of parser threads, in single-segment");
DEFINE_int32(psvr_gc_thread_num, 1, "Number of GC threads, in single-segment");
DEFINE_int32(psvr_rbio_thread_num, 16, "Number of RBIO threads, in single-segment");

DEFINE_int32(multi_psvr_control_thread_num, 20, "Number of control flow threads, in multi-segment");
DEFINE_bool(multi_psvr_fetcher_thread_enable_shared, false, "Fetcher threads shared a task queue");
DEFINE_int32(multi_psvr_fetcher_thread_num_per_store, 4, "Number of fetcher threads per store, in multi-segment");
DEFINE_bool(multi_psvr_parser_thread_enable_shared, true, "Parser threads shared a task queue");
DEFINE_int32(multi_psvr_parser_thread_num_per_store, 4, "Number of parser threads per store, in multi-segment");
DEFINE_bool(multi_psvr_gc_thread_enable_shared, true, "GC threads shared a task queue");
DEFINE_int32(multi_psvr_gc_thread_num_per_group, 8, "Number of GC threads per group, in multi-segment");
DEFINE_int32(multi_psvr_gc_prior_thread_num_per_group, 0, "Number of GC prior threads per group, in multi-segment");
DEFINE_int32(multi_psvr_dblwr_dump_num_per_group, 10, "Number of DBLWR dump threads per group, in multi-segment");
DEFINE_bool(multi_psvr_rbio_thread_enable_shared, true, "RBIO threads shared a task queue");
DEFINE_int32(multi_psvr_rbio_thread_num_per_group, 8, "Number of RBIO threads per store, in multi-segment");
DEFINE_int32(multi_psvr_recover_thread_num, 8, "Number of recoverer threads, in multi-segment");
DEFINE_int32(multi_psvr_dst_recover_thread_num, 24, "Number of dest recoverer threads, in multi-segment");
DEFINE_int32(multi_psvr_src_recover_thread_num, 0, "Number of src recoverer threads, in multi-segment");
DEFINE_int32(multi_psvr_compress_thread_num, 4, "Number of compress threads, in multi-segment");

DEFINE_int32(multi_psvr_get_metadata_thread_num, 4, "Number of get metadata threads, in multi-segment");
DEFINE_int64(multi_psvr_store_reserve_size, 128lu<<30, "Store reserve size");

DEFINE_int32(multi_psvr_gc_condition_thread_num, 2, "Number of condition GC threads, in multi-segment");
DEFINE_int32(multi_psvr_rbio_condition_thread_num, 4, "Number of condition RBIO threads, in multi-segment");
DEFINE_int32(multi_psvr_recover_condition_thread_num, 1, "Number of condition recover threads, in multi-segment");

DEFINE_int32(multi_psvr_gc_group_num, 0, "Number of GC thread group, in multi-segment");
DEFINE_int32(multi_psvr_rbio_group_num, 0, "Number of RBIO thread group, in multi-segment");

DEFINE_bool(multi_psvr_enable_reopen_segment, false, "Enable to reopen segment when fetching lsn is invalid");
DEFINE_int32(multi_psvr_enable_reopen_check_times, 10, "Check LSN is behind and prepare to reopen segment");

DEFINE_int64(psvr_fetch_max_buf_size, (32L<<30), "Max total fetch logblock buf size (byte)");
DEFINE_int64(psvr_cluster_fetch_max_buf_size, (12L<<30), "Max total fetch logblock buf size per cluster (byte)");
DEFINE_int64(psvr_segment_fetch_max_buf_size, (2L<<30), "Max total fetch logblock buf size per segment (byte)");
DEFINE_int64(psvr_segment_fetch_max_buf_size_by_append, (3L<<30), "Max total fetch logblock buf size per segment (byte), in append");

DEFINE_int64(psvr_recover_redo_max_buf_size, (16L<<30), "Max total recover redo rec buf size per segment (byte)");
DEFINE_int64(psvr_cluster_recover_redo_max_buf_size, (6L<<30), "Max total recover redo rec size per segment (byte)");

DEFINE_int64(psvr_fetch_max_time_us, 300000, "Switch LogServer nodes, If fetch time (us) from node exceed this value");
DEFINE_int64(psvr_fetch_max_time_us_from_backup, 900000, "Switch LogServer nodes, If fetch time (us) from backup node exceed this value");
DEFINE_int64(psvr_fetch_abnormal_max_time_us, 3000000, "Force update LogServer nodes, If fetch abnormal time (us) exceed this value");
DEFINE_int32(psvr_fetch_empty_consecutive_time, 2, "Max number of empty consecutive fetches for one log service");
DEFINE_int64(psvr_fetch_redo_rec_max_time_s, 300, "Switch Peer nodes, If fetch time (s) from node exceed this value");

DEFINE_int32(psvr_fetch_batch_type, 0, "Batch fetch type: None(0), All(1), Cluster(2)");
DEFINE_string(psvr_fetch_batch_cluster_type_config_file, "", "Config file of batch fetch cluster type");
DEFINE_int64(psvr_fetch_batch_monitor_s, 3, "Schedule between batch monitor interval(s)");
DEFINE_int32(psvr_fetch_batch_segment_count, 64, "Segment count of a batch fetch request");

DEFINE_bool(psvr_fetch_enable_server_push, true, "Turn on server push to fetch logblock");
DEFINE_int64(psvr_fetch_server_push_timeout_ms, 2500, "Server push timeout (ms)");
DEFINE_uint64(psvr_fetch_delay_empty, 0, "Delay fetch empty");
DEFINE_uint64(psvr_fetch_delay_non_empty, 0, "Delay fetch non empty");
DEFINE_int64(psvr_fetch_long_query_time_us, 5000, "Print trace logs of fetch long queries (us)");
DEFINE_int32(psvr_fetch_redo_rec_log_timeout_ms, 8000, "Get peer redo rec logs timeout (ms)");

DEFINE_uint64(psvr_fetcher_delay_min_us, 2000, "Min delay to retry fetching (us)");
DEFINE_uint64(psvr_fetcher_delay_max_us, 2000000, "Max delay to retry fetching (us)");
DEFINE_uint64(psvr_parser_delay_min_us, 10000, "Min delay to retry parsing (us)");
DEFINE_uint64(psvr_parser_delay_max_us, 2000000, "Max delay to retry parsing (us)");
DEFINE_uint64(psvr_gc_delay_min_us, 200, "Min delay to retry GC (us)");
DEFINE_uint64(psvr_gc_delay_max_us, 50000, "Max delay to retry GC (us)");
DEFINE_uint64(psvr_gc_delay_max_us_for_append, 1500000, "Max delay to retry GC (us) when enable append");
DEFINE_uint64(psvr_dblwr_dump_delay_min_us, 50, "Min delay to retry dblwr dump (us)");
DEFINE_uint64(psvr_dblwr_dump_delay_max_us, 5000000, "Max delay to retry dblwr dump (us)");
DEFINE_uint64(psvr_recover_delay_min_us, 20000, "Min delay to retry recovering (us)");
DEFINE_uint64(psvr_recover_delay_max_us, 2000000, "Max delay to retry recovering (us)");
DEFINE_uint64(psvr_rbio_delay_min_us, 50, "Min delay to retry RBIO (us)");
DEFINE_uint64(psvr_rbio_delay_max_us, 5000, "Max delay to retry RBIO (us)");

DEFINE_bool(psvr_gc_enable_punch_hole, false, "Gc compression data with PUNCH_HOLE");
DEFINE_bool(psvr_dblwr_enable_punch_hole, false, "Dblwr compression data with PUNCH_HOLE");
DEFINE_bool(psvr_enable_fallocate_extent_first_page, true,
        "Alloc extent size from file when write extent first page");
DEFINE_int32(psvr_gc_compress_type, 10, "GC compression data type, snappy(8), zstd(9), lz4(10)");
DEFINE_int32(psvr_gc_compress_level, 5, "GC compression data default level");
DEFINE_int32(psvr_gc_compress_lz4_level, 6, "GC compression data level for LZ4");
DEFINE_int32(psvr_gc_compress_zstd_level, 3, "GC compression data level for ZSTD");

DEFINE_int64(psvr_gc_delay_for_recovery_us, 20000, "Delay GC of per logblock to recover data (us)");
DEFINE_int32(psvr_gc_delay_max_times_for_recovery, 3, "Max number of delay GC per logblock");
DEFINE_int64(psvr_gc_long_query_time_us, 5000000, "Print trace logs of GC long queries (us)");
DEFINE_int64(psvr_gc_page_long_query_time_us, 100000, "Print trace logs of GC page long queries (us)");

DEFINE_int32(psvr_gc_parallel_num, 6, "Logblock GC parallel num");

DEFINE_uint64(psvr_gc_delay_lsn_size, 0, "Max GC log block delay lsn size");
DEFINE_int64(psvr_gc_delay_time_us, 0, "Max Gc log block delay time (us)");

DEFINE_uint64(psvr_gc_delay_append_lsn_size, 1075838976lu, "Max GC log block delay lsn size for append db");
DEFINE_uint64(psvr_gc_delay_append_data_size, 64lu<<20, "Max GC log block delay data size for append db");
DEFINE_int64(psvr_gc_delay_append_time_us, 90l * 1000 * 1000, "Max Gc log block delay time (us) for append db");
DEFINE_uint64(psvr_gc_nowait_peer_recovery_window_s, 300,
        "Skip GC wait when peer recovery was seen within this many seconds; 0 disables");

DEFINE_bool(psvr_gc_clear_ignore_cluster_space, true, "Enable clear cluster ignore gc space on GC drop space");
DEFINE_bool(psvr_gc_corrupted_enable_recover, true, "Enable recovery page when data is corrupted on GC");

DEFINE_int32(psvr_gc_wait_lsn_max_times, 3, "Max wait time when logblock GC unable fully complete");
DEFINE_int64(psvr_gc_wait_lsn_sleep_interval_us, 1000, "GC wait sleep interval (us)");
DEFINE_int32(psvr_rbio_wait_lsn_max_times, 20, "Max wait time when RBIO LSN non-compliant");
DEFINE_int64(psvr_rbio_wait_lsn_sleep_interval_us, 50, "RBIO LSN wait sleep interval (us)");
DEFINE_int32(psvr_recover_wait_lsn_max_times, 3, "Max wait time when recover LSN non-compliant");
DEFINE_int64(psvr_recover_wait_lsn_sleep_interval_us, 1000, "Recover LSN wait sleep interval (us)");

DEFINE_int64(psvr_parser_wait_quota_sleep_interval_us, 100, "Parser quota wait sleep interval (us)");
DEFINE_int64(psvr_recover_wait_quota_sleep_interval_us, 200, "Recover quota wait sleep interval (us)");
DEFINE_int64(psvr_compress_wait_quota_sleep_interval_us, 500, "Compress quota wait sleep interval (us)");

DEFINE_bool(psvr_recover_enable_check, false, "Turn on segment data check, disable it when data compression is turned on");
DEFINE_bool(psvr_recover_enable_incremental_completion, true,
        "Enable incremental completion during recovery");
DEFINE_bool(psvr_recover_use_attachment, true, "Turn on segment recover data use brpc attachment");
DEFINE_bool(psvr_stop_recovery_work, false, "Stop recovery work");
DEFINE_int64(psvr_recover_check_interval, 7 * 86400, "Min time between checks for each segment (s)");
DEFINE_bool(psvr_recover_block_if_check_fail, false, "Turn on repair data in data check");
DEFINE_int64(psvr_recover_check_max_speed, (20L<<20), "Max throughput limit for data check (byte)");
DEFINE_int64(psvr_recover_long_query_time_us, 200000, "Print trace logs of recover long queries (us)");
DEFINE_int64(psvr_recover_read_max_speed, 0, "Max throughput limit for data read (byte)");
DEFINE_int64(psvr_recover_read_store_max_speed, (40L<<20), "Max per-disk throughput limit for data read (byte)");
DEFINE_int64(psvr_get_redo_log_max_speed, 0, "Max throughput limit for get redo log qps");
DEFINE_int64(psvr_get_redo_log_store_max_speed, (100L<<20), "Max per-disk throughput limit for get redo log (byte)");
DEFINE_int64(psvr_recover_write_max_speed, 0, "Max global throughput limit for write physical page (byte)");
DEFINE_int64(psvr_recover_write_store_max_speed, (40L<<20), "Max per-disk throughput limit for write physical page (byte)");

DEFINE_int64(psvr_recover_src_max_speed, 0, "Max global throughput limit for source recovery (byte), Peers read my data");
DEFINE_int64(psvr_recover_dst_max_speed, 0, "Max global throughput limit for destination recovery (byte), I read data of my peers");
DEFINE_int64(psvr_recover_src_store_max_speed, (100L<<20), "Max store throughput limit for source recovery (byte)");
DEFINE_int64(psvr_recover_dst_store_max_speed, (100L<<20), "Max store throughput limit for destination recovery (byte)");

DEFINE_int64(psvr_recover_check_task_interval_second, 2, "Schedule recovery tasks intervals (s)");
DEFINE_int32(psvr_recover_max_inflight_task_size, 64, "Max number of inflight recovery blocks per segment");
DEFINE_int32(psvr_recover_task_parallel_num_per_store, 4, "Max number of recovery tasks to run in parallel per store");
DEFINE_int64(psvr_recover_call_timeout_ms, 5000, "Recovery RPC timeout");
DEFINE_int32(psvr_recover_max_wait_lsn_size, 2048, "The max wait lsn tasks size on recovery");
DEFINE_uint64(psvr_recover_max_read_for_recovery_num, 512, "Max number of in-flight read requests for recovery");
DEFINE_uint64(psvr_recover_max_read_for_backup_num, 512, "Max number of in-flight read requests for backup");
DEFINE_uint64(psvr_recover_max_write_for_backup_num, 128, "Max number of in-flight write requests for backup");
DEFINE_uint64(psvr_recover_max_read_redo_log_num, 512, "Max number of in-flight redo log read requests");

DEFINE_bool(psvr_recover_disabled_as_data_source, false, "Disable as data source on recovery");
DEFINE_bool(psvr_rbio_disabled_as_data_source, false, "Disable as data source on rbio");

DEFINE_bool(psvr_enable_compression, true, "Turn on data compression");
DEFINE_bool(psvr_enable_check_compress_data, false, "Enable data compression checking");
DEFINE_int64(psvr_compress_max_speed, 0, "Max global throughput limit for data compression (byte)");
DEFINE_int64(psvr_compress_store_max_speed, (40L<<20), "Max store throughput limit for data compression (byte)");
DEFINE_int64(psvr_compress_store_inflight_num, 2, "Max number of data compression tasks to run in parallel per store");
DEFINE_uint64(psvr_compress_calc_priority_interval_second, 60, "Data compression task sorting interval (s)");
DEFINE_uint64(psvr_compress_store_max_task_num, 10, "Data compression task queue size");
DEFINE_int64(psvr_compress_segment_min_interval_second, 900, "Min time between compression for each segment (s)");
DEFINE_int32(psvr_stat_update_page_interval_second, 1500, "Update statistics window for segment page");

DEFINE_bool(psvr_enable_trim_free_extent, true, "Turn on trim free extent");
DEFINE_uint64(psvr_trim_free_extent_calc_priority_interval_second, 120, "Data trim free extent task sorting interval (s)");
DEFINE_int64(psvr_trim_free_extent_min_interval_us, 900 * 1000 * 1000, "Min time between trim free extents for each segment (us)");
DEFINE_int32(psvr_trim_free_extent_max_task_num_per_store, 1, "Max number of trim free extent tasks to run in parallel per store");
DEFINE_uint64(psvr_update_lowest_lsn_interval_second, 3, "Update cluster lowest lsn interval (s)");

DEFINE_bool(psvr_rbio_enable_wait_queue, true, "Turn on RBIO wait LSN queue");
DEFINE_int64(psvr_rbio_max_tasks_size, 65536, "Max running RBIO queue size, in single-segment");
DEFINE_int64(multi_psvr_rbio_max_tasks_size, 262144, "Max running RBIO queue size, in multi-segment");
DEFINE_int64(psvr_rbio_store_max_tasks_size, 0, "Max running RBIO queue size per store");
DEFINE_int64(psvr_rbio_thread_max_queue_size, 0, "RBIO thread queue size");
DEFINE_int64(psvr_rbio_long_query_time_us, 100000, "Print trace logs of RBIO long queries (us)");
DEFINE_int64(psvr_rbio_long_query_time_print_detail_us, 100000, "Print latency logs of RBIO long queries (us)");
DEFINE_int64(psvr_rbio_long_write_page_us, 100000, "Print trace logs of write page long queries (us)");
DEFINE_int64(psvr_rbio_max_timeout_ms, 2000, "RBIO timeout (ms)");
DEFINE_bool(psvr_rbio_enable_direct_get_meta, true, "Enable RBIO to directly get space or extent metadata");
DEFINE_int32(psvr_rbio_response_compress_type, 0, "Enable data compression for RPC responses, disable(0), snappy(1), gzip(2), zlib(3), lz4(4)");
DEFINE_bool(psvr_rbio_transfer_req_in_recovery, false, "In recovery, Trun on transfer RBIO request to peers if miss data");

DEFINE_bool(psvr_enable_append_file, true, "Use append db engine for GC");
DEFINE_int32(multi_psvr_append_thread_num_per_group, 12, "Number of Append threads per group");
DEFINE_uint64(psvr_append_file_block_size, 1U<<30, "DB append file block size");
DEFINE_int32(multi_psvr_append_recover_thread_num_pre_store, 8, "DB append recover thread size");
DEFINE_bool(psvr_append_disable_cache_key, false, "Disable cache key on append log block");
DEFINE_uint64(psvr_append_merge_max_buf_size, 1<<20, "Append buffer max merge log blocks buf size");
DEFINE_uint64(psvr_append_recover_read_buf_size, 256LU<<10, "Append recover read-ahead buffer size (byte)");
DEFINE_uint64(psvr_append_open_read_buf_size, 2LU<<20, "Append open read-ahead buffer size (byte)");
DEFINE_int32(psvr_append_recover_max_empty_block_num, 1024,
        "Max number of empty log blocks skipped in one recover read (= read_buf_size / kLogHeaderSize)");
DEFINE_uint64(psvr_append_seek_anchor_chunk_size, 8LU<<20,
        "Append recover seek anchor chunk size (byte)");
DEFINE_bool(psvr_append_enable_slots, true,
        "Enable writing append file block footer slots");
DEFINE_bool(psvr_append_fix_footer_backward_scan, true,
        "Use backward scan to find the last complete log when fixing append file footer");
DEFINE_uint64(psvr_append_fix_footer_backward_scan_min_file_size, 16LU<<20,
        "Min block file size to use backward scan when fixing append file footer (byte)");
DEFINE_uint64(psvr_append_fix_footer_max_truncate_size, 16LU<<20,
        "Max tail size allowed to be truncated automatically when fixing append file footer");

DEFINE_int32(psvr_dblwr_max_page_num, 128, "Max double write buf page number");
DEFINE_int32(psvr_dblwr_dump_max_num_per_round, 3, "Max number of dblwr dump buf per round");
DEFINE_int32(psvr_dblwr_buf_file_limit_per_segment, 512, "Max number of dblwr buf files per segment");
DEFINE_int64(psvr_dblwr_seal_timeout_us, 60ll * 1000 * 1000, "Seal least dblwr file timeout (us), 0 is disable.");
DEFINE_uint64(psvr_dblwr_seal_interval_second, 60, "Do Seal dblwr interval (s)");

DEFINE_int32(psvr_refresh_peers_err_times, 64, "Refresh peers data if fail number exceed it");

DEFINE_bool(psvr_enable_encrypt, false, "Enable encrpyt for TDE");

DEFINE_bool(psvr_in_chaos, false, "Use in chaos, enable check with assert");

DEFINE_bool(psvr_mock_rbio_timeout, false, "Mock rbio timeout for test");
DEFINE_uint64(psvr_mock_rbio_sleep_us, 20 * 1000 * 10000, "Mock rbio sleep us");

}
