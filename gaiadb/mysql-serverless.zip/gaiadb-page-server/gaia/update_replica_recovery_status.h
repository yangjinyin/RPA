/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_replica_recovery_status.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <gaiadb/proto/replication/replication.pb.h>
#include "gaia/command.h"

namespace psvr {
namespace gaia {

class UpdateReplicaRecoveryStatus : public Command {
public:
    UpdateReplicaRecoveryStatus() {
        SetName("update-replica-recovery-status");
        SetDesc("update segment replica recovery status information to manager");
        SetDescCn("在管理服务上更新分片副本的恢复状态信息");

        AddPsmClusterOption();
        AddRequiredArgOption("segment-id", NULL, 's', "the segment id", kuint32_t);
        AddRequiredArgOption("replica-id", &_long_opt_val, kOptMax + 2, "the replica id", kuint32_t);
        AddRequiredArgOption("replica-addr", &_long_opt_val, kOptMax + 3, "the replica address", kip_port);
        AddRequiredArgOption("status", &_long_opt_val, kOptMax + 4,
                "the recovery status, RECOVERY_FINISH or RECOVERY_IN",
                kenum);
        
        AddExample("--manager-address bns://xxx --segment-id <id> --replica-id <id>"
                " --replica-addr <ip:port> --status <status>");
    }
    virtual ~UpdateReplicaRecoveryStatus() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 's':
            _segment_id.Set(std::strtoul(opt, nullptr, 10));
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 2:
                _replica_id.Set(std::strtoul(opt, nullptr, 10));
                break;
            case kOptMax + 3:
                _replica_addr = opt;
                break;
            case kOptMax + 4:
                _status = opt;
                break;
            default:
                return 1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::AckResponse& rsp);

private:
    std::string _manager_address {};
    VarOptional<uint32_t> _segment_id;
    VarOptional<uint32_t> _replica_id;
    std::string _replica_addr {};
    std::string _status {};
};

}
}
