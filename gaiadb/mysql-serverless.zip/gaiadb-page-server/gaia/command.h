/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/command.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <iomanip>
#include <pb_to_json.h>
#include <json_to_pb.h>
#include <gaiadb/proto/page_server/page_server_gaia.pb.h>
#include <google/protobuf/text_format.h>
#include <psvr/option.h>
#include "psvr/common.h"
#include "psvr/client.h"
#include "psvr/signal.h"
#include "gaia/table_format.h"
#include <base/macros.h>

namespace psvr {
namespace gaia {

class Command;
using CommandPtr = std::shared_ptr<Command>;

template<typename COMMAND> CommandPtr create_command_instance() {
    CommandPtr cmd(new COMMAND());
    return cmd;
}

inline bool execute_confirm(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    std::string msg;
    base::string_vprintf(&msg, fmt, ap);
    va_end(ap);
    printf("\n**Warning! You are trying to execute a DANGEROUS command!**\n\n");
    printf("[Comfirm] %s. continue? (yes/no): ", msg.c_str());
    char buf[1024];
    if (0 == fgets(buf, 1024, stdin) || 0 != strncmp("yes", buf, 3)) {
        return false;
    }
    return true;
}

static std::string kJson("json");
static std::string kPb("pb");
static std::string kRaw("raw");

#define ZoneStr(z) base::string_printf("%s %s", z.region().c_str(), z.available_zone().c_str())
#define ZoneStrName(z) base::string_printf("zone: %s %s", z.region().c_str(), z.available_zone().c_str())
#define GetZoneStr(rsp)   (!rsp.has_zone() ? "" : (ZoneStr(rsp.zone())))
#define GetZoneStrWithName(rsp)   (!rsp.has_zone() ? "" : (ZoneStrName(rsp.zone())))

#define BinLogInfoStr(b) base::string_printf("on=%d sync_lsn=%lu pos=%lu, file_id=%u", \
        b.enable(), b.sync_lsn(), b.pos(), b.file_id())
#define GetBinLogInfo(rsp) (!rsp.has_binlog_in_redo_info() ? std::string("") : BinLogInfoStr(rsp.binlog_in_redo_info()))

template<typename T>
static T diff_val(T a, T b)  {
    return (a > b) ? (a - b) : 0;
}

inline int format_output(const ggpb::Message& message,
        const std::string& format_type = kJson) {
    if (format_type == kJson) {
        // outout
        std::string json;
        std::string error;
        bool ret = ProtoMessageToJson(message, &json, &error);
        if (!ret) {
            std::cout << "rsp json error, " << error << std::endl;
            return 1;
        }
        std::cout << json << std::endl;
        return 0;
    } else if (format_type == kPb) {
        std::string result;
        bool ret = ggpb::TextFormat::PrintToString(message, &result);
        if (!ret) {
            std::cout << "rsp pb error" << std::endl;
            return 1;
        }
        std::cout << result << std::endl;
        return 0;
    }
    std::cout << "unkown format type," << format_type << std::endl;
    return 1;
}

inline void print_error(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    std::string msg;
    base::string_vprintf(&msg, fmt, ap);
    va_end(ap);
    LOG(WARNING) << msg;
    std::cout << msg << std::endl;
}

static const int32_t kOptLogId = 1;
static const int32_t kOptEnableLog = 2;
static const int32_t kOptConnectTimeout = 3;
static const int32_t kOptRegion = 4;
static const int32_t kOptAvailableZone = 5;
static const int32_t kOptRawWithTable = 6;
static const int32_t kOptSortBy = 7;
static const int32_t kOptSortOrder = 8;
static const int32_t kOptMax = 9;

enum OptionType {
    knull = 0,
    kuint32_t = 1,
    kint32_t,
    kuint64_t,
    kint64_t,
    kbool,
    kfloat,
    kmanager_address,
    kcluster_address,
    kip,
    kip_port,
    kstring,
    kenum,
    kjson,
};

inline const char* OptionType2Str(OptionType type, bool is_optional) {
#define OPTION_TYPE_VALUE(s)  \
    (!is_optional) ? s : s " optional"

    switch(type) {
    case kuint32_t:
        return OPTION_TYPE_VALUE("uint32_t");
    case kuint64_t:
        return OPTION_TYPE_VALUE("uint64_t");
    case kint32_t:
        return OPTION_TYPE_VALUE("int32_t");
    case kint64_t:
        return OPTION_TYPE_VALUE("int64_t");
    case kbool:
        return OPTION_TYPE_VALUE("bool");
    case kfloat:
        return OPTION_TYPE_VALUE("float");
    case kmanager_address:
        return OPTION_TYPE_VALUE("manager_address");
    case kcluster_address:
        return OPTION_TYPE_VALUE("cluster_address");
    case kip:
        return OPTION_TYPE_VALUE("ip");
    case kip_port:
        return OPTION_TYPE_VALUE("ip:port");
    case kstring:
        return OPTION_TYPE_VALUE("string");
    case kenum:
        return OPTION_TYPE_VALUE("enum");
    case kjson:
        return OPTION_TYPE_VALUE("json");
    case knull:
    default:
        return OPTION_TYPE_VALUE("null");
    }
}

static constexpr uint64_t kOnlyMultiPSScope = (1lu << 0);
static constexpr uint64_t kOnlyMultiPSScopeMask = ~(1lu << 0);


static constexpr uint64_t kCommonScope = 1lu << 32;
static constexpr uint64_t kGroup1Scope = 2lu << 32;
static constexpr uint64_t kGroup2Scope = 3lu << 32;
static constexpr uint64_t kGroup3Scope = 4lu << 32;
static constexpr uint64_t kGroup4Scope = 5lu << 32;
static constexpr uint64_t kGroup5Scope = 6lu << 32;
static constexpr uint64_t kZoneScope = 7lu << 32;

struct OptionArg {
    const char* name;           // option name
    int has_arg;                // 0 = no_argument、1 = required_argument、2 = optional_argument
    int* flag;                  // return value point
    int val;                    // short name or return value
    const char* description;    // description it
    OptionType  type;           // value type
    uint64_t scope;             // arg scope
};

inline bool rsp_is_retry(const gaiapb::Status& st) {
    switch(static_cast<gaiadb::GaiaErrno>(st.code())) {
    case gaiadb::GIE_NOT_LEADER:
    case gaiadb::GIE_REDIRECT:
        return true;
    default:
        return false;
    }
}

inline bool rsp_is_retry(const lspb::Status& st) {
    switch(static_cast<lspb::GaiaErrno>(st.code())) {
    case lspb::GIE_NOT_LEADER:
    case lspb::GIE_REDIRECT:
        return true;
    default:
        return false;
    }
}

#define SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp)           \
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED_LOW(rsp, !_raw_with_table)

#define SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED_LOW(rsp, cond) \
    if (cond || rsp.status().code()) {                      \
        Table __table(_raw_with_table, 2);                   \
        __table.AddRowsValue({"log_id:", _log_id});         \
        __table.AddRowsValue({"code:", gaiadb::GaiaErrno_Name(static_cast<gaiadb::GaiaErrno>(rsp.status().code())).c_str()});    \
        __table.AddRowsValue({"msg:", rsp.status().msg().c_str()});  \
        __table.Display();                                  \
    }                                                       \
    if (rsp.status().code()) {                              \
        return 0;                                           \
    }

#define SHOW_LS_OUTPUT_MSG_RETURN_IF_FAILED(rsp)            \
    SHOW_LS_OUTPUT_MSG_RETURN_IF_FAILED_LOW(rsp, !_raw_with_table)

#define SHOW_LS_OUTPUT_MSG_RETURN_IF_FAILED_LOW(rsp, cond)  \
    if (cond || rsp.status().code()) {                      \
        Table __table(_raw_with_table, 2);                  \
        __table.AddRowsValue({"log_id:", _log_id});         \
        __table.AddRowsValue({"code:", log_service::GaiaErrno_Name(static_cast<log_service::GaiaErrno>(rsp.status().code())).c_str()});  \
        __table.AddRowsValue({"msg:", rsp.status().msg().c_str()});  \
        __table.Display();                                  \
    }                                                       \
    if (rsp.status().code()) {                              \
        return 0;                                           \
    }

#define SHOW_CMP_OUTPUT_MSG_RETURN_IF_FAILED(rsp)            \
    SHOW_CMP_OUTPUT_MSG_RETURN_IF_FAILED_LOW(rsp, !_raw_with_table)

#define SHOW_CMP_OUTPUT_MSG_RETURN_IF_FAILED_LOW(rsp, cond)  \
    if (cond || rsp.status().code()) {                       \
        Table __table(_raw_with_table, 2);                   \
        __table.AddRowsValue({"log_id:", _log_id});          \
        __table.AddRowsValue({"code:", rsp.status().code()}); \
        __table.AddRowsValue({"msg:", rsp.status().msg().c_str()});   \
        __table.Display();                                   \
    }                                                        \
    if (rsp.status().code()) {                               \
        return 0;                                            \
    }

#define SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp)                    \
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED_LOW(rsp, !_raw_with_table)

#define SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED_LOW(rsp, cond)          \
    if (cond || rsp.status().code() != pspb::Status_ReturnCode_SUCCESS) {  \
        Table __table(_raw_with_table, 2);                          \
        __table.AddRowsValue({"log_id:", _log_id});                 \
        __table.AddRowsValue({"code:", pspb::Status_ReturnCode_Name(rsp.status().code()).c_str()});  \
        __table.AddRowsValue({"msg:", rsp.status().msg().c_str()});  \
        __table.Display();                                          \
    }                                                               \
    if (rsp.status().code() != pspb::Status_ReturnCode_SUCCESS) {   \
        return 0;                                                   \
    }

#define SHOW_RPL_OUTPUT_MSG_RETURN_IF_FAILED(rsp)                    \
    SHOW_RPL_OUTPUT_MSG_RETURN_IF_FAILED_LOW(rsp, !_raw_with_table)

#define SHOW_RPL_OUTPUT_MSG_RETURN_IF_FAILED_LOW(rsp, cond)          \
    if (cond || rsp.status().code() != replicate::pb::SUCCESS) {     \
        Table __table(_raw_with_table, 2);                           \
        __table.AddRowsValue({"log_id:", _log_id});                  \
        __table.AddRowsValue({"code:", replicate::pb::Code_Name(rsp.status().code()).c_str()});      \
        __table.AddRowsValue({"msg:", rsp.status().msg().c_str()});  \
        __table.Display();                                           \
    }                                                                \
    if (rsp.status().code() != replicate::pb::SUCCESS) {             \
        return 0;                                                    \
    }

template<typename T> 
struct VarOptional {
    bool has_val;
    T val;

    VarOptional() : has_val(false), val{} {}

    void Set(const T& v) {
        has_val = true;
        val = v;
    }
};

struct VarZone {
    std::string region;
    std::string available_zone;

    bool Invalid() const {
        return (!region.empty() && available_zone.empty())
        || (region.empty() && !available_zone.empty());
    }
};

class Command : public SignalStop {
public:
    Command() {
        _log_id = get_current_micros();
        _opts.reserve(16);
        AddCommonOptions();
    }
    Command(bool enable_log) {
        _enable_log = enable_log;
        _log_id = get_current_micros();
        _opts.reserve(16);
        AddCommonOptions();
    }
    virtual ~Command() {
        if (_options) {
            std::free(_options);
        }
    }

    virtual bool is_cmd() { return true; }

    const char* name() {
        return _cmd_name ? _cmd_name : "";
    }

    const char* description() {
        return _cmd_desc ? _cmd_desc : "";
    }

    const char* description_cn() {
        return _cmd_desc_cn ? _cmd_desc_cn : "";
    }

    void help() {
        if (_cmd_name) {
            std::cout << "Usage:  gaia " << _cmd_name << " [OPTION]..." << std::endl;
        }
        if (_cmd_desc) {
            std::cout << _cmd_desc << "." << std::endl;
            if (_cmd_desc_cn) {
                std::cout << _cmd_desc_cn << "." << std::endl;
            }
            std::cout << std::endl;
        }

        size_t size = _opts.size();
        Table table;
        if (size) {
            table.AddRowsWithName({"NAME", "TYPE", "DESCIPTION"});
            std::stable_sort(_opts.begin(), _opts.end(), [](const OptionArg& lhs, const OptionArg& rhs){
                        return (lhs.scope & kOnlyMultiPSScopeMask) < (rhs.scope & kOnlyMultiPSScopeMask);
                    });
        }
        uint64_t last_scope = 0;
        for (size_t i = 0; i < size; ++i) {
            auto opt = &_opts[i];
            uint64_t scope = opt->scope & kOnlyMultiPSScopeMask;
            if (scope != last_scope) {
                if (scope == kCommonScope) {
                    table.AddRowsValue({"Common Options:", "", ""});
                } else {
                    table.AddRowsValue({"", "", ""});
                    table.AddRowsValue({"Options:", "", ""});
                }
                last_scope = scope;
            }
            table.AddRowsValue({
                    opt->flag ? RowStr(RowPrefix("--", opt->name)) : RowStr(RowPrefix("--", opt->name), RowPrefix("-", static_cast<char>(opt->val))),
                    opt->has_arg == 0 ? "" : OptionType2Str(opt->type, opt->has_arg == 2),
                    RowStr(opt->description, (opt->scope & kOnlyMultiPSScope) ? ", With -m" : "")
                    });
        }
        table.Display();

        if (!_examples.empty()) {
            std::cout << std::endl << "EXAMPLES" << std::endl;
            for (const auto& example : _examples) {
                std::cout << "  gaia " << _cmd_name << " " << example << std::endl;
            }
        }
    }

    const struct option* options() {
        size_t size = _opts.size();
        _options = static_cast<struct option*>(std::malloc(sizeof(struct option) * (size + 1)));

        for (size_t i = 0; i < size; ++i) {
            struct option* opt = &_options[i];
            *opt = {_opts[i].name, _opts[i].has_arg, _opts[i].flag, _opts[i].val};
        }

        _options[size] = PSVR_ARGS_OPTION_END;
        return _options;
    }

    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) = 0;
    virtual int Run() = 0;

    virtual void Stop() override {
        _stopped = true;
    }

    void SetName(const char* cmd_name) {
        _cmd_name = cmd_name;
    }

    void SetDesc(const char* cmd_desc) {
        _cmd_desc = cmd_desc;
    }

    void SetDescCn(const char* cmd_desc_cn) {
        _cmd_desc_cn = cmd_desc_cn;
    }

    void AddExample(const char* example) {
        _examples.emplace_back(example);
    }

    void AddOption(const char* name, int has_arg, int* flag, int val,
            const char* description, OptionType type, uint64_t scope) {
        _opts.emplace_back(OptionArg{name, has_arg, flag, val, description, type, scope});
    }

    void AddNoArgOption(const char* name, int* flag, int val,
            const char* description, uint64_t scope = kGroup1Scope) {
        AddOption(name, 0, flag, val, description, OptionType::knull, scope);
    }

    void AddRequiredArgOption(const char* name, int* flag, int val,
            const char* description, OptionType type, uint64_t scope = kGroup1Scope) {
        AddOption(name, 1, flag, val, description, type, scope);
    }

    void AddOptionalArgOption(const char* name, int* flag, int val,
            const char* description, OptionType type, uint64_t scope = kGroup1Scope) {
        AddOption(name, 2, flag, val, description, type, scope);
    }

    void AddCommonOptions() {
        AddNoArgOption("help", NULL, 'h', "display this help and exit", kCommonScope);
        AddRequiredArgOption("output", NULL, 'o',
                "set the output format type (json, pb, raw)", kenum, kCommonScope);
        AddNoArgOption("multi-type", NULL, 'm', "set multi-server type for command", kCommonScope);
        AddNoArgOption("both", NULL, 'b', "parse manager address include disabled nodes", kCommonScope);
        AddRequiredArgOption("timeout", NULL, 't',
                "set RPC timeout, default 3000ms", kuint32_t, kCommonScope);
        AddRequiredArgOption("connect-timeout", &_long_opt_val, kOptConnectTimeout,
                "set RPC connect timeout, default 300ms", kuint32_t, kCommonScope);
        AddNoArgOption("force", NULL, 'f', "skip dangerous command confirmation", kCommonScope);
        AddNoArgOption("total", NULL, 'T', "show output total information", kCommonScope);
        AddNoArgOption("human", NULL, 'H', "show human-readable output", kCommonScope);
        AddOptionalArgOption("table", &_long_opt_val, kOptRawWithTable, "use table format raw output", kbool, kCommonScope);
        AddRequiredArgOption("sort-by", &_long_opt_val, kOptSortBy,
                "sort table output by column name", kstring, kCommonScope);
        AddRequiredArgOption("sort-order", &_long_opt_val, kOptSortOrder,
                "sort order: asc or desc (default: asc)", kenum, kCommonScope);
        AddRequiredArgOption("log-id", &_long_opt_val, kOptLogId,
                "set trace id for RPC or logs", kint64_t, kCommonScope);
        AddNoArgOption("enable-log", &_long_opt_val, kOptEnableLog,
                "print log messages to file", kCommonScope);
    }

    void AddPsmClusterOption(uint64_t scope = kGroup1Scope) {
        AddRequiredArgOption("manager-address", NULL, 'M',
                "the manager address", kmanager_address, scope);
    }

    void AddClusterOption(uint64_t scope = kGroup1Scope) {
        AddRequiredArgOption("cluster-addr", NULL, 'C',
                "the cluster address", kcluster_address, scope);
    }

    void AddNodeOption(uint64_t scope = kGroup1Scope) {
        AddRequiredArgOption("address", NULL, 'a', "service listening address", kip, scope);
        AddRequiredArgOption("port", NULL, 'p', "service listening port", kint32_t, scope);
    }

    void AddClusterAndNodeOptions(uint64_t scope = kGroup1Scope) {
        AddClusterOption(scope);
        AddNodeOption(scope);
    }

    void AddZoneOption(uint64_t scope = kZoneScope) {
        AddRequiredArgOption("region", &_long_opt_val, kOptRegion,
                "server region name of zone", kstring, scope);
        AddRequiredArgOption("available-zone", &_long_opt_val, kOptAvailableZone,
                "server available_zone name of zone", kstring, scope);
    }

    bool enable_log() const { return _enable_log; }
    int64_t log_id() const { return _log_id; }

    int long_opt_val() { return _long_opt_val; }

    void set_format(const std::string& type) {
        _format = type;
    }

    void set_multi_type() {
        _multi_type = true;
    }

    void set_both() {
        _both = true;
    }

    bool both() const { return _both; }

    void set_timeout_ms(int ms) {
        _timeout_ms = ms;
    }

    void set_force() {
        _force = true;
    }

    void set_raw_with_table(bool v) {
        _raw_with_table = v;
    }

    virtual void set_log_id(int64_t log_id) {
        _log_id = log_id;
    }

    virtual const std::string& log_file_name() {
        static std::string empty {};
        return empty;
    }

    void set_show_total() {
        _show_total = true;
    }

    void set_human_readable() {
        _human_readable = true;
    }

protected:
    bool _enable_log {false};
    volatile bool _stopped {false};
    std::string _format {kRaw};
    bool _multi_type {false};
    bool _both {false};
    int _long_opt_val {0};
    int _timeout_ms {3000};
    bool _force {false};
    bool _show_total {false};
    bool _human_readable {false};
    bool _raw_with_table {false};

    int64_t _log_id;
    RpcClient _client;

private:
    const char* _cmd_name {nullptr};
    const char* _cmd_desc {nullptr};
    const char* _cmd_desc_cn {nullptr};
    struct option* _options {nullptr};
    std::vector<OptionArg> _opts;
    std::vector<const char*> _examples;
};

class EmptyCommand : public Command {
public:
    virtual bool is_cmd() override { return false; }

    virtual int Parser(int , const char* ) override { return 0; }
    virtual int Run() override { return 0; }
};

}
}
