/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/add_replicator.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class AddReplicator : public Command {
public:
    AddReplicator() {
        SetName("add-replicator");
        SetDesc("add replicator to manager");
        SetDescCn("添加热活集群复制节点到管理服务");
        
        AddPsmClusterOption();
        AddRequiredArgOption("addr", &_long_opt_val, kOptMax + 1, "server endpoint information", kip_port);
        AddZoneOption();

        AddExample("--manager-address \"bns://xxx\" --addr <ip:port>");
        AddExample("--manager-address \"bns://xxx\" --addr <ip:port> --region bjdd --available-zone test");
    }
    virtual ~AddReplicator() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptRegion:
                _zone.region = opt;
                break;
            case kOptAvailableZone:
                _zone.available_zone = opt;
                break;
            case kOptMax + 1:
                _addr = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::AddReplicatorResponse& rsp);

private:
    std::string _manager_address {};
    std::string _addr {};
    VarZone _zone;
};

}
}
