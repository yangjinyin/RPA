/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test_segment_server.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/segment_server.h"
#include "gaiadb/psm_client/config.h"
#include "bmock.h"

namespace psvr {
namespace test {

class SegmentServerTests : public PsvrTest {
 public:
    SegmentServerTests() {

    }
    virtual ~SegmentServerTests() {}

    void SetUp() {
        _multi.reset(new MultiSegment());
        _single.reset(new OneSegment());
        _multi->_client = _mock_client;
        _multi->_control = _control;
        _single->_client = _mock_client;
        _single->_control = _control;
        EXPECT_CALL(*_mock_control, Stop()).WillRepeatedly(Return());

        // The mock objects created by BMOCK_NS_METHOD attach their hooks at static-init
        // time, so they would stay in effect for the whole binary. Stop them all here and
        // let each test enable only the ones it injects with BMOCK_NS_RESUME.
        BMOCK_NS_STOP(std::filesystem, exists, bool(const std::filesystem::path&));
        BMOCK_NS_STOP(std::filesystem, create_directories, bool(const std::filesystem::path&));
        BMOCK_NS_STOP(psvr::db, fsync, int(int));
    }

    void TearDown() {
    }

private:
    std::shared_ptr<MultiSegment> _multi;
    std::shared_ptr<OneSegment> _single;
};

BMOCK_NS_METHOD1(std::filesystem, exists,
        bool(const std::filesystem::path&));
BMOCK_NS_METHOD1(std::filesystem, create_directories,
        bool(const std::filesystem::path&));
BMOCK_NS_METHOD1(psvr::db, fsync, int(int));

TEST_F(SegmentServerTests, test_00_init_logger) {
    ASSERT_TRUE(init_logger());
}

TEST_F(SegmentServerTests, test_Start_Stop) {
    {
        FLAGS_psvr_rbio_server_port = 0;
        ASSERT_FALSE(_multi->Start());
        FLAGS_psvr_rbio_server_port = 7888;
    }
    {
        FLAGS_psvr_store_config_file = "";
        ASSERT_FALSE(_multi->Start());
        FLAGS_psvr_store_config_file = "./output/not_exists_file";
    }
    {
        ASSERT_FALSE(_multi->Start());
        FLAGS_psvr_store_config_file = "./output/test/segment_server_test";
        std::filesystem::create_directories(FLAGS_psvr_store_config_file);
    }
    {
        EXPECT_CALL(*_mock_control, Start())
            .WillOnce(Return(false))
            .WillOnce(Return(true));
        ASSERT_FALSE(_multi->Start());
        ASSERT_TRUE(_multi->Start());

        _multi->Stop();
    }
}

TEST_F(SegmentServerTests, test_Start_Stop2) {
    {
        gaiadb::psm_client::FLAGS_manager_address = "";
        ASSERT_FALSE(_single->Start());
        gaiadb::psm_client::FLAGS_manager_address = "bns://xx";
    }
    {
        FLAGS_psvr_page_store_dir = "";
        ASSERT_FALSE(_single->Start());
        FLAGS_psvr_page_store_dir = "./data/not_exists" + std::to_string(time(NULL));
    }
    {
        FLAGS_psvr_rbio_server_port = 0;
        ASSERT_FALSE(_single->Start());
        FLAGS_psvr_rbio_server_port = 8888;
    }
    {
        EXPECT_CALL(*_mock_control, Start())
            .WillOnce(Return(false))
            .WillOnce(Return(true));
        ASSERT_FALSE(_single->Start());
        EXPECT_CALL(*_mock_control, Dispatch(_)).WillOnce(Invoke(_mock_control, &MockControl::MockDispatch));
        ASSERT_TRUE(_single->Start());

        _single->Stop();
    }
}

TEST_F(SegmentServerTests, test_OneSegmentStart_directory_failures) {
    const std::string old_manager_address =
            gaiadb::psm_client::FLAGS_manager_address;
    const std::string old_page_store_dir = FLAGS_psvr_page_store_dir;
    const int32_t old_rbio_server_port = FLAGS_psvr_rbio_server_port;
    const bool old_enable_sync_directory = FLAGS_psvr_enable_sync_directory;

    gaiadb::psm_client::FLAGS_manager_address = "bns://xx";
    FLAGS_psvr_page_store_dir = "./data/one_segment_start_test";
    FLAGS_psvr_rbio_server_port = 8888;

    BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&));
    EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_))
        .WillOnce(Return(false));
    BMOCK_NS_RESUME(std::filesystem, create_directories, bool(const std::filesystem::path&));
    EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directories),
            create_directories(_))
        .WillOnce(Return(false));
    ASSERT_FALSE(_single->Start());

    FLAGS_psvr_enable_sync_directory = true;
    BMOCK_NS_RESUME(std::filesystem, exists, bool(const std::filesystem::path&));
    EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, exists), exists(_))
        .WillOnce(Return(false));
    BMOCK_NS_RESUME(std::filesystem, create_directories, bool(const std::filesystem::path&));
    EXPECT_CALL(BMOCK_NS_OBJECT(std::filesystem, create_directories),
            create_directories(_))
        .WillOnce(Return(true));
    BMOCK_NS_RESUME(psvr::db, fsync, int(int));
    EXPECT_CALL(BMOCK_NS_OBJECT(psvr::db, fsync), fsync(_))
        .WillOnce(Invoke([](int) {
            errno = EIO;
            return -1;
        }));
    ASSERT_FALSE(_single->Start());

    gaiadb::psm_client::FLAGS_manager_address = old_manager_address;
    FLAGS_psvr_page_store_dir = old_page_store_dir;
    FLAGS_psvr_rbio_server_port = old_rbio_server_port;
    FLAGS_psvr_enable_sync_directory = old_enable_sync_directory;
    BMOCK_NS_STOP(std::filesystem, exists, bool(const std::filesystem::path&));
    BMOCK_NS_STOP(std::filesystem, create_directories, bool(const std::filesystem::path&));
    BMOCK_NS_STOP(psvr::db, fsync, int(int));
    END_OF_CASE;
}

}
}
