#include "bir0async_binlog.h"
#include <ctype.h>
#include <base/base64.h>
#include <openssl/hmac.h>
#include <baidu/rpc/uri.h>
#include <baidu/rpc/details/http_message.h>
#include <openssl/aes.h>
#include "gaiadb/common/global_flags.h"
#include "rpl0rpl.h"
#include "rpl0parse.h"
#include "gaiadb/redo_fetch/fetch_mdc_object.h"
#include "gaiadb/redo_fetch/fetch_mdc_utils.h"
namespace bir {
void BirAsyncBinlog::binlog_sync_routine() {
  uint32_t current_parse_lsn = 0;
  while (!is_stop()) {
    if (is_stop()) {
      break;
    }
    {
      mutex_enter(binlog_mutex());
      binlog_recover()->sync();
      mutex_exit(binlog_mutex());
    }
    // Update binlog_in_redo_info information for asynchronous disk writes.
    if (!binlog_queue().empty()) {
      BinlogInRedoInfo binlog_in_redo_info;
      while (!binlog_queue().empty() 
            && binlog_queue().front().binlog_sync_lsn <= parse_lsn_ 
            && !is_stop()) {
        binlog_in_redo_info = binlog_queue().front();
        binlog_queue().pop();
      }
      BinlogInRedoInfoMeta binlog_meta;
      binlog_meta.async_info = binlog_in_redo_info;
      retry_operation(
        bir::MAX_RETRYS, gaiadb_update_binlog_in_redo_info_v2, &binlog_meta, 0);
      // Send master-slave synchronization data for downstream binlog dumping.
      if (mysql_bin_log.is_open())
        mysql_bin_log.update_binlog_end_pos();
    } else {
      if (current_parse_lsn >= parse_lsn_) {
        std::this_thread::sleep_for(std::chrono::microseconds(1000));
        continue;
      }
      current_parse_lsn = parse_lsn_;
      BinlogInRedoInfo binlog_in_redo_info;
      binlog_in_redo_info.binlog_sync_lsn = parse_lsn_;
      BinlogInRedoInfoMeta binlog_meta;
      binlog_meta.async_info = binlog_in_redo_info;
      retry_operation(
        bir::MAX_RETRYS, gaiadb_update_binlog_in_redo_info_v2, &binlog_meta, 0);
    }
  }
}
}