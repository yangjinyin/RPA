/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/mock_append_file.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "psvr/append_block.h"

namespace psvr {
namespace test {

class MockBlock : public db::Block {
public:
    MockBlock() : db::Block("test/1.db", 1) {}
    MockBlock(const std::string& fname, uint64_t fno) : db::Block(fname, fno) {}
    virtual ~MockBlock() {}

    MOCK_METHOD1(Open, db::Status(uint64_t));

    MOCK_METHOD0(Close, db::Status());
    MOCK_METHOD7(Append, db::Status(const struct iovec*, int, size_t, uint64_t, uint64_t, uint64_t*, uint64_t*));
    MOCK_METHOD0(Seal, db::Status());
    MOCK_METHOD0(Sync, db::Status());
};

class MockRandomAccessBlock : public db::RandomAccessBlock {
public:
    MockRandomAccessBlock() : db::RandomAccessBlock("test/1.db", 1, -1, 1024) {}
    MockRandomAccessBlock(const std::string& fname, uint64_t fno, int fd, uint64_t start_lsn)
        : db::RandomAccessBlock(fname, fno, fd, start_lsn) {}
    virtual ~MockRandomAccessBlock() {}

    // Must be const to override db::RandomAccessBlock::Read, so calls made through a
    // base reference (e.g. from AppendReadBuf) are intercepted as well.
    MOCK_CONST_METHOD4(Read, db::Status(uint64_t, size_t, base::Slice*, char*));
    MOCK_METHOD0(Delete, db::Status());
};

class MockCheckPointBlock : public db::CheckPointBlock {
public:
    MockCheckPointBlock() : db::CheckPointBlock("test/checkpoint") {}
    MockCheckPointBlock(const std::string& fname) : db::CheckPointBlock(fname) {}
    virtual ~MockCheckPointBlock() {}

    MOCK_METHOD0(Open, db::Status());
    MOCK_METHOD0(Close, db::Status());
    MOCK_METHOD1(Update, db::Status(uint64_t));
    MOCK_METHOD0(Reset, db::Status());

};

}
}
