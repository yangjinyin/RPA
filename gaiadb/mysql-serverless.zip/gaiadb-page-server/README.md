# GaiaDB PageServer
GaiaDB 分布式存储服务

## 快速开始
### 编译
```shell
bcloud build
```

### 安装
见文档：[GaiaDB 单机版部署](https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/PA2gxLX6I5/SNzdpV2fcc/XdinYKmRuIz2AJ)

### 运行
```shell
# 进入安装目录执行
sh load.sh start
```

## 测试
1. 执行 run_test.sh 脚本
2. 按需执行 output/test 目录下的测试 case 即可

## 如何贡献
提交的代码需符合公司的代码规范，同时需要补充对应的单测

## 讨论
如流讨论群：4755318
