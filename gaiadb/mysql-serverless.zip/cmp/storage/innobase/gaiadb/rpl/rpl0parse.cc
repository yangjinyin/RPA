/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file rpl/rpl0parse.cc
 Gaiadb redo log replication

 Authors: qiaohongyu@baidu.com, wanglonglong01@baidu.com
 *******************************************************/

#include "rpl0parse.h"
#include "baidu/rpc/reloadable_flags.h"
#include "gaiadb/innodb_redo/parse.h"
#include "gflags/gflags.h"
#include "log0log.h"
#include "mtr0log.h"
#include "rpl0conductor.h"
#include "rpl0rpl.h"
#include "ibuf0ibuf.h"
#include "rpl0apply.h"
#include "conductor.h"
#include "gaia_rpl_msg.h"

#ifdef HAVE_GAIA_PLAN_CACHE
#include "sql/plan_cache.h"
#endif // HAVE_GAIA_PLAN_CACHE

namespace rpl {

DEFINE_bool(rpl_enable_parallel_parse, false, "enable multi-thread-parse");

static const char *const shredder_str = "rpl_shredder";
static constexpr uint32_t C_PARSE_WAIT_STEP = 4;

DEFINE_uint64(
    rpl_parse_batch_max_size_once, 8388608,
    "Assembly max size, avoid to the rbio or thd lock size too bigger during recycling");
BAIDU_RPC_VALIDATE_GFLAG(rpl_parse_batch_max_size_once,
                         baidu::rpc::PassValidate);


RplParser *g_rpl_parser = &(RplParser::get_instance());

std::unordered_map<MDL_key::enum_mdl_namespace_8018, MDL_key::enum_mdl_namespace> mdl_ns_8018_to_8031_conversion =
{
    {MDL_key::enum_mdl_namespace_8018::GLOBAL_8018, MDL_key::enum_mdl_namespace::GLOBAL},
    {MDL_key::enum_mdl_namespace_8018::TABLESPACE_8018, MDL_key::enum_mdl_namespace::TABLESPACE},
    {MDL_key::enum_mdl_namespace_8018::SCHEMA_8018, MDL_key::enum_mdl_namespace::SCHEMA},
    {MDL_key::enum_mdl_namespace_8018::TABLE_8018, MDL_key::enum_mdl_namespace::TABLE},
    {MDL_key::enum_mdl_namespace_8018::FUNCTION_8018, MDL_key::enum_mdl_namespace::FUNCTION},
    {MDL_key::enum_mdl_namespace_8018::PROCEDURE_8018, MDL_key::enum_mdl_namespace::PROCEDURE},
    {MDL_key::enum_mdl_namespace_8018::TRIGGER_8018, MDL_key::enum_mdl_namespace::TRIGGER},
    {MDL_key::enum_mdl_namespace_8018::EVENT_8018, MDL_key::enum_mdl_namespace::EVENT},
    {MDL_key::enum_mdl_namespace_8018::COMMIT_8018, MDL_key::enum_mdl_namespace::COMMIT},
    {MDL_key::enum_mdl_namespace_8018::USER_LEVEL_LOCK_8018, MDL_key::enum_mdl_namespace::USER_LEVEL_LOCK},
    {MDL_key::enum_mdl_namespace_8018::LOCKING_SERVICE_8018, MDL_key::enum_mdl_namespace::LOCKING_SERVICE},
    {MDL_key::enum_mdl_namespace_8018::SRID_8018, MDL_key::enum_mdl_namespace::SRID},
    {MDL_key::enum_mdl_namespace_8018::ACL_CACHE_8018, MDL_key::enum_mdl_namespace::ACL_CACHE},
    {MDL_key::enum_mdl_namespace_8018::COLUMN_STATISTICS_8018, MDL_key::enum_mdl_namespace::COLUMN_STATISTICS},
    {MDL_key::enum_mdl_namespace_8018::BACKUP_LOCK_8018, MDL_key::enum_mdl_namespace::BACKUP_LOCK},
    {MDL_key::enum_mdl_namespace_8018::RESOURCE_GROUPS_8018, MDL_key::enum_mdl_namespace::RESOURCE_GROUPS},
    {MDL_key::enum_mdl_namespace_8018::FOREIGN_KEY_8018, MDL_key::enum_mdl_namespace::FOREIGN_KEY},
    {MDL_key::enum_mdl_namespace_8018::CHECK_CONSTRAINT_8018, MDL_key::enum_mdl_namespace::CHECK_CONSTRAINT}
};

void rpl_parser() {
  DBUG_ENTER(shredder_str);
  pthread_setname_np(pthread_self(), shredder_str);
#ifdef UNIV_LINUX_ONLY
  setpriority(PRIO_PROCESS, (pid_t)syscall(SYS_gettid), -20);
#endif
  ib_info(ER_IB_GAIA_MSG_RPL) << "Gaia replication shredder thread start";

  g_rpl_parser->routine();

  ib_info(ER_IB_GAIA_MSG_RPL) << "Gaia replication shredder threads stopped";
  DBUG_VOID_RETURN;
}

void ParseWorker::enqueue_record(RawRecord record) {
  uint32_t count = 0;
  while (!queue_.push(record)) {
    count++;
    if (count >= 16) {
      count = 0;
      std::this_thread::sleep_for(std::chrono::microseconds(10));
    } else {
      UT_RELAX_CPU();
    }
  }
}

void ParseWorker::parse_worker_routine(ParseWorker *pw) {
  pthread_setname_np(pthread_self(), "rpl_parse_worker");

  LOG(NOTICE) << "rpl_parse_worker " << pw->index_ << " started";

  while (!rpl_sys->should_stop()) {
    RawRecord record{(mlog_id_t)0, 0, 0, nullptr, nullptr, 0, 0, nullptr};

    uint32_t count = 0;
    while (!pw->queue_.pop(record) && !rpl_sys->should_stop()) {
      count++;
      if (count >= 8) {
        count = 0;
        std::this_thread::sleep_for(std::chrono::microseconds(50));
        LOG_EVERY_SECOND(NOTICE)
            << "rpl_parse_worker " << pw->index_ << " wait for record";
      } else {
        UT_RELAX_CPU();
      }
    }
    if (rpl_sys->should_stop()) {
      break;
    }
    if (record.type == 0) {  // finish sentinel
      pw->finished_.store(true);
      continue;
    }
    record.asmb->add_record(record.type, record.space, record.page_no,
                            record.body, record.end_ptr, record.start_lsn,
                            record.end_lsn, record.ibuf_merge, record.ibuf_entry_counter);
  }

  LOG(NOTICE) << "rpl_parse_worker " << pw->index_ << " stopped";
}

RplParser::RplParser() {}

RplParser::~RplParser() {}

RplParser &RplParser::get_instance() {
  static RplParser parser;
  return parser;
}

void RplParser::reset_parse_worker() {
  ut_a(FLAGS_rpl_enable_parallel_parse);
  for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; i++) {
    parse_workers[i]->reset_state();
  }
}

void RplParser::wait_for_all_worker_finish() {
  ut_a(FLAGS_rpl_enable_parallel_parse);
  RawRecord record;
  record.type = (mlog_id_t)0;

  for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; i++) {
    parse_workers[i]->enqueue_record(record);
  }
  while (true) {
    bool finish = true;
    for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; i++) {
      if (!parse_workers[i]->finished()) {
        finish = false;
        break;
      }
    }
    if (finish) {
      break;
    } else {
      std::this_thread::sleep_for(std::chrono::microseconds(10));
      LOG_EVERY_SECOND(NOTICE) << "wait for parse worker finish";
    }
  }
}

void RplParser::assemble_record(mlog_id_t type, space_id_t space_id,
                                page_no_t page_no, byte *body, byte *rec_end,
                                lsn_t start_lsn, lsn_t end_lsn,
                                RplAssembly *assembly, 
                                const bool &ibuf_sec_index_page_modificiaton,
                                const ulint &ibuf_counter) {
  ut_a(mtr_page_modification_type(type) || type == MLOG_GAIA_IBUF_MERGE_ENTRY_COUNTER);
  ut_a(assembly != nullptr);
  if (FLAGS_rpl_enable_parallel_parse) {
    RawRecord record{type, space_id,  page_no, body,
                     rec_end, start_lsn, end_lsn, assembly,
                     ibuf_sec_index_page_modificiaton, ibuf_counter};
    int32_t index = page_id_hash(page_id_t(space_id, page_no)) %
                    RplConst::RPL_SLOTS_PARALLEL;
    parse_workers[index]->enqueue_record(record);
  } else {
    assembly->add_record(type, space_id, page_no, body, rec_end, start_lsn,
                         end_lsn, ibuf_sec_index_page_modificiaton, ibuf_counter);
  }
}

/** Tries to parse a single log record.
@param[in]  ptr   pointer to a buffer
@param[in]  end_ptr   end of the buffer
@param[out] type    log record type
@param[out] space_id  tablespace identifier
@param[out] page_no   page number
@param[out] body    start of log record body
@paran[in] metadata_add_to_hashmap whether to add the metadata to hashmap
@return length of the record, or 0 if the record was not complete */
inline uint64_t parse_one_log_rec(byte *ptr, byte *end_ptr, mlog_id_t *type,
                                  space_id_t *space_id, page_no_t *page_no,
                                  byte **body, uint32_t *check_bits_len) {
  UNIV_MEM_INVALID(type, sizeof *type);
  UNIV_MEM_INVALID(space_id, sizeof *space_id);
  UNIV_MEM_INVALID(page_no, sizeof *page_no);
  UNIV_MEM_INVALID(body, sizeof *body);
  *body = nullptr;
  *check_bits_len = 0;
  if (ptr >= end_ptr) {
    return (0);
  }

  byte *body_start = nullptr;
  byte *rec_end = nullptr;
  uint32_t body_len = 0;
  innodb::mlog_id_t &ref_type = *reinterpret_cast<innodb::mlog_id_t *>(type);

  switch (*ptr) {
#ifdef UNIV_LOG_LSN_DEBUG
    case MLOG_LSN | MLOG_SINGLE_REC_FLAG:
    case MLOG_LSN:
      rec_end = innodb::Parser::mlog_parse_initial_log_record(
          ptr, end_ptr, type, space_id, page_no, &body_len, check_bits_len);
      *type = MLOG_LSN;
      return (rec_end == nullptr ? 0 : rec_end - ptr);
#endif /* UNIV_LOG_LSN_DEBUG */
    case MLOG_MULTI_REC_END:
    case MLOG_DUMMY_RECORD:
      *page_no = FIL_NULL;
      *space_id = SPACE_UNKNOWN;
      *type = static_cast<mlog_id_t>(*ptr);
      return (1);
    case MLOG_MULTI_REC_END | MLOG_SINGLE_REC_FLAG:
    case MLOG_DUMMY_RECORD | MLOG_SINGLE_REC_FLAG:
      LOG(ERROR) << "bad record: multi end with single flag";
      ut_error;
    case MLOG_TABLE_DYNAMIC_META:
    case MLOG_TABLE_DYNAMIC_META | MLOG_SINGLE_REC_FLAG:
      table_id_t id;
      uint64_t version;
      *page_no = FIL_NULL;
      *space_id = SPACE_UNKNOWN;
      body_start = innodb::Parser::mlog_parse_initial_dict_log_record(
          ptr, end_ptr, ref_type, id, version, body_len, *check_bits_len);
      break;
    case MLOG_GAIA_BINLOG_DATA:
    case MLOG_GAIA_BINLOG_DATA | MLOG_SINGLE_REC_FLAG:
      uint32_t index_num;
      uint64_t pos;
      innodb::binlog_redo_op_t binlog_redo_op_type;
      *page_no = FIL_NULL;
      *space_id = SPACE_UNKNOWN;
      body_start = innodb::Parser::mlog_parse_initial_binlog_log_record(
          ptr, end_ptr, ref_type, &binlog_redo_op_type, index_num, pos, body_len, *check_bits_len);
      break;
    case MLOG_GAIA_COLUMNAR_OPERATOR:
    case MLOG_GAIA_COLUMNAR_OPERATOR | MLOG_SINGLE_REC_FLAG: {
      uint64_t trx_id;
      innodb::columnar_op_t op;
      uint32_t space_id;
      uint64_t index_id;
      body_start = innodb::Parser::mlog_parse_initial_columnar_log_record(
          ptr, end_ptr, ref_type, space_id, index_id, body_len, trx_id, op,
          *check_bits_len);
      break;
    }
    default:
      uint32_t raw_type = (*ptr) & 0x7f;
      ut_a(raw_type < MLOG_GAIA_TRX_BEGIN || raw_type == MLOG_GAIA_TRX_BEGIN ||
           raw_type == MLOG_GAIA_TRX_COMMIT ||
           raw_type == MLOG_GAIA_TRX_LIST_CLEAN ||
           raw_type == MLOG_GAIA_MDL_EXCLUSIVE ||
           raw_type == MLOG_GAIA_TIME_STAMP ||
           raw_type == MLOG_GAIA_ALLOC_EXTENT ||
           raw_type == MLOG_GAIA_INDEX_LOCK ||
           raw_type == MLOG_GAIA_RPL_FENCE ||
           raw_type == MLOG_GAIA_STATS_UPDATE ||
           raw_type == MLOG_GAIA_BINLOG_DATA ||
           raw_type == MLOG_GAIA_FILE_DELETE_LSN ||
           raw_type == MLOG_GAIA_QC_INVIDATE_OP ||
           raw_type == MLOG_GAIA_RPL_MSG ||
           raw_type == MLOG_GAIA_IBUF_MERGE_ENTRY_COUNTER ||
           raw_type == MLOG_GAIA_COLUMNAR_OPERATOR);
      body_start = innodb::Parser::mlog_parse_initial_log_record(
          ptr, end_ptr, ref_type, *space_id, *page_no, body_len,
          *check_bits_len);
      ut_a(body_len < 0x8000);
      break;
  }
  if (body_start != nullptr) {
    *body = body_start;
    rec_end = body_start + body_len;
  }
  if (rec_end == nullptr || end_ptr < rec_end) {
    return 0;
  }
  LOG(TRACE) << "parse one record, type:" << *type << ", space_id:" << *space_id
             << ", page_no:" << *page_no << ", len:" << rec_end - ptr
             << ", ptr: " << (void *)ptr;

  return (rec_end - ptr);
}

void RplParser::parse_mdl_log(byte *body, space_id_t space_id,
                              RplAssembly *assembly, lsn_t lsn) {
  uint32_t key_len = (uint32_t)mach_read_from_2(body);
  auto is_8031_ns = ((key_len & MDL_KEY_NAME_SPACE_8031_FLAG) == MDL_KEY_NAME_SPACE_8031_FLAG);
  const char *key = (const char *)body + 2;
  if (!is_8031_ns) {
    MDL_key::enum_mdl_namespace_8018 namespace_type_8018 = (MDL_key::enum_mdl_namespace_8018)*key;
    if (mdl_ns_8018_to_8031_conversion.find(namespace_type_8018) != mdl_ns_8018_to_8031_conversion.end()) {
      MDL_key::enum_mdl_namespace namespace_type_8031 = mdl_ns_8018_to_8031_conversion.at(namespace_type_8018);
      mach_write_to_1((byte*)key, namespace_type_8031);
    } else {
      assert(false);
    }
  } else {
    key_len ^= MDL_KEY_NAME_SPACE_8031_FLAG;
  }

  MDL_key *mdl_key = new MDL_key();
  MDL_key::enum_mdl_namespace namespace_type =
      (MDL_key::enum_mdl_namespace)*key;
  if (namespace_type == MDL_key::TABLESPACE && space_id != 0) {
    // full name, used to clear fil_shard map
    // | namespace_type | db_name | '\0' | object_name| '\0' | flags  |
    // |<-  1B        ->|<- 0B  ->|<-1B->|
    std::string full_name(key + 2, key_len - 2);
    bool is_new_data = false;
    auto is_trx_new_type = [&full_name, &is_new_data](const std::string& type_name) {
      size_t real_full_name_size = full_name.size() - type_name.size();
      std::string flags = full_name.substr(real_full_name_size);
      if (flags == type_name && full_name[real_full_name_size - 1] == '\0') {
        full_name.resize(real_full_name_size - 1);
        is_new_data = true;
        return true;
      }
      return false;
    };

    mlog_id_t log_type = MLOG_SINGLE_REC_FLAG;
    bool is_new_name = false;
    if (is_trx_new_type(TRX_DROP_NAME)) {
      log_type = MLOG_FILE_DELETE;
    } else if (is_trx_new_type(TRX_CREATE_NAME)) {
      log_type = MLOG_FILE_CREATE;
    } else if (is_trx_new_type(TRX_RENAME_NAME)) {
      log_type = MLOG_FILE_RENAME;
    } else if (is_trx_new_type(TRX_RENAME_NEW_NAME)) {
      log_type = MLOG_FILE_RENAME;
      is_new_name = true;
    }

    // if name overflows, truncate
    if (full_name.size() > NAME_LEN) {
      std::string key_str;
      key_str.append(key, NAME_LEN + 2);
      key_str.append(1, '\0');
      key_len = key_str.length();
      mdl_key->mdl_key_init(key_str.c_str(), key_len);
    } else {
      mdl_key->mdl_key_init(key, key_len);
    }
    if (!is_new_data) {
      ib_system() << "add ddl old log,"
        << " space_id=" << space_id
        << " key_len=" << key_len
        << " full_name=" << full_name
        << " mtr_start_lsn=" << lsn;
      assembly->tablespace_mdl_vec.push_back(
          std::pair<std::string, space_id_t>(full_name, space_id));
      if (!srv_gaia_need_restart_secondnary) {
        srv_gaia_need_restart_secondnary = true;
      }
    } else {
      ut_a(log_type != MLOG_SINGLE_REC_FLAG);
      ib_info() << "add ddl log,"
        << " space_id=" << space_id
        << " key_len=" << key_len
        << " log_type=" << get_mlog_string(log_type)
        << " full_name=" << full_name
        << " is_new_name=" << is_new_name
        << " mtr_start_lsn=" << lsn;
      assembly->push_space_ddls(log_type, space_id, std::move(full_name), is_new_name);
    }
  } else {
    mdl_key->mdl_key_init(key, key_len);
  }

#ifdef HAVE_GAIA_PLAN_CACHE
  if (namespace_type == MDL_key::TABLE) {
    std::string table_key = std::string(mdl_key->db_name(), mdl_key->db_name_length()) 
                          + "/" 
                          + std::string(mdl_key->name(), mdl_key->name_length());
    Plan_cache::getInstance().discard_cache_by_table(table_key);
  }
#endif // HAVE_GAIA_PLAN_CACHE

  if (namespace_type == MDL_key::TABLESPACE &&
      (strcmp(mdl_key->db_name(), "dd_upgrade_targets_80031_reload_meta") == 0 ||
       strcmp(mdl_key->db_name(), "dd_upgrade_targets_80018_reload_meta") == 0)) {
    char db_name[FN_REFLEN];
    strcpy(db_name, mdl_key->db_name());
    auto occurence = strstr(db_name, "_reload_meta");
    if (occurence != nullptr) {
      *occurence = '\0';
    }
    auto rpl_reload_meta = rpl_sys->get_rpl_reload_meta();
    //the control console will trigger self-healing in 30s, so we'd better reload meta before that time
    *rpl_reload_meta = RplReloadMeta(std::string(db_name),
        std::chrono::steady_clock::now(), (rand() % 25));
    LOG(NOTICE)<< "received reload meta signals, db:"<< db_name;
    delete mdl_key;
    mdl_key = nullptr;
  } else {
    if (!assembly->add_mdl_key(mdl_key, lsn)) {
      delete mdl_key;
      mdl_key = nullptr;
    }
  }
}

void RplParser::parse_stats_update_log(byte *body, RplAssembly *assembly) {
  uint32_t len = (uint32_t)mach_read_from_2(body);
  std::string table_name((char *)(body + 2), len);
  assembly->add_stats_tablename(table_name);
}

/** return true is redo not enough to parse.
 *  if mtr_len > 0, the parsing is successful.
 */
bool RplParser::try_shadow_parse_mtr(byte *start_ptr, byte *end_ptr,
                                     uint64_t &mtr_len, uint64_t &n_records) {
  /* Try to parse a log record, fetching its type, space id,
     page no, and a pointer to the body of the log record */
  bool in_multi = false;
  uint64_t total_len = 0;
  byte *cur_ptr = start_ptr;
  n_records = 0;
  auto record_start_lsn = parse_lsn_;

  for (; cur_ptr <= end_ptr;) {
    LOG(TRACE) << "cur_ptr:" << intptr_t(cur_ptr) << " end_ptr:" << intptr_t(end_ptr);
    byte *body;
    mlog_id_t type;
    page_no_t page_no;
    space_id_t space_id;
    uint32_t check_bits_len = 0;
    uint64_t len = parse_one_log_rec(cur_ptr, end_ptr, &type, &space_id,
                                     &page_no, &body, &check_bits_len);

    if (len == 0) {
      if (static_cast<ulong>(end_ptr - start_ptr) >= cur_parse_buf_size_ - 0x8000) {
        limit_by_parse_buffer_ = true;
        LOG_EVERY_SECOND(WARNING) << "parse recod error, limit by parse buf size, parsed_len:" << total_len
          << " buf_size:" << cur_parse_buf_size_;
        //this ib log is need by test case, the test case will search keyword: "Gaia replication parse multi rec to long:"
        ib_warn(ER_IB_GAIA_MSG_RPL)
          << "Gaia replication parse multi rec to long, parsed_len:" << total_len
          << " buf_size:" << cur_parse_buf_size_;
      }
      LOG(TRACE) << "parser need more data, cur_lsn: " << parse_scan_lsn_
                 << ", parsed_len: " << total_len
                 << ", buf_len: " << (end_ptr - start_ptr);
      return true;
    }

    // check record start lsn
    lsn_t real_rec_start_lsn = 0;
    switch (check_bits_len) {
    case 0:
      /* don't has check bits */
      break;
    case (innodb::RECORD_CHECK_BITS_LEN + innodb::PAGE_CHECK_BITS_LEN):
      [[fallthrough]];
    case innodb::RECORD_CHECK_BITS_LEN:
      real_rec_start_lsn = mach_read_from_8(cur_ptr + len - check_bits_len);
      break;
    default:
      LOG(ERROR) << "invalid check bits len: " << check_bits_len;
      ut_error;
    }

    if (real_rec_start_lsn != 0 && real_rec_start_lsn != record_start_lsn) {
      LOG(ERROR) << "record start lsn dismatch"
                 << ", real_rec_start_lsn: " << real_rec_start_lsn
                 << ", record_start_lsn: " << record_start_lsn;
      ut_error;
    }
    record_start_lsn = recv_calc_lsn_on_data_add(record_start_lsn, len);

    n_records++;
    total_len += len;

    if ((int)(*cur_ptr) & MLOG_SINGLE_REC_FLAG) {
      if (in_multi) {
        ut_error;
      }
      break;
    } else {
      in_multi = true;
      if ((int)(*cur_ptr) == MLOG_MULTI_REC_END) {
        in_multi = false;
        break;
      }
    }
    cur_ptr += len;
  }
  ut_a(start_ptr + total_len <= end_ptr);

  if (!in_multi) {
    mtr_len = total_len;
  }
  return cur_ptr >= end_ptr;
}

// return true if need no more processing
bool RplParser::parse_one_mtr(byte *start_ptr, byte *end_ptr, uint64_t mtr_len,
                              uint64_t n_records, RplAssembly *assembly) {
  lsn_t mtr_start_lsn = parse_scan_lsn_;
  lsn_t parse_lsn = recv_calc_lsn_on_data_add(parse_scan_lsn_, mtr_len);
  parse_scan_lsn_ = parse_lsn;
  auto total_len = mtr_len;
  byte *cur_ptr = start_ptr;
  lsn_t record_start_lsn = mtr_start_lsn;
  bool found_ibuf_merge = false;
  page_id_t ibuf_merge_page_id(UINT32_UNDEFINED, UINT32_UNDEFINED);
  ulint ibuf_counter = ULINT_UNDEFINED;

  for (uint64_t i = 0; i < n_records; ++i) {
    mlog_id_t type;
    page_no_t page_no;
    space_id_t space_id;
    byte *body;
    uint32_t check_bits_len = 0;
    uint64_t len = parse_one_log_rec(cur_ptr, end_ptr, &type, &space_id,
                                     &page_no, &body, &check_bits_len);
    ut_a(len > 0);
    total_len -= len;
    switch (type) {
      case MLOG_DUMMY_RECORD:
      case MLOG_GAIA_FILE_DELETE_LSN:
      case MLOG_MULTI_REC_END:
        /* Do nothing */
        break;
#ifdef UNIV_LOG_LSN_DEBUG
      case MLOG_LSN:
        /* Do not add these records to the hash table.
           The page number and space id fields are misused
           for something else. */
        break;
#endif /* UNIV_LOG_LSN_DEBUG */
      case MLOG_GAIA_TRX_BEGIN: {
        trx_id_t trx_id = (trx_id_t)mach_read_from_8(body);
        assembly->add_begin_trx_id(trx_id);
        break;
      }
      case MLOG_GAIA_TRX_COMMIT: {
        trx_id_t trx_id = (trx_id_t)mach_read_from_8(body);
        trx_id_t trx_no = (trx_id_t)mach_read_from_8(body + 8);
        uint64_t time = mach_read_from_8(body + 8 + 8);
        assembly->add_commit_trx_id(trx_id);
        assembly->set_max_trx_id(trx_no);
        assembly->set_max_trx_no(trx_no);
        assembly->update_last_rpl_time(time);
        break;
      }
      case MLOG_GAIA_TRX_LIST_CLEAN: {
        trx_id_t max_trx_id = (trx_id_t)mach_read_from_8(body);
        assembly->set_max_primary_recv_trx_id(max_trx_id);
        assembly->set_max_trx_id(max_trx_id);
        break;
      }
      case MLOG_GAIA_MDL_EXCLUSIVE: {
        parse_mdl_log(body, space_id, assembly, mtr_start_lsn);
        break;
      }
      case MLOG_GAIA_INDEX_LOCK: {
        table_id_t table_id = (table_id_t)mach_read_from_8(body);
        space_index_t index_id = (space_index_t)mach_read_from_8(body + 8);
        assembly->add_smo_index(space_id, table_id, index_id);
        break;
      }
      case MLOG_GAIA_STATS_UPDATE:{
        parse_stats_update_log(body, assembly);
        break;
      }
      case MLOG_GAIA_TIME_STAMP: {
        uint64_t time = mach_read_from_8(body);
        assembly->update_last_rpl_time(time);
        break;
      }
      case MLOG_GAIA_QC_INVIDATE_OP: {
        int table_length = mach_read_from_4(body);
        body += 4;

        std::string table_name((const char*)body, table_length);
        ib_info() << "Parse MLOG_GAIA_QC_INVIDATE_OP table_name:" << table_name;
        assembly->add_invalid_qc_table(table_name);
        break;
      }
      case MLOG_GAIA_RPL_MSG: {
        uint8_t msg_type = mach_read_from_1(body);
        body += 1;

        uint8_t msg_flags = mach_read_from_1(body);
        body += 1;

        const auto payload_len =
            static_cast<ulint>((cur_ptr + len - check_bits_len) - body);

        switch (static_cast<gaia_rpl_msg_type_t>(msg_type)) {
          case GAIA_RPL_MSG_OUTLINE_RELOAD: {
            const bool retain_counters =
                (msg_flags & GAIA_RPL_MSG_F_OUTLINE_RETAIN_COUNTERS) != 0;
            ib_info() << "Parse MLOG_GAIA_RPL_MSG outline reload flags:"
                      << static_cast<uint>(msg_flags)
                      << " retain_counters:" << retain_counters;
            assembly->add_rpl_msg(msg_type, msg_flags, body, payload_len);
            break;
          }
          default: {
            ib_warn() << "Unknown MLOG_GAIA_RPL_MSG msg_type:"
                      << static_cast<uint>(msg_type)
                      << " flags:" << static_cast<uint>(msg_flags);
            break;
          }
        }
        break;
      }
      case MLOG_GAIA_RPL_FENCE: {
        if (srv_gaia_secondary_ignore_fence_log) {
          break;
        } else {
          return (true);
        }
      }
      case MLOG_FILE_DELETE: {
        assembly->add_space_ddls(type, space_id, body, mtr_start_lsn);
        assembly->add_deleting_space(space_id);
        break;
      }
      case MLOG_FILE_CREATE: { // deal with new undo space
        assembly->add_space_ddls(type, space_id, body, mtr_start_lsn);
        if (fsp_is_undo_tablespace(space_id)) {
          assembly->add_creating_undo_space(space_id);
        }
        break;
      }
      case MLOG_FILE_RENAME: {
        assembly->add_space_ddls(type, space_id, body, mtr_start_lsn);
        break;
      }
      case MLOG_TABLE_DYNAMIC_META: {
        uint64_t version;
        uint64_t body_len;
        table_id_t table_id;
        uint32_t check_bits_len;
        byte *body_ptr = mlog_parse_initial_dict_log_record(
            cur_ptr, end_ptr, &type, &table_id, &version, &body_len,
            &check_bits_len);
        ut_a(body_ptr);
        assembly->metadatas.parseMetadataLog(table_id, version, body_ptr,
                                             end_ptr, check_bits_len);
        break;
      }
      case MLOG_GAIA_BINLOG_DATA: {
        uint32_t index_num;
        uint64_t pos;
        innodb::binlog_redo_op_t binlog_redo_op_type;
        page_no = FIL_NULL;
        space_id = SPACE_UNKNOWN;
        uint64_t body_len;
        uint32_t check_bits_len;
        byte *body_ptr = mlog_parse_initial_binlog_log_record(
            cur_ptr, end_ptr, &type, &binlog_redo_op_type, &index_num, &pos, &body_len,
            &check_bits_len);
        ut_a(body_ptr);
        if (srv_gaia_binlog_in_redo_log) {
          mutex_enter(g_rpl_conductor->binlog_mutex());
          g_rpl_conductor->binlog_recover()->apply(binlog_redo_op_type, index_num, pos, body_ptr,
                                                   body_len, check_bits_len);
          mutex_exit(g_rpl_conductor->binlog_mutex());
        }
      }
      case MLOG_INDEX_LOAD:
      case MLOG_GAIA_ALLOC_EXTENT:
      case MLOG_GAIA_COLUMNAR_OPERATOR:
        // do nothing
        break;
      
      case MLOG_GAIA_IBUF_MERGE_ENTRY_COUNTER: {
        uint8_t couter_type = mach_read_from_1(body);
        if (couter_type == IBUF_MERGE_END) {
          assemble_record(type, space_id, page_no, body,
                cur_ptr + len - check_bits_len, record_start_lsn,
                recv_calc_lsn_on_data_add(record_start_lsn, len), assembly,
                false, ULINT_UNDEFINED);
        } else {
          body += 1;
          ibuf_counter = (ulint)mach_read_from_4(body);
          ibuf_merge_page_id.reset(space_id, page_no); 
          found_ibuf_merge = true;
        }
        break;
      }

      default:
        bool ibuf_sec_index_page_modificiaton = false;
        if (found_ibuf_merge && 
            ibuf_merge_page_id.space() == space_id &&
            ibuf_merge_page_id.page_no() == page_no) {
          ibuf_sec_index_page_modificiaton = true;
        }
        ut_a(type != MLOG_GAIA_IBUF_MERGE_ENTRY_COUNTER);
        assemble_record(type, space_id, page_no, body,
                        cur_ptr + len - check_bits_len, record_start_lsn,
                        recv_calc_lsn_on_data_add(record_start_lsn, len), assembly,
                        ibuf_sec_index_page_modificiaton, ibuf_counter);
        break;
    }
    record_start_lsn = recv_calc_lsn_on_data_add(record_start_lsn, len);
    cur_ptr += len;
  }
  ut_a(total_len == 0);
  return false;
}

bool RplParser::init() {
  cur_parse_buf_size_ = ut_uint64_align_up(srv_log_buffer_size, OS_FILE_LOG_BLOCK_SIZE);
  parse_buf_.alloc_withkey(UT_NEW_THIS_FILE_PSI_KEY, ut::Count{cur_parse_buf_size_});

  if (FLAGS_rpl_enable_parallel_parse) {
    parse_workers.reserve(RplConst::RPL_SLOTS_PARALLEL);
    for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; i++) {
      ParseWorker *pw = new ParseWorker(i);
      parse_workers.push_back(pw);
    }
  }
  return true;
}

bool RplParser::cleanup() {
  parse_buf_.dealloc();
  if (FLAGS_rpl_enable_parallel_parse) {
    for (uint64_t i = 0; i < RplConst::RPL_SLOTS_PARALLEL; i++) {
      delete parse_workers[i];
    }
  }
  return true;
}

void RplParser::update_parse_speed(uint64_t parsed_size) {
  static uint64_t bytes_parsed = 0;
  static uint64_t last_stat_ts = my_micro_time();

  bytes_parsed += parsed_size;
  auto now = my_micro_time();
  // update per 5s
  if (now > last_stat_ts && now - last_stat_ts > 6000000) {
    auto time_diff = now - last_stat_ts;
    auto parse_speed = bytes_parsed * 1000000 / time_diff;
    rpl_sys->set_parse_speed(parse_speed);
    bytes_parsed = 0;
    last_stat_ts = now;
  }
}

inline bool RplParser::is_page_mod_record_type(mlog_id_t type) {
  return (type != MLOG_FILE_DELETE && type != MLOG_FILE_CREATE &&
          type != MLOG_FILE_RENAME && type != MLOG_DUMMY_RECORD &&
          type != MLOG_INDEX_LOAD  &&
          type != MLOG_GAIA_TRX_BEGIN && type != MLOG_GAIA_TRX_COMMIT &&
          type != MLOG_GAIA_TRX_LIST_CLEAN && type != MLOG_GAIA_MDL_EXCLUSIVE &&
          type != MLOG_GAIA_TIME_STAMP && type != MLOG_GAIA_ALLOC_EXTENT &&
          type != MLOG_GAIA_INDEX_LOCK  &&
          type != MLOG_GAIA_RPL_FENCE && type != MLOG_GAIA_STATS_UPDATE &&
          type != MLOG_GAIA_BINLOG_DATA &&
          type != MLOG_GAIA_FILE_DELETE_LSN &&
          type != MLOG_GAIA_QC_INVIDATE_OP &&
          type != MLOG_GAIA_RPL_MSG &&
          type != MLOG_GAIA_IBUF_MERGE_ENTRY_COUNTER &&
          type != MLOG_GAIA_COLUMNAR_OPERATOR);
}

void RplParser::resize_buf() {
  const auto cur_size = cur_parse_buf_size_;
  byte *tmp_buf = ut::new_arr_withkey<byte>(UT_NEW_THIS_FILE_PSI_KEY,
      ut::Count(cur_parse_buf_size_));
  std::memcpy(tmp_buf, parse_buf_, cur_parse_buf_size_);
  parse_buf_.dealloc();

  cur_parse_buf_size_ = log_translate_sn_to_lsn(
      static_cast<sn_t>(1.382 * cur_parse_buf_size_ + OS_FILE_LOG_BLOCK_SIZE));
  cur_parse_buf_size_ = ut_uint64_align_up(cur_parse_buf_size_, OS_FILE_LOG_BLOCK_SIZE);

  parse_buf_.alloc_withkey(UT_NEW_THIS_FILE_PSI_KEY, ut::Count{cur_parse_buf_size_});
  std::memcpy(parse_buf_, tmp_buf, cur_size);

  ut::delete_arr(tmp_buf);
  LOG(NOTICE) << "resize rpl parser buf size to " << cur_parse_buf_size_;
}

lsn_t RplParser::copy_fetch_buf(bool move) {
  lsn_t fetch_lsn = g_rpl_conductor->fetch_lsn();
  lsn_t copy_lsn = g_rpl_conductor->copy_lsn();
  if (copy_lsn >= fetch_lsn) {
    return 0;
  }
  if (move && buf_pos_ > 0) {
    ut_a(buf_size_ >= buf_pos_);
    std::memmove(parse_buf_, parse_buf_ + buf_pos_, buf_size_ - buf_pos_);
    buf_size_ -= buf_pos_;
    buf_pos_ = 0;
  }

  std::unique_lock lk(g_rpl_conductor->log_buf_mutex());

  auto buf_size = g_rpl_conductor->log_buf_size();
  byte* log_buf = g_rpl_conductor->log_buf();
  byte *log_buf_end = log_buf + buf_size;

  sn_t start_sn = log_translate_lsn_to_sn(copy_lsn);
  sn_t fetch_sn = log_translate_lsn_to_sn(fetch_lsn);

  auto copy_size = fetch_sn - start_sn;
  auto remain_size = cur_parse_buf_size_ - buf_size_;
  if (copy_size > remain_size) {
    copy_size = remain_size;
  }

  byte *ptr = log_buf + (start_sn % buf_size);
  byte *end_ptr = ptr + copy_size;

  if (end_ptr <= log_buf_end) {
    std::memcpy(parse_buf_ + buf_size_, ptr, copy_size);
  } else {
    auto part_size = log_buf_end - ptr;
    std::memcpy(parse_buf_ + buf_size_, ptr, part_size);
    std::memcpy(parse_buf_ + buf_size_ + part_size, log_buf, copy_size - part_size);
  }
  buf_size_ += copy_size;

  copy_lsn = recv_calc_lsn_on_data_add(copy_lsn, copy_size);
  g_rpl_conductor->update_copy_lsn(copy_lsn);
  LOG(TRACE) << "copy buf size:" << copy_size
    << ", fetch_lsn:" << fetch_lsn << ", copy_lsn:" << copy_lsn;
  return copy_size;
}

void RplParser::routine() {
  parse_lsn_ = g_rpl_conductor->parse_lsn();

  uint32_t wait_buf_count = 0;
  uint64_t last_parse_batch_time = my_micro_time();

  for (; !rpl_sys->should_stop();) {
    lsn_t start_lsn = parse_lsn_;
    lsn_t fetch_lsn = g_rpl_conductor->fetch_lsn();

    update_parse_speed(0);

    if (fetch_lsn <= start_lsn) {
      sleep_buf_not_enough(++wait_buf_count);
      continue;
    }

    LOG(TRACE) << "parse start_lsn: " << start_lsn
                << ", fetch_lsn: " << fetch_lsn;
    sn_t start_sn = log_translate_lsn_to_sn(start_lsn);

    uint64_t batch_time_begin = my_micro_time();
    // 1. wait for rpl_fetcher has data
    do {
      if (rpl_sys->should_stop()) {
        return;
      }

      static int32_t partial_wait_step = C_PARSE_WAIT_STEP;
      /* check fetch size over 2/5 of buf size */
      auto wait_lsn = log_translate_sn_to_lsn(start_sn + cur_parse_buf_size_ * 2 / 5);
      if (g_rpl_conductor->log_buf_reach_lsn(wait_lsn)) {
        LOG(TRACE) << "log buf full-filled for parse, lsn: "
          << wait_lsn;
        partial_wait_step = C_PARSE_WAIT_STEP;
        break;
      }

      const uint64_t wait_interval =
          FLAGS_rpl_parse_batch_interval_threshold / C_PARSE_WAIT_STEP;
      std::this_thread::sleep_for(std::chrono::microseconds(wait_interval));

      partial_wait_step--;
      uint64_t wait_size = 0;
      if (partial_wait_step == 0) {
        partial_wait_step = C_PARSE_WAIT_STEP;
        wait_size = 1;
      } else {
        wait_size = cur_parse_buf_size_ * partial_wait_step / C_PARSE_WAIT_STEP;
      }

      wait_lsn = log_translate_sn_to_lsn(start_sn + wait_size);
      if (g_rpl_conductor->log_buf_reach_lsn(wait_lsn) &&
          (my_micro_time() - batch_time_begin) >
            wait_interval * (C_PARSE_WAIT_STEP - partial_wait_step)) {
        LOG(TRACE) << "log buf partial-filled for parse, lsn: "
          << g_rpl_conductor->fetch_lsn();
        break;
      }

      update_parse_speed(0);
      LOG_EVERY_SECOND(TRACE) << "rpl_parser wait for data after lsn: "
        << log_translate_sn_to_lsn(start_sn);
    } while (true); // return if parser stopped, dont break

    g_rpl_metric->parse_batch_wait << my_micro_time() - batch_time_begin;

    // copy buf
    copy_fetch_buf();

    // start ptr to parse
    byte *ptr = parse_buf_ + buf_pos_;
    byte *end_ptr = parse_buf_ + buf_size_;

    static bvar::LatencyRecorder parse_data_len("parse_data_len");
    auto to_parse_len = buf_size_ - buf_pos_;
    parse_data_len << to_parse_len;

    LOG(TRACE) << "parse from: " << start_lsn << ", len: " << to_parse_len
               << ", offset: " << buf_pos_
               << ", ptr:" << uintptr_t(ptr)
               << ", end_ptr:" << uintptr_t(end_ptr);

    lsn_t batch_start_lsn = parse_lsn_;
    parse_scan_lsn_ = parse_lsn_;
    auto batch_finished = false;
    RplAssembly *assembly = nullptr;

    {
      ScopedLatencyRecorder _(&g_rpl_metric->parse_assembly_wait);
      while (!g_rpl_conductor->can_advance_parse()) {
        update_parse_speed(0);
        LOG_EVERY_SECOND(WARNING) << "no space for assembly,"
          << " gc_index:" << g_rpl_conductor->gc_index()
          << " apply_index:" << g_rpl_conductor->apply_index()
          << " parse_index:" << g_rpl_conductor->parse_index()
          << " apply_state:" << g_rpl_coordinator->apply_state_str();
        std::this_thread::sleep_for(std::chrono::microseconds(100));
      }
    }

    if (FLAGS_rpl_enable_parallel_parse) {
      reset_parse_worker();
    }

    const uint64_t parse_work_begin = my_micro_time();
    uint64_t mtr_count = 0;
    do {
      uint64_t mtr_len = 0, n_records = 0;
      {
        static bvar::LatencyRecorder parse_shadow("cmp_rpl_parse_shadow");
        ScopedLatencyRecorder _(&parse_shadow);
        batch_finished =
          try_shadow_parse_mtr(ptr, end_ptr, mtr_len, n_records);
        LOG(TRACE) << "shadow parse, finished: " << batch_finished
          << ", n_records: " << n_records
          << ", mtr_len: " << mtr_len;
        if (limit_by_parse_buffer_) {
          ut_a(batch_finished);
          /** a lager mtr, its size exceeds buf max size */
          resize_buf();
          copy_fetch_buf(false);
          ptr = parse_buf_ + buf_pos_;
          end_ptr = parse_buf_ + buf_size_;
          limit_by_parse_buffer_ = false;
          continue;
        }
      }

      if (UNIV_LIKELY(mtr_len > 0 && n_records > 0)) {
        mtr_count++;
        if (UNIV_UNLIKELY(!assembly)) {
          ScopedLatencyRecorder lat(&g_rpl_metric->parse_get_assembly);
          assembly = g_rpl_conductor->parse_next();
          ut_a(assembly);
          assembly->init(parse_epoch_, g_rpl_conductor->parse_index());
        }

        {
          static bvar::LatencyRecorder parse_deep("cmp_rpl_parse_deep");
          ScopedLatencyRecorder _(&parse_deep);
          batch_finished |=
            parse_one_mtr(ptr, end_ptr, mtr_len, n_records, assembly);
          parse_lsn_ = parse_scan_lsn_;
          ptr += mtr_len;
          buf_pos_ += mtr_len;
          LOG(TRACE) << "parse one mtr, n_records: " << n_records
            << ", mtr_len: " << mtr_len
            << ", parse_lsn: " << parse_lsn_;
        }

        if (FLAGS_rpl_parse_batch_max_size_once > 0 &&
            assembly->lsn_range_size() >= FLAGS_rpl_parse_batch_max_size_once) {
          batch_finished = true;
        }
      }

      if (!batch_finished) {
        copy_fetch_buf(false);
        end_ptr = parse_buf_ + buf_size_;
      }

    } while (!rpl_sys->should_stop() && !batch_finished);

    if (rpl_sys->should_stop()) {
      return;
    }

    if (FLAGS_rpl_enable_parallel_parse) {
      wait_for_all_worker_finish();
    }

    g_rpl_metric->parse_batch_work << my_micro_time() - parse_work_begin;

    lsn_t batch_end_lsn = parse_lsn_;

    auto now = my_micro_time();
    if (batch_end_lsn == batch_start_lsn) {
      ScopedBvarTimerAdder adder(&g_rpl_metric->parse_wait_more_data);
      sleep_buf_not_enough(++wait_buf_count);
      last_parse_batch_time = now;
      continue;
    }

    g_rpl_conductor->update_parse_lsn(parse_lsn_);
    g_rpl_metric->parse_lsn_diff_fetch_lsn
        << g_rpl_conductor->fetch_lsn() - g_rpl_conductor->parse_lsn();

    static bvar::LatencyRecorder parse_interval("cmp_rpl_parse_interval");
    parse_interval << now - last_parse_batch_time;
    last_parse_batch_time = now;

    static bvar::LatencyRecorder parse_mtr_count("cmp_rpl_parse_mtr_count");
    parse_mtr_count << mtr_count;

    static bvar::LatencyRecorder assembly_lsn_size("cmp_rpl_assembly_lsn_size");
    assembly_lsn_size << (batch_end_lsn - batch_start_lsn);

    {
      ScopedLatencyRecorder _(&g_rpl_metric->parse_advance);
      update_parse_speed(batch_end_lsn - batch_start_lsn);
      assembly->update_record_range(batch_start_lsn, batch_end_lsn);
      assembly->finish_parse();
      g_rpl_conductor->advance_parse();
    }

    wait_buf_count = 0;
    parse_epoch_++;
  }
}

}  // namespace rpl
