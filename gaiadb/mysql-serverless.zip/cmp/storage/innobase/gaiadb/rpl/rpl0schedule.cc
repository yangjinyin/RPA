/*****************************************************************************

Copyright (c) 1997, 2019, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2021, Baidu Inc.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/** @file rpl/rpl0schedule.cc
 Gaiadb redo log replication

 Created 01/16/2023
 Authors: wanglonglong01@baidu.com
 *******************************************************/

#include "rpl0schedule.h"
#include "bthread.h"
#include "my_systime.h"
#include "rpl0conductor.h"
#include "rpl0rpl.h"
#include "ut0vec.h"

namespace rpl {

RplScheduler *g_rpl_scheduler = &(RplScheduler::get_instance());

static const char *const rpl_scheduler_str = "rpl_scheduler";

DEFINE_int32(rpl_assembly_gc_delay_ms, 5, "delay ms of assembly gc");

void rpl_scheduler() {
  DBUG_ENTER(rpl_scheduler_str);
  pthread_setname_np(pthread_self(), rpl_scheduler_str);
#ifdef UNIV_LINUX_ONLY
  setpriority(PRIO_PROCESS, (pid_t)syscall(SYS_gettid), -20);
#endif
  ib_info(ER_IB_GAIA_MSG_RPL) << "Gaia replication schedule thread started";

  g_rpl_scheduler->routine();

  ib_info(ER_IB_GAIA_MSG_RPL) << "Gaia replication schedule thread stopped";

  DBUG_VOID_RETURN;
}

void* update_lowest_lsn(void *) {
  if (FLAGS_rpl_enable_delta_replay) {
    ScopedLatencyRecorder _(&g_rpl_metric->update_lowest);
    rpl_sys->update_lowest_lsn();

    lsn_t lowest_lsn = rpl_sys->lowest_lsn();
    lsn_t parse_lsn = g_rpl_conductor->parse_lsn();
    lsn_t apply_lsn = g_rpl_conductor->apply_lsn();
    g_rpl_metric->gc_2_parse_lsn_gap << parse_lsn - lowest_lsn;
    g_rpl_metric->gc_2_apply_lsn_gap << apply_lsn - lowest_lsn;
  }
  return nullptr;
}

void* rpl_recycle(void *) {
  if (!FLAGS_rpl_enable_delta_replay) {
    return nullptr;
  }
  ScopedLatencyRecorder _(&g_rpl_metric->gc);
  auto lowest_lsn = rpl_sys->lowest_lsn();
  g_rpl_conductor->recycle_assembly_before_lsn(lowest_lsn);
  return nullptr;
}

RplScheduler &RplScheduler::get_instance() {
  static RplScheduler s_rpl_scheduler;
  return s_rpl_scheduler;
}

void RplScheduler::routine() {
  if (!FLAGS_rpl_enable_delta_replay) {
    uint32_t wait_buf_count = 0;
    uint64_t index = 0;
    while (!rpl_sys->should_stop()) {
      GcJob* job = nullptr;
      if (gc_queue_.pop(job)) {
        auto now = my_micro_time();
        uint64_t ts = job->time + FLAGS_rpl_assembly_gc_delay_ms * 1000;
        if (now < ts) {
          std::this_thread::sleep_for(std::chrono::microseconds(ts - now));
        }
        index = job->asmb->snapshot_index;
        wait_buf_count = 0;
        g_rpl_conductor->recycle_assembly(job->asmb);
        delete job;
      } else {
        uint64_t parse_index = g_rpl_conductor->parse_index();
        if (index >= parse_index) {
          sleep_buf_not_enough(++wait_buf_count);
        } else {
          std::this_thread::sleep_for(std::chrono::microseconds(50));
        }
      }
    }
    return;
  }

  start_time_ = my_micro_time();
  for (auto it = job_conf_.begin(); it != job_conf_.end(); ++it) {
    auto job_next_run = start_time_ + it->second.interval;
    if (job_timer_.find(job_next_run) == job_timer_.end()) {
      job_timer_[job_next_run] = Tasks();
    }
    job_timer_[job_next_run].push_back(it->second);
    LOG(TRACE) << it->second.task_name << " next run : " << job_next_run;
  }

  do {
    uint64_t now = my_micro_time();

    std::vector<std::pair<uint64_t, ScheduleTask>> next_run_job;

    for (auto it = job_timer_.begin();
         it != job_timer_.end() && it->first <= now + SCHEDULE_PRECISION;) {
      auto jobs = it->second;
      for (auto &job : jobs) {
        auto job_function = job.task_func;

        LOG(TRACE) << "run job: " << job.task_name;
        // do the actual job
        job_function(NULL);

        // update next run time
        auto next_run = it->first + job.interval;
        next_run_job.push_back(std::make_pair(next_run, job));
      }

      // update iterator
      it = job_timer_.erase(it);
    }
    for (auto &entry : next_run_job) {
      if (job_timer_.find(entry.first) == job_timer_.end()) {
        job_timer_[entry.first] = Tasks();
      }
      job_timer_[entry.first].push_back(entry.second);
    }
    uint64_t sleep_time = SCHEDULE_PRECISION * 2;
    if (job_timer_.size() == 0) {
      sleep_time = SCHEDULE_PRECISION * 4;
    } else {
      auto next_run_time = job_timer_.begin()->first;
      now = my_micro_time();
      if (next_run_time <= now + SCHEDULE_PRECISION) {
        continue;
      } else if (next_run_time < now + sleep_time) {
        sleep_time = next_run_time - now;
      }
    }

    std::this_thread::sleep_for(std::chrono::microseconds(sleep_time));

  } while (!rpl_sys->should_stop());
}

void RplScheduler::register_task(const std::string &task_name,
                                 uint64_t interval, TaskFunc task_func) {
  ScheduleTask task;
  task.task_func = task_func;
  task.interval = interval;
  task.task_name = task_name;
  job_conf_[task_name] = task;
  LOG(TRACE) << "register task: " << task.task_name
             << ", task_interval: " << interval;
}

void RplScheduler::add_gc_job(RplAssembly *asmb) {
  ut_a(!FLAGS_rpl_enable_delta_replay);
  ut_a(asmb);
  uint32_t count = 0;
  GcJob* job = new GcJob();
  job->asmb = asmb;
  job->time = my_micro_time();
  while(!gc_queue_.push(job)) {
    count++;
    if (count >= 32) {
      count = 0;
      std::this_thread::sleep_for(std::chrono::microseconds(10));
    } else {
      UT_RELAX_CPU();
    }
  }
}

}  // namespace  rpl

