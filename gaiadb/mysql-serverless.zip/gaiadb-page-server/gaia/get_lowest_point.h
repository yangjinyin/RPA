/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/get_lowest_point.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class GetLowestPoint : public Command {
public:
    GetLowestPoint() {
        SetName("get-lowest-point");
        SetDesc("get cluster lowest lsn");
        SetDescCn("获取集群最低 LSN");

        AddPsmClusterOption();
        AddNoArgOption("more", &_long_opt_val, kOptMax + 1, "show all page servers in raw mode");
        
        AddExample("--manager-address \"bns://xxx\"");
    }
    virtual ~GetLowestPoint() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _more = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const gaiapb::GetLowestPointResponse& rsp);
    int Format(const gaiapb::ListReplicatorResponse& rsp);
    int Format(const gaiapb::ComputeNodeBatchGetResponse& rsp);
    int Format(const log_service::batch_lsrv_status_response& rsp);
    int Format(const gaiapb::ListPageServerResponse& rsp);

private:
    std::string _manager_address {};
    bool _more {false};
};

}
}
