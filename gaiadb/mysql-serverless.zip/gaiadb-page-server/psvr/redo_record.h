/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/redo_record.h
* @author yukeyong@baidu.com
* @brief Common append redo record parser.
*/

#pragma once

#include <psvr0recv.h>

#include "psvr/page.h"

namespace psvr {

db::Status parse_append_redo_record(
        gaia_apply::byte* record_start,
        gaia_apply::byte* record_end,
        gaia_apply::lsn_t record_end_lsn,
        void* record_storage,
        LogRecord** record,
        gaia_apply::ulint* record_len);

}  // namespace psvr
