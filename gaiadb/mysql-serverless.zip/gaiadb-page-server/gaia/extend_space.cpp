/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/extend_space.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/extend_space.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ExtendSpace::Run() {
    RpcStatus status;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    if (!_space_id.has_val) {
        print_error("miss --space-id");
        return 1;
    }

    if (!_begin_extent_id.has_val) {
        print_error("miss --begin-extent-id");
        return 1;
    }

    if (_num < 1) {
        print_error("miss --num");
        return 1;
    }

    if (!_force) {
        if (!execute_confirm("extend space:%u begin:%u num:%u?", _space_id.val, _begin_extent_id.val, _num)) {
            std::cout << "quit!" << std::endl;
            return -1;
        }
    }

    gaiapb::ExtendSpaceRequest request;
    gaiapb::ExtendSpaceResponse response;

    request.set_space_id(_space_id.val);
    request.set_begin_extent_id(_begin_extent_id.val);
    request.set_num(_num);
    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::extend_space, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            LOG(WARNING) << node << " extend space failed, " << status << " " << response.status();
        }
    }
    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("extend failed, all nodes failed");
    return Output(response);
}

int ExtendSpace::Format(const gaiapb::ExtendSpaceResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"total_extent_num", rsp.total_extent_num()});
    table.Display();
    return 0;
}

}
}
