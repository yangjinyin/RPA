/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_rebalance_segment_replicas.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "gaia/rebalance_segment_replicas.h"

namespace psvr {
namespace test {

class PsvrRebalanceTests : public PsvrTest {
 public:
    PsvrRebalanceTests() {
    }
    virtual ~PsvrRebalanceTests() {}

    void SetUp() {
        _rebalance = new gaia::RebalanceSegmentReplicas();
        _rebalance->_debug = true;
        // keep legacy threshold for existing test scenarios
        _rebalance->_min_replica_count = 2;
    }

    void TearDown() {
        delete _rebalance;
        _rebalance = nullptr;
    }

private:
    gaia::RebalanceSegmentReplicas* _rebalance { nullptr };
};

static void fill_nodes(std::vector<base::EndPoint>& nodes, int32_t size = 10) {
    for (int32_t i = 0; i < size; ++i) {
        nodes.emplace_back(base::IP_ANY, 8001 + i);
    }
}

static void fill_server_response(std::shared_ptr<gaia::Server> server,
        int32_t zone) {
    auto& response = server->rpc_response;
    response.set_log_id(1);
    response.mutable_status()->set_code(pspb::Status::SUCCESS);
    response.set_topology_zone(zone);
    response.set_topology_to_offline(false);
}

static void fill_server_response_store(std::shared_ptr<gaia::Server> server,
        int32_t id, int64_t physical_used_size, int64_t physical_store_size,
        int64_t used_capacity, int64_t capacity, bool io_error, bool active) {
    auto& response = server->rpc_response;
    auto store = response.add_stores();
    store->set_store_id(id);
    store->set_active(active);
    store->set_store_size(physical_store_size);
    store->set_physical_used_size(physical_used_size);
    store->set_physical_store_size(physical_store_size);
    store->set_capacity(capacity);
    store->set_used_capacity(used_capacity);
    store->set_specify_store_size(false);
    store->set_free_size(0);
    store->set_logic_used_size(0);
    store->set_store_path("path_store");
    store->set_io_error_count(io_error ? 1 : 0);
}

static pspb::MultiGetStatusResponse::Segment* fill_server_response_segment(std::shared_ptr<gaia::Server> server,
        const std::string& cluster_id, uint32_t segment_id, uint32_t replica_id,
        int32_t store_id, uint64_t used_size, bool in_recovery = false, const std::string& status = "Open") {
    auto& response = server->rpc_response;
    auto segment = response.add_segments();
    segment->mutable_status()->set_code(pspb::Status::SUCCESS);
    segment->set_cluster_id(cluster_id);
    segment->set_segment_id(segment_id);
    segment->set_replica_id(replica_id);
    segment->set_segment_size(32ul<<30);
    segment->set_segment_physical_size(used_size);
    segment->set_store_id(store_id);
    segment->set_in_recovery(in_recovery);
    segment->set_manager_address("bns://" + cluster_id);
    segment->set_version(1);
    segment->set_segment_status(status);
    segment->set_init_flag("InitSucc");
    return segment;
}

TEST_F(PsvrRebalanceTests, test_StartRebalanceReplicas_ForLimitMaxNum) {

    _rebalance->_max_num = 8;
    _rebalance->_disk_max_num = 4;
    _rebalance->_cluster_max_num = 2;

    _rebalance->_max_recovery_num = 9;
    _rebalance->_disk_max_recovery_num = 6;
    _rebalance->_cluster_max_recovery_num = 3;

    std::vector<base::EndPoint> nodes;
    fill_nodes(nodes, 6);
    _rebalance->_server_manager.InitServerMap(nodes);

    auto server1 = _rebalance->_server_manager.server_map[nodes[0]];
    auto server2 = _rebalance->_server_manager.server_map[nodes[1]];
    auto server3 = _rebalance->_server_manager.server_map[nodes[2]];
    auto server4 = _rebalance->_server_manager.server_map[nodes[3]];
    auto server5 = _rebalance->_server_manager.server_map[nodes[4]];
    auto server6 = _rebalance->_server_manager.server_map[nodes[5]];

    // zone 1
    fill_server_response(server1, 1);
    fill_server_response(server4, 1);
    fill_server_response(server6, 1);
    // zone 2
    fill_server_response(server2, 2);
    // zone 3
    fill_server_response(server3, 3);
    fill_server_response(server5, 3);

    fill_server_response_store(server1, 1, 1ul<<40, 8ul<<40, 100, 800, false, true);
    fill_server_response_store(server6, 1, 1ul<<40, 8ul<<40, 100, 800, false, true);
    fill_server_response_store(server4, 1, 3ul<<40, 8ul<<40, 200, 800, false, true);

    fill_server_response_store(server2, 1, 3ul<<40, 8ul<<40, 200, 800, false, true);

    fill_server_response_store(server3, 1, 5ul<<40, 8ul<<40, 400, 800, false, true);
    fill_server_response_store(server5, 1, 5ul<<40, 8ul<<40, 400, 800, false, true);

    // add not ok replica
    fill_server_response_segment(server3, "c_replica_error", 1, 0, 1, 32ul<<30, false, "Error");

    // add in recover replica
    fill_server_response_segment(server3, "c_replica_in_recovery", 2, 0, 1, 32ul<<30, true);

    // add a recover replica in peer
    fill_server_response_segment(server3, "c_replica_peer_in_recovery", 2, 0, 1, 32ul<<30);
    fill_server_response_segment(server2, "c_replica_peer_in_recovery", 2, 1, 1, 32ul<<30, true);

    // add a rebalance replica
    {
        auto seg = fill_server_response_segment(server3, "c_replcia_in_rebalance", 3, 0, 1, 32ul<<30);
        seg->set_rebalance_from(gaiadb::common::endpoint2str(server2->addr));
        seg->set_rebalance_version(2);
        auto seg2 = fill_server_response_segment(server2, "c_replcia_in_rebalance", 3, 1, 1, 32ul<<30);
        seg2->set_version(2);
    }
    // add a single replcia
    fill_server_response_segment(server3, "c_replica_num_invalid", 4, 0, 1, 32ul<<30);

    // add a exist
    fill_server_response_segment(server1, "c_replica_exist", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "c_replica_exist", 1, 1, 1, 32ul<<30);

    // add a zone conflict
    fill_server_response_segment(server4, "c_replica_zone_conflict", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "c_replica_zone_conflict", 1, 1, 1, 32ul<<30);

    // add a ok
    fill_server_response_segment(server2, "c_replica_ok", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "c_replica_ok", 1, 1, 1, 32ul<<30);
    // add a ok
    fill_server_response_segment(server2, "c_replica_ok", 2, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "c_replica_ok", 2, 1, 1, 32ul<<30);
    // add a ok, but over cluster max
    fill_server_response_segment(server2, "c_replica_ok", 3, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "c_replica_ok", 3, 1, 1, 32ul<<30);

    // add a ok2
    fill_server_response_segment(server2, "c_replica_ok2", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "c_replica_ok2", 1, 1, 1, 32ul<<30);
    // add a ok3
    fill_server_response_segment(server2, "c_replica_ok3", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "c_replica_ok3", 1, 1, 1, 32ul<<30);
    // add a ok4, but over disk max
    fill_server_response_segment(server2, "c_replica_ok4", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "c_replica_ok4", 1, 1, 1, 32ul<<30);

    // add a ok1
    fill_server_response_segment(server2, "c1_replica_ok", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server5, "c1_replica_ok", 1, 1, 1, 32ul<<30);
    // add a ok2
    fill_server_response_segment(server2, "c1_replica_ok2", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server5, "c1_replica_ok2", 1, 1, 1, 32ul<<30);
    // add a ok3
    fill_server_response_segment(server2, "c1_replica_ok3", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server5, "c1_replica_ok3", 1, 1, 1, 32ul<<30);
    // add a ok3, but over max
    fill_server_response_segment(server2, "c1_replica_ok4", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server5, "c1_replica_ok4", 1, 1, 1, 32ul<<30);

    for (auto& it : _rebalance->_server_manager.server_map) {
        it.second->InitServerStatus();
    }

    //for (auto& it : _rebalance->_server_manager.server_map) {
        //it.second->PrintDiskReplicas(std::cout, 1);
    //}

    _rebalance->_server_manager.BuildClusterAndSegmentFromServerDiskReplicas();
    pspb::GaiaReblanceSegments rebalance_replicas;
    _rebalance->StartRebalanceReplicas(rebalance_replicas);

    auto fn_check_cluster_num = [&rebalance_replicas](const std::string& cluster_id) -> int32_t {
        int32_t n = 0;
        for (int32_t i = 0; i < rebalance_replicas.segments_size(); ++i) {
            const auto& seg = rebalance_replicas.segments(i);
            if (seg.src().cluster_id() == cluster_id) {
                ++n;
            }
        }
        return n;
    };

    ASSERT_EQ(7, rebalance_replicas.segments_size());
    ASSERT_EQ(fn_check_cluster_num("c_replcia_in_rebalance"), 1);
    ASSERT_EQ(fn_check_cluster_num("c_replica_ok"), 2);
    ASSERT_EQ(fn_check_cluster_num("c_replica_ok2") + fn_check_cluster_num("c_replica_ok3"), 1);
    ASSERT_EQ(fn_check_cluster_num("c1_replica_ok"), 1);
    ASSERT_EQ(fn_check_cluster_num("c1_replica_ok2"), 1);
    ASSERT_EQ(fn_check_cluster_num("c1_replica_ok3"), 1);
    ASSERT_EQ(fn_check_cluster_num("c1_replica_ok4"), 0);

    //for (auto& it : _rebalance->_server_manager.server_map) {
        //it.second->PrintDiskReplicas(std::cout, 1);
    //}
}

TEST_F(PsvrRebalanceTests, test_StartRebalanceReplicas_ForLimitMaxRecovery) {

    _rebalance->_max_num = 70;
    _rebalance->_disk_max_num = 40;
    _rebalance->_cluster_max_num = 20;

    _rebalance->_max_recovery_num = 10;
    _rebalance->_disk_max_recovery_num = 6;
    _rebalance->_cluster_max_recovery_num = 3;

    std::vector<base::EndPoint> nodes;
    fill_nodes(nodes, 6);
    _rebalance->_server_manager.InitServerMap(nodes);

    auto server1 = _rebalance->_server_manager.server_map[nodes[0]];
    auto server2 = _rebalance->_server_manager.server_map[nodes[1]];
    auto server3 = _rebalance->_server_manager.server_map[nodes[2]];
    auto server4 = _rebalance->_server_manager.server_map[nodes[3]];
    auto server5 = _rebalance->_server_manager.server_map[nodes[4]];
    auto server6 = _rebalance->_server_manager.server_map[nodes[5]];

    // zone 1
    fill_server_response(server1, 1);
    fill_server_response(server4, 1);
    fill_server_response(server6, 1);
    // zone 2
    fill_server_response(server2, 2);
    // zone 3
    fill_server_response(server3, 3);
    fill_server_response(server5, 3);

    fill_server_response_store(server1, 1, 1ul<<40, 8ul<<40, 100, 800, false, true);
    fill_server_response_store(server6, 1, 1ul<<40, 8ul<<40, 100, 800, false, true);
    fill_server_response_store(server4, 1, 3ul<<40, 8ul<<40, 200, 800, false, true);

    fill_server_response_store(server2, 1, 3ul<<40, 8ul<<40, 200, 800, false, true);

    fill_server_response_store(server3, 1, 5ul<<40, 8ul<<40, 400, 800, false, true);
    fill_server_response_store(server5, 1, 5ul<<40, 8ul<<40, 400, 800, false, true);

    // add 3 recovery replica and 1 normal
    fill_server_response_segment(server2, "c_replica_in_recovery", 1, 0, 1, 32ul<<30, true);
    fill_server_response_segment(server2, "c_replica_in_recovery", 2, 0, 1, 32ul<<30, true);
    fill_server_response_segment(server2, "c_replica_in_recovery", 3, 0, 1, 32ul<<30, true);
    fill_server_response_segment(server2, "c_replica_in_recovery", 4, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "c_replica_in_recovery", 4, 1, 1, 32ul<<30);

    // let server1 disk over max
    fill_server_response_segment(server1, "c2_replica_in_recovery", 1, 0, 1, 32ul<<30, true);
    fill_server_response_segment(server1, "c2_replica_in_recovery", 2, 0, 1, 32ul<<30, true);
    fill_server_response_segment(server1, "c2_replica_in_recovery", 3, 0, 1, 32ul<<30, true);
    fill_server_response_segment(server1, "c2_replica_in_recovery", 4, 0, 1, 32ul<<30, true);
    fill_server_response_segment(server1, "c2_replica_in_recovery", 5, 0, 1, 32ul<<30, true);
    fill_server_response_segment(server1, "c2_replica_in_recovery", 6, 0, 1, 32ul<<30, true);

    fill_server_response_segment(server2, "c_replica_ok", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "c_replica_ok", 1, 1, 1, 32ul<<30);
    fill_server_response_segment(server2, "c_replica_ok", 2, 0, 1, 32ul<<30);
    fill_server_response_segment(server5, "c_replica_ok", 2, 1, 1, 32ul<<30);

    for (auto& it : _rebalance->_server_manager.server_map) {
        it.second->InitServerStatus();
    }

    //for (auto& it : _rebalance->_server_manager.server_map) {
        //it.second->PrintDiskReplicas(std::cout, 1);
    //}

    _rebalance->_server_manager.BuildClusterAndSegmentFromServerDiskReplicas();
    pspb::GaiaReblanceSegments rebalance_replicas;
    _rebalance->StartRebalanceReplicas(rebalance_replicas);

    auto fn_check_cluster_num = [&rebalance_replicas](const std::string& cluster_id) -> int32_t {
        int32_t n = 0;
        for (int32_t i = 0; i < rebalance_replicas.segments_size(); ++i) {
            const auto& seg = rebalance_replicas.segments(i);
            if (seg.src().cluster_id() == cluster_id) {
                ++n;
            }
        }
        return n;
    };

    ASSERT_EQ(1, rebalance_replicas.segments_size());
    ASSERT_EQ(fn_check_cluster_num("c_replica_ok"), 1);

    //for (auto& it : _rebalance->_server_manager.server_map) {
        //it.second->PrintDiskReplicas(std::cout, 1);
    //}
}

TEST_F(PsvrRebalanceTests, test_StartRebalanceReplicas_ForClusters) {

    _rebalance->_max_num = 70;
    _rebalance->_disk_max_num = 40;
    _rebalance->_cluster_max_num = 20;

    _rebalance->_max_recovery_num = 20;
    _rebalance->_disk_max_recovery_num = 6;
    _rebalance->_cluster_max_recovery_num = 3;

    std::vector<base::EndPoint> nodes;
    fill_nodes(nodes, 6);
    _rebalance->_server_manager.InitServerMap(nodes);

    auto server1 = _rebalance->_server_manager.server_map[nodes[0]];
    auto server2 = _rebalance->_server_manager.server_map[nodes[1]];
    auto server3 = _rebalance->_server_manager.server_map[nodes[2]];
    auto server4 = _rebalance->_server_manager.server_map[nodes[3]];
    auto server5 = _rebalance->_server_manager.server_map[nodes[4]];
    auto server6 = _rebalance->_server_manager.server_map[nodes[5]];

    // zone 1
    fill_server_response(server1, 1);
    fill_server_response(server4, 1);
    // zone 2
    fill_server_response(server2, 2);
    fill_server_response(server6, 2);
    // zone 3
    fill_server_response(server3, 3);
    fill_server_response(server5, 3);

    fill_server_response_store(server1, 1, 3ul<<40, 8ul<<40, 100, 800, false, true);
    fill_server_response_store(server6, 1, 3ul<<40, 8ul<<40, 100, 800, false, true);
    fill_server_response_store(server4, 1, 3ul<<40, 8ul<<40, 200, 800, false, true);

    fill_server_response_store(server2, 1, 3ul<<40, 8ul<<40, 200, 800, false, true);

    fill_server_response_store(server3, 1, 3ul<<40, 8ul<<40, 400, 800, false, true);
    fill_server_response_store(server5, 1, 3ul<<40, 8ul<<40, 400, 800, false, true);

    // add 3 recovery replica
    fill_server_response_segment(server1, "c_replica_in_recovery", 1, 0, 1, 32ul<<30, true);
    fill_server_response_segment(server2, "c_replica_in_recovery", 2, 0, 1, 32ul<<30, true);
    fill_server_response_segment(server3, "c_replica_in_recovery", 3, 0, 1, 32ul<<30, true);

    // 6 servers, and the server 1,2,3 has 6 replicas, the server 4,5,6 has 0 replias
    // after rebalance
    // the server 1,2,3 has 3 replias, the server 4,5,6 has 3 replias

    fill_server_response_segment(server1, "zone1_1", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server1, "zone1_1", 2, 0, 1, 32ul<<30);
    fill_server_response_segment(server1, "zone1_1", 3, 0, 1, 32ul<<30);
    fill_server_response_segment(server1, "zone1_1", 4, 0, 1, 32ul<<30);
    fill_server_response_segment(server2, "zone1_1", 1, 1, 1, 32ul<<30);
    fill_server_response_segment(server2, "zone1_1", 2, 1, 1, 32ul<<30);
    fill_server_response_segment(server3, "zone1_1", 3, 1, 1, 32ul<<30);
    fill_server_response_segment(server3, "zone1_1", 4, 1, 1, 32ul<<30);

    fill_server_response_segment(server2, "zone2_1", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server2, "zone2_1", 2, 0, 1, 32ul<<30);
    fill_server_response_segment(server2, "zone2_1", 3, 0, 1, 32ul<<30);
    fill_server_response_segment(server2, "zone2_1", 4, 0, 1, 32ul<<30);
    fill_server_response_segment(server1, "zone2_1", 1, 1, 1, 32ul<<30);
    fill_server_response_segment(server1, "zone2_1", 2, 1, 1, 32ul<<30);
    fill_server_response_segment(server3, "zone2_1", 3, 1, 1, 32ul<<30);
    fill_server_response_segment(server3, "zone2_1", 4, 1, 1, 32ul<<30);

    fill_server_response_segment(server3, "zone3_1", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "zone3_1", 2, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "zone3_1", 3, 0, 1, 32ul<<30);
    fill_server_response_segment(server3, "zone3_1", 4, 0, 1, 32ul<<30);
    fill_server_response_segment(server1, "zone3_1", 1, 1, 1, 32ul<<30);
    fill_server_response_segment(server1, "zone3_1", 2, 1, 1, 32ul<<30);
    fill_server_response_segment(server2, "zone3_1", 3, 1, 1, 32ul<<30);
    fill_server_response_segment(server2, "zone3_1", 4, 1, 1, 32ul<<30);


    for (auto& it : _rebalance->_server_manager.server_map) {
        it.second->InitServerStatus();
    }

    //for (auto& it : _rebalance->_server_manager.server_map) {
        //it.second->PrintDiskReplicas(std::cout, 1);
    //}

    _rebalance->_server_manager.BuildClusterAndSegmentFromServerDiskReplicas();
    pspb::GaiaReblanceSegments rebalance_replicas;
    _rebalance->StartRebalanceReplicas(rebalance_replicas);

    auto fn_check_cluster_num = [&rebalance_replicas](const std::string& cluster_id, const std::string& to_addr) -> int32_t {
        int32_t n = 0;
        for (int32_t i = 0; i < rebalance_replicas.segments_size(); ++i) {
            const auto& seg = rebalance_replicas.segments(i);
            if (seg.src().cluster_id() == cluster_id
                    && seg.dest().addr() == to_addr) {
                ++n;
            }
        }
        return n;
    };

    ASSERT_EQ(9, rebalance_replicas.segments_size());
    ASSERT_EQ(fn_check_cluster_num("zone1_1", "0.0.0.0:8004"), 1);
    ASSERT_EQ(fn_check_cluster_num("zone1_1", "0.0.0.0:8005"), 1);
    ASSERT_EQ(fn_check_cluster_num("zone1_1", "0.0.0.0:8006"), 1);
    ASSERT_EQ(fn_check_cluster_num("zone2_1", "0.0.0.0:8004"), 1);
    ASSERT_EQ(fn_check_cluster_num("zone2_1", "0.0.0.0:8005"), 1);
    ASSERT_EQ(fn_check_cluster_num("zone2_1", "0.0.0.0:8006"), 1);
    ASSERT_EQ(fn_check_cluster_num("zone3_1", "0.0.0.0:8004"), 1);
    ASSERT_EQ(fn_check_cluster_num("zone3_1", "0.0.0.0:8005"), 1);
    ASSERT_EQ(fn_check_cluster_num("zone3_1", "0.0.0.0:8006"), 1);

    //for (auto& it : _rebalance->_server_manager.server_map) {
        //it.second->PrintDiskReplicas(std::cout, 1);
    //}
}

TEST_F(PsvrRebalanceTests, test_StartRebalanceReplicas_ForNoSetZone) {

    _rebalance->_max_num = 70;
    _rebalance->_disk_max_num = 40;
    _rebalance->_cluster_max_num = 20;

    _rebalance->_max_recovery_num = 100;
    _rebalance->_disk_max_recovery_num = 60;
    _rebalance->_cluster_max_recovery_num = 30;

    _rebalance->_disk_floating_rate = 15;

    std::vector<base::EndPoint> nodes;
    fill_nodes(nodes, 6);
    _rebalance->_server_manager.InitServerMap(nodes);

    auto server1 = _rebalance->_server_manager.server_map[nodes[0]];
    auto server2 = _rebalance->_server_manager.server_map[nodes[1]];
    auto server3 = _rebalance->_server_manager.server_map[nodes[2]];
    auto server4 = _rebalance->_server_manager.server_map[nodes[3]];
    auto server5 = _rebalance->_server_manager.server_map[nodes[4]];
    auto server6 = _rebalance->_server_manager.server_map[nodes[5]];

    // zone 0
    fill_server_response(server1, 0);
    fill_server_response(server2, 0);
    fill_server_response(server3, 0);
    fill_server_response(server4, 0);
    fill_server_response(server5, 0);
    fill_server_response(server6, 0);

    fill_server_response_store(server1, 1, 3 * (32ul<<30), 1ul<<40, 100, 800, false, true);
    fill_server_response_store(server2, 1, 3 * (32ul<<30), 1ul<<40, 200, 800, false, true);
    fill_server_response_store(server3, 1, 0, 1ul<<40, 400, 800, false, true);
    fill_server_response_store(server4, 1, 0, 1ul<<40, 200, 800, false, true);
    fill_server_response_store(server5, 1, 0, 1ul<<40, 400, 800, false, true);
    fill_server_response_store(server6, 1, 0, 1ul<<40, 100, 800, false, true);

    // add 6 replica
    fill_server_response_segment(server1, "c_replica_ok", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server2, "c_replica_ok", 1, 1, 1, 32ul<<30);
    fill_server_response_segment(server1, "c_replica_ok2", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server2, "c_replica_ok2", 1, 1, 1, 32ul<<30);
    fill_server_response_segment(server1, "c_replica_ok3", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server2, "c_replica_ok3", 1, 1, 1, 32ul<<30);

    for (auto& it : _rebalance->_server_manager.server_map) {
        it.second->InitServerStatus();
    }

    //for (auto& it : _rebalance->_server_manager.server_map) {
        //it.second->PrintDiskReplicas(std::cout, 1);
    //}

    _rebalance->_server_manager.BuildClusterAndSegmentFromServerDiskReplicas();
    pspb::GaiaReblanceSegments rebalance_replicas;
    _rebalance->StartRebalanceReplicas(rebalance_replicas);

    auto fn_check_cluster_num = [&rebalance_replicas](const std::string& cluster_id) -> int32_t {
        int32_t n = 0;
        for (int32_t i = 0; i < rebalance_replicas.segments_size(); ++i) {
            const auto& seg = rebalance_replicas.segments(i);
            if (seg.src().cluster_id() == cluster_id) {
                ++n;
            }
        }
        return n;
    };

    ASSERT_EQ(3, rebalance_replicas.segments_size());
    ASSERT_EQ(fn_check_cluster_num("c_replica_ok"), 1);
    ASSERT_EQ(fn_check_cluster_num("c_replica_ok2"), 1);
    ASSERT_EQ(fn_check_cluster_num("c_replica_ok3"), 1);

    //for (auto& it : _rebalance->_server_manager.server_map) {
        //it.second->PrintDiskReplicas(std::cout, 1);
    //}
}


TEST_F(PsvrRebalanceTests, test_StartRebalanceReplicas_ForNoActiveDisk) {
    _rebalance->_max_num = 8;
    _rebalance->_disk_max_num = 4;
    _rebalance->_cluster_max_num = 2;
    _rebalance->_max_recovery_num = 9;
    _rebalance->_disk_max_recovery_num = 6;
    _rebalance->_cluster_max_recovery_num = 3;

    std::vector<base::EndPoint> nodes;
    fill_nodes(nodes, 2);
    _rebalance->_server_manager.InitServerMap(nodes);

    auto server1 = _rebalance->_server_manager.server_map[nodes[0]];
    auto server2 = _rebalance->_server_manager.server_map[nodes[1]];

    fill_server_response(server1, 1);
    fill_server_response(server2, 2);

    // all disks inactive: should be guarded, no divide-by-zero
    fill_server_response_store(server1, 1, 0, 1ul<<40, 100, 800, false, false);
    fill_server_response_store(server2, 1, 0, 1ul<<40, 100, 800, false, false);

    for (auto& it : _rebalance->_server_manager.server_map) {
        it.second->InitServerStatus();
    }

    _rebalance->_server_manager.BuildClusterAndSegmentFromServerDiskReplicas();
    pspb::GaiaReblanceSegments rebalance_replicas;
    ASSERT_EQ(-1, _rebalance->StartRebalanceReplicas(rebalance_replicas));
}

TEST_F(PsvrRebalanceTests, test_StartRebalanceReplicas_ForClusterIdFilter) {
    _rebalance->_max_num = 70;
    _rebalance->_disk_max_num = 40;
    _rebalance->_cluster_max_num = 20;
    _rebalance->_max_recovery_num = 100;
    _rebalance->_disk_max_recovery_num = 60;
    _rebalance->_cluster_max_recovery_num = 30;
    _rebalance->_cluster_id = "c_target";   // only rebalance this cluster

    std::vector<base::EndPoint> nodes;
    fill_nodes(nodes, 3);
    _rebalance->_server_manager.InitServerMap(nodes);

    auto server1 = _rebalance->_server_manager.server_map[nodes[0]];
    auto server2 = _rebalance->_server_manager.server_map[nodes[1]];
    auto server3 = _rebalance->_server_manager.server_map[nodes[2]];

    fill_server_response(server1, 1);
    fill_server_response(server2, 2);
    fill_server_response(server3, 3);

    // server1 inflation, server2/3 deflation
    fill_server_response_store(server1, 1, 6ul<<40, 8ul<<40, 400, 800, false, true);
    fill_server_response_store(server2, 1, 1ul<<40, 8ul<<40, 100, 800, false, true);
    fill_server_response_store(server3, 1, 1ul<<40, 8ul<<40, 100, 800, false, true);

    // two clusters on inflation disk; only c_target should be rebalanced
    fill_server_response_segment(server1, "c_target", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server2, "c_target", 1, 1, 1, 32ul<<30);
    fill_server_response_segment(server1, "c_other", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server2, "c_other", 1, 1, 1, 32ul<<30);

    for (auto& it : _rebalance->_server_manager.server_map) {
        it.second->InitServerStatus();
    }
    _rebalance->_server_manager.BuildClusterAndSegmentFromServerDiskReplicas();

    pspb::GaiaReblanceSegments rebalance_replicas;
    _rebalance->StartRebalanceReplicas(rebalance_replicas);

    ASSERT_EQ(1, rebalance_replicas.segments_size());
    ASSERT_EQ("c_target", rebalance_replicas.segments(0).src().cluster_id());
}

TEST_F(PsvrRebalanceTests, test_StartRebalanceReplicas_ForOfflineServer) {
    _rebalance->_max_num = 70;
    _rebalance->_disk_max_num = 40;
    _rebalance->_cluster_max_num = 20;
    _rebalance->_max_recovery_num = 100;
    _rebalance->_disk_max_recovery_num = 60;
    _rebalance->_cluster_max_recovery_num = 30;

    std::vector<base::EndPoint> nodes;
    fill_nodes(nodes, 3);
    _rebalance->_server_manager.InitServerMap(nodes);

    auto server1 = _rebalance->_server_manager.server_map[nodes[0]];
    auto server2 = _rebalance->_server_manager.server_map[nodes[1]];
    auto server3 = _rebalance->_server_manager.server_map[nodes[2]];

    // server1 offline, its disks should be pushed to inflation group
    fill_server_response(server1, 1);
    server1->rpc_response.set_topology_to_offline(true);
    fill_server_response(server2, 2);
    fill_server_response(server3, 3);

    // usage is identical; without offline handling, no inflation would exist
    fill_server_response_store(server1, 1, 1ul<<40, 8ul<<40, 100, 800, false, true);
    fill_server_response_store(server2, 1, 1ul<<40, 8ul<<40, 100, 800, false, true);
    fill_server_response_store(server3, 1, 1ul<<40, 8ul<<40, 100, 800, false, true);

    fill_server_response_segment(server1, "c_ok", 1, 0, 1, 32ul<<30);
    fill_server_response_segment(server2, "c_ok", 1, 1, 1, 32ul<<30);

    for (auto& it : _rebalance->_server_manager.server_map) {
        it.second->InitServerStatus();
    }
    _rebalance->_server_manager.BuildClusterAndSegmentFromServerDiskReplicas();

    pspb::GaiaReblanceSegments rebalance_replicas;
    _rebalance->StartRebalanceReplicas(rebalance_replicas);

    // replica on offline server1 should be migrated out
    ASSERT_EQ(1, rebalance_replicas.segments_size());
    ASSERT_EQ("c_ok", rebalance_replicas.segments(0).src().cluster_id());
    ASSERT_EQ(gaiadb::common::endpoint2str(server1->addr),
            rebalance_replicas.segments(0).src().addr());
}

TEST_F(PsvrRebalanceTests, test_StartRebalanceReplicas_ForInflationEmpty_UsageThresholdSkipped) {
    // empty inflation branch: cluster-count rebalance should NOT be blocked
    // by deflation/inflation usage thresholds (P2 fix in PickReplica family)
    _rebalance->_max_num = 70;
    _rebalance->_disk_max_num = 40;
    _rebalance->_cluster_max_num = 20;
    _rebalance->_max_recovery_num = 100;
    _rebalance->_disk_max_recovery_num = 60;
    _rebalance->_cluster_max_recovery_num = 30;

    std::vector<base::EndPoint> nodes;
    fill_nodes(nodes, 6);
    _rebalance->_server_manager.InitServerMap(nodes);

    auto server1 = _rebalance->_server_manager.server_map[nodes[0]];
    auto server2 = _rebalance->_server_manager.server_map[nodes[1]];
    auto server3 = _rebalance->_server_manager.server_map[nodes[2]];
    auto server4 = _rebalance->_server_manager.server_map[nodes[3]];
    auto server5 = _rebalance->_server_manager.server_map[nodes[4]];
    auto server6 = _rebalance->_server_manager.server_map[nodes[5]];

    // all zone=0 to disable zone conflict check
    fill_server_response(server1, 0);
    fill_server_response(server2, 0);
    fill_server_response(server3, 0);
    fill_server_response(server4, 0);
    fill_server_response(server5, 0);
    fill_server_response(server6, 0);

    // all disks at 500 thousandth -> no inflation, no deflation group
    // floating_rate=25 (default), deflation=475, inflation=525
    int64_t total = 1ul<<40;    // 1 TiB
    int64_t used = 1ul<<39;     // 512 GiB -> used_thousandth = 500
    fill_server_response_store(server1, 1, used, total, 100, 800, false, true);
    fill_server_response_store(server2, 1, used, total, 100, 800, false, true);
    fill_server_response_store(server3, 1, used, total, 100, 800, false, true);
    fill_server_response_store(server4, 1, used, total, 100, 800, false, true);
    fill_server_response_store(server5, 1, used, total, 100, 800, false, true);
    fill_server_response_store(server6, 1, used, total, 100, 800, false, true);

    // Cluster skewed: 4 segments each with 2 replicas on {server1, server2}
    // => server1 & server2 are cluster-wise over-concentrated (score >= 2)
    // Moving a 40 GiB replica drops used_thousandth to ~460 < deflation(475)
    // Adding to a target pushes it to ~540 > inflation(525)
    // Old logic would reject both sides; P2 fix skips these checks in empty branch.
    int64_t replica_size = 40ul<<30;
    fill_server_response_segment(server1, "c_skewed", 1, 0, 1, replica_size);
    fill_server_response_segment(server2, "c_skewed", 1, 1, 1, replica_size);
    fill_server_response_segment(server1, "c_skewed", 2, 0, 1, replica_size);
    fill_server_response_segment(server2, "c_skewed", 2, 1, 1, replica_size);
    fill_server_response_segment(server1, "c_skewed", 3, 0, 1, replica_size);
    fill_server_response_segment(server2, "c_skewed", 3, 1, 1, replica_size);
    fill_server_response_segment(server1, "c_skewed", 4, 0, 1, replica_size);
    fill_server_response_segment(server2, "c_skewed", 4, 1, 1, replica_size);

    for (auto& it : _rebalance->_server_manager.server_map) {
        it.second->InitServerStatus();
    }
    _rebalance->_server_manager.BuildClusterAndSegmentFromServerDiskReplicas();

    pspb::GaiaReblanceSegments rebalance_replicas;
    _rebalance->StartRebalanceReplicas(rebalance_replicas);

    // All 4 segments' over-concentrated replica should be migrated out.
    // Targets are server3~server6 (count=0 -> 1 each).
    ASSERT_EQ(4, rebalance_replicas.segments_size());
    for (int32_t i = 0; i < rebalance_replicas.segments_size(); ++i) {
        ASSERT_EQ("c_skewed", rebalance_replicas.segments(i).src().cluster_id());
        const auto& dest_addr = rebalance_replicas.segments(i).dest().addr();
        // target must not be server1/server2 (both already hold the cluster)
        ASSERT_NE(gaiadb::common::endpoint2str(server1->addr), dest_addr);
        ASSERT_NE(gaiadb::common::endpoint2str(server2->addr), dest_addr);
    }
}


}
}
