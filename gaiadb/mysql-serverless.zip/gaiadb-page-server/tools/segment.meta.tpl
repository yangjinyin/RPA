[segment]
cluster_id = %(cluster_id)
segment_id = %(segment_id)
segment_size = %(segment_size)
replica_id = %(replica_id)
# status: Creating, Open, Close
status = %(status)
manager_address = %(manager_address)
