/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/load_page_server_segment.h
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/load_page_server_segment.h"

namespace psvr {
namespace gaia {

int LoadPageServerSegment::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    if (_cluster_id.empty()) {
        print_error("miss --cluster-id or -c");
        return 1;
    }

    if (!_segment_id.has_val || _segment_id.val < 1) {
        print_error("miss or error --segment-id or -s");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    RpcStatus status;
    pspb::LoadSegmentRequest request;
    pspb::LoadSegmentResponse response;

    request.set_log_id(_log_id);
    request.set_cluster_id(_cluster_id);
    request.set_segment_id(_segment_id.val);

    _client.Call(_log_id++, node, &pspb::ManagerService_Stub::LoadSegment, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int LoadPageServerSegment::Format(const pspb::LoadSegmentResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
