/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/write_ibd_page_data.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class WriteIbdPageData : public Command {
public:
    WriteIbdPageData() {
        SetName("write-ibd-page-data");
        SetDesc("write ibd file page data, set page data to init type or reset zero");
        SetDescCn("写入 ibd 文件页面数据, 设置页面为初始类型或清零");

        AddPsmClusterOption(kGroup2Scope);
        AddRequiredArgOption("cluster-id", NULL, 'c', "cluster id", kstring, kGroup2Scope);
        AddNodeOption(kGroup3Scope);
        AddRequiredArgOption("segment-id", NULL, 's', "segment id", kuint32_t, kGroup3Scope);
        AddRequiredArgOption("ibd-file", &_long_opt_val, kOptMax + 1, "ibd file path name", kstring);
        AddRequiredArgOption("offset", &_long_opt_val, kOptMax + 2, "ibd file check start offset", kuint64_t);
        AddRequiredArgOption("type", &_long_opt_val, kOptMax + 3, "operation type: init, clear, replace", kenum);
        AddRequiredArgOption("space-id", &_long_opt_val, kOptMax + 4,
                "space id of init page data",
                kuint32_t, kGroup4Scope);
        AddRequiredArgOption("page-no", &_long_opt_val, kOptMax + 5,
                "page no of init page data",
                kuint32_t, kGroup4Scope);
        AddRequiredArgOption("lsn", &_long_opt_val, kOptMax + 6, "lsn of init page data", kuint64_t, kGroup4Scope);
        AddRequiredArgOption("page-num", &_long_opt_val, kOptMax + 7, "update page size, default 1", kuint64_t);
        AddRequiredArgOption("replace-file", &_long_opt_val, kOptMax + 8,
                "read file data replace offset",
                kstring, kGroup4Scope);
        AddNoArgOption("backup", &_long_opt_val, kOptMax + 9, "backup before update page", kGroup5Scope);
        AddRequiredArgOption("shift", &_long_opt_val, kOptMax + 10,
                "the offset shift page num",
                kuint64_t, kGroup5Scope);
        AddNoArgOption("use-bytes", &_long_opt_val, kOptMax + 11,
                "set use_bytes type to get meta data, default false",
                kGroup5Scope);
        AddNoArgOption("align", &_long_opt_val, kOptMax + 12, "align offset to extent size", kGroup5Scope);

        AddExample("--ibd-file xx.ibd --offset 0 --type init --space-id 1 --page-no 1 --lsn 10240");
        AddExample("--ibd-file xx.ibd --offset 0 --type clear");
        AddExample("--ibd-file xx.ibd --offset 0 --type clear --page-num 64");
        AddExample("--ibd-file xx.ibd --offset 0 --type replace --replace-file file");
        AddExample("--ibd-file xx.ibd --offset 0 --type clear --manager-address \"bns://xx\" --cluster xx");
        AddExample("-a ip -p port --segment-id xx --offset 0 --type clear --manager-address \"bns://xx\" --cluster xx");
    }
    virtual ~WriteIbdPageData() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id = std::strtoul(opt, NULL, 10);
            break;
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _ibd_file = opt;
                break;
            case kOptMax + 2:
                _set_offset = true;
                _offset = std::strtoull(opt, nullptr, 10);
                break;
            case kOptMax + 3:
                _type = opt;
                break;
            case kOptMax + 4:
                _set_space_id = true;
                _space_id = std::strtoull(opt, nullptr, 10);
                break;
            case kOptMax + 5:
                _set_page_no = true;
                _page_no = std::strtoull(opt, nullptr, 10);
                break;
            case kOptMax + 6:
                _set_lsn = true;
                _lsn = std::strtoull(opt, nullptr, 10);
                break;
            case kOptMax + 7:
                _page_num = std::strtoull(opt, nullptr, 10);
                break;
            case kOptMax + 8:
                _replace_file = opt;
                break;
            case kOptMax + 9:
                _backup = true;
                break;
            case kOptMax + 10:
                _shift = std::strtoull(opt, nullptr, 10);
                break;
            case kOptMax + 11:
                _use_bytes = true;
                break;
            case kOptMax + 12:
                _align = true;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;
    bool Read(const base::EndPoint& node,
        uint64_t offset, uint64_t size, gaia_apply::byte* buf);
    bool CheckPageInfo(std::vector<base::EndPoint>& nodes,
        uint32_t space_id, uint32_t extent_id);

private:
    std::string _ibd_file {};
    std::string _address {};
    int32_t _port {};
    std::string _cluster_id {};
    uint32_t _segment_id {std::numeric_limits<uint32_t>::max()};
    std::string _manager_address {};
    bool _use_bytes {false};
    bool _set_offset {false};
    uint64_t _offset {0};
    bool _align {false};
    std::string _type {};
    bool _set_space_id {false};
    uint32_t _space_id {0};
    bool _set_page_no {false};
    uint32_t _page_no {0};
    bool _set_lsn {false};
    uint64_t _lsn {0};
    uint64_t _page_num {0};
    uint64_t _shift {0};
    std::string _replace_file {};
    bool _backup {false};
    int _fd {-1};
    uint64_t _file_size {0};
};

}
}
