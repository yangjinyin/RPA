/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/read_buf_pool_page.h
* @author guolingjie@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ReadBufPoolPage : public Command {
public:
    ReadBufPoolPage() {
        SetName("read-bp-page");
        SetDesc("read one page from primary buffer pool");
        SetDescCn("从主计算节点缓冲池读取一个页面");

        AddNodeOption();
        AddRequiredArgOption("space-id", &_long_opt_val, kOptMax + 1,
                "read page from tablespace that matches the tablespace id",
                kuint32_t);
        AddRequiredArgOption("page-no", &_long_opt_val, kOptMax + 2,
                "the number of page which you want to read",
                kuint32_t);
        AddNoArgOption("dump-page", &_long_opt_val, kOptMax + 3, "dump page data to file", kGroup2Scope);

        AddExample("-m -a <ip> -p <port> --space-id 7 --page-no 1");
    }
    virtual ~ReadBufPoolPage() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _space_id = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 2:
                _page_no = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 3:
                _dump_page = true;
                break;
            default:
                return 1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format != kRaw) {
            print_error("only support raw format, continue exporting in raw format");
        }

        return Format(rsp);
    }

    int Format(const cmppb::ReadPageFromBPResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    uint32_t _space_id {std::numeric_limits<uint32_t>::max()};
    uint32_t _page_no {std::numeric_limits<uint32_t>::max()};
    bool _dump_page {false};
};

}
}
