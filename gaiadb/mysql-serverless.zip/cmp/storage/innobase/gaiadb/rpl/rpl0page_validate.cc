/*****************************************************************************

Copyright (c) 2021, Baidu Inc. All Rights Reserved.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License, version 2.0, as published by the
Free Software Foundation.

This program is also distributed with certain software (including but not
limited to OpenSSL) that is licensed under separate terms, as designated in a
particular file or component or in included license documentation. The authors
of MySQL hereby grant you an additional permission to link the program and
your derivative works with the separately licensed software that they have
included with MySQL.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License, version 2.0,
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

*****************************************************************************/

/**
 Gaiadb primary page validator against page server

 Created 4/20/2022 Shenghu ZHU
 *******************************************************/


#include "rpl0rpl.h"
#include "rbio.h"
#include "fil0types.h"
#include "buf0checksum.h"
#include "ut0crc32.h"
#include "rpl0conductor.h"
#include "rpl0pv.h"
#include "os0thread-create.h"

#ifdef ENABLED_GAIADB_PAGE_VALIDATION
mysql_pfs_key_t rpl_page_validator_thread_key;
#endif

namespace rpl {

#ifdef ENABLED_GAIADB_PAGE_VALIDATION
my_off_t rpl_page_validation_file_offset = 0;
lsn_t rpl_start_apply_lsn = 0;
struct drirty_page {
drirty_page(space_id_t spaceid, page_no_t page_no,
                   uint32_t page_size, ib_uint32_t chksum, 
                   uint64_t page_data_offset)
                   : m_space_id(spaceid), m_page_no(page_no),
                   m_page_size(page_size), m_chksum(chksum),
                   m_page_data_offset(page_data_offset) { }

  space_id_t  m_space_id; /*4 bytes*/
  page_no_t   m_page_no;  /*4 bytes*/
  uint32_t    m_page_size; /*4 bytes*/
  ib_uint32_t m_chksum;  /*4 bytes*/
  uint64_t    m_page_data_offset; /*8 bytes*/
};

struct mtr_modified_pages{
  lsn_t end_lsn;
  std::vector<drirty_page> dirty_pages;
};


void rpl_page_validator() {
  DBUG_ENTER("rpl_page_validator");
  #ifdef UNIV_LINUX
  /** set high priority to rpl_page_validator thread */
  setpriority(PRIO_PROCESS, (pid_t)syscall(SYS_gettid), -20);
  #endif /* UNIV_LINUX */
  pthread_setname_np(pthread_self(), "rpl_page_validator");

  rpl_start_apply_lsn = g_rpl_conductor->apply_lsn();
  ib_info(ER_IB_GAIA_MSG_RPL) << "Gaia replication page validator threads started"
                              << ", rpl_start_apply_lsn="<<rpl_start_apply_lsn;

  while(true){
    if (rpl_sys->should_stop()) {
      break;
    }
    uchar ubuf[1024*1024];
    size_t readbytes = my_pread(rpl_page_validation_file_fd, ubuf , 1024*1024, rpl_page_validation_file_offset, MYF(0));
    if(readbytes <=0 || readbytes<4){ // number of page occupy 4 bytes
      ib_info(ER_IB_GAIA_MSG_RPL) << " rpl_page_validator, my_pread got bytes="<<readbytes;
      std::this_thread::sleep_for(std::chrono::microseconds(500*10000));
      continue;
    }

    int leftbytes = readbytes;
    std::vector<mtr_modified_pages> mtr_modified_pages_vec;
    byte *buf = ubuf;
    while(leftbytes >= 0 ){
      ut_a((uint64_t)(buf-(byte*)ubuf) == (uint64_t)(readbytes - leftbytes));

      if(leftbytes < 4){
        rpl_page_validation_file_offset += readbytes - leftbytes;
        break;
      }
      uint32_t num_page = mach_read_from_4(buf);
      int total_size = PAGE_VALIDATION_TOTAL_SIZE(num_page);
      if(leftbytes < total_size){
        rpl_page_validation_file_offset += readbytes - leftbytes;
        break;
      }

      uint32_t data_chksum = ut_crc32(buf, total_size - 4);
      if(data_chksum != mach_read_from_4(buf + total_size - 4)){
        ib_error(ER_IB_GAIA_MSG_RPL) << "rpl_page_validator, data is not correct, will try read the file again";
        rpl_page_validation_file_offset += readbytes - leftbytes;
        break;
      }
      
      buf += 4;
      lsn_t end_lsn = mach_read_from_8(buf);
      buf += 8;
      mtr_modified_pages modified_pages;
      modified_pages.end_lsn = end_lsn;
      modified_pages.dirty_pages.reserve(num_page);
      for(auto i = 0; i < (int)num_page; i++){
        auto space_id = mach_read_from_4(buf);
        buf += 4;
        auto page_no = mach_read_from_4(buf);
        buf += 4;
        auto page_size = mach_read_from_4(buf);
        buf += 4;
        auto chksum = mach_read_from_4(buf);
        buf +=4;
        auto page_data_offset = mach_read_from_8(buf);
        buf += 8;

        modified_pages.dirty_pages.emplace_back(drirty_page(space_id, page_no, page_size, chksum, page_data_offset));
      }
      buf += 4; // data check sum
      mtr_modified_pages_vec.emplace_back(modified_pages);
      leftbytes -= total_size;
    }

    for(auto vect : mtr_modified_pages_vec){
      if(vect.end_lsn < rpl_start_apply_lsn){
        //before this fake secondary start, primary may produce some redo logs, for those redo logs, 
        //end lsn may less than the start apply lsn of this fake secondary, 
        //so skip validate those redo logs because query page from page_server may got a page with an greater lsn 
        continue;
      }
      for(auto item : vect.dirty_pages){
        page_id_t page_id(item.m_space_id, item.m_page_no);
        page_size_t page_size(item.m_page_size, item.m_page_size, false);
        byte page_buf[65536]; //maximum page size 64KB
        lsn_t vlsn = vect.end_lsn > g_rpl_conductor->apply_lsn() ? vect.end_lsn : g_rpl_conductor->apply_lsn();
        auto err = RbioClient::get_instance().get_page(page_server::RbioRequest_Type_READ_SYNC, 
            page_id, page_size, page_buf, NULL, true, false, vlsn); 
        ut_a(err == DB_SUCCESS);
        ib_uint32_t header_chksum = mach_read_from_4(page_buf + FIL_PAGE_SPACE_OR_CHKSUM);
        ib_uint32_t tailer_chksum = mach_read_from_4(page_buf + item.m_page_size - FIL_PAGE_END_LSN_OLD_CHKSUM);
        if(header_chksum != tailer_chksum){
          ib_error(ER_IB_GAIA_MSG_RPL) << "page validation failed, got corrupted page form ps for space_id=" 
            <<item.m_space_id <<", page_no="<<item.m_page_no;
            continue;
        }

        ib_uint32_t calc_chksum = buf_calc_page_crc32_exclude_fil_page_lsn(page_buf, item.m_page_size);
        if(calc_chksum != item.m_chksum){
          ib_error(ER_IB_GAIA_MSG_RPL) << "page validation failed for space_id="<<item.m_space_id <<", page_no="<<item.m_page_no
          << ", end_lsn="<<vect.end_lsn << ", vlsn="<<vlsn<<", cmp chksum ="<<item.m_chksum 
          << ", ps calc_chksum ="<<calc_chksum <<", vdl="<< g_rpl_conductor->apply_lsn()
          << ", page_data_offset="<<item.m_page_data_offset;
          std::string nam = "====page_validator===="; 
          debug_for_buf_hexdump(nam.c_str(), page_buf, UNIV_PAGE_SIZE);
        }
       
      }

      if(vect.end_lsn > g_rpl_conductor->apply_lsn()) {
        g_rpl_conductor->update_apply_lsn(vect.end_lsn);
      }

    }
  }

  ib_info(ER_IB_GAIA_MSG_RPL) << "Gaia replication page validator threads stopped";
  DBUG_VOID_RETURN;
}

File rpl_page_validation_file_fd;

bool page_validator_init() {
  std::string page_validation_file = "page_validation";
  char *page_validation_file_name = Fil_path::make(
      srv_gaia_page_validation_dir, page_validation_file, NO_EXT);
  rpl_page_validation_file_fd =
      my_open(page_validation_file_name, O_RDONLY, MYF(0));
  if (rpl_page_validation_file_fd < 0) {
    ib_error(ER_IB_GAIA_MSG_RPL)
        << "open file failed, filename=" << page_validation_file_name;
    ut_free(page_validation_file_name);
    std::exit(-1);
  }
  ut_free(page_validation_file_name);
  return (true);
}

bool page_validator_is_active() {
  return (srv_thread_is_active(srv_threads.m_rpl_page_validator));
}

void start_page_validator_thread() {
  if (!srv_fake_gaia_secondary) return;
  srv_threads.m_rpl_page_validator =
      os_thread_create(rpl_page_validator_thread_key, rpl_page_validator);
  srv_threads.m_rpl_page_validator.start();
  ut_a(page_validator_is_active());
}

void debug_for_buf_hexdump(
    const char *name, /*!< in: name of the data structure */
    const void *buf,  /*!< in: data */
    ulint size)       /*!< in: length of the data, in bytes */
{
  const byte *s = static_cast<const byte *>(buf);
  ulint addr;
  const ulint width = 16; /* bytes per line */
  fprintf(stderr, "%s:\n", name);
  for (addr = 0; addr < size; addr += width) {
    ulint i;
    fprintf(stderr, "%04lx ", (ulong)addr);
    i = ut_min(width, size - addr);
    while (i--) {
      fprintf(stderr, "%02x ", *s++);
      if (i == 8) {
        fprintf(stderr, " ");
      }
    }
    putc('\n', stderr);
  }
}
#endif
} // namespace rpl
