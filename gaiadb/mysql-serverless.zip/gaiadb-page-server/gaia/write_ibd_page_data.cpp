/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/write_ibd_page_data.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include <sys/ioctl.h>
#include <termios.h>
#include <sys/stat.h>
#include <gaiadb/utils/ut.h>
#include "psvr/common.h"
#include "psvr/utils.h"
#include "psvr/config.h"
#include "psvr/log.h"
#include "psvr/compress_utils.h"
#include "psvr/page_op.h"
#include "psvr/psminfo.h"
#include "gaia/write_ibd_page_data.h"

namespace psvr {
namespace gaia {

bool WriteIbdPageData::Read(const base::EndPoint& node,
        uint64_t offset, uint64_t size, gaia_apply::byte* buf) {
    RpcStatus status;
    pspb::ReadRequest request;
    pspb::ReadResponse response;

    request.set_cluster_id(_cluster_id);
    request.set_segment_id(_segment_id);
    request.set_offset(offset);
    request.set_size(size);

    _client.Call(_log_id, node, &pspb::QueryService_Stub::Read, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        LOG(NOTICE) << status;
        return false;
    }
    if (response.status().code() != pspb::Status::SUCCESS) {
        LOG(NOTICE) << response.status();
        return false;
    }
    if (response.size() != size) {
        LOG(NOTICE) << "miss response size";
        return false;
    }
    memcpy(buf, response.data().c_str(), response.size());
    return true;
}

bool WriteIbdPageData::CheckPageInfo(std::vector<base::EndPoint>& nodes,
        uint32_t space_id, uint32_t extent_id) {
    RpcStatus status;
    gaiapb::GetSpaceExtentMapRequest request;
    gaiapb::GetSpaceExtentMapResponse response;

    request.set_cluster_id(_cluster_id);
    request.set_space_id(space_id);
    request.set_begin_extent_id(extent_id);
    request.set_num(1);
    request.set_need_physical_extent_id(true);
    request.set_use_bytes(_use_bytes);

    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::QueryService_Stub::get_space_extent_map, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            gaiapb::GetSpaceExtentMapResponse response2;
            response2.mutable_status()->CopyFrom(response.status());
            response2.set_total_extent_num(response.total_extent_num());
            if (response.has_extent_map_bytes()) {
                struct ExtentMap {
                    uint32_t segment_id;
                    uint32_t extent_id;
                };
                const ExtentMap* entry = reinterpret_cast<const ExtentMap*>(response.extent_map_bytes().c_str());
                const uint32_t count = response.extent_map_bytes().length() / sizeof(*entry);
                for (uint32_t i = 0; i < count; ++i) {
                    auto m = response2.mutable_extent_map()->add_entries();
                    m->set_segment_id(entry->segment_id);
                    m->set_physical_extent_id(entry->extent_id);
                    ++entry;
                }
            } else {
                response2.mutable_extent_map()->CopyFrom(response.extent_map());
            }

            const auto& extent_map = response2.extent_map();
            if (extent_map.entries_size() > 0) {
                const auto& m = extent_map.entries(0);
                std::cout << "on_segment_id:[" << m.segment_id()
                    << "] physical_extent_id:[" << m.physical_extent_id()
                    << "]";
                return true;
            }
            LOG(NOTICE) << "not found extent map";
            return false;
        } else {
            LOG(WARNING) << node << " get space extend failed, " << status << " " << response.status();
        }
    }
    return false;
}

int WriteIbdPageData::Run() {
    gaiadb::common::ut_crc32_init();
    BufPool buf_pool;

    std::vector<base::EndPoint> psm_nodes;
    if (!_manager_address.empty()) {
        PsmInfo psm_info(_manager_address, _both);
        if (!psm_info.GetOrRefreshNodes(&psm_nodes)) {
            print_error("--manager-addr parse failed, cant get server list");
            return 1;
        }
        if (_cluster_id.empty()) {
            print_error("miss --cluster-id");
            return 1;
        }
    }

    bool local = true;
    base::EndPoint remote_node;
    if (!_ibd_file.empty()) {
        if (!_address.empty() || _port > 0) {
            print_error("use --ibd-file, invalid --address or --port");
            return 1;
        }
    } else {
        if (_address.empty() || _port == 0) {
            print_error("miss --ibd-file or remote args");
            return 1;
        }
        int ret = base::str2endpoint(_address.c_str(), _port, &remote_node);
        if (ret != 0) {
            print_error("--address and --port convert to endpoint error");
            return 1;
        }
        if (_segment_id == std::numeric_limits<uint32_t>::max()) {
            print_error("miss --segment-id");
            return 1;
        }
        local = false;
    }

    if (!_set_offset) {
        print_error("miss --offset");
        return 1;
    }

    if (_align) {
        _offset = (_offset / GAIADB_EXTENT_SIZE) * GAIADB_EXTENT_SIZE;
    }

    if (_type.empty() || (_type != "init" && _type != "clear" && _type != "replace")) {
        print_error("miss --type or not support");
        return 1;
    }

    gaia_apply::byte* replace_buf = nullptr;
    std::shared_ptr<nullptr_t> replace_buf_guard(nullptr, [&replace_buf](nullptr_t){
                std::free(replace_buf);
            });

    std::string confirm_msg;
    if (_type == "init") {
        confirm_msg = "Reset page to init type";
        if (!_set_space_id) {
            print_error("miss --space-id");
            return -1;
        }
        if (!_set_page_no) {
            print_error("miss --page-no");
            return -1;
        }
        if (!_set_lsn) {
            print_error("miss --lsn");
            return -1;
        }

        if (_page_num != 0) {
            print_error("invalid --page-num and --type is init");
            return -1;
        }
        _page_num = 1;
    } else if (_type == "replace") {
        if (_page_num > 64) {
            print_error("invalid --page-num, need less than 64");
            return 1;
        }
        confirm_msg = "Replace page data";
        if (_replace_file.empty()) {
            print_error("miss --replace-file");
            return -1;
        }
        int fd = open(_replace_file.c_str(), O_RDONLY, S_IRUSR | S_IWUSR);
        if (fd < 0) {
            print_error("open replace file failed, %s", strerror(errno));
            return 1;
        }

        replace_buf = static_cast<gaia_apply::byte*>(std::malloc(_page_num * gaia_apply::FLAGS_univ_page_size));
        if (!replace_buf) {
            print_error("malloc replace page buffer failed");
            close(fd);
            return 1;
        }
        ssize_t r = pread(fd, replace_buf, _page_num * gaia_apply::FLAGS_univ_page_size, 0);
        if (r != static_cast<ssize_t>(_page_num * gaia_apply::FLAGS_univ_page_size)) {
            print_error("replace page file size invalid");
            close(fd);
            return 1;
        }
        close(fd);

        for (uint64_t i = 0; i < _page_num; ++i) {
            bool is_empty = false;
            if (page_is_corrupted(replace_buf + i * gaia_apply::FLAGS_univ_page_size,
                        gaia_apply::FLAGS_univ_page_size, &is_empty)) {
                print_error("replace page is corrupted");
                return 1;
            }

            if (is_empty) {
                print_error("replace page is empty, idx:%lu", i);
                return 1;
            }
        }
    } else {
        assert(_type == "clear");
        confirm_msg = "Clear page data";
        if (_page_num < 1) {
            _page_num = 1;
        }
    }

    if (_shift >= _page_num) {
        print_error("invalid --shift, need less than --page-num");
        return 1;
    }

    if (gaia_apply::FLAGS_univ_page_size == 0) {
        print_error("invalid flags -univ_page_size");
        return 1;
    }

    if (local) {
        struct stat sbuf;
        if (stat(_ibd_file.c_str(), &sbuf) != 0) {
            print_error("get ibd file size failed");
            return 1;
        }

        _file_size = sbuf.st_size;
        if (_file_size % gaia_apply::FLAGS_univ_page_size != 0 || _file_size == 0) {
            print_error("ibd file size not right, %lu", _file_size);
            return 1;
        }

        if (_offset >= _file_size || _offset % gaia_apply::FLAGS_univ_page_size != 0) {
            print_error("invalid offset, %lu", _offset);
            return 1;
        }
    }

    int backup_fd = -1;
    GuardFd guard_backup_fd(backup_fd);
    if (_backup) {
        std::string backup_fname = std::to_string(_offset) + "_offset.bak";
        auto flags = O_CREAT | O_RDWR;
        if (!_force) {
            flags |= O_EXCL;
        }
        backup_fd = open(backup_fname.c_str(), flags, S_IRUSR | S_IWUSR);
        if (backup_fd < 0) {
            print_error("open backup file failed, %s", strerror(errno));
            return 1;
        }
    }

    GuardFd guard_fd(_fd);
    if (local) {
        _fd = open(_ibd_file.c_str(), O_RDWR, S_IRUSR | S_IWUSR);
        if (_fd < 0) {
            print_error("open ibd file failed, %s", strerror(errno));
            return 1;
        }
    }

    auto buf_block = buf_pool.AllocBufBlock(gaia_apply::FLAGS_univ_page_size, nullptr);
    auto frame = buf_block->frame;

    size_t data_page_num = 0;
    uint32_t last_extent_id = std::numeric_limits<uint32_t>::max();
    for (uint64_t i = _shift; i < _page_num; ++i) {
        const auto off = _offset + i * gaia_apply::FLAGS_univ_page_size;
        if (local) {
            const ssize_t read_size  = pread(_fd, frame, gaia_apply::FLAGS_univ_page_size, off);
            if (read_size != static_cast<ssize_t>(gaia_apply::FLAGS_univ_page_size)) {
                print_error("read ibd file data error, off:%lu size: %ld, error: %m", off, read_size);
                return -1;
            }
        } else {
            const bool rc = Read(remote_node, off, gaia_apply::FLAGS_univ_page_size, frame);
            if (!rc) {
                print_error("read remote data error, off:%lu, see detail on gaia.log", off);
                return -1;
            }
        }

        std::unique_ptr<gaia_apply::byte[]> decompress_buf(new gaia_apply::byte[gaia_apply::FLAGS_univ_page_size]);
        if (!decompress_page(frame, decompress_buf.get(), gaia_apply::FLAGS_univ_page_size)) {
            print_error("decompress page data error");
            return -1;
        }

        bool is_empty = false;
        if (!page_is_corrupted(frame, gaia_apply::FLAGS_univ_page_size, &is_empty)) {
            if (!is_empty) {
                ++data_page_num;
                const uint32_t space_id = gaia_apply::page_get_space_id(frame);
                const uint32_t page_no = gaia_apply::page_get_page_no(frame);
                const uint32_t logic_extent_id = page_no / GAIADB_EXTENT_PAGE_NUM;
                std::cout << "show current page data info,"
                    << " idx:[" << i
                    << "] offset:[" << off
                    << "] page_size:[" << gaia_apply::FLAGS_univ_page_size
                    << "] space_id:[" << space_id
                    << "] page_no:[" << page_no
                    << "] lsn:[" << page_get_page_lsn(frame)
                    << "] logical_extent_id:[" << logic_extent_id
                    << "] physical_extent_id:[" << (off / GAIADB_EXTENT_SIZE)
                    << "] ";
                if (!_manager_address.empty() && last_extent_id != logic_extent_id) {
                    last_extent_id = logic_extent_id;
                    const bool rc = CheckPageInfo(psm_nodes, space_id, logic_extent_id);
                    if (!rc) {
                        std::cout << std::endl;
                        print_error("check data error, off:%lu, see detail on gaia.log", off);
                        return -1;
                    }
                }
                std::cout << std::endl;
            } else {
                std::cout << "current page data is empty,"
                    << " offset:[" << off
                    << "] page_size:[" << gaia_apply::FLAGS_univ_page_size
                    << "]" << std::endl;
            }
        } else {
            std::cout << "current page data is corrupted!" << std::endl;
        }

        if (_type == "replace") {
            auto rbuf = replace_buf + i * gaia_apply::FLAGS_univ_page_size;
            std::cout << "show replace page data info,"
                << " idx:[" << i
                << "] offset:[" << off
                << "] page_size:[" << gaia_apply::FLAGS_univ_page_size
                << "] space_id:[" << gaia_apply::page_get_space_id(rbuf)
                << "] page_no:[" << gaia_apply::page_get_page_no(rbuf)
                << "] lsn:[" << page_get_page_lsn(rbuf)
                << "] logical_extent_id:[" << gaia_apply::page_get_page_no(rbuf) / GAIADB_EXTENT_PAGE_NUM
                << "] physical_extent_id:[" << (off / GAIADB_EXTENT_SIZE)
                << "]" << std::endl;
        }

        if (_backup) {
            ssize_t backup_w = pwrite(backup_fd, frame,
                    gaia_apply::FLAGS_univ_page_size, i * gaia_apply::FLAGS_univ_page_size);
            if (backup_w != static_cast<ssize_t>(gaia_apply::FLAGS_univ_page_size)) {
                std::cout << "back page data fail!"
                    << " off:[" << i * gaia_apply::FLAGS_univ_page_size
                    << "]" << std::endl;
                return -1;
            }
        }
    }

    std::cout << "total_num:" << _page_num << ", data_page_num:" << data_page_num << std::endl;

    if (_type == "init") {
        assert(_page_num == 1);
        gaia_apply::page_size_t page_size(gaia_apply::FLAGS_univ_page_size,
                gaia_apply::FLAGS_univ_page_size, false);
        init_buf_block(buf_block, _space_id, _page_no, page_size);
        INIT_APPLY_RAW_ARG(false);
        gaia_apply::fsp_init_file_page(buf_block.get() APPLY_RAW_ARG_NAME_CC);
        if (APPLY_RAW_IS_ERROR()) {
            print_error("init page buf failed");
            return -1;
        }
        buf_block_set_page_lsn(buf_block, _lsn);
        if (!buf_block_reset_checksum(buf_block, _lsn)) {
            print_error("reset page checksum failed");
            return -1;
        }
    } else if (_type == "replace") {
        // nothing
    } else {
        assert(_type == "clear");
        memset(frame, '\0', gaia_apply::FLAGS_univ_page_size);
    }

    if (!_force) {
        if (!execute_confirm(confirm_msg.c_str())) {
            std::cout << "quit!" << std::endl;
            return -1;
        }
    }

    if (_backup) {
        if (fsync(backup_fd) != 0) {
            print_error("sync backup file error, error:%s", strerror(errno));
            return -1;
        }
    }

    if (!local) {
        print_error("remote unsupport write data");
        return 1;
    }

    for (uint64_t i = _shift; i < _page_num; ++i) {
        auto off = _offset + i * gaia_apply::FLAGS_univ_page_size;
        if (_type == "replace") {
            frame = replace_buf + i * gaia_apply::FLAGS_univ_page_size;
        }
        ssize_t write_size = pwrite(_fd, frame, gaia_apply::FLAGS_univ_page_size, off);
        if (write_size != static_cast<ssize_t>(gaia_apply::FLAGS_univ_page_size)) {
            print_error("write ibd file data error, size: %ld, error: %s", write_size, strerror(errno));
            return -1;
        }
        std::cout << "idx: " << i << " write off:" << off <<  " data ok!" << std::endl;
    }
    return 0;
}

}
}
