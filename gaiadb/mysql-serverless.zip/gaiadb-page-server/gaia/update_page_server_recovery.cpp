/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/update_page_server_recovery.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/update_page_server_recovery.h"

namespace psvr {
namespace gaia {

int UpdatePageServerRecovery::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    if (_cluster_id.size() && _segments.size()) {
        print_error("choice one bettween --multi-segment and --cluster-id");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    RpcStatus status;
    if (!_multi_type) {
        if (_segments.size()) {
            print_error("--multi-segment is disable in single type");
            return 1;
        }
        if ((_cluster_id.size() && !_segment_id.has_val)
                || (_cluster_id.empty() && _segment_id.has_val)) {
            print_error("--cluster-id and --segment-id should always appear in pairs in single type");
            return 1;
        }
        if (_segment_id.has_val && _segment_id.val < 1) {
            print_error("error --segment-id:%u", _segment_id.val);
            return 1;
        }

        if (!_recover_enable.has_val && !_recover_force.has_val) {
            print_error("miss --recover-enable and --recover-force");
            return 1;
        }

        if (!_force) {
            bool cf_ret = execute_confirm("Update segment recovery info?");
            if (!cf_ret) {
                return 1;
            }
        }

        pspb::SetRecoverInfoRequest request;
        pspb::SetRecoverInfoResponse response;
        request.set_log_id(_log_id);
        if (_recover_enable.has_val) {
            request.set_recover_enable(_recover_enable.val);
        }
        if (_recover_force.has_val) {
            request.set_recover_force(_recover_force.val);
        }
        if (_segment_id.has_val) {
            request.set_cluster_id(_cluster_id);
            request.set_segment_id(_segment_id.val);
        }
        _client.Call(_log_id++, node, &pspb::ManagerService_Stub::SetRecoverInfo, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }
        return Output(response);
    } else {
        pspb::MultiSetRecoverInfoRequest request;
        pspb::MultiSetRecoverInfoResponse response;

        request.set_log_id(_log_id);
        if (_segments.size()) {
            std::string error;
            ret = JsonToProtoMessage(_segments, &request, &error);
            if (!ret) {
                print_error("--multi-segment convert error, %s", error.c_str());
                return 1;
            }
        } else if (_cluster_id.size()) {
            if (!_recover_enable.has_val && !_recover_force.has_val) {
                print_error("miss --recover-enable and --recover-force");
                return 1;
            }
            auto segment_pb = request.add_segments();
            segment_pb->set_cluster_id(_cluster_id);
            if (_segment_id.has_val) {
                if (_segment_id.val < 1) {
                    print_error("error --segment-id:%u", _segment_id.val);
                    return 1;
                }
                segment_pb->set_segment_id(_segment_id.val);
            }
            if (_recover_enable.has_val) {
                segment_pb->set_recover_enable(_recover_enable.val);
            }
            if (_recover_force.has_val) {
                segment_pb->set_recover_force(_recover_force.val);
            }
        }

        if (!_force) {
            bool cf_ret = execute_confirm("Update segment recovery info (m)?");
            if (!cf_ret) {
                return 1;
            }
        }
        _client.Call(_log_id++, node, &pspb::ManagerService_Stub::MultiSetRecoverInfo, &request, &response,
                nullptr, &status, _timeout_ms);
        if (!status.IsOk()) {
            response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
            response.mutable_status()->set_msg(status.msg);
        }
        return Output(response);
    }
}

int UpdatePageServerRecovery::Format(const pspb::SetRecoverInfoResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"recover_enable:", rsp.recover_enable() ? "on" : "off"});
    table.AddRowsValue({"recover_force:", rsp.recover_force() ? "on" : "off"});
    table.Display();
    return 0;
}

int UpdatePageServerRecovery::Format(const pspb::MultiSetRecoverInfoResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    if (rsp.segments_size()) {
        Table table(_raw_with_table, 0);
        table.AddRowsWithName({"segment", "status"}, true);
        for (auto& seg_pb : rsp.segments()) {
            if (seg_pb.status().code() != pspb::Status_ReturnCode_SUCCESS) {
                table.AddRowsValue({
                            RowStr(seg_pb.cluster_id(), seg_pb.segment_id()),
                            RowStr(pspb::Status_ReturnCode_Name(seg_pb.status().code()), seg_pb.status().msg())
                        });
            } else {
                table.AddRowsValue({
                            RowStr(seg_pb.cluster_id(), seg_pb.segment_id()),
                            RowStr(RowStr("enable", seg_pb.recover_enable() ? "on" : "off"),
                                    RowStr("force", seg_pb.recover_force() ? "on" : "off"))
                        });
            }
        }
        table.Display();
    }
    return 0;
}

}
}
