/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/read_page_server_page.h
* @author guolingjie@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class ReadPageServerPage : public Command {
public:
    ReadPageServerPage() {
        SetName("read-ps-page");
        SetDesc("read one page from page server");
        SetDescCn("从页面服务器读取一个页面");

        AddNodeOption();
        AddRequiredArgOption("cluster-id", NULL, 'c',
                "read page from the cluster that matches the cluster id", kstring);
        AddRequiredArgOption("segment-id", NULL, 's',
                "read page from the segment that matches the segment id", kuint32_t);
        AddRequiredArgOption("space-id", &_long_opt_val, kOptMax + 3,
                "read page from tablespace that matches the tablespace id",
                kuint32_t, kGroup2Scope);
        AddRequiredArgOption("page-no", &_long_opt_val, kOptMax + 4,
                "the number of page which you want to read",
                kuint32_t, kGroup2Scope);
        AddRequiredArgOption("vlsn", &_long_opt_val, kOptMax + 5, "the lsn of page which you want to read", kuint64_t);
        AddRequiredArgOption("zip-len", &_long_opt_val, kOptMax + 6,
                "physical size of page, default: 16384", kuint32_t);
        AddRequiredArgOption("offset", &_long_opt_val, kOptMax + 7, "the data file offset", kuint64_t, kGroup3Scope);
        AddNoArgOption("dump-page", &_long_opt_val, kOptMax + 8, "dump page data to file", kGroup4Scope);
        AddNoArgOption("direct", &_long_opt_val, kOptMax + 9, "read physical data, no apply records", kGroup3Scope);

        AddExample("-m -a <ip> -p <port> --cluster-id gaia-test-perf"
                " --segment-id 1 --space-id 7 --page-no 1 --vlsn 10000");
        AddExample("-a <ip> -p <port> --space-id 7 --page-no 1 --vlsn 10000 ");
        AddExample("-a <ip> -p <port> -m --cluster-id gaia-test-perf --segment-id 1 --offset 0 --vlsn 10000");
        AddExample("-a <ip> -p <port> -m --cluster-id gaia-test-perf --segment-id 1 --offset 0 --direct");
    }
    virtual ~ReadPageServerPage() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'a':
            _address = opt;
            break;
        case 'p':
            _port = std::strtol(opt, NULL, 10);
            break;
        case 'c':
            _cluster_id = opt;
            break;
        case 's':
            _segment_id.Set(std::strtoul(opt, NULL, 10));
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 3:
                _space_id = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 4:
                _page_no = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 5:
                _vlsn = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 6:
                _zip_len = std::strtoul(opt, NULL, 10);
                break;
            case kOptMax + 7:
                _offset.Set(std::strtoul(opt, NULL, 10));
                break;
            case kOptMax + 8:
                _dump_page = true;
                break;
            case kOptMax + 9:
                _direct = true;
                break;
            default:
                return 1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format != kRaw) {
            print_error("only support raw format, continue exporting in raw format");
        }

        return Format(rsp);
    }

    int Format(const pspb::RbioResponse& rsp);
    int Format(const pspb::ReadPageResponse& rsp);
    int Format(const pspb::ReadResponse& rsp);

private:
    std::string _address {};
    int32_t _port {0};
    std::string _cluster_id {};
    VarOptional<uint32_t> _segment_id;
    uint32_t _space_id {std::numeric_limits<uint32_t>::max()};
    uint32_t _page_no {std::numeric_limits<uint32_t>::max()};
    uint64_t _vlsn {0};
    uint64_t _zip_len {16384};
    VarOptional<uint64_t> _offset;
    bool _dump_page {false};
    bool _direct {false};
};

}
}
