/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/add_raft_peer.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include <raft/cli.pb.h>
#include "gaia/command.h"

namespace psvr {
namespace gaia {

class AddRaftPeer : public Command {
public:
    AddRaftPeer() {
        SetName("add-raft-peer");
        SetDesc("add new peer node to raft group");
        SetDescCn("向 Raft 组添加新的节点");

        AddPsmClusterOption();
        AddRequiredArgOption("group-id", &_long_opt_val, kOptMax + 1, "raft group id", kstring);
        AddRequiredArgOption("peer-id", &_long_opt_val, kOptMax + 2, "peer to add", kstring);
        
        AddExample("--manager-address \"bns://xxx\" --group-id xxx --peer-id 127.0.0.1:8888:0");
    }
    virtual ~AddRaftPeer() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 'M':
            _manager_address = opt;
            break;
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _group_id = opt;
                break;
            case kOptMax + 2:
                _add_peer_id = opt;
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    template<typename T>
    int Output(const T& rsp) {
        if (_format == kRaw) {
            return Format(rsp);
        }
        return format_output(rsp, _format);
    }

    int Format(const raft::AddPeerResponse& rsp);

private:
    std::string _manager_address {};
    std::string _group_id {};
    std::string _add_peer_id {};
};

}
}
