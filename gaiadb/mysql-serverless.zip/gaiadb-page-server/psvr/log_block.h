/**************************************************************************
 * Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
 * File Name:     par_apply.h
 **************************************************************************/

#pragma once

#include <unordered_set>
#include <base/strings/string_number_conversions.h>
#include <gaiadb/utils/crc32.h>
#include <gaiadb/utils/aarch64.h>
#include <gaiadb/utils/mb_alloc.h>
#include <base/slice.h>
#include "psvr/common.h"
#include "psvr/utils.h"
#include "psvr/space.h"
#include "psvr/page.h"
#include "psvr/config.h"
#include "psvr/time_point.h"

namespace psvr {

class LogBlock;
using LogBlockPtr = std::shared_ptr<LogBlock>;

struct fold_space_page_t {
    gaia_apply::space_id_t space_id;
    gaia_apply::page_no_t page_no;

    fold_space_page_t(gaia_apply::space_id_t space,  gaia_apply::page_no_t page)
        : space_id(space), page_no(page) {}
    fold_space_page_t(const fold_space_page_t& fold)
        : space_id(fold.space_id), page_no(fold.page_no) {}
    fold_space_page_t() : fold_space_page_t(gaia_apply::SPACE_UNKNOWN, gaia_apply::FIL_NULL) {}

    bool operator==(const fold_space_page_t& rhs) const {
        return space_id == rhs.space_id && page_no == rhs.page_no;
    }

    bool operator< (const fold_space_page_t& rhs) const {
        return (space_id != rhs.space_id) ? (space_id < rhs.space_id) : (page_no < rhs.page_no);
    }
};

inline fold_space_page_t fold_space_page_align(const fold_space_page_t& fold) {
    return fold_space_page_t(fold.space_id,
            fold.page_no - (fold.page_no % (GAIADB_EXTENT_SIZE / gaia_apply::FLAGS_univ_page_size)));
}

inline uint32_t fold_space_page_to_index(const fold_space_page_t& fold) {
    return fold.space_id + (fold.page_no / (GAIADB_EXTENT_SIZE / gaia_apply::FLAGS_univ_page_size));
}

inline uint64_t fold_space_page_to_key(const fold_space_page_t& fold) {
    return u32tou64(fold.space_id, fold.page_no);
}

} // endof ns psvr

namespace std {

template<> struct hash<psvr::fold_space_page_t> {
    size_t operator()(const psvr::fold_space_page_t& f) const {
        return std::hash<uint64_t>{}(fold_space_page_to_key(f));
    }
};

} // endof ns std

namespace psvr {

namespace destroy_only = gaiadb::common::destroy_only;

struct PageRecordLsnRange {
    gaia_apply::lsn_t min_lsn;
    gaia_apply::lsn_t max_lsn;
};

using fold_space_page_lsn_map_vt = std::pair<const fold_space_page_t, PageRecordLsnRange>;
using fold_space_page_lsn_map_t = destroy_only::unordered_map<fold_space_page_t, PageRecordLsnRange>;

struct LogBlockChunk {
    fold_space_page_lsn_map_t fold_space_page_lsn_map;
    int32_t real_gc_page_count;
    std::atomic<gaia_apply::lsn_t> incomplete_lift_start_lsn;
    rwlock_t shared_mutex;

    LogBlockChunk() {}
    LogBlockChunk(gaia_apply::lsn_t lsn, gaiadb::common::MemArena* mb_arena)
        : fold_space_page_lsn_map(destroy_only::Allocator<fold_space_page_lsn_map_vt>(mb_arena)),
        real_gc_page_count(0),
        incomplete_lift_start_lsn(lsn) {}
    LogBlockChunk(const LogBlockChunk& lhs)
        : fold_space_page_lsn_map(lhs.fold_space_page_lsn_map),
        real_gc_page_count(lhs.real_gc_page_count),
        incomplete_lift_start_lsn(lhs.incomplete_lift_start_lsn.load()) {}
    LogBlockChunk& operator=(const LogBlockChunk& lhs) {
        fold_space_page_lsn_map = lhs.fold_space_page_lsn_map;
        real_gc_page_count = lhs.real_gc_page_count;
        incomplete_lift_start_lsn.store(lhs.incomplete_lift_start_lsn.load());
        return *this;
    }
    ~LogBlockChunk() {}
};

enum class EventOp {
    kOther = 0,
    kParseRecord,
    kGetSpaceMeta,
    kGetSpaceExtent,
    kGetPeer,
    kClearSpaceStatus,
    kGetAllSapceId,
};

template<typename Key, typename Value>
struct KeyValueCache {
    using map_vt = std::pair<const Key, Value*>;
    using map_t = destroy_only::map<Key, Value*>;
public:
    KeyValueCache(gaiadb::common::MemArena* mb_arena)
        : _mb_arena(mb_arena),
        _size(0), _pos(0),
        _buf(nullptr), _buf_size(0),
        _buf_map(destroy_only::Allocator<map_vt>(mb_arena)),
        _status(0) {}
    KeyValueCache(gaiadb::common::MemArena* mb_arena,
            size_t size) : KeyValueCache<Key, Value>(mb_arena) {
        Init(size);
    }

    ~KeyValueCache() {}

    size_t buf_size() const { return _buf_size; }
    const void* buf() const { return _buf; }
    char* data() const { return static_cast<char*>(_buf); }
    size_t size() const { return _size; }
    size_t pos() const { return _pos; }

    void Free() {
        _size = 0;
        _pos = 0;
        _buf = nullptr;
        _ptr = nullptr;
        _buf_size = 0;
        _buf_map.clear();
        _status.store(0);
    }

    bool Decode(const char* buf, uint32_t buf_size, uint32_t size) {
        if (buf_size != _buf_size || _size != size) {
            return false;
        }
        if (is_init()) {
            return _pos == _size;
        }
        for (uint32_t i = 0; i < size; ++i) {
            Key key = *reinterpret_cast<const Key*>(buf);
            buf += sizeof(Key);
            Value value = *reinterpret_cast<const Value*>(buf);
            buf += sizeof(Value);
            Add(key, value);
        }
        return _pos == _size;
    }

    void Init(size_t size, char* buf = nullptr) {
        if (_buf_size == 0) {
            _size = size;
            _pos = 0;
            _buf_size = (sizeof(Key) + sizeof(Value)) * size;
            _buf = buf ? buf : _mb_arena->Alloc(_buf_size);
            _ptr = static_cast<char*>(_buf);
            if (buf) {
                for (uint32_t i = 0; i < size; ++i) {
                    Key key = *reinterpret_cast<const Key*>(buf);
                    buf += sizeof(Key);
                    Value value = *reinterpret_cast<const Value*>(buf);
                    buf += sizeof(Value);
                    if (auto it = _buf_map.find(key); it != _buf_map.end()) {
                        PSVR_ASSERT(false);
                    } else {
                        PSVR_ASSERT(_pos < _size);
                        auto key_ptr = reinterpret_cast<Key*>(_ptr);
                        PSVR_ASSERT(*key_ptr == key);
                        _ptr += sizeof(Key);
                        auto value_ptr = reinterpret_cast<Value*>(_ptr);
                        PSVR_ASSERT(*value_ptr == value);
                        _ptr += sizeof(Value);
                        _buf_map[key] = value_ptr;
                        _pos++;
                    }
                }
                set_init();
            }
        }
    }

    void Add(Key key, Value value) {
        if (auto it = _buf_map.find(key); it != _buf_map.end()) {
            return;
        }
        PSVR_ASSERT(_pos < _size);
        auto key_ptr = reinterpret_cast<Key*>(_ptr);
        *key_ptr = key;
        _ptr += sizeof(Key);
        auto value_ptr = reinterpret_cast<Value*>(_ptr);
        *value_ptr = value;
        _ptr += sizeof(Value);
        _buf_map[key] = value_ptr;
        _pos++;
    }

    bool Get(Key key, Value* value) const {
        if (auto it = _buf_map.find(key); it != _buf_map.end()) {
            *value = *(it->second);
            return true;
        }
        return false;
    }

    bool is_init() const { return _status.load() > 0; }
    void set_init() { _status.store(1); }

private:
    gaiadb::common::MemArena* _mb_arena;
    size_t _size;
    size_t _pos;
    void* _buf;
    char* _ptr;
    size_t _buf_size;
    map_t  _buf_map;
    std::atomic<int32_t> _status;
};

struct AppendInfo {
    char* buf;
    uint64_t fno;
    uint64_t off;
    uint32_t size;
    size_t fold_size;

    AppendInfo() : buf(nullptr), fno(0), off(0), size(0), fold_size(0) {}
};

constexpr int32_t FROM_NONE = 0;
constexpr int32_t FROM_LOCAL = 1;
constexpr int32_t FROM_PEER = 2;

// A set of redo records fetched from LogService
struct LogBlock {
    LogBlockPtr next;
    gaiadb::common::MemArena mb_arena;
    const int64_t log_id;
    TimePoint* tp;
    const gaia_apply::lsn_t start_lsn;
    const gaia_apply::lsn_t end_lsn;
    gaia_apply::byte* buf;
    uint64_t buf_size;
    uint32_t buf_crc;
    size_t quota_size;             // estimated memory size for quota accounting, see calc_log_block_quota_size()
    base::EndPoint fetch_from;
    int32_t from_append_file;      // fetch from append db on restart server
    KeyValueCache<uint64_t, uint32_t> fold_space_page_offset_cache;  // align fold -> extent id
    gaia_apply::byte* parse_ptr;
    uint32_t is_parsed;
    AppendInfo append_info;
    uint32_t records_count;
    uint32_t valid_records_count;
    std::atomic<int32_t> gc_ref_nr;
    int32_t parallel_size;
    std::atomic<int32_t> real_gc_page_count;
    std::atomic<int32_t> offset_cache_lock;
    int64_t time;
    EventOp event;
    gaia_apply::space_id_t event_space_id;
    uint32_t space_status;

    using page_refs_vt = std::shared_ptr<Page>;
    destroy_only::unordered_set<std::shared_ptr<Page>> page_refs;

    fold_space_page_lsn_map_t fold_space_page_lsn_map;

    using drop_space_lsn_map_vt = std::pair<const gaia_apply::space_id_t, gaia_apply::lsn_t>;
    destroy_only::unordered_map<gaia_apply::space_id_t, gaia_apply::lsn_t> drop_space_lsn_map;

    using chunks_vt = destroy_only::unique_ptr<LogBlockChunk>;
    destroy_only::vector<destroy_only::unique_ptr<LogBlockChunk>> chunks;

    destroy_only::set<gaia_apply::space_id_t> fold_space_ids;

    destroy_only::set<fold_space_page_t> fold_space_align_pages; // for append

#ifdef GTEST
    std::vector<gaia_apply::lsn_t> records_start_lsn;
#endif

    explicit LogBlock(int64_t id, gaia_apply::lsn_t start, gaia_apply::lsn_t end)
        : next {nullptr},
        mb_arena(),
        log_id(id),
        tp(nullptr),
        start_lsn(start),
        end_lsn(end),
        buf(nullptr),
        buf_size(0),
        buf_crc(0),
        quota_size(0),
        fetch_from(),
        from_append_file(FROM_NONE),
        fold_space_page_offset_cache(&mb_arena),
        parse_ptr(nullptr),
        is_parsed(false),
        append_info(),
        records_count(0),
        valid_records_count(0),
        gc_ref_nr(0),
        parallel_size(0),
        real_gc_page_count(0),
        offset_cache_lock(0),
        event(EventOp::kParseRecord),
        event_space_id(gaia_apply::SPACE_UNKNOWN),
        space_status(kSpaceStatusUnknown),
        page_refs(destroy_only::Allocator<page_refs_vt>(&mb_arena)),
        fold_space_page_lsn_map(destroy_only::Allocator<fold_space_page_lsn_map_vt>(&mb_arena)),
        drop_space_lsn_map(destroy_only::Allocator<drop_space_lsn_map_vt>(&mb_arena)),
        chunks(destroy_only::Allocator<chunks_vt>(&mb_arena)),
        fold_space_ids(destroy_only::Allocator<gaia_apply::space_id_t>(&mb_arena)),
        fold_space_align_pages(destroy_only::Allocator<fold_space_page_t>(&mb_arena)) {
        time = base::cpuwide_time_us();
    }

    explicit LogBlock(EventOp _event,
        gaia_apply::space_id_t _event_space_id,
        uint32_t _space_status)
        : next {nullptr},
        mb_arena(64),
        log_id(0),
        tp(nullptr),
        start_lsn(0),
        end_lsn(0),
        buf(nullptr),
        buf_size(0),
        buf_crc(0),
        quota_size(0),
        fetch_from(),
        from_append_file(FROM_NONE),
        fold_space_page_offset_cache(&mb_arena),
        parse_ptr(nullptr),
        is_parsed(false),
        append_info(),
        records_count(0),
        valid_records_count(0),
        gc_ref_nr(0),
        parallel_size(0),
        real_gc_page_count(0),
        offset_cache_lock(0),
        event(_event),
        event_space_id(_event_space_id),
        space_status(_space_status),
        page_refs(destroy_only::Allocator<page_refs_vt>(&mb_arena)),
        fold_space_page_lsn_map(destroy_only::Allocator<fold_space_page_lsn_map_vt>(&mb_arena)),
        drop_space_lsn_map(destroy_only::Allocator<drop_space_lsn_map_vt>(&mb_arena)),
        chunks(destroy_only::Allocator<chunks_vt>(&mb_arena)),
        fold_space_ids(destroy_only::Allocator<gaia_apply::space_id_t>(&mb_arena)),
        fold_space_align_pages(destroy_only::Allocator<fold_space_page_t>(&mb_arena)) {
        time = base::cpuwide_time_us();
    }

    FUNC_MOCK ~LogBlock() {
        TP_DESTROY(tp);
    }

    bool set_data(const base::Slice& data, uint32_t rec_cnt, uint32_t crc) {
        buf_size = data.size();
        if (buf_size > 0) {
            buf = static_cast<gaia_apply::byte*>(mb_arena.Alloc(data.size() * sizeof(char)));
            if (!buf) {
                return false;
            }
            std::memcpy(buf, data.data(), data.size());
            parse_ptr = buf;
        }
        records_count = rec_cnt;
        buf_crc = crc;
        return true;
    }

    bool set_key(const base::Slice& key) {
        append_info.buf = static_cast<char*>(mb_arena.Alloc(key.size() * sizeof(char)));
        if (!append_info.buf) {
            return false;
        }
        std::memcpy(append_info.buf, key.data(), key.size());
        return true;
    }

    const gaia_apply::byte* data() { return buf; }
    uint64_t data_length() const { return buf_size; }
    uint64_t lsn_length() const { return end_lsn - start_lsn; }
    int64_t latency_us() const { return base::cpuwide_time_us() - time; }

    std::string HexEncode() const { return buf_size ? std::move(gaia_apply::StringToHex(buf, buf_size)) : ""; }
    bool check_buf_crc() const { return gaiadb::common::ut_crc32(buf, buf_size) == buf_crc; }

    bool PushRecord(const LogRecord* rec) {
        if (is_file_delete_record(rec->type)) {
            drop_space_lsn_map.emplace(rec->space_id, rec->end_lsn);
            return true;
        } else {
            fold_space_ids.emplace(rec->space_id);
            auto it = fold_space_page_lsn_map.emplace(fold_space_page_t(rec->space_id, rec->page_no),
                    PageRecordLsnRange{rec->start_lsn, rec->end_lsn});
            if (!it.second) {
                it.first->second.max_lsn = rec->end_lsn;
            }
            return it.second;
        }
    }

    void PrepareGc() {
        if (chunks.size() > 0) {
            PSVR_LOG(ERROR, log_id) << "logblock repeat prepare to GC?";
            return;
        }

        parallel_size = 1;
        if (!fold_space_page_lsn_map.empty()) {
            parallel_size = std::min(FLAGS_psvr_gc_parallel_num,
                static_cast<int32_t>(fold_space_page_lsn_map.size()));
        }

        PSVR_ASSERT(parallel_size > 0);
        gc_ref_nr.store(parallel_size);

        for (int32_t i = 0; i < parallel_size; ++i) {
            chunks.emplace_back(destroy_only::make_unique_ptr<LogBlockChunk>(&mb_arena, start_lsn, &mb_arena));
        }
        if (parallel_size == 1) {
            chunks[0]->fold_space_page_lsn_map = std::move(fold_space_page_lsn_map);
        } else {
            for (auto& it : fold_space_page_lsn_map) {
                chunks[fold_space_page_to_index(it.first) % parallel_size]
                  ->fold_space_page_lsn_map.emplace(it.first, it.second);
            }
        }
    }

    bool EnableGc(gaia_apply::lsn_t lsn) const {
        return lsn > start_lsn;
    }

    void ToString(std::ostream& os) const {
        os << "lsn=" << start_lsn << "," << end_lsn
            << "; crc=" << buf_crc << "," << check_buf_crc()
            << "; from=" << fetch_from
            << "; buf=" << HexEncode() << "," << buf_size;
    }
};

inline size_t calc_log_block_quota_size(size_t buf_size, uint32_t rec_cnt) {
    return buf_size + sizeof(LogBlock) + (sizeof(LogRecord) + sizeof(PagePtr)) * rec_cnt;
}

inline std::ostream& operator<<(std::ostream& os, const LogBlockPtr& log_block) {
    if (log_block) {
        log_block->ToString(os);
    }
    return os;
}

inline std::ostream& operator<<(std::ostream& os, const LogBlock* log_block) {
    if (log_block) {
        log_block->ToString(os);
    }
    return os;
}

}
