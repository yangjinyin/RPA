/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/set_page_server_recovery_prior.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/set_page_server_recovery_prior.h"

namespace psvr {
namespace gaia {

int SetPageServerRecoveryPrior::Run() {
    if (_address.empty() || _port < 1) {
        print_error("miss --address or --port");
        return 1;
    }

    if (_cluster_id.empty() || !_segment_id.has_val) {
        print_error("miss --segment-id or --cluster-id");
        return 1;
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Set segment recovery prior number?");
        if (!cf_ret) {
            return 1;
        }
    }

    pspb::SetRecoverPriorRequest request;
    pspb::SetRecoverPriorResponse response;
    request.set_log_id(_log_id);
    request.set_cluster_id(_cluster_id);
    request.set_segment_id(_segment_id.val);
    request.set_prior_num(_prior);

    RpcStatus status;
    _client.Call(_log_id++, node, &pspb::ManagerService_Stub::SetRecoverPrior, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int SetPageServerRecoveryPrior::Format(const pspb::SetRecoverPriorResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
