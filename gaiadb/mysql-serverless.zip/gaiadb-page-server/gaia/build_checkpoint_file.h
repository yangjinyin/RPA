/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/build_checkpoint_file.h
* @author yukeyong@baidu.com
* @brief
*/

#pragma once

#include "gaia/command.h"

namespace psvr {
namespace gaia {

class BuildCheckpointFile : public Command {
public:
    BuildCheckpointFile() {
        SetName("build-ckp-file");
        SetDesc("build or display ckp file");
        SetDescCn("创建或查看存储检查点文件");

        AddRequiredArgOption("ckp-file", &_long_opt_val, kOptMax + 1, "ckp file path name", kstring);
        AddRequiredArgOption("lsn", &_long_opt_val, kOptMax + 2,
                "which lsn will written to the ckp file?",
                kuint64_t, kGroup2Scope);
        AddNoArgOption("is-create", &_long_opt_val, kOptMax + 3, "to create ckp file", kGroup2Scope);
        AddRequiredArgOption("file-size", &_long_opt_val, kOptMax + 4,
                "size of page server checkpoint file?", kuint64_t);

        AddExample("--ckp-file xxx.ckp");
        AddExample("--is-create --ckp-file xxx.ckp");
    }
    virtual ~BuildCheckpointFile() {}
    // return 0 ok,
    // > 0 is error and direct return
    // < 0 is error, call help and return;
    virtual int Parser(int ch, const char* opt) override {
        switch(ch) {
        case 0:
            switch (_long_opt_val) {
            case kOptMax + 1:
                _ckp_file = opt;
                break;
            case kOptMax + 2:
                _lsn = std::strtoull(opt, nullptr, 10);
                break;
            case kOptMax + 3:
                _is_create = true;
                break;
            case kOptMax + 4:
                _file_size = std::strtoull(opt, nullptr, 10);
                break;
            default:
                return -1;
            }
            break;
        default:
            return -1;
        }
        return 0;
    }

    virtual int Run() override;

private:
    std::string _ckp_file {};
    uint64_t _lsn {0};
    bool _is_create {false};
    uint64_t _file_size {65536};
    int _fd {-1};
};

}
}
