/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file psvr/log.cc
* @author yukeyong@baidu.com
* @brief
*/

#include <stdio.h>
#include <string>
#include <sys/time.h>
#include <syslog.h>
#include <spdlog/cfg/env.h>
#include <spdlog/sinks/rotating_file_sink.h>
#include <spdlog/sinks/daily_file_sink.h>
#include <base/memory/singleton.h>
#include "psvr/log.h"
#include "psvr/config.h"

namespace psvr {

LogSink* LogSink::GetInstance() {
    return Singleton<LogSink, LeakySingletonTraits<LogSink> >::get();
}

int LogSink::Setup(const logging::ComlogSinkOptions* options) {
    if (options) {
        _options = *options;
    }
    if (_options.max_log_length < 128) {
        fprintf(stderr, "log length:%d invalid\n", _options.max_log_length);
        return -1;
    }

    const std::string& log_path = _options.log_dir;
    struct stat st;
    if (-1 == stat(log_path.c_str(), &st)) {
        if (-1 == mkdir(log_path.c_str(), S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH)) {
            fprintf(stderr, "create log path:%s failed\n", log_path.c_str());
            return -1;
        }
    } else if (!S_ISDIR(st.st_mode)) {
        fprintf(stderr, "log path:%s is not dir\n", log_path.c_str());
        return -1;
    }

    if (_options.async) {
        _spd_thread_pool = std::make_shared<spdlog::details::thread_pool>(
                FLAGS_psvr_spd_log_max_items_num,
                FLAGS_psvr_spd_log_thread_num,
                []() {
                    pthread_setname_np(pthread_self(), "spdlog");
                });
    }
    if (true || _options.split_type == logging::COMLOG_SPLIT_SIZECUT) {
        std::string filename = log_path + "/" + _options.process_name + ".log";
        auto max_files = (_options.quota_size / _options.cut_size_megabytes);
        std::size_t file_max_size = static_cast<std::size_t>(_options.cut_size_megabytes) << 20;
        auto file_sink = std::make_shared<spdlog::sinks::rotating_file_sink_mt>(filename, file_max_size, max_files > 1 ? max_files : 2);
        file_sink->set_level(spdlog::level::trace);  // set the min level

        std::shared_ptr<spdlog::sinks::rotating_file_sink_mt> wf_file_sink = nullptr;
        if (_options.enable_wf_device) {
            std::string wf_filename = log_path + "/" + _options.process_name + ".log.wf";
            wf_file_sink = std::make_shared<spdlog::sinks::rotating_file_sink_mt>(wf_filename, file_max_size, 2);
            wf_file_sink->set_level(spdlog::level::warn);  // set the min level
        }
        if (_options.async) {
            if (!wf_file_sink) {
                _spd_logger.reset(new spdlog::async_logger("async", std::move(file_sink), _spd_thread_pool, spdlog::async_overflow_policy::block));
            } else {
                _spd_logger.reset(new spdlog::async_logger("async", {file_sink, wf_file_sink}, _spd_thread_pool, spdlog::async_overflow_policy::block));
            }
        } else {
            if (!wf_file_sink) {
                _spd_logger.reset(new spdlog::logger("sync", std::move(file_sink)));
            } else {
                _spd_logger.reset(new spdlog::logger("sync", {file_sink, wf_file_sink}));
            }
        }
    }

    _spd_logger->set_pattern("%v");
    _spd_logger->set_level(spdlog::level::trace);
    _spd_logger->flush_on(spdlog::level::warn);
    spdlog::register_logger(_spd_logger);
    spdlog::flush_every(std::chrono::seconds(FLAGS_psvr_spd_log_flush_second));
    return 0;
}

// BLOG_INFO(BLOG_TRACE) 0, BLOG_NOTICE 1, BLOG_WARNING 2, BLOG_ERROR 3, BLOG_FATAL 4
static const char* log_level_str[] = {"TRACE", "NOTICE", "WARNING", "ERROR", "FATAL"};
static const char* short_log_level_str[] = {"T", "N", "W", "E", "F"};
static const spdlog::level::level_enum spd_levels[] = {
    //spdlog::level::trace,   // 0
    spdlog::level::debug,   // 1
    spdlog::level::info,    // 2
    spdlog::level::warn,    // 3
    spdlog::level::err,     // 4
    spdlog::level::critical,    // 5
};

bool LogSink::OnLogMessage(int severity, const char* file, int line,
        const base::StringPiece& log_content) {
    if (_disable) {
        return true;
    }

    if (_options.print_vlog_as_warning && severity < 0) {
        severity = COMLOG_WARNING;
    }

    // Validate severity before it is used to index log_level_str/spd_levels
    // below; otherwise a VLOG(n) negative severity (when print_vlog_as_warning
    // is disabled) or any other out-of-range value would read out of bounds.
    if (severity < logging::BLOG_INFO || severity > logging::BLOG_FATAL) {
        return false;
    }

    thread_local struct tm tm_now;
    thread_local struct timeval tv_now;
    thread_local std::shared_ptr<char[]> log_buf = nullptr;
    thread_local std::mutex mutex;
    thread_local pid_t thread_id = gettid();
    if (!log_buf) {
        std::unique_lock<std::mutex> locker(mutex);
        if (!log_buf) {
            log_buf.reset(new char[_options.max_log_length + 1]);
            log_buf[_options.max_log_length] = '\0';
        }
    }

    gettimeofday(&tv_now, NULL);
    localtime_r(&(tv_now.tv_sec), &tm_now);

    int32_t left = _options.max_log_length;
    // the last pos will auto set null character
    snprintf(log_buf.get(), left, "%s %02d%02d %02d:%02d:%02d.%06ld %d %s:%d] %.*s",
            _options.shorter_log_level ? short_log_level_str[severity] : log_level_str[severity],
            tm_now.tm_mon + 1, tm_now.tm_mday,
            tm_now.tm_hour, tm_now.tm_min, tm_now.tm_sec, tv_now.tv_usec,
            thread_id, file, line, static_cast<int>(log_content.size()), log_content.data());

    _spd_logger->log(spd_levels[severity], log_buf.get());
    return true;
}

}
