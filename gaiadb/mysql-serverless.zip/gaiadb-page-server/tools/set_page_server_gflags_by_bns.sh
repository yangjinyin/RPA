#!/usr/bin/env bash
set -euo pipefail

DEFAULT_PORT="6000"
CURL_OPTS=(--connect-timeout 5 --max-time 10 --silent --show-error)

usage() {
    cat <<'EOF'
Usage:
  ./set_page_server_gflags_by_bns.sh <bns> get <flag_name> [port]
  ./set_page_server_gflags_by_bns.sh <bns> set <flag_name> <flag_value> [port]

Compatibility:
  ./set_page_server_gflags_by_bns.sh <bns> <flag_name> <flag_value> [port]

Examples:
  ./set_page_server_gflags_by_bns.sh sandbox-multips00.gaia.bjdd get segment_in_trash_second
  ./set_page_server_gflags_by_bns.sh sandbox-multips00.gaia.bjdd set segment_in_trash_second 1200
  ./set_page_server_gflags_by_bns.sh sandbox-multips00.gaia.bjdd psvr_recover_src_max_speed 104857600 6000

Notes:
  - Requires get_instance_by_service in PATH.
  - Requires curl in PATH.
  - Read calls each host via HTTP:
      http://<host>:<port>/flags/<flag_name>?getvalue
  - Set calls each host via HTTP:
      http://<host>:<port>/flags/<flag_name>?setvalue=<flag_value>
  - BNS only needs to provide host information.
  - Any port in BNS output is ignored.
  - The script always uses default port 6000 or the optional [port].
EOF
}

if [[ $# -lt 3 || $# -gt 5 ]]; then
    usage
    exit 1
fi

BNS="$1"
ACTION="$2"
FLAG_NAME=""
FLAG_VALUE=""
PORT="$DEFAULT_PORT"

case "$ACTION" in
    get)
        if [[ $# -lt 3 || $# -gt 4 ]]; then
            usage
            exit 1
        fi
        FLAG_NAME="${3#--}"
        PORT="${4:-$DEFAULT_PORT}"
        ;;
    set)
        if [[ $# -lt 4 || $# -gt 5 ]]; then
            usage
            exit 1
        fi
        FLAG_NAME="${3#--}"
        FLAG_VALUE="$4"
        PORT="${5:-$DEFAULT_PORT}"
        ;;
    *)
        if [[ $# -lt 3 || $# -gt 4 ]]; then
            usage
            exit 1
        fi
        ACTION="set"
        FLAG_NAME="${2#--}"
        FLAG_VALUE="$3"
        PORT="${4:-$DEFAULT_PORT}"
        ;;
esac

if [[ -z "$FLAG_NAME" || "$FLAG_NAME" == *"="* || "$FLAG_NAME" =~ [[:space:]] ]]; then
    echo "ERROR: invalid flag name: $FLAG_NAME" >&2
    exit 1
fi
if [[ ! "$PORT" =~ ^[0-9]+$ ]]; then
    echo "ERROR: invalid port: $PORT" >&2
    exit 1
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

HOST_LIST="$TMP_DIR/hosts.txt"
FAILED_LOG="$TMP_DIR/failed.log"
: >"$FAILED_LOG"

trap 'echo; echo "Interrupted by user." >&2; if [[ -s "$FAILED_LOG" ]]; then echo; echo "Failures collected so far:"; cat "$FAILED_LOG"; fi; exit 130' INT

extract_hosts() {
    awk -v default_port="$PORT" '
        /^[[:space:]]*$/ { next }
        /^#/ { next }
        {
            for (i = 1; i <= NF; i++) {
                field = $i
                gsub(/^\[/, "", field)
                gsub(/\]$/, "", field)

                if (field ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+(:[0-9]+)?$/) {
                    sub(/:[0-9]+$/, "", field)
                    print field ":" default_port
                    next
                }

                if (field ~ /^[A-Za-z0-9._-]+(:[0-9]+)?$/ && field !~ /^[0-9]+$/) {
                    sub(/:[0-9]+$/, "", field)
                    print field ":" default_port
                    next
                }
            }
        }
    ' | sort -u
}

if ! command -v get_instance_by_service >/dev/null 2>&1; then
    echo "ERROR: get_instance_by_service not found in PATH" >&2
    exit 2
fi
if ! command -v curl >/dev/null 2>&1; then
    echo "ERROR: curl not found in PATH" >&2
    exit 2
fi

echo "Fetching BNS instances: $BNS" >&2
if ! get_instance_by_service "$BNS" 2>"$TMP_DIR/bns.err" | extract_hosts >"$HOST_LIST"; then
    echo "ERROR: failed to fetch BNS instances" >&2
    cat "$TMP_DIR/bns.err" >&2 || true
    exit 3
fi

if [[ ! -s "$HOST_LIST" ]]; then
    echo "ERROR: no hosts parsed from BNS: $BNS" >&2
    echo "Raw error output:" >&2
    cat "$TMP_DIR/bns.err" >&2 || true
    exit 3
fi

HOST_COUNT="$(wc -l <"$HOST_LIST")"
echo "Found $HOST_COUNT host(s)" >&2
echo "Action: $ACTION"
echo "Flag:   $FLAG_NAME"
if [[ "$ACTION" = "set" ]]; then
    echo "Value:  $FLAG_VALUE"
fi
echo

SUCCESS_COUNT=0
FAILED_COUNT=0

while IFS= read -r host; do
    safe_host="${host//[^A-Za-z0-9_.:-]/_}"
    out_file="$TMP_DIR/${safe_host}.out"
    err_file="$TMP_DIR/${safe_host}.err"
    url="http://${host}/flags/${FLAG_NAME}"

    echo "Calling $host ..." >&2
    if [[ "$ACTION" = "get" ]]; then
        request_url="${url}?getvalue"
        curl_cmd=(curl "${CURL_OPTS[@]}" "$request_url")
    else
        request_url="${url}?setvalue=${FLAG_VALUE}"
        curl_cmd=(curl "${CURL_OPTS[@]}" --get --data-urlencode "setvalue=${FLAG_VALUE}" "$url")
    fi

    if "${curl_cmd[@]}" >"$out_file" 2>"$err_file"; then
        SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
        echo "OK     $host"
        if [[ -s "$out_file" ]]; then
            while IFS= read -r line; do
                echo "       $line"
            done <"$out_file"
        fi
    else
        rc=$?
        FAILED_COUNT=$((FAILED_COUNT + 1))
        echo "FAILED $host" >&2
        {
            echo "===== $host ====="
            echo "url=$request_url"
            echo "exit_code=$rc"
            if [[ -s "$out_file" ]]; then
                echo "--- stdout ---"
                cat "$out_file"
            fi
            if [[ -s "$err_file" ]]; then
                echo "--- stderr ---"
                cat "$err_file"
            fi
            echo
        } >"$TMP_DIR/${safe_host}.failure"
        cat "$TMP_DIR/${safe_host}.failure" >&2
        cat "$TMP_DIR/${safe_host}.failure" >>"$FAILED_LOG"
    fi
done <"$HOST_LIST"

echo
echo "Summary"
echo "  BNS:           $BNS"
echo "  Action:        $ACTION"
echo "  Flag:          $FLAG_NAME"
if [[ "$ACTION" = "set" ]]; then
    echo "  Value:         $FLAG_VALUE"
fi
echo "  Total hosts:   $HOST_COUNT"
echo "  Success hosts: $SUCCESS_COUNT"
echo "  Failed hosts:  $FAILED_COUNT"

if [[ -s "$FAILED_LOG" ]]; then
    echo
    echo "Failures:"
    cat "$FAILED_LOG"
fi

if [[ "$FAILED_COUNT" -gt 0 ]]; then
    exit 4
fi

exit 0
