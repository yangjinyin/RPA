/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_compress.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/compress_utils.h"
#include "psvr/buf.h"
#include <base/fast_rand.h>

namespace psvr {
namespace test {

class CompressUtilsTests : public ::testing::Test {
 public:
    CompressUtilsTests() {
        _buf_pool.reset(new BufPool());
        _buf_pool->_slice_size = 16384;
    }
    virtual ~CompressUtilsTests() {}

    void SetUp() {
    }

    void TearDown() {
    }

private:
    BufPoolPtr _buf_pool;
};

static void set_page_data(gaia_apply::byte* page) {
    INIT_APPLY_RAW_ARG(false);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_SPACE_OR_CHKSUM, 1);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_OFFSET, 2);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_PREV, 0);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_NEXT, 2);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_LSN, 100ul);
    gaia_apply::mach_write_to_2(page + gaia_apply::FIL_PAGE_TYPE, gaia_apply::FIL_PAGE_INODE APPLY_RAW_ARG_NAME_CC);
    gaia_apply::mach_write_to_8(page + gaia_apply::FIL_PAGE_FILE_FLUSH_LSN, 0);
    gaia_apply::mach_write_to_4(page + gaia_apply::FIL_PAGE_SPACE_ID, 2);
}

static void rand_make_data(gaia_apply::byte* page, uint32_t size) {
    for (uint32_t i = 0; i < size; ++i) {
        page[i] = ((base::fast_rand() + i) % 26) + 'a';
    }
}

TEST_F(CompressUtilsTests, test_type) {
    int32_t type;
    ASSERT_EQ(get_compress_type("zstd", &type), true);
    ASSERT_EQ(type, PSVR_COMPRESS_TYPE_ZSTD);

    ASSERT_EQ(get_compress_type("lz4", &type), true);
    ASSERT_EQ(type, PSVR_COMPRESS_TYPE_LZ4);

    ASSERT_EQ(get_compress_type("snappy", &type), true);
    ASSERT_EQ(type, PSVR_COMPRESS_TYPE_SNAPPY);

    ASSERT_EQ(get_compress_type("other", &type), false);
    ASSERT_EQ(type, PSVR_COMPRESS_TYPE_NONE);

    std::string name;
    get_compress_name(PSVR_COMPRESS_TYPE_ZSTD, &name);
    ASSERT_EQ(name, "zstd");

    get_compress_name(PSVR_COMPRESS_TYPE_LZ4, &name);
    ASSERT_EQ(name, "lz4");

    get_compress_name(PSVR_COMPRESS_TYPE_SNAPPY, &name);
    ASSERT_EQ(name, "snappy");

    get_compress_name(PSVR_COMPRESS_TYPE_NONE, &name);
    ASSERT_EQ(name, "none");
}

TEST_F(CompressUtilsTests, test_train_dict_save_to_file_with_directory_sync) {
    const bool old_enable_sync_directory = FLAGS_psvr_enable_sync_directory;
    FLAGS_psvr_enable_sync_directory = true;
    const std::filesystem::path dir =
            std::filesystem::current_path() / "compress_utils_test";
    const std::filesystem::path file = dir / "dict";
    std::filesystem::remove_all(dir);
    ASSERT_TRUE(std::filesystem::create_directories(dir));

    dict::TrainDict trainer(1024);
    ASSERT_TRUE(trainer.SaveToFile(file.string(), "test dictionary"));
    ASSERT_TRUE(std::filesystem::exists(file));

    FLAGS_psvr_enable_sync_directory = old_enable_sync_directory;
    std::filesystem::remove_all(dir);
    END_OF_CASE;
}

TEST_F(CompressUtilsTests, test_page_is_compressed) {
    BufBlockPtr src = _buf_pool->AllocBufBlock(16384, nullptr);
    memset(src->frame, 0, 16384);
    ASSERT_FALSE(page_is_compressed(src->frame));
}

TEST_F(CompressUtilsTests, test_compress_and_decompress) {
    BufBlockPtr src = _buf_pool->AllocBufBlock(16384, nullptr);
    BufBlockPtr dst = _buf_pool->AllocBufBlock(16384 * 2, nullptr);
    BufBlockPtr tmp = _buf_pool->AllocBufBlock(16384 * 2, nullptr);
    for (uint32_t i = 0; i < 500; ++i) {
        rand_make_data(src->frame, 16384);
        gaia_apply::ulint compressed_size = 0;
        bool ret = compress_data(PSVR_COMPRESS_TYPE_SNAPPY, 5, src->frame, 16384, dst->frame, 16384 * 2, &compressed_size);
        ASSERT_TRUE(ret);
        ret = decompress_data(PSVR_COMPRESS_TYPE_SNAPPY, dst->frame, compressed_size, 16384, tmp->frame);
        ASSERT_TRUE(ret);
        ASSERT_EQ(0, memcmp(src->frame, tmp->frame, 16384));

        ret = compress_data(PSVR_COMPRESS_TYPE_ZSTD, 5, src->frame, 16384, dst->frame, 16384 * 2, &compressed_size);
        ASSERT_TRUE(ret);
        ret = decompress_data(PSVR_COMPRESS_TYPE_ZSTD, dst->frame, compressed_size, 16384, tmp->frame);
        ASSERT_TRUE(ret);
        ASSERT_EQ(0, memcmp(src->frame, tmp->frame, 16384));

        ret = compress_data(PSVR_COMPRESS_TYPE_LZ4, 5, src->frame, 16384, dst->frame, 16384 * 2, &compressed_size);
        ASSERT_TRUE(ret);
        ret = decompress_data(PSVR_COMPRESS_TYPE_LZ4, dst->frame, compressed_size, 16384, tmp->frame);
        ASSERT_TRUE(ret);
        ASSERT_EQ(0, memcmp(src->frame, tmp->frame, 16384));
    }
}

TEST_F(CompressUtilsTests, test_compress_failure_paths) {
    BufBlockPtr src = _buf_pool->AllocBufBlock(16384, nullptr);
    BufBlockPtr dst = _buf_pool->AllocBufBlock(16384, nullptr);
    ASSERT_NE(src, nullptr);
    ASSERT_NE(dst, nullptr);
    rand_make_data(src->frame, 16384);

    gaia_apply::ulint compressed_size = 0;
    ASSERT_FALSE(compress_data(PSVR_COMPRESS_TYPE_SNAPPY, 1,
            src->frame, 16384, dst->frame, 0, &compressed_size));
    ASSERT_FALSE(compress_data(PSVR_COMPRESS_TYPE_ZSTD, 1,
            src->frame, 16384, dst->frame, 0, &compressed_size));
    ASSERT_FALSE(compress_data(PSVR_COMPRESS_TYPE_LZ4, 1,
            src->frame, 16384, dst->frame, 0, &compressed_size));

    gaia_apply::byte invalid[8] = {};
    gaia_apply::byte output[16384] = {};
    ASSERT_FALSE(decompress_data(PSVR_COMPRESS_TYPE_SNAPPY, invalid,
            sizeof(invalid), sizeof(output), output));
    ASSERT_FALSE(decompress_data(PSVR_COMPRESS_TYPE_ZSTD, invalid,
            sizeof(invalid), sizeof(output), output));
    ASSERT_FALSE(decompress_data(PSVR_COMPRESS_TYPE_LZ4, invalid,
            sizeof(invalid), sizeof(output), output));
    END_OF_CASE;
}

TEST_F(CompressUtilsTests, test_compress_page_conditions) {
    INIT_APPLY_RAW_ARG(false);
    BufBlockPtr src = _buf_pool->AllocBufBlock(16384, nullptr);
    BufBlockPtr dst = _buf_pool->AllocBufBlock(16384 * 2, nullptr);
    ASSERT_NE(src, nullptr);
    ASSERT_NE(dst, nullptr);

    set_page_data(src->frame);
    gaia_apply::ulint compressed_size = 0;

    ASSERT_FALSE(compress_page(2, 2, 0, PSVR_COMPRESS_TYPE_SNAPPY, 1,
            src->frame, 16384, dst->frame, 16384 * 2, &compressed_size));
    ASSERT_FALSE(compress_page(2, 2, gaia_apply::ULINT_UNDEFINED,
            PSVR_COMPRESS_TYPE_SNAPPY, 1, src->frame, 16384,
            dst->frame, 16384 * 2, &compressed_size));
    ASSERT_FALSE(compress_page(2, 2, 4096, PSVR_COMPRESS_TYPE_SNAPPY, 1,
            src->frame, 4096, dst->frame, 16384 * 2, &compressed_size));

    gaia_apply::mach_write_to_8(src->frame + gaia_apply::FIL_PAGE_FILE_FLUSH_LSN, 1);
    ASSERT_FALSE(compress_page(2, 2, 4096, PSVR_COMPRESS_TYPE_SNAPPY, 1,
            src->frame, 16384, dst->frame, 16384 * 2, &compressed_size));

    gaia_apply::mach_write_to_8(src->frame + gaia_apply::FIL_PAGE_FILE_FLUSH_LSN, 0);
    gaia_apply::mach_write_to_2(src->frame + gaia_apply::FIL_PAGE_TYPE,
            gaia_apply::FIL_PAGE_COMPRESSED APPLY_RAW_ARG_NAME_CC);
    ASSERT_FALSE(compress_page(2, 2, 4096, PSVR_COMPRESS_TYPE_SNAPPY, 1,
            src->frame, 16384, dst->frame, 16384 * 2, &compressed_size));
    END_OF_CASE;
}

TEST_F(CompressUtilsTests, test_rw_with_punch_hole_with_snappy) {

    BufBlockPtr src = _buf_pool->AllocBufBlock(16384, nullptr);
    ASSERT_TRUE(src != nullptr);

    memset(src->frame, 0x1, 16384);
    set_page_data(src->frame);

    BufBlockPtr dst = _buf_pool->AllocBufBlock(16384 * 2, nullptr);
    ASSERT_TRUE(dst != nullptr);
    gaia_apply::ulint dst_len = 16384 * 2;

    bool ret = compress_page(2, 1, 4096, PSVR_COMPRESS_TYPE_SNAPPY, 5, src->frame, 16384, dst->frame, 16384 * 2, &dst_len);
    ASSERT_FALSE(ret);

    dst_len = 16384 * 2;
    ret = compress_page(2, 2, 4096, PSVR_COMPRESS_TYPE_SNAPPY, 5, src->frame, 16384, dst->frame, 16384 * 2, &dst_len);
    ASSERT_TRUE(ret);
    ASSERT_LT(dst_len, 16384);

    ASSERT_TRUE(page_is_compressed(dst->frame));
    ASSERT_EQ(page_compress_data_size(dst->frame, 4096), dst_len);

    BufBlockPtr tmp = _buf_pool->AllocBufBlock(16384, nullptr);
    ASSERT_TRUE(tmp != nullptr);


    ret = decompress_page(dst->frame, tmp->frame, 16384);
    ASSERT_TRUE(ret);

    for (uint32_t i = 0; i < 16384; i++) {
        if (dst->frame[i] != src->frame[i]) {
            LOG(ERROR) << "cmp failed:" << i;
            break;
        }
    }
    int cmp_ret = memcmp(dst->frame, src->frame, 16384);
    ASSERT_EQ(0, cmp_ret);
}

TEST_F(CompressUtilsTests, test_rw_with_punch_hole_with_zstd) {

    BufBlockPtr src = _buf_pool->AllocBufBlock(16384, nullptr);
    ASSERT_TRUE(src != nullptr);

    memset(src->frame, 0x1, 16384);
    set_page_data(src->frame);

    BufBlockPtr dst = _buf_pool->AllocBufBlock(16384 * 2, nullptr);
    ASSERT_TRUE(dst != nullptr);
    gaia_apply::ulint dst_len = 16384 * 2;

    bool ret = compress_page(2, 1, 4096, PSVR_COMPRESS_TYPE_ZSTD, 5, src->frame, 16384, dst->frame, 16384 * 2, &dst_len);
    ASSERT_FALSE(ret);

    dst_len = 16384 * 2;
    ret = compress_page(2, 2, 4096, PSVR_COMPRESS_TYPE_ZSTD, 5, src->frame, 16384, dst->frame, 16384 * 2, &dst_len);
    ASSERT_TRUE(ret);
    ASSERT_LT(dst_len, 16384);

    BufBlockPtr tmp = _buf_pool->AllocBufBlock(16384, nullptr);
    ASSERT_TRUE(tmp != nullptr);

    ret = decompress_page(dst->frame, tmp->frame, 16384);
    ASSERT_TRUE(ret);

    for (uint32_t i = 0; i < 16384; i++) {
        if (dst->frame[i] != src->frame[i]) {
            LOG(ERROR) << "cmp failed:" << i;
            break;
        }
    }
    int cmp_ret = memcmp(dst->frame, src->frame, 16384);
    ASSERT_EQ(0, cmp_ret);
}

TEST_F(CompressUtilsTests, test_rw_with_punch_hole_with_lz4) {

    BufBlockPtr src = _buf_pool->AllocBufBlock(16384, nullptr);
    ASSERT_TRUE(src != nullptr);

    memset(src->frame, 0x1, 16384);
    set_page_data(src->frame);

    BufBlockPtr dst = _buf_pool->AllocBufBlock(16384 * 2, nullptr);
    ASSERT_TRUE(dst != nullptr);
    gaia_apply::ulint dst_len = 16384 * 2;

    bool ret = compress_page(2, 1, 4096, PSVR_COMPRESS_TYPE_LZ4, 5, src->frame, 16384, dst->frame, 16384 * 2, &dst_len);
    ASSERT_FALSE(ret);

    dst_len = 16384 * 2;
    ret = compress_page(2, 2, 4096, PSVR_COMPRESS_TYPE_LZ4, 5, src->frame, 16384, dst->frame, 16384 * 2, &dst_len);
    ASSERT_TRUE(ret);
    ASSERT_LT(dst_len, 16384);

    BufBlockPtr tmp = _buf_pool->AllocBufBlock(16384, nullptr);
    ASSERT_TRUE(tmp != nullptr);

    ret = decompress_page(dst->frame, tmp->frame, 16384);
    ASSERT_TRUE(ret);

    for (uint32_t i = 0; i < 16384; i++) {
        if (dst->frame[i] != src->frame[i]) {
            LOG(ERROR) << "cmp failed:" << i;
            break;
        }
    }
    int cmp_ret = memcmp(dst->frame, src->frame, 16384);
    ASSERT_EQ(0, cmp_ret);
}

}
}
