/**************************************************************************
 * Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
 * File Name:     rbio.h
 **************************************************************************/
#pragma once

#include "psvr/model.h"
#include "psvr/namespace.h"
#include "psvr/thread_pool.hpp"
#include "psvr/queue.hpp"
#include "psvr/segment.h"
#include "psvr/utils.h"

namespace psvr {

class RbioManager;
using RbioManagerPtr = std::shared_ptr<RbioManager>;

using RbioError = pspb::RbioResponse_Error;

// the default max error code that cmp can handle
static constexpr RbioError kRbioMaxErrorCodeOld = pspb::RbioResponse::RBIO_TIMEOUT;

inline int64_t diff_rbio_lsn(uint64_t p1, uint64_t p2) {
    return (p1 > p2) ? (p1 - p2) : 0;
}

inline RbioError handle_rbio_error_code(RbioError error,
        int32_t max_error) {
    if (error > max_error) {
        return kRbioMaxErrorCodeOld;
    }
    return error;
}

inline bool rbio_req_need_wait_lsn(pspb::RbioRequest::VersionRule read_rule,
        uint64_t vlsn, uint64_t parse_lsn) {
    return read_rule != pspb::RbioRequest::LE && vlsn > parse_lsn;
}

class RbioManager : public Model<RbioManager> {
public:
struct Context;
struct Task;
struct ReadTask;
struct WriteTask;

enum class Action {
    kInit = 1,
    kRbio,
    kWaitLsn,
    kPrepare,
    kReadPage,
    kWritePage,
};

private:
using ThreadPoolType = GroupThreadPoolExecutor<Context, thread::TaskContext>;
using ThreadPoolTypePtr = std::shared_ptr<ThreadPoolType>;
using ConditionTask = LsnConditionTask<Context>;
using ConditionQueue = ClusterConditionQueue<Context>;
using ConditionThreadType = GroupConditionThread<ConditionTask, ConditionQueue>;
using ConditionThreadTypePtr = std::shared_ptr<ConditionThreadType>;

public:
    RbioManager(ClientPtr client, ControlWeakPtr control);
    FUNC_MOCK ~RbioManager();

    virtual bool SetUp() override;
    virtual void TearDown() override;
    virtual void Join() override;

    bool IncOrDecThreadNum();

    FUNC_MOCK void Dispatch(SegmentPtr segment,
            ggpb::RpcController* cntl,
            const pspb::RbioRequest* request,
            pspb::RbioResponse* response,
            google::protobuf::Closure* done,
            int64_t begin_time);
    FUNC_MOCK void Dispatch(SegmentPtr segment,
            const pspb::WritePageRequest* request,
            pspb::WritePageResponse* response,
            google::protobuf::Closure* done,
            int64_t begin_time);
    FUNC_MOCK bool Execute(Context* ctx);

    int64_t rbio_size() const { return *_rbio_size; }
    int64_t inflight_rbio_size() const { return _inflight_rbio_size.load(std::memory_order_relaxed); }

private:
    void Expose();
    template<typename Request, typename Response>
    Task* GetRbioCtx(SegmentPtr segment, uint32_t req_nr,
            const Request* request, Response* response, ggpb::Closure* closure);

    int32_t CheckStoreQuota(int32_t store_id, uint32_t nr, bool* pass);
    void PutStoreQuota(int32_t store_id, uint32_t nr);

    bool CheckQuota(uint32_t nr);
    void PutRbioCtx(Task* task);

    template<typename ERROR>
    void FinishRbioReqWithError(Context* ctx, ERROR error);

    bool InterruptRbioReqIf(Context* ctx);
    void FinishRbioReqWithTimeout(Context* ctx);
    void Schedule(Context* ctx, uint64_t delay_us = 0, bool is_retry = false, bool check_queue_size = false);
    void ScheduleNextAction(Context* ctx, Action action);
    void OnCompletion(Context* ctx);

    void SetRbioReqCtxClientId(Context* ctx);
    void Dispatch(Task* task);

    void ConditionDispatch(Task* task, SegmentPtr segment);
    void ConditionScheduleNextAction(Context* ctx,
            Action action, SegmentPtr segment, gaia_apply::lsn_t lsn);
    void RetryConditionSchedule(Context* ctx,
            SegmentPtr segment, gaia_apply::lsn_t lsn);
    void ConditionSchedule(Context* ctx,
            SegmentPtr segment, gaia_apply::lsn_t lsn);
    void ConditionFn(const ConditionTask& task);

    template<typename ErrorType>
    void FinishRbioReq(Context* ctx, ErrorType code);
    void RetryOrErrorRbioReq(Context* ctx, bool emergent = false);

    void Rbio(Context* ctx);
    void WaitLsn(Context* ctx);
    void Prepare(Context* ctx);

    void GetSpaceExtent(Context* ctx);
    void OnGetSpaceExtent(Context* ctx, RpcGetSpaceExtentMapCtx* rpc_ctx);

    void ReadPage(Context* ctx);
    void OnReadPeerPage(Context* ctx, ReadPeerPageContext* read_peer_page_ctx);

    void WritePage(Context* ctx);
private:
    uint32_t _thread_num;
    uint32_t _condi_thread_num;
    const int64_t* _rbio_size;
    std::atomic<int64_t> _inflight_rbio_size;
    std::vector<std::shared_ptr<std::atomic<int64_t>>> _store_inflight_rbio_size;
    std::atomic<int64_t> _rbio_req_in_wait_count_primary;
    std::atomic<int64_t> _rbio_req_in_wait_count_secondary;
    std::atomic<int64_t> _rbio_req_in_wait_count_peer;
    ThreadPoolTypePtr  _thread_pool;
    ConditionThreadTypePtr  _condition_thread_pool;
    // statistic
    bvar::PassiveStatus<bvar::Vector<int64_t, 2>> _stat_inflight_rbio_size;
    StatQps _stat_rbio_schedule_qps;
    StatCount _stat_rbio_err_count;
    StatLatency _stat_rbio_write_lat;
    StatLatency _stat_rbio_init_lat;
    StatLatency _stat_rbio_read_lat_primary;
    StatLatency _stat_rbio_read_lat_secondary;
    StatLatency _stat_rbio_read_lat_peer;

    StatSize _stat_rbio_req_lsn_behind_size_primary;
    StatSize _stat_rbio_req_lsn_behind_size_secondary;
    StatSize _stat_rbio_req_lsn_behind_size_peer;
    StatLatency _stat_rbio_req_wait_lsn_lat_primary;
    StatLatency _stat_rbio_req_wait_lsn_lat_secondary;
    StatLatency _stat_rbio_req_wait_lsn_lat_peer;
    StatLatency _stat_rbio_req_prepare_lat_primary;
    StatLatency _stat_rbio_req_prepare_lat_secondary;
    StatLatency _stat_rbio_req_prepare_lat_peer;
    StatLatency _stat_rbio_req_apply_lat_primary;
    StatLatency _stat_rbio_req_apply_lat_secondary;
    StatLatency _stat_rbio_req_apply_lat_peer;

    bvar::PassiveStatus<int64_t> _stat_rbio_req_in_wait_count_primary;
    bvar::PassiveStatus<int64_t> _stat_rbio_req_in_wait_count_secondary;
    bvar::PassiveStatus<int64_t> _stat_rbio_req_in_wait_count_peer;

    StatQps _stat_rbio_req_interrupt_by_lsn_qps_primary;
    StatQps _stat_rbio_req_interrupt_by_lsn_qps_secondary;
    StatQps _stat_rbio_req_interrupt_by_lsn_qps_peer;
    StatQps _stat_rbio_req_interrupt_by_space_extent_qps_primary;
    StatQps _stat_rbio_req_interrupt_by_space_extent_qps_secondary;
    StatQps _stat_rbio_req_interrupt_by_space_extent_qps_peer;
};

std::ostream& operator<<(std::ostream& os, RbioManager::Context* ctx);

template<>
inline LsnConditionTask<RbioManager::Context>::operator bool() {
    if (segment->parse_lsn() >= lsn
            || !segment_is_valid(segment)) {
        return true;
    } else if (++retry_nr > FLAGS_psvr_rbio_wait_lsn_max_times) {
        return true;
    } else {
        return false;
    }
}


}
