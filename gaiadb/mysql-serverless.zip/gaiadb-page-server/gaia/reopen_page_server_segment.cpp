/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/reopen_page_server_segment.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/reopen_page_server_segment.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int ReopenPageServerSegment::Run() {
    RpcStatus status;
    pspb::ReopenSegmentRequest request;
    pspb::ReopenSegmentResponse response;

    if (_address.empty() || _port < 1) {
        print_error("miss --cluster-addr or (--address and --port)");
        return 1;
    }

    if (_cluster_id.empty()) {
        print_error("miss --cluster-id");
        return 1;
    }

    if (!_segment_id.has_val || _segment_id.val < 1) {
        print_error("miss --segment-id");
        return 1;
    }

    request.set_log_id(_log_id);
    request.set_cluster_id(_cluster_id);
    request.set_segment_id(_segment_id.val);
    if (_no_check) {
        request.set_force(true);
    }
    if (_no_recover) {
        request.set_not_recover(true);
    }

    base::EndPoint node;
    int ret = base::str2endpoint(_address.c_str(), _port, &node);
    if (ret != 0) {
        print_error("--address and --port convert to endpoint error");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("reopen segment? no-check: %s no-recover: %s",
                _no_check ? "yes" : "no",
                _no_recover ? "yes" : "no");
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    _client.Call(_log_id, node, &pspb::ManagerService_Stub::ReopenSegment, &request, &response,
            nullptr, &status, _timeout_ms);
    if (!status.IsOk()) {
        response.mutable_status()->set_code(pspb::Status_ReturnCode_RPC_ERROR);
        response.mutable_status()->set_msg(status.msg);
    }
    return Output(response);
}

int ReopenPageServerSegment::Format(const pspb::ReopenSegmentResponse& rsp) {
    SHOW_PS_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    return 0;
}

}
}
