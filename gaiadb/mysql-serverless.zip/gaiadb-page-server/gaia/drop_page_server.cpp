/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file gaia/drop_page_server.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "gaia/drop_page_server.h"
#include "psvr/psminfo.h"

namespace psvr {
namespace gaia {

int DropPageServer::Run() {
    RpcStatus status;
    gaiapb::DropPageServerRequest request;
    gaiapb::DropPageServerResponse response;

    if (_manager_address.empty()) {
        print_error("miss --manager-address");
        return 1;
    }

    if (_addr.empty()) {
        print_error("miss --addr");
        return 1;
    }

    if (!_force) {
        bool cf_ret = execute_confirm("Drop this page server?");
        if (!cf_ret) {
            printf("quit!\n");
            return 1;
        }
    }

    PsmInfo psm_info(_manager_address, _both);
    std::vector<base::EndPoint> nodes;
    if (!psm_info.GetOrRefreshNodes(&nodes)) {
        print_error("--manager-address parse failed, cant get server list from it");
        return 1;
    }

    request.set_log_id(_log_id);
    request.set_addr(_addr);
    request.set_ignore_fail_segment(_ignore_fail);
    for (auto& node : nodes) {
        _client.Call(_log_id, node, &gaiapb::ManageService_Stub::drop_page_server, &request, &response,
                nullptr, &status, _timeout_ms);
        if (status.IsOk()
                && !rsp_is_retry(response.status())) {
            return Output(response);
        } else {
            // Fail to find method, status is not ok
            LOG(WARNING) << node << " drop page server failed, " << status << " " << response.status();
        }
    }

    // retry to call drop replica method
    do {
        gaiapb::ListPageServerRequest list_request;
        gaiapb::ListPageServerResponse list_response;
        list_request.set_log_id(_log_id);
        for (auto& node : nodes) {
            _client.Call(_log_id, node, &gaiapb::QueryService_Stub::list_page_server, &list_request, &list_response,
                    nullptr, &status, _timeout_ms);
            if (status.IsOk()
                    && !rsp_is_retry(list_response.status())) {
                LOG(NOTICE) << node << " list page server ok, all page server size:" << list_response.page_servers_size();
                for (auto& ps : list_response.page_servers()) {
                    if (ps.addr() != _addr) {
                        continue;
                    }

                    gaiapb::DropReplicaRequest drop_request;
                    gaiapb::AckResponse drop_response;
                    drop_request.set_log_id(_log_id);
                    drop_request.set_segment_id(ps.segment_id());
                    drop_request.set_replica_id(ps.replica_id());
                    drop_request.set_addr(_addr);

                    _client.Call(_log_id, node, &gaiapb::ManageService_Stub::drop_replica, &drop_request, &drop_response,
                            nullptr, &status, _timeout_ms);
                    LOG(NOTICE) << node << " drop segment " << ps.segment_id()
                        <<  " replica id " << ps.replica_id() << " addr " << _addr << " failed, "
                        << status << " " << drop_response.status();
                    if (status.IsOk() && drop_response.status().code() == 0) {
                        response.add_succ_segments(ps.segment_id());
                    } else {
                        response.add_fail_segments(ps.segment_id());
                        if (!_ignore_fail) {
                            break;
                        }
                    }
                }
                response.mutable_status()->set_code(response.fail_segments_size() ? gaiadb::GIE_FAIL : gaiadb::GIE_OK);
                response.mutable_status()->set_msg("drop ok");
                return Output(response);
            } else {
                LOG(WARNING) << node << " list page server failed, " << status << " " << list_response.status();
            }
        }

    } while (false);

    response.mutable_status()->set_code(gaiadb::GIE_FAIL);
    response.mutable_status()->set_msg("drop failed, all nodes failed");
    return Output(response);
}

int DropPageServer::Format(const gaiapb::DropPageServerResponse& rsp) {
    SHOW_PSM_OUTPUT_MSG_RETURN_IF_FAILED(rsp);
    Table table(_raw_with_table, 2);
    table.AddRowsValue({"succ_segments:", rsp.succ_segments_size()});
    table.AddRowsValue({"fail_segments:", rsp.fail_segments_size()});
    table.Display();
    return 0;
}

}
}
