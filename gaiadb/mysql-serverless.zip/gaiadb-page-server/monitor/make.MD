# 信心来源获取
## 获取集群列表
1) 通过执行 `get_services_by_path BAIDU_DBA_DBA-GaiaDB_gaia_public_multips` 命令拿到集群列表, 
其结果大致如下:
multips00.gaia.gzbh
multips00.gaia.whzj
multips00.gaia.gzdt
multips00.gaia.bdjl
multips00.gaia.cdmt
multips03.gaia.gajl
1.1) 测试执行 `get_services_by_path BAIDU_DBA_DBA-GaiaDB_gaia_online_multips` 命令拿到集群列表.

## 获取每个集群的磁盘信息
2) 执行 `gaia list-ps-store --cluster-addr bns://<集群名字>:6000 -o json` 可以拿到集群中每个节点的每个磁盘信息. 
### 每个磁盘字段对应的信息如下
{
"store_id":0,    磁盘编号
"active":true,    是否启用, true启用
"store_size":6047313952768,  磁盘可用大小
"specify_store_size":true,   是否为人工指定大小
"free_size":6047221641216,   磁盘剩余可用大小
"logic_used_size":0,         逻辑使用大小
"physical_used_size":92311552,  物理使用大小
"capacity":300,              分片数容量上限
"used_capacity":0,           分片数已使用的个数
"store_path":"/ssd1/segment",   磁盘路径
"io_error_count":0,             IO错误次数
"physical_store_size":7620805222400,    磁盘物理大小
"compress_rate":0               数据压缩比率
}

### 磁盘显示字段规则如下
磁盘列名顺序, 不在说明中列不用显示
- 节点信息
- 编号
- 启用
- 物理使用率
- 磁盘使用率
- 可使用比例
- 逻辑使用率
- 物理大小 / 使用大小 / 剩余大小
- 分片使用率
- 分片大小 / 已使用大小 / 剩余大小
- IO 错误
- 路径


### 每个节点的信息
topology_zone:  表示 zone 信息, 机器可以按照 zone 归类展示.
topology_to_offline: 表示机器处于预下线状态
pkg_version:  节点版本
git_commit:   版本对应的commit信息, 可以暂时前8位commit号

## 获取分片信息
3) 执行命令 `gaia list-ps-status -m --cluster-addr bns://<集群名字>:6000 -o pb`

### 每个节点字段如下
server_status {
  addr: "10.57.132.85:6000"         // 节点信息
  status {
    log_id: 1782974723843413
    status {
      code: SUCCESS
    }
    segments {
    }

### 每个节点下分片字段信息如下
segments {
  status {
    code: SUCCESS       // 状态信息
  }
  cluster_id: "gaiadbgsegc1"    // 集群名
  segment_id: 8                 // 集群分片ID
  fetch_lsn: 779653309464       // *_lsn 都是各种水位信息
  apply_lsn: 779653309464
  cn_lowest_lsn: 779653309464
  checkpoint_lsn: 779653309464
  store_id: 7                   // 存在磁盘上的ID
  segment_size: 34359738368     // 逻辑大小
  segment_physical_size: 34359746560    // 物理大小
  segment_status: "Open"            // 分片状态
  manager_address: "bns://gaiadbgsegc1-0000.gaia.all:13493"     // 对应集群的bns信息
  init_flag: "InitSucc"         // 初始化状态
  in_recovery: false            // 是否在恢复中
  version: 0                    // 分片版本信息
  replica_id: 1                 // 分片副本ID
  init_lsn_ok: true             // 水位初始化成功状态
  compress_num: 0               // 压缩次数
  append_lsn: 779653309464
  append_db_size: 0             // AppendDB 大小
  rebalance_from: "ip:port"     // 迁移节点
  rebalance_version: 2          // 迁移的分片版本
}

#### 展示信息
- 增加一个搜索框, 用于搜索指定的 `集群名`
- 每行一个集群名, 列信息为
-- 集群分片ID个数, 去重后求和
-- 分片数量
-- 恢复中数量
-- 异常数量:  init_lsn_ok != true,  init_flag != 'InitSucc'
-- 1副本个数:  相同 `cluster_id + segment_id` 中, `in_recovery = false` 的条数等于 1 的分片个数,
   点击后显示对应的 `segment_id`
-- 分布信息:  按照 `节点信息` + `存在磁盘上的ID` 求和, 从大到小排序
- 除分别信息外, 其他各个列支持排序

## 获取集群恢复信息
4) 执行 `gaia list-ps-recovery -m --cluster-addr bns://<集群名字>:6000 -o pb` 获取集群中恢复信息

其返回格式为 protobuf 转的 json. 
protobuf 定义见  /ssd3/yukeyong/baidu/dba/gaiadb-common/gaiadb/proto/page_server/page_server_gaia.proto 中的 BatchListRecoveryInfoResponse
其他pb见 /ssd3/yukeyong/baidu/dba/gaiadb-common/gaiadb/proto/page_server/page_server.proto

### 部分 pb 字段语义如下:
message ListRecoveryInfoResponse {
    message Segment {
        required string cluster_id = 1;     集群名字
        required uint32 segment_id = 2;     分片ID
        required uint64 segment_size = 3;   数据大小
        required int32 store_id = 4;        磁盘ID
        required uint64 recovery_size = 5;  已恢复数据大小
        required uint32 paiallel_task_count = 6;    并发数量
        required uint64 finish_rate = 7;    已恢复百分比
        required bool is_running = 8;       是否开始恢复
        optional uint32 prior_num = 9;      优先级
    }
    optional uint64 log_id = 1;
    required Status status = 2;
    repeated Segment segments = 3;
    optional int64 disk_quota = 4;          磁盘限速
    optional int64 total_quota = 5;         节点限速
}

### 展示列信息和顺序如下
- cluster_id
- segment_id
- store_id
- segment_size
- prior_num
- is_running
- recovery_size
- paiallel_task_count
- finish_rate

### 展示总结信息
- 当前恢复中的数量
- 运行中的数量
- 待运行中的数量
- 总的待恢复数据大小
- 总的已恢复数据大小


## 获取池子的已分配容量
- 在获取分片信息后, 后台提取分片的 manager_address 字段, 然后去重. 
- 然后并发请求每个 manager_address, 执行 `gaia list-segment -M <manager_address> --not-show-segments -o json`, 累加返回结果中的 used_extent_num 值.
- 累加后的 used_extent_num 值, 表示当前池子的已分配容量.
- 总分配容量 / 磁盘数量(启用状态) / 86400 = 速率 (单位已经是 MB/s), 将其显示为最小备份速率. 比添加 title 提示. 
- 将以上2个信息:  总分配容量, 最小备份速率, 放在"刷新分片"的前面. 


# 要求:
- 生成一个浏览器界面, 在顶部让用户选择集群列表. 
- 当用户选择集群列表后, 然后在页面显示 2) 的结果. 
- 在磁盘信息右侧增加一个分片信息选项卡, 可以点击查看 3) 的信息.

# 代码规范要求
- 遵循 `curly` 规则: `if` / `else if` / `for` / `while` 等控制语句必须使用大括号.
- 遵循 `max-len` 规则: 单行长度不超过 120 字符.
- 遵循 `indentation` 规则: JS 和 CSS 使用 4 个空格缩进; 顶层 CSS 选择器从 0 缩进开始.
- 遵循 `rule-empty-line-before` 规则: CSS 规则块之间保留空行.
- 遵循 `color-hex-length` 规则: 可缩写的十六进制颜色使用短写, 例如 `#ffffff` 写成 `#fff`.
- 避免未使用代码: 不保留未使用的函数、变量或常量.

# 其他
- 当每次执行修改完成后, 需要重启服务.