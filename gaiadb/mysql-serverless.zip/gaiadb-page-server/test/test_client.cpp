/***************************************************************************
* Copyright (c) Baidu.com, Inc. All Rights Reserved
**************************************************************************/
/**
* @file test/test_client.cpp
* @author yukeyong@baidu.com
* @brief
*/

#include "test/test_common.h"
#include "psvr/client.h"
#include "test/mock_rpc_client.h"

namespace psvr {
namespace test {

class ClientTests : public ::testing::Test {
 public:
    ClientTests() {}
    virtual ~ClientTests() {}

    void SetUp() {
        g_mock_channel.reset(new MockRpcChannel);
        _client.reset(new Client);
        _mock_channel = g_mock_channel.get();
        _rpc_client = new MockBrpcClient;

        _client->_rpc_client.reset(_rpc_client);
    }

    void TearDown() {
        // _client must be destroyed (and thus MockBrpcClient) BEFORE
        // g_mock_channel is reset. The ON_CALL in MockBrpcClient captures
        // g_mock_channel. If g_mock_channel is the last reference and is
        // reset while MockBrpcClient is still alive, its destructor will
        // hold g_gmock_mutex while destroying the action, which triggers
        // MockRpcChannel::~MockRpcChannel() that also needs g_gmock_mutex
        // -> deadlock.
        _client.reset();
        g_mock_channel.reset();
    }

private:
    std::shared_ptr<Client> _client;
    MockBrpcClient* _rpc_client;
    MockRpcChannel* _mock_channel;
};

void rpc_done(ClientContext<gaiapb::GetPageServerRequest, gaiapb::GetPageServerResponse>* ctx) {
    delete ctx;
}

TEST_F(ClientTests, test_Join) {

    EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(AtLeast(1));
    EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
        .WillOnce(Invoke(MockClosureDefault));

    bool stopped = false;
    std::thread t([this, &stopped](){
        while(!stopped) {
            auto ctx = new ClientContext<gaiapb::GetPageServerRequest, gaiapb::GetPageServerResponse>;
            ctx->servers.push_back(base::EndPoint());
            ctx->servers.push_back(base::EndPoint());
            auto closure = brpc::NewCallback(&rpc_done, ctx);
            _client->GetSegmentInfo(ctx, closure);
        }
    });

    std::thread t2([&stopped](){
        sleep_for(10000);
        stopped = true;
    });

    sleep_for(1000);
    _client->Stop(false);
    _client->Stop(true);
    t.join();
    t2.join();
}

TEST_F(ClientTests, test_ClientContext) {
    auto* ctx = new ClientContext<gaiapb::GetPageServerRequest, gaiapb::GetPageServerResponse>;
    ASSERT_EQ(ctx->servers.size(), 0);
    ASSERT_EQ(ctx->idx, 0);

    ASSERT_FALSE(ctx->Retryable());

    ctx->servers.push_back(base::EndPoint());
    ASSERT_TRUE(ctx->Retryable());

    ASSERT_EQ(base::EndPoint(), ctx->current_server());

    ++ctx->idx;
    ASSERT_FALSE(ctx->Retryable());
}

TEST_F(ClientTests, test_all) {
    {
        brpc::ChannelOptions options;
        RpcClient client;
    }
    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new ClientContext<gaiapb::GetPageServerRequest, gaiapb::GetPageServerResponse>;
        ctx->servers.push_back(base::EndPoint());
        _client->GetSegmentInfo(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new ClientContext<gaiapb::LogServiceBatchGetRequest, gaiapb::LogServiceBatchGetResponse>;
        ctx->servers.push_back(base::EndPoint());
        _client->ListLogService(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new ClientContext<gaiapb::GetSpaceMetaRequest, gaiapb::GetSpaceMetaResponse>;
        ctx->servers.push_back(base::EndPoint());
        _client->GetSpaceMeta(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new ClientContext<gaiapb::GetSpaceExtentMapRequest, gaiapb::GetSpaceExtentMapResponse>;
        ctx->servers.push_back(base::EndPoint());
        _client->GetSpaceExtentMap(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new ClientContext<gaiapb::GetSegmentRequest, gaiapb::GetSegmentResponse>;
        ctx->servers.push_back(base::EndPoint());
        _client->ListSegmentReplica(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new ClientContext<gaiapb::UpdateReplicaRecoveryStatusRequest, gaiapb::AckResponse>;
        ctx->servers.push_back(base::EndPoint());
        _client->UpdateReplicaRecoveryStatus(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new ClientContext<pspb::ReadPageRequest, pspb::ReadPageResponse, gaiadb::common::PeerZone>;
        ctx->servers.push_back(gaiadb::common::PeerZone());
        _client->ReadPhysicalPage(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new ClientContext<pspb::RbioRequest, pspb::RbioResponse, gaiadb::common::PeerZone>;
        ctx->servers.push_back(gaiadb::common::PeerZone());
        _client->Rbio(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new ClientContext<gaiapb::PageServerHeartbeatRequest, gaiapb::HeartbeatResponse>;
        ctx->servers.push_back(base::EndPoint());
        _client->Heartbeat(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new ClientContext<gaiapb::BatchPageServerHeartbeatRequest, gaiapb::BatchPageServerHeartbeatResponse>;
        ctx->servers.push_back(base::EndPoint());
        _client->BatchHeartbeat(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new ClientContext<pspb::WritePageRequest, pspb::WritePageResponse>;
        ctx->servers.push_back(base::EndPoint());
        _client->WritePhysicalPages(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new ClientContext<lspb::psrv_get_log_request, lspb::psrv_get_log_response, gaiadb::common::PeerZone>;
        ctx->servers.push_back(gaiadb::common::PeerZone());
        _client->GetLog(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new RpcBatchGetLogCtx;
        ctx->servers.push_back(gaiadb::common::PeerZone());
        _client->BatchGetLog(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        auto ctx = new RpcSetReplicaRecovery;
        ctx->servers.push_back(base::EndPoint());
        _client->SetReplicaRecovery(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        brpc::Controller cntl;
        auto ctx = new RpcReadCtx;
        ctx->controller = &cntl;
        ctx->servers.push_back(gaiadb::common::PeerZone());
        _client->Read(ctx, nullptr);
        delete ctx;
    }

    {
        EXPECT_CALL(*_rpc_client, GetOrCreateRpcChannel(_)).Times(1);
        EXPECT_CALL(*_mock_channel, CallMethod(_,_,_,_,_))
            .WillOnce(Invoke(MockClosureDefault));
        brpc::Controller cntl;
        auto ctx = new RpcGetRedoRecLog;
        ctx->controller = &cntl;
        ctx->servers.push_back(gaiadb::common::PeerZone());
        _client->GetRedoRecLog(ctx, nullptr);
        delete ctx;
    }

}

TEST_F(ClientTests, test_update_leader) {
     {
        auto rpc_ctx = new ClientContext<gaiapb::BatchPageServerHeartbeatRequest, gaiapb::BatchPageServerHeartbeatResponse>;
        rpc_ctx->servers.push_back(base::EndPoint());
        rpc_ctx->servers.push_back(base::EndPoint());
        rpc_ctx->servers.push_back(base::EndPoint());
        rpc_ctx->idx = 3;
        base::EndPoint ep1;
        base::str2endpoint("1.2.3.4:5", &ep1);
        rpc_ctx->servers.push_back(ep1);
        base::EndPoint ep2;
        base::str2endpoint("1.2.3.4:6", &ep2);
        rpc_ctx->servers.push_back(ep2);
        base::EndPoint ep3;
        base::str2endpoint("1.2.3.4:7", &ep3);
        rpc_ctx->servers.push_back(ep3);
        rpc_ctx->status.code = RpcCode::kSuccess;
        rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_REDIRECT);
        rpc_ctx->response.mutable_status()->mutable_leader_hint()->CopyFrom(gaiadb::common::endpoint2node(ep3));

        try_update_leader(rpc_ctx, gaiadb::GIE_REDIRECT);
        ASSERT_EQ(rpc_ctx->servers[4], ep3);
        ASSERT_EQ(rpc_ctx->servers[5], ep2);
        delete rpc_ctx;
    }
}

TEST_F(ClientTests, test_rpc_failed) {
    auto rpc_ctx = new ClientContext<gaiapb::BatchPageServerHeartbeatRequest, gaiapb::BatchPageServerHeartbeatResponse>;
    rpc_ctx->status.Reset(gaiadb::common::RpcCode::kFailGetChannel, "fail");
    bool not_exists;
    bool rpc_ok;
    ASSERT_TRUE(rpc_failed(rpc_ctx, &not_exists, &rpc_ok));
    ASSERT_FALSE(rpc_ok);

    rpc_ctx->status.Reset(gaiadb::common::RpcCode::kSuccess, "ok");
    rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_NOT_EXIST);
    ASSERT_TRUE(rpc_failed(rpc_ctx, &not_exists, &rpc_ok));
    ASSERT_TRUE(not_exists);
    ASSERT_TRUE(rpc_ok);

    rpc_ctx->response.mutable_status()->set_code(gaiadb::GIE_OK);
    ASSERT_FALSE(rpc_failed(rpc_ctx, &not_exists, &rpc_ok));
    ASSERT_FALSE(not_exists);
    ASSERT_TRUE(rpc_ok);

    ASSERT_FALSE(rpc_failed(rpc_ctx, &not_exists));
}

}
}
